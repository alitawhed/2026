import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { once } from 'node:events';
import {
  createBackendServer,
  detectRasterImageFormat,
  FailureKind,
  ServerSideSallaTokenStore,
} from './app.mjs';

const VALID_PNG = Buffer.from(
  '89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360606060000000050001a5f645400000000049454e44ae426082',
  'hex',
);
const VALID_WEBP = Buffer.from('524946461800000057454250565038200c0000003001009d012a010001000200', 'hex');
const VALID_JPG = Buffer.from('ffd8ffe000104a46494600010100000100010000ffd9', 'hex');

async function startHttpServer(handler) {
  const srv = http.createServer(handler);
  srv.listen(0, '127.0.0.1');
  await once(srv, 'listening');
  const addr = srv.address();
  return { server: srv, baseUrl: `http://127.0.0.1:${addr.port}` };
}

test('detectRasterImageFormat detects PNG, JPEG, WEBP, GIF, BMP cleanly', () => {
  assert.equal(detectRasterImageFormat(VALID_PNG), 'png');
  assert.equal(detectRasterImageFormat(VALID_WEBP), 'webp');
  assert.equal(detectRasterImageFormat(VALID_JPG), 'jpg');
  assert.equal(detectRasterImageFormat(Buffer.from('<html>not image</html>')), null);
});

test('POST /api/images/fetch-batch enforces bearer auth, fetches images server-side, classifies 403/404/corrupt, and blocks SSRF', async (t) => {
  const upstream = await startHttpServer((req, res) => {
    if (req.url === '/ok.webp') {
      res.writeHead(200, { 'Content-Type': 'image/webp' });
      res.end(VALID_WEBP);
    } else if (req.url === '/ok.png') {
      res.writeHead(200, { 'Content-Type': 'application/octet-stream' });
      res.end(VALID_PNG);
    } else if (req.url === '/salla-403.jpg') {
      res.writeHead(403, { 'Content-Type': 'text/html' });
      res.end('Forbidden');
    } else if (req.url === '/missing.jpg') {
      res.writeHead(404, { 'Content-Type': 'text/html' });
      res.end('Not Found');
    } else if (req.url === '/corrupt.jpg') {
      res.writeHead(200, { 'Content-Type': 'image/jpeg' });
      res.end(Buffer.from([0x01, 0x02, 0x03, 0x04, 0x05]));
    } else {
      res.writeHead(404);
      res.end();
    }
  });
  t.after(() => upstream.server.close());

  const backendSrv = createBackendServer({
    backendAccessToken: 'secret-token-123',
    allowPrivateForTesting: true,
  });
  backendSrv.listen(0, '127.0.0.1');
  await once(backendSrv, 'listening');
  t.after(() => backendSrv.close());
  const backendUrl = `http://127.0.0.1:${backendSrv.address().port}`;

  // Unauthorized request rejected
  const unauthResp = await fetch(`${backendUrl}/api/images/fetch-batch`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ images: [] }),
  });
  assert.equal(unauthResp.status, 401);

  // Batch fetch mixed URLs
  const batchResp = await fetch(`${backendUrl}/api/images/fetch-batch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer secret-token-123',
    },
    body: JSON.stringify({
      images: [
        { id: 1, gtin: '628001', url: `${upstream.baseUrl}/ok.webp` },
        { id: 2, gtin: '628002', url: `${upstream.baseUrl}/ok.png` },
        { id: 3, gtin: '628003', url: `${upstream.baseUrl}/salla-403.jpg` },
        { id: 4, gtin: '628004', url: `${upstream.baseUrl}/missing.jpg` },
        { id: 5, gtin: '628005', url: `${upstream.baseUrl}/corrupt.jpg` },
      ],
    }),
  });
  assert.equal(batchResp.status, 200);
  const data = await batchResp.json();
  assert.equal(data.total, 5);
  assert.equal(data.succeededCount, 2);
  assert.equal(data.failedCount, 3);

  const r1 = data.results.find((r) => r.id === 1);
  assert.equal(r1.ok, true);
  assert.equal(r1.detectedFormat, 'webp');
  assert.deepEqual(Buffer.from(r1.base64Data, 'base64'), VALID_WEBP);

  const r2 = data.results.find((r) => r.id === 2);
  assert.equal(r2.ok, true);
  assert.equal(r2.detectedFormat, 'png');

  const r3 = data.results.find((r) => r.id === 3);
  assert.equal(r3.ok, false);
  assert.equal(r3.statusCode, 403);
  assert.equal(r3.failureKind, FailureKind.HTTP_FORBIDDEN);

  const r4 = data.results.find((r) => r.id === 4);
  assert.equal(r4.ok, false);
  assert.equal(r4.statusCode, 404);
  assert.equal(r4.failureKind, FailureKind.HTTP_NOT_FOUND);

  const r5 = data.results.find((r) => r.id === 5);
  assert.equal(r5.ok, false);
  assert.equal(r5.failureKind, FailureKind.CORRUPT_OR_NOT_IMAGE);
});

test('SSRF protection blocks localhost and private IP fetches on strict production backend', async (t) => {
  const backendSrv = createBackendServer({
    backendAccessToken: 'tok',
    allowPrivateForTesting: false,
  });
  backendSrv.listen(0, '127.0.0.1');
  await once(backendSrv, 'listening');
  t.after(() => backendSrv.close());
  const backendUrl = `http://127.0.0.1:${backendSrv.address().port}`;

  const resp = await fetch(`${backendUrl}/api/images/fetch-batch`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer tok' },
    body: JSON.stringify({
      images: [
        { id: 1, url: 'http://127.0.0.1/secret.png' },
        { id: 2, url: 'http://169.254.169.254/latest/meta-data/' },
      ],
    }),
  });
  const json = await resp.json();
  assert.equal(json.succeededCount, 0);
  assert.equal(json.results[0].failureKind, FailureKind.BLOCKED_NETWORK);
  assert.equal(json.results[1].failureKind, FailureKind.BLOCKED_NETWORK);
});

test('Official Salla OAuth flow exchanges code server-side without exposing tokens and fetches product images', async (t) => {
  let lastImgAuth = '';
  const mockSalla = await startHttpServer(async (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    if (u.pathname === '/oauth2/token' && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          access_token: 'salla_access_xyz',
          refresh_token: 'salla_refresh_abc',
          expires_in: 1209600,
          scope: 'offline_access products.read',
        }),
      );
    } else if (u.pathname === '/admin/v2/products') {
      lastImgAuth = req.headers.authorization || '';
      if (lastImgAuth !== 'Bearer salla_access_xyz') {
        res.writeHead(401);
        res.end();
        return;
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          pagination: { total: 1, currentPage: 1, totalPages: 1 },
          data: [
            {
              id: 501,
              name: 'منتج سلة الرسمي',
              sku: 'SKU-501',
              gtin: '6281000005011',
              main_image: `${mockSalla.baseUrl}/media/501_main.jpg`,
              images: [
                { url: `${mockSalla.baseUrl}/media/501_main.jpg`, main: true, sort: 0 },
                { url: `${mockSalla.baseUrl}/media/501_side.webp`, main: false, sort: 1 },
              ],
            },
          ],
        }),
      );
    } else if (u.pathname === '/media/501_main.jpg') {
      res.writeHead(200, { 'Content-Type': 'image/jpeg' });
      res.end(VALID_JPG);
    } else if (u.pathname === '/media/501_side.webp') {
      res.writeHead(200, { 'Content-Type': 'image/webp' });
      res.end(VALID_WEBP);
    } else {
      res.writeHead(404);
      res.end();
    }
  });
  t.after(() => mockSalla.server.close());

  const tokenStore = new ServerSideSallaTokenStore();
  const backendSrv = createBackendServer({
    backendAccessToken: 'client-token',
    sallaClientId: 'salla-client-id',
    sallaClientSecret: 'super-secret-client-secret',
    sallaRedirectUri: 'https://backend.example.com/api/salla/auth/callback',
    sallaOAuthBaseUrl: mockSalla.baseUrl,
    sallaApiBaseUrl: `${mockSalla.baseUrl}/admin/v2`,
    tokenStore,
    allowPrivateForTesting: true,
  });
  backendSrv.listen(0, '127.0.0.1');
  await once(backendSrv, 'listening');
  t.after(() => backendSrv.close());
  const backendUrl = `http://127.0.0.1:${backendSrv.address().port}`;

  // 1. Get authorize URL with CSRF state
  const authUrlResp = await fetch(`${backendUrl}/api/salla/auth/url`, {
    headers: { Authorization: 'Bearer client-token' },
  });
  const authUrlJson = await authUrlResp.json();
  assert.equal(authUrlJson.ok, true);
  const authUrl = new URL(authUrlJson.authorizeUrl);
  const state = authUrl.searchParams.get('state');
  assert.ok(state);
  assert.equal(authUrl.searchParams.get('client_id'), 'salla-client-id');

  // 2. Simulate OAuth callback with code & state -> verify tokens stay server-side only
  const cbResp = await fetch(`${backendUrl}/api/salla/auth/callback?code=auth_code_1&state=${encodeURIComponent(state)}`);
  assert.equal(cbResp.status, 200);
  const cbHtml = await cbResp.text();
  assert.ok(!cbHtml.includes('salla_access_xyz'));
  assert.ok(!cbHtml.includes('super-secret-client-secret'));

  // 3. Config status shows connected=true without exposing secrets
  const statusResp = await fetch(`${backendUrl}/api/salla/config-status`, {
    headers: { Authorization: 'Bearer client-token' },
  });
  const statusJson = await statusResp.json();
  assert.equal(statusJson.configured, true);
  assert.equal(statusJson.connected, true);
  assert.ok(!JSON.stringify(statusJson).includes('salla_access_xyz'));

  // 4. Fetch catalog + verify multiple downloaded images returned as base64
  const prodResp = await fetch(`${backendUrl}/api/salla/products?page=1&downloadImages=true`, {
    headers: { Authorization: 'Bearer client-token' },
  });
  assert.equal(prodResp.status, 200);
  const prodJson = await prodResp.json();
  assert.equal(prodJson.products.length, 1);
  assert.equal(prodJson.products[0].gtin, '6281000005011');
  assert.equal(prodJson.products[0].imageUrls.length, 2);
  assert.equal(prodJson.products[0].downloadedImages.length, 2);
  assert.equal(prodJson.products[0].downloadedImages[0].detectedFormat, 'jpg');
  assert.equal(prodJson.products[0].downloadedImages[1].detectedFormat, 'webp');
});
