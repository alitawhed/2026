import http from 'node:http';
import crypto from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';
import fs from 'node:fs/promises';
import path from 'node:path';

export const DEFAULT_MAX_FILE_BYTES = 20 * 1024 * 1024; // 20 MB
export const DEFAULT_CONNECT_TIMEOUT_MS = 12_000;
export const DEFAULT_MAX_BATCH_ITEMS = 50;
export const DEFAULT_MAX_JSON_BODY_BYTES = 1024 * 1024; // 1 MB
export const DEFAULT_MAX_REDIRECTS = 5;

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'ip6-localhost',
  'ip6-loopback',
  'metadata.google.internal',
  'metadata',
]);

export const FailureKind = {
  INVALID_URL: 'INVALID_URL',
  BLOCKED_NETWORK: 'BLOCKED_NETWORK',
  TIMEOUT: 'TIMEOUT',
  NETWORK_ERROR: 'NETWORK_ERROR',
  HTTP_FORBIDDEN: 'HTTP_FORBIDDEN',
  HTTP_UNAUTHORIZED: 'HTTP_UNAUTHORIZED',
  HTTP_NOT_FOUND: 'HTTP_NOT_FOUND',
  HTTP_RATE_LIMITED: 'HTTP_RATE_LIMITED',
  HTTP_SERVER_ERROR: 'HTTP_SERVER_ERROR',
  HTTP_ERROR: 'HTTP_ERROR',
  FILE_TOO_LARGE: 'FILE_TOO_LARGE',
  UNSUPPORTED_FORMAT: 'UNSUPPORTED_FORMAT',
  CORRUPT_OR_NOT_IMAGE: 'CORRUPT_OR_NOT_IMAGE',
};

const FAILURE_ARABIC = {
  [FailureKind.INVALID_URL]: 'رابط غير صالح',
  [FailureKind.BLOCKED_NETWORK]: 'رابط محظور لأسباب أمنية',
  [FailureKind.TIMEOUT]: 'انتهت مهلة الاتصال',
  [FailureKind.NETWORK_ERROR]: 'خطأ في الاتصال بالشبكة',
  [FailureKind.HTTP_FORBIDDEN]: 'HTTP 403: رفض الوصول',
  [FailureKind.HTTP_UNAUTHORIZED]: 'رابط يحتاج إلى صلاحيات أو جلسة دخول',
  [FailureKind.HTTP_NOT_FOUND]: 'HTTP 404: الصورة غير موجودة',
  [FailureKind.HTTP_RATE_LIMITED]: 'HTTP 429: تجاوز حد الطلبات',
  [FailureKind.HTTP_SERVER_ERROR]: 'HTTP 5xx: خطأ من الخادم',
  [FailureKind.HTTP_ERROR]: 'خطأ استجابة من الخادم',
  [FailureKind.FILE_TOO_LARGE]: 'حجم الصورة يتجاوز الحد المسموح',
  [FailureKind.UNSUPPORTED_FORMAT]: 'صيغة صورة أو ملف غير مدعومة',
  [FailureKind.CORRUPT_OR_NOT_IMAGE]: 'ملف تالف أو ليس صورة حقيقية',
};

export function encodeSpacesAndUnsafeChars(rawUrl) {
  return String(rawUrl || '').trim().replaceAll('&amp;', '&').replaceAll(' ', '%20');
}

export function isDisallowedIpv4String(ip) {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) return true;
  const [a, b] = parts;
  if (a === 0 || a === 10 || a === 127) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a >= 224) return true;
  return false;
}

export function isDisallowedIpAddress(ip) {
  const clean = String(ip || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  const version = net.isIP(clean);
  if (version === 4) return isDisallowedIpv4String(clean);
  if (version === 6) {
    if (clean === '::' || clean === '::1' || clean === '0:0:0:0:0:0:0:1' || clean === '0:0:0:0:0:0:0:0') return true;
    if (clean.startsWith('fc') || clean.startsWith('fd') || clean.startsWith('fe80:') || clean.startsWith('ff')) return true;
    const v4Match = clean.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (v4Match) return isDisallowedIpv4String(v4Match[1]);
    return false;
  }
  return true;
}

function isObfuscatedOrLiteralDisallowedHost(host) {
  const clean = host.replace(/^\[|\]$/g, '').toLowerCase();
  if (net.isIP(clean)) return isDisallowedIpAddress(clean);
  if (/^(0x[0-9a-f]+|\d+)$/i.test(clean)) return true;
  if (/^(0x[0-9a-f]+|0\d+|\d+)(\.(0x[0-9a-f]+|0\d+|\d+)){1,2}$/i.test(clean)) return true;
  return false;
}

export function validateRemoteImageSyntax(rawUrl, allowPrivateForTesting = false) {
  const cleaned = encodeSpacesAndUnsafeChars(rawUrl);
  if (!cleaned) {
    return { isValid: false, normalizedUrl: '', failureKind: FailureKind.INVALID_URL, reason: 'رابط الصورة فارغ' };
  }
  const lower = cleaned.toLowerCase();
  if (!lower.startsWith('http://') && !lower.startsWith('https://')) {
    return {
      isValid: false,
      normalizedUrl: cleaned,
      failureKind: FailureKind.INVALID_URL,
      reason: 'صيغة الرابط غير صالحة — يجب أن يبدأ بـ https:// أو http://',
    };
  }
  let parsed;
  try {
    parsed = new URL(cleaned);
  } catch {
    return {
      isValid: false,
      normalizedUrl: cleaned,
      failureKind: FailureKind.INVALID_URL,
      reason: 'رابط الصورة يحتوي على صيغة غير صالحة',
    };
  }
  if (parsed.username || parsed.password) {
    return {
      isValid: false,
      normalizedUrl: cleaned,
      failureKind: FailureKind.INVALID_URL,
      reason: 'رابط الصورة يحتوي على بيانات مصادقة مضمنة غير مسموح بها',
    };
  }
  const host = (parsed.hostname || '').trim().toLowerCase();
  if (!host) {
    return {
      isValid: false,
      normalizedUrl: cleaned,
      failureKind: FailureKind.INVALID_URL,
      reason: 'رابط الصورة لا يحتوي على اسم نطاق صالح',
    };
  }
  if (!allowPrivateForTesting) {
    if (
      BLOCKED_HOSTNAMES.has(host) ||
      host.endsWith('.local') ||
      host.endsWith('.internal') ||
      host.endsWith('.localhost') ||
      isObfuscatedOrLiteralDisallowedHost(host)
    ) {
      return {
        isValid: false,
        normalizedUrl: cleaned,
        failureKind: FailureKind.BLOCKED_NETWORK,
        reason: 'تم حظر الرابط لأنه يشير إلى عنوان شبكة محلي أو خاص غير آمن',
      };
    }
  }
  return { isValid: true, normalizedUrl: parsed.toString() };
}

export async function verifyHostSafe(host, lookupFn = dns.lookup, allowPrivateForTesting = false) {
  if (allowPrivateForTesting) return;
  const cleanHost = String(host || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (
    BLOCKED_HOSTNAMES.has(cleanHost) ||
    cleanHost.endsWith('.local') ||
    cleanHost.endsWith('.internal') ||
    cleanHost.endsWith('.localhost')
  ) {
    const err = new Error('تم حظر الرابط لأنه يشير إلى عنوان شبكة محلي أو داخلي');
    err.code = 'SECURITY_URL_BLOCKED';
    throw err;
  }
  if (net.isIP(cleanHost)) {
    if (isDisallowedIpAddress(cleanHost)) {
      const err = new Error('تم رفض الاتصال بعنوان شبكة محلي أو خاص غير آمن');
      err.code = 'SECURITY_URL_BLOCKED';
      throw err;
    }
    return;
  }
  const resolved = await lookupFn(cleanHost, { all: true });
  if (!Array.isArray(resolved) || resolved.length === 0) {
    const err = new Error(`تعذر العثور على النطاق: ${cleanHost}`);
    err.code = 'ENOTFOUND';
    throw err;
  }
  for (const item of resolved) {
    const addr = typeof item === 'string' ? item : item?.address;
    if (isDisallowedIpAddress(addr)) {
      const err = new Error('تم رفض الاتصال بعنوان شبكة محلي أو خاص غير آمن');
      err.code = 'SECURITY_URL_BLOCKED';
      throw err;
    }
  }
}

export function detectRasterImageFormat(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 4) return null;
  // PNG
  if (
    buf.length >= 8 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47 &&
    buf[4] === 0x0d &&
    buf[5] === 0x0a &&
    buf[6] === 0x1a &&
    buf[7] === 0x0a
  ) {
    return 'png';
  }
  // JPEG
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return 'jpg';
  }
  // GIF87a / GIF89a
  if (
    buf.length >= 6 &&
    buf[0] === 0x47 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x38 &&
    (buf[4] === 0x37 || buf[4] === 0x39) &&
    buf[5] === 0x61
  ) {
    return 'gif';
  }
  // WEBP: RIFF....WEBP
  if (
    buf.length >= 12 &&
    buf[0] === 0x52 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x46 &&
    buf[8] === 0x57 &&
    buf[9] === 0x45 &&
    buf[10] === 0x42 &&
    buf[11] === 0x50
  ) {
    return 'webp';
  }
  // BMP: BM
  if (buf[0] === 0x42 && buf[1] === 0x4d) {
    return 'bmp';
  }
  // AVIF: ISO BMFF ftyp box
  if (buf.length >= 12 && buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70) {
    const ftyp = buf.subarray(8, Math.min(buf.length, 64)).toString('ascii').toLowerCase();
    if (ftyp.includes('avif') || ftyp.includes('avis')) {
      return 'avif';
    }
  }
  return null;
}

function detectNonImagePayload(buf, mime, finalUrl) {
  const headText = buf
    .subarray(0, Math.min(buf.length, 1024))
    .toString('utf8')
    .replace(/^\uFEFF/, '')
    .trimStart()
    .toLowerCase();

  if (buf.length >= 4 && buf.subarray(0, 4).toString('ascii') === '%PDF') {
    return { kind: FailureKind.UNSUPPORTED_FORMAT, reason: 'الرابط يشير إلى ملف PDF وليس ملف صورة' };
  }
  if (buf.length >= 2 && buf[0] === 0x4d && buf[1] === 0x5a) {
    return { kind: FailureKind.UNSUPPORTED_FORMAT, reason: 'تم رفض الملف لأن محتواه تنفيذي وليس صورة صالحة' };
  }
  if (buf.length >= 4 && buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46) {
    return { kind: FailureKind.UNSUPPORTED_FORMAT, reason: 'تم رفض الملف لأن محتواه تنفيذي وليس صورة صالحة' };
  }
  if (mime.includes('svg') || headText.startsWith('<svg') || (headText.startsWith('<?xml') && headText.includes('<svg'))) {
    return { kind: FailureKind.UNSUPPORTED_FORMAT, reason: 'صيغة SVG غير مدعومة كصورة نقطية (المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF)' };
  }
  const isHtml =
    mime === 'text/html' ||
    mime === 'application/xhtml+xml' ||
    headText.startsWith('<!doctype html') ||
    headText.startsWith('<html');
  if (isHtml) {
    const lowerUrl = String(finalUrl || '').toLowerCase();
    const looksLikeLogin =
      lowerUrl.includes('/login') ||
      lowerUrl.includes('/signin') ||
      lowerUrl.includes('/auth') ||
      headText.includes('type="password"') ||
      headText.includes('name="password"');
    if (looksLikeLogin) {
      return { kind: FailureKind.HTTP_UNAUTHORIZED, reason: 'الرابط يتطلب تسجيل دخول أو صلاحيات وصول' };
    }
    return { kind: FailureKind.CORRUPT_OR_NOT_IMAGE, reason: 'الرابط أعاد صفحة ويب HTML بدلاً من صورة حقيقية' };
  }
  return null;
}

function isRejectedContentType(mime) {
  if (!mime) return false;
  if (mime.startsWith('image/')) {
    return mime.includes('svg') || mime.includes('xml');
  }
  return mime !== 'application/octet-stream' && mime !== 'binary/octet-stream';
}

async function readResponseWithCap(response, maxBytes) {
  const declared = Number(response.headers.get('content-length') || -1);
  if (Number.isFinite(declared) && declared > maxBytes) {
    const err = new Error(`حجم الصورة يتجاوز الحد المسموح (${Math.round(maxBytes / (1024 * 1024))} ميجابايت)`);
    err.code = 'PAYLOAD_TOO_LARGE';
    throw err;
  }
  if (!response.body) {
    const ab = await response.arrayBuffer();
    const buf = Buffer.from(ab);
    if (buf.length > maxBytes) {
      const err = new Error('حجم الصورة يتجاوز الحد المسموح');
      err.code = 'PAYLOAD_TOO_LARGE';
      throw err;
    }
    return buf;
  }
  const chunks = [];
  let total = 0;
  for await (const chunk of response.body) {
    const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += b.length;
    if (total > maxBytes) {
      const err = new Error('حجم الصورة يتجاوز الحد المسموح');
      err.code = 'PAYLOAD_TOO_LARGE';
      throw err;
    }
    chunks.push(b);
  }
  return Buffer.concat(chunks);
}

export async function fetchAndVerifyImageServerSide(
  rawUrl,
  {
    fetchImpl = globalThis.fetch,
    lookupFn = dns.lookup,
    timeoutMs = DEFAULT_CONNECT_TIMEOUT_MS,
    maxBytes = DEFAULT_MAX_FILE_BYTES,
    allowPrivateForTesting = false,
  } = {},
) {
  const syntax = validateRemoteImageSyntax(rawUrl, allowPrivateForTesting);
  if (!syntax.isValid) {
    return {
      url: String(rawUrl || ''),
      normalizedUrl: syntax.normalizedUrl,
      ok: false,
      statusCode: 0,
      finalUrl: syntax.normalizedUrl,
      failureKind: syntax.failureKind,
      failureCategory: FAILURE_ARABIC[syntax.failureKind],
      failureReason: syntax.reason,
    };
  }

  let currentUrl = syntax.normalizedUrl;
  let redirects = 0;

  while (true) {
    const parsed = new URL(currentUrl);
    try {
      await verifyHostSafe(parsed.hostname, lookupFn, allowPrivateForTesting);
    } catch (e) {
      const isSecurity = e?.code === 'SECURITY_URL_BLOCKED';
      const kind = isSecurity ? FailureKind.BLOCKED_NETWORK : FailureKind.NETWORK_ERROR;
      return {
        url: String(rawUrl),
        normalizedUrl: syntax.normalizedUrl,
        ok: false,
        statusCode: 0,
        finalUrl: currentUrl,
        failureKind: kind,
        failureCategory: FAILURE_ARABIC[kind],
        failureReason: e?.message || 'تعذر التحقق من عنوان الخادم',
      };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new Error('ETIMEDOUT')), timeoutMs);

    let resp;
    try {
      resp = await fetchImpl(currentUrl, {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          Accept: 'image/avif,image/webp,image/png,image/jpeg,image/gif,image/bmp,image/*;q=0.8,*/*;q=0.5',
          'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
          'User-Agent': 'ReportManager-Backend/1.0 (Authorized Image Sync)',
        },
      });
    } catch (e) {
      clearTimeout(timer);
      const isTimeout = e?.name === 'AbortError' || e?.message === 'ETIMEDOUT' || e?.code === 'ETIMEDOUT';
      const kind = isTimeout ? FailureKind.TIMEOUT : FailureKind.NETWORK_ERROR;
      return {
        url: String(rawUrl),
        normalizedUrl: syntax.normalizedUrl,
        ok: false,
        statusCode: 0,
        finalUrl: currentUrl,
        failureKind: kind,
        failureCategory: FAILURE_ARABIC[kind],
        failureReason: isTimeout
          ? 'انتهت مهلة الاتصال بالخادم من جهة الخادم'
          : `خطأ شبكة من جهة الخادم: ${e?.message || 'تعذر الاتصال'}`,
      };
    }

    try {
      const code = resp.status;
      if ([301, 302, 303, 307, 308].includes(code)) {
        clearTimeout(timer);
        redirects++;
        if (redirects > DEFAULT_MAX_REDIRECTS) {
          return {
            url: String(rawUrl),
            normalizedUrl: syntax.normalizedUrl,
            ok: false,
            statusCode: code,
            finalUrl: currentUrl,
            failureKind: FailureKind.NETWORK_ERROR,
            failureCategory: FAILURE_ARABIC[FailureKind.NETWORK_ERROR],
            failureReason: `تم تجاوز الحد الأقصى لعمليات إعادة التوجيه (${DEFAULT_MAX_REDIRECTS})`,
          };
        }
        const rawLoc = resp.headers.get('location')?.trim();
        if (!rawLoc) {
          return {
            url: String(rawUrl),
            normalizedUrl: syntax.normalizedUrl,
            ok: false,
            statusCode: code,
            finalUrl: currentUrl,
            failureKind: FailureKind.NETWORK_ERROR,
            failureCategory: FAILURE_ARABIC[FailureKind.NETWORK_ERROR],
            failureReason: 'إعادة توجيه بدون عنوان وجهة',
          };
        }
        const resolved = new URL(encodeSpacesAndUnsafeChars(rawLoc), parsed);
        if (resolved.protocol !== 'http:' && resolved.protocol !== 'https:') {
          return {
            url: String(rawUrl),
            normalizedUrl: syntax.normalizedUrl,
            ok: false,
            statusCode: code,
            finalUrl: currentUrl,
            failureKind: FailureKind.BLOCKED_NETWORK,
            failureCategory: FAILURE_ARABIC[FailureKind.BLOCKED_NETWORK],
            failureReason: 'إعادة التوجيه تستخدم بروتوكولاً غير مدعوم',
          };
        }
        if (parsed.protocol === 'https:' && resolved.protocol === 'http:') {
          return {
            url: String(rawUrl),
            normalizedUrl: syntax.normalizedUrl,
            ok: false,
            statusCode: code,
            finalUrl: resolved.toString(),
            failureKind: FailureKind.BLOCKED_NETWORK,
            failureCategory: FAILURE_ARABIC[FailureKind.BLOCKED_NETWORK],
            failureReason: 'تم رفض التحويل من HTTPS إلى HTTP غير مشفر',
          };
        }
        currentUrl = resolved.toString();
        continue;
      }

      if (code === 403) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: 403,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_FORBIDDEN,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_FORBIDDEN],
          failureReason: 'الخادم البعيد أو CDN رفض الوصول من الخادم أيضاً (HTTP 403 Forbidden) — استخدم Salla Merchant API الرسمي أو الاستيراد المحلي بالباركود.',
        };
      }
      if (code === 401 || code === 407) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_UNAUTHORIZED,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_UNAUTHORIZED],
          failureReason: `الرابط يتطلب توثيقاً أو صلاحيات وصول (HTTP ${code})`,
        };
      }
      if (code === 404 || code === 410) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_NOT_FOUND,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_NOT_FOUND],
          failureReason: `الصورة غير موجودة على الخادم (HTTP ${code})`,
        };
      }
      if (code === 429) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: 429,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_RATE_LIMITED,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_RATE_LIMITED],
          failureReason: 'تجاوز حد الطلبات المسموح على الخادم البعيد (HTTP 429)',
        };
      }
      if (code >= 500 && code <= 599) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_SERVER_ERROR,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_SERVER_ERROR],
          failureReason: `خطأ مؤقت من الخادم البعيد (HTTP ${code})`,
        };
      }
      if (code < 200 || code >= 300) {
        clearTimeout(timer);
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.HTTP_ERROR,
          failureCategory: FAILURE_ARABIC[FailureKind.HTTP_ERROR],
          failureReason: `فشل استرجاع الصورة من الخادم (HTTP ${code})`,
        };
      }

      const buf = await readResponseWithCap(resp, maxBytes);
      clearTimeout(timer);

      if (buf.length === 0) {
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.CORRUPT_OR_NOT_IMAGE,
          failureCategory: FAILURE_ARABIC[FailureKind.CORRUPT_OR_NOT_IMAGE],
          failureReason: 'الرابط أعاد ملفاً فارغاً بدون بيانات صورة',
        };
      }

      const rawCt = resp.headers.get('content-type') || '';
      const mime = rawCt.split(';')[0].trim().toLowerCase();

      const nonImg = detectNonImagePayload(buf, mime, currentUrl);
      if (nonImg) {
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: nonImg.kind,
          failureCategory: FAILURE_ARABIC[nonImg.kind],
          failureReason: nonImg.reason,
        };
      }

      if (isRejectedContentType(mime)) {
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: FailureKind.UNSUPPORTED_FORMAT,
          failureCategory: FAILURE_ARABIC[FailureKind.UNSUPPORTED_FORMAT],
          failureReason: `نوع المحتوى غير مدعوم كصورة (${mime})`,
        };
      }

      const ext = detectRasterImageFormat(buf);
      if (!ext) {
        const unsupportedImgMime =
          mime.startsWith('image/') &&
          !['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif', 'image/bmp', 'image/x-ms-bmp', 'image/avif'].includes(mime);
        const kind = unsupportedImgMime ? FailureKind.UNSUPPORTED_FORMAT : FailureKind.CORRUPT_OR_NOT_IMAGE;
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: code,
          finalUrl: currentUrl,
          failureKind: kind,
          failureCategory: FAILURE_ARABIC[kind],
          failureReason: unsupportedImgMime
            ? `صيغة الصورة غير مدعومة (${mime})`
            : 'الملف تالف أو ليس صورة حقيقية قابلة للفتح (المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF)',
        };
      }

      const hash = crypto.createHash('sha256').update(buf).digest('hex');
      return {
        url: String(rawUrl),
        normalizedUrl: syntax.normalizedUrl,
        ok: true,
        statusCode: code,
        finalUrl: currentUrl,
        contentType: mime || `image/${ext === 'jpg' ? 'jpeg' : ext}`,
        detectedFormat: ext,
        contentHash: hash,
        fileSizeBytes: buf.length,
        base64Data: buf.toString('base64'),
      };
    } catch (e) {
      clearTimeout(timer);
      if (e?.code === 'PAYLOAD_TOO_LARGE') {
        return {
          url: String(rawUrl),
          normalizedUrl: syntax.normalizedUrl,
          ok: false,
          statusCode: resp?.status || 0,
          finalUrl: currentUrl,
          failureKind: FailureKind.FILE_TOO_LARGE,
          failureCategory: FAILURE_ARABIC[FailureKind.FILE_TOO_LARGE],
          failureReason: e.message,
        };
      }
      return {
        url: String(rawUrl),
        normalizedUrl: syntax.normalizedUrl,
        ok: false,
        statusCode: resp?.status || 0,
        finalUrl: currentUrl,
        failureKind: FailureKind.NETWORK_ERROR,
        failureCategory: FAILURE_ARABIC[FailureKind.NETWORK_ERROR],
        failureReason: e?.message || 'فشل قراءة بيانات الصورة',
      };
    }
  }
}

export class ServerSideSallaTokenStore {
  constructor(filePath = '') {
    this.filePath = filePath;
    this.memoryTokens = null;
  }

  async load() {
    if (this.memoryTokens) return this.memoryTokens;
    if (!this.filePath) return null;
    try {
      const txt = await fs.readFile(this.filePath, 'utf8');
      this.memoryTokens = JSON.parse(txt);
      return this.memoryTokens;
    } catch {
      return null;
    }
  }

  async save(tokens) {
    this.memoryTokens = tokens;
    if (!this.filePath) return;
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    await fs.writeFile(this.filePath, JSON.stringify(tokens, null, 2), { mode: 0o600 });
  }

  async clear() {
    this.memoryTokens = null;
    if (!this.filePath) return;
    try {
      await fs.unlink(this.filePath);
    } catch {
      // ignore if absent
    }
  }
}

function constantTimeTokenMatch(provided, expected) {
  const a = Buffer.from(String(provided || ''), 'utf8');
  const b = Buffer.from(String(expected || ''), 'utf8');
  if (a.length !== b.length || a.length === 0) return false;
  return crypto.timingSafeEqual(a, b);
}

async function readJsonBody(req, maxBytes = DEFAULT_MAX_JSON_BODY_BYTES) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += b.length;
    if (total > maxBytes) {
      const err = new Error('حجم الطلب يتجاوز الحد المسموح');
      err.status = 413;
      throw err;
    }
    chunks.push(b);
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    const err = new Error('صيغة JSON غير صالحة');
    err.status = 400;
    throw err;
  }
}

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

function sendHtml(res, statusCode, html) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(html);
}

function escapeHtml(str) {
  return String(str || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

export function extractSallaProductEntry(rawProd) {
  const mainImg = typeof rawProd?.main_image === 'string' ? rawProd.main_image.trim() : '';
  const thumbImg = typeof rawProd?.thumbnail === 'string' ? rawProd.thumbnail.trim() : '';
  const gallery = Array.isArray(rawProd?.images)
    ? [...rawProd.images]
        .sort((a, b) => Number(a?.main ? -1 : 0) - Number(b?.main ? -1 : 0) || Number(a?.sort ?? 999) - Number(b?.sort ?? 999))
        .map((img) => (typeof img?.url === 'string' ? img.url.trim() : ''))
        .filter(Boolean)
    : [];

  const urls = [];
  for (const u of [mainImg, ...gallery, thumbImg]) {
    if (u && !urls.includes(u)) urls.push(u);
  }

  return {
    sallaProductId: rawProd?.id ?? null,
    name: String(rawProd?.name || '').trim(),
    sku: String(rawProd?.sku || '').trim(),
    gtin: String(rawProd?.gtin || rawProd?.metadata?.gtin || '').trim(),
    barcode: String(rawProd?.barcode || rawProd?.gtin || '').trim(),
    mainImageUrl: urls[0] || '',
    imageUrls: urls,
  };
}

export function createBackendServer(options = {}) {
  const {
    backendAccessToken = process.env.BACKEND_ACCESS_TOKEN || '',
    sallaClientId = process.env.SALLA_CLIENT_ID || '',
    sallaClientSecret = process.env.SALLA_CLIENT_SECRET || '',
    sallaRedirectUri = process.env.SALLA_REDIRECT_URI || '',
    sallaOAuthBaseUrl = process.env.SALLA_OAUTH_BASE_URL || 'https://accounts.salla.sa',
    sallaApiBaseUrl = process.env.SALLA_API_BASE_URL || 'https://api.salla.dev/admin/v2',
    tokenStore = new ServerSideSallaTokenStore(process.env.SALLA_TOKEN_STORE_PATH || ''),
    fetchImpl = globalThis.fetch,
    lookupFn = dns.lookup,
    allowPrivateForTesting = false,
    maxBatchItems = DEFAULT_MAX_BATCH_ITEMS,
  } = options;

  // CSRF OAuth state store with 10-minute expiration
  const oauthStates = new Map();

  function isSallaConfigured() {
    return Boolean(sallaClientId && sallaClientSecret && sallaRedirectUri);
  }

  function pruneStates() {
    const now = Date.now();
    for (const [k, exp] of oauthStates.entries()) {
      if (exp < now) oauthStates.delete(k);
    }
  }

  function requireBackendAuth(req) {
    if (!backendAccessToken) return true; // Optional in local self-hosted dev if unset
    const auth = req.headers.authorization || '';
    if (!auth.startsWith('Bearer ')) return false;
    const token = auth.slice(7).trim();
    return constantTimeTokenMatch(token, backendAccessToken);
  }

  async function exchangeSallaToken(params) {
    const body = new URLSearchParams({
      client_id: sallaClientId,
      client_secret: sallaClientSecret,
      ...params,
    });
    const resp = await fetchImpl(`${sallaOAuthBaseUrl.replace(/\/$/, '')}/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: body.toString(),
    });
    const text = await resp.text();
    let json = {};
    try {
      json = JSON.parse(text);
    } catch {
      // keep empty
    }
    if (!resp.ok || !json.access_token) {
      const err = new Error(json?.error_description || json?.message || `فشل مصادقة Salla (HTTP ${resp.status})`);
      err.status = resp.status || 502;
      throw err;
    }
    const stored = {
      accessToken: json.access_token,
      refreshToken: json.refresh_token || '',
      tokenType: json.token_type || 'Bearer',
      scope: json.scope || '',
      expiresAt: Date.now() + Number(json.expires_in || 1209600) * 1000,
      updatedAt: Date.now(),
    };
    await tokenStore.save(stored);
    return stored;
  }

  async function ensureValidSallaAccessToken() {
    let tokens = await tokenStore.load();
    if (!tokens || !tokens.accessToken) {
      const err = new Error('حساب متجر سلة غير مربوط بعد. أكمل ربط OAuth عبر البوابة الرسمية أولاً.');
      err.status = 401;
      throw err;
    }
    if (tokens.expiresAt && Date.now() > tokens.expiresAt - 60_000 && tokens.refreshToken) {
      tokens = await exchangeSallaToken({
        grant_type: 'refresh_token',
        refresh_token: tokens.refreshToken,
        redirect_uri: sallaRedirectUri,
      });
    }
    return tokens;
  }

  async function fetchSallaProductsPage(page = 1, perPage = 50, retried = false) {
    const tokens = await ensureValidSallaAccessToken();
    const url = `${sallaApiBaseUrl.replace(/\/$/, '')}/products?page=${encodeURIComponent(page)}&per_page=${encodeURIComponent(perPage)}`;
    const resp = await fetchImpl(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${tokens.accessToken}`,
        Accept: 'application/json',
      },
    });
    if (resp.status === 401 && !retried && tokens.refreshToken && isSallaConfigured()) {
      await exchangeSallaToken({
        grant_type: 'refresh_token',
        refresh_token: tokens.refreshToken,
        redirect_uri: sallaRedirectUri,
      });
      return fetchSallaProductsPage(page, perPage, true);
    }
    if (!resp.ok) {
      const err = new Error(`فشل جلب منتجات سلة عبر API الرسمي (HTTP ${resp.status})`);
      err.status = resp.status;
      throw err;
    }
    return resp.json();
  }

  return http.createServer(async (req, res) => {
    try {
      const reqUrl = new URL(req.url || '/', 'http://localhost');
      const pathname = reqUrl.pathname;

      if (req.method === 'GET' && pathname === '/health') {
        return sendJson(res, 200, {
          ok: true,
          service: 'report-manager-image-backend',
          sallaConfigured: isSallaConfigured(),
        });
      }

      // Public OAuth callback endpoint from Salla browser redirect
      if (req.method === 'GET' && pathname === '/api/salla/auth/callback') {
        pruneStates();
        const code = reqUrl.searchParams.get('code') || '';
        const state = reqUrl.searchParams.get('state') || '';
        const oauthErr = reqUrl.searchParams.get('error');
        if (oauthErr) {
          return sendHtml(
            res,
            400,
            `<html dir="rtl" lang="ar"><body><h2>تم رفض الربط من سلة</h2><p>${escapeHtml(oauthErr)}</p></body></html>`,
          );
        }
        if (!state || !oauthStates.has(state)) {
          return sendHtml(
            res,
            400,
            `<html dir="rtl" lang="ar"><body><h2>انتهت صلاحية جلسة التحقق (state غير صالح)</h2></body></html>`,
          );
        }
        oauthStates.delete(state);
        if (!code || !isSallaConfigured()) {
          return sendHtml(
            res,
            400,
            `<html dir="rtl" lang="ar"><body><h2>بيانات تطبيق سلة أو رمز التفويض غير مكتملة على الخادم</h2></body></html>`,
          );
        }
        await exchangeSallaToken({
          grant_type: 'authorization_code',
          code,
          redirect_uri: sallaRedirectUri,
        });
        return sendHtml(
          res,
          200,
          `<html dir="rtl" lang="ar"><body><h2>تم ربط متجر سلة بنجاح</h2><p>تم حفظ رموز الوصول بأمان على الخادم. يمكنك العودة إلى تطبيق «مدير التقارير» ومتابعة استيراد الصور.</p></body></html>`,
        );
      }

      if (!requireBackendAuth(req)) {
        return sendJson(res, 401, { ok: false, error: 'رمز التفويض للخادم الخلفي غير صحيح أو مفقود' });
      }

      if (req.method === 'POST' && pathname === '/api/images/fetch-batch') {
        const body = await readJsonBody(req);
        const items = Array.isArray(body?.images) ? body.images : null;
        if (!items) {
          return sendJson(res, 400, { ok: false, error: 'الحقل images يجب أن يكون مصفوفة' });
        }
        if (items.length > maxBatchItems) {
          return sendJson(res, 400, {
            ok: false,
            error: `تجاوزت الدفعة الحد الأقصى (${maxBatchItems} صورة في الطلب الواحد)`,
          });
        }

        // Deduplicate concurrent fetches for identical URLs inside the batch
        const cache = new Map();
        const getOrFetch = (url) => {
          const key = String(url || '').trim();
          if (!cache.has(key)) {
            cache.set(
              key,
              fetchAndVerifyImageServerSide(key, {
                fetchImpl,
                lookupFn,
                allowPrivateForTesting,
              }),
            );
          }
          return cache.get(key);
        };

        const results = await Promise.all(
          items.map(async (item) => {
            const fetched = await getOrFetch(item?.url || '');
            return {
              id: item?.id ?? null,
              gtin: item?.gtin ?? '',
              barcode: item?.barcode ?? '',
              ...fetched,
            };
          }),
        );

        const succeededCount = results.filter((r) => r.ok).length;
        const failedCount = results.length - succeededCount;
        return sendJson(res, 200, {
          ok: true,
          total: results.length,
          succeededCount,
          failedCount,
          results,
        });
      }

      if (req.method === 'GET' && pathname === '/api/salla/config-status') {
        const tokens = await tokenStore.load();
        return sendJson(res, 200, {
          ok: true,
          configured: isSallaConfigured(),
          connected: Boolean(tokens?.accessToken),
          scopes: ['offline_access', 'products.read'],
          redirectUriConfigured: Boolean(sallaRedirectUri),
          expiresAt: tokens?.expiresAt || 0,
        });
      }

      if (req.method === 'GET' && pathname === '/api/salla/auth/url') {
        if (!isSallaConfigured()) {
          return sendJson(res, 412, {
            ok: false,
            error: 'بيانات تطبيق سلة (SALLA_CLIENT_ID / SALLA_CLIENT_SECRET / SALLA_REDIRECT_URI) غير مهيأة على الخادم بعد.',
          });
        }
        pruneStates();
        const state = crypto.randomBytes(24).toString('hex');
        oauthStates.set(state, Date.now() + 10 * 60 * 1000);
        const authUrl = new URL(`${sallaOAuthBaseUrl.replace(/\/$/, '')}/oauth2/auth`);
        authUrl.searchParams.set('client_id', sallaClientId);
        authUrl.searchParams.set('redirect_uri', sallaRedirectUri);
        authUrl.searchParams.set('response_type', 'code');
        authUrl.searchParams.set('scope', 'offline_access products.read');
        authUrl.searchParams.set('state', state);
        return sendJson(res, 200, { ok: true, authorizeUrl: authUrl.toString() });
      }

      if (req.method === 'POST' && pathname === '/api/salla/auth/refresh') {
        const tokens = await tokenStore.load();
        if (!isSallaConfigured() || !tokens?.refreshToken) {
          return sendJson(res, 400, { ok: false, error: 'لا يوجد refresh_token أو إعدادات سلة غير مكتملة' });
        }
        const refreshed = await exchangeSallaToken({
          grant_type: 'refresh_token',
          refresh_token: tokens.refreshToken,
          redirect_uri: sallaRedirectUri,
        });
        return sendJson(res, 200, { ok: true, connected: true, expiresAt: refreshed.expiresAt });
      }

      if (req.method === 'POST' && pathname === '/api/salla/disconnect') {
        await tokenStore.clear();
        return sendJson(res, 200, { ok: true, connected: false });
      }

      if (req.method === 'GET' && pathname === '/api/salla/products') {
        const page = Math.max(1, Number(reqUrl.searchParams.get('page') || 1));
        const perPage = Math.min(100, Math.max(1, Number(reqUrl.searchParams.get('perPage') || 50)));
        const downloadImages = reqUrl.searchParams.get('downloadImages') === 'true';

        const payload = await fetchSallaProductsPage(page, perPage);
        const rawList = Array.isArray(payload?.data) ? payload.data : [];
        const products = await Promise.all(
          rawList.map(async (rawProd) => {
            const normalized = extractSallaProductEntry(rawProd);
            if (!downloadImages || normalized.imageUrls.length === 0) {
              return normalized;
            }
            const downloadedImages = await Promise.all(
              normalized.imageUrls.map((u) =>
                fetchAndVerifyImageServerSide(u, {
                  fetchImpl,
                  lookupFn,
                  allowPrivateForTesting,
                }),
              ),
            );
            return { ...normalized, downloadedImages };
          }),
        );

        return sendJson(res, 200, {
          ok: true,
          page,
          pagination: payload?.pagination || null,
          products,
        });
      }

      return sendJson(res, 404, { ok: false, error: 'المسار غير موجود' });
    } catch (err) {
      const status = Number(err?.status) || 500;
      return sendJson(res, status, { ok: false, error: err?.message || 'خطأ داخلي في الخادم' });
    }
  });
}
