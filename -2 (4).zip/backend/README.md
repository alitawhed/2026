# خدمة الخلفية المرافقة لتطبيق «مدير التقارير» (Backend Image & Salla OAuth Service)

توفر هذه الخدمة (Node.js 22 بدون أي حزم خارجية) مسارين أساسيين لحل رفض الخادم (`HTTP 403`) على صور روابط سلة (`cdn.salla.sa` / `cdn.files.salla.network`) بطريقة رسمية وآمنة:

1. **تنزيل الصور من جهة الخادم (`POST /api/images/fetch-batch`)**
   - تستقبل طلبات الروابط من تطبيق Android وتنفّذ طلبات HTTPS من الخادم بدلاً من جهاز العميل.
   - تتحقق من رمز HTTP و`Content-Type` والحد الأقصى للحجم (20 ميجابايت) وبصمة البايتات الحقيقية (`JPG / PNG / WEBP / GIF / BMP / AVIF`) وترفض الروابط الداخلية/الخاصة وصفحات HTML.
   - إذا ظل الخادم البعيد يرفض الوصول بـ `HTTP 403` فتُرجع تشخيصاً صريحاً دون محاولات متكررة أو تجاوز لحماية CDN.

2. **الربط الرسمي مع Salla Merchant API (`OAuth 2.0`)**
   - تخزّن `SALLA_CLIENT_ID` و`SALLA_CLIENT_SECRET` و`access_token` و`refresh_token` على الخادم فقط (لا تُحفظ أي أسرار داخل تطبيق Android).
   - المسارات:
     - `GET /api/salla/config-status`
     - `GET /api/salla/auth/url`
     - `GET /api/salla/auth/callback`
     - `POST /api/salla/auth/refresh`
     - `GET /api/salla/products?page=1&perPage=50&downloadImages=true`
     - `POST /api/salla/disconnect`

## خطوات التفعيل على Salla Partners
1. أنشئ تطبيقاً في لوحة مطوري سلة (`salla.partners`).
2. فعّل الصلاحيات (`Scopes`): `offline_access` و `products.read`.
3. اضبط `Redirect URI` ليطابق: `https://<your-domain>/api/salla/auth/callback`.
4. انشر هذا الخادم عبر HTTPS، واضبط متغيرات البيئة في `.env` (بناءً على `.env.example`) ثم شغّله:
   ```bash
   node server.mjs
   ```
5. من شاشة الاستيراد في تطبيق «مدير التقارير»، أدخل رابط HTTPS للخادم ورمز الوصول `BACKEND_ACCESS_TOKEN`.
