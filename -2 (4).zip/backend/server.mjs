import { createBackendServer } from './app.mjs';

const port = Number(process.env.PORT || 8787);
const host = process.env.HOST || '0.0.0.0';

const server = createBackendServer();
server.listen(port, host, () => {
  console.log(`Report Manager Image Backend listening on http://${host}:${port}`);
});
