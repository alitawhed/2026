# دليل إعداد النشر على Google Play Store وملخص سياسة الخصوصية
# تطبيق: مدير التقارير (Report Manager) — `com.aistudio.reportmanager.kmtwqz`

> **ملاحظة مهمة:** العناصر المشار إليها بـ **`MANUAL SETUP`** تتطلب إجراءً خارجياً من حسابك في **Firebase Console** أو **Google Play Console** أو استضافة الويب، ولا توجد أي روابط أو معرفات وهمية داخل التطبيق.

---

## 1. إعداد Firebase Authentication (`MANUAL SETUP`)
1. تنزيل ملف `google-services.json` الخاص بمشروع Firebase المعتمد ووضعه في:
   `app/google-services.json`
2. إضافة بصمات الشهادة **SHA-1** و**SHA-256** (لمفتاح Debug ومفتاح Release / Play App Signing) داخل إعدادات تطبيق Android في Firebase Console.
3. تفعيل طرق المصادقة التالية من **Firebase Console -> Authentication -> Sign-in method**:
   - **Google** (مع التأكد من وجود `default_web_client_id` داخل `google-services.json` الناتج).
   - **Email/Password** (تفعيل يدوي من لوحة التحكم).
4. لا توجد أي تهيئة لـ Firestore أو Realtime Database أو Cloud Functions؛ فالتطبيق يستخدم **Firebase Authentication فقط**.

---

## 2. إعداد الاشتراكات في Google Play Console (`MANUAL SETUP`)
1. من **Google Play Console -> Monetize -> Products -> Subscriptions**:
   - إنشاء منتج الاشتراك الاحترافي (أو منتجين منفصلين شهري وسنوي).
   - إضافة الخطط الأساسية (**Base Plans**):
     - خطة شهرية (`P1M`) — تجديد تلقائي.
     - خطة سنوية (`P1Y`) — تجديد تلقائي.
   - إضافة عرض التجربة المجانية (**Free Trial Offer**): 7 أيام (`P7D`) مؤهل للمشتركين الجدد.
2. إدخال معرفات المنتجات والخطط في التطبيق من خلال شاشة:
   **الإعدادات العامة -> حالة الأنظمة والاشتراكات والإدارة -> معرفات Play -> حفظ**.
3. إضافة حسابات اختبار الترخيص (**License Testers**) في Play Console للتحقق من:
   - الشراء، الإلغاء مع بقاء الصلاحية حتى انتهاء الدورة، مهلة السداد (Grace Period)، الدفع المعلق (`PENDING`)، واستعادة المشتريات على جهاز آخر.

---

## 3. متطلبات النشر والامتثال على Google Play (`MANUAL SETUP`)

### أ. رابط سياسة الخصوصية العام (Privacy Policy URL)
- استضافة صفحة ويب عامة تتضمن نفس بنود الخصوصية المعروضة داخل شاشة `الخصوصية وحذف الحساب` في التطبيق، وإدخال رابطها في:
  `Google Play Console -> Policy -> App content -> Privacy policy`.

### ب. رابط طلب حذف الحساب عبر الويب (Web Account Deletion URL)
- وفق سياسة Google Play لحسابات التطبيقات، يجب توفير رابط ويب عام يوضح للمستخدم خطوات حذف الحساب من داخل التطبيق (`الإعدادات -> الحساب -> إدارة الحساب -> حذف الحساب نهائياً`) أو عبر مراسلة بريد الدعم (`s2x518u@gmail.com`) وإدخال الرابط في `Data safety -> Account deletion URL`.
- **توضيح فصل البيانات في السياسة:**
  - حذف الحساب يزيل حساب الدخول من Firebase Authentication فقط.
  - البيانات المحلية (`Room SQLite` والصور وملفات النسخ الاحتياطي `ZIP`) تبقى محفوظة على الجهاز ولا تُحذف تلقائياً.
  - حذف الحساب لا يُلغي اشتراك Google Play تلقائياً؛ يجب الإلغاء من مركز اشتراكات Google Play.

### ج. نموذج أمان البيانات (Data Safety Declaration)
- **بيانات يتم جمعها للمصادقة فقط (Firebase Auth):** الاسم، البريد الإلكتروني، معرّف المستخدم (`UID`).
- **تاريخ المشتريات (Purchase history):** عبر Google Play Billing فقط للتحقق من صلاحية الاشتراك على الجهاز.
- **تشفير البيانات أثناء النقل (Encrypted in transit):** نعم (HTTPS / TLS via Firebase Auth & Google Play).
- **إمكانية حذف الحساب:** نعم (عبر التطبيق مع إعادة مصادقة).
- **المنتجات والتقارير والصور والجرد:** محفوظة محلياً على جهاز المستخدم ولا يتم رفعها أو مشاركتها مع خوادم خارجية.

### د. App Access (وصول المراجعين)
- توفير حساب تجريبي مفعّل البريد الإلكتروني وكلمة مرور لفريق مراجعة Google Play لاختبار شاشة الحسابات، مع ملاحظة إمكانية استخدام التطبيق محلياً بالكامل بدون تسجيل دخول أيضاً.

---

## 4. التحقق من توقيع الإطلاق (Release Signing & Bundle)
يقرأ `app/build.gradle.kts` متغيرات البيئة التالية عند بناء حزمة الإنتاج الموقّعة (`bundleRelease` / `assembleRelease`) دون تخزين أي مفاتيح أو كلمات مرور في الكود:
- `KEYSTORE_PATH` (أو `${rootDir}/my-upload-key.jks`)
- `STORE_PASSWORD`
- `KEY_PASSWORD`
- `keyAlias = "upload"`
