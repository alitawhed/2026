package com.example.di

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TemplateRepository
import com.example.data.storage.BackendImageSyncService
import com.example.data.storage.ImageService
import com.example.data.storage.MediaStorageManager
import com.example.data.storage.RemoteImageDownloader
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.FirebaseAuthGateway
import com.example.domain.auth.GoogleSignInHelper
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.billing.BillingConfigStore
import com.example.domain.billing.BillingGateway
import com.example.domain.billing.PlayBillingManager
import com.example.domain.billing.SubscriptionEntitlementManager
import com.example.domain.diagnostics.DiagnosticExportEngine
import com.example.domain.diagnostics.DiagnosticsFileStore
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.OperationLogger
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.pdf.LabelPdfGenerator
import com.example.domain.pdf.PdfEditorEngine
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.workspace.AccountWorkspaceManager
import com.example.domain.workspace.WorkspaceIdentity
import java.io.File

/**
 * Process-wide singletons shared safely across workspace switches (authentication, billing, diagnostics, executor).
 */
class SharedAppServices(
    context: Context,
    authGatewayOverride: AuthGateway? = null,
    billingGatewayOverride: BillingGateway? = null,
) {
    val appContext: Context = context.applicationContext

    val diagnosticsFileStore: DiagnosticsFileStore by lazy { DiagnosticsFileStore(appContext.filesDir) }
    val operationLogger: OperationLogger by lazy { OperationLogger(diagnosticsFileStore) }
    val globalErrorMonitor: GlobalErrorMonitor by lazy {
        GlobalErrorMonitor(appContext, diagnosticsFileStore, operationLogger)
    }
    val cameraAnalysisExecutorManager: com.example.domain.barcode.CameraAnalysisExecutorManager by lazy {
        com.example.domain.barcode.CameraAnalysisExecutorManager(globalErrorMonitor)
    }
    val authGateway: AuthGateway by lazy {
        authGatewayOverride ?: FirebaseAuthGateway(appContext, globalErrorMonitor)
    }
    val googleSignInHelper: GoogleSignInHelper by lazy {
        GoogleSignInHelper(globalErrorMonitor)
    }
    val billingConfigStore: BillingConfigStore by lazy {
        BillingConfigStore(appContext)
    }
    val billingGateway: BillingGateway by lazy {
        billingGatewayOverride ?: PlayBillingManager(
            context = appContext,
            configStore = billingConfigStore,
            errorMonitor = globalErrorMonitor,
            activeUidProvider = { authGateway.currentUser()?.uid },
        )
    }
    val entitlementManager: SubscriptionEntitlementManager by lazy {
        SubscriptionEntitlementManager(billingGateway, authGateway)
    }
    val workspaceManager: AccountWorkspaceManager by lazy {
        AccountWorkspaceManager(appContext, authGateway, this)
    }
}

class AppContainer(
    context: Context,
    val workspaceIdentity: WorkspaceIdentity = WorkspaceIdentity.Local,
    val sharedServices: SharedAppServices = SharedAppServices(context.applicationContext),
) {
    val appContext: Context = context.applicationContext

    val diagnosticsFileStore: DiagnosticsFileStore
        get() = sharedServices.diagnosticsFileStore
    val operationLogger: OperationLogger
        get() = sharedServices.operationLogger
    val globalErrorMonitor: GlobalErrorMonitor
        get() = sharedServices.globalErrorMonitor
    val cameraAnalysisExecutorManager: com.example.domain.barcode.CameraAnalysisExecutorManager
        get() = sharedServices.cameraAnalysisExecutorManager
    val authGateway: AuthGateway
        get() = sharedServices.authGateway
    val googleSignInHelper: GoogleSignInHelper
        get() = sharedServices.googleSignInHelper
    val billingConfigStore: BillingConfigStore
        get() = sharedServices.billingConfigStore
    val billingGateway: BillingGateway
        get() = sharedServices.billingGateway
    val entitlementManager: SubscriptionEntitlementManager
        get() = sharedServices.entitlementManager
    val workspaceManager: AccountWorkspaceManager
        get() = sharedServices.workspaceManager

    val diagnosticExportEngine: DiagnosticExportEngine by lazy {
        DiagnosticExportEngine(appContext, globalErrorMonitor, databaseSchemaVersion = 11)
    }

    val workspaceStorageRoot: File by lazy {
        when (workspaceIdentity) {
            is WorkspaceIdentity.Local -> appContext.filesDir
            is WorkspaceIdentity.Account -> File(appContext.filesDir, "workspaces/${workspaceIdentity.safeKey}").apply {
                mkdirs()
            }
        }
    }

    val database: AppDatabase by lazy {
        AppDatabase.getInstanceForDatabaseName(appContext, workspaceIdentity.databaseName).also { db ->
            globalErrorMonitor.attachDaoProvider { db.diagnosticsDao() }
        }
    }
    val mediaStorage: MediaStorageManager by lazy {
        MediaStorageManager(appContext, globalErrorMonitor, baseStorageDir = workspaceStorageRoot)
    }
    val remoteImageDownloader: RemoteImageDownloader by lazy { RemoteImageDownloader(mediaStorage) }
    val backendImageSyncService: BackendImageSyncService by lazy { BackendImageSyncService() }
    val imageService: ImageService by lazy { ImageService(appContext, database, mediaStorage, globalErrorMonitor) }

    val barcodeService: com.example.domain.barcode.BarcodeService by lazy {
        com.example.domain.barcode.BarcodeService(database, mediaStorage, globalErrorMonitor)
    }

    val productRepository: ProductRepository by lazy {
        ProductRepository(database, mediaStorage, globalErrorMonitor, barcodeService)
    }
    val inventoryRepository: InventoryRepository by lazy {
        InventoryRepository(database, globalErrorMonitor, barcodeService)
    }
    val reportRepository: ReportRepository by lazy {
        ReportRepository(database, mediaStorage, globalErrorMonitor, barcodeService)
    }
    val templateRepository: TemplateRepository by lazy { TemplateRepository(database, globalErrorMonitor) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(database, globalErrorMonitor) }

    val excelImportEngine: ExcelImportEngine by lazy {
        ExcelImportEngine(appContext, database, mediaStorage, remoteImageDownloader, backendImageSyncService, globalErrorMonitor, barcodeService)
    }
    val excelExportEngine: ExcelExportEngine by lazy {
        ExcelExportEngine(mediaStorage, globalErrorMonitor)
    }
    val pdfGeneratorEngine: PdfGeneratorEngine by lazy {
        PdfGeneratorEngine(appContext, mediaStorage, errorMonitor = globalErrorMonitor)
    }
    val labelPdfGenerator: LabelPdfGenerator by lazy {
        LabelPdfGenerator(appContext, mediaStorage, errorMonitor = globalErrorMonitor)
    }
    val pdfEditorEngine: PdfEditorEngine by lazy {
        PdfEditorEngine(appContext, database, mediaStorage, errorMonitor = globalErrorMonitor)
    }
    val backupRestoreEngine: BackupRestoreEngine by lazy {
        BackupRestoreEngine(appContext, database, mediaStorage, globalErrorMonitor)
    }
}
