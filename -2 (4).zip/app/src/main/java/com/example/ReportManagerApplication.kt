package com.example

import android.app.Activity
import android.app.Application
import android.os.Bundle
import coil.Coil
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.data.local.AppDatabase
import com.example.di.AppContainer
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.MemoryPressureAdvisor
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

class ReportManagerApplication : Application(), ImageLoaderFactory {
    val sharedServices: com.example.di.SharedAppServices by lazy {
        com.example.di.SharedAppServices(applicationContext)
    }
    val container: AppContainer
        get() = sharedServices.workspaceManager.currentContainer()
    private val startupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val monitor = sharedServices.globalErrorMonitor
        monitor.installGlobalHandlers(this)

        startupScope.launch {
            runCatching {
                AppDatabase.ensureSeeded(container.database)
                container.backupRestoreEngine.verifyPendingRestoreAfterAppRestart()
            }.onFailure { err ->
                monitor.recordError(
                    throwable = err,
                    screenName = ScreenNames.DASHBOARD,
                    moduleName = DiagnosticModules.SQLITE,
                    operationName = "تهيئة قاعدة البيانات والتحقق بعد التشغيل",
                )
            }
        }

        registerActivityLifecycleCallbacks(
            object : ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                    monitor.updateCurrentScreen(ScreenNames.DASHBOARD)
                }

                override fun onActivityStarted(activity: Activity) = Unit
                override fun onActivityResumed(activity: Activity) = Unit
                override fun onActivityPaused(activity: Activity) = Unit
                override fun onActivityStopped(activity: Activity) = Unit
                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
                override fun onActivityDestroyed(activity: Activity) = Unit
            },
        )
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.15)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "image_manager_disk_cache"))
                    .maxSizeBytes(32L * 1024L * 1024L)
                    .build()
            }
            .allowRgb565(true)
            .respectCacheHeaders(false)
            .build()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        handleTrimMemoryLevel(level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        handleTrimMemoryLevel(TRIM_MEMORY_COMPLETE)
    }

    fun handleTrimMemoryLevel(level: Int) {
        runCatching {
            val eval = MemoryPressureAdvisor.evaluate(applicationContext, level)
            if (eval.shouldTrimCaches) {
                val loader = Coil.imageLoader(applicationContext)
                if (level >= TRIM_MEMORY_RUNNING_CRITICAL || level >= TRIM_MEMORY_MODERATE) {
                    loader.memoryCache?.clear()
                } else {
                    loader.memoryCache?.trimMemory(level)
                }
                MemoryPressureAdvisor.releaseDisposableTempCaches(
                    context = applicationContext,
                    aggressive = eval.shouldLogWarning || level >= TRIM_MEMORY_BACKGROUND,
                )
            }

            if (eval.shouldLogWarning) {
                container.globalErrorMonitor.recordCustomError(
                    screenName = container.globalErrorMonitor.currentScreenName,
                    moduleName = DiagnosticModules.SYSTEM,
                    operationName = "إدارة ذاكرة التشغيل (RAM)",
                    errorType = "LowMemoryWarning",
                    message = eval.toDiagnosticMessage(),
                    wasHandled = true,
                    severity = eval.severity,
                    extraMeta = mapOf(
                        "trimLevel" to level.toString(),
                        "availRamMb" to eval.availRamMb.toString(),
                        "totalRamMb" to eval.totalRamMb.toString(),
                        "heapUsedMb" to eval.heapUsedMb.toString(),
                        "heapMaxMb" to eval.heapMaxMb.toString(),
                        "cachesTrimmed" to eval.shouldTrimCaches.toString(),
                    ),
                )
            }
        }
    }
}
