package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.billing.PlayBillingConfiguration
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.domain.model.ThemeMode
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.ProductsNumericSettingsDialog
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.SettingsViewModel
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: (() -> Unit)? = null,
    onOpenBackup: () -> Unit,
    onOpenAbout: () -> Unit = {},
    onOpenDiagnostics: () -> Unit = {},
    onOpenAccount: () -> Unit = {},
    onOpenSubscription: () -> Unit = {},
    onOpenPrivacy: () -> Unit = {},
) {
    val persisted by viewModel.settings.collectAsStateWithLifecycle()
    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()
    val productsNumCfg by viewModel.productsNumericConfig.collectAsStateWithLifecycle()
    val diagStats by viewModel.diagnosticStats.collectAsStateWithLifecycle()
    val auditReport by viewModel.barcodeAuditReport.collectAsStateWithLifecycle()
    val repairResult by viewModel.barcodeRepairResult.collectAsStateWithLifecycle()
    val isAuditingBarcodes by viewModel.isAuditingOrRepairingBarcodes.collectAsStateWithLifecycle()
    val repairProgress by viewModel.barcodeRepairProgress.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val billingConnState by viewModel.billingConnectionState.collectAsStateWithLifecycle()
    val billingCfg by viewModel.billingConfig.collectAsStateWithLifecycle()
    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var showProductsDecimalDialog by remember { mutableStateOf(false) }
    var showBarcodeRepairDialog by remember { mutableStateOf(false) }
    var approveIncompatibleConversion by remember { mutableStateOf(false) }
    var showBillingConfigEditor by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var draft by remember(persisted) { mutableStateOf(persisted) }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { viewModel.updateCompanyLogo(it) }
    }

    val accentColors = listOf("#0D9488", "#0F172A", "#0284C7", "#D97706", "#15803D", "#7C3AED")

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "الإعدادات العامة",
                subtitle = "بيانات الشركة والتقارير والكاميرا والباركود",
                onBack = onBack,
                actions = {
                    Button(
                        onClick = { viewModel.updateSettings(draft) },
                        modifier = Modifier.padding(end = 8.dp).testTag("settings_save_btn"),
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("حفظ")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("settings_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Account & Authentication Entry Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حساب المستخدم والمصادقة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "تسجيل الدخول عبر Google أو البريد الإلكتروني، إدارة التحقق من البريد وكلمة المرور وحذف الحساب.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(
                            onClick = onOpenAccount,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("settings_open_account_btn"),
                        ) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("فتح الحساب وتسجيل الدخول")
                        }
                    }
                }
            }

            // Administrative Status & Subscriptions Panel (Honest live state — zero hardcoded stats/passwords)
            item {
                val authCfg = remember(currentUser) { viewModel.authConfigStatus }
                var draftSubProdId by remember(billingCfg) { mutableStateOf(billingCfg.subscriptionProductId) }
                var draftMonthlyProdId by remember(billingCfg) { mutableStateOf(billingCfg.monthlyProductId) }
                var draftYearlyProdId by remember(billingCfg) { mutableStateOf(billingCfg.yearlyProductId) }
                var draftMonthlyBpId by remember(billingCfg) { mutableStateOf(billingCfg.monthlyBasePlanId) }
                var draftYearlyBpId by remember(billingCfg) { mutableStateOf(billingCfg.yearlyBasePlanId) }
                var draftTrialOfferId by remember(billingCfg) { mutableStateOf(billingCfg.trialOfferId) }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_admin_status_card"),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "حالة الأنظمة والاشتراكات والإدارة",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "• Firebase Auth: ${if (authCfg.isFirebaseInitialized && authCfg.isGoogleServicesConfigured) "مهيأ ويعمل" else "بانتظار google-services.json (Manual Setup)"}\n" +
                                "• المستخدم النشط: ${currentUser?.email ?: "وضع محلي (بدون تسجيل دخول)"}\n" +
                                "• مساحة العمل: ${viewModel.workspaceLabel}\n" +
                                "• Google Play Billing: ${billingConnState.arabicLabel}\n" +
                                "• معرفات منتجات الاشتراك: ${if (billingCfg.isConfigured) billingCfg.allConfiguredProductIds().joinToString("، ") else "غير مضبوطة بعد (Manual Setup)"}\n" +
                                "• حالة الباقة الحالية: ${entitlementState.planType.arabicTitle} — ${entitlementState.status.arabicLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Button(
                                onClick = onOpenSubscription,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_open_subscription_btn"),
                            ) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("الباقات والاشتراك")
                            }
                            OutlinedButton(
                                onClick = viewModel::refreshBillingStatus,
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_refresh_billing_btn"),
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "تحديث الفوترة", modifier = Modifier.size(18.dp))
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = onOpenPrivacy,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_open_privacy_btn"),
                            ) {
                                Icon(Icons.Default.PrivacyTip, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("الخصوصية والحذف")
                            }
                            OutlinedButton(
                                onClick = { showBillingConfigEditor = !showBillingConfigEditor },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_toggle_billing_config_btn"),
                            ) {
                                Icon(Icons.Default.ManageAccounts, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("معرفات Play")
                            }
                        }

                        if (showBillingConfigEditor) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    text = "إعداد معرفات منتجات الاشتراك من Google Play Console (للاختبار والتشغيل الفعلي):",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                OutlinedTextField(
                                    value = draftSubProdId,
                                    onValueChange = { draftSubProdId = it },
                                    label = { Text("معرف منتج الاشتراك الموحد (Subscription Product ID)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("settings_billing_sub_product_id"),
                                )
                                OutlinedTextField(
                                    value = draftMonthlyBpId,
                                    onValueChange = { draftMonthlyBpId = it },
                                    label = { Text("معرف الخطة الأساسية الشهرية (Monthly Base Plan ID)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("settings_billing_monthly_bp_id"),
                                )
                                OutlinedTextField(
                                    value = draftYearlyBpId,
                                    onValueChange = { draftYearlyBpId = it },
                                    label = { Text("معرف الخطة الأساسية السنوية (Yearly Base Plan ID)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("settings_billing_yearly_bp_id"),
                                )
                                OutlinedTextField(
                                    value = draftMonthlyProdId,
                                    onValueChange = { draftMonthlyProdId = it },
                                    label = { Text("معرف المنتج الشهري المنفصل (اختياري)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                OutlinedTextField(
                                    value = draftYearlyProdId,
                                    onValueChange = { draftYearlyProdId = it },
                                    label = { Text("معرف المنتج السنوي المنفصل (اختياري)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                OutlinedTextField(
                                    value = draftTrialOfferId,
                                    onValueChange = { draftTrialOfferId = it },
                                    label = { Text("معرف عرض التجربة المجانية 7 أيام (اختياري)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Button(
                                    onClick = {
                                        viewModel.savePlayBillingConfiguration(
                                            PlayBillingConfiguration(
                                                subscriptionProductId = draftSubProdId,
                                                monthlyProductId = draftMonthlyProdId,
                                                yearlyProductId = draftYearlyProdId,
                                                monthlyBasePlanId = draftMonthlyBpId,
                                                yearlyBasePlanId = draftYearlyBpId,
                                                trialOfferId = draftTrialOfferId,
                                            ),
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("settings_save_billing_config_btn"),
                                ) {
                                    Text("حفظ معرفات Google Play Console")
                                }
                            }
                        }
                    }
                }
            }

            // App Display Title (Company & Report info live separately below; Developer identity is immutable)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("عنوان العرض العام", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = draft.appName,
                            onValueChange = { draft = draft.copy(appName = it) },
                            label = { Text("اسم التطبيق") },
                            modifier = Modifier.fillMaxWidth().testTag("settings_app_name"),
                            singleLine = true,
                        )
                    }
                }
            }

            // Company Branding & Header Defaults
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("بيانات الشركة والترويسة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (persisted.companyLogoPath.isNotBlank() && File(persisted.companyLogoPath).exists()) {
                                AsyncImage(
                                    model = File(persisted.companyLogoPath),
                                    contentDescription = "شعار الشركة",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)),
                                )
                            }
                            OutlinedButton(onClick = {
                                logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("اختيار شعار الشركة")
                            }
                        }
                        OutlinedTextField(
                            value = draft.companyName,
                            onValueChange = { draft = draft.copy(companyName = it) },
                            label = { Text("اسم الشركة / المؤسسة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = draft.companyAddress,
                            onValueChange = { draft = draft.copy(companyAddress = it) },
                            label = { Text("عنوان الشركة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = draft.companyPhone,
                            onValueChange = { draft = draft.copy(companyPhone = it) },
                            label = { Text("هاتف الشركة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = draft.headerDefaultText,
                            onValueChange = { draft = draft.copy(headerDefaultText = it) },
                            label = { Text("نص الترويسة الافتراضي") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                    }
                }
            }

            // Appearance: Theme, Font & Accent Color
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("المظهر والخطوط والألوان", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = draft.themeMode == mode.name,
                                    onClick = {
                                        draft = draft.copy(themeMode = mode.name)
                                        viewModel.updateSettings(draft)
                                    },
                                    label = { Text(mode.arabicLabel) },
                                )
                            }
                        }
                        Text("الخط العربي للتطبيق و PDF:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = draft.fontFamilyKey == "CAIRO",
                                onClick = {
                                    draft = draft.copy(fontFamilyKey = "CAIRO")
                                    viewModel.updateSettings(draft)
                                },
                                label = { Text("خط Cairo") },
                            )
                            FilterChip(
                                selected = draft.fontFamilyKey == "IBM_PLEX",
                                onClick = {
                                    draft = draft.copy(fontFamilyKey = "IBM_PLEX")
                                    viewModel.updateSettings(draft)
                                },
                                label = { Text("IBM Plex Arabic") },
                            )
                        }
                        Text("اللون الرئيسي:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            accentColors.forEach { hex ->
                                val c = parseHexColor(hex)
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .clickable {
                                            draft = draft.copy(accentColorHex = hex)
                                            viewModel.updateSettings(draft)
                                        },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (draft.accentColorHex.equals(hex, true)) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Defaults: Paper, Currency, Barcode, Export
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("إعدادات الورق والعملة والباركود", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = draft.defaultCurrency,
                                onValueChange = { draft = draft.copy(defaultCurrency = it) },
                                label = { Text("العملة الافتراضية") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                            OutlinedTextField(
                                value = draft.exportFilePrefix,
                                onValueChange = { draft = draft.copy(exportFilePrefix = it) },
                                label = { Text("بادئة ملفات التصدير") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                        }
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PaperSizeType.entries.forEach { ps ->
                                FilterChip(selected = draft.defaultPaperSize == ps.name, onClick = { draft = draft.copy(defaultPaperSize = ps.name) }, label = { Text(ps.name) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PageOrientation.entries.forEach { ori ->
                                FilterChip(selected = draft.defaultOrientation == ori.name, onClick = { draft = draft.copy(defaultOrientation = ori.name) }, label = { Text(ori.arabicLabel) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = draft.defaultMarginMm.toInt().toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { draft = draft.copy(defaultMarginMm = it) } },
                                label = { Text("الهامش (مم)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = draft.barcodeDpi.toString(),
                                onValueChange = { v -> v.toIntOrNull()?.let { draft = draft.copy(barcodeDpi = it) } },
                                label = { Text("دقة الباركود DPI") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Text(
                            text = "نوع الباركود الافتراضي للباركودات الداخلية الجديدة:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "المختار حالياً: ${defaultBarcodeType.arabicLabel} • المقترح للباركودات الداخلية Code 128 ويُحفظ الاختيار فوراً في جميع الشاشات",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            BarcodeEngine.PRIMARY_SUPPORTED_FORMATS.forEach { fmt ->
                                FilterChip(
                                    selected = defaultBarcodeType == fmt || draft.defaultBarcodeType == fmt.name,
                                    onClick = {
                                        draft = draft.copy(defaultBarcodeType = fmt.name)
                                        viewModel.updateDefaultBarcodeType(fmt)
                                    },
                                    leadingIcon = if (defaultBarcodeType == fmt) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null,
                                    label = { Text(fmt.arabicLabel) },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("settings_default_barcode_${fmt.name.lowercase()}"),
                                )
                            }
                        }
                    }
                }
            }

            // Legacy Barcode Audit & OOM-Safe Repair Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "فحص وإصلاح باركودات المنتجات القديمة",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Text(
                            text = "يفحص جميع الباركودات في القاعدة ويعيد توليد الصور المفقودة ومزامنة كشوف الجرد بدون حذف أي منتج أو تعديل أرقام الباركود الأصلية.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (isAuditingBarcodes) {
                            val prog = repairProgress
                            if (prog != null && prog.second > 0) {
                                LinearProgressIndicator(
                                    progress = { (prog.first.toFloat() / prog.second.toFloat()).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Text(
                                    text = "جارٍ المعالجة بأمان (${prog.first} / ${prog.second})...",
                                    style = MaterialTheme.typography.labelSmall,
                                )
                            } else {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                        }
                        auditReport?.let { rep ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text("• المنتجات: ${rep.totalProducts} | إجمالي الباركودات: ${rep.totalBarcodes}", style = MaterialTheme.typography.labelMedium)
                                    Text("• صور باركود تحتاج إعادة توليد: ${rep.missingImageCacheCount}", style = MaterialTheme.typography.labelMedium)
                                    Text("• باركودات بنوع غير محدد: ${rep.unspecifiedFormatCount}", style = MaterialTheme.typography.labelMedium)
                                    Text("• لقطات جرد غير متزامنة: ${rep.staleInventorySnapshotCount}", style = MaterialTheme.typography.labelMedium)
                                    if (rep.incompatibleBarcodes.isNotEmpty()) {
                                        Text(
                                            text = "• تنبيه: ${rep.incompatibleBarcodes.size} باركود مرمّز بصيغة غير متوافقة مع رقمه",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    }
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.runBarcodeLegacyAudit() },
                                enabled = !isAuditingBarcodes,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_audit_legacy_barcodes_btn"),
                            ) {
                                Text("فحص الآن")
                            }
                            Button(
                                onClick = {
                                    if (auditReport == null) viewModel.runBarcodeLegacyAudit()
                                    showBarcodeRepairDialog = true
                                },
                                enabled = !isAuditingBarcodes,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_repair_legacy_barcodes_btn"),
                            ) {
                                Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("إصلاح آمن")
                            }
                        }
                    }
                }
            }

            // Camera, Sound, Vibration, AutoSave & Backup
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("الكاميرا والصوت والحفظ التلقائي", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        SettingSwitch("المسح المتواصل للباركود", draft.cameraContinuousScan) { draft = draft.copy(cameraContinuousScan = it) }
                        SettingSwitch("تشغيل الفلاش افتراضياً", draft.cameraFlashDefault) { draft = draft.copy(cameraFlashDefault = it) }
                        SettingSwitch("صوت عند نجاح المسح", draft.scanBeepEnabled) { draft = draft.copy(scanBeepEnabled = it) }
                        SettingSwitch("اهتزاز عند نجاح المسح", draft.scanVibrateEnabled) { draft = draft.copy(scanVibrateEnabled = it) }
                        SettingSwitch("الحفظ التلقائي الفوري", draft.autoSaveEnabled) { draft = draft.copy(autoSaveEnabled = it) }
                        Spacer(Modifier.size(4.dp))
                        OutlinedButton(onClick = onOpenBackup, modifier = Modifier.fillMaxWidth()) {
                            Text("فتح إدارة النسخ الاحتياطي والاستعادة")
                        }
                        OutlinedButton(
                            onClick = onOpenDiagnostics,
                            modifier = Modifier.fillMaxWidth().testTag("settings_open_diagnostics_btn"),
                        ) {
                            Icon(Icons.Default.BugReport, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            val badge = if (diagStats.newErrorsCount > 0) " (${diagStats.newErrorsCount} جديد)" else ""
                            Text("مركز تشخيص الأخطاء$badge")
                        }
                    }
                }
            }

            // Dedicated About App Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التعريف بالتطبيق والدعم", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "اطلع على نبذة التطبيق ومميزاته ورقم الإصدار المثبت ومعلومات التواصل المباشر مع المطور.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(
                            onClick = onOpenAbout,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("settings_open_about_btn"),
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("حول التطبيق")
                        }
                    }
                }
            }

            // Independent Decimal Places Card for Products (Report & Inventory have per-column panels)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("المنازل العشرية وتنسيق الأرقام", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "أعمدة الجرد والتقارير تتحكم بمنازلها العشرية بشكل مستقل مباشرة من لوحة الأعمدة داخل كل شاشة. يمكنك هنا ضبط تنسيق أرقام شاشة المنتجات:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "• كمية المنتجات: ${NumberFormatEngine.arabicSummaryLabel(productsNumCfg.quantityFormat)}\n" +
                                "• سعر المنتجات: ${NumberFormatEngine.arabicSummaryLabel(productsNumCfg.priceFormat)}\n" +
                                "• معامل التحويل: ${NumberFormatEngine.arabicSummaryLabel(productsNumCfg.conversionFactorFormat)}",
                            style = MaterialTheme.typography.labelMedium,
                        )
                        OutlinedButton(
                            onClick = { showProductsDecimalDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("settings_products_decimals_btn"),
                        ) {
                            Text("تخصيص المنازل العشرية للمنتجات")
                        }
                    }
                }
            }
        }
    }

    if (showProductsDecimalDialog) {
        ProductsNumericSettingsDialog(
            config = productsNumCfg,
            onDismiss = { showProductsDecimalDialog = false },
            onSave = viewModel::updateProductsNumericConfig,
            onResetDefaults = viewModel::resetProductsNumericConfig,
        )
    }

    if (showBarcodeRepairDialog) {
        AlertDialog(
            onDismissRequest = { showBarcodeRepairDialog = false },
            title = { Text("إصلاح وتحديث باركودات القاعدة", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "سيتم تنفيذ العملية على دفعات آمنة دون حذف أي منتج أو تغيير أي رقم باركود أصلي أو معرّف (ID). سيتم فقط توليد الصور المفقودة، وتحديد الأنواع غير المحددة وفق الافتراضي، ومزامنة كشوف الجرد.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    val incompatibleCount = auditReport?.incompatibleBarcodes?.size ?: 0
                    if (incompatibleCount > 0) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "تم رصد $incompatibleCount باركود مرمّز بصيغة غير متطابقة مع أرقامه (مثل EAN-13 برقم تحقق غير قياسي).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { approveIncompatibleConversion = !approveIncompatibleConversion }
                                        .testTag("settings_approve_incompatible_conversion_checkbox"),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Checkbox(
                                        checked = approveIncompatibleConversion,
                                        onCheckedChange = { approveIncompatibleConversion = it },
                                    )
                                    Text(
                                        text = "أوافق على تحويل الصيغة غير المتوافقة إلى Code 128 للعرض والطباعة (مع إبقاء الرقم الأصلي كما هو تماماً)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBarcodeRepairDialog = false
                        viewModel.repairLegacyBarcodes(approveIncompatibleConversion)
                    },
                    modifier = Modifier.testTag("confirm_legacy_barcode_repair_btn"),
                ) {
                    Text("بدء الإصلاح الآمن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBarcodeRepairDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }

    repairResult?.let { res ->
        AlertDialog(
            onDismissRequest = { viewModel.clearBarcodeRepairResult() },
            title = { Text("نتيجة فحص وإصلاح الباركود", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("• إجمالي الباركودات المفحوصة: ${res.inspectedBarcodes}")
                    Text("• صور باركود مولّدة حديثاً: ${res.generatedImagesCount}")
                    Text("• باركودات حُدد نوعها الافتراضي: ${res.fixedUnspecifiedFormatsCount}")
                    Text("• بنود جرد تمت مزامنتها: ${res.syncedInventorySnapshotsCount}")
                    if (res.convertedIncompatibleWithApprovalCount > 0) {
                        Text("• صيغ غير متوافقة حُوّلت بموافقتك: ${res.convertedIncompatibleWithApprovalCount}")
                    }
                    if (res.skippedIncompatibleWithoutApprovalCount > 0) {
                        Text(
                            "• باركودات غير متوافقة تم الحفاظ عليها كما هي: ${res.skippedIncompatibleWithoutApprovalCount}",
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.clearBarcodeRepairResult() }) {
                    Text("تم")
                }
            },
        )
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
