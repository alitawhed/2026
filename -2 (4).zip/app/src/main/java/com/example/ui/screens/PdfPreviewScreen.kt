package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SaveAs
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.di.AppContainer
import com.example.domain.model.PageOrientation
import com.example.domain.pdf.PdfCancelledException
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintHelper
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.openFileViaProvider
import com.example.ui.components.shareFileViaProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfPreviewScreen(
    reportId: Long,
    initialPdfPath: String,
    inventorySessionId: Long = 0L,
    container: AppContainer,
    onBack: () -> Unit,
    onOpenPdfEditor: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var activeFile by remember { mutableStateOf(initialPdfPath.takeIf { it.isNotBlank() }?.let { File(it) }) }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    var renderedPageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isBusy by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }
    var cancelRequested by remember { mutableStateOf(false) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var showRenameSaveDialog by remember { mutableStateOf(false) }

    fun renderCurrentPage(file: File?, pageIdx: Int) {
        if (file == null || !file.exists()) return
        scope.launch {
            val (total, bmp) = withContext(Dispatchers.IO) {
                var pfd: ParcelFileDescriptor? = null
                var renderer: PdfRenderer? = null
                try {
                    pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    renderer = PdfRenderer(pfd)
                    val totalPages = renderer.pageCount
                    val safeIdx = pageIdx.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
                    val page = renderer.openPage(safeIdx)
                    val bmpW = (page.width * 2.5f).toInt().coerceIn(300, 2600)
                    val bmpH = (page.height * 2.5f).toInt().coerceIn(400, 3400)
                    val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(AndroidColor.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    totalPages to bitmap
                } catch (_: Throwable) {
                    0 to null
                } finally {
                    try { renderer?.close() } catch (_: Throwable) {}
                    try { pfd?.close() } catch (_: Throwable) {}
                }
            }
            pageCount = total
            renderedPageBitmap?.recycle()
            renderedPageBitmap = bmp
        }
    }

    var isLandscapePdf by remember { mutableStateOf(false) }

    fun regeneratePdf(customFileName: String? = null) {
        if (isBusy) return
        scope.launch {
            isBusy = true
            cancelRequested = false
            progressText = "جارٍ تجهيز الصفحات..."
            try {
                if (inventorySessionId > 0L) {
                    val session = container.inventoryRepository.getSessionOnce(inventorySessionId)
                    val allProducts = withContext(Dispatchers.IO) { container.database.productDao().getAllProductsWithDetailsOnce() }
                    val settings = container.settingsRepository.getSettingsOnce()
                    val invConfig = container.settingsRepository.getInventoryConfigOnce()
                    isLandscapePdf = invConfig.orientation == PageOrientation.LANDSCAPE
                    if (session != null) {
                        val res = withContext(Dispatchers.IO) {
                            container.pdfGeneratorEngine.generateInventoryReportPdf(
                                sessionDetails = session,
                                allProducts = allProducts,
                                settings = settings,
                                inventoryConfig = invConfig,
                                outputFileName = customFileName,
                                onProgress = { cur, tot -> progressText = "صفحة $cur من $tot" },
                                isCancelled = { cancelRequested },
                            )
                        }
                        activeFile = res.file
                        currentPageIndex = 0
                        renderCurrentPage(res.file, 0)
                        snackbarHostState.showSnackbar("تم إنشاء كشف الجرد PDF (${res.file.name}) • ${res.pageCount} صفحة")
                    }
                } else if (reportId > 0L) {
                    val details = container.reportRepository.getReportOnce(reportId)
                    val settings = container.settingsRepository.getSettingsOnce()
                    isLandscapePdf = details?.report?.orientation?.equals(PageOrientation.LANDSCAPE.name, true) == true
                    if (details != null) {
                        val res = withContext(Dispatchers.IO) {
                            container.pdfGeneratorEngine.generateReportPdf(
                                reportDetails = details,
                                settings = settings,
                                outputFileName = customFileName,
                                onProgress = { cur, tot -> progressText = "صفحة $cur من $tot" },
                                isCancelled = { cancelRequested },
                            )
                        }
                        activeFile = res.file
                        currentPageIndex = 0
                        renderCurrentPage(res.file, 0)
                        snackbarHostState.showSnackbar("تم إنشاء ملف PDF (${res.file.name}) • ${res.pageCount} صفحة")
                    }
                }
            } catch (_: PdfCancelledException) {
                snackbarHostState.showSnackbar("تم إلغاء إنشاء ملف PDF")
            } catch (t: Throwable) {
                snackbarHostState.showSnackbar("تعذر إنشاء PDF: ${t.localizedMessage ?: "خطأ"}")
            } finally {
                isBusy = false
                progressText = ""
            }
        }
    }

    LaunchedEffect(inventorySessionId, reportId) {
        if (inventorySessionId > 0L) {
            isLandscapePdf = container.settingsRepository.getInventoryConfigOnce().orientation == PageOrientation.LANDSCAPE
        } else if (reportId > 0L) {
            val details = container.reportRepository.getReportOnce(reportId)
            isLandscapePdf = details?.report?.orientation?.equals(PageOrientation.LANDSCAPE.name, true) == true
        }
    }

    LaunchedEffect(activeFile) {
        val f = activeFile
        if (f == null || !f.exists()) {
            regeneratePdf()
        } else {
            renderCurrentPage(f, currentPageIndex)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            renderedPageBitmap?.recycle()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "معاينة ملف PDF",
                subtitle = activeFile?.name,
                onBack = onBack,
                actions = {
                    IconButton(onClick = { regeneratePdf() }, modifier = Modifier.testTag("pdf_regenerate_btn")) {
                        Icon(Icons.Default.Refresh, contentDescription = "إعادة إنشاء التقرير")
                    }
                    IconButton(onClick = { showRenameSaveDialog = true }, modifier = Modifier.testTag("pdf_save_as_btn")) {
                        Icon(Icons.Default.SaveAs, contentDescription = "حفظ باسم مخصص")
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Zoom & Page Inspection Toolbar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        enabled = currentPageIndex > 0,
                        onClick = {
                            currentPageIndex--
                            renderCurrentPage(activeFile, currentPageIndex)
                        },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "الصفحة السابقة")
                    }
                    Text(
                        text = if (pageCount > 0) "صفحة ${currentPageIndex + 1} من $pageCount" else "—",
                        fontWeight = FontWeight.Bold,
                    )
                    IconButton(
                        enabled = currentPageIndex < pageCount - 1,
                        onClick = {
                            currentPageIndex++
                            renderCurrentPage(activeFile, currentPageIndex)
                        },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "الصفحة التالية")
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = { zoomScale = (zoomScale - 0.35f).coerceAtLeast(1f) }) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "تصغير")
                    }
                    IconButton(onClick = { zoomScale = 1f }) {
                        Icon(Icons.Default.FitScreen, contentDescription = "عرض الصفحة كاملة")
                    }
                    IconButton(onClick = { zoomScale = (zoomScale + 0.35f).coerceAtMost(4f) }) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "تكبير")
                    }
                }
            }

            // Rendered PDF Page Viewport
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF334155))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomScale = (zoomScale * zoom).coerceIn(1f, 4.5f)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (isBusy) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(color = Color.White)
                        if (progressText.isNotBlank()) {
                            Text(progressText, color = Color.White)
                        }
                        TextButton(onClick = { cancelRequested = true }) {
                            Text("إلغاء", color = Color(0xFFFCA5A5))
                        }
                    }
                } else {
                    val bmp = renderedPageBitmap
                    if (bmp != null) {
                        Surface(
                            shadowElevation = 8.dp,
                            color = Color.White,
                            modifier = Modifier
                                .padding(12.dp)
                                .graphicsLayer(scaleX = zoomScale, scaleY = zoomScale),
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "معاينة صفحة PDF",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    } else {
                        Text("تعذر عرض ملف PDF", color = Color.White)
                    }
                }
            }

            // Action Buttons: Share, Open, Print, Save As
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !isBusy && activeFile?.exists() == true,
                    onClick = {
                        activeFile?.let { f ->
                            shareFileViaProvider(context, f, "application/pdf", "مشاركة أو تنزيل PDF")
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("pdf_share_btn"),
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("مشاركة / تنزيل")
                }
                FilledTonalButton(
                    enabled = !isBusy && activeFile?.exists() == true,
                    onClick = {
                        activeFile?.let { f ->
                            val res = SafePdfPrintHelper.printPdfWithActivity(
                                context = context,
                                pdfFile = f,
                                jobName = f.nameWithoutExtension,
                                isLandscape = isLandscapePdf,
                            )
                            if (res is PrintDispatchResult.Error) {
                                scope.launch { snackbarHostState.showSnackbar(res.message) }
                            }
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("pdf_print_btn"),
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("طباعة")
                }
                OutlinedButton(
                    onClick = {
                        activeFile?.let { f ->
                            openFileViaProvider(context, f, "application/pdf")
                        }
                    },
                    modifier = Modifier.testTag("pdf_open_btn"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "فتح PDF", modifier = Modifier.size(18.dp))
                }
            }
            OutlinedButton(
                enabled = activeFile?.exists() == true,
                onClick = {
                    activeFile?.let { f -> onOpenPdfEditor(f.absolutePath) }
                },
                modifier = Modifier.fillMaxWidth().testTag("pdf_open_in_editor_btn"),
            ) {
                Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("تحرير في محرر PDF الاحترافي")
            }
        }
    }

    if (showRenameSaveDialog) {
        var fileName by remember { mutableStateOf(activeFile?.nameWithoutExtension ?: "report_$reportId") }
        AlertDialog(
            onDismissRequest = { showRenameSaveDialog = false },
            title = { Text("اختيار اسم ملف PDF قبل التصدير") },
            text = {
                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text("اسم الملف") },
                    singleLine = true,
                )
            },
            confirmButton = {
                Button(onClick = {
                    showRenameSaveDialog = false
                    regeneratePdf(fileName)
                }) { Text("إنشاء وحفظ") }
            },
            dismissButton = {
                TextButton(onClick = { showRenameSaveDialog = false }) { Text("إلغاء") }
            },
        )
    }
}
