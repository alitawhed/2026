package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.ProductWithDetails
import com.example.data.repository.DuplicateCountAction
import com.example.data.repository.InventoryScanLookupResult
import com.example.data.repository.InventoryUnitConflictException
import com.example.di.AppContainer
import com.example.domain.barcode.BarcodeChangeResult
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.withNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.layout.ColumnLayoutEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnLayoutResult
import com.example.domain.model.ColumnType
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySessionStatus
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.OverflowSuggestionType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

enum class InventoryListFilter(val arabicLabel: String) {
    ALL("الكل"),
    REGISTERED_COUNTED("مسجلة"),
    UNREGISTERED_ONLY("غير مسجلة"),
}

enum class InventoryViewMode(val arabicLabel: String) {
    TABLE("جدول الكشف المباشر"),
    CARDS("بطاقات الجرد"),
}

enum class DuplicatePromptStep {
    CHOOSE,
    ADD_QUANTITY,
    REPLACE_QUANTITY,
}

data class DuplicateBarcodePrompt(
    val lookupResult: InventoryScanLookupResult,
    val existingItem: InventoryCountItemEntity,
    val step: DuplicatePromptStep = DuplicatePromptStep.CHOOSE,
    val qtyInputText: String = "",
    val notesInputText: String = "",
    val unitConflictMessage: String? = null,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
) {
    val enteredQty: Double get() = parseInventoryDecimal(qtyInputText) ?: 0.0
    val enteredNotes: String get() = notesInputText
}

private fun normalizeArabicDigits(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            '٫', '،' -> sb.append('.')
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}

internal fun parseInventoryDecimal(raw: String): Double? {
    val normalized = normalizeArabicDigits(raw.trim()).replace(",", ".")
    if (normalized.isEmpty()) return null
    val parsed = normalized.toDoubleOrNull() ?: return null
    return if (parsed.isFinite() && parsed >= 0.0) parsed else null
}

data class InventoryUiState(
    val sessions: List<InventorySessionWithDetails> = emptyList(),
    val selectedSessionId: Long? = null,
    val activeSession: InventorySessionWithDetails? = null,
    val allProducts: List<ProductWithDetails> = emptyList(),
    val inventoryConfig: InventorySheetConfig = InventorySheetConfig(),
    val layoutResult: ColumnLayoutResult = ColumnLayoutEngine.calculateLayout(
        InventorySheetConfig().toPageSpec(),
        InventorySheetConfig().columns,
        ColumnDistributionMode.AUTO_FIT,
    ),
    val canUndoColumns: Boolean = false,
    val canRedoColumns: Boolean = false,
    val viewMode: InventoryViewMode = InventoryViewMode.TABLE,
    val barcodeInput: String = "",
    val searchQuery: String = "",
    val listFilter: InventoryListFilter = InventoryListFilter.ALL,
    val pendingScanLookup: InventoryScanLookupResult? = null,
    val qtyInput: String = "",
    val notesInput: String = "",
    val duplicatePrompt: DuplicateBarcodePrompt? = null,
    val isSubmittingCount: Boolean = false,
    val isBusy: Boolean = false,
    val statusMessage: String? = null,
    val isError: Boolean = false,
)

class InventoryViewModel(private val container: AppContainer) : ViewModel() {

    val barcodeService = container.barcodeService
    val defaultBarcodeType: StateFlow<BarcodeFormatType> = container.barcodeService.defaultBarcodeTypeFlow

    private val selectedSessionIdFlow = MutableStateFlow<Long?>(null)
    private val localControlsFlow = MutableStateFlow(LocalControls())

    private val configStateLock = Any()
    private val configWriteMutex = Mutex()
    private val pendingInventoryConfigFlow = MutableStateFlow<InventorySheetConfig?>(null)
    private val authoritativeDbConfigFlow = MutableStateFlow<InventorySheetConfig?>(null)
    private val pendingTransformQueue = ArrayDeque<(InventorySheetConfig) -> InventorySheetConfig>()
    private val configUndoStack = ArrayDeque<InventorySheetConfig>()
    private val configRedoStack = ArrayDeque<InventorySheetConfig>()
    private val configHistoryTickFlow = MutableStateFlow(0)
    private var activeConfigWriteCount = 0
    private var lastCommittedConfig: InventorySheetConfig? = null

    init {
        viewModelScope.launch {
            container.settingsRepository.inventoryConfigFlow.collect { cfg ->
                synchronized(configStateLock) {
                    authoritativeDbConfigFlow.value = cfg
                    if (activeConfigWriteCount == 0 &&
                        pendingTransformQueue.isEmpty() &&
                        (pendingInventoryConfigFlow.value == null ||
                            pendingInventoryConfigFlow.value == cfg ||
                            lastCommittedConfig == cfg)
                    ) {
                        pendingInventoryConfigFlow.value = null
                        lastCommittedConfig = null
                    }
                }
            }
        }
    }

    private data class LocalControls(
        val viewMode: InventoryViewMode = InventoryViewMode.TABLE,
        val barcodeInput: String = "",
        val searchQuery: String = "",
        val listFilter: InventoryListFilter = InventoryListFilter.ALL,
        val pendingScanLookup: InventoryScanLookupResult? = null,
        val qtyInput: String = "",
        val notesInput: String = "",
        val duplicatePrompt: DuplicateBarcodePrompt? = null,
        val isSubmittingCount: Boolean = false,
        val isBusy: Boolean = false,
        val statusMessage: String? = null,
        val isError: Boolean = false,
    )

    private val effectiveInventoryConfigFlow = combine(
        container.settingsRepository.inventoryConfigFlow,
        pendingInventoryConfigFlow,
    ) { dbConfig, pendingConfig ->
        pendingConfig ?: dbConfig
    }

    val uiState: StateFlow<InventoryUiState> = combine(
        container.inventoryRepository.allSessions,
        selectedSessionIdFlow,
        container.productRepository.allProducts,
        effectiveInventoryConfigFlow,
        localControlsFlow,
        configHistoryTickFlow,
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val sessions = arr[0] as List<InventorySessionWithDetails>
        val selectedId = arr[1] as Long?
        @Suppress("UNCHECKED_CAST")
        val products = arr[2] as List<ProductWithDetails>
        val invConfig = arr[3] as InventorySheetConfig
        val controls = arr[4] as LocalControls
        val resolvedSession = sessions.firstOrNull { it.session.id == selectedId }
            ?: sessions.firstOrNull { it.session.status == InventorySessionStatus.OPEN.name }
            ?: sessions.firstOrNull()

        val pageSpec = invConfig.toPageSpec()
        val layout = ColumnLayoutEngine.calculateLayout(
            pageSpec = pageSpec,
            allColumns = invConfig.columns,
            distributionMode = invConfig.distributionMode,
            splitHorizontalGroups = invConfig.splitHorizontalGroups,
        )
        val (canUndo, canRedo) = synchronized(configStateLock) {
            configUndoStack.isNotEmpty() to configRedoStack.isNotEmpty()
        }

        InventoryUiState(
            sessions = sessions,
            selectedSessionId = resolvedSession?.session?.id,
            activeSession = resolvedSession,
            allProducts = products,
            inventoryConfig = invConfig,
            layoutResult = layout,
            canUndoColumns = canUndo,
            canRedoColumns = canRedo,
            viewMode = controls.viewMode,
            barcodeInput = controls.barcodeInput,
            searchQuery = controls.searchQuery,
            listFilter = controls.listFilter,
            pendingScanLookup = controls.pendingScanLookup,
            qtyInput = controls.qtyInput,
            notesInput = controls.notesInput,
            duplicatePrompt = controls.duplicatePrompt,
            isSubmittingCount = controls.isSubmittingCount,
            isBusy = controls.isBusy,
            statusMessage = controls.statusMessage,
            isError = controls.isError,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InventoryUiState())

    val entitlementState = container.entitlementManager.entitlementState

    fun checkProFeature(feature: com.example.domain.billing.ProFeature): com.example.domain.billing.FeatureAccessDecision =
        container.entitlementManager.checkProFeatureAccess(feature)

    fun clearMessage() {
        localControlsFlow.value = localControlsFlow.value.copy(statusMessage = null, isError = false)
    }

    fun setViewMode(mode: InventoryViewMode) {
        localControlsFlow.value = localControlsFlow.value.copy(viewMode = mode)
    }

    fun selectSession(sessionId: Long) {
        selectedSessionIdFlow.value = sessionId
        localControlsFlow.value = localControlsFlow.value.copy(
            pendingScanLookup = null,
            qtyInput = "",
            notesInput = "",
            duplicatePrompt = null,
        )
    }

    fun onBarcodeInputChange(value: String) {
        if (value.contains('\n') || value.contains('\r')) {
            val cleaned = value.replace("\r", "").replace("\n", "")
            localControlsFlow.value = localControlsFlow.value.copy(barcodeInput = cleaned)
            if (cleaned.trim().isNotEmpty()) {
                lookupBarcode(cleaned)
            }
        } else {
            localControlsFlow.value = localControlsFlow.value.copy(barcodeInput = value)
        }
    }

    fun onQtyInputChange(value: String) {
        localControlsFlow.value = localControlsFlow.value.copy(qtyInput = value)
    }

    fun onNotesInputChange(value: String) {
        localControlsFlow.value = localControlsFlow.value.copy(notesInput = value)
    }

    fun onSearchQueryChange(value: String) {
        localControlsFlow.value = localControlsFlow.value.copy(searchQuery = value)
    }

    fun setListFilter(filter: InventoryListFilter) {
        localControlsFlow.value = localControlsFlow.value.copy(listFilter = filter)
    }

    fun dismissPendingLookup() {
        localControlsFlow.value = localControlsFlow.value.copy(
            pendingScanLookup = null,
            qtyInput = "",
            notesInput = "",
            duplicatePrompt = null,
        )
    }

    fun dismissDuplicatePrompt() {
        localControlsFlow.value = localControlsFlow.value.copy(duplicatePrompt = null)
    }

    fun createSession(title: String, notes: String = "") {
        viewModelScope.launch {
            val res = container.inventoryRepository.createSession(title = title, notes = notes)
            res.onSuccess { newId ->
                selectedSessionIdFlow.value = newId
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "تم إنشاء كشف الجرد «$title» بنجاح",
                    isError = false,
                )
            }.onFailure { err ->
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = err.message ?: "تعذر إنشاء كشف الجرد",
                    isError = true,
                )
            }
        }
    }

    fun updateActiveSessionDetails(title: String, notes: String) {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            container.inventoryRepository.updateSessionDetails(sessionId, title, notes)
                .onSuccess {
                    localControlsFlow.value = localControlsFlow.value.copy(
                        statusMessage = "تم تحديث بيانات كشف الجرد",
                        isError = false,
                    )
                }
                .onFailure { err ->
                    localControlsFlow.value = localControlsFlow.value.copy(
                        statusMessage = err.message ?: "تعذر تحديث بيانات الكشف",
                        isError = true,
                    )
                }
        }
    }

    fun closeActiveSession() {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            container.inventoryRepository.closeSession(sessionId).onSuccess {
                localControlsFlow.value = localControlsFlow.value.copy(
                    pendingScanLookup = null,
                    statusMessage = "تم إغلاق كشف الجرد وحفظه",
                    isError = false,
                )
            }.onFailure { err ->
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = err.message ?: "تعذر إغلاق الكشف",
                    isError = true,
                )
            }
        }
    }

    fun reopenActiveSession() {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            container.inventoryRepository.reopenSession(sessionId).onSuccess {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "تمت إعادة فتح كشف الجرد للتعديل",
                    isError = false,
                )
            }.onFailure { err ->
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = err.message ?: "تعذر إعادة فتح الكشف",
                    isError = true,
                )
            }
        }
    }

    fun deleteActiveSession() {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            container.inventoryRepository.deleteSession(sessionId).onSuccess {
                selectedSessionIdFlow.value = null
                localControlsFlow.value = localControlsFlow.value.copy(
                    pendingScanLookup = null,
                    statusMessage = "تم حذف كشف الجرد",
                    isError = false,
                )
            }.onFailure { err ->
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = err.message ?: "تعذر حذف الكشف",
                    isError = true,
                )
            }
        }
    }

    private suspend fun resolveActiveSessionForAction(): InventorySessionWithDetails? {
        uiState.value.activeSession?.let { return it }
        val targetId = selectedSessionIdFlow.value
        if (targetId != null) {
            container.inventoryRepository.getSessionOnce(targetId)?.let { return it }
        }
        val all = container.database.inventoryDao().getAllSessionsOnce()
        val picked = all.firstOrNull { it.status == InventorySessionStatus.OPEN.name } ?: all.firstOrNull()
        return picked?.let { container.inventoryRepository.getSessionOnce(it.id) }
    }

    /**
     * Looks up a scanned or entered barcode.
     * Immediately raises DuplicateBarcodePrompt if already recorded in the active session;
     * otherwise opens manual quantity entry without auto-incrementing.
     */
    fun lookupBarcode(rawBarcode: String, barcodeType: String? = null) {
        val code = rawBarcode.trim()
        if (code.isEmpty()) {
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = "أدخل قيمة الباركود أولاً",
                isError = true,
            )
            return
        }
        viewModelScope.launch {
            val session = resolveActiveSessionForAction()
            if (session == null) {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "أنشئ كشف جرد أولاً قبل المسح",
                    isError = true,
                )
                return@launch
            }
            if (session.session.status != InventorySessionStatus.OPEN.name) {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "الكشف مغلق؛ أعد فتحه أولاً لإضافة أو مسح البنود",
                    isError = true,
                )
                return@launch
            }
            val lookup = container.inventoryRepository.lookupBarcodeForSession(
                sessionId = session.session.id,
                rawBarcode = code,
                fallbackBarcodeType = barcodeType,
            )
            if (lookup != null) {
                presentLookupResult(lookup, code)
            }
        }
    }

    fun selectProductForInventory(
        product: ProductWithDetails,
        chosenBarcode: String? = null,
    ) {
        viewModelScope.launch {
            val session = resolveActiveSessionForAction()
            if (session == null) {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "أنشئ كشف جرد أولاً قبل إضافة المنتجات",
                    isError = true,
                )
                return@launch
            }
            if (session.session.status != InventorySessionStatus.OPEN.name) {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "الكشف مغلق؛ أعد فتحه أولاً لإضافة منتجات",
                    isError = true,
                )
                return@launch
            }

            val matchedBc = chosenBarcode?.trim()?.takeIf { it.isNotEmpty() }?.let { target ->
                product.barcodes.firstOrNull { it.barcodeValue == target }
            } ?: product.primaryBarcode ?: product.barcodes.firstOrNull()

            if (matchedBc != null) {
                val lookup = container.inventoryRepository.lookupBarcodeForSession(
                    sessionId = session.session.id,
                    rawBarcode = matchedBc.barcodeValue,
                    fallbackBarcodeType = matchedBc.barcodeType,
                )
                if (lookup != null) {
                    presentLookupResult(lookup, matchedBc.barcodeValue)
                    return@launch
                }
            }

            // Product with no registered barcode yet: use internalCode or PRD-<id> fallback key
            val fallbackCode = product.product.internalCode.ifBlank { "PRD-${product.product.id}" }
            val sessionDetails = container.inventoryRepository.getSessionOnce(session.session.id) ?: session
            val existingItem = sessionDetails.items.firstOrNull {
                it.productId == product.product.id && it.scannedBarcode == fallbackCode
            }
            val otherUnits = sessionDetails.items
                .filter { it.productId == product.product.id && it.scannedBarcode != fallbackCode && it.unitType != "حبة" }
                .map { "${it.unitType} (${it.scannedBarcode})" }
                .distinct()

            val lookup = InventoryScanLookupResult.MatchedRegistered(
                product = product,
                barcodeValue = fallbackCode,
                barcodeType = defaultBarcodeType.value.name,
                unitType = "حبة",
                conversionFactor = 1.0,
                isAlternativeBarcode = false,
                existingItemInSession = existingItem,
                otherUnitsInSession = otherUnits,
            )
            presentLookupResult(lookup, fallbackCode)
        }
    }

    fun onNewProductCreatedFromEditor(productId: Long) {
        if (productId <= 0L) return
        viewModelScope.launch {
            val created = container.productRepository.getProductWithDetailsOnce(productId)
            if (created != null) {
                selectProductForInventory(created)
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "تم حفظ المنتج «${created.product.name}» — أدخل الكمية لإضافته للجرد",
                    isError = false,
                )
            } else {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "تعذر العثور على المنتج المحفوظ",
                    isError = true,
                )
            }
        }
    }

    private fun presentLookupResult(
        lookup: InventoryScanLookupResult,
        displayBarcode: String,
    ) {
        val existingItem = when (lookup) {
            is InventoryScanLookupResult.MatchedRegistered -> lookup.existingItemInSession
            is InventoryScanLookupResult.UnregisteredBarcode -> lookup.existingUnregisteredItem
        }
        if (existingItem != null) {
            val unitConflictMsg = computeUnitConflictMessage(lookup, existingItem)
            localControlsFlow.value = localControlsFlow.value.copy(
                barcodeInput = displayBarcode,
                pendingScanLookup = null,
                qtyInput = "",
                notesInput = "",
                duplicatePrompt = DuplicateBarcodePrompt(
                    lookupResult = lookup,
                    existingItem = existingItem,
                    step = DuplicatePromptStep.CHOOSE,
                    qtyInputText = "",
                    notesInputText = "",
                    unitConflictMessage = unitConflictMsg,
                ),
                statusMessage = null,
                isError = false,
            )
        } else {
            localControlsFlow.value = localControlsFlow.value.copy(
                barcodeInput = displayBarcode,
                pendingScanLookup = lookup,
                qtyInput = "", // Strictly never auto-incremented on scan
                notesInput = "",
                duplicatePrompt = null,
                statusMessage = null,
                isError = false,
            )
        }
    }

    private fun computeUnitConflictMessage(
        lookup: InventoryScanLookupResult,
        existingItem: InventoryCountItemEntity,
    ): String? {
        if (lookup !is InventoryScanLookupResult.MatchedRegistered) return null
        if (existingItem.unitType == lookup.unitType &&
            abs(existingItem.conversionFactor - lookup.conversionFactor) <= 0.0001
        ) {
            return null
        }
        val currentCfg = synchronized(configStateLock) {
            pendingInventoryConfigFlow.value ?: authoritativeDbConfigFlow.value ?: uiState.value.inventoryConfig
        }
        val factorSpec = NumberFormatEngine.resolveInventoryColumnSpec(
            currentCfg.columns,
            "conversion_factor",
        )
        val prevFactorStr = NumberFormatEngine.formatDouble(existingItem.conversionFactor, factorSpec)
        val nextFactorStr = NumberFormatEngine.formatDouble(lookup.conversionFactor, factorSpec)
        return "تنبيه تعارض وحدة: هذا الباركود مسجل مسبقاً بوحدة (${existingItem.unitType} × $prevFactorStr) والآن وحدته (${lookup.unitType} × $nextFactorStr). تم تعطيل الإضافة فوق السابقة لحماية الكمية، ويمكنك استخدام «تعديل الكمية السابقة» أو «إلغاء»."
    }

    fun submitPendingCount() {
        val controls = localControlsFlow.value
        if (controls.isSubmittingCount) return
        val state = uiState.value
        val session = state.activeSession ?: return
        val lookup = state.pendingScanLookup ?: return

        if (session.session.status != InventorySessionStatus.OPEN.name) {
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = "الكشف مغلق؛ أعد فتحه أولاً لإضافة بنود",
                isError = true,
            )
            return
        }

        val parsedQty = parseInventoryDecimal(state.qtyInput)
        if (parsedQty == null || parsedQty < 0.0) {
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = "أدخل كمية صحيحة (0 أو رقم صحيح أو عشري)",
                isError = true,
            )
            return
        }

        val existingItem = when (lookup) {
            is InventoryScanLookupResult.MatchedRegistered -> lookup.existingItemInSession
            is InventoryScanLookupResult.UnregisteredBarcode -> lookup.existingUnregisteredItem
        }

        if (existingItem != null) {
            val unitConflictMsg = computeUnitConflictMessage(lookup, existingItem)
            localControlsFlow.value = localControlsFlow.value.copy(
                duplicatePrompt = DuplicateBarcodePrompt(
                    lookupResult = lookup,
                    existingItem = existingItem,
                    step = DuplicatePromptStep.CHOOSE,
                    qtyInputText = state.qtyInput,
                    notesInputText = state.notesInput,
                    unitConflictMessage = unitConflictMsg,
                ),
            )
            return
        }

        localControlsFlow.value = localControlsFlow.value.copy(isSubmittingCount = true)
        commitLookupWithAction(
            sessionId = session.session.id,
            lookup = lookup,
            qty = parsedQty,
            notes = state.notesInput,
            action = DuplicateCountAction.REPLACE_EXISTING,
        )
    }

    fun chooseDuplicatePromptStep(step: DuplicatePromptStep) {
        val current = localControlsFlow.value.duplicatePrompt ?: return
        if (step == DuplicatePromptStep.ADD_QUANTITY && current.unitConflictMessage != null) {
            localControlsFlow.value = localControlsFlow.value.copy(
                duplicatePrompt = current.copy(errorMessage = current.unitConflictMessage),
            )
            return
        }
        localControlsFlow.value = localControlsFlow.value.copy(
            duplicatePrompt = current.copy(
                step = step,
                qtyInputText = "",
                errorMessage = null,
            ),
        )
    }

    fun onDuplicatePromptQtyChange(value: String) {
        val current = localControlsFlow.value.duplicatePrompt ?: return
        localControlsFlow.value = localControlsFlow.value.copy(
            duplicatePrompt = current.copy(qtyInputText = value, errorMessage = null),
        )
    }

    fun onDuplicatePromptNotesChange(value: String) {
        val current = localControlsFlow.value.duplicatePrompt ?: return
        localControlsFlow.value = localControlsFlow.value.copy(
            duplicatePrompt = current.copy(notesInputText = value),
        )
    }

    fun confirmDuplicatePrompt() {
        val controls = localControlsFlow.value
        val prompt = controls.duplicatePrompt ?: return
        if (prompt.isSubmitting || controls.isSubmittingCount) return
        val session = uiState.value.activeSession ?: return
        if (session.session.status != InventorySessionStatus.OPEN.name) {
            localControlsFlow.value = controls.copy(
                duplicatePrompt = prompt.copy(errorMessage = "الكشف مغلق؛ أعد فتحه أولاً"),
            )
            return
        }

        val parsedQty = parseInventoryDecimal(prompt.qtyInputText)
        if (parsedQty == null || parsedQty < 0.0) {
            localControlsFlow.value = controls.copy(
                duplicatePrompt = prompt.copy(errorMessage = "أدخل كمية صحيحة (0 أو رقم صحيح أو عشري)"),
            )
            return
        }

        if (prompt.step == DuplicatePromptStep.ADD_QUANTITY && prompt.unitConflictMessage != null) {
            localControlsFlow.value = controls.copy(
                duplicatePrompt = prompt.copy(errorMessage = prompt.unitConflictMessage),
            )
            return
        }

        val action = when (prompt.step) {
            DuplicatePromptStep.ADD_QUANTITY -> DuplicateCountAction.ADD_TO_EXISTING
            DuplicatePromptStep.REPLACE_QUANTITY -> DuplicateCountAction.REPLACE_EXISTING
            DuplicatePromptStep.CHOOSE -> return
        }

        localControlsFlow.value = controls.copy(
            isSubmittingCount = true,
            duplicatePrompt = prompt.copy(isSubmitting = true, errorMessage = null),
        )
        commitLookupWithAction(
            sessionId = session.session.id,
            lookup = prompt.lookupResult,
            qty = parsedQty,
            notes = prompt.notesInputText,
            action = action,
        )
    }

    fun resolveDuplicatePrompt(action: DuplicateCountAction) {
        val controls = localControlsFlow.value
        if (controls.isSubmittingCount) return
        val state = uiState.value
        val session = state.activeSession ?: return
        val prompt = state.duplicatePrompt ?: return
        if (prompt.isSubmitting) return
        val qty = parseInventoryDecimal(prompt.qtyInputText) ?: return
        localControlsFlow.value = controls.copy(
            isSubmittingCount = true,
            duplicatePrompt = prompt.copy(isSubmitting = true, errorMessage = null),
        )
        commitLookupWithAction(
            sessionId = session.session.id,
            lookup = prompt.lookupResult,
            qty = qty,
            notes = prompt.enteredNotes,
            action = action,
        )
    }

    private fun commitLookupWithAction(
        sessionId: Long,
        lookup: InventoryScanLookupResult,
        qty: Double,
        notes: String,
        action: DuplicateCountAction,
    ) {
        viewModelScope.launch {
            try {
                val res = when (lookup) {
                    is InventoryScanLookupResult.MatchedRegistered -> {
                        container.inventoryRepository.recordCountedItem(
                            sessionId = sessionId,
                            product = lookup.product,
                            scannedBarcode = lookup.barcodeValue,
                            barcodeType = lookup.barcodeType,
                            unitType = lookup.unitType,
                            conversionFactor = lookup.conversionFactor,
                            quantity = qty,
                            notes = notes,
                            duplicateAction = action,
                        )
                    }
                    is InventoryScanLookupResult.UnregisteredBarcode -> {
                        container.inventoryRepository.recordUnregisteredBarcode(
                            sessionId = sessionId,
                            scannedBarcode = lookup.barcodeValue,
                            barcodeType = lookup.barcodeType,
                            quantity = qty,
                            notes = notes,
                            duplicateAction = action,
                        )
                    }
                }
                res.onSuccess {
                    localControlsFlow.value = localControlsFlow.value.copy(
                        barcodeInput = "",
                        pendingScanLookup = null,
                        qtyInput = "",
                        notesInput = "",
                        duplicatePrompt = null,
                        isSubmittingCount = false,
                        statusMessage = "تم حفظ الكمية في كشف الجرد بنجاح",
                        isError = false,
                    )
                }.onFailure { err ->
                    if (err is InventoryUnitConflictException) {
                        val prompt = localControlsFlow.value.duplicatePrompt
                        localControlsFlow.value = localControlsFlow.value.copy(
                            isSubmittingCount = false,
                            duplicatePrompt = prompt?.copy(
                                step = DuplicatePromptStep.CHOOSE,
                                isSubmitting = false,
                                unitConflictMessage = err.message,
                                errorMessage = err.message,
                            ),
                            statusMessage = err.message,
                            isError = true,
                        )
                    } else {
                        val prompt = localControlsFlow.value.duplicatePrompt
                        localControlsFlow.value = localControlsFlow.value.copy(
                            isSubmittingCount = false,
                            duplicatePrompt = prompt?.copy(isSubmitting = false, errorMessage = err.message),
                            statusMessage = err.message ?: "تعذر حفظ البند",
                            isError = true,
                        )
                    }
                }
            } catch (t: Throwable) {
                val prompt = localControlsFlow.value.duplicatePrompt
                localControlsFlow.value = localControlsFlow.value.copy(
                    isSubmittingCount = false,
                    duplicatePrompt = prompt?.copy(isSubmitting = false, errorMessage = t.message),
                    statusMessage = t.message ?: "تعذر حفظ البند",
                    isError = true,
                )
            }
        }
    }

    fun updateItemQuantity(itemId: Long, qtyText: String, notes: String) {
        val parsed = parseInventoryDecimal(qtyText)
        if (parsed == null || parsed < 0.0) {
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = "أدخل كمية صالحة (0 أو أكثر)",
                isError = true,
            )
            return
        }
        viewModelScope.launch {
            container.inventoryRepository.updateCountItemQuantity(itemId, parsed, notes.trim())
                .onSuccess {
                    localControlsFlow.value = localControlsFlow.value.copy(
                        statusMessage = "تم تحديث السطر في كشف الجرد",
                        isError = false,
                    )
                }
                .onFailure { err ->
                    localControlsFlow.value = localControlsFlow.value.copy(
                        statusMessage = err.message ?: "تعذر تعديل الكمية",
                        isError = true,
                    )
                }
        }
    }

    fun deleteItem(item: InventoryCountItemEntity) {
        viewModelScope.launch {
            container.inventoryRepository.deleteCountItem(item.id).onSuccess {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = "تم حذف السطر من كشف الجرد",
                    isError = false,
                )
            }.onFailure { err ->
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = err.message ?: "تعذر حذف السطر",
                    isError = true,
                )
            }
        }
    }

    // ==================== In-Place Scoped Barcode Format Switching ====================

    fun changePendingLookupBarcodeFormat(
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        val lookup = uiState.value.pendingScanLookup ?: return
        viewModelScope.launch {
            if (scope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                val res = container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
                val out = if (res.isSuccess) {
                    BarcodeChangeResult(
                        success = true,
                        message = "تم تعيين ${targetFormat.arabicLabel} كنوع افتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                        appliedFormat = targetFormat,
                    )
                } else {
                    BarcodeChangeResult(false, "تعذر تحديث النوع الافتراضي")
                }
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = out.message,
                    isError = !out.success,
                )
                onResult(out)
                return@launch
            }

            val code = when (lookup) {
                is InventoryScanLookupResult.MatchedRegistered -> lookup.barcodeValue
                is InventoryScanLookupResult.UnregisteredBarcode -> lookup.barcodeValue
            }
            val validation = BarcodeEngine.validate(code, targetFormat)
            if (!validation.isValid) {
                val msg = validation.errorMessage ?: "الباركود غير متوافق مع ${targetFormat.arabicLabel}"
                localControlsFlow.value = localControlsFlow.value.copy(statusMessage = msg, isError = true)
                onResult(BarcodeChangeResult(false, msg))
                return@launch
            }

            val updatedLookup = when (lookup) {
                is InventoryScanLookupResult.MatchedRegistered ->
                    lookup.copy(barcodeType = targetFormat.name)
                is InventoryScanLookupResult.UnregisteredBarcode ->
                    lookup.copy(barcodeType = targetFormat.name)
            }
            localControlsFlow.value = localControlsFlow.value.copy(pendingScanLookup = updatedLookup)

            if (scope == BarcodeFormatChangeScope.CURRENT_PRODUCT &&
                lookup is InventoryScanLookupResult.MatchedRegistered
            ) {
                val matchingBc = lookup.product.barcodes.firstOrNull { it.barcodeValue == lookup.barcodeValue }
                if (matchingBc != null) {
                    val res = container.barcodeService.changeFormatForProductBarcode(
                        productId = lookup.product.product.id,
                        barcodeId = matchingBc.id,
                        targetFormat = targetFormat,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                    localControlsFlow.value = localControlsFlow.value.copy(
                        statusMessage = res.message,
                        isError = !res.success,
                    )
                    onResult(res)
                    return@launch
                }
            }

            if (alsoUpdateDefault) {
                container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
            }
            val res = BarcodeChangeResult(
                success = true,
                message = "تم تغيير نوع باركود المعاينة إلى ${targetFormat.arabicLabel}",
                updatedCount = 1,
                appliedFormat = targetFormat,
            )
            localControlsFlow.value = localControlsFlow.value.copy(statusMessage = res.message, isError = false)
            onResult(res)
        }
    }

    fun changeInventoryItemBarcodeFormat(
        item: InventoryCountItemEntity,
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            val res = when (scope) {
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING -> {
                    val saved = container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
                    if (saved.isSuccess) {
                        BarcodeChangeResult(
                            success = true,
                            message = "تم تعيين ${targetFormat.arabicLabel} كنوع افتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                            appliedFormat = targetFormat,
                        )
                    } else {
                        BarcodeChangeResult(false, "تعذر تحديث النوع الافتراضي")
                    }
                }
                BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION ->
                    container.barcodeService.changeFormatForInventorySession(
                        sessionId = sessionId,
                        targetFormat = targetFormat,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                BarcodeFormatChangeScope.CURRENT_PRODUCT ->
                    container.barcodeService.changeFormatForInventoryItem(
                        sessionId = sessionId,
                        itemId = item.id,
                        targetFormat = targetFormat,
                        alsoUpdateProductCatalog = true,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                else ->
                    container.barcodeService.changeFormatForInventoryItem(
                        sessionId = sessionId,
                        itemId = item.id,
                        targetFormat = targetFormat,
                        alsoUpdateProductCatalog = false,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
            }
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = res.message,
                isError = !res.success,
            )
            onResult(res)
        }
    }

    fun changeCurrentSessionBarcodeFormat(
        targetFormat: BarcodeFormatType,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        val sessionId = uiState.value.activeSession?.session?.id ?: return
        viewModelScope.launch {
            val res = container.barcodeService.changeFormatForInventorySession(
                sessionId = sessionId,
                targetFormat = targetFormat,
                alsoUpdateDefaultSetting = alsoUpdateDefault,
            )
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = res.message,
                isError = !res.success,
            )
            onResult(res)
        }
    }

    // ==================== Independent Column, Barcode & Print Settings ====================

    private fun normalizeInventoryConfig(cfg: InventorySheetConfig): InventorySheetConfig {
        val normalizedCols = cfg.columns
            .sortedBy { it.sortOrder }
            .mapIndexed { idx, c -> c.copy(sortOrder = idx) }
        return cfg.copy(columns = normalizedCols, schemaRevision = 2)
    }

    fun updateInventoryConfig(transform: (InventorySheetConfig) -> InventorySheetConfig) {
        applyInventoryConfigTransform(recordUndo = true, transform = transform)
    }

    private fun applyInventoryConfigTransform(
        recordUndo: Boolean,
        transform: (InventorySheetConfig) -> InventorySheetConfig,
    ) {
        synchronized(configStateLock) {
            val current = pendingInventoryConfigFlow.value
                ?: authoritativeDbConfigFlow.value
                ?: uiState.value.inventoryConfig
            if (recordUndo) {
                configUndoStack.addLast(current)
                if (configUndoStack.size > 30) configUndoStack.removeFirst()
                configRedoStack.clear()
                configHistoryTickFlow.value++
            }
            val next = normalizeInventoryConfig(transform(current))
            pendingInventoryConfigFlow.value = next
            pendingTransformQueue.addLast(transform)
            activeConfigWriteCount++
        }

        viewModelScope.launch {
            var writeSucceeded = false
            var committed: InventorySheetConfig? = null
            try {
                committed = configWriteMutex.withLock {
                    withContext(NonCancellable) {
                        val nextTransform = synchronized(configStateLock) {
                            pendingTransformQueue.removeFirstOrNull()
                        }
                        if (nextTransform != null) {
                            container.settingsRepository.updateInventoryConfig(nextTransform)
                        } else {
                            null
                        }
                    }
                }
                writeSucceeded = true
            } catch (e: Exception) {
                localControlsFlow.value = localControlsFlow.value.copy(
                    statusMessage = e.message ?: "تعذر حفظ إعدادات الأعمدة",
                    isError = true,
                )
            } finally {
                synchronized(configStateLock) {
                    activeConfigWriteCount = (activeConfigWriteCount - 1).coerceAtLeast(0)
                    if (committed != null) {
                        lastCommittedConfig = committed
                        pendingInventoryConfigFlow.value = committed
                    }
                    if (activeConfigWriteCount == 0 && pendingTransformQueue.isEmpty()) {
                        val dbCfg = authoritativeDbConfigFlow.value
                        if (!writeSucceeded || (lastCommittedConfig != null && dbCfg == lastCommittedConfig)) {
                            pendingInventoryConfigFlow.value = null
                            lastCommittedConfig = null
                        }
                    }
                }
            }
        }
    }

    fun undoColumns() {
        val prev = synchronized(configStateLock) {
            if (configUndoStack.isEmpty()) return
            val current = pendingInventoryConfigFlow.value
                ?: authoritativeDbConfigFlow.value
                ?: uiState.value.inventoryConfig
            val popped = configUndoStack.removeLast()
            configRedoStack.addLast(current)
            configHistoryTickFlow.value++
            popped
        }
        applyInventoryConfigTransform(recordUndo = false) { prev }
        localControlsFlow.value = localControlsFlow.value.copy(
            statusMessage = "تم التراجع عن آخر تعديل للأعمدة",
            isError = false,
        )
    }

    fun redoColumns() {
        val next = synchronized(configStateLock) {
            if (configRedoStack.isEmpty()) return
            val current = pendingInventoryConfigFlow.value
                ?: authoritativeDbConfigFlow.value
                ?: uiState.value.inventoryConfig
            val popped = configRedoStack.removeLast()
            configUndoStack.addLast(current)
            configHistoryTickFlow.value++
            popped
        }
        applyInventoryConfigTransform(recordUndo = false) { next }
        localControlsFlow.value = localControlsFlow.value.copy(
            statusMessage = "تمت إعادة تطبيق تعديل الأعمدة",
            isError = false,
        )
    }

    fun toggleColumnVisibility(columnKey: String) {
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = cfg.columns.map {
                    if (it.columnKey == columnKey) it.copy(visible = !it.visible) else it
                },
            )
        }
    }

    fun toggleColumnPinned(columnKey: String) {
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = cfg.columns.map {
                    if (it.columnKey == columnKey) it.copy(pinned = !it.pinned) else it
                },
            )
        }
    }

    fun moveColumn(fromIndex: Int, toIndex: Int) {
        updateInventoryConfig { cfg ->
            val sorted = cfg.columns.sortedBy { it.sortOrder }.toMutableList()
            if (fromIndex !in sorted.indices || toIndex !in sorted.indices || fromIndex == toIndex) {
                cfg
            } else {
                val moved = sorted.removeAt(fromIndex)
                sorted.add(toIndex, moved)
                cfg.copy(columns = sorted.mapIndexed { idx, col -> col.copy(sortOrder = idx) })
            }
        }
    }

    fun reorderColumnsByKeys(orderedKeys: List<String>) {
        updateInventoryConfig { cfg ->
            val currentMap = cfg.columns.associateBy { it.columnKey }
            val reordered = orderedKeys.mapNotNull { currentMap[it] }.toMutableList()
            cfg.columns.forEach { col ->
                if (col.columnKey !in orderedKeys) reordered.add(col)
            }
            cfg.copy(columns = reordered.mapIndexed { idx, col -> col.copy(sortOrder = idx) })
        }
    }

    fun adjustColumnManualWidthDelta(columnKey: String, deltaPt: Float) {
        updateInventoryConfig { cfg ->
            val layout = ColumnLayoutEngine.calculateLayout(
                pageSpec = cfg.toPageSpec(),
                allColumns = cfg.columns,
                distributionMode = cfg.distributionMode,
                splitHorizontalGroups = cfg.splitHorizontalGroups,
            )
            val computedMap = layout.computedColumns.associateBy { it.column.columnKey }
            val nextCols = cfg.columns.map { col ->
                val baseW = computedMap[col.columnKey]?.widthPt ?: col.manualWidthPt
                if (col.columnKey == columnKey) {
                    val minAllowed = ColumnLayoutEngine.effectiveMinWidth(col)
                    val target = (baseW + deltaPt).coerceIn(minAllowed, col.maxWidthPt.coerceAtLeast(minAllowed + 40f))
                    col.copy(
                        manualWidthPt = target,
                        presetWidth = ColumnWidthPreset.CUSTOM,
                        widthMode = ColumnDistributionMode.MANUAL,
                    )
                } else if (cfg.distributionMode != ColumnDistributionMode.MANUAL) {
                    col.copy(
                        manualWidthPt = baseW,
                        widthMode = ColumnDistributionMode.MANUAL,
                    )
                } else {
                    col
                }
            }
            cfg.copy(
                distributionMode = ColumnDistributionMode.MANUAL,
                columns = nextCols,
            )
        }
    }

    fun setColumnManualWidth(columnKey: String, widthPt: Float) {
        updateInventoryConfig { cfg ->
            val layout = ColumnLayoutEngine.calculateLayout(
                pageSpec = cfg.toPageSpec(),
                allColumns = cfg.columns,
                distributionMode = cfg.distributionMode,
                splitHorizontalGroups = cfg.splitHorizontalGroups,
            )
            val computedMap = layout.computedColumns.associateBy { it.column.columnKey }
            val nextCols = cfg.columns.map { col ->
                val baseW = computedMap[col.columnKey]?.widthPt ?: col.manualWidthPt
                if (col.columnKey == columnKey) {
                    val minAllowed = ColumnLayoutEngine.effectiveMinWidth(col)
                    val target = widthPt.coerceIn(minAllowed, col.maxWidthPt.coerceAtLeast(minAllowed + 40f))
                    col.copy(
                        manualWidthPt = target,
                        presetWidth = ColumnWidthPreset.CUSTOM,
                        widthMode = ColumnDistributionMode.MANUAL,
                    )
                } else if (cfg.distributionMode != ColumnDistributionMode.MANUAL) {
                    col.copy(manualWidthPt = baseW, widthMode = ColumnDistributionMode.MANUAL)
                } else {
                    col
                }
            }
            cfg.copy(
                distributionMode = ColumnDistributionMode.MANUAL,
                columns = nextCols,
            )
        }
    }

    fun updateColumn(updated: ColumnConfigModel) {
        val cleanTitle = updated.title.trim()
        if (cleanTitle.isEmpty()) {
            localControlsFlow.value = localControlsFlow.value.copy(
                statusMessage = "يرجى إدخال عنوان غير فارغ للعمود",
                isError = true,
            )
            return
        }
        val normalizedUpdated = updated.copy(title = cleanTitle)
        updateInventoryConfig { cfg ->
            val prev = cfg.columns.firstOrNull { it.columnKey == normalizedUpdated.columnKey }
            val manualWidthChanged = prev != null &&
                (abs(prev.manualWidthPt - normalizedUpdated.manualWidthPt) > 0.5f ||
                    (normalizedUpdated.presetWidth == ColumnWidthPreset.CUSTOM && prev.presetWidth != ColumnWidthPreset.CUSTOM))
            val nextDistMode = if (manualWidthChanged) ColumnDistributionMode.MANUAL else cfg.distributionMode
            val layout = ColumnLayoutEngine.calculateLayout(
                pageSpec = cfg.toPageSpec(),
                allColumns = cfg.columns,
                distributionMode = cfg.distributionMode,
                splitHorizontalGroups = cfg.splitHorizontalGroups,
            )
            val computedMap = layout.computedColumns.associateBy { it.column.columnKey }
            cfg.copy(
                distributionMode = nextDistMode,
                columns = cfg.columns.map { col ->
                    when {
                        col.columnKey == normalizedUpdated.columnKey -> {
                            if (manualWidthChanged) {
                                val minAllowed = ColumnLayoutEngine.effectiveMinWidth(normalizedUpdated)
                                val target = normalizedUpdated.manualWidthPt.coerceIn(minAllowed, normalizedUpdated.maxWidthPt.coerceAtLeast(minAllowed + 40f))
                                normalizedUpdated.copy(
                                    manualWidthPt = target,
                                    presetWidth = ColumnWidthPreset.CUSTOM,
                                    widthMode = ColumnDistributionMode.MANUAL,
                                )
                            } else {
                                normalizedUpdated
                            }
                        }
                        manualWidthChanged && cfg.distributionMode != ColumnDistributionMode.MANUAL -> {
                            val baseW = computedMap[col.columnKey]?.widthPt ?: col.manualWidthPt
                            col.copy(manualWidthPt = baseW, widthMode = ColumnDistributionMode.MANUAL)
                        }
                        else -> col
                    }
                },
            )
        }
        localControlsFlow.value = localControlsFlow.value.copy(
            statusMessage = "تم حفظ تعديل عمود «$cleanTitle» وتطبيقه فوراً",
            isError = false,
        )
    }

    fun resetColumnWidthToDefault(columnKey: String) {
        val def = InventoryColumnDefaults.defaultColumnForKey(columnKey)
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = cfg.columns.map { col ->
                    if (col.columnKey == columnKey) {
                        if (def != null) {
                            col.copy(
                                manualWidthPt = def.manualWidthPt,
                                presetWidth = def.presetWidth,
                                minWidthPt = def.minWidthPt,
                                maxWidthPt = def.maxWidthPt,
                                cellHeightPt = def.cellHeightPt,
                                widthMode = ColumnDistributionMode.AUTO_FIT,
                            )
                        } else {
                            col.copy(
                                manualWidthPt = 78f,
                                presetWidth = ColumnWidthPreset.MEDIUM,
                                widthMode = ColumnDistributionMode.AUTO_FIT,
                            )
                        }
                    } else {
                        col
                    }
                },
            )
        }
    }

    fun resetAllColumnsToDefault() {
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = InventoryColumnDefaults.defaultColumns(),
                distributionMode = ColumnDistributionMode.AUTO_FIT,
                splitHorizontalGroups = false,
            )
        }
        localControlsFlow.value = localControlsFlow.value.copy(
            statusMessage = "تمت استعادة الإعدادات الافتراضية لأعمدة كشف الجرد",
            isError = false,
        )
    }

    fun updateColumnNumberFormat(columnKey: String, spec: NumberFormatSpec) {
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = cfg.columns.map { col ->
                    if (col.columnKey == columnKey) col.withNumberFormatSpec(spec) else col
                },
            )
        }
    }

    fun resetDecimalDefaults() {
        updateInventoryConfig { cfg ->
            cfg.copy(
                columns = cfg.columns.map { col ->
                    if (NumberFormatEngine.isNumericColumnType(col.columnType)) {
                        val defSpec = NumberFormatEngine.defaultSpecForColumn(
                            section = AppNumericSection.INVENTORY,
                            columnKey = col.columnKey,
                            columnType = col.columnType,
                        )
                        col.withNumberFormatSpec(defSpec)
                    } else {
                        col
                    }
                },
            )
        }
        localControlsFlow.value = localControlsFlow.value.copy(
            statusMessage = "تمت استعادة المنازل العشرية الافتراضية لأعمدة الجرد",
            isError = false,
        )
    }

    fun fitColumnsToPageWidth() {
        updateInventoryConfig { cfg ->
            cfg.copy(
                distributionMode = ColumnDistributionMode.AUTO_FIT,
                splitHorizontalGroups = false,
                columns = cfg.columns.map { it.copy(widthMode = ColumnDistributionMode.AUTO_FIT) },
            )
        }
    }

    fun setDistributionMode(mode: ColumnDistributionMode) {
        updateInventoryConfig { cfg ->
            cfg.copy(
                distributionMode = mode,
                columns = cfg.columns.map { it.copy(widthMode = mode) },
            )
        }
    }

    fun addOptionalColumn(optionalCol: ColumnConfigModel) {
        updateInventoryConfig { cfg ->
            if (cfg.columns.any { it.columnKey == optionalCol.columnKey }) {
                cfg.copy(
                    columns = cfg.columns.map {
                        if (it.columnKey == optionalCol.columnKey) it.copy(visible = true) else it
                    },
                )
            } else {
                cfg.copy(
                    columns = cfg.columns + optionalCol.copy(sortOrder = cfg.columns.size, visible = true),
                )
            }
        }
    }

    fun addCustomColumn(
        title: String,
        type: ColumnType,
        preset: ColumnWidthPreset = ColumnWidthPreset.MEDIUM,
    ) {
        val key = "custom_${System.currentTimeMillis()}"
        val defaultSpec = NumberFormatEngine.defaultSpecForColumn(AppNumericSection.INVENTORY, key, type)
        val widthPt = when (preset) {
            ColumnWidthPreset.NARROW -> 48f
            ColumnWidthPreset.MEDIUM -> 78f
            ColumnWidthPreset.WIDE -> 132f
            ColumnWidthPreset.CUSTOM -> 90f
        }
        updateInventoryConfig { cfg ->
            val col = ColumnConfigModel(
                columnKey = key,
                title = title.trim().ifBlank { type.arabicLabel },
                columnType = type,
                visible = true,
                sortOrder = cfg.columns.size,
                widthMode = cfg.distributionMode,
                manualWidthPt = widthPt,
                presetWidth = preset,
            ).withNumberFormatSpec(defaultSpec)
            cfg.copy(columns = cfg.columns + col)
        }
    }

    fun cloneColumn(column: ColumnConfigModel) {
        updateInventoryConfig { cfg ->
            val basePrefix = column.columnKey.substringBefore("_copy_")
            val copy = column.copy(
                columnKey = "${basePrefix}_copy_${System.currentTimeMillis() % 100000}",
                title = "${column.title} (نسخة)",
                sortOrder = cfg.columns.size,
                pinned = false,
            )
            cfg.copy(columns = cfg.columns + copy)
        }
    }

    fun deleteColumn(columnKey: String) {
        updateInventoryConfig { cfg ->
            val remaining = cfg.columns.filterNot { it.columnKey == columnKey }
            if (remaining.isEmpty()) cfg
            else cfg.copy(columns = remaining.mapIndexed { idx, c -> c.copy(sortOrder = idx) })
        }
    }

    fun applyOverflowSuggestion(type: OverflowSuggestionType) {
        when (type) {
            OverflowSuggestionType.SWITCH_LANDSCAPE -> updateInventoryConfig { it.copy(orientation = PageOrientation.LANDSCAPE) }
            OverflowSuggestionType.REDUCE_MARGINS -> updateInventoryConfig {
                it.copy(marginStartMm = 5f, marginEndMm = 5f, marginTopMm = 8f, marginBottomMm = 8f)
            }
            OverflowSuggestionType.LARGER_PAPER_A3 -> updateInventoryConfig { it.copy(paperSize = PaperSizeType.A3) }
            OverflowSuggestionType.SPLIT_HORIZONTAL_GROUPS -> updateInventoryConfig { it.copy(splitHorizontalGroups = true) }
            OverflowSuggestionType.MANUAL_WIDTHS -> setDistributionMode(ColumnDistributionMode.MANUAL)
        }
    }

    // ==================== Export, Preview & Print (Matching Active Columns & Barcode Settings) ====================

    fun exportInventoryPdf(onGenerated: (File) -> Unit) {
        val state = uiState.value
        val session = state.activeSession ?: return
        if (localControlsFlow.value.isBusy) return
        viewModelScope.launch {
            localControlsFlow.value = localControlsFlow.value.copy(isBusy = true)
            val trace = container.operationLogger.startOperation(
                ScreenNames.INVENTORY,
                DiagnosticModules.PDF,
                "تصدير كشف الجرد PDF",
                "تجهيز بيانات الجلسة والأعمدة",
            )
            try {
                val result = withContext(Dispatchers.IO) {
                    val settings = container.settingsRepository.getSettingsOnce()
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    trace.stage("رسم صفحات PDF لكشف الجرد")
                    container.pdfGeneratorEngine.generateInventoryReportPdf(
                        sessionDetails = session,
                        allProducts = state.allProducts,
                        settings = settings,
                        inventoryConfig = state.inventoryConfig,
                        outputFileName = "inventory_sheet_${session.session.id}_$stamp.pdf",
                    )
                }
                trace.succeed("صفحات: ${result.pageCount}")
                val warnNote = result.warnings.firstOrNull()?.let { " • تنبيه: $it" }.orEmpty()
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تم إنشاء كشف الجرد PDF (${result.pageCount} صفحة)$warnNote",
                    isError = false,
                )
                onGenerated(result.file)
            } catch (c: kotlinx.coroutines.CancellationException) {
                trace.cancel("تم إلغاء التصدير بمغادرة الشاشة")
                throw c
            } catch (e: Exception) {
                val err = container.globalErrorMonitor.recordError(
                    e,
                    ScreenNames.INVENTORY,
                    DiagnosticModules.PDF,
                    "تصدير كشف الجرد PDF",
                    linkedOperationId = trace.operationId,
                )
                trace.fail(e.message ?: "تعذر تصدير PDF", err.errorId)
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تعذر تصدير PDF: ${e.message}",
                    isError = true,
                )
            }
        }
    }

    fun generatePreviewPdf(onReady: (sessionId: Long, pdfPath: String) -> Unit) {
        val state = uiState.value
        val session = state.activeSession ?: return
        if (localControlsFlow.value.isBusy) return
        viewModelScope.launch {
            localControlsFlow.value = localControlsFlow.value.copy(isBusy = true)
            val trace = container.operationLogger.startOperation(
                ScreenNames.INVENTORY,
                DiagnosticModules.PDF,
                "معاينة كشف الجرد PDF",
                "تجهيز معاينة كشف الجرد",
            )
            try {
                val file = withContext(Dispatchers.IO) {
                    val settings = container.settingsRepository.getSettingsOnce()
                    trace.stage("توليد ملف المعاينة المؤقت")
                    container.pdfGeneratorEngine.generateInventoryReportPdf(
                        sessionDetails = session,
                        allProducts = state.allProducts,
                        settings = settings,
                        inventoryConfig = state.inventoryConfig,
                        outputFileName = "inventory_preview_${session.session.id}.pdf",
                    ).file
                }
                trace.succeed(file.name)
                localControlsFlow.value = localControlsFlow.value.copy(isBusy = false)
                onReady(session.session.id, file.absolutePath)
            } catch (c: kotlinx.coroutines.CancellationException) {
                trace.cancel("أُلغيت المعاينة بمغادرة الشاشة")
                throw c
            } catch (e: Exception) {
                val err = container.globalErrorMonitor.recordError(
                    e,
                    ScreenNames.INVENTORY,
                    DiagnosticModules.PDF,
                    "معاينة كشف الجرد PDF",
                    linkedOperationId = trace.operationId,
                )
                trace.fail(e.message ?: "تعذر تجهيز المعاينة", err.errorId)
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تعذر تجهيز المعاينة: ${e.message}",
                    isError = true,
                )
            }
        }
    }

    fun printInventoryPdf(context: Context) {
        val state = uiState.value
        val session = state.activeSession ?: return
        if (localControlsFlow.value.isBusy) return
        viewModelScope.launch {
            localControlsFlow.value = localControlsFlow.value.copy(isBusy = true)
            val trace = container.operationLogger.startOperation(
                ScreenNames.INVENTORY,
                DiagnosticModules.PDF,
                "طباعة كشف الجرد",
                "تجهيز مستند الطباعة",
            )
            try {
                val file = withContext(Dispatchers.IO) {
                    val settings = container.settingsRepository.getSettingsOnce()
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    trace.stage("إنشاء ملف PDF للطباعة")
                    container.pdfGeneratorEngine.generateInventoryReportPdf(
                        sessionDetails = session,
                        allProducts = state.allProducts,
                        settings = settings,
                        inventoryConfig = state.inventoryConfig,
                        outputFileName = "inventory_print_${session.session.id}_$stamp.pdf",
                    ).file
                }
                trace.stage("إرسال أمر الطباعة لنظام أندرويد")
                when (
                    val res = SafePdfPrintHelper.printPdfWithActivity(
                        context = context,
                        pdfFile = file,
                        jobName = "كشف_جرد_${session.session.title}",
                        isLandscape = state.inventoryConfig.orientation == PageOrientation.LANDSCAPE,
                    )
                ) {
                    is PrintDispatchResult.Started -> {
                        trace.succeed("تم إرسال وظيفة الطباعة بنجاح")
                        localControlsFlow.value = localControlsFlow.value.copy(
                            isBusy = false,
                            statusMessage = "تم فتح واجهة طباعة كشف الجرد",
                            isError = false,
                        )
                    }
                    is PrintDispatchResult.Error -> {
                        val err = container.globalErrorMonitor.recordCustomError(
                            screenName = ScreenNames.INVENTORY,
                            moduleName = DiagnosticModules.PDF,
                            operationName = "طباعة كشف الجرد",
                            errorType = "PrintDispatchError",
                            message = res.message,
                            linkedOperationId = trace.operationId,
                        )
                        trace.fail(res.message, err.errorId)
                        localControlsFlow.value = localControlsFlow.value.copy(
                            isBusy = false,
                            statusMessage = res.message,
                            isError = true,
                        )
                    }
                }
            } catch (c: kotlinx.coroutines.CancellationException) {
                trace.cancel("تم إلغاء الطباعة")
                throw c
            } catch (e: Exception) {
                val err = container.globalErrorMonitor.recordError(
                    e,
                    ScreenNames.INVENTORY,
                    DiagnosticModules.PDF,
                    "طباعة كشف الجرد",
                    linkedOperationId = trace.operationId,
                )
                trace.fail(e.message ?: "تعذر طباعة كشف الجرد", err.errorId)
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تعذر طباعة كشف الجرد: ${e.message}",
                    isError = true,
                )
            }
        }
    }

    fun exportInventoryExcel(onGenerated: (File) -> Unit) {
        val state = uiState.value
        val session = state.activeSession ?: return
        if (localControlsFlow.value.isBusy) return
        viewModelScope.launch {
            localControlsFlow.value = localControlsFlow.value.copy(isBusy = true)
            val trace = container.operationLogger.startOperation(
                ScreenNames.INVENTORY,
                DiagnosticModules.EXCEL,
                "تصدير كشف الجرد إلى Excel",
                "تجهيز أعمدة الجرد والتنسيق",
            )
            try {
                val file = withContext(Dispatchers.IO) {
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    trace.stage("كتابة ملف XLSX للجرد")
                    container.excelExportEngine.exportInventoryReportToXlsx(
                        sessionDetails = session,
                        allProducts = state.allProducts,
                        fileName = "inventory_sheet_${session.session.id}_$stamp.xlsx",
                        inventoryConfig = state.inventoryConfig,
                    )
                }
                trace.succeed(file.name)
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تم تصدير كشف الجرد إلى Excel بالأعمدة المحددة",
                    isError = false,
                )
                onGenerated(file)
            } catch (c: kotlinx.coroutines.CancellationException) {
                trace.cancel("تم إلغاء تصدير Excel")
                throw c
            } catch (e: Exception) {
                val err = container.globalErrorMonitor.recordError(
                    e,
                    ScreenNames.INVENTORY,
                    DiagnosticModules.EXCEL,
                    "تصدير كشف الجرد إلى Excel",
                    linkedOperationId = trace.operationId,
                )
                trace.fail(e.message ?: "تعذر تصدير Excel", err.errorId)
                localControlsFlow.value = localControlsFlow.value.copy(
                    isBusy = false,
                    statusMessage = "تعذر تصدير Excel: ${e.message}",
                    isError = true,
                )
            }
        }
    }
}
