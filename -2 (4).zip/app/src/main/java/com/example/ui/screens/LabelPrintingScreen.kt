package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.model.BarcodeFormatType
import com.example.domain.pdf.LabelPrintItem
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintHelper
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.CachedBarcodeImage
import com.example.ui.components.shareFileViaProvider
import com.example.ui.viewmodel.LabelPrintingViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LabelPrintingScreen(
    viewModel: LabelPrintingViewModel,
    onBack: () -> Unit,
) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val selectedLabels by viewModel.selectedLabels.collectAsStateWithLifecycle()
    val config by viewModel.config.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var productMenuOpen by remember { mutableStateOf(false) }
    var formatChangeLabelItem by remember { mutableStateOf<LabelPrintItem?>(null) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "طباعة ملصقات الباركود",
                subtitle = "تصدير PDF و SVG و PNG بدقة 300/600 DPI",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Product & Barcode Picker
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("اختيار منتج وباركود للطباعة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Box {
                            Button(
                                onClick = { productMenuOpen = true },
                                modifier = Modifier.fillMaxWidth().testTag("label_pick_product_btn"),
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("إضافة باركود منتج إلى قائمة الملصقات")
                            }
                            DropdownMenu(expanded = productMenuOpen, onDismissRequest = { productMenuOpen = false }) {
                                products.forEach { prod ->
                                    if (prod.barcodes.isEmpty()) return@forEach
                                    prod.barcodes.forEach { b ->
                                        DropdownMenuItem(
                                            text = { Text("${prod.product.name} — ${b.barcodeValue} (${b.label})") },
                                            onClick = {
                                                viewModel.addBarcodeLabel(
                                                    prod,
                                                    b.barcodeValue,
                                                    BarcodeFormatType.fromString(b.barcodeType),
                                                    copies = 4,
                                                )
                                                productMenuOpen = false
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Label Dimensions & Options
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مقاس الملصق والهوامش (مم)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = config.labelWidthMm.toInt().toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { viewModel.updateConfig(config.copy(labelWidthMm = it.coerceIn(20f, 200f))) } },
                                label = { Text("عرض الملصق") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = config.labelHeightMm.toInt().toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { viewModel.updateConfig(config.copy(labelHeightMm = it.coerceIn(15f, 150f))) } },
                                label = { Text("ارتفاع الملصق") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = config.marginMm.toInt().toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { viewModel.updateConfig(config.copy(marginMm = it.coerceIn(2f, 30f))) } },
                                label = { Text("الهامش") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("إظهار اسم المنتج")
                            Switch(checked = config.showProductName, onCheckedChange = { viewModel.updateConfig(config.copy(showProductName = it)) })
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("إظهار الرقم أسفل الباركود")
                            Switch(checked = config.showBarcodeValue, onCheckedChange = { viewModel.updateConfig(config.copy(showBarcodeValue = it)) })
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("إظهار السعر")
                            Switch(checked = config.showPrice, onCheckedChange = { viewModel.updateConfig(config.copy(showPrice = it)) })
                        }
                    }
                }
            }

            // Selected Labels Preview & Copies
            items(selectedLabels, key = { it.barcodeValue }) { item ->
                val matchingProdId = remember(products, item.barcodeValue) {
                    products.firstOrNull { p -> p.barcodes.any { it.barcodeValue == item.barcodeValue } }?.product?.id
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                if (config.showProductName) Text(item.productName, fontWeight = FontWeight.Bold)
                                Text("${item.barcodeValue} (${item.barcodeFormat.arabicLabel})", style = MaterialTheme.typography.labelSmall)
                                if (config.showPrice) Text(item.priceText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedTextField(
                                    value = item.copies.toString(),
                                    onValueChange = { v -> v.toIntOrNull()?.let { viewModel.updateCopies(item.barcodeValue, it) } },
                                    label = { Text("النسخ") },
                                    modifier = Modifier.width(80.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                )
                                IconButton(onClick = { viewModel.removeLabel(item.barcodeValue) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                        CachedBarcodeImage(
                            productId = matchingProdId,
                            barcodeValue = item.barcodeValue,
                            format = item.barcodeFormat,
                            barcodeService = viewModel.barcodeService,
                            baseWidthPx = if (item.barcodeFormat.is2D) 420 else 840,
                            baseHeightPx = if (item.barcodeFormat.is2D) 420 else 260,
                            showTextBelow = config.showBarcodeValue,
                            quietZoneModules = config.quietZoneModules,
                            allowTapToZoom = true,
                            modifier = Modifier.fillMaxWidth().height(88.dp),
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            OutlinedButton(
                                onClick = { formatChangeLabelItem = item },
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("label_change_format_btn_${item.barcodeValue}"),
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تغيير النوع")
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.exportSingleSvg(item.barcodeValue, item.barcodeFormat) { f ->
                                        shareFileViaProvider(context, f, "image/svg+xml", "تصدير SVG")
                                    }
                                },
                                modifier = Modifier.heightIn(min = 48.dp),
                            ) { Text("SVG") }
                            OutlinedButton(
                                onClick = {
                                    viewModel.exportSingleHighDpiPng(item.barcodeValue, item.barcodeFormat, 300) { f ->
                                        shareFileViaProvider(context, f, "image/png", "تصدير PNG 300 DPI")
                                    }
                                },
                                modifier = Modifier.heightIn(min = 48.dp),
                            ) { Text("PNG 300 DPI") }
                            OutlinedButton(
                                onClick = {
                                    viewModel.exportSingleHighDpiPng(item.barcodeValue, item.barcodeFormat, 600) { f ->
                                        shareFileViaProvider(context, f, "image/png", "تصدير PNG 600 DPI")
                                    }
                                },
                                modifier = Modifier.heightIn(min = 48.dp),
                            ) { Text("PNG 600 DPI") }
                        }
                    }
                }
            }

            // Export PDF & Print Buttons
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !isBusy,
                        onClick = {
                            viewModel.exportLabelsPdf { f ->
                                shareFileViaProvider(context, f, "application/pdf", "تصدير ملصقات الباركود PDF")
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("labels_export_pdf_btn"),
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تصدير PDF")
                    }
                    FilledTonalButton(
                        enabled = !isBusy,
                        onClick = {
                            viewModel.exportLabelsPdf { file ->
                                val res = SafePdfPrintHelper.printPdfWithActivity(
                                    context = context,
                                    pdfFile = file,
                                    jobName = "طباعة ملصقات الباركود",
                                )
                                if (res is PrintDispatchResult.Error) {
                                    viewModel.postMessage(res.message)
                                }
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("labels_print_btn"),
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (isBusy) "جارٍ التجهيز..." else "طباعة مباشرة")
                    }
                }
            }
        }
    }

    formatChangeLabelItem?.let { target ->
        val isRegisteredProduct = products.any { p -> p.barcodes.any { it.barcodeValue == target.barcodeValue } }
        val scopes = buildList {
            add(BarcodeFormatChangeScope.CURRENT_LABEL_ONLY)
            if (isRegisteredProduct) add(BarcodeFormatChangeScope.CURRENT_PRODUCT)
            add(BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING)
        }
        BarcodeFormatChangeDialog(
            barcodeValue = target.barcodeValue,
            currentFormat = target.barcodeFormat,
            productName = target.productName,
            availableScopes = scopes,
            initialScope = BarcodeFormatChangeScope.CURRENT_LABEL_ONLY,
            onDismiss = { formatChangeLabelItem = null },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                viewModel.changeLabelBarcodeFormat(
                    barcodeValue = target.barcodeValue,
                    targetFormat = targetFormat,
                    scope = scope,
                    alsoUpdateDefault = alsoUpdateDefault,
                ) { res ->
                    if (res.success) formatChangeLabelItem = null
                }
            },
        )
    }
}
