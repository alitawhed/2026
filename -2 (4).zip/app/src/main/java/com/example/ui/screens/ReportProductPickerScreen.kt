package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.repository.AddProductToReportResult
import com.example.data.repository.ReportProductPickRequest
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.di.AppContainer
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.ProductSelectionViewMode
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.components.formatCurrencyValue
import kotlinx.coroutines.launch

private enum class PickerFilterOption(val label: String) {
    ALL("الكل"),
    HAS_IMAGES("لديها صور"),
    NO_IMAGES("بدون صور"),
    MULTI_BARCODE("متعددة الباركودات"),
    IN_REPORT("مضافة للتقرير"),
    NOT_IN_REPORT("غير مضافة بعد"),
}

private enum class PickerSortOption(val label: String) {
    NEWEST("الأحدث"),
    NAME_ASC("الاسم (أ - ي)"),
    PRICE_DESC("السعر (الأعلى)"),
    PRICE_ASC("السعر (الأقل)"),
}

@kotlin.OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ReportProductPickerScreen(
    reportId: Long,
    container: AppContainer,
    onBack: () -> Unit,
    onOpenScannerForReport: (Long) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val allProducts by container.productRepository.allProducts.collectAsStateWithLifecycle(initialValue = emptyList())
    val reportDetails by container.reportRepository.observeReport(reportId).collectAsStateWithLifecycle(initialValue = null)
    val settings by container.settingsRepository.settingsFlow.collectAsStateWithLifecycle(initialValue = AppSettingsEntity())

    val viewMode = remember(settings.productPickerViewMode) {
        ProductSelectionViewMode.fromString(settings.productPickerViewMode)
    }

    var searchQuery by remember { mutableStateOf("") }
    var filterOption by remember { mutableStateOf(PickerFilterOption.ALL) }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var sortOption by remember { mutableStateOf(PickerSortOption.NEWEST) }
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showViewModeMenu by remember { mutableStateOf(false) }

    var multiSelectMode by remember { mutableStateOf(false) }
    var selectedProductIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    var galleryTargetProduct by remember { mutableStateOf<ProductWithDetails?>(null) }
    var previewTargetProduct by remember { mutableStateOf<ProductWithDetails?>(null) }

    val addedCountsByProductId = remember(reportDetails) {
        reportDetails?.items
            ?.mapNotNull { it.item.sourceProductId }
            ?.groupingBy { it }
            ?.eachCount()
            .orEmpty()
    }

    val categories = remember(allProducts) {
        listOf("الكل") + allProducts.mapNotNull { it.product.categoryName.trim().takeIf { c -> c.isNotEmpty() } }
            .distinct()
            .sorted()
    }

    val filteredProducts = remember(allProducts, searchQuery, filterOption, selectedCategory, sortOption, addedCountsByProductId) {
        val unified = container.productRepository.filterProductsUnified(allProducts, searchQuery)
        val matched = unified.filter { p ->
            val matchesCat = selectedCategory == "الكل" ||
                p.product.categoryName.equals(selectedCategory, ignoreCase = true)

            val inReport = (addedCountsByProductId[p.product.id] ?: 0) > 0
            val matchesFilter = when (filterOption) {
                PickerFilterOption.ALL -> true
                PickerFilterOption.HAS_IMAGES -> p.images.isNotEmpty()
                PickerFilterOption.NO_IMAGES -> p.images.isEmpty()
                PickerFilterOption.MULTI_BARCODE -> p.barcodes.size > 1
                PickerFilterOption.IN_REPORT -> inReport
                PickerFilterOption.NOT_IN_REPORT -> !inReport
            }
            matchesCat && matchesFilter
        }
        when (sortOption) {
            PickerSortOption.NEWEST -> matched.sortedByDescending { it.product.updatedAt }
            PickerSortOption.NAME_ASC -> matched.sortedBy { it.product.name.lowercase() }
            PickerSortOption.PRICE_DESC -> matched.sortedByDescending { it.product.basePrice }
            PickerSortOption.PRICE_ASC -> matched.sortedBy { it.product.basePrice }
        }
    }

    fun addSingleProduct(
        product: ProductWithDetails,
        barcodeOverride: String? = null,
        imageId: Long? = null,
    ) {
        scope.launch {
            when (val res = container.reportRepository.addProductToReport(
                reportId = reportId,
                product = product,
                selectedBarcodeOverride = barcodeOverride,
                selectedImageId = imageId,
            )) {
                is AddProductToReportResult.Added ->
                    snackbarHostState.showSnackbar("تمت إضافة (${product.product.name}) إلى التقرير")
                is AddProductToReportResult.IncrementedExisting -> {
                    val qtySpec = NumberFormatEngine.resolveReportQuantitySpec(
                        reportDetails?.columns?.map { it.toDomainModel() }.orEmpty(),
                    )
                    snackbarHostState.showSnackbar(
                        "تمت زيادة كمية (${product.product.name}) إلى ${NumberFormatEngine.formatDouble(res.newQty, qtySpec)}",
                    )
                }
                AddProductToReportResult.PreventedDuplicate ->
                    snackbarHostState.showSnackbar("المنتج مضاف مسبقاً (التكرار ممنوع حسب إعدادات التقرير)")
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "اختيار المنتجات للتقرير",
                subtitle = reportDetails?.let { "${it.report.title} • ${it.items.size} صفوف مضافة" },
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { onOpenScannerForReport(reportId) },
                        modifier = Modifier.testTag("picker_scan_barcode_btn"),
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود")
                    }
                    IconButton(
                        onClick = {
                            multiSelectMode = !multiSelectMode
                            if (!multiSelectMode) selectedProductIds = emptySet()
                        },
                        modifier = Modifier.testTag("picker_multiselect_toggle_btn"),
                    ) {
                        Icon(
                            Icons.Default.Checklist,
                            contentDescription = "تحديد متعدد",
                            tint = if (multiSelectMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Box {
                        IconButton(
                            onClick = { showViewModeMenu = true },
                            modifier = Modifier.testTag("picker_view_mode_btn"),
                        ) {
                            Icon(
                                when (viewMode) {
                                    ProductSelectionViewMode.LIST -> Icons.AutoMirrored.Filled.FormatListBulleted
                                    ProductSelectionViewMode.GRID -> Icons.Default.GridView
                                    ProductSelectionViewMode.COMPACT -> Icons.Default.ViewHeadline
                                    ProductSelectionViewMode.DETAILED -> Icons.Default.ViewAgenda
                                },
                                contentDescription = "نمط العرض",
                            )
                        }
                        DropdownMenu(expanded = showViewModeMenu, onDismissRequest = { showViewModeMenu = false }) {
                            ProductSelectionViewMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(mode.arabicLabel, fontWeight = if (viewMode == mode) FontWeight.Bold else FontWeight.Normal)
                                        }
                                    },
                                    onClick = {
                                        showViewModeMenu = false
                                        scope.launch {
                                            container.settingsRepository.saveSettings(
                                                settings.copy(productPickerViewMode = mode.name),
                                            )
                                        }
                                    },
                                )
                            }
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (multiSelectMode || selectedProductIds.isNotEmpty()) {
                Surface(
                    tonalElevation = 4.dp,
                    shadowElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TextButton(
                            onClick = {
                                selectedProductIds = if (selectedProductIds.size == filteredProducts.size) {
                                    emptySet()
                                } else {
                                    filteredProducts.map { it.product.id }.toSet()
                                }
                            },
                        ) {
                            Text(if (selectedProductIds.size == filteredProducts.size && filteredProducts.isNotEmpty()) "إلغاء الكل" else "تحديد الكل")
                        }
                        Spacer(Modifier.weight(1f))
                        Button(
                            enabled = selectedProductIds.isNotEmpty(),
                            onClick = {
                                val chosen = filteredProducts
                                    .filter { it.product.id in selectedProductIds }
                                    .map { ReportProductPickRequest(product = it) }
                                scope.launch {
                                    val res = container.reportRepository.addProductsBatchToReport(reportId, chosen)
                                    selectedProductIds = emptySet()
                                    multiSelectMode = false
                                    snackbarHostState.showSnackbar(
                                        "تمت إضافة ${res.addedCount} • زيادة كمية ${res.incrementedCount} • متجاهل ${res.skippedCount}",
                                    )
                                }
                            },
                            modifier = Modifier.testTag("picker_add_selected_batch_btn"),
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إضافة المحدد (${selectedProductIds.size})")
                        }
                    }
                }
            } else {
                Surface(tonalElevation = 2.dp, border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "المعروض: ${filteredProducts.size} منتج • بالتقرير: ${reportDetails?.items?.size ?: 0}",
                            style = MaterialTheme.typography.labelMedium,
                        )
                        FilledTonalButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("picker_done_back_btn"),
                        ) {
                            Text("عرض التقرير")
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // Instant Smart Search Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث ذكي بالاسم، الباركود الرئيسي/الإضافي، الرقم الداخلي، التصنيف...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("picker_search_input"),
            )

            // Filter Chips + Category + Sort Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    AssistChip(
                        onClick = { showCategoryMenu = true },
                        label = { Text("التصنيف: $selectedCategory") },
                    )
                    DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    selectedCategory = cat
                                    showCategoryMenu = false
                                },
                            )
                        }
                    }
                }

                Box {
                    AssistChip(
                        onClick = { showSortMenu = true },
                        leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text(sortOption.label) },
                    )
                    DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                        PickerSortOption.entries.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt.label) },
                                onClick = {
                                    sortOption = opt
                                    showSortMenu = false
                                },
                            )
                        }
                    }
                }

                PickerFilterOption.entries.forEach { opt ->
                    FilterChip(
                        selected = filterOption == opt,
                        onClick = { filterOption = opt },
                        label = { Text(opt.label) },
                    )
                }
            }

            if (filteredProducts.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyStateCard(
                        title = "لا توجد منتجات مطابقة",
                        description = "جرّب تغيير كلمات البحث أو إزالة الفلاتر الحالية.",
                        actionLabel = "إعادة ضبط الفلترة",
                        onAction = {
                            searchQuery = ""
                            filterOption = PickerFilterOption.ALL
                            selectedCategory = "الكل"
                        },
                    )
                }
            } else {
                BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    val gridCols = if (maxWidth >= 600.dp) 3 else 2

                    if (viewMode == ProductSelectionViewMode.GRID) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(gridCols),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 12.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            gridItems(filteredProducts, key = { it.product.id }) { prod ->
                                val addedCount = addedCountsByProductId[prod.product.id] ?: 0
                                val isChecked = prod.product.id in selectedProductIds
                                ProductPickerGridCard(
                                    product = prod,
                                    addedCount = addedCount,
                                    multiSelectMode = multiSelectMode,
                                    isSelected = isChecked,
                                    onToggleSelect = {
                                        selectedProductIds = if (isChecked) selectedProductIds - prod.product.id else selectedProductIds + prod.product.id
                                    },
                                    onQuickAdd = { addSingleProduct(prod) },
                                    onOpenGallery = { galleryTargetProduct = prod },
                                    onOpenPreview = { previewTargetProduct = prod },
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 12.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(filteredProducts, key = { it.product.id }) { prod ->
                                val addedCount = addedCountsByProductId[prod.product.id] ?: 0
                                val isChecked = prod.product.id in selectedProductIds
                                when (viewMode) {
                                    ProductSelectionViewMode.COMPACT -> ProductPickerCompactRow(
                                        product = prod,
                                        addedCount = addedCount,
                                        multiSelectMode = multiSelectMode,
                                        isSelected = isChecked,
                                        onToggleSelect = {
                                            selectedProductIds = if (isChecked) selectedProductIds - prod.product.id else selectedProductIds + prod.product.id
                                        },
                                        onQuickAdd = { addSingleProduct(prod) },
                                        onOpenGallery = { galleryTargetProduct = prod },
                                        onOpenPreview = { previewTargetProduct = prod },
                                    )
                                    ProductSelectionViewMode.DETAILED -> ProductPickerDetailedCard(
                                        product = prod,
                                        addedCount = addedCount,
                                        multiSelectMode = multiSelectMode,
                                        isSelected = isChecked,
                                        onToggleSelect = {
                                            selectedProductIds = if (isChecked) selectedProductIds - prod.product.id else selectedProductIds + prod.product.id
                                        },
                                        onQuickAdd = { addSingleProduct(prod) },
                                        onOpenGallery = { galleryTargetProduct = prod },
                                        onOpenPreview = { previewTargetProduct = prod },
                                    )
                                    else -> ProductPickerListCard(
                                        product = prod,
                                        addedCount = addedCount,
                                        multiSelectMode = multiSelectMode,
                                        isSelected = isChecked,
                                        onToggleSelect = {
                                            selectedProductIds = if (isChecked) selectedProductIds - prod.product.id else selectedProductIds + prod.product.id
                                        },
                                        onQuickAdd = { addSingleProduct(prod) },
                                        onOpenGallery = { galleryTargetProduct = prod },
                                        onOpenPreview = { previewTargetProduct = prod },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Multi-Image Zoomable Gallery Modal (with "Pick this image for this report only")
    galleryTargetProduct?.let { prod ->
        ProductGalleryPickerDialog(
            product = prod,
            onDismiss = { galleryTargetProduct = null },
            onSelectImageForReport = { chosenImg ->
                galleryTargetProduct = null
                addSingleProduct(prod, imageId = chosenImg.id)
            },
        )
    }

    // Rich Product Preview Modal (Barcode Selector + Image Selector + Full Details)
    previewTargetProduct?.let { prod ->
        ProductPreviewBeforeAddDialog(
            product = prod,
            onDismiss = { previewTargetProduct = null },
            onAddToReport = { chosenBarcode, chosenImageId ->
                previewTargetProduct = null
                addSingleProduct(prod, barcodeOverride = chosenBarcode, imageId = chosenImageId)
            },
        )
    }
}

@Composable
private fun ProductPickerThumbnail(
    product: ProductWithDetails,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(modifier = modifier) {
        ProductEntityImageBox(
            image = product.primaryImage,
            contentDescription = product.product.name,
            preferThumbnail = true,
            contentScale = ContentScale.Crop,
            showDiagnosticsOnError = false,
            modifier = Modifier.fillMaxSize(),
            onClick = onClick,
        )
        if (product.images.size > 1) {
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Icon(Icons.Default.Collections, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                    Text("${product.images.size}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun ProductPickerListCard(
    product: ProductWithDetails,
    addedCount: Int,
    multiSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onQuickAdd: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenPreview: () -> Unit,
) {
    val primaryCode = product.primaryBarcode?.barcodeValue ?: product.product.internalCode
    val extraBarcodeCount = (product.barcodes.size - 1).coerceAtLeast(0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { if (multiSelectMode) onToggleSelect() else onOpenPreview() }
            .testTag("picker_item_${product.product.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(
            width = if (addedCount > 0 || isSelected) 1.5.dp else 1.dp,
            color = when {
                isSelected -> MaterialTheme.colorScheme.primary
                addedCount > 0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                else -> MaterialTheme.colorScheme.outlineVariant
            },
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (multiSelectMode) {
                Checkbox(checked = isSelected, onCheckedChange = { onToggleSelect() })
            }

            // Thumbnail at start (right side in Arabic RTL) directly beside name
            ProductPickerThumbnail(
                product = product,
                modifier = Modifier.size(72.dp),
                onClick = onOpenGallery,
            )

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        product.product.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (addedCount > 0) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                Text(
                                    if (addedCount > 1) "مضاف ($addedCount)" else "مضاف للتقرير",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }

                Text(
                    buildString {
                        if (product.product.internalCode.isNotBlank()) {
                            append("ID: ${product.product.internalCode} • ")
                        }
                        append(primaryCode.ifBlank { "بدون باركود" })
                        if (extraBarcodeCount > 0) append(" (+$extraBarcodeCount إضافي)")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        formatCurrencyValue(product.product.basePrice, product.product.currency),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    if (product.product.categoryName.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Text(
                                product.product.categoryName,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }

            FilledTonalButton(
                onClick = onQuickAdd,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("picker_add_btn_${product.product.id}"),
            ) {
                Icon(Icons.Default.Add, contentDescription = "اختيار وإضافة", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (addedCount > 0) "إضافة+" else "إضافة")
            }
        }
    }
}

@Composable
private fun ProductPickerGridCard(
    product: ProductWithDetails,
    addedCount: Int,
    multiSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onQuickAdd: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenPreview: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { if (multiSelectMode) onToggleSelect() else onOpenPreview() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(
            width = if (addedCount > 0 || isSelected) 1.5.dp else 1.dp,
            color = if (addedCount > 0 || isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box {
                ProductPickerThumbnail(
                    product = product,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1.15f),
                    onClick = onOpenGallery,
                )
                if (multiSelectMode) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        modifier = Modifier.align(Alignment.TopEnd),
                    )
                } else if (addedCount > 0) {
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                    ) {
                        Text("✓ $addedCount", color = Color.White)
                    }
                }
            }

            Text(
                product.product.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                buildString {
                    if (product.product.internalCode.isNotBlank()) {
                        append("${product.product.internalCode} • ")
                    }
                    append(product.primaryBarcode?.barcodeValue ?: "بدون باركود")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    formatCurrencyValue(product.product.basePrice, product.product.currency),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                )
                IconButton(
                    onClick = onQuickAdd,
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = "إضافة", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun ProductPickerCompactRow(
    product: ProductWithDetails,
    addedCount: Int,
    multiSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onQuickAdd: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenPreview: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        tonalElevation = 1.dp,
        border = BorderStroke(1.dp, if (addedCount > 0 || isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth().clickable { if (multiSelectMode) onToggleSelect() else onOpenPreview() },
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (multiSelectMode) {
                Checkbox(checked = isSelected, onCheckedChange = { onToggleSelect() })
            }
            ProductPickerThumbnail(product = product, modifier = Modifier.size(44.dp), onClick = onOpenGallery)
            Column(modifier = Modifier.weight(1f)) {
                Text(product.product.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${product.primaryBarcode?.barcodeValue ?: "-"} • ${formatCurrencyValue(product.product.basePrice, product.product.currency)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            if (addedCount > 0) {
                Icon(Icons.Default.CheckCircle, contentDescription = "مضاف", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onQuickAdd) {
                Icon(Icons.Default.AddCircle, contentDescription = "إضافة", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun ProductPickerDetailedCard(
    product: ProductWithDetails,
    addedCount: Int,
    multiSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onQuickAdd: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenPreview: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { if (multiSelectMode) onToggleSelect() else onOpenPreview() },
        border = BorderStroke(1.dp, if (addedCount > 0 || isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (multiSelectMode) {
                    Checkbox(checked = isSelected, onCheckedChange = { onToggleSelect() })
                }
                ProductPickerThumbnail(product = product, modifier = Modifier.size(88.dp), onClick = onOpenGallery)
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(product.product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "الكود الداخلي: ${product.product.internalCode} • التصنيف: ${product.product.categoryName.ifBlank { "غير مصنف" }}",
                        style = MaterialTheme.typography.labelSmall,
                    )
                    if (product.product.manufacturer.isNotBlank() || product.product.originCountry.isNotBlank()) {
                        Text(
                            "${product.product.manufacturer} ${product.product.originCountry}".trim(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        formatCurrencyValue(product.product.basePrice, product.product.currency),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            if (product.product.description.isNotBlank()) {
                Text(product.product.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                product.barcodes.forEach { b ->
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            if (b.isPrimary) "رئيسي: ${b.barcodeValue}" else b.barcodeValue,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenPreview, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("خيارات ومعاينة")
                }
                Button(onClick = onQuickAdd, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (addedCount > 0) "مضاف ($addedCount) • إضافة" else "إضافة للتقرير")
                }
            }
        }
    }
}

@Composable
private fun ProductGalleryPickerDialog(
    product: ProductWithDetails,
    onDismiss: () -> Unit,
    onSelectImageForReport: (ProductImageEntity) -> Unit,
) {
    val images = remember(product) {
        product.images.sortedWith(compareByDescending<ProductImageEntity> { it.isPrimary }.thenBy { it.sortOrder })
    }
    var activeIndex by remember(images) { mutableIntStateOf(0) }
    var scale by remember(activeIndex) { mutableFloatStateOf(1f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (images.isEmpty()) "لا توجد صور" else "الصورة ${activeIndex + 1} من ${images.size}",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                if (images.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        ProductEntityImageBox(
                            image = null,
                            contentDescription = "بدون صورة",
                            modifier = Modifier.size(160.dp),
                        )
                    }
                } else {
                    val current = images[activeIndex.coerceIn(images.indices)]
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.08f))
                            .pointerInput(activeIndex) {
                                detectTransformGestures { _, _, zoom, _ ->
                                    scale = (scale * zoom).coerceIn(1f, 4f)
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        ProductEntityImageBox(
                            image = current,
                            contentDescription = product.product.name,
                            preferThumbnail = false,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(scaleX = scale, scaleY = scale),
                        )
                        if (current.isPrimary) {
                            Surface(
                                color = MaterialTheme.colorScheme.primary,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                            ) {
                                Text(
                                    "الصورة الأساسية",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التكبير: ${String.format("%.1fx", scale)}", style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = scale,
                            onValueChange = { scale = it },
                            valueRange = 1f..4f,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    if (images.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(images.indices.toList()) { idx ->
                                val img = images[idx]
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .border(
                                            width = if (idx == activeIndex) 2.5.dp else 1.dp,
                                            color = if (idx == activeIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                            shape = RoundedCornerShape(8.dp),
                                        ),
                                ) {
                                    ProductEntityImageBox(
                                        image = img,
                                        contentDescription = "صورة ${idx + 1}",
                                        preferThumbnail = true,
                                        modifier = Modifier.fillMaxSize(),
                                        onClick = { activeIndex = idx },
                                    )
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { onSelectImageForReport(current) },
                        modifier = Modifier.fillMaxWidth().testTag("gallery_pick_for_report_btn"),
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("اختيار هذه الصورة للتقرير فقط وإضافة المنتج")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductPreviewBeforeAddDialog(
    product: ProductWithDetails,
    onDismiss: () -> Unit,
    onAddToReport: (chosenBarcode: String?, chosenImageId: Long?) -> Unit,
) {
    val images = remember(product) {
        product.images.sortedWith(compareByDescending<ProductImageEntity> { it.isPrimary }.thenBy { it.sortOrder })
    }
    var selectedBarcode by remember(product) { mutableStateOf(product.primaryBarcode?.barcodeValue) }
    var selectedImageId by remember(product) { mutableStateOf(images.firstOrNull()?.id) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(product.product.name) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (images.isNotEmpty()) {
                    Text("اختر صورة هذا الصف في التقرير (دون تعديل المنتج الأصلي):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(images, key = { it.id }) { img ->
                            val isChosen = img.id == selectedImageId
                            Box(
                                modifier = Modifier
                                    .size(82.dp)
                                    .border(
                                        width = if (isChosen) 2.5.dp else 1.dp,
                                        color = if (isChosen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                        shape = RoundedCornerShape(10.dp),
                                    ),
                            ) {
                                ProductEntityImageBox(
                                    image = img,
                                    contentDescription = product.product.name,
                                    preferThumbnail = true,
                                    modifier = Modifier.fillMaxSize(),
                                    onClick = { selectedImageId = img.id },
                                )
                            }
                        }
                    }
                }

                HorizontalDivider()
                Text("التفاصيل:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Text("السعر: ${formatCurrencyValue(product.product.basePrice, product.product.currency)}")
                if (product.product.categoryName.isNotBlank()) Text("التصنيف: ${product.product.categoryName}")
                if (product.product.manufacturer.isNotBlank()) Text("المصنع: ${product.product.manufacturer}")
                if (product.product.originCountry.isNotBlank()) Text("المنشأ: ${product.product.originCountry}")
                if (product.product.description.isNotBlank()) Text("الوصف: ${product.product.description}")

                if (product.barcodes.isNotEmpty()) {
                    HorizontalDivider()
                    Text("اختر الباركود المعتمد في التقرير:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    product.barcodes.forEach { b ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBarcode = b.barcodeValue }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = selectedBarcode == b.barcodeValue,
                                onClick = { selectedBarcode = b.barcodeValue },
                            )
                            Column {
                                Text(b.barcodeValue, fontWeight = FontWeight.Bold)
                                Text(
                                    "${b.label} • ${b.barcodeType}" + if (b.isPrimary) " (رئيسي)" else "",
                                    style = MaterialTheme.typography.labelSmall,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAddToReport(selectedBarcode, selectedImageId) },
                modifier = Modifier.testTag("preview_dialog_add_btn"),
            ) {
                Text("إضافة إلى التقرير")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}
