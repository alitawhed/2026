package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.di.AppContainer
import com.example.domain.auth.AuthActionResult
import com.example.domain.auth.AuthConfigurationStatus
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.AuthInputValidator
import com.example.domain.auth.AuthProviderType
import com.example.domain.auth.AuthUserProfile
import com.example.domain.auth.FirebaseAuthGateway
import com.example.domain.auth.GoogleCredentialFetchResult
import com.example.domain.auth.GoogleSignInHelper
import com.example.domain.auth.PasswordValidationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthScreenMode {
    SIGN_IN,
    REGISTER,
    FORGOT_PASSWORD,
}

sealed interface PendingSensitiveOperation {
    data object DeleteAccount : PendingSensitiveOperation
    data class UnlinkProvider(val providerType: AuthProviderType) : PendingSensitiveOperation
    data class LinkEmailPassword(val email: String, val password: String) : PendingSensitiveOperation
    data class LinkGoogleToken(val idToken: String) : PendingSensitiveOperation
}

data class AuthUiState(
    val mode: AuthScreenMode = AuthScreenMode.SIGN_IN,
    val currentUser: AuthUserProfile? = null,
    val configStatus: AuthConfigurationStatus = AuthConfigurationStatus(
        isGoogleServicesConfigured = false,
        isFirebaseInitialized = false,
        googleWebClientIdPresent = false,
        statusMessage = "",
    ),
    val displayName: String = "",
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val currentPasswordForChange: String = "",
    val newPasswordForChange: String = "",
    val confirmNewPasswordForChange: String = "",
    val linkEmailInput: String = "",
    val linkPasswordInput: String = "",
    val linkConfirmPasswordInput: String = "",
    val linkPasswordPolicy: PasswordValidationResult = AuthInputValidator.validatePasswordPolicy(""),
    val passwordPolicy: PasswordValidationResult = AuthInputValidator.validatePasswordPolicy(""),
    val isBusy: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    val requiresRecentLoginOperation: String? = null,
    val pendingSensitiveOperation: PendingSensitiveOperation? = null,
    val collisionEmail: String? = null,
    val collisionExistingProviderHint: String? = null,
    val collisionPendingGoogleIdToken: String? = null,
    val consecutiveFailures: Int = 0,
    val cooldownUntilMs: Long = 0L,
)

class AuthViewModel(
    private val authGateway: AuthGateway,
    private val googleSignInHelper: GoogleSignInHelper = GoogleSignInHelper(),
    private val clockMs: () -> Long = { System.currentTimeMillis() },
) : ViewModel() {

    constructor(container: AppContainer) : this(
        authGateway = container.authGateway,
        googleSignInHelper = container.googleSignInHelper,
    )

    private val _uiState = MutableStateFlow(
        AuthUiState(
            currentUser = authGateway.currentUser(),
            configStatus = authGateway.configurationStatus(),
            linkEmailInput = authGateway.currentUser()?.email.orEmpty(),
        ),
    )
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authGateway.authStateFlow.collect { user ->
                _uiState.update { state ->
                    state.copy(
                        currentUser = user,
                        configStatus = authGateway.configurationStatus(),
                        linkEmailInput = if (state.linkEmailInput.isBlank()) user?.email.orEmpty() else state.linkEmailInput,
                    )
                }
            }
        }
    }

    fun refreshConfigStatus() {
        val current = authGateway.currentUser()
        _uiState.update {
            it.copy(
                currentUser = current,
                configStatus = authGateway.configurationStatus(),
                linkEmailInput = if (it.linkEmailInput.isBlank()) current?.email.orEmpty() else it.linkEmailInput,
            )
        }
    }

    fun setMode(mode: AuthScreenMode) {
        _uiState.update {
            it.copy(
                mode = mode,
                errorMessage = null,
                statusMessage = null,
                requiresRecentLoginOperation = null,
                pendingSensitiveOperation = null,
            )
        }
    }

    fun updateDisplayName(value: String) {
        _uiState.update { it.copy(displayName = value, errorMessage = null) }
    }

    fun updateEmail(value: String) {
        _uiState.update { it.copy(email = value, errorMessage = null) }
    }

    fun updatePassword(value: String) {
        _uiState.update {
            it.copy(
                password = value,
                passwordPolicy = AuthInputValidator.validatePasswordPolicy(value),
                errorMessage = null,
            )
        }
    }

    fun updateConfirmPassword(value: String) {
        _uiState.update { it.copy(confirmPassword = value, errorMessage = null) }
    }

    fun updateChangePasswordInputs(
        currentPassword: String? = null,
        newPassword: String? = null,
        confirmNewPassword: String? = null,
    ) {
        _uiState.update {
            it.copy(
                currentPasswordForChange = currentPassword ?: it.currentPasswordForChange,
                newPasswordForChange = newPassword ?: it.newPasswordForChange,
                confirmNewPasswordForChange = confirmNewPassword ?: it.confirmNewPasswordForChange,
                errorMessage = null,
            )
        }
    }

    fun updateLinkEmailPasswordInputs(
        email: String? = null,
        password: String? = null,
        confirmPassword: String? = null,
    ) {
        _uiState.update {
            val nextPassword = password ?: it.linkPasswordInput
            it.copy(
                linkEmailInput = email ?: it.linkEmailInput,
                linkPasswordInput = nextPassword,
                linkConfirmPasswordInput = confirmPassword ?: it.linkConfirmPasswordInput,
                linkPasswordPolicy = AuthInputValidator.validatePasswordPolicy(nextPassword),
                errorMessage = null,
            )
        }
    }

    fun clearMessages() {
        _uiState.update {
            it.copy(
                errorMessage = null,
                statusMessage = null,
                requiresRecentLoginOperation = null,
                pendingSensitiveOperation = null,
            )
        }
    }

    fun consumeStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun clearCollisionState() {
        _uiState.update {
            it.copy(
                collisionEmail = null,
                collisionExistingProviderHint = null,
                collisionPendingGoogleIdToken = null,
            )
        }
    }

    fun signInWithGoogle(context: Context) {
        val status = authGateway.configurationStatus()
        if (!status.isReadyForGoogleSignIn) {
            _uiState.update {
                it.copy(
                    configStatus = status,
                    errorMessage = status.statusMessage,
                )
            }
            return
        }
        val webClientId = (authGateway as? FirebaseAuthGateway)?.getGoogleWebClientIdOrNull()
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            when (val cred = googleSignInHelper.requestGoogleIdToken(context, webClientId)) {
                is GoogleCredentialFetchResult.IdToken -> {
                    val result = authGateway.signInWithGoogleIdToken(cred.token)
                    applyAuthResult(result)
                }
                is GoogleCredentialFetchResult.Cancelled -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            statusMessage = "تم إلغاء تسجيل الدخول عبر Google.",
                        )
                    }
                }
                is GoogleCredentialFetchResult.NotConfigured -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            errorMessage = "معرّف عميل الويب (default_web_client_id) غير متوفر في إعدادات Firebase.",
                        )
                    }
                }
                is GoogleCredentialFetchResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            errorMessage = cred.arabicMessage,
                        )
                    }
                }
            }
        }
    }

    fun signInWithGoogleIdTokenDirect(idToken: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            applyAuthResult(authGateway.signInWithGoogleIdToken(idToken))
        }
    }

    fun signInWithEmail() {
        val state = _uiState.value
        val now = clockMs()
        if (state.cooldownUntilMs > now) {
            val sec = ((state.cooldownUntilMs - now) / 1000L).coerceAtLeast(1L)
            _uiState.update {
                it.copy(errorMessage = "تم إيقاف المحاولات مؤقتاً لأسباب أمنية. يرجى الانتظار $sec ثانية.")
            }
            return
        }

        val validationError = AuthInputValidator.validateSignInInputs(state.email, state.password)
        if (validationError != null) {
            _uiState.update { it.copy(errorMessage = validationError) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.signInWithEmail(state.email, state.password)
            applyAuthResult(result, trackFailureRate = true)
        }
    }

    fun registerWithEmail() {
        val state = _uiState.value
        val validationError = AuthInputValidator.validateRegistrationInputs(
            displayName = state.displayName,
            email = state.email,
            password = state.password,
            confirmPassword = state.confirmPassword,
        )
        if (validationError != null) {
            _uiState.update { it.copy(errorMessage = validationError) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.registerWithEmail(
                email = state.email,
                password = state.password,
                displayName = state.displayName,
            )
            applyAuthResult(result)
        }
    }

    fun resendVerificationEmail() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            applyAuthResult(authGateway.sendEmailVerification())
        }
    }

    fun refreshEmailVerificationStatus() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            applyAuthResult(authGateway.reloadCurrentUser())
        }
    }

    fun sendPasswordReset() {
        val email = _uiState.value.email
        val err = AuthInputValidator.validateEmail(email)
        if (err != null) {
            _uiState.update { it.copy(errorMessage = err) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            applyAuthResult(authGateway.sendPasswordResetEmail(email))
        }
    }

    fun changePassword() {
        val state = _uiState.value
        val user = state.currentUser ?: return
        if (user.hasEmailPasswordProvider && state.currentPasswordForChange.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "يرجى إدخال كلمة المرور الحالية للتحقق أولاً") }
            return
        }
        val policyErr = AuthInputValidator.validatePasswordPolicy(state.newPasswordForChange).errorMessage
        if (policyErr != null) {
            _uiState.update { it.copy(errorMessage = policyErr) }
            return
        }
        if (state.newPasswordForChange != state.confirmNewPasswordForChange) {
            _uiState.update { it.copy(errorMessage = "كلمة المرور الجديدة وتأكيدها غير متطابقتين") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.updatePassword(
                currentPassword = state.currentPasswordForChange.takeIf { it.isNotEmpty() },
                newPassword = state.newPasswordForChange,
            )
            if (result is AuthActionResult.Success) {
                _uiState.update {
                    it.copy(
                        currentPasswordForChange = "",
                        newPasswordForChange = "",
                        confirmNewPasswordForChange = "",
                    )
                }
            }
            applyAuthResult(result)
        }
    }

    fun linkGoogleAccount(context: Context) {
        val user = _uiState.value.currentUser ?: return
        if (!user.isAccountVerified) {
            _uiState.update {
                it.copy(errorMessage = "يرجى توثيق البريد الإلكتروني أولاً قبل ربط حساب Google لحماية حسابك.")
            }
            return
        }
        if (user.hasGoogleProvider) {
            _uiState.update { it.copy(statusMessage = "حساب Google مرتبط بالفعل بهذا الحساب.") }
            return
        }
        val status = authGateway.configurationStatus()
        if (!status.isReadyForGoogleSignIn) {
            _uiState.update { it.copy(configStatus = status, errorMessage = status.statusMessage) }
            return
        }
        val webClientId = (authGateway as? FirebaseAuthGateway)?.getGoogleWebClientIdOrNull()
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            when (val cred = googleSignInHelper.requestGoogleIdToken(context, webClientId)) {
                is GoogleCredentialFetchResult.IdToken -> {
                    val result = authGateway.linkGoogleIdToken(cred.token)
                    applyAuthResult(
                        result = result,
                        pendingOpOnRecentLogin = PendingSensitiveOperation.LinkGoogleToken(cred.token),
                    )
                }
                is GoogleCredentialFetchResult.Cancelled -> {
                    _uiState.update { it.copy(isBusy = false, statusMessage = "تم إلغاء عملية ربط حساب Google.") }
                }
                is GoogleCredentialFetchResult.NotConfigured -> {
                    _uiState.update { it.copy(isBusy = false, errorMessage = "إعداد Google Sign-In غير مكتمل.") }
                }
                is GoogleCredentialFetchResult.Failure -> {
                    _uiState.update { it.copy(isBusy = false, errorMessage = cred.arabicMessage) }
                }
            }
        }
    }

    fun linkGoogleIdTokenDirect(idToken: String) {
        val user = _uiState.value.currentUser ?: return
        if (!user.isAccountVerified) {
            _uiState.update {
                it.copy(errorMessage = "يرجى توثيق البريد الإلكتروني أولاً قبل ربط حساب Google لحماية حسابك.")
            }
            return
        }
        if (user.hasGoogleProvider) {
            _uiState.update { it.copy(statusMessage = "حساب Google مرتبط بالفعل بهذا الحساب.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.linkGoogleIdToken(idToken)
            applyAuthResult(
                result = result,
                pendingOpOnRecentLogin = PendingSensitiveOperation.LinkGoogleToken(idToken),
            )
        }
    }

    fun linkEmailPassword() {
        val state = _uiState.value
        val user = state.currentUser ?: return
        if (user.hasEmailPasswordProvider) {
            _uiState.update { it.copy(statusMessage = "البريد الإلكتروني وكلمة المرور مرتبطان بالفعل بهذا الحساب.") }
            return
        }
        val targetEmail = AuthInputValidator.normalizeEmail(
            state.linkEmailInput.ifBlank { user.email },
        )
        AuthInputValidator.validateEmail(targetEmail)?.let { err ->
            _uiState.update { it.copy(errorMessage = err) }
            return
        }
        AuthInputValidator.validatePasswordPolicy(state.linkPasswordInput).errorMessage?.let { err ->
            _uiState.update { it.copy(errorMessage = err) }
            return
        }
        if (state.linkPasswordInput != state.linkConfirmPasswordInput) {
            _uiState.update { it.copy(errorMessage = "كلمة المرور وتأكيدها غير متطابقتين") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.linkEmailPassword(targetEmail, state.linkPasswordInput)
            if (result is AuthActionResult.Success) {
                _uiState.update {
                    it.copy(
                        linkPasswordInput = "",
                        linkConfirmPasswordInput = "",
                        linkPasswordPolicy = AuthInputValidator.validatePasswordPolicy(""),
                    )
                }
            }
            applyAuthResult(
                result = result,
                pendingOpOnRecentLogin = PendingSensitiveOperation.LinkEmailPassword(targetEmail, state.linkPasswordInput),
            )
        }
    }

    fun unlinkProvider(providerType: AuthProviderType) {
        val user = _uiState.value.currentUser ?: return
        if (providerType !in user.providers) {
            _uiState.update { it.copy(errorMessage = "${providerType.arabicLabel} غير مرتبط بهذا الحساب.") }
            return
        }
        if (user.providers.size <= 1) {
            _uiState.update {
                it.copy(errorMessage = "لا يمكن فك ربط وسيلة الدخول الوحيدة المرتبطة بالحساب.")
            }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.unlinkProvider(providerType)
            applyAuthResult(
                result = result,
                pendingOpOnRecentLogin = PendingSensitiveOperation.UnlinkProvider(providerType),
            )
        }
    }

    fun resolveCollisionByEmailSignInAndLink(password: String) {
        val state = _uiState.value
        val email = state.collisionEmail?.let { AuthInputValidator.normalizeEmail(it) }.orEmpty()
        val pendingToken = state.collisionPendingGoogleIdToken.orEmpty()
        if (email.isBlank() || pendingToken.isBlank()) {
            _uiState.update {
                it.copy(errorMessage = "بيانات التعارض غير مكتملة؛ يرجى المحاولة مرة أخرى.")
            }
            return
        }
        if (password.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "يرجى إدخال كلمة مرور الحساب المرتبط بالبريد أولاً.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            when (val signInRes = authGateway.signInWithEmail(email, password)) {
                is AuthActionResult.Success -> {
                    val user = signInRes.user
                    if (user != null && user.isAccountVerified) {
                        val linkRes = authGateway.linkGoogleIdToken(pendingToken)
                        clearCollisionState()
                        applyAuthResult(
                            result = linkRes,
                            pendingOpOnRecentLogin = PendingSensitiveOperation.LinkGoogleToken(pendingToken),
                        )
                    } else {
                        clearCollisionState()
                        _uiState.update {
                            it.copy(
                                isBusy = false,
                                currentUser = user,
                                errorMessage = "تم تسجيل الدخول بالبريد لكن يجب توثيق البريد الإلكتروني أولاً قبل ربط حساب Google.",
                            )
                        }
                    }
                }
                is AuthActionResult.RequiresEmailVerification -> {
                    clearCollisionState()
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            currentUser = signInRes.user,
                            statusMessage = "تم تسجيل الدخول لكن البريد غير موثق؛ وثّق البريد أولاً ثم اربط حساب Google من إدارة الحساب.",
                        )
                    }
                }
                else -> {
                    applyAuthResult(signInRes, trackFailureRate = true)
                }
            }
        }
    }

    fun signOut(context: Context? = null) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            if (context != null) {
                googleSignInHelper.clearCredentialState(context)
            }
            val res = authGateway.signOut()
            _uiState.update {
                it.copy(
                    isBusy = false,
                    password = "",
                    confirmPassword = "",
                    currentPasswordForChange = "",
                    newPasswordForChange = "",
                    confirmNewPasswordForChange = "",
                    linkEmailInput = "",
                    linkPasswordInput = "",
                    linkConfirmPasswordInput = "",
                    linkPasswordPolicy = AuthInputValidator.validatePasswordPolicy(""),
                    pendingSensitiveOperation = null,
                    requiresRecentLoginOperation = null,
                )
            }
            clearCollisionState()
            applyAuthResult(res)
        }
    }

    fun deleteAccount() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val result = authGateway.deleteCurrentAccount()
            applyAuthResult(
                result = result,
                pendingOpOnRecentLogin = PendingSensitiveOperation.DeleteAccount,
            )
        }
    }

    fun reauthenticateWithEmail(password: String) {
        val email = _uiState.value.currentUser?.email.orEmpty()
        val pending = _uiState.value.pendingSensitiveOperation
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val res = authGateway.reauthenticateWithEmailPassword(email, password)
            if (res is AuthActionResult.Success) {
                handlePostReauthentication(res, pending)
            } else {
                applyAuthResult(res)
            }
        }
    }

    fun reauthenticateWithGoogle(context: Context) {
        val webClientId = (authGateway as? FirebaseAuthGateway)?.getGoogleWebClientIdOrNull()
        val pending = _uiState.value.pendingSensitiveOperation
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            when (val cred = googleSignInHelper.requestGoogleIdToken(context, webClientId)) {
                is GoogleCredentialFetchResult.IdToken -> {
                    val res = authGateway.reauthenticateWithGoogleIdToken(cred.token)
                    if (res is AuthActionResult.Success) {
                        handlePostReauthentication(res, pending)
                    } else {
                        applyAuthResult(res)
                    }
                }
                is GoogleCredentialFetchResult.Cancelled -> {
                    _uiState.update { it.copy(isBusy = false, statusMessage = "تم إلغاء إعادة المصادقة عبر Google.") }
                }
                is GoogleCredentialFetchResult.NotConfigured -> {
                    _uiState.update { it.copy(isBusy = false, errorMessage = "إعداد Google Sign-In غير مكتمل.") }
                }
                is GoogleCredentialFetchResult.Failure -> {
                    _uiState.update { it.copy(isBusy = false, errorMessage = cred.arabicMessage) }
                }
            }
        }
    }

    fun reauthenticateWithGoogleIdTokenDirect(idToken: String) {
        val pending = _uiState.value.pendingSensitiveOperation
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null, statusMessage = null) }
            val res = authGateway.reauthenticateWithGoogleIdToken(idToken)
            if (res is AuthActionResult.Success) {
                handlePostReauthentication(res, pending)
            } else {
                applyAuthResult(res)
            }
        }
    }

    private suspend fun handlePostReauthentication(
        reauthSuccess: AuthActionResult.Success,
        pending: PendingSensitiveOperation?,
    ) {
        _uiState.update {
            it.copy(
                requiresRecentLoginOperation = null,
                pendingSensitiveOperation = null,
            )
        }
        when (pending) {
            is PendingSensitiveOperation.UnlinkProvider -> {
                applyAuthResult(authGateway.unlinkProvider(pending.providerType))
            }
            is PendingSensitiveOperation.LinkEmailPassword -> {
                val res = authGateway.linkEmailPassword(pending.email, pending.password)
                if (res is AuthActionResult.Success) {
                    _uiState.update {
                        it.copy(
                            linkPasswordInput = "",
                            linkConfirmPasswordInput = "",
                            linkPasswordPolicy = AuthInputValidator.validatePasswordPolicy(""),
                        )
                    }
                }
                applyAuthResult(res)
            }
            is PendingSensitiveOperation.LinkGoogleToken -> {
                applyAuthResult(authGateway.linkGoogleIdToken(pending.idToken))
            }
            is PendingSensitiveOperation.DeleteAccount -> {
                applyAuthResult(
                    AuthActionResult.Success(
                        user = reauthSuccess.user,
                        message = "تم تأكيد هويتك بنجاح. يمكنك الآن تأكيد حذف الحساب لإتمام الحذف النهائي.",
                    ),
                )
            }
            null -> applyAuthResult(reauthSuccess)
        }
    }

    private fun applyAuthResult(
        result: AuthActionResult,
        trackFailureRate: Boolean = false,
        pendingOpOnRecentLogin: PendingSensitiveOperation? = null,
    ) {
        when (result) {
            is AuthActionResult.Success -> {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        currentUser = result.user,
                        statusMessage = result.message.takeIf { m -> m.isNotBlank() },
                        errorMessage = null,
                        consecutiveFailures = 0,
                        cooldownUntilMs = 0L,
                        requiresRecentLoginOperation = null,
                        pendingSensitiveOperation = null,
                    )
                }
            }
            is AuthActionResult.RequiresEmailVerification -> {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        currentUser = result.user,
                        statusMessage = result.message,
                        errorMessage = null,
                        consecutiveFailures = 0,
                    )
                }
            }
            is AuthActionResult.AccountCollision -> {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        errorMessage = result.message,
                        collisionEmail = result.email,
                        collisionExistingProviderHint = result.existingProviderHint,
                        collisionPendingGoogleIdToken = result.pendingGoogleIdToken,
                    )
                }
            }
            is AuthActionResult.RequiresRecentLogin -> {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        requiresRecentLoginOperation = result.operationLabel,
                        pendingSensitiveOperation = pendingOpOnRecentLogin ?: it.pendingSensitiveOperation,
                        errorMessage = result.message,
                    )
                }
            }
            is AuthActionResult.Cancelled -> {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusMessage = "تم إلغاء العملية.",
                    )
                }
            }
            is AuthActionResult.Failure -> {
                _uiState.update { state ->
                    val nextFailures = if (trackFailureRate && !result.isNetworkError) {
                        state.consecutiveFailures + 1
                    } else {
                        state.consecutiveFailures
                    }
                    val nextCooldown = if (nextFailures >= 5) {
                        clockMs() + 30_000L
                    } else {
                        state.cooldownUntilMs
                    }
                    state.copy(
                        isBusy = false,
                        errorMessage = result.userMessageArabic,
                        consecutiveFailures = nextFailures,
                        cooldownUntilMs = nextCooldown,
                    )
                }
            }
        }
    }
}
