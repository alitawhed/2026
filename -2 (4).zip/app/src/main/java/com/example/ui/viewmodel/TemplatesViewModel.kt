package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ReportTemplateEntity
import com.example.di.AppContainer
import com.example.domain.billing.FeatureAccessDecision
import com.example.domain.billing.ProFeature
import com.example.domain.billing.SubscriptionEntitlementState
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TemplatesViewModel(private val container: AppContainer) : ViewModel() {

    val templates: StateFlow<List<ReportTemplateEntity>> = container.templateRepository.allTemplates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val entitlementState: StateFlow<SubscriptionEntitlementState> = container.entitlementManager.entitlementState

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() { _message.value = null }

    fun checkProAccess(feature: ProFeature = ProFeature.PRO_TEMPLATE_CUSTOMIZATION): FeatureAccessDecision =
        container.entitlementManager.checkProFeatureAccess(feature)

    fun createReportFromTemplate(templateId: Long, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = container.reportRepository.createEmptyReport(templateId)
            onCreated(id)
        }
    }

    fun setDefault(templateId: Long) {
        viewModelScope.launch {
            container.templateRepository.setDefaultTemplate(templateId)
            _message.value = "تم تعيين القالب الافتراضي"
        }
    }

    fun duplicateTemplate(template: ReportTemplateEntity) {
        viewModelScope.launch {
            container.templateRepository.duplicateTemplate(template)
            _message.value = "تم نسخ القالب"
        }
    }

    fun saveTemplate(template: ReportTemplateEntity) {
        viewModelScope.launch {
            container.templateRepository.saveTemplate(template)
            _message.value = "تم حفظ القالب"
        }
    }

    fun deleteTemplate(template: ReportTemplateEntity) {
        viewModelScope.launch {
            container.templateRepository.deleteTemplate(template)
            _message.value = "تم حذف القالب"
        }
    }

    fun exportTemplateJson(template: ReportTemplateEntity): String =
        container.templateRepository.exportTemplateJson(template)

    fun importTemplateJson(rawJson: String) {
        viewModelScope.launch {
            container.templateRepository.importTemplateJson(rawJson)
                .onSuccess { _message.value = "تم استيراد القالب بنجاح" }
                .onFailure { err ->
                    container.globalErrorMonitor.recordError(err, ScreenNames.TEMPLATES, DiagnosticModules.REPORTS, "استيراد قالب JSON")
                    _message.value = "صيغة القالب غير صالحة: ${err.message}"
                }
        }
    }
}
