package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ExcelImageConflictPolicy
import com.example.data.local.entity.ImageDownloadStatus
import com.example.data.local.entity.ProductWithDetails
import com.example.data.storage.BackendImageSyncService
import com.example.di.AppContainer
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.excel.ExcelImportConflictException
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ExcelImportFinalReport
import com.example.domain.excel.ExcelNewBarcodePolicy
import com.example.domain.excel.ExcelPreImportReview
import com.example.domain.excel.ExcelRowConflictType
import com.example.domain.excel.ExcelUrlImageStatus
import com.example.domain.excel.ExtractedExcelImage
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ImportPreviewAnalysis
import com.example.domain.excel.OfficialApiImageConfig
import com.example.domain.excel.ParsedSheetData
import com.example.domain.excel.ParsedWorkbookResult
import com.example.domain.excel.ProductImportField
import com.example.domain.excel.UrlImagePreviewProbeResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

enum class ExcelImportStep {
    PICK_FILE,
    MAP_AND_PREVIEW,
    REVIEW_IMAGES,
    IMPORTING,
    SUMMARY_AND_IMAGES,
}

enum class ExcelReviewFilter(val arabicLabel: String) {
    ALL("الكل"),
    CONFLICTS_AND_DUPLICATES("التعارضات والتكرار"),
    WITH_IMAGE_URLS("تحتوي روابط صور"),
    IMAGE_CONFLICTS("تعارض صور موجودة"),
    NEW_BARCODES_EXISTING("باركودات جديدة لموجود"),
    NEW_PRODUCTS("منتجات جديدة"),
    SKIPPED_OR_ERRORS("المتخطاة والأخطاء"),
}

data class ExcelImportUiState(
    val step: ExcelImportStep = ExcelImportStep.PICK_FILE,
    val isLoadingFile: Boolean = false,
    val workbook: ParsedWorkbookResult? = null,
    val selectedSheetIndex: Int = 0,
    val hasHeaderRow: Boolean = true,
    val mappings: Map<Int, ProductImportField> = emptyMap(),
    val duplicatePolicy: ImportDuplicatePolicy = ImportDuplicatePolicy.SKIP,
    val analysis: ImportPreviewAnalysis? = null,
    val reviewDraft: ExcelPreImportReview? = null,
    val reviewFilter: ExcelReviewFilter = ExcelReviewFilter.ALL,
    val progressProcessed: Int = 0,
    val progressTotal: Int = 0,
    val imageDownloadProgressProcessed: Int = 0,
    val imageDownloadProgressTotal: Int = 0,
    val isProbingPreviewUrls: Boolean = false,
    val isRetryingFailedImages: Boolean = false,
    val isProcessingFallback: Boolean = false,
    val lastRetrySummary: String? = null,
    val finalReport: ExcelImportFinalReport? = null,
    val remainingUnlinkedImages: List<ExtractedExcelImage> = emptyList(),
    val allProductsForLinking: List<ProductWithDetails> = emptyList(),
    val backendServiceUrl: String = "",
    val sallaStatus: BackendImageSyncService.SallaBackendStatus? = null,
    val sallaAuthorizeUrl: String? = null,
    val errorMessage: String? = null,
    val statusMessage: String? = null,
) {
    val activeSheet: ParsedSheetData?
        get() = workbook?.sheets?.getOrNull(selectedSheetIndex)
}

class ExcelImportViewModel(private val container: AppContainer) : ViewModel() {

    private val _uiState = MutableStateFlow(ExcelImportUiState())
    val uiState: StateFlow<ExcelImportUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val savedBackendUrl = withContext(Dispatchers.IO) {
                runCatching { container.settingsRepository.getSettingsOnce().backendServiceUrl }.getOrDefault("")
            }
            if (savedBackendUrl.isNotBlank()) {
                _uiState.value = _uiState.value.copy(backendServiceUrl = savedBackendUrl)
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun clearStatusMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }

    fun clearSallaAuthorizeUrl() {
        _uiState.value = _uiState.value.copy(sallaAuthorizeUrl = null)
    }

    fun reset() {
        container.appContext.cacheDir.let { cacheRoot ->
            File(cacheRoot, "url_previews").takeIf { it.exists() }?.deleteRecursively()
        }
        val savedBackend = _uiState.value.backendServiceUrl
        _uiState.value = ExcelImportUiState(backendServiceUrl = savedBackend)
    }

    fun loadExcelUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingFile = true, errorMessage = null)
            val result = container.excelImportEngine.parseUri(uri)
            result.onSuccess { wb ->
                if (wb.sheets.isEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        isLoadingFile = false,
                        errorMessage = "الملف لا يحتوي على أوراق عمل صالحة",
                    )
                } else {
                    val firstSheet = wb.sheets.first()
                    val suggested = container.excelImportEngine.suggestMappings(
                        firstSheet.headers,
                        firstSheet.rows.drop(1).take(30),
                    )
                    val analysis = container.excelImportEngine.analyzeBeforeImport(firstSheet, suggested, true)
                    _uiState.value = _uiState.value.copy(
                        isLoadingFile = false,
                        step = ExcelImportStep.MAP_AND_PREVIEW,
                        workbook = wb,
                        selectedSheetIndex = 0,
                        hasHeaderRow = true,
                        mappings = suggested,
                        analysis = analysis,
                    )
                }
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isLoadingFile = false,
                    errorMessage = "فشل قراءة الملف: ${err.message}",
                )
            }
        }
    }

    fun selectSheet(index: Int) {
        val wb = _uiState.value.workbook ?: return
        val sheet = wb.sheets.getOrNull(index) ?: return
        viewModelScope.launch {
            val sampleSlice = if (_uiState.value.hasHeaderRow) sheet.rows.drop(1).take(30) else sheet.rows.take(30)
            val suggested = container.excelImportEngine.suggestMappings(sheet.headers, sampleSlice)
            val analysis = container.excelImportEngine.analyzeBeforeImport(sheet, suggested, _uiState.value.hasHeaderRow)
            _uiState.value = _uiState.value.copy(
                selectedSheetIndex = index,
                mappings = suggested,
                analysis = analysis,
            )
        }
    }

    fun toggleHasHeaderRow(hasHeader: Boolean) {
        val sheet = _uiState.value.activeSheet ?: return
        viewModelScope.launch {
            val analysis = container.excelImportEngine.analyzeBeforeImport(sheet, _uiState.value.mappings, hasHeader)
            _uiState.value = _uiState.value.copy(hasHeaderRow = hasHeader, analysis = analysis)
        }
    }

    fun updateColumnMapping(colIndex: Int, field: ProductImportField) {
        val sheet = _uiState.value.activeSheet ?: return
        val updated = _uiState.value.mappings.toMutableMap().apply { this[colIndex] = field }
        viewModelScope.launch {
            val analysis = container.excelImportEngine.analyzeBeforeImport(sheet, updated, _uiState.value.hasHeaderRow)
            _uiState.value = _uiState.value.copy(mappings = updated, analysis = analysis)
        }
    }

    fun setDuplicatePolicy(policy: ImportDuplicatePolicy) {
        val draft = _uiState.value.reviewDraft
        _uiState.value = _uiState.value.copy(
            duplicatePolicy = policy,
            reviewDraft = draft?.copy(policy = policy),
        )
    }

    fun setReviewFilter(filter: ExcelReviewFilter) {
        _uiState.value = _uiState.value.copy(reviewFilter = filter)
    }

    fun proceedToImageReview() {
        val state = _uiState.value
        val sheet = state.activeSheet ?: return
        if (state.mappings.values.none { it == ProductImportField.NAME }) {
            _uiState.value = state.copy(errorMessage = "يجب مطابقة عمود اسم المنتج على الأقل قبل المتابعة")
            return
        }
        viewModelScope.launch {
            _uiState.value = state.copy(isLoadingFile = true, errorMessage = null)
            val settings = container.settingsRepository.getSettingsOnce()
            val draft = container.excelImportEngine.buildPreImportReviewDraft(
                sheet = sheet,
                mappings = state.mappings,
                hasHeaderRow = state.hasHeaderRow,
                policy = state.duplicatePolicy,
                defaultCurrency = settings.defaultCurrency,
            )
            val summary = draft.computeSummary()
            val defaultFilter = if (summary.unresolvedBlockingCount > 0) {
                ExcelReviewFilter.CONFLICTS_AND_DUPLICATES
            } else {
                ExcelReviewFilter.ALL
            }
            _uiState.value = _uiState.value.copy(
                isLoadingFile = false,
                step = ExcelImportStep.REVIEW_IMAGES,
                reviewDraft = draft,
                reviewFilter = defaultFilter,
            )
        }
    }

    fun backToMapping() {
        _uiState.value = _uiState.value.copy(step = ExcelImportStep.MAP_AND_PREVIEW, errorMessage = null)
    }

    fun setRowBarcodePolicy(sheetRow: Int, policy: ExcelNewBarcodePolicy) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased == sheetRow) {
                r.copy(
                    newBarcodePolicy = policy,
                    skipRow = policy == ExcelNewBarcodePolicy.SKIP_PRODUCT,
                )
            } else r
        }
        _uiState.value = _uiState.value.copy(
            reviewDraft = draft.copy(rows = updatedRows),
            errorMessage = null,
        )
    }

    fun applyPolicyToNewBarcodeRows(policy: ExcelNewBarcodePolicy) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.conflictType == ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE) {
                r.copy(
                    newBarcodePolicy = policy,
                    skipRow = policy == ExcelNewBarcodePolicy.SKIP_PRODUCT,
                )
            } else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun ignoreAllForeignConflicts() {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.conflictType == ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT) {
                r.copy(newBarcodePolicy = ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE, skipRow = false)
            } else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun skipAllForeignConflicts() {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.conflictType == ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT) {
                r.copy(newBarcodePolicy = ExcelNewBarcodePolicy.SKIP_PRODUCT, skipRow = true)
            } else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun skipSubsequentIntraFileDuplicates() {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.conflictType == ExcelRowConflictType.INTRA_FILE_DUPLICATE) {
                val isSubsequent = r.intraFileDuplicateRows.any { (_, rowNums) ->
                    rowNums.firstOrNull() != r.displayRowNumber
                }
                if (isSubsequent) {
                    r.copy(newBarcodePolicy = ExcelNewBarcodePolicy.SKIP_PRODUCT, skipRow = true)
                } else r
            } else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun setDraftPrimaryImage(sheetRow: Int, imageId: String) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased == sheetRow) r.copy(primaryImageId = imageId) else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows))
    }

    fun moveDraftImageOrder(sheetRow: Int, imageId: String, delta: Int) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased != sheetRow) r
            else {
                val imgs = r.images.toMutableList()
                val idx = imgs.indexOfFirst { it.id == imageId }
                val target = idx + delta
                if (idx >= 0 && target in imgs.indices) {
                    val moved = imgs.removeAt(idx)
                    imgs.add(target, moved)
                    r.copy(images = imgs)
                } else r
            }
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows))
    }

    fun removeImageFromDraftRow(sheetRow: Int, imageId: String, ignoreCompletely: Boolean = false) {
        val draft = _uiState.value.reviewDraft ?: return
        var removedImg: ExtractedExcelImage? = null
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased != sheetRow) r
            else {
                removedImg = r.images.firstOrNull { it.id == imageId }
                val remaining = r.images.filterNot { it.id == imageId }
                val nextPrimary = if (r.primaryImageId == imageId) remaining.firstOrNull()?.id else r.primaryImageId
                r.copy(images = remaining, primaryImageId = nextPrimary)
            }
        }
        val img = removedImg
        val updatedUnlinked = if (!ignoreCompletely && img != null) draft.unlinkedImages + img else draft.unlinkedImages
        val updatedIgnored = if (ignoreCompletely && img != null) draft.ignoredImages + img else draft.ignoredImages
        _uiState.value = _uiState.value.copy(
            reviewDraft = draft.copy(rows = updatedRows, unlinkedImages = updatedUnlinked, ignoredImages = updatedIgnored),
        )
    }

    fun moveImageBetweenDraftRows(imageId: String, fromSheetRow: Int, toSheetRow: Int) {
        if (fromSheetRow == toSheetRow) return
        val draft = _uiState.value.reviewDraft ?: return
        val movedImg = draft.rows.firstOrNull { it.sheetRowZeroBased == fromSheetRow }
            ?.images?.firstOrNull { it.id == imageId } ?: return
        val updatedRows = draft.rows.map { r ->
            when (r.sheetRowZeroBased) {
                fromSheetRow -> {
                    val rem = r.images.filterNot { it.id == imageId }
                    r.copy(
                        images = rem,
                        primaryImageId = if (r.primaryImageId == imageId) rem.firstOrNull()?.id else r.primaryImageId,
                    )
                }
                toSheetRow -> {
                    val added = r.images + movedImg
                    r.copy(
                        images = added,
                        primaryImageId = r.primaryImageId ?: movedImg.id,
                    )
                }
                else -> r
            }
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows))
    }

    fun assignUnlinkedImageToDraftRow(imageId: String, toSheetRow: Int) {
        val draft = _uiState.value.reviewDraft ?: return
        val img = draft.unlinkedImages.firstOrNull { it.id == imageId } ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased == toSheetRow) {
                val added = r.images + img
                r.copy(images = added, primaryImageId = r.primaryImageId ?: img.id)
            } else r
        }
        _uiState.value = _uiState.value.copy(
            reviewDraft = draft.copy(
                rows = updatedRows,
                unlinkedImages = draft.unlinkedImages.filterNot { it.id == imageId },
            ),
        )
    }

    fun ignoreUnlinkedImage(imageId: String) {
        val draft = _uiState.value.reviewDraft ?: return
        val img = draft.unlinkedImages.firstOrNull { it.id == imageId } ?: return
        _uiState.value = _uiState.value.copy(
            reviewDraft = draft.copy(
                unlinkedImages = draft.unlinkedImages.filterNot { it.id == imageId },
                ignoredImages = draft.ignoredImages + img,
            ),
        )
    }

    fun setRowImageConflictPolicy(sheetRow: Int, policy: ExcelImageConflictPolicy) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased == sheetRow) r.copy(imageConflictPolicy = policy) else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun applyImagePolicyToAllExistingConflicts(policy: ExcelImageConflictPolicy) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.matchedExistingProductId != null && r.existingProductHasImage && r.imageUrl.isNotBlank()) {
                r.copy(imageConflictPolicy = policy)
            } else r
        }
        _uiState.value = _uiState.value.copy(
            reviewDraft = draft.copy(rows = updatedRows),
            statusMessage = "تم تطبيق (${policy.arabicLabel}) على جميع المنتجات الموجودة ذات الصور",
            errorMessage = null,
        )
    }

    fun probePreviewImageUrls() {
        val draft = _uiState.value.reviewDraft ?: return
        if (_uiState.value.isProbingPreviewUrls) return
        val distinctUrls = draft.rows
            .filter { !it.skipRow && it.validationError == null && it.imageUrl.isNotBlank() }
            .flatMap { it.imageUrls.ifEmpty { ExcelImportEngine.splitCellImageUrls(it.imageUrl) } }
            .distinct()
        if (distinctUrls.isEmpty()) {
            _uiState.value = _uiState.value.copy(statusMessage = "لا توجد روابط صور صالحة للمعاينة")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProbingPreviewUrls = true, errorMessage = null)
            val resultsMap: Map<String, UrlImagePreviewProbeResult> = coroutineScope {
                val semaphore = Semaphore(4)
                distinctUrls.map { url ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            url to container.excelImportEngine.probeUrlForReview(url)
                        }
                    }
                }.awaitAll().toMap()
            }
            val currentDraft = _uiState.value.reviewDraft ?: draft
            val updatedRows = currentDraft.rows.map { r ->
                val rowUrls = r.imageUrls.ifEmpty { ExcelImportEngine.splitCellImageUrls(r.imageUrl) }
                val rowProbes = rowUrls.mapNotNull { resultsMap[it] }
                if (rowProbes.isNotEmpty()) {
                    val readyProbe = rowProbes.firstOrNull { it.status == ExcelUrlImageStatus.READY }
                    val firstErr = rowProbes.firstOrNull { it.status == ExcelUrlImageStatus.FAILED }?.errorReason
                    r.copy(
                        urlImageStatus = if (readyProbe != null) ExcelUrlImageStatus.READY else ExcelUrlImageStatus.FAILED,
                        urlPreviewThumbnailPath = readyProbe?.previewThumbnailPath,
                        urlPreviewError = firstErr,
                    )
                } else r
            }
            val readyCount = resultsMap.values.count { it.status == ExcelUrlImageStatus.READY }
            val failedCount = resultsMap.values.count { it.status == ExcelUrlImageStatus.FAILED }
            _uiState.value = _uiState.value.copy(
                isProbingPreviewUrls = false,
                reviewDraft = currentDraft.copy(rows = updatedRows),
                statusMessage = "تم فحص الروابط: جاهزة $readyCount • غير صالحة/تعذر الوصول $failedCount",
            )
        }
    }

    fun toggleSkipDraftRow(sheetRow: Int) {
        val draft = _uiState.value.reviewDraft ?: return
        val updatedRows = draft.rows.map { r ->
            if (r.sheetRowZeroBased == sheetRow) {
                val nextSkip = !r.skipRow
                val nextPolicy = if (nextSkip) {
                    ExcelNewBarcodePolicy.SKIP_PRODUCT
                } else if (r.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
                    ExcelNewBarcodePolicy.ADD_AS_ALTERNATIVE
                } else {
                    r.newBarcodePolicy
                }
                r.copy(skipRow = nextSkip, newBarcodePolicy = nextPolicy)
            } else r
        }
        _uiState.value = _uiState.value.copy(reviewDraft = draft.copy(rows = updatedRows), errorMessage = null)
    }

    fun startImport() {
        val state = _uiState.value
        val draft = state.reviewDraft
        if (draft != null && state.step == ExcelImportStep.REVIEW_IMAGES) {
            commitReviewDraft(draft)
            return
        }
        val sheet = state.activeSheet ?: return
        if (state.mappings.values.none { it == ProductImportField.NAME }) {
            _uiState.value = state.copy(errorMessage = "يجب مطابقة عمود اسم المنتج على الأقل قبل الاستيراد")
            return
        }
        viewModelScope.launch {
            val settings = container.settingsRepository.getSettingsOnce()
            val builtDraft = container.excelImportEngine.buildPreImportReviewDraft(
                sheet = sheet,
                mappings = state.mappings,
                hasHeaderRow = state.hasHeaderRow,
                policy = state.duplicatePolicy,
                defaultCurrency = settings.defaultCurrency,
            )
            val builtSummary = builtDraft.computeSummary()
            when {
                builtSummary.unresolvedBlockingCount > 0 -> {
                    _uiState.value = _uiState.value.copy(
                        step = ExcelImportStep.REVIEW_IMAGES,
                        reviewDraft = builtDraft,
                        reviewFilter = ExcelReviewFilter.CONFLICTS_AND_DUPLICATES,
                        errorMessage = "تم رصد تعارضات أو تكرارات باركود تتطلب قرارك قبل التنفيذ.",
                    )
                }
                builtSummary.existingWithImageUrlConflictCount > 0 -> {
                    _uiState.value = _uiState.value.copy(
                        step = ExcelImportStep.REVIEW_IMAGES,
                        reviewDraft = builtDraft,
                        reviewFilter = ExcelReviewFilter.IMAGE_CONFLICTS,
                        statusMessage = "توجد منتجات لديها صور حالية — راجع سياسة الاحتفاظ بالصورة القديمة أو استبدالها قبل التنفيذ.",
                    )
                }
                builtSummary.invalidUrlImagesCount > 0 -> {
                    _uiState.value = _uiState.value.copy(
                        step = ExcelImportStep.REVIEW_IMAGES,
                        reviewDraft = builtDraft,
                        reviewFilter = ExcelReviewFilter.WITH_IMAGE_URLS,
                        statusMessage = "تم رصد روابط صور غير صالحة — راجع الصفوف قبل تنفيذ الاستيراد.",
                    )
                }
                else -> commitReviewDraft(builtDraft)
            }
        }
    }

    fun commitReviewDraft(draft: ExcelPreImportReview) {
        val summary = draft.computeSummary()
        if (summary.unresolvedBlockingCount > 0) {
            _uiState.value = _uiState.value.copy(
                step = ExcelImportStep.REVIEW_IMAGES,
                reviewDraft = draft,
                reviewFilter = ExcelReviewFilter.CONFLICTS_AND_DUPLICATES,
                errorMessage = "يوجد ${summary.unresolvedBlockingCount} تعارض باركود لم يُحل بعد. اختر معالجة التعارض أو التخطي قبل الاعتماد.",
            )
            return
        }
        viewModelScope.launch {
            val urlTotal = draft.rows
                .filter { !it.skipRow && it.validationError == null }
                .sumOf { it.imageUrls.size }
            _uiState.value = _uiState.value.copy(
                step = ExcelImportStep.IMPORTING,
                progressProcessed = 0,
                progressTotal = draft.rows.size,
                imageDownloadProgressProcessed = 0,
                imageDownloadProgressTotal = urlTotal,
                errorMessage = null,
                statusMessage = null,
            )
            try {
                val report = container.excelImportEngine.commitReviewedImport(
                    review = draft,
                    onProgress = { processed, total ->
                        _uiState.value = _uiState.value.copy(progressProcessed = processed, progressTotal = total)
                    },
                    onImageDownloadProgress = { processed, total ->
                        _uiState.value = _uiState.value.copy(
                            imageDownloadProgressProcessed = processed,
                            imageDownloadProgressTotal = total,
                        )
                    },
                )
                val products = withContext(Dispatchers.IO) {
                    container.database.productDao().getAllProductsWithDetailsOnce()
                }
                _uiState.value = _uiState.value.copy(
                    step = ExcelImportStep.SUMMARY_AND_IMAGES,
                    finalReport = report,
                    remainingUnlinkedImages = report.unlinkedImages,
                    allProductsForLinking = products,
                )
            } catch (e: ExcelImportConflictException) {
                _uiState.value = _uiState.value.copy(
                    step = ExcelImportStep.REVIEW_IMAGES,
                    reviewDraft = draft,
                    reviewFilter = ExcelReviewFilter.CONFLICTS_AND_DUPLICATES,
                    errorMessage = e.message,
                )
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "تنفيذ استيراد ملف Excel")
                _uiState.value = _uiState.value.copy(
                    step = ExcelImportStep.REVIEW_IMAGES,
                    reviewDraft = draft,
                    errorMessage = "فشل الاستيراد وتم التراجع التلقائي عن كافة التغييرات حفاظاً على سلامة قاعدة البيانات: ${t.message}",
                )
            }
        }
    }

    private suspend fun refreshReportAfterImageRecovery(
        currentReport: ExcelImportFinalReport,
        fallbackRecords: List<com.example.data.local.entity.ProductImageDownloadEntity> = emptyList(),
        extraLinkedDelta: Int = 0,
    ): Pair<ExcelImportFinalReport, List<ProductWithDetails>> {
        val refreshedRecords = withContext(Dispatchers.IO) {
            if (currentReport.downloadBatchId.isNotBlank()) {
                container.database.productDao().getImageDownloadsByBatchOnce(currentReport.downloadBatchId)
            } else {
                val ids = (currentReport.imageDownloadRecords.map { it.id } + fallbackRecords.map { it.id }).distinct()
                if (ids.isNotEmpty()) container.database.productDao().getImageDownloadsByIdsOnce(ids) else fallbackRecords
            }
        }
        val products = withContext(Dispatchers.IO) {
            container.database.productDao().getAllProductsWithDetailsOnce()
        }
        val newSuccess = refreshedRecords.count { it.status == ImageDownloadStatus.SUCCESS.name }
        val newFailed = refreshedRecords.filter { it.status == ImageDownloadStatus.FAILED.name }
        val newSkipped = refreshedRecords.count { it.status == ImageDownloadStatus.SKIPPED.name }
        val deltaSuccess = (newSuccess - currentReport.imageDownloadSuccessCount).coerceAtLeast(0)
        val totalAdded = deltaSuccess + extraLinkedDelta
        val updatedReport = currentReport.copy(
            autoLinkedImagesCount = currentReport.autoLinkedImagesCount + totalAdded,
            linkedImagesCount = currentReport.linkedImagesCount + totalAdded,
            verifiedDownloadedCount = currentReport.verifiedDownloadedCount + totalAdded,
            totalImageUrlsCount = maxOf(currentReport.totalImageUrlsCount, refreshedRecords.size),
            imageDownloadSuccessCount = newSuccess,
            imageDownloadFailedCount = newFailed.size,
            imageDownloadSkippedCount = newSkipped,
            imageDownloadRecords = refreshedRecords,
            failedImageDownloads = newFailed,
        )
        return updatedReport to products
    }

    fun retryFailedImages(downloadIds: List<Long>? = null) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isRetryingFailedImages || _uiState.value.isProcessingFallback) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRetryingFailedImages = true, errorMessage = null)
            try {
                val retryRes = container.excelImportEngine.retryFailedImageDownloads(
                    downloadIds = downloadIds,
                    batchId = currentReport.downloadBatchId.takeIf { it.isNotBlank() },
                )
                val (updatedReport, products) = refreshReportAfterImageRecovery(currentReport, retryRes.updatedRecords)
                val summaryText = if (retryRes.totalAttempted == 0) {
                    "لا توجد صور فاشلة لإعادة تحميلها"
                } else {
                    "إعادة المحاولة لـ ${retryRes.totalAttempted} صورة: نجح ${retryRes.succeededCount} • فشل ${retryRes.failedCount}"
                }
                _uiState.value = _uiState.value.copy(
                    isRetryingFailedImages = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = summaryText,
                    statusMessage = summaryText,
                )
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.IMAGES, "إعادة تحميل صور Excel الفاشلة")
                _uiState.value = _uiState.value.copy(
                    isRetryingFailedImages = false,
                    errorMessage = "تعذر إعادة تحميل الصور الفاشلة: ${t.message}",
                )
            }
        }
    }

    fun fulfillFailedDownloadManually(downloadId: Long, imageUri: Uri) {
        fulfillFailedDownloadManuallyMultiple(downloadId, listOf(imageUri))
    }

    fun fulfillFailedDownloadManuallyMultiple(downloadId: Long, imageUris: List<Uri>) {
        if (imageUris.isEmpty()) return
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            val res = container.excelImportEngine.fulfillFailedDownloadManuallyMultiple(downloadId, imageUris)
            res.onSuccess { (rec, extraCount) ->
                val (updatedReport, products) = refreshReportAfterImageRecovery(
                    currentReport = currentReport,
                    fallbackRecords = listOf(rec),
                    extraLinkedDelta = extraCount,
                )
                val totalCount = 1 + extraCount
                val msg = if (totalCount > 1) {
                    "تم رفع وربط $totalCount صور يدوياً للمنتج (${rec.productName})"
                } else {
                    "تم رفع وربط الصورة يدوياً للمنتج (${rec.productName})"
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = msg,
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = "تعذر حفظ الصورة اليدوية: ${err.message}",
                )
            }
        }
    }

    fun importFailedImagesFromFolder(folderTreeUri: Uri) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            try {
                val res = container.excelImportEngine.matchAndImportFailedFromFolder(
                    folderTreeUri = folderTreeUri,
                    batchId = currentReport.downloadBatchId.takeIf { it.isNotBlank() },
                )
                val (updatedReport, products) = refreshReportAfterImageRecovery(
                    currentReport = currentReport,
                    fallbackRecords = res.updatedRecords,
                    extraLinkedDelta = res.extraLinkedCount,
                )
                val msg = if (res.scannedFilesCount == 0) {
                    "المجلد المحدد لا يحتوي على ملفات صور مدعومة"
                } else {
                    buildString {
                        append("استيراد المجلد (فحص ${res.scannedFilesCount} ملف): طابق ${res.matchedCount} منتج • رُبطت ${res.succeededCount} صورة")
                        if (res.unmatchedFiles.isNotEmpty()) {
                            append(" • غير مطابقة (بدون GTIN/باركود مطابق): ${res.unmatchedFiles.size}")
                        }
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = msg,
                    errorMessage = res.errors.firstOrNull(),
                )
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.STORAGE, "استيراد صور المنتجات من مجلد محلي")
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = "تعذر استيراد الصور من المجلد المحلي: ${t.message}",
                )
            }
        }
    }

    fun updateAndRetryFailedDownloadUrl(downloadId: Long, newUrl: String) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            val res = container.excelImportEngine.updateAndRetryFailedDownloadUrl(downloadId, newUrl)
            res.onSuccess { rec ->
                val (updatedReport, products) = refreshReportAfterImageRecovery(currentReport, listOf(rec))
                val succeeded = rec.status == ImageDownloadStatus.SUCCESS.name
                val msg = if (succeeded) {
                    "تم تنزيل وربط الصورة بالرابط البديل للمنتج (${rec.productName})"
                } else {
                    "فشل الرابط البديل لـ (${rec.productName}): ${rec.failureReason}"
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = if (succeeded) msg else null,
                    errorMessage = if (succeeded) null else msg,
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = err.message ?: "الرابط البديل غير صالح",
                )
            }
        }
    }

    fun retryFailedUsingAuthorizedApi(
        endpointOrTemplate: String,
        authHeaderName: String,
        authHeaderValue: String,
    ) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            try {
                val res = container.excelImportEngine.retryFailedUsingAuthorizedApi(
                    config = OfficialApiImageConfig(
                        endpointOrTemplate = endpointOrTemplate,
                        authHeaderName = authHeaderName,
                        authHeaderValue = authHeaderValue,
                    ),
                    batchId = currentReport.downloadBatchId.takeIf { it.isNotBlank() },
                )
                val (updatedReport, products) = refreshReportAfterImageRecovery(currentReport, res.updatedRecords)
                val msg = if (res.totalAttempted == 0) {
                    "لم تطابق واجهة API أياً من المنتجات الفاشلة"
                } else {
                    "API الرسمي: نجح ${res.succeededCount} من ${res.totalAttempted} • متبقي فاشل ${updatedReport.imageDownloadFailedCount}"
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = msg,
                )
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.IMAGES, "استيراد صور عبر API الرسمي")
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = t.message ?: "تعذر الاستيراد عبر واجهة API الرسمية",
                )
            }
        }
    }

    private suspend fun persistBackendUrlSetting(cleanUrl: String) {
        withContext(Dispatchers.IO) {
            val current = container.settingsRepository.getSettingsOnce()
            if (current.backendServiceUrl != cleanUrl) {
                container.settingsRepository.saveSettings(current.copy(backendServiceUrl = cleanUrl))
            }
        }
        _uiState.value = _uiState.value.copy(backendServiceUrl = cleanUrl)
    }

    fun saveAndRetryViaBackendService(backendUrl: String, accessToken: String) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        val cleanUrl = backendUrl.trim().trimEnd('/')
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            try {
                persistBackendUrlSetting(cleanUrl)
                val res = container.excelImportEngine.retryFailedViaBackendService(
                    config = BackendImageSyncService.BackendServerConfig(
                        backendBaseUrl = cleanUrl,
                        backendAccessToken = accessToken.trim(),
                    ),
                    batchId = currentReport.downloadBatchId.takeIf { it.isNotBlank() },
                )
                val (updatedReport, products) = refreshReportAfterImageRecovery(currentReport, res.updatedRecords)
                val msg = if (res.totalAttempted == 0) {
                    "لا توجد صور فاشلة لإرسالها إلى الخدمة الخلفية"
                } else {
                    "الخدمة الخلفية: تم التحقق وحفظ ${res.succeededCount} من ${res.totalAttempted} • متبقي فاشل ${updatedReport.imageDownloadFailedCount}"
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = msg,
                )
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.IMAGES, "جلب الصور عبر الخدمة الخلفية")
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = t.message ?: "تعذر جلب الصور عبر الخدمة الخلفية",
                )
            }
        }
    }

    fun checkSallaBackendStatus(backendUrl: String, accessToken: String) {
        val cleanUrl = backendUrl.trim().trimEnd('/')
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            runCatching { persistBackendUrlSetting(cleanUrl) }
            val res = container.backendImageSyncService.getSallaConfigStatus(
                BackendImageSyncService.BackendServerConfig(cleanUrl, accessToken.trim()),
            )
            res.onSuccess { st ->
                val msg = if (st.connected) {
                    "متجر سلة مربوط على الخادم الخلفي"
                } else if (st.configured) {
                    "بيانات OAuth جاهزة على الخادم وبانتظار تفويض التاجر"
                } else {
                    "إعدادات SALLA_CLIENT_ID / SALLA_CLIENT_SECRET غير مهيأة على الخادم الخلفي بعد"
                }
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    sallaStatus = st,
                    statusMessage = msg,
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = err.message ?: "تعذر فحص حالة الربط مع الخادم الخلفي",
                )
            }
        }
    }

    fun requestSallaOAuthUrl(backendUrl: String, accessToken: String) {
        val cleanUrl = backendUrl.trim().trimEnd('/')
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            runCatching { persistBackendUrlSetting(cleanUrl) }
            val res = container.backendImageSyncService.getSallaAuthorizeUrl(
                BackendImageSyncService.BackendServerConfig(cleanUrl, accessToken.trim()),
            )
            res.onSuccess { authUrl ->
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    sallaAuthorizeUrl = authUrl,
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = err.message ?: "تعذر إنشاء رابط تفويض سلة OAuth",
                )
            }
        }
    }

    fun syncSallaCatalogViaBackend(
        backendUrl: String,
        accessToken: String,
        createMissingProducts: Boolean = false,
    ) {
        val currentReport = _uiState.value.finalReport ?: return
        if (_uiState.value.isProcessingFallback || _uiState.value.isRetryingFailedImages) return
        val cleanUrl = backendUrl.trim().trimEnd('/')
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessingFallback = true, errorMessage = null)
            try {
                persistBackendUrlSetting(cleanUrl)
                val syncRes = container.excelImportEngine.syncSallaCatalogViaBackend(
                    config = BackendImageSyncService.BackendServerConfig(cleanUrl, accessToken.trim()),
                    batchId = currentReport.downloadBatchId.takeIf { it.isNotBlank() },
                    createMissingProducts = createMissingProducts,
                )
                val (updatedReport, products) = refreshReportAfterImageRecovery(
                    currentReport = currentReport,
                    fallbackRecords = emptyList(),
                    extraLinkedDelta = syncRes.linkedImagesCount,
                )
                val msg = "مزامنة سلة الرسمية: جُلب ${syncRes.fetchedProductsCount} منتج • طابق ${syncRes.matchedProductsCount} • حُفظ ${syncRes.linkedImagesCount} صورة"
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    finalReport = updatedReport,
                    allProductsForLinking = products,
                    lastRetrySummary = msg,
                    statusMessage = msg,
                    errorMessage = syncRes.errors.firstOrNull(),
                )
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isProcessingFallback = false,
                    errorMessage = t.message ?: "تعذر مزامنة صور متجر سلة عبر الخادم الخلفي",
                )
            }
        }
    }

    fun exportErrorReportToExcel(onReady: (File) -> Unit) {
        val report = _uiState.value.finalReport ?: return
        viewModelScope.launch {
            try {
                val outFile = withContext(Dispatchers.IO) {
                    container.excelExportEngine.exportImageImportErrorsToXlsx(
                        downloads = report.imageDownloadRecords,
                        importIssues = report.issues,
                    )
                }
                _uiState.value = _uiState.value.copy(statusMessage = "تم إنشاء تقرير الأخطاء (${outFile.name})")
                onReady(outFile)
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "تصدير تقرير أخطاء استيراد Excel")
                _uiState.value = _uiState.value.copy(errorMessage = "تعذر تصدير تقرير الأخطاء: ${t.message}")
            }
        }
    }

    fun linkUnlinkedImageToProduct(image: ExtractedExcelImage, productId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val stored = container.mediaStorage.saveProductImageBytesWithOriginal(image.bytes)
            if (stored != null) {
                container.productRepository.addStoredImageTripletToProduct(
                    productId = productId,
                    storedPath = stored.activePath,
                    originalPath = stored.originalPath,
                    thumbnailPath = stored.thumbnailPath,
                    makePrimary = false,
                )
                val remaining = _uiState.value.remainingUnlinkedImages.filterNot { it.id == image.id }
                _uiState.value = _uiState.value.copy(remainingUnlinkedImages = remaining)
            }
        }
    }
}
