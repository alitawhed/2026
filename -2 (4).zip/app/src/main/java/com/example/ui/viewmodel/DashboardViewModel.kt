package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.DashboardStats
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportWithDetails
import com.example.di.AppContainer
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.ProductsNumericConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class DashboardUiState(
    val stats: DashboardStats = DashboardStats(),
    val recentProducts: List<ProductWithDetails> = emptyList(),
    val recentReports: List<ReportWithDetails> = emptyList(),
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val productsNumericConfig: ProductsNumericConfig = ProductsNumericConfig(),
)

private data class ReportCountsTuple(
    val totalReports: Int,
    val savedReports: Int,
    val archivedReports: Int,
    val todaysReports: Int,
)

class DashboardViewModel(private val container: AppContainer) : ViewModel() {

    private val usedStorageBytesFlow = MutableStateFlow(0L)

    init {
        refreshStorageUsage()
    }

    fun refreshStorageUsage() {
        viewModelScope.launch {
            val trace = container.operationLogger.startOperation(
                screenName = ScreenNames.DASHBOARD,
                moduleName = DiagnosticModules.STORAGE,
                operationName = "حساب المساحة المستخدمة في لوحة التحكم",
                initialStage = "فحص مجلدات الوسائط والتقارير",
            )
            try {
                val bytes = withContext(Dispatchers.IO) {
                    container.mediaStorage.calculateUsedStorageBytes()
                }
                usedStorageBytesFlow.value = bytes
                trace.succeed("المساحة المستخدمة=${bytes} بايت")
            } catch (c: CancellationException) {
                trace.cancel("تم إلغاء حساب المساحة")
                throw c
            } catch (t: Throwable) {
                val err = container.globalErrorMonitor.recordError(
                    throwable = t,
                    screenName = ScreenNames.DASHBOARD,
                    moduleName = DiagnosticModules.STORAGE,
                    operationName = "حساب المساحة المستخدمة",
                    linkedOperationId = trace.operationId,
                )
                trace.fail(t.message ?: "تعذر حساب المساحة", linkedErrorId = err.errorId)
            }
        }
    }

    private val reportCountsFlow = combine(
        container.reportRepository.totalReportCount,
        container.reportRepository.savedReportCount,
        container.reportRepository.archivedReportCount,
        container.reportRepository.observeTodaysReportCount(),
    ) { total, saved, archived, today ->
        ReportCountsTuple(total, saved, archived, today)
    }

    private val combinedStatsFlow = combine(
        container.productRepository.observeDashboardProductMetrics(),
        reportCountsFlow,
        container.database.backupDao().observeLatestBackup(),
        usedStorageBytesFlow,
    ) { prodMetrics: DashboardStats,
        repCounts: ReportCountsTuple,
        latestBackup: BackupHistoryEntity?,
        storageBytes: Long ->
        prodMetrics.copy(
            totalReports = repCounts.totalReports,
            savedReports = repCounts.savedReports,
            archivedReports = repCounts.archivedReports,
            todaysReports = repCounts.todaysReports,
            lastBackupTimestamp = latestBackup?.createdAt,
            lastBackupStatus = latestBackup?.status.orEmpty(),
            usedStorageBytes = storageBytes,
        )
    }

    val uiState: StateFlow<DashboardUiState> = combine(
        combinedStatsFlow,
        container.productRepository.recentProducts,
        container.reportRepository.recentReports,
        container.settingsRepository.settingsFlow,
        container.settingsRepository.productsNumericConfigFlow,
    ) { stats, recentProds, recentReps, settings, prodNumCfg ->
        DashboardUiState(
            stats = stats,
            recentProducts = recentProds,
            recentReports = recentReps,
            settings = settings,
            productsNumericConfig = prodNumCfg,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState(),
    )
}
