package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.billing.BillingGateway
import com.example.domain.model.DeveloperIdentity
import com.example.ui.components.AppScreenTopBar
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusWarning

@Composable
fun PrivacyAndDeletionScreen(
    billingGateway: BillingGateway,
    onBack: () -> Unit,
    onOpenAccountManagement: () -> Unit,
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Top + WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal,
        ),
        topBar = {
            AppScreenTopBar(
                title = "الخصوصية وحذف الحساب",
                subtitle = "التزامات Google Play وبيانات المستخدم",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .testTag("privacy_screen_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    PolicySectionCard(
                        icon = Icons.Default.PrivacyTip,
                        title = "1. نطاق البيانات ومعالجتها",
                        body = "يعتمد تطبيق «مدير التقارير» على حفظ بيانات المنتجات والتقارير والصور والجرد محلياً على جهازك داخل قواعد بيانات معزولة لكل حساب (Room SQLite + MediaStorageManager).\n" +
                            "• لا يرفع التطبيق منتجاتك أو تقاريرك أو صورك إلى Firestore أو أي خادم مزامنة سحابي.\n" +
                            "• تُستخدم خدمة Firebase Authentication فقط لإدارة تسجيل الدخول عبر Google أو البريد الإلكتروني (الاسم، البريد الإلكتروني، ومعرّف UID فقط).\n" +
                            "• تُعالج المدفوعات والاشتراكات حصرياً عبر متجر Google Play (Play Billing) دون تخزين بيانات بطاقات الدفع داخل التطبيق.",
                        testTag = "privacy_data_scope_card",
                    )
                }

                item {
                    PolicySectionCard(
                        icon = Icons.Default.Storage,
                        title = "2. عزل مساحات العمل والبيانات السابقة",
                        body = "• البيانات الموجودة على الجهاز قبل تسجيل الدخول تبقى في مساحة العمل المحلية (report_manager_db) دون نقل أو دمج تلقائي.\n" +
                            "• لكل حساب مستخدم مساحة عمل معزولة بقاعدة بيانات ومجلد ملفات مستقلين.\n" +
                            "• النسخ الاحتياطي والاستعادة بصيغة ZIP (v6) تظل متاحة ومملوكة لك دائماً، وتظل جميع بياناتك السابقة قابلة للقراءة حتى بعد انتهاء الاشتراك.",
                        testTag = "privacy_workspace_card",
                    )
                }

                item {
                    PolicySectionCard(
                        icon = Icons.Default.DeleteForever,
                        title = "3. سياسة حذف الحساب والفصل عن البيانات المحلية والاشتراك",
                        body = "عند اختيار «حذف الحساب نهائياً» من شاشة إدارة الحساب (قد يتطلب إعادة المصادقة حديثاً وفق سياسة Firebase Auth):\n" +
                            "• يُحذف حساب الدخول وبيانات المصادقة من Firebase Authentication فقط.\n" +
                            "• لا تُحذف بياناتك المحلية أو ملفات النسخ الاحتياطي (ZIP) تلقائياً حمايةً لعملك من الفقد غير المقصود.\n" +
                            "• تنبيه مهم: حذف حساب Firebase لا يُلغي اشتراك Google Play تلقائياً؛ يجب إلغاء التجديد التلقائي من مركز اشتراكات Google Play قبل إزالة الحساب.",
                        testTag = "privacy_deletion_policy_card",
                    )
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.10f)),
                        border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("privacy_manual_setup_urls_card"),
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(Icons.Default.WarningAmber, contentDescription = null, tint = StatusWarning)
                                Text(
                                    text = "متطلبات النشر على Google Play Console (Manual Setup)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Text(
                                text = "لإتمام النشر على Google Play Store، يجب نشر صفحة الويب العامة لسياسة الخصوصية وصفحة الويب الخاصة بطلب حذف الحساب خارج التطبيق وإدخال رابطيهما في Google Play Console (App content -> Privacy policy / Data safety). لا يستخدم التطبيق أي روابط وهمية.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("privacy_actions_card"),
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(
                                text = "إجراءات سريعة والتواصل",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(Icons.Default.Email, contentDescription = null, tint = StatusInfo, modifier = Modifier.size(18.dp))
                                Text(
                                    text = "بريد الخصوصية والدعم: ${DeveloperIdentity.DEVELOPER_EMAIL}",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            Button(
                                onClick = onOpenAccountManagement,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("privacy_open_account_mgmt_btn"),
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("الانتقال إلى إدارة الحساب وحذفه")
                            }
                            OutlinedButton(
                                onClick = { billingGateway.openPlaySubscriptionsCenter(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("privacy_open_play_subscriptions_btn"),
                            ) {
                                Icon(Icons.Default.ManageAccounts, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("فتح اشتراكات Google Play للإلغاء")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PolicySectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    testTag: String,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
