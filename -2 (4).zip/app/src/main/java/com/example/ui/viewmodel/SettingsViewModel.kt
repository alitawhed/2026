package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.AppSettingsEntity
import com.example.di.AppContainer
import com.example.domain.auth.AuthConfigurationStatus
import com.example.domain.auth.AuthUserProfile
import com.example.domain.barcode.BarcodeLegacyAuditReport
import com.example.domain.barcode.BarcodeRepairResult
import com.example.domain.billing.BillingConnectionState
import com.example.domain.billing.PlayBillingConfiguration
import com.example.domain.billing.SubscriptionEntitlementState
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.DiagnosticSummaryStats
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.BarcodeFormatType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    val diagnosticStats: StateFlow<DiagnosticSummaryStats> = container.globalErrorMonitor.stats
    val barcodeService = container.barcodeService
    val defaultBarcodeType: StateFlow<BarcodeFormatType> = container.barcodeService.defaultBarcodeTypeFlow

    val currentUser: StateFlow<AuthUserProfile?> = container.authGateway.authStateFlow
    val authConfigStatus: AuthConfigurationStatus
        get() = container.authGateway.configurationStatus()
    val billingConnectionState: StateFlow<BillingConnectionState> = container.billingGateway.connectionState
    val billingConfig: StateFlow<PlayBillingConfiguration> = container.billingGateway.billingConfiguration
    val entitlementState: StateFlow<SubscriptionEntitlementState> = container.billingGateway.entitlementState
    val workspaceLabel: String
        get() = container.workspaceIdentity.displayLabel

    val settings: StateFlow<AppSettingsEntity> = container.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsEntity())

    val productsNumericConfig: StateFlow<ProductsNumericConfig> =
        container.settingsRepository.productsNumericConfigFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProductsNumericConfig())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _barcodeAuditReport = MutableStateFlow<BarcodeLegacyAuditReport?>(null)
    val barcodeAuditReport: StateFlow<BarcodeLegacyAuditReport?> = _barcodeAuditReport.asStateFlow()

    private val _barcodeRepairResult = MutableStateFlow<BarcodeRepairResult?>(null)
    val barcodeRepairResult: StateFlow<BarcodeRepairResult?> = _barcodeRepairResult.asStateFlow()

    private val _isAuditingOrRepairingBarcodes = MutableStateFlow(false)
    val isAuditingOrRepairingBarcodes: StateFlow<Boolean> = _isAuditingOrRepairingBarcodes.asStateFlow()

    private val _barcodeRepairProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val barcodeRepairProgress: StateFlow<Pair<Int, Int>?> = _barcodeRepairProgress.asStateFlow()

    private val errorHandler = container.globalErrorMonitor.coroutineExceptionHandler(
        screenName = ScreenNames.SETTINGS,
        moduleName = DiagnosticModules.SETTINGS,
        operationName = "عملية في الإعدادات العامة",
    ) { err ->
        _isAuditingOrRepairingBarcodes.value = false
        _message.value = "تعذر تنفيذ العملية: ${err.message}"
    }

    fun clearMessage() { _message.value = null }
    fun clearBarcodeRepairResult() { _barcodeRepairResult.value = null }

    fun savePlayBillingConfiguration(updatedConfig: PlayBillingConfiguration) {
        viewModelScope.launch(errorHandler) {
            container.billingGateway.updateBillingConfiguration(updatedConfig)
            _message.value = if (updatedConfig.isConfigured) {
                "تم حفظ معرفات منتجات Google Play Console وجاري تحديث الباقات."
            } else {
                "تم مسح معرفات منتجات Google Play (بانتظار الإعداد)."
            }
        }
    }

    fun refreshBillingStatus() {
        viewModelScope.launch(errorHandler) {
            container.billingGateway.refreshProductsAndPurchases()
            _message.value = "تم تحديث حالة الاتصال والاشتراك مع Google Play."
        }
    }

    fun updateSettings(updated: AppSettingsEntity) {
        viewModelScope.launch(errorHandler) {
            container.settingsRepository.saveSettings(updated)
            _message.value = "تم حفظ الإعدادات"
        }
    }

    fun updateDefaultBarcodeType(format: BarcodeFormatType) {
        viewModelScope.launch(errorHandler) {
            container.barcodeService.updateDefaultBarcodeFormat(format)
                .onSuccess {
                    _message.value = "تم حفظ ${format.arabicLabel} كنوع باركود افتراضي لجميع الباركودات الداخلية الجديدة"
                }
                .onFailure { err ->
                    _message.value = "تعذر حفظ نوع الباركود الافتراضي: ${err.message}"
                }
        }
    }

    fun runBarcodeLegacyAudit() {
        if (_isAuditingOrRepairingBarcodes.value) return
        viewModelScope.launch(errorHandler) {
            _isAuditingOrRepairingBarcodes.value = true
            val report = container.barcodeService.auditLegacyBarcodes()
            _barcodeAuditReport.value = report
            _isAuditingOrRepairingBarcodes.value = false
        }
    }

    fun repairLegacyBarcodes(convertIncompatibleWithApproval: Boolean) {
        if (_isAuditingOrRepairingBarcodes.value) return
        viewModelScope.launch(errorHandler) {
            _isAuditingOrRepairingBarcodes.value = true
            _barcodeRepairProgress.value = 0 to 1
            val result = container.barcodeService.repairLegacyProductBarcodes(
                convertIncompatibleFormatWithUserApproval = convertIncompatibleWithApproval,
                chunkSize = 50,
            ) { processed, total ->
                _barcodeRepairProgress.value = processed to total
            }
            _barcodeRepairResult.value = result
            _barcodeAuditReport.value = container.barcodeService.auditLegacyBarcodes()
            _barcodeRepairProgress.value = null
            _isAuditingOrRepairingBarcodes.value = false
            _message.value = buildString {
                append("تم فحص ${result.inspectedBarcodes} باركود")
                if (result.generatedImagesCount > 0) append(" • توليد ${result.generatedImagesCount} صورة")
                if (result.fixedUnspecifiedFormatsCount > 0) append(" • تحديد نوع ${result.fixedUnspecifiedFormatsCount}")
                if (result.syncedInventorySnapshotsCount > 0) append(" • مزامنة ${result.syncedInventorySnapshotsCount} بند جرد")
            }
        }
    }

    fun updateProductsNumericConfig(config: ProductsNumericConfig) {
        viewModelScope.launch(errorHandler) {
            container.settingsRepository.saveProductsNumericConfig(config)
            _message.value = "تم حفظ إعدادات المنازل العشرية للمنتجات"
        }
    }

    fun resetProductsNumericConfig() {
        viewModelScope.launch(errorHandler) {
            container.settingsRepository.resetProductsNumericConfig()
            _message.value = "تمت استعادة المنازل العشرية الافتراضية للمنتجات"
        }
    }

    fun updateCompanyLogo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO + errorHandler) {
            val path = container.mediaStorage.saveBrandingImageFromUri(uri, "company_logo")
            if (path != null) {
                val current = container.settingsRepository.getSettingsOnce()
                container.settingsRepository.saveSettings(current.copy(companyLogoPath = path))
                withContext(Dispatchers.Main) {
                    _message.value = "تم تحديث شعار الشركة"
                }
            }
        }
    }
}
