package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TemplateDefaults
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportTemplateEntity
import com.example.data.local.entity.ReportWithDetails
import com.example.data.repository.AddProductToReportResult
import com.example.data.storage.ImageEditParameters
import com.example.di.AppContainer
import com.example.domain.barcode.BarcodeChangeResult
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.withNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.layout.ColumnLayoutEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.BarcodeStyleConfig
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnLayoutResult
import com.example.domain.model.ColumnType
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.OverflowSuggestionType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PageSpec
import com.example.domain.model.PaperSizeType
import com.example.domain.model.ReportHeaderFooterConfig
import com.example.domain.model.ReportImageSourceType
import com.example.domain.model.ReportRowSortMode
import com.example.domain.model.SaveStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import java.io.File

data class ReportEditorUiState(
    val reportDetails: ReportWithDetails? = null,
    val columns: List<ColumnConfigModel> = emptyList(),
    val pageSpec: PageSpec = PageSpec(),
    val distributionMode: ColumnDistributionMode = ColumnDistributionMode.AUTO_FIT,
    val layoutResult: ColumnLayoutResult = ColumnLayoutEngine.calculateLayout(PageSpec(), emptyList(), ColumnDistributionMode.AUTO_FIT),
    val headerFooter: ReportHeaderFooterConfig = ReportHeaderFooterConfig(),
    val barcodeStyle: BarcodeStyleConfig = BarcodeStyleConfig(),
    val allProducts: List<ProductWithDetails> = emptyList(),
    val allTemplates: List<ReportTemplateEntity> = emptyList(),
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val saveStatus: SaveStatus = SaveStatus.IDLE,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val canUndoRowOrder: Boolean = false,
    val canRedoRowOrder: Boolean = false,
    val rowSortMode: ReportRowSortMode = ReportRowSortMode.MANUAL,
)

class ReportEditorViewModel(
    private val reportId: Long,
    private val container: AppContainer,
) : ViewModel() {

    private val undoStack = ArrayDeque<List<ColumnConfigModel>>()
    private val redoStack = ArrayDeque<List<ColumnConfigModel>>()
    private val rowOrderUndoStack = ArrayDeque<List<Long>>()
    private val rowOrderRedoStack = ArrayDeque<List<Long>>()
    private val _undoRedoTick = MutableStateFlow(0)

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isGeneratingPdf = MutableStateFlow(false)
    val isGeneratingPdf: StateFlow<Boolean> = _isGeneratingPdf.asStateFlow()

    val mediaStorage = container.mediaStorage
    val barcodeService = container.barcodeService
    val defaultBarcodeType: StateFlow<BarcodeFormatType> = container.barcodeService.defaultBarcodeTypeFlow

    val uiState: StateFlow<ReportEditorUiState> = combine(
        container.reportRepository.observeReport(reportId),
        container.productRepository.allProducts,
        container.templateRepository.allTemplates,
        container.settingsRepository.settingsFlow,
        container.reportRepository.saveStatus,
        _undoRedoTick,
    ) { arr ->
        val report = arr[0] as ReportWithDetails?
        @Suppress("UNCHECKED_CAST")
        val products = arr[1] as List<ProductWithDetails>
        @Suppress("UNCHECKED_CAST")
        val templates = arr[2] as List<ReportTemplateEntity>
        val settings = arr[3] as AppSettingsEntity
        val saveStatus = arr[4] as SaveStatus

        if (report == null) {
            ReportEditorUiState(
                allProducts = products,
                allTemplates = templates,
                settings = settings,
                saveStatus = saveStatus,
            )
        } else {
            val cols = report.sortedColumns.map { it.toDomainModel() }
            val pageSpec = PageSpec(
                paperSize = PaperSizeType.fromString(report.report.paperSize),
                customWidthMm = report.report.customWidthMm,
                customHeightMm = report.report.customHeightMm,
                orientation = PageOrientation.fromString(report.report.orientation),
                marginTopMm = report.report.marginTopMm,
                marginBottomMm = report.report.marginBottomMm,
                marginStartMm = report.report.marginStartMm,
                marginEndMm = report.report.marginEndMm,
            )
            val distMode = ColumnDistributionMode.fromString(report.report.columnDistributionMode)
            val layout = ColumnLayoutEngine.calculateLayout(
                pageSpec = pageSpec,
                allColumns = cols,
                distributionMode = distMode,
                splitHorizontalGroups = report.report.splitHorizontalGroups,
            )
            ReportEditorUiState(
                reportDetails = report,
                columns = cols,
                pageSpec = pageSpec,
                distributionMode = distMode,
                layoutResult = layout,
                headerFooter = TemplateDefaults.decodeHeaderFooter(report.report.headerFooterConfigJson),
                barcodeStyle = TemplateDefaults.decodeBarcodeStyle(report.report.barcodeStyleConfigJson),
                allProducts = products,
                allTemplates = templates,
                settings = settings,
                saveStatus = saveStatus,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                canUndoRowOrder = rowOrderUndoStack.isNotEmpty(),
                canRedoRowOrder = rowOrderRedoStack.isNotEmpty(),
                rowSortMode = ReportRowSortMode.fromString(report.report.rowSortMode),
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ReportEditorUiState(),
    )

    val entitlementState = container.entitlementManager.entitlementState

    fun checkProFeature(feature: com.example.domain.billing.ProFeature): com.example.domain.billing.FeatureAccessDecision =
        container.entitlementManager.checkProFeatureAccess(feature)

    fun clearMessage() { _statusMessage.value = null }

    fun updateReportMeta(transform: (ReportEntity) -> ReportEntity) {
        val current = uiState.value.reportDetails?.report ?: return
        viewModelScope.launch {
            container.reportRepository.updateReport(transform(current))
        }
    }

    fun updateHeaderFooter(config: ReportHeaderFooterConfig) {
        val json = TemplateDefaults.json.encodeToString(config)
        updateReportMeta { it.copy(headerFooterConfigJson = json) }
    }

    fun updateBarcodeStyle(style: BarcodeStyleConfig) {
        val json = TemplateDefaults.json.encodeToString(style)
        updateReportMeta { it.copy(barcodeStyleConfigJson = json) }
    }

    fun changeReportItemBarcodeFormat(
        item: ReportItemEntity,
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        viewModelScope.launch {
            val res = when (scope) {
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING -> {
                    val saved = container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
                    if (saved.isSuccess) {
                        BarcodeChangeResult(
                            success = true,
                            message = "تم تعيين ${targetFormat.arabicLabel} كنوع افتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                            appliedFormat = targetFormat,
                        )
                    } else {
                        BarcodeChangeResult(false, "تعذر تحديث النوع الافتراضي")
                    }
                }
                BarcodeFormatChangeScope.CURRENT_REPORT ->
                    container.barcodeService.changeFormatForReport(
                        reportId = reportId,
                        targetFormat = targetFormat,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                BarcodeFormatChangeScope.CURRENT_PRODUCT ->
                    container.barcodeService.changeFormatForReportItem(
                        reportId = reportId,
                        itemId = item.id,
                        targetFormat = targetFormat,
                        alsoUpdateProductCatalog = true,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                else ->
                    container.barcodeService.changeFormatForReportItem(
                        reportId = reportId,
                        itemId = item.id,
                        targetFormat = targetFormat,
                        alsoUpdateProductCatalog = false,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
            }
            _statusMessage.value = res.message
            onResult(res)
        }
    }

    fun changeEntireReportBarcodeFormat(
        targetFormat: BarcodeFormatType,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        viewModelScope.launch {
            val res = container.barcodeService.changeFormatForReport(
                reportId = reportId,
                targetFormat = targetFormat,
                alsoUpdateDefaultSetting = alsoUpdateDefault,
            )
            _statusMessage.value = res.message
            onResult(res)
        }
    }

    fun addProduct(product: ProductWithDetails, selectedBarcodeOverride: String? = null) {
        viewModelScope.launch {
            when (val res = container.reportRepository.addProductToReport(reportId, product, selectedBarcodeOverride)) {
                is AddProductToReportResult.Added -> _statusMessage.value = "تمت إضافة (${product.product.name}) إلى التقرير"
                is AddProductToReportResult.IncrementedExisting -> {
                    val qtyFormatted = NumberFormatEngine.formatDouble(
                        res.newQty,
                        NumberFormatEngine.resolveReportQuantitySpec(uiState.value.columns),
                    )
                    _statusMessage.value = "تمت زيادة كمية (${product.product.name}) إلى $qtyFormatted"
                }
                AddProductToReportResult.PreventedDuplicate -> _statusMessage.value = "المنتج مضاف مسبقاً (التكرار ممنوع حسب الإعدادات)"
            }
        }
    }

    fun addProductByScannedBarcode(barcodeValue: String) {
        viewModelScope.launch {
            val found = container.productRepository.findProductByExactBarcode(barcodeValue)
            if (found != null) {
                addProduct(found, barcodeValue)
            } else {
                _statusMessage.value = "لم يتم العثور على منتج بالباركود: $barcodeValue"
            }
        }
    }

    fun updateItem(item: ReportItemEntity) {
        viewModelScope.launch {
            container.reportRepository.updateReportItem(item)
        }
    }

    fun deleteItem(itemId: Long) {
        viewModelScope.launch {
            container.reportRepository.deleteReportItem(reportId, itemId)
            _statusMessage.value = "تمت إزالة الصف من التقرير دون المساس بقاعدة المنتجات"
        }
    }

    // ==================== Stage 5: Row Ordering + Undo/Redo + Batch Move + Duplicate ====================

    private fun pushRowOrderUndoSnapshot() {
        val currentIds = uiState.value.reportDetails?.sortedItems?.map { it.item.id } ?: return
        if (currentIds.isEmpty()) return
        rowOrderUndoStack.addLast(currentIds)
        if (rowOrderUndoStack.size > 30) rowOrderUndoStack.removeFirst()
        rowOrderRedoStack.clear()
        _undoRedoTick.value++
    }

    fun undoRowOrder() {
        if (rowOrderUndoStack.isEmpty()) return
        val currentIds = uiState.value.reportDetails?.sortedItems?.map { it.item.id }.orEmpty()
        val prevIds = rowOrderUndoStack.removeLast()
        if (currentIds.isNotEmpty()) rowOrderRedoStack.addLast(currentIds)
        _undoRedoTick.value++
        viewModelScope.launch {
            container.reportRepository.reorderReportRows(reportId, prevIds)
            _statusMessage.value = "تم التراجع عن آخر إعادة ترتيب للصفوف"
        }
    }

    fun redoRowOrder() {
        if (rowOrderRedoStack.isEmpty()) return
        val currentIds = uiState.value.reportDetails?.sortedItems?.map { it.item.id }.orEmpty()
        val nextIds = rowOrderRedoStack.removeLast()
        if (currentIds.isNotEmpty()) rowOrderUndoStack.addLast(currentIds)
        _undoRedoTick.value++
        viewModelScope.launch {
            container.reportRepository.reorderReportRows(reportId, nextIds)
            _statusMessage.value = "تمت إعادة تطبيق ترتيب الصفوف"
        }
    }

    fun reorderRows(orderedItemIds: List<Long>) {
        if (orderedItemIds.isEmpty()) return
        pushRowOrderUndoSnapshot()
        viewModelScope.launch {
            container.reportRepository.reorderReportRows(reportId, orderedItemIds)
        }
    }

    fun moveRow(fromIndex: Int, toIndex: Int) {
        val items = uiState.value.reportDetails?.sortedItems.orEmpty()
        if (fromIndex !in items.indices || toIndex !in items.indices || fromIndex == toIndex) return
        pushRowOrderUndoSnapshot()
        viewModelScope.launch {
            container.reportRepository.moveReportRow(reportId, fromIndex, toIndex)
        }
    }

    fun moveRowToStart(itemId: Long) {
        moveRowToPosition(itemId, 1)
    }

    fun moveRowToEnd(itemId: Long) {
        val total = uiState.value.reportDetails?.items?.size ?: return
        moveRowToPosition(itemId, total)
    }

    fun moveRowToPosition(itemId: Long, oneBasedPosition: Int) {
        pushRowOrderUndoSnapshot()
        viewModelScope.launch {
            container.reportRepository.moveReportRowToPosition(reportId, itemId, oneBasedPosition)
            _statusMessage.value = "تم نقل الصف إلى الموضع رقم $oneBasedPosition"
        }
    }

    fun moveRowsBatch(selectedItemIds: Set<Long>, oneBasedTargetPosition: Int) {
        if (selectedItemIds.isEmpty()) return
        pushRowOrderUndoSnapshot()
        val zeroBasedTarget = (oneBasedTargetPosition - 1).coerceAtLeast(0)
        viewModelScope.launch {
            container.reportRepository.moveReportRowsBatch(reportId, selectedItemIds, zeroBasedTarget)
            _statusMessage.value = "تم نقل ${selectedItemIds.size} صفوف مع الحفاظ على ترتيبها"
        }
    }

    fun duplicateRow(itemId: Long) {
        viewModelScope.launch {
            val createdId = container.reportRepository.duplicateReportRow(reportId, itemId)
            _statusMessage.value = if (createdId != null) {
                "تم تكرار الصف بصورة مستقلة للتقرير"
            } else {
                "تعذر نسخ الصف"
            }
        }
    }

    fun setRowSortMode(mode: ReportRowSortMode) {
        pushRowOrderUndoSnapshot()
        viewModelScope.launch {
            container.reportRepository.applyReportRowSortMode(reportId, mode)
            _statusMessage.value = "تم تطبيق: ${mode.arabicLabel}"
        }
    }

    // ==================== Stage 5: Report-Only Image Management ====================

    fun replaceReportItemImageFromProductPath(
        itemId: Long,
        sourcePath: String,
        sourceType: ReportImageSourceType,
        sourceProductId: Long?,
        sourceImageId: Long?,
    ) {
        viewModelScope.launch {
            val ok = container.reportRepository.setReportItemImageFromPath(
                reportId = reportId,
                itemId = itemId,
                sourcePath = sourcePath,
                sourceType = sourceType,
                sourceProductId = sourceProductId,
                sourceImageId = sourceImageId,
            )
            _statusMessage.value = if (ok) {
                "تم تحديث صورة الصف داخل التقرير فقط (المنتج الأصلي لم يتغير)"
            } else {
                "تعذر تحديث صورة التقرير"
            }
        }
    }

    fun replaceReportItemImageFromUri(itemId: Long, uri: Uri) {
        viewModelScope.launch {
            val ok = container.reportRepository.setReportItemImageFromUri(reportId, itemId, uri)
            _statusMessage.value = if (ok) {
                "تم رفع صورة جديدة لهذا الصف داخل التقرير فقط"
            } else {
                "تعذر قراءة أو حفظ الصورة المحددة"
            }
        }
    }

    fun applyReportOnlyImageEdits(
        itemId: Long,
        sourcePathOverride: String?,
        params: ImageEditParameters,
        onDone: (Boolean) -> Unit = {},
    ) {
        viewModelScope.launch {
            val newPath = withContext(Dispatchers.IO) {
                container.reportRepository.applyReportOnlyImageEdits(reportId, itemId, sourcePathOverride, params)
            }
            val ok = newPath != null
            _statusMessage.value = if (ok) {
                "تم حفظ تعديل الصورة داخل التقرير فقط دون المساس بصورة المنتج"
            } else {
                "تعذر معالجة وحفظ تعديل الصورة"
            }
            onDone(ok)
        }
    }

    fun restoreReportItemOriginalImage(itemId: Long) {
        viewModelScope.launch {
            val ok = container.reportRepository.restoreReportItemOriginalProductImage(reportId, itemId)
            _statusMessage.value = if (ok) {
                "تمت استعادة صورة المنتج الأساسية لهذا الصف"
            } else {
                "تعذر الاستعادة: المنتج الأصلي غير موجود أو لا يملك صورة"
            }
        }
    }

    fun renderEditedPreviewBitmap(sourcePath: String, params: ImageEditParameters): Bitmap? {
        val raw = mediaStorage.decodeSampledBitmap(sourcePath, 900) ?: return null
        return try {
            mediaStorage.renderEditedBitmap(raw, params)
        } finally {
            if (!raw.isRecycled) raw.recycle()
        }
    }

    private fun commitColumnsChange(newCols: List<ColumnConfigModel>) {
        val previous = uiState.value.columns
        undoStack.addLast(previous)
        if (undoStack.size > 30) undoStack.removeFirst()
        redoStack.clear()
        _undoRedoTick.value++
        viewModelScope.launch {
            container.reportRepository.replaceReportColumns(reportId, newCols)
        }
    }

    fun undoColumns() {
        if (undoStack.isEmpty()) return
        val current = uiState.value.columns
        val previous = undoStack.removeLast()
        redoStack.addLast(current)
        _undoRedoTick.value++
        viewModelScope.launch {
            container.reportRepository.replaceReportColumns(reportId, previous)
        }
    }

    fun redoColumns() {
        if (redoStack.isEmpty()) return
        val current = uiState.value.columns
        val next = redoStack.removeLast()
        undoStack.addLast(current)
        _undoRedoTick.value++
        viewModelScope.launch {
            container.reportRepository.replaceReportColumns(reportId, next)
        }
    }

    fun addColumn(title: String, type: ColumnType, preset: ColumnWidthPreset = ColumnWidthPreset.MEDIUM) {
        val current = uiState.value.columns.toMutableList()
        val key = "custom_${System.currentTimeMillis()}"
        val defaultSpec = NumberFormatEngine.defaultSpecForColumn(AppNumericSection.REPORT, key, type)
        val newCol = ColumnConfigModel(
            columnKey = key,
            title = title.ifBlank { type.arabicLabel },
            columnType = type,
            visible = true,
            sortOrder = current.size,
            widthMode = uiState.value.distributionMode,
            presetWidth = preset,
            manualWidthPt = when (preset) {
                ColumnWidthPreset.NARROW -> 48f
                ColumnWidthPreset.MEDIUM -> 80f
                ColumnWidthPreset.WIDE -> 135f
                ColumnWidthPreset.CUSTOM -> 90f
            },
        ).withNumberFormatSpec(defaultSpec)
        current.add(newCol)
        commitColumnsChange(current)
    }

    fun updateColumn(updated: ColumnConfigModel) {
        val list = uiState.value.columns.map { if (it.columnKey == updated.columnKey && it.id == updated.id) updated else it }
        commitColumnsChange(list)
    }

    fun updateColumnNumberFormat(column: ColumnConfigModel, spec: NumberFormatSpec) {
        updateColumn(column.withNumberFormatSpec(spec))
    }

    fun resetReportDecimalDefaults() {
        val resetList = uiState.value.columns.map { col ->
            if (NumberFormatEngine.isNumericColumnType(col.columnType)) {
                val defSpec = NumberFormatEngine.defaultSpecForColumn(
                    section = AppNumericSection.REPORT,
                    columnKey = col.columnKey,
                    columnType = col.columnType,
                )
                col.withNumberFormatSpec(defSpec)
            } else {
                col
            }
        }
        commitColumnsChange(resetList)
        _statusMessage.value = "تمت استعادة المنازل العشرية الافتراضية لأعمدة التقرير"
    }

    fun toggleColumnVisibility(column: ColumnConfigModel) {
        updateColumn(column.copy(visible = !column.visible))
    }

    fun cloneColumn(column: ColumnConfigModel) {
        val current = uiState.value.columns.toMutableList()
        val copy = column.copy(
            id = 0L,
            columnKey = "${column.columnKey}_copy_${System.currentTimeMillis() % 10000}",
            title = "${column.title} (نسخة)",
            sortOrder = current.size,
        )
        current.add(copy)
        commitColumnsChange(current)
    }

    fun deleteColumn(column: ColumnConfigModel) {
        val remaining = uiState.value.columns.filterNot { it.columnKey == column.columnKey && it.id == column.id }
            .mapIndexed { idx, col -> col.copy(sortOrder = idx) }
        commitColumnsChange(remaining)
    }

    fun moveColumn(fromIndex: Int, toIndex: Int) {
        val current = uiState.value.columns.sortedBy { it.sortOrder }.toMutableList()
        if (fromIndex !in current.indices || toIndex !in current.indices || fromIndex == toIndex) return
        val moved = current.removeAt(fromIndex)
        current.add(toIndex, moved)
        commitColumnsChange(current.mapIndexed { idx, col -> col.copy(sortOrder = idx) })
    }

    fun setDistributionMode(mode: ColumnDistributionMode) {
        updateReportMeta { it.copy(columnDistributionMode = mode.name) }
    }

    fun fitColumnsToPageWidth() {
        val currentCols = uiState.value.columns.map {
            it.copy(widthMode = ColumnDistributionMode.AUTO_FIT)
        }
        updateReportMeta { it.copy(columnDistributionMode = ColumnDistributionMode.AUTO_FIT.name) }
        commitColumnsChange(currentCols)
        _statusMessage.value = "تمت ملاءمة الأعمدة مع عرض الورقة تلقائياً"
    }

    fun adjustColumnManualWidthDelta(column: ColumnConfigModel, deltaPt: Float) {
        val minW = ColumnLayoutEngine.effectiveMinWidth(column)
        val newW = (column.manualWidthPt + deltaPt).coerceIn(minW, column.maxWidthPt.coerceAtLeast(minW + 40f))
        updateReportMeta { it.copy(columnDistributionMode = ColumnDistributionMode.MANUAL.name) }
        updateColumn(
            column.copy(
                widthMode = ColumnDistributionMode.MANUAL,
                presetWidth = ColumnWidthPreset.CUSTOM,
                manualWidthPt = newW,
            ),
        )
    }

    fun applyOverflowSuggestion(type: OverflowSuggestionType) {
        when (type) {
            OverflowSuggestionType.SWITCH_LANDSCAPE -> {
                updateReportMeta { it.copy(orientation = PageOrientation.LANDSCAPE.name) }
                _statusMessage.value = "تم تحويل الورقة إلى الوضع الأفقي"
            }
            OverflowSuggestionType.REDUCE_MARGINS -> {
                updateReportMeta { it.copy(marginStartMm = 5f, marginEndMm = 5f) }
                _statusMessage.value = "تم تقليل الهوامش الجانبية إلى 5 مم"
            }
            OverflowSuggestionType.LARGER_PAPER_A3 -> {
                updateReportMeta { it.copy(paperSize = PaperSizeType.A3.name) }
                _statusMessage.value = "تم تغيير حجم الورق إلى A3"
            }
            OverflowSuggestionType.SPLIT_HORIZONTAL_GROUPS -> {
                updateReportMeta { it.copy(splitHorizontalGroups = true) }
                _statusMessage.value = "تم تفعيل توزيع الأعمدة على مجموعات أفقية"
            }
            OverflowSuggestionType.MANUAL_WIDTHS -> {
                setDistributionMode(ColumnDistributionMode.MANUAL)
            }
        }
    }

    fun applyTemplate(template: ReportTemplateEntity) {
        viewModelScope.launch {
            container.reportRepository.applyTemplateToReport(reportId, template)
            _statusMessage.value = "تم تطبيق القالب: ${template.name}"
        }
    }

    fun saveAsTemplate(name: String, description: String) {
        val details = uiState.value.reportDetails ?: return
        viewModelScope.launch {
            container.templateRepository.saveReportAsNewTemplate(details, name, description)
            _statusMessage.value = "تم حفظ القالب الجديد في المكتبة"
        }
    }

    fun archiveReport() {
        viewModelScope.launch {
            container.reportRepository.archiveReport(reportId, true)
            _statusMessage.value = "تم حفظ وأرشفة التقرير بنجاح"
        }
    }

    fun saveAsNewVersion(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val newId = container.reportRepository.saveAsNewReportVersion(reportId)
            _statusMessage.value = "تم إنشاء وحفظ إصدار جديد من التقرير"
            onCreated(newId)
        }
    }

    fun generatePdf(customFileName: String? = null, onReady: (File) -> Unit) {
        if (_isGeneratingPdf.value) return
        val details = uiState.value.reportDetails ?: return
        val settings = uiState.value.settings
        viewModelScope.launch {
            _isGeneratingPdf.value = true
            try {
                val result = withContext(Dispatchers.IO) {
                    container.pdfGeneratorEngine.generateReportPdf(details, settings, customFileName)
                }
                container.reportRepository.updateReport(details.report.copy(lastPdfPath = result.file.absolutePath))
                if (result.warnings.isNotEmpty()) {
                    _statusMessage.value = result.warnings.first()
                }
                onReady(result.file)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Exception) {
                container.globalErrorMonitor.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.PDF, "توليد ملف PDF للتقرير")
                _statusMessage.value = "تعذر إنشاء ملف PDF: ${e.localizedMessage ?: "خطأ"}"
            } finally {
                _isGeneratingPdf.value = false
            }
        }
    }

    fun exportToExcel(onReady: (File) -> Unit) {
        val details = uiState.value.reportDetails ?: return
        viewModelScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    container.excelExportEngine.exportReportToXlsx(
                        details,
                        "${details.report.reportNumber}_${details.report.title}",
                    )
                }
                _statusMessage.value = "تم تصدير التقرير إلى Excel"
                onReady(file)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(t, ScreenNames.REPORT_EDITOR, DiagnosticModules.EXCEL, "تصدير التقرير إلى Excel")
                _statusMessage.value = "تعذر تصدير التقرير إلى Excel: ${t.localizedMessage ?: "خطأ"}"
            }
        }
    }
}
