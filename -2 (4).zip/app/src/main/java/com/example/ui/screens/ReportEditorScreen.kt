package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material.icons.filled.VerticalAlignTop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportItemWithBarcodes
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.billing.FeatureAccessDecision
import com.example.domain.billing.ProFeature
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.toNumberFormatSpec
import com.example.domain.formatting.NumberFormatEngine.withNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.CellAlignment
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnType
import com.example.ui.components.DecimalPlacesControlDialog
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.DuplicateProductBehavior
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.domain.model.ReportImageSourceType
import com.example.domain.model.ReportRowSortMode
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.CachedBarcodeImage
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MoveRowPositionDialog
import com.example.ui.components.PathImageBox
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.components.ReportRowImageDialog
import com.example.ui.components.formatArabicDate
import com.example.ui.components.formatCurrencyValue
import com.example.ui.components.shareFileViaProvider
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.ReportEditorUiState
import com.example.ui.viewmodel.ReportEditorViewModel
import java.io.File

@Composable
fun ReportEditorScreen(
    viewModel: ReportEditorViewModel,
    onBack: () -> Unit,
    onOpenVisualProductPicker: (Long) -> Unit,
    onOpenScannerForReport: (Long) -> Unit,
    onOpenPdfPreview: (Long, String) -> Unit,
    onCreatedNewVersion: (Long) -> Unit = {},
    onOpenSubscription: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()
    val isGeneratingPdf by viewModel.isGeneratingPdf.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMsg) {
        statusMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var editingItem by remember { mutableStateOf<ReportItemEntity?>(null) }
    var imageTargetRow by remember { mutableStateOf<ReportItemWithBarcodes?>(null) }
    var showSaveTemplateDialog by remember { mutableStateOf(false) }
    var upgradePromptFeature by remember { mutableStateOf<ProFeature?>(null) }

    fun requirePro(feature: ProFeature, onGranted: () -> Unit) {
        when (viewModel.checkProFeature(feature)) {
            is FeatureAccessDecision.Allowed -> onGranted()
            is FeatureAccessDecision.RequiresProUpgrade -> upgradePromptFeature = feature
        }
    }

    val report = state.reportDetails?.report

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = report?.title ?: "محرر التقرير",
                subtitle = report?.reportNumber,
                saveStatus = state.saveStatus,
                onBack = onBack,
                actions = {
                    if (isGeneratingPdf) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp).padding(end = 8.dp), strokeWidth = 2.dp)
                    } else {
                        IconButton(
                            onClick = {
                                requirePro(ProFeature.PRO_REPORTS_AND_EXPORT) {
                                    report?.let { r ->
                                        viewModel.generatePdf { file ->
                                            onOpenPdfPreview(r.id, file.absolutePath)
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.testTag("report_preview_pdf_btn"),
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "معاينة وإنشاء PDF")
                        }
                    }
                    IconButton(
                        onClick = {
                            requirePro(ProFeature.PRO_REPORTS_AND_EXPORT) {
                                viewModel.exportToExcel { file ->
                                    shareFileViaProvider(context, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "تصدير التقرير Excel")
                                }
                            }
                        },
                        modifier = Modifier.testTag("report_export_excel_btn"),
                    ) {
                        Icon(Icons.Default.TableView, contentDescription = "تصدير Excel")
                    }
                    IconButton(
                        onClick = {
                            requirePro(ProFeature.PRO_TEMPLATE_CUSTOMIZATION) { showSaveTemplateDialog = true }
                        },
                        modifier = Modifier.testTag("report_save_template_btn"),
                    ) {
                        Icon(Icons.Default.BookmarkAdd, contentDescription = "حفظ كقالب")
                    }
                    IconButton(
                        onClick = { viewModel.archiveReport() },
                        modifier = Modifier.testTag("report_archive_btn"),
                    ) {
                        Icon(Icons.Default.Archive, contentDescription = "حفظ في الأرشيف")
                    }
                },
            )
        },
    ) { innerPadding ->
        if (report == null) {
            Box(Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("المنتجات والترتيب (${state.reportDetails?.items?.size ?: 0})") },
                    modifier = Modifier.testTag("tab_report_items"),
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("مصمم الأعمدة") },
                    modifier = Modifier.testTag("tab_column_designer"),
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("الصفحة والبيانات") },
                    modifier = Modifier.testTag("tab_page_meta"),
                )
            }

            when (selectedTab) {
                0 -> ReportItemsAndLiveTableTab(
                    state = state,
                    viewModel = viewModel,
                    onOpenPicker = { onOpenVisualProductPicker(report.id) },
                    onOpenScanner = { onOpenScannerForReport(report.id) },
                    onEditItem = { editingItem = it },
                    onOpenRowImageEditor = { row -> imageTargetRow = row },
                )
                1 -> VisualColumnDesignerTab(
                    state = state,
                    viewModel = viewModel,
                )
                2 -> PageAndMetadataTab(
                    state = state,
                    viewModel = viewModel,
                    onCreatedNewVersion = onCreatedNewVersion,
                )
            }
        }
    }

    editingItem?.let { item ->
        val matchingRow = state.reportDetails?.items?.firstOrNull { it.item.id == item.id }
        ReportRowItemEditorDialog(
            item = item,
            currency = report?.currency ?: "ر.س",
            onDismiss = { editingItem = null },
            onOpenChangeImage = {
                editingItem = null
                matchingRow?.let { imageTargetRow = it }
            },
            onSave = { updated ->
                viewModel.updateItem(updated)
                editingItem = null
            },
        )
    }

    imageTargetRow?.let { latestRow ->
        val freshRow = state.reportDetails?.items?.firstOrNull { it.item.id == latestRow.item.id } ?: latestRow
        val srcProduct = freshRow.item.sourceProductId?.let { pid ->
            state.allProducts.firstOrNull { it.product.id == pid }
        }
        ReportRowImageDialog(
            row = freshRow,
            sourceProduct = srcProduct,
            viewModel = viewModel,
            onDismiss = { imageTargetRow = null },
        )
    }

    if (showSaveTemplateDialog) {
        var tName by remember { mutableStateOf("") }
        var tDesc by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSaveTemplateDialog = false },
            title = { Text("حفظ التصميم كقالب جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = tName, onValueChange = { tName = it }, label = { Text("اسم القالب") }, singleLine = true)
                    OutlinedTextField(value = tDesc, onValueChange = { tDesc = it }, label = { Text("وصف مختصر") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveAsTemplate(tName, tDesc)
                    showSaveTemplateDialog = false
                }) { Text("حفظ القالب") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveTemplateDialog = false }) { Text("إلغاء") }
            },
        )
    }

    upgradePromptFeature?.let { feature ->
        ProUpgradeDialog(
            feature = feature,
            currentStatus = entitlementState.status,
            onGoToSubscriptions = onOpenSubscription,
            onDismiss = { upgradePromptFeature = null },
        )
    }
}

@Composable
private fun ReportItemsAndLiveTableTab(
    state: ReportEditorUiState,
    viewModel: ReportEditorViewModel,
    onOpenPicker: () -> Unit,
    onOpenScanner: () -> Unit,
    onEditItem: (ReportItemEntity) -> Unit,
    onOpenRowImageEditor: (ReportItemWithBarcodes) -> Unit,
) {
    val reportDetails = state.reportDetails ?: return
    val items = reportDetails.sortedItems
    val layout = state.layoutResult
    val report = reportDetails.report

    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()

    var showWysiwygTable by remember { mutableStateOf(false) }
    var batchSelectMode by remember { mutableStateOf(false) }
    var selectedRowIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var showSortMenu by remember { mutableStateOf(false) }
    var moveSingleRowTarget by remember { mutableStateOf<ReportItemWithBarcodes?>(null) }
    var showMoveBatchDialog by remember { mutableStateOf(false) }
    var deleteRowConfirm by remember { mutableStateOf<ReportItemWithBarcodes?>(null) }
    var formatChangeReportItem by remember { mutableStateOf<ReportItemWithBarcodes?>(null) }
    var showReportBulkBarcodeFormatDialog by remember { mutableStateOf(false) }

    // Optimistic local row order list for ultra-smooth Drag & Drop without stutter
    var localRows by remember(items) { mutableStateOf(items) }
    var draggingRowId by remember { mutableStateOf<Long?>(null) }
    var dragAccumulatedY by remember { mutableFloatStateOf(0f) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Quick Add Product Action Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onOpenPicker,
                modifier = Modifier.weight(1f).testTag("report_add_product_btn"),
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("اختيار منتج بالصور")
            }
            FilledTonalButton(
                onClick = onOpenScanner,
                modifier = Modifier.weight(1f).testTag("report_scan_barcode_btn"),
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("مسح باركود")
            }
        }

        // Row Ordering & View Mode Control Strip
        if (items.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = !showWysiwygTable,
                    onClick = { showWysiwygTable = false },
                    leadingIcon = { Icon(Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("الترتيب والصور") },
                    modifier = Modifier.testTag("report_mode_cards_btn"),
                )
                FilterChip(
                    selected = showWysiwygTable,
                    onClick = { showWysiwygTable = true },
                    leadingIcon = { Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("معاينة جدول الورقة") },
                    modifier = Modifier.testTag("report_mode_table_btn"),
                )

                Box {
                    AssistChip(
                        onClick = { showSortMenu = true },
                        leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text(state.rowSortMode.arabicLabel) },
                        modifier = Modifier.testTag("report_row_sort_chip"),
                    )
                    DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                        ReportRowSortMode.entries.forEach { mode ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        mode.arabicLabel,
                                        fontWeight = if (state.rowSortMode == mode) FontWeight.Bold else FontWeight.Normal,
                                    )
                                },
                                onClick = {
                                    showSortMenu = false
                                    viewModel.setRowSortMode(mode)
                                },
                            )
                        }
                    }
                }

                FilterChip(
                    selected = batchSelectMode,
                    onClick = {
                        batchSelectMode = !batchSelectMode
                        if (!batchSelectMode) selectedRowIds = emptySet()
                    },
                    leadingIcon = { Icon(Icons.Default.Checklist, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("نقل متعدد") },
                    modifier = Modifier.testTag("report_batch_select_toggle_btn"),
                )

                FilterChip(
                    selected = false,
                    onClick = { showReportBulkBarcodeFormatDialog = true },
                    leadingIcon = { Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("نوع باركود التقرير") },
                    modifier = Modifier.testTag("report_bulk_barcode_format_btn"),
                )

                IconButton(
                    enabled = state.canUndoRowOrder,
                    onClick = { viewModel.undoRowOrder() },
                    modifier = Modifier.size(36.dp).testTag("report_row_undo_btn"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع ترتيب الصفوف", modifier = Modifier.size(18.dp))
                }
                IconButton(
                    enabled = state.canRedoRowOrder,
                    onClick = { viewModel.redoRowOrder() },
                    modifier = Modifier.size(36.dp).testTag("report_row_redo_btn"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة ترتيب الصفوف", modifier = Modifier.size(18.dp))
                }
            }
        }

        // Batch Row Move Toolbar
        if (batchSelectMode && items.isNotEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "محدد: ${selectedRowIds.size}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    TextButton(onClick = {
                        selectedRowIds = if (selectedRowIds.size == items.size) emptySet() else items.map { it.item.id }.toSet()
                    }) {
                        Text(if (selectedRowIds.size == items.size) "إلغاء الكل" else "تحديد الكل")
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        enabled = selectedRowIds.isNotEmpty(),
                        onClick = { showMoveBatchDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("report_batch_move_btn"),
                    ) {
                        Icon(Icons.Default.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("نقل المحدد")
                    }
                }
            }
        }

        // Overflow Advisory Banner
        if (layout.hasOverflow) {
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.12f)),
                border = BorderStroke(1.dp, StatusWarning),
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(18.dp))
                        Text(
                            "الأعمدة الظاهرة تتجاوز عرض الصفحة (${layout.overflowAmountPt.toInt()} نقطة). لم يتم حذف أي عمود.",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        layout.suggestions.forEach { sug ->
                            OutlinedButton(
                                onClick = { viewModel.applyOverflowSuggestion(sug.type) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            ) {
                                Text(sug.title, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        if (items.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                EmptyStateCard(
                    title = "التقرير فارغ حالياً",
                    description = "يبدأ التقرير فارغاً دائماً. اختر المنتجات بالصور أو امسح الباركود لإضافتها كلقطة ثابتة (Snapshot).",
                    actionLabel = "اختيار المنتجات للتقرير",
                    onAction = onOpenPicker,
                )
            }
        } else if (!showWysiwygTable) {
            // Interactive Draggable + Reorderable Rows View with Per-Row Report Image Control
            val listState = rememberLazyListState()
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(localRows, key = { _, r -> r.item.id }) { rowIdx, row ->
                    val isDragging = draggingRowId == row.item.id
                    val isChecked = row.item.id in selectedRowIds
                    val primaryImageEntity = row.images.firstOrNull { it.isPrimary } ?: row.images.firstOrNull()
                    val imageSrcType = ReportImageSourceType.fromString(primaryImageEntity?.imageSourceType)
                    var showRowMenu by remember(row.item.id) { mutableStateOf(false) }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .zIndex(if (isDragging) 1f else 0f)
                            .graphicsLayer {
                                translationY = if (isDragging) dragAccumulatedY else 0f
                                scaleX = if (isDragging) 1.02f else 1f
                                scaleY = if (isDragging) 1.02f else 1f
                            }
                            .testTag("report_row_card_${row.item.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                isDragging -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                isChecked -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                else -> MaterialTheme.colorScheme.surface
                            },
                        ),
                        border = BorderStroke(
                            width = if (isDragging || isChecked) 1.8.dp else 1.dp,
                            color = if (isDragging || isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        ),
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                if (batchSelectMode) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = {
                                            selectedRowIds = if (isChecked) selectedRowIds - row.item.id else selectedRowIds + row.item.id
                                        },
                                    )
                                }

                                // Drag Handle + Serial Badge
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                                        .padding(horizontal = 6.dp, vertical = 6.dp)
                                        .pointerInput(row.item.id) {
                                            detectDragGestures(
                                                onDragStart = {
                                                    draggingRowId = row.item.id
                                                    dragAccumulatedY = 0f
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragAccumulatedY += dragAmount.y
                                                    val stepHeightPx = 115f
                                                    val curIdx = localRows.indexOfFirst { it.item.id == row.item.id }
                                                    if (curIdx >= 0) {
                                                        if (dragAccumulatedY > stepHeightPx && curIdx < localRows.lastIndex) {
                                                            val mutable = localRows.toMutableList()
                                                            val moved = mutable.removeAt(curIdx)
                                                            mutable.add(curIdx + 1, moved)
                                                            localRows = mutable
                                                            dragAccumulatedY -= stepHeightPx
                                                        } else if (dragAccumulatedY < -stepHeightPx && curIdx > 0) {
                                                            val mutable = localRows.toMutableList()
                                                            val moved = mutable.removeAt(curIdx)
                                                            mutable.add(curIdx - 1, moved)
                                                            localRows = mutable
                                                            dragAccumulatedY += stepHeightPx
                                                        }
                                                    }
                                                },
                                                onDragEnd = {
                                                    val finalIds = localRows.map { it.item.id }
                                                    draggingRowId = null
                                                    dragAccumulatedY = 0f
                                                    viewModel.reorderRows(finalIds)
                                                },
                                                onDragCancel = {
                                                    draggingRowId = null
                                                    dragAccumulatedY = 0f
                                                    localRows = items
                                                },
                                            )
                                        }
                                        .testTag("report_row_drag_handle_${row.item.id}"),
                                ) {
                                    Icon(Icons.Default.DragIndicator, contentDescription = "اسحب للترتيب", modifier = Modifier.size(20.dp))
                                    Text(
                                        "#${rowIdx + 1}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }

                                // Report Snapshot Image + Quick Change Indicator
                                PathImageBox(
                                    filePath = row.item.imageSnapshotPath,
                                    contentDescription = row.item.productNameSnapshot,
                                    contentScale = ContentScale.Crop,
                                    showDiagnosticsOnError = false,
                                    modifier = Modifier.size(64.dp),
                                    onClick = { onOpenRowImageEditor(row) },
                                )

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onEditItem(row.item) },
                                    verticalArrangement = Arrangement.spacedBy(2.dp),
                                ) {
                                    Text(
                                        row.item.productNameSnapshot,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    val qtySpec = NumberFormatEngine.resolveReportQuantitySpec(state.columns)
                                    val priceSpec = NumberFormatEngine.resolveReportPriceSpec(state.columns)
                                    val totalSpec = NumberFormatEngine.resolveReportTotalSpec(state.columns)
                                    Text(
                                        "${row.item.primaryBarcodeSnapshot.ifBlank { "-" }} • الكمية: ${NumberFormatEngine.formatDouble(row.item.quantity, qtySpec)} • السعر: ${formatCurrencyValue(row.item.unitPrice, report.currency, priceSpec)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        "الإجمالي: ${formatCurrencyValue(row.item.lineTotal, report.currency, totalSpec)} • ${imageSrcType.arabicLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }

                                // Quick Up / Down + Overflow Actions Menu
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row {
                                        IconButton(
                                            enabled = rowIdx > 0,
                                            onClick = { viewModel.moveRow(rowIdx, rowIdx - 1) },
                                            modifier = Modifier.size(32.dp).testTag("report_row_up_${row.item.id}"),
                                        ) {
                                            Icon(Icons.Default.ArrowUpward, contentDescription = "تحريك لأعلى", modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            enabled = rowIdx < items.lastIndex,
                                            onClick = { viewModel.moveRow(rowIdx, rowIdx + 1) },
                                            modifier = Modifier.size(32.dp).testTag("report_row_down_${row.item.id}"),
                                        ) {
                                            Icon(Icons.Default.ArrowDownward, contentDescription = "تحريك لأسفل", modifier = Modifier.size(16.dp))
                                        }
                                        Box {
                                            IconButton(
                                                onClick = { showRowMenu = true },
                                                modifier = Modifier.size(32.dp).testTag("report_row_menu_${row.item.id}"),
                                            ) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "خيارات الصف", modifier = Modifier.size(18.dp))
                                            }
                                            DropdownMenu(expanded = showRowMenu, onDismissRequest = { showRowMenu = false }) {
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.VerticalAlignTop, contentDescription = null) },
                                                    text = { Text("نقل إلى البداية") },
                                                    onClick = { showRowMenu = false; viewModel.moveRowToStart(row.item.id) },
                                                )
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.VerticalAlignBottom, contentDescription = null) },
                                                    text = { Text("نقل إلى النهاية") },
                                                    onClick = { showRowMenu = false; viewModel.moveRowToEnd(row.item.id) },
                                                )
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) },
                                                    text = { Text("نقل إلى موضع محدد...") },
                                                    onClick = { showRowMenu = false; moveSingleRowTarget = row },
                                                )
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                                                    text = { Text("تكرار الصف") },
                                                    onClick = { showRowMenu = false; viewModel.duplicateRow(row.item.id) },
                                                )
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                                                    text = { Text("تغيير صورة التقرير") },
                                                    onClick = { showRowMenu = false; onOpenRowImageEditor(row) },
                                                )
                                                if (row.item.primaryBarcodeSnapshot.isNotBlank()) {
                                                    DropdownMenuItem(
                                                        leadingIcon = { Icon(Icons.Default.QrCode2, contentDescription = null) },
                                                        text = { Text("تغيير نوع الباركود") },
                                                        onClick = { showRowMenu = false; formatChangeReportItem = row },
                                                    )
                                                }
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                                                    text = { Text("تعديل السعر والكمية") },
                                                    onClick = { showRowMenu = false; onEditItem(row.item) },
                                                )
                                                DropdownMenuItem(
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                    text = { Text("حذف الصف", color = MaterialTheme.colorScheme.error) },
                                                    onClick = { showRowMenu = false; deleteRowConfirm = row },
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (row.item.primaryBarcodeSnapshot.isNotBlank()) {
                                val rowFmt = BarcodeEngine.parseFormatOrNull(row.item.primaryBarcodeTypeSnapshot)
                                    ?: BarcodeEngine.resolveCompatibleDefaultFormat(row.item.primaryBarcodeSnapshot, defaultBarcodeType)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    CachedBarcodeImage(
                                        productId = row.item.sourceProductId,
                                        barcodeValue = row.item.primaryBarcodeSnapshot,
                                        format = rowFmt,
                                        barcodeService = viewModel.barcodeService,
                                        baseWidthPx = if (rowFmt.is2D) 200 else 520,
                                        baseHeightPx = if (rowFmt.is2D) 200 else 140,
                                        showTextBelow = true,
                                        quietZoneModules = 10,
                                        allowTapToZoom = true,
                                        modifier = Modifier.weight(1f).height(56.dp),
                                    )
                                    OutlinedButton(
                                        onClick = { formatChangeReportItem = row },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .heightIn(min = 48.dp)
                                            .testTag("report_change_barcode_format_btn_${row.item.id}"),
                                    ) {
                                        Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(rowFmt.arabicLabel, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }

                            // Direct prominent Change Report Image & Edit Row action pills
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OutlinedButton(
                                    onClick = { onOpenRowImageEditor(row) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f).testTag("report_change_img_btn_${row.item.id}"),
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تغيير صورة التقرير", style = MaterialTheme.typography.labelMedium)
                                }
                                OutlinedButton(
                                    onClick = { onEditItem(row.item) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تعديل الصف", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Live WYSIWYG Report Paper Preview Table (Uses exact ColumnLayoutEngine widths & synced order!)
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
            ) {
                val computedCols = layout.computedColumns
                val usablePt = layout.usableWidthPt.coerceAtLeast(100f)
                val availDp = maxWidth
                val scaleDpPerPt = (availDp.value / usablePt).coerceAtLeast(0.75f)
                val dateStr = formatArabicDate(report.reportDate)

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(rememberScrollState()),
                ) {
                    // Header Row matching PDF exactly, with direct drag resize handles!
                    item {
                        Row(modifier = Modifier.background(Color(0xFF0F172A))) {
                            computedCols.forEach { cw ->
                                val col = cw.column
                                val wDp = (cw.widthPt * scaleDpPerPt).dp
                                Box(
                                    modifier = Modifier
                                        .width(wDp)
                                        .height(38.dp)
                                        .background(parseHexColor(col.headerBgColorHex, Color(0xFF0F172A)))
                                        .border(0.5.dp, Color.White.copy(alpha = 0.4f)),
                                ) {
                                    Text(
                                        text = col.title,
                                        color = parseHexColor(col.headerTextColorHex, Color.White),
                                        fontSize = col.fontSizeSp.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.align(Alignment.Center).padding(horizontal = 4.dp),
                                    )
                                    // Direct Drag-Resize Handle on edge
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .width(8.dp)
                                            .height(38.dp)
                                            .pointerInput(col.columnKey) {
                                                detectHorizontalDragGestures { _, dragAmount ->
                                                    viewModel.adjustColumnManualWidthDelta(col, -dragAmount / scaleDpPerPt)
                                                }
                                            },
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier.width(120.dp).height(38.dp).background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("إجراء", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    itemsIndexed(items, key = { _, r -> r.item.id }) { rowIdx, row ->
                        val bg = if (rowIdx % 2 == 1) Color(0xFFF8FAFC) else Color.White
                        Row(modifier = Modifier.background(bg)) {
                            computedCols.forEach { cw ->
                                val col = cw.column
                                val wDp = (cw.widthPt * scaleDpPerPt).dp
                                val cellHeightDp = col.cellHeightPt.coerceAtLeast(36f).dp
                                Box(
                                    modifier = Modifier
                                        .width(wDp)
                                        .height(cellHeightDp)
                                        .border(0.5.dp, Color(0xFFE2E8F0))
                                        .clickable {
                                            if (col.columnType == ColumnType.IMAGE || col.columnType == ColumnType.MULTI_IMAGE) {
                                                onOpenRowImageEditor(row)
                                            } else {
                                                onEditItem(row.item)
                                            }
                                        }
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    contentAlignment = when (col.alignment) {
                                        CellAlignment.START -> Alignment.CenterStart
                                        CellAlignment.CENTER -> Alignment.Center
                                        CellAlignment.END -> Alignment.CenterEnd
                                    },
                                ) {
                                    when (col.columnType) {
                                        ColumnType.IMAGE -> {
                                            PathImageBox(
                                                filePath = row.item.imageSnapshotPath,
                                                contentDescription = row.item.productNameSnapshot,
                                                contentScale = ContentScale.Fit,
                                                showDiagnosticsOnError = false,
                                                modifier = Modifier.fillMaxSize().padding(2.dp),
                                                onClick = { onOpenRowImageEditor(row) },
                                            )
                                        }
                                        ColumnType.MULTI_IMAGE -> {
                                            val paths = row.images
                                                .sortedBy { it.sortOrder }
                                                .map { it.filePath }
                                                .filter { it.isNotBlank() && File(it).exists() }
                                                .ifEmpty {
                                                    listOfNotNull(
                                                        row.item.imageSnapshotPath.takeIf { it.isNotBlank() && File(it).exists() },
                                                    )
                                                }
                                                .take(4)
                                            if (paths.isNotEmpty()) {
                                                Row(
                                                    modifier = Modifier.fillMaxSize().padding(2.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                ) {
                                                    paths.forEach { path ->
                                                        PathImageBox(
                                                            filePath = path,
                                                            contentDescription = row.item.productNameSnapshot,
                                                            contentScale = ContentScale.Crop,
                                                            showDiagnosticsOnError = false,
                                                            modifier = Modifier.weight(1f).fillMaxSize(),
                                                            onClick = { onOpenRowImageEditor(row) },
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        ColumnType.BARCODE, ColumnType.QR_CODE -> {
                                            val code = row.item.primaryBarcodeSnapshot
                                            val fmt = if (col.columnType == ColumnType.QR_CODE) BarcodeFormatType.QR_CODE
                                            else BarcodeEngine.parseFormatOrNull(row.item.primaryBarcodeTypeSnapshot)
                                                ?: BarcodeEngine.resolveCompatibleDefaultFormat(code, defaultBarcodeType)
                                            if (code.isNotBlank()) {
                                                CachedBarcodeImage(
                                                    productId = row.item.sourceProductId,
                                                    barcodeValue = code,
                                                    format = fmt,
                                                    barcodeService = viewModel.barcodeService,
                                                    baseWidthPx = if (fmt.is2D) 220 else 480,
                                                    baseHeightPx = if (fmt.is2D) 220 else 150,
                                                    showTextBelow = true,
                                                    quietZoneModules = 8,
                                                    allowTapToZoom = false,
                                                    onClick = { formatChangeReportItem = row },
                                                    modifier = Modifier.fillMaxSize(),
                                                )
                                            }
                                        }
                                        else -> {
                                            val text = resolvePreviewCellText(row, col, dateStr, report.currency)
                                            Text(
                                                text = text,
                                                color = parseHexColor(col.textColorHex, Color(0xFF0F172A)),
                                                fontSize = col.fontSizeSp.sp,
                                                maxLines = if (col.wrapText) 3 else 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                            }

                            // Row Image, Edit & Delete Actions
                            Row(
                                modifier = Modifier.width(120.dp).height(42.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                IconButton(onClick = { onOpenRowImageEditor(row) }, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Default.Image, contentDescription = "تغيير صورة التقرير", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onEditItem(row.item) }, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل الصف", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { deleteRowConfirm = row }, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف الصف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Totals Bar
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            val totalQty = items.sumOf { it.item.quantity }
            val netTotal = items.sumOf { it.item.lineTotal }
            val qtySpec = NumberFormatEngine.resolveReportQuantitySpec(state.columns)
            val totalSpec = NumberFormatEngine.resolveReportTotalSpec(state.columns)
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "الأصناف: ${items.size}  •  الكميات: ${NumberFormatEngine.formatDouble(totalQty, qtySpec)}",
                    style = MaterialTheme.typography.labelLarge,
                )
                Text(
                    "الإجمالي: ${formatCurrencyValue(netTotal, report.currency, totalSpec)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }

    moveSingleRowTarget?.let { target ->
        MoveRowPositionDialog(
            title = "نقل (${target.item.productNameSnapshot}) إلى موضع",
            totalRows = items.size,
            initialPosition = target.item.serialNumber,
            onDismiss = { moveSingleRowTarget = null },
            onConfirm = { newPos ->
                moveSingleRowTarget = null
                viewModel.moveRowToPosition(target.item.id, newPos)
            },
        )
    }

    if (showMoveBatchDialog) {
        MoveRowPositionDialog(
            title = "نقل ${selectedRowIds.size} صفوف محددة",
            totalRows = items.size,
            initialPosition = 1,
            onDismiss = { showMoveBatchDialog = false },
            onConfirm = { newPos ->
                showMoveBatchDialog = false
                viewModel.moveRowsBatch(selectedRowIds, newPos)
                selectedRowIds = emptySet()
                batchSelectMode = false
            },
        )
    }

    deleteRowConfirm?.let { target ->
        ConfirmActionDialog(
            title = "تأكيد حذف الصف من التقرير",
            message = "سيتم حذف (${target.item.productNameSnapshot}) من هذا التقرير فقط ولن تتأثر قاعدة المنتجات أو أي صور محفوظة.",
            onConfirm = {
                viewModel.deleteItem(target.item.id)
                deleteRowConfirm = null
            },
            onDismiss = { deleteRowConfirm = null },
        )
    }

    formatChangeReportItem?.let { target ->
        val code = target.item.primaryBarcodeSnapshot
        val curFmt = BarcodeEngine.parseFormatOrNull(target.item.primaryBarcodeTypeSnapshot)
            ?: BarcodeEngine.resolveCompatibleDefaultFormat(code, defaultBarcodeType)
        val scopes = buildList {
            add(BarcodeFormatChangeScope.CURRENT_REPORT_ITEM)
            if (target.item.sourceProductId != null) {
                add(BarcodeFormatChangeScope.CURRENT_PRODUCT)
            }
            add(BarcodeFormatChangeScope.CURRENT_REPORT)
            add(BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING)
        }
        BarcodeFormatChangeDialog(
            barcodeValue = code,
            currentFormat = curFmt,
            productName = target.item.productNameSnapshot,
            availableScopes = scopes,
            initialScope = BarcodeFormatChangeScope.CURRENT_REPORT_ITEM,
            bulkCount = items.size,
            onDismiss = { formatChangeReportItem = null },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                viewModel.changeReportItemBarcodeFormat(
                    item = target.item,
                    targetFormat = targetFormat,
                    scope = scope,
                    alsoUpdateDefault = alsoUpdateDefault,
                ) { res ->
                    if (res.success) formatChangeReportItem = null
                }
            },
        )
    }

    if (showReportBulkBarcodeFormatDialog) {
        val sampleFmt = BarcodeEngine.parseFormatOrNull(items.firstOrNull()?.item?.primaryBarcodeTypeSnapshot)
            ?: defaultBarcodeType
        BarcodeFormatChangeDialog(
            barcodeValue = "",
            currentFormat = sampleFmt,
            productName = "${report.title} (${items.size} بند)",
            availableScopes = listOf(
                BarcodeFormatChangeScope.CURRENT_REPORT,
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
            ),
            initialScope = BarcodeFormatChangeScope.CURRENT_REPORT,
            bulkCount = items.size,
            onDismiss = { showReportBulkBarcodeFormatDialog = false },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                if (scope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                    val first = items.firstOrNull()?.item
                    if (first != null) {
                        viewModel.changeReportItemBarcodeFormat(
                            item = first,
                            targetFormat = targetFormat,
                            scope = BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                            alsoUpdateDefault = true,
                        ) { res -> if (res.success) showReportBulkBarcodeFormatDialog = false }
                    } else {
                        showReportBulkBarcodeFormatDialog = false
                    }
                } else {
                    viewModel.changeEntireReportBarcodeFormat(
                        targetFormat = targetFormat,
                        alsoUpdateDefault = alsoUpdateDefault,
                    ) { res ->
                        if (res.success) showReportBulkBarcodeFormatDialog = false
                    }
                }
            },
        )
    }
}

@Composable
private fun VisualColumnDesignerTab(
    state: ReportEditorUiState,
    viewModel: ReportEditorViewModel,
) {
    val columns = state.columns.sortedBy { it.sortOrder }
    val hasReportData = (state.reportDetails?.items?.isNotEmpty() == true)
    var showAddColumnDialog by remember { mutableStateOf(false) }
    var editingColumn by remember { mutableStateOf<ColumnConfigModel?>(null) }
    var decimalEditingColumn by remember { mutableStateOf<ColumnConfigModel?>(null) }
    var deleteConfirmColumn by remember { mutableStateOf<ColumnConfigModel?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Toolbar: Undo / Redo / Auto-Fit Page Width / Add Column
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                enabled = state.canUndo,
                                onClick = { viewModel.undoColumns() },
                                modifier = Modifier.testTag("columns_undo_btn"),
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع")
                            }
                            IconButton(
                                enabled = state.canRedo,
                                onClick = { viewModel.redoColumns() },
                                modifier = Modifier.testTag("columns_redo_btn"),
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة")
                            }
                        }
                        FilledTonalButton(
                            onClick = { viewModel.fitColumnsToPageWidth() },
                            modifier = Modifier.testTag("fit_columns_page_btn"),
                        ) {
                            Icon(Icons.Default.FitScreen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("ملاءمة الأعمدة مع عرض الورقة")
                        }
                    }

                    Text("وضع توزيع الأعمدة على الورقة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        ColumnDistributionMode.entries.forEach { mode ->
                            FilterChip(
                                selected = state.distributionMode == mode,
                                onClick = { viewModel.setDistributionMode(mode) },
                                label = { Text(mode.arabicLabel) },
                            )
                        }
                    }

                    val layout = state.layoutResult
                    Text(
                        "العرض الفعلي القابل للطباعة: ${layout.usableWidthPt.toInt()} نقطة  •  الموزع: ${layout.totalAllocatedWidthPt.toInt()} نقطة",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = { showAddColumnDialog = true },
                            modifier = Modifier.weight(1f).testTag("designer_add_column_btn"),
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("إضافة عمود")
                        }
                        OutlinedButton(
                            onClick = { viewModel.resetReportDecimalDefaults() },
                            modifier = Modifier.weight(1f).testTag("report_reset_decimals_btn"),
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("افتراضي المنازل العشرية")
                        }
                    }
                }
            }
        }

        // Columns List
        itemsIndexed(columns, key = { idx, col -> "${col.columnKey}_$idx" }) { idx, col ->
            val computedWidth = state.layoutResult.computedColumns.firstOrNull { it.column.columnKey == col.columnKey }?.widthPt
            val isNumeric = NumberFormatEngine.isNumericColumnType(col.columnType)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                enabled = idx > 0,
                                onClick = { viewModel.moveColumn(idx, idx - 1) },
                                modifier = Modifier.size(30.dp),
                            ) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = "أعلى", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                enabled = idx < columns.lastIndex,
                                onClick = { viewModel.moveColumn(idx, idx + 1) },
                                modifier = Modifier.size(30.dp),
                            ) {
                                Icon(Icons.Default.ArrowDownward, contentDescription = "أسفل", modifier = Modifier.size(16.dp))
                            }
                        }

                        Column(modifier = Modifier.weight(1f).padding(horizontal = 6.dp)) {
                            Text(col.title, fontWeight = FontWeight.Bold)
                            val decLabel = if (isNumeric) {
                                " • ${NumberFormatEngine.shortBadgeLabel(col.toNumberFormatSpec())}"
                            } else ""
                            Text(
                                "${col.columnType.arabicLabel} • ${if (col.visible) "ظاهر" else "مخفي"}" +
                                    (if (computedWidth != null) " • العرض: ${computedWidth.toInt()}pt" else "") +
                                    decLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        IconButton(onClick = { viewModel.toggleColumnVisibility(col) }) {
                            Icon(
                                if (col.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "إظهار/إخفاء",
                                tint = if (col.visible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            )
                        }
                        IconButton(onClick = { editingColumn = col }) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل العمود")
                        }
                        IconButton(onClick = { viewModel.cloneColumn(col) }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ العمود")
                        }
                        IconButton(onClick = {
                            if (hasReportData) deleteConfirmColumn = col
                            else viewModel.deleteColumn(col)
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف العمود", tint = MaterialTheme.colorScheme.error)
                        }
                    }

                    if (isNumeric) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                        ) {
                            FilterChip(
                                selected = false,
                                onClick = { decimalEditingColumn = col },
                                label = {
                                    Text(
                                        "المنازل العشرية: ${NumberFormatEngine.shortBadgeLabel(col.toNumberFormatSpec())}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                },
                                modifier = Modifier.testTag("report_col_decimal_${col.columnKey}"),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddColumnDialog) {
        AddColumnDialog(
            onDismiss = { showAddColumnDialog = false },
            onAdd = { title, type, preset ->
                viewModel.addColumn(title, type, preset)
                showAddColumnDialog = false
            },
        )
    }

    editingColumn?.let { col ->
        ColumnPropertiesDialog(
            column = col,
            onDismiss = { editingColumn = null },
            onSave = { updated ->
                viewModel.updateColumn(updated)
                editingColumn = null
            },
        )
    }

    decimalEditingColumn?.let { targetCol ->
        val latest = state.columns.firstOrNull { it.columnKey == targetCol.columnKey && it.id == targetCol.id } ?: targetCol
        DecimalPlacesControlDialog(
            columnTitle = latest.title,
            currentSpec = latest.toNumberFormatSpec(),
            defaultSpec = NumberFormatEngine.defaultSpecForColumn(
                section = AppNumericSection.REPORT,
                columnKey = latest.columnKey,
                columnType = latest.columnType,
            ),
            onDismiss = { decimalEditingColumn = null },
            onSave = { spec ->
                viewModel.updateColumnNumberFormat(latest, spec)
                decimalEditingColumn = null
            },
        )
    }

    deleteConfirmColumn?.let { col ->
        ConfirmActionDialog(
            title = "تأكيد حذف العمود",
            message = "التقرير يحتوي على بيانات؛ هل أنت متأكد من حذف عمود (${col.title})؟ يمكنك استخدام التراجع (Undo) أو الإخفاء بدلاً من الحذف.",
            onConfirm = {
                viewModel.deleteColumn(col)
                deleteConfirmColumn = null
            },
            onDismiss = { deleteConfirmColumn = null },
        )
    }
}

@Composable
private fun PageAndMetadataTab(
    state: ReportEditorUiState,
    viewModel: ReportEditorViewModel,
    onCreatedNewVersion: (Long) -> Unit,
) {
    val report = state.reportDetails?.report ?: return
    val hf = state.headerFooter
    var templateMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Version & Template Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text("قالب التقرير والإصدار", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "الإصدار الحالي: V${report.versionNumber}" + if (report.isArchived) " • مؤرشف" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        FilledTonalButton(
                            onClick = { viewModel.saveAsNewVersion(onCreatedNewVersion) },
                            modifier = Modifier.testTag("report_save_new_version_btn"),
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حفظ كإصدار جديد")
                        }
                    }
                    Box {
                        OutlinedButton(onClick = { templateMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("تغيير / تطبيق قالب جاهز (${state.allTemplates.size})")
                        }
                        DropdownMenu(expanded = templateMenu, onDismissRequest = { templateMenu = false }) {
                            state.allTemplates.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t.name) },
                                    onClick = {
                                        viewModel.applyTemplate(t)
                                        templateMenu = false
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }

        // Paper Size, Orientation & Margins
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إعدادات الورق والهوامش", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PaperSizeType.entries.forEach { ps ->
                            FilterChip(
                                selected = report.paperSize == ps.name,
                                onClick = { viewModel.updateReportMeta { it.copy(paperSize = ps.name) } },
                                label = { Text(ps.name) },
                            )
                        }
                    }
                    if (report.paperSize == PaperSizeType.CUSTOM.name) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = report.customWidthMm.toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { w -> viewModel.updateReportMeta { it.copy(customWidthMm = w) } } },
                                label = { Text("العرض (مم)") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                            OutlinedTextField(
                                value = report.customHeightMm.toString(),
                                onValueChange = { v -> v.toFloatOrNull()?.let { h -> viewModel.updateReportMeta { it.copy(customHeightMm = h) } } },
                                label = { Text("الارتفاع (مم)") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PageOrientation.entries.forEach { ori ->
                            FilterChip(
                                selected = report.orientation == ori.name,
                                onClick = { viewModel.updateReportMeta { it.copy(orientation = ori.name) } },
                                label = { Text(ori.arabicLabel) },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = report.marginStartMm.toInt().toString(),
                            onValueChange = { v -> v.toFloatOrNull()?.let { m -> viewModel.updateReportMeta { it.copy(marginStartMm = m, marginEndMm = m) } } },
                            label = { Text("الهامش الجانبي (مم)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                        OutlinedTextField(
                            value = report.marginTopMm.toInt().toString(),
                            onValueChange = { v -> v.toFloatOrNull()?.let { m -> viewModel.updateReportMeta { it.copy(marginTopMm = m, marginBottomMm = m) } } },
                            label = { Text("الهامش الرأسي (مم)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                    }
                }
            }
        }

        // Report Metadata & Client Info
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("بيانات التقرير والعميل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = report.title,
                        onValueChange = { txt -> viewModel.updateReportMeta { it.copy(title = txt) } },
                        label = { Text("عنوان التقرير") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = report.reportNumber,
                            onValueChange = { txt -> viewModel.updateReportMeta { it.copy(reportNumber = txt) } },
                            label = { Text("رقم التقرير") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = report.currency,
                            onValueChange = { txt -> viewModel.updateReportMeta { it.copy(currency = txt) } },
                            label = { Text("العملة") },
                            modifier = Modifier.weight(0.6f),
                            singleLine = true,
                        )
                    }
                    OutlinedTextField(
                        value = report.clientName,
                        onValueChange = { txt -> viewModel.updateReportMeta { it.copy(clientName = txt) } },
                        label = { Text("اسم العميل") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = report.clientPhone,
                            onValueChange = { txt -> viewModel.updateReportMeta { it.copy(clientPhone = txt) } },
                            label = { Text("جوال العميل") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = report.clientAddress,
                            onValueChange = { txt -> viewModel.updateReportMeta { it.copy(clientAddress = txt) } },
                            label = { Text("العنوان") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                        )
                    }
                    OutlinedTextField(
                        value = report.notes,
                        onValueChange = { txt -> viewModel.updateReportMeta { it.copy(notes = txt) } },
                        label = { Text("ملاحظات التقرير") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = report.termsAndConditions,
                        onValueChange = { txt -> viewModel.updateReportMeta { it.copy(termsAndConditions = txt) } },
                        label = { Text("الشروط والأحكام (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = report.responsiblePerson,
                        onValueChange = { txt -> viewModel.updateReportMeta { it.copy(responsiblePerson = txt) } },
                        label = { Text("اسم المسؤول") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                }
            }
        }

        // Duplicate Product Policy & Header/Footer Visibility
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سلوك تكرار المنتج داخل التقرير", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    DuplicateProductBehavior.entries.forEach { beh ->
                        FilterChip(
                            selected = report.duplicateBehavior == beh.name,
                            onClick = { viewModel.updateReportMeta { it.copy(duplicateBehavior = beh.name) } },
                            label = { Text(beh.arabicLabel) },
                        )
                    }

                    Spacer(Modifier.height(4.dp))
                    Text("عناصر الترويسة والتذييل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    SwitchRow("إظهار شعار الشركة", hf.showLogo) { viewModel.updateHeaderFooter(hf.copy(showLogo = it)) }
                    SwitchRow("إظهار بيانات الشركة", hf.showCompanyInfo) { viewModel.updateHeaderFooter(hf.copy(showCompanyInfo = it)) }
                    SwitchRow("إظهار بيانات العميل", hf.showClientInfo) { viewModel.updateHeaderFooter(hf.copy(showClientInfo = it)) }
                    SwitchRow("إظهار صندوق الإجماليات", hf.showTotals) { viewModel.updateHeaderFooter(hf.copy(showTotals = it)) }
                    SwitchRow("إظهار الشروط والأحكام", hf.showTerms) { viewModel.updateHeaderFooter(hf.copy(showTerms = it)) }
                    SwitchRow("إظهار التوقيع والختم", hf.showSignature) { viewModel.updateHeaderFooter(hf.copy(showSignature = it, showStamp = it)) }
                    SwitchRow("تكرار رأس الجدول في الصفحات التالية", hf.repeatTableHeader) { viewModel.updateHeaderFooter(hf.copy(repeatTableHeader = it)) }
                    SwitchRow("ترقيم الصفحات", hf.showPageNumbers) { viewModel.updateHeaderFooter(hf.copy(showPageNumbers = it)) }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun resolvePreviewCellText(
    row: ReportItemWithBarcodes,
    col: ColumnConfigModel,
    dateStr: String,
    currency: String,
): String {
    val item = row.item
    val key = col.columnKey
    val spec = col.toNumberFormatSpec()
    return when (col.columnType) {
        ColumnType.SERIAL -> item.serialNumber.toString()
        ColumnType.PRICE -> NumberFormatEngine.formatDouble(item.unitPrice, spec)
        ColumnType.CURRENCY -> {
            val v = if (key == "price") item.unitPrice else item.lineTotal
            NumberFormatEngine.formatCurrencyAmount(v, currency, spec)
        }
        ColumnType.QUANTITY -> NumberFormatEngine.formatDouble(item.quantity, spec)
        ColumnType.PERCENTAGE -> "${NumberFormatEngine.formatDouble(item.discountPercent, spec)}%"
        ColumnType.NUMBER -> {
            val v = when (key) {
                "qty", "quantity" -> item.quantity
                "price" -> item.unitPrice
                "total" -> item.lineTotal
                "subtotal" -> item.unitPrice * item.quantity
                "discount_amount" -> (item.unitPrice * item.quantity - item.lineTotal).coerceAtLeast(0.0)
                else -> col.customFieldKey.toDoubleOrNull() ?: item.quantity
            }
            NumberFormatEngine.formatDouble(v, spec)
        }
        ColumnType.DATE -> dateStr
        ColumnType.NOTES -> item.notes
        else -> when (key) {
            "name" -> item.productNameSnapshot
            "barcode_text" -> item.primaryBarcodeSnapshot
            "barcode_type" -> item.primaryBarcodeTypeSnapshot
            "category" -> item.categorySnapshot
            "origin" -> item.originCountrySnapshot
            "manufacturer" -> item.manufacturerSnapshot
            "internal_code" -> item.sourceProductId?.toString().orEmpty()
            else -> item.productNameSnapshot
        }
    }
}

@Composable
private fun ReportRowItemEditorDialog(
    item: ReportItemEntity,
    currency: String,
    onDismiss: () -> Unit,
    onOpenChangeImage: () -> Unit,
    onSave: (ReportItemEntity) -> Unit,
) {
    var price by remember { mutableStateOf(NumberFormatEngine.formatEditableNumber(item.unitPrice)) }
    var qty by remember { mutableStateOf(NumberFormatEngine.formatEditableNumber(item.quantity)) }
    var discPct by remember { mutableStateOf(NumberFormatEngine.formatEditableNumber(item.discountPercent)) }
    var notes by remember { mutableStateOf(item.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل صف: ${item.productNameSnapshot}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "تعديل السعر أو الكمية هنا خاص بهذا التقرير فقط ولا يغير السعر الأساسي للمنتج.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(
                    onClick = onOpenChangeImage,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("تغيير / تحرير صورة هذا الصف للتقرير فقط")
                }
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("السعر ($currency)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it },
                    label = { Text("الكمية") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                OutlinedTextField(
                    value = discPct,
                    onValueChange = { discPct = it },
                    label = { Text("نسبة الخصم %") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الصف") },
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    item.copy(
                        unitPrice = price.toDoubleOrNull() ?: item.unitPrice,
                        quantity = qty.toDoubleOrNull()?.coerceAtLeast(0.0) ?: item.quantity,
                        discountPercent = discPct.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: item.discountPercent,
                        notes = notes,
                    ),
                )
            }) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}

@Composable
private fun AddColumnDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, type: ColumnType, preset: ColumnWidthPreset) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(ColumnType.TEXT) }
    var preset by remember { mutableStateOf(ColumnWidthPreset.MEDIUM) }
    var typeMenu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عمود جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان العمود") }, singleLine = true)
                Box {
                    OutlinedButton(onClick = { typeMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("النوع: ${type.arabicLabel}")
                    }
                    DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        ColumnType.entries.forEach { t ->
                            DropdownMenuItem(text = { Text(t.arabicLabel) }, onClick = { type = t; typeMenu = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(ColumnWidthPreset.NARROW, ColumnWidthPreset.MEDIUM, ColumnWidthPreset.WIDE).forEach { p ->
                        FilterChip(selected = preset == p, onClick = { preset = p }, label = { Text(p.arabicLabel) })
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onAdd(title, type, preset) }) { Text("إضافة") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}

@Composable
private fun ColumnPropertiesDialog(
    column: ColumnConfigModel,
    onDismiss: () -> Unit,
    onSave: (ColumnConfigModel) -> Unit,
) {
    var title by remember { mutableStateOf(column.title) }
    var preset by remember { mutableStateOf(column.presetWidth) }
    var manualWidth by remember { mutableStateOf(column.manualWidthPt.toInt().toString()) }
    var cellHeight by remember { mutableStateOf(column.cellHeightPt.toInt().toString()) }
    var fontSize by remember { mutableStateOf(column.fontSizeSp.toInt().toString()) }
    var align by remember { mutableStateOf(column.alignment) }
    var wrapText by remember { mutableStateOf(column.wrapText) }
    var decimalSpec by remember { mutableStateOf(column.toNumberFormatSpec()) }
    var showDecimalDialog by remember { mutableStateOf(false) }
    var headerBg by remember { mutableStateOf(column.headerBgColorHex) }
    val isNumeric = NumberFormatEngine.isNumericColumnType(column.columnType)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل خصائص العمود") },
        text = {
            LazyColumn(modifier = Modifier.height(340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("اسم العمود") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                item {
                    Text("خيارات العرض السريع", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ColumnWidthPreset.entries.forEach { p ->
                            FilterChip(selected = preset == p, onClick = { preset = p }, label = { Text(p.arabicLabel) })
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = manualWidth,
                            onValueChange = { manualWidth = it },
                            label = { Text("العرض اليدوي (pt)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = cellHeight,
                            onValueChange = { cellHeight = it },
                            label = { Text("ارتفاع الخلية") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = fontSize,
                        onValueChange = { fontSize = it },
                        label = { Text("حجم الخط") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (isNumeric) {
                    item {
                        OutlinedButton(
                            onClick = { showDecimalDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("report_edit_col_decimal_btn"),
                        ) {
                            Text("المنازل العشرية: ${NumberFormatEngine.arabicSummaryLabel(decimalSpec)}")
                        }
                    }
                }
                item {
                    Text("المحاذاة", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CellAlignment.entries.forEach { a ->
                            FilterChip(selected = align == a, onClick = { align = a }, label = { Text(a.arabicLabel) })
                        }
                    }
                }
                item {
                    OutlinedTextField(value = headerBg, onValueChange = { headerBg = it }, label = { Text("لون رأس العمود (Hex)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                item {
                    SwitchRow("التفاف النص داخل الخلية", wrapText) { wrapText = it }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    column.copy(
                        title = title.ifBlank { column.title },
                        presetWidth = preset,
                        manualWidthPt = manualWidth.toFloatOrNull()?.coerceIn(24f, 400f) ?: column.manualWidthPt,
                        cellHeightPt = cellHeight.toFloatOrNull()?.coerceIn(22f, 200f) ?: column.cellHeightPt,
                        fontSizeSp = fontSize.toFloatOrNull()?.coerceIn(6f, 18f) ?: column.fontSizeSp,
                        alignment = align,
                        wrapText = wrapText,
                        headerBgColorHex = headerBg,
                    ).withNumberFormatSpec(decimalSpec),
                )
            }) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )

    if (showDecimalDialog) {
        DecimalPlacesControlDialog(
            columnTitle = title.ifBlank { column.title },
            currentSpec = decimalSpec,
            defaultSpec = NumberFormatEngine.defaultSpecForColumn(
                section = AppNumericSection.REPORT,
                columnKey = column.columnKey,
                columnType = column.columnType,
            ),
            onDismiss = { showDecimalDialog = false },
            onSave = { nextSpec ->
                decimalSpec = nextSpec
                showDecimalDialog = false
            },
        )
    }
}
