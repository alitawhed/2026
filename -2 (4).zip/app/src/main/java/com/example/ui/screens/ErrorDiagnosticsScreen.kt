package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.diagnostics.ErrorEventRecord
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.OperationLogRecord
import com.example.domain.diagnostics.OperationOutcome
import com.example.domain.diagnostics.RestoreDiagnosticsReport
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatArabicDateTime
import com.example.ui.components.shareFileViaProvider
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.DiagnosticsTab
import com.example.ui.viewmodel.ErrorDiagnosticsViewModel
import com.example.ui.viewmodel.ErrorStatusFilter

@Composable
fun ErrorDiagnosticsScreen(
    viewModel: ErrorDiagnosticsViewModel,
    onBack: () -> Unit,
) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val filteredErrors by viewModel.filteredErrors.collectAsStateWithLifecycle()
    val filteredOperations by viewModel.filteredOperations.collectAsStateWithLifecycle()
    val lastRestore by viewModel.lastRestoreDiagnostics.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val severityFilter by viewModel.severityFilter.collectAsStateWithLifecycle()
    val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
    val moduleFilter by viewModel.moduleFilter.collectAsStateWithLifecycle()
    val fingerprintFilter by viewModel.fingerprintFilter.collectAsStateWithLifecycle()
    val operationIdFilter by viewModel.operationIdFilter.collectAsStateWithLifecycle()
    val availableModules by viewModel.availableModules.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    var inspectedError by remember { mutableStateOf<ErrorEventRecord?>(null) }
    var inspectedOperation by remember { mutableStateOf<OperationLogRecord?>(null) }
    var showClearConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "مركز تشخيص الأخطاء",
                subtitle = "مراقبة الانهيارات والعمليات والتوافق بدون بيانات حساسة",
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { viewModel.markAllReviewed() },
                        modifier = Modifier.testTag("diag_mark_all_reviewed_btn"),
                    ) {
                        Icon(Icons.Default.DoneAll, contentDescription = "تعليم الكل كمراجَع")
                    }
                    IconButton(
                        onClick = { showClearConfirm = true },
                        modifier = Modifier.testTag("diag_clear_logs_btn"),
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "مسح السجلات")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (isBusy) {
                item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
            }

            // Prominent Diagnostic Bundle ZIP Export Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "حزمة التشخيص المستقلة (ZIP)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                                Text(
                                    "تُصدَّر في ملف منفصل عن النسخ الاحتياطي وتخلو تماماً من كلمات المرور والمفاتيح ومحتوى قاعدة البيانات.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                        }
                        Button(
                            onClick = {
                                viewModel.exportDiagnosticZip { zipFile ->
                                    shareFileViaProvider(context, zipFile, "application/zip", "مشاركة تقرير التشخيص (ZIP)")
                                }
                            },
                            enabled = !isBusy,
                            modifier = Modifier.fillMaxWidth().testTag("diag_export_zip_btn"),
                        ) {
                            Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("تصدير تقرير التشخيص (ZIP)")
                        }
                    }
                }
            }

            // KPI Summary Cards
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DiagnosticKpiCard("إجمالي الأخطاء", stats.totalErrors.toString(), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        DiagnosticKpiCard("الجديدة", stats.newErrorsCount.toString(), StatusWarning, Modifier.weight(1f))
                        DiagnosticKpiCard("المتكررة", stats.recurringErrorsCount.toString(), StatusInfo, Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DiagnosticKpiCard("الحرجة", stats.criticalErrorsCount.toString(), StatusError, Modifier.weight(1f))
                        DiagnosticKpiCard("تمت معالجتها", stats.handledErrorsCount.toString(), StatusSuccess, Modifier.weight(1f))
                        DiagnosticKpiCard("العمليات الفاشلة", stats.failedOperationsCount.toString(), StatusError, Modifier.weight(1f))
                    }
                }
            }

            // Last App Crash Card
            stats.lastCrash?.let { crash ->
                item {
                    HighlightDiagnosticCard(
                        title = "آخر انهيار للتطبيق",
                        subtitle = "${crash.errorType} • ${formatArabicDateTime(crash.timestamp)}",
                        body = "${crash.screenName} — ${crash.originalMessage}",
                        meta = "${crash.sourceFile}:${crash.lineNumber} (${crash.functionName})",
                        isCritical = true,
                        onClick = { inspectedError = crash },
                    )
                }
            }

            // Last Failed Operation Card
            stats.lastFailedOperation?.let { failedOp ->
                item {
                    HighlightDiagnosticCard(
                        title = "آخر عملية فاشلة",
                        subtitle = "${failedOp.operationName} • ${formatArabicDateTime(failedOp.startTime)}",
                        body = failedOp.failureReason.ifBlank { "تعذر إكمال العملية" },
                        meta = "المراحل المسجلة: ${failedOp.stages.size} • الوحدة: ${failedOp.moduleName}",
                        isCritical = false,
                        onClick = { inspectedOperation = failedOp },
                    )
                }
            }

            // Last Cross-Device Restore Verification Card
            lastRestore?.let { restoreReport ->
                item {
                    RestoreDiagnosticsCard(restoreReport)
                }
            }

            // Tabs: Errors vs Operations
            item {
                TabRow(selectedTabIndex = selectedTab.ordinal) {
                    DiagnosticsTab.entries.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { viewModel.selectTab(tab) },
                            text = {
                                Text(
                                    when (tab) {
                                        DiagnosticsTab.ERRORS -> "${tab.arabicLabel} (${filteredErrors.size})"
                                        DiagnosticsTab.OPERATIONS -> "${tab.arabicLabel} (${filteredOperations.size})"
                                    },
                                )
                            },
                            modifier = Modifier.testTag("diag_tab_${tab.name.lowercase()}"),
                        )
                    }
                }
            }

            // Search & Filters
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = viewModel::setSearchQuery,
                        label = { Text("بحث في الأخطاء أو الشاشات أو الملفات") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("diag_search_input"),
                        singleLine = true,
                    )

                    if (fingerprintFilter != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تصفية حسب البصمة المتشابهة: ${fingerprintFilter!!.take(8)}", style = MaterialTheme.typography.labelMedium)
                            TextButton(onClick = { viewModel.filterByFingerprint(null) }) {
                                Text("إلغاء")
                            }
                        }
                    }

                    if (operationIdFilter != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تصفية حسب العملية: ${operationIdFilter!!.take(12)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = { viewModel.filterByOperationId(null) }) {
                                Text("إلغاء")
                            }
                        }
                    }

                    if (selectedTab == DiagnosticsTab.ERRORS) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            ErrorStatusFilter.entries.forEach { st ->
                                FilterChip(
                                    selected = statusFilter == st,
                                    onClick = { viewModel.setStatusFilter(st) },
                                    label = { Text(st.arabicLabel) },
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FilterChip(
                                selected = severityFilter == null,
                                onClick = { viewModel.setSeverityFilter(null) },
                                label = { Text("كل المستويات") },
                            )
                            listOf(LogSeverity.CRITICAL, LogSeverity.ERROR, LogSeverity.WARNING, LogSeverity.INFO).forEach { sev ->
                                FilterChip(
                                    selected = severityFilter == sev,
                                    onClick = { viewModel.setSeverityFilter(if (severityFilter == sev) null else sev) },
                                    label = { Text(sev.arabicLabel) },
                                )
                            }
                        }
                    }

                    if (availableModules.isNotEmpty()) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FilterChip(
                                selected = moduleFilter == null,
                                onClick = { viewModel.setModuleFilter(null) },
                                label = { Text("جميع الوحدات") },
                            )
                            availableModules.forEach { mod ->
                                FilterChip(
                                    selected = moduleFilter == mod,
                                    onClick = { viewModel.setModuleFilter(if (moduleFilter == mod) null else mod) },
                                    label = { Text(mod) },
                                )
                            }
                        }
                    }
                }
            }

            if (selectedTab == DiagnosticsTab.ERRORS) {
                if (filteredErrors.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "لا توجد أخطاء مطابقة",
                            description = "لم يتم رصد أي أعطال مطابقة للفلاتر المحددة.",
                            icon = Icons.Default.CheckCircle,
                        )
                    }
                } else {
                    items(filteredErrors, key = { it.errorId }) { err ->
                        ErrorEventRowCard(
                            error = err,
                            onClick = { inspectedError = err },
                        )
                    }
                }
            } else {
                if (filteredOperations.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "لا توجد عمليات مسجلة",
                            description = "سيظهر هنا سجل المراحل الزمنية لعمليات النسخ الاحتياطي والاستعادة والتصدير.",
                            icon = Icons.Default.History,
                        )
                    }
                } else {
                    items(filteredOperations, key = { it.operationId }) { op ->
                        OperationLogRowCard(
                            op = op,
                            onClick = { inspectedOperation = op },
                        )
                    }
                }
            }
        }
    }

    inspectedError?.let { err ->
        ErrorDetailDialog(
            error = err,
            formattedText = viewModel.formatSingleError(err),
            onDismiss = { inspectedError = null },
            onCopy = { txt ->
                clipboard.setText(AnnotatedString(txt))
            },
            onExportAndShare = {
                viewModel.exportSingleError(err) { file ->
                    shareFileViaProvider(context, file, "text/plain", "مشاركة تفاصيل الخطأ")
                }
            },
            onToggleReviewed = {
                viewModel.markReviewed(err.errorId, !err.isReviewed)
                inspectedError = err.copy(isReviewed = !err.isReviewed)
            },
            onShowSimilar = {
                viewModel.filterByFingerprint(err.fingerprint)
                inspectedError = null
            },
            onFilterByOperation = if (err.linkedOperationId.isNotBlank()) {
                {
                    viewModel.filterByOperationId(err.linkedOperationId)
                    inspectedError = null
                }
            } else null,
        )
    }

    inspectedOperation?.let { op ->
        OperationDetailDialog(
            op = op,
            onDismiss = { inspectedOperation = null },
            onShowOperationErrors = {
                viewModel.filterByOperationId(op.operationId)
                inspectedOperation = null
            },
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("مسح سجلات التشخيص") },
            text = { Text("هل تريد مسح جميع الأخطاء وسجل العمليات المحفوظ محلياً؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllLogs()
                        showClearConfirm = false
                    },
                ) { Text("مسح السجلات") }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("إلغاء") }
            },
        )
    }
}

@Composable
private fun DiagnosticKpiCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = accent)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HighlightDiagnosticCard(
    title: String,
    subtitle: String,
    body: String,
    meta: String,
    isCritical: Boolean,
    onClick: () -> Unit,
) {
    val container = if (isCritical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer
    val onContainer = if (isCritical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = container),
        border = BorderStroke(1.dp, if (isCritical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    if (isCritical) Icons.Default.ErrorOutline else Icons.Default.WarningAmber,
                    contentDescription = title,
                    tint = onContainer,
                    modifier = Modifier.size(18.dp),
                )
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = onContainer)
            }
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = onContainer)
            Text(body, style = MaterialTheme.typography.bodySmall, color = onContainer, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(meta, style = MaterialTheme.typography.labelSmall, color = onContainer.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun RestoreDiagnosticsCard(report: RestoreDiagnosticsReport) {
    val isOk = report.outcome == "SUCCESS"
    val sizeKb = (report.zipSizeBytes / 1024L).coerceAtLeast(1L)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (isOk) StatusSuccess else StatusError),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (isOk) "تقرير التحقق من آخر استعادة (ناجحة)" else "تقرير تشخيص آخر استعادة (${report.outcome})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isOk) StatusSuccess else StatusError,
                )
                Text(formatArabicDateTime(report.timestamp), style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "الإصدار: ${report.sourceAppVersion.ifBlank { "قديم" }} ← ${report.targetAppVersion.ifBlank { "الحالي" }} • القاعدة: v${report.sourceSchemaVersion} ← v${report.targetSchemaVersion}",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "ملفات الأرشيف: ${report.assetFilesInZip} ($sizeKb KB) • المفقودة: ${report.missingFiles.size} • التالفة: ${report.corruptedFiles.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (report.failureReason.isNotBlank()) {
                Text("السبب (${report.failureStage}): ${report.failureReason}", style = MaterialTheme.typography.bodySmall, color = StatusError)
            }
            report.verificationChecks.take(6).forEach { chk ->
                Text(
                    "${if (chk.passed) "✓" else "✗"} ${chk.checkName}: ${chk.detail}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (chk.passed) MaterialTheme.colorScheme.onSurface else StatusError,
                )
            }
        }
    }
}

@Composable
private fun ErrorEventRowCard(
    error: ErrorEventRecord,
    onClick: () -> Unit,
) {
    val sevColor = when (error.severity) {
        LogSeverity.CRITICAL -> StatusError
        LogSeverity.ERROR -> MaterialTheme.colorScheme.error
        LogSeverity.WARNING -> StatusWarning
        LogSeverity.INFO -> StatusInfo
        LogSeverity.DEBUG -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (!error.isReviewed && error.severity == LogSeverity.CRITICAL) StatusError else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Surface(color = sevColor.copy(alpha = 0.14f), shape = RoundedCornerShape(99.dp)) {
                    Text(
                        "${error.severity.arabicLabel}${if (error.isCrash) " • انهيار" else ""}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = sevColor,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (error.occurrenceCount > 1) {
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(99.dp)) {
                            Text(
                                "×${error.occurrenceCount}",
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    if (error.isReviewed) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "تمت المراجعة", tint = StatusSuccess, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Text("${error.errorType}: ${error.operationName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(error.originalMessage, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (error.failedStage.isNotBlank() || error.linkedOperationId.isNotBlank()) {
                Text(
                    "المرحلة: ${error.failedStage.ifBlank { "غير محدد" }} • عملية: ${error.linkedOperationId.take(8).ifBlank { "-" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                "${error.screenName} • ${error.moduleName} • ${error.sourceFile}:${error.lineNumber} • ${formatArabicDateTime(error.timestamp)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun OperationLogRowCard(
    op: OperationLogRecord,
    onClick: () -> Unit,
) {
    val outcomeColor = when (op.outcome) {
        OperationOutcome.SUCCESS -> StatusSuccess
        OperationOutcome.WARNING -> StatusWarning
        OperationOutcome.FAILED -> StatusError
        OperationOutcome.STARTED, OperationOutcome.RUNNING -> StatusInfo
        OperationOutcome.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (op.interruptedAbnormally) StatusError else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(op.operationName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (op.interruptedAbnormally) {
                        Surface(color = StatusError.copy(alpha = 0.14f), shape = RoundedCornerShape(99.dp)) {
                            Text(
                                "انقطع بشكل غير طبيعي",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusError,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    Surface(color = outcomeColor.copy(alpha = 0.14f), shape = RoundedCornerShape(99.dp)) {
                        Text(
                            op.outcome.arabicLabel,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = outcomeColor,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Text("${op.screenName} • ${op.moduleName} • ${formatArabicDateTime(op.startTime)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (op.currentStage.isNotBlank()) {
                Text("المرحلة الحالية: ${op.currentStage}", style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (op.failureReason.isNotBlank()) {
                Text(op.failureReason, style = MaterialTheme.typography.bodySmall, color = StatusError, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Text("معرّف العملية: ${op.operationId.take(8)} • المراحل: ${op.stages.size}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ErrorDetailDialog(
    error: ErrorEventRecord,
    formattedText: String,
    onDismiss: () -> Unit,
    onCopy: (String) -> Unit,
    onExportAndShare: () -> Unit,
    onToggleReviewed: () -> Unit,
    onShowSimilar: () -> Unit,
    onFilterByOperation: (() -> Unit)? = null,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تفاصيل الخطأ: ${error.errorType}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("معرّف الخطأ (errorId): ${error.errorId}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                Text("الشاشة: ${error.screenName}", style = MaterialTheme.typography.labelMedium)
                Text("الوحدة: ${error.moduleName}", style = MaterialTheme.typography.labelMedium)
                Text("العملية: ${error.operationName}", style = MaterialTheme.typography.labelMedium)
                if (error.linkedOperationId.isNotBlank()) {
                    Text("معرّف العملية المرتبط: ${error.linkedOperationId}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                }
                if (error.failedStage.isNotBlank()) {
                    Text("المرحلة الفاشلة: ${error.failedStage}", style = MaterialTheme.typography.labelMedium, color = StatusError)
                }
                Text("الملف والسطر: ${error.sourceFile}:${error.lineNumber}", style = MaterialTheme.typography.labelMedium)
                Text("الدالة: ${error.functionName}", style = MaterialTheme.typography.labelMedium)
                if (error.deviceSummary.isNotBlank() || error.appVersionSummary.isNotBlank()) {
                    Text("الجهاز والإصدار: ${error.deviceSummary} • v${error.appVersionSummary}", style = MaterialTheme.typography.labelSmall)
                }
                Text("الحالة: ${if (error.wasHandled) "معالج" else "انهيار غير معالج"} • التكرار: ${error.occurrenceCount} • ${formatArabicDateTime(error.timestamp)}", style = MaterialTheme.typography.labelMedium)
                HorizontalDivider()
                Text(error.originalMessage, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text("حالة التطبيق:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(error.appStateSummary, style = MaterialTheme.typography.labelSmall)
                Text("تتبع المكدس (Stack Trace):", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                    Text(
                        error.stackTrace.ifBlank { "غير متوفر" },
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                    )
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = { onCopy(formattedText) }, label = { Text("نسخ") }, leadingIcon = { Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp)) })
                    AssistChip(onClick = onExportAndShare, label = { Text("تصدير ومشاركة") }, leadingIcon = { Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp)) })
                    AssistChip(onClick = onShowSimilar, label = { Text("عرض المشابهة") }, leadingIcon = { Icon(Icons.Default.BugReport, null, modifier = Modifier.size(16.dp)) })
                    onFilterByOperation?.let { onOp ->
                        AssistChip(onClick = onOp, label = { Text("أخطاء العملية") }, leadingIcon = { Icon(Icons.Default.History, null, modifier = Modifier.size(16.dp)) })
                    }
                }
            }
        },
        confirmButton = {
            FilledTonalButton(onClick = onToggleReviewed) {
                Text(if (error.isReviewed) "إعادة فتح" else "تمّت المراجعة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
    )
}

@Composable
private fun OperationDetailDialog(
    op: OperationLogRecord,
    onDismiss: () -> Unit,
    onShowOperationErrors: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(op.operationName, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text("المعرّف (operationId): ${op.operationId}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                Text("النتيجة: ${op.outcome.arabicLabel} • الوحدة: ${op.moduleName}", style = MaterialTheme.typography.labelMedium)
                if (op.interruptedAbnormally) {
                    Text("تنبيه: هذه العملية انقطعت بشكل غير طبيعي قبل اكتمالها.", style = MaterialTheme.typography.bodySmall, color = StatusError, fontWeight = FontWeight.Bold)
                }
                if (op.currentStage.isNotBlank()) {
                    Text("آخر مرحلة نشطة: ${op.currentStage}", style = MaterialTheme.typography.labelSmall)
                }
                if (op.lastSuccessfulStage.isNotBlank()) {
                    Text("آخر مرحلة ناجحة: ${op.lastSuccessfulStage}", style = MaterialTheme.typography.labelSmall, color = StatusSuccess)
                }
                Text("البداية: ${formatArabicDateTime(op.startTime)}", style = MaterialTheme.typography.labelSmall)
                if (op.endTime > 0L) {
                    Text("المدة: ${(op.endTime - op.startTime).coerceAtLeast(0L)} مللي ثانية", style = MaterialTheme.typography.labelSmall)
                }
                if (op.failureReason.isNotBlank()) {
                    Text("سبب الفشل: ${op.failureReason}", style = MaterialTheme.typography.bodySmall, color = StatusError)
                }
                HorizontalDivider()
                Text("المراحل بالترتيب:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                op.stages.forEachIndexed { idx, st ->
                    Text(
                        "${idx + 1}. [${st.status}] ${st.stageName}${if (st.detail.isNotBlank()) " — ${st.detail}" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            FilledTonalButton(onClick = onShowOperationErrors) {
                Text("أخطاء هذه العملية")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
    )
}
