package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.auth.AuthUserProfile
import com.example.domain.model.DeveloperIdentity
import com.example.ui.components.AppScreenTopBar
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.AuthScreenMode
import com.example.ui.viewmodel.AuthUiState
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(
    viewModel: AuthViewModel,
    onBack: (() -> Unit)? = null,
    onContinueLocally: (() -> Unit)? = null,
    onOpenAccountManagement: () -> Unit = {},
    onOpenPrivacyPolicy: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var reauthPasswordInput by remember { mutableStateOf("") }
    var collisionPasswordInput by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        viewModel.refreshConfigStatus()
    }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeStatusMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Top + WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal,
        ),
        topBar = {
            AppScreenTopBar(
                title = if (state.currentUser != null) "حساب المستخدم" else "تسجيل الدخول والحساب",
                subtitle = DeveloperIdentity.APP_NAME,
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("auth_screen_list"),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Brand Identity Header
                AuthBrandHeaderCard()

                // Firebase Configuration Notice if google-services.json not yet placed
                if (!state.configStatus.isGoogleServicesConfigured || !state.configStatus.isFirebaseInitialized) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_config_notice_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = StatusWarning.copy(alpha = 0.10f),
                        ),
                        border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.45f)),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = "تنبيه إعداد Firebase",
                                tint = StatusWarning,
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "إعداد Firebase قيد الانتظار (Manual Setup)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = state.configStatus.statusMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }

                // Error Banner
                state.errorMessage?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_error_banner"),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                            )
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }

                val currentUser = state.currentUser
                if (currentUser != null) {
                    // Signed-In State (either waiting for email verification or active)
                    SignedInAccountCard(
                        user = currentUser,
                        isBusy = state.isBusy,
                        onResendVerification = viewModel::resendVerificationEmail,
                        onRefreshVerification = viewModel::refreshEmailVerificationStatus,
                        onOpenAccountManagement = onOpenAccountManagement,
                        onOpenChangePassword = { showChangePasswordDialog = true },
                        onSignOut = { viewModel.signOut(context) },
                        onRequestDelete = { showDeleteConfirmDialog = true },
                    )
                } else {
                    // Sign-In / Registration / Forgot Password Flows
                    GoogleContinueCard(
                        isBusy = state.isBusy,
                        isReady = state.configStatus.isReadyForGoogleSignIn,
                        onContinueWithGoogle = { viewModel.signInWithGoogle(context) },
                    )

                    EmailAuthCard(
                        state = state,
                        showPassword = showPassword,
                        showConfirmPassword = showConfirmPassword,
                        onToggleShowPassword = { showPassword = !showPassword },
                        onToggleShowConfirmPassword = { showConfirmPassword = !showConfirmPassword },
                        onModeChange = viewModel::setMode,
                        onDisplayNameChange = viewModel::updateDisplayName,
                        onEmailChange = viewModel::updateEmail,
                        onPasswordChange = viewModel::updatePassword,
                        onConfirmPasswordChange = viewModel::updateConfirmPassword,
                        onSignIn = viewModel::signInWithEmail,
                        onRegister = viewModel::registerWithEmail,
                        onSendReset = viewModel::sendPasswordReset,
                    )
                }

                // Continue locally without signing in (preserves existing local data access)
                if (onContinueLocally != null) {
                    OutlinedButton(
                        onClick = onContinueLocally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("auth_continue_local_btn"),
                    ) {
                        Text("المتابعة بالبيانات المحلية على الجهاز")
                    }
                }

                // Privacy Policy & Terms of Use Footer Links
                AuthLegalLinksCard(
                    onOpenPrivacy = onOpenPrivacyPolicy,
                    onOpenTerms = { showTermsDialog = true },
                )
            }
        }
    }

    // Change Password Dialog
    if (showChangePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("تغيير كلمة المرور", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (state.currentUser?.hasEmailPasswordProvider == true) {
                        OutlinedTextField(
                            value = state.currentPasswordForChange,
                            onValueChange = { viewModel.updateChangePasswordInputs(currentPassword = it) },
                            label = { Text("كلمة المرور الحالية") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("auth_current_password_input"),
                        )
                    }
                    OutlinedTextField(
                        value = state.newPasswordForChange,
                        onValueChange = { viewModel.updateChangePasswordInputs(newPassword = it) },
                        label = { Text("كلمة المرور الجديدة (8 أحرف، حرف ورقم)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("auth_new_password_input"),
                    )
                    OutlinedTextField(
                        value = state.confirmNewPasswordForChange,
                        onValueChange = { viewModel.updateChangePasswordInputs(confirmNewPassword = it) },
                        label = { Text("تأكيد كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("auth_confirm_new_password_input"),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.changePassword()
                        showChangePasswordDialog = false
                    },
                    enabled = !state.isBusy,
                    modifier = Modifier.testTag("auth_confirm_change_password_btn"),
                ) {
                    Text("تحديث كلمة المرور")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            icon = {
                Icon(
                    Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                )
            },
            title = { Text("تأكيد حذف حساب Firebase", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "سيتم حذف حساب المصادقة الخاص بك في Firebase Authentication نهائياً ولا يمكن التراجع عن ذلك.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "ملاحظة مهمة:\n" +
                            "• لن تُحذف بيانات المنتجات أو الصور أو التقارير المحلية أو نسخ ZIP الاحتياطية على جهازك تلقائياً.\n" +
                            "• حذف الحساب لا يلغي اشتراك Google Play تلقائياً؛ يجب إدارة الإلغاء عبر Google Play.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteAccount()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("auth_confirm_delete_account_btn"),
                ) {
                    Text("حذف الحساب نهائياً")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }

    // Reauthentication Dialog when Firebase requires recent login
    if (state.requiresRecentLoginOperation != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearMessages() },
            title = { Text("إعادة تأكيد الهوية مطلوبة", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "يتطلب تنفيذ «${state.requiresRecentLoginOperation}» تأكيد هويتك الآن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (state.currentUser?.hasEmailPasswordProvider == true) {
                        OutlinedTextField(
                            value = reauthPasswordInput,
                            onValueChange = { reauthPasswordInput = it },
                            label = { Text("كلمة المرور الحالية") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Button(
                            onClick = {
                                val pw = reauthPasswordInput
                                reauthPasswordInput = ""
                                viewModel.reauthenticateWithEmail(pw)
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("تأكيد بكلمة المرور")
                        }
                    }
                    if (state.currentUser?.hasGoogleProvider == true) {
                        OutlinedButton(
                            onClick = { viewModel.reauthenticateWithGoogle(context) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("تأكيد عبر حساب Google")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.clearMessages() }) {
                    Text("إغلاق")
                }
            },
        )
    }

    // Terms of Use Summary Dialog
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("شروط الاستخدام", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "1. يستخدم تطبيق «مدير التقارير» نظام Firebase Authentication لإدارة الهوية فقط.\n" +
                        "2. تظل بيانات المنتجات والصور والتقارير وسجلات الجرد محفوظة محلياً على جهازك.\n" +
                        "3. الاشتراكات المدفوعة تُدار عبر Google Play Billing، ويتم التجديد والإلغاء من حسابك في متجر Google Play.\n" +
                        "4. تسجيل الخروج أو انتهاء الاشتراك لا يحذف بياناتك المحلية ولا يمنعك من استعادة نسخك الاحتياطية.",
                    style = MaterialTheme.typography.bodySmall,
                )
            },
            confirmButton = {
                Button(onClick = { showTermsDialog = false }) {
                    Text("موافق")
                }
            },
        )
    }

    // Account Collision Resolution Dialog (when email exists with another provider)
    if (state.collisionEmail != null) {
        val collisionEmail = state.collisionEmail.orEmpty()
        AlertDialog(
            onDismissRequest = {
                collisionPasswordInput = ""
                viewModel.clearCollisionState()
            },
            title = { Text("الحساب مرتبط مسبقاً بطريقة أخرى", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "البريد الإلكتروني ($collisionEmail) مسجل بالفعل باستخدام ${state.collisionExistingProviderHint ?: "البريد وكلمة المرور"}. " +
                            "لا يقوم التطبيق بدمج حسابين منفصلين تلقائياً. أدخل كلمة مرور حسابك لتسجيل الدخول أولاً ثم ربط حساب Google على نفس المعرّف الثابت (UID).",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (!state.collisionPendingGoogleIdToken.isNullOrBlank()) {
                        OutlinedTextField(
                            value = collisionPasswordInput,
                            onValueChange = { collisionPasswordInput = it },
                            label = { Text("كلمة مرور الحساب المسجل") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_collision_password_input"),
                        )
                    }
                }
            },
            confirmButton = {
                if (!state.collisionPendingGoogleIdToken.isNullOrBlank()) {
                    Button(
                        onClick = {
                            val pw = collisionPasswordInput
                            collisionPasswordInput = ""
                            viewModel.resolveCollisionByEmailSignInAndLink(pw)
                        },
                        enabled = !state.isBusy,
                        modifier = Modifier.testTag("auth_collision_resolve_btn"),
                    ) {
                        Text("دخول وربط حساب Google")
                    }
                } else {
                    Button(onClick = { viewModel.clearCollisionState() }) {
                        Text("موافق")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        collisionPasswordInput = ""
                        viewModel.clearCollisionState()
                    },
                ) {
                    Text("إلغاء")
                }
            },
        )
    }
}

@Composable
private fun AuthBrandHeaderCard() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(BrandNavy, Color(0xFF1E3A5F), BrandEmerald),
                ),
            )
            .padding(20.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF141D2E),
                border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.25f)),
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_app_foreground_1795213452670),
                    contentDescription = "شعار تطبيق مدير التقارير",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(72.dp)
                        .padding(5.dp)
                        .clip(RoundedCornerShape(14.dp)),
                )
            }
            Text(
                text = DeveloperIdentity.APP_NAME,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("auth_brand_title"),
            )
            Text(
                text = "إدارة الحساب والمصادقة الآمنة",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.88f),
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun GoogleContinueCard(
    isBusy: Boolean,
    isReady: Boolean,
    onContinueWithGoogle: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "الدخول السريع",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            Button(
                onClick = onContinueWithGoogle,
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandNavy,
                    contentColor = Color.White,
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("auth_google_continue_btn"),
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp,
                    )
                    Spacer(Modifier.width(8.dp))
                } else {
                    Icon(Icons.Default.AccountCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text = "المتابعة باستخدام Google",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (!isReady) {
                Text(
                    text = "يتطلب تفعيل Google Sign-In وإضافة ملف google-services.json وبصمات SHA-1/SHA-256.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun EmailAuthCard(
    state: AuthUiState,
    showPassword: Boolean,
    showConfirmPassword: Boolean,
    onToggleShowPassword: () -> Unit,
    onToggleShowConfirmPassword: () -> Unit,
    onModeChange: (AuthScreenMode) -> Unit,
    onDisplayNameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onConfirmPasswordChange: (String) -> Unit,
    onSignIn: () -> Unit,
    onRegister: () -> Unit,
    onSendReset: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = state.mode == AuthScreenMode.SIGN_IN,
                    onClick = { onModeChange(AuthScreenMode.SIGN_IN) },
                    label = { Text("تسجيل الدخول") },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("auth_mode_sign_in_chip"),
                )
                FilterChip(
                    selected = state.mode == AuthScreenMode.REGISTER,
                    onClick = { onModeChange(AuthScreenMode.REGISTER) },
                    label = { Text("إنشاء حساب جديد") },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("auth_mode_register_chip"),
                )
            }

            if (state.mode == AuthScreenMode.REGISTER) {
                OutlinedTextField(
                    value = state.displayName,
                    onValueChange = onDisplayNameChange,
                    label = { Text("الاسم الكامل") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_name_input"),
                )
            }

            OutlinedTextField(
                value = state.email,
                onValueChange = onEmailChange,
                label = { Text("البريد الإلكتروني") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_email_input"),
            )

            if (state.mode != AuthScreenMode.FORGOT_PASSWORD) {
                OutlinedTextField(
                    value = state.password,
                    onValueChange = onPasswordChange,
                    label = { Text("كلمة المرور") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = onToggleShowPassword) {
                            Icon(
                                imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (showPassword) "إخفاء كلمة المرور" else "إظهار كلمة المرور",
                            )
                        }
                    },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_password_input"),
                )
            }

            if (state.mode == AuthScreenMode.REGISTER) {
                PasswordPolicyChecklist(state)
                OutlinedTextField(
                    value = state.confirmPassword,
                    onValueChange = onConfirmPasswordChange,
                    label = { Text("تأكيد كلمة المرور") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = onToggleShowConfirmPassword) {
                            Icon(
                                imageVector = if (showConfirmPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "إظهار أو إخفاء تأكيد كلمة المرور",
                            )
                        }
                    },
                    visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_confirm_password_input"),
                )
            }

            when (state.mode) {
                AuthScreenMode.SIGN_IN -> {
                    Button(
                        onClick = onSignIn,
                        enabled = !state.isBusy,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .testTag("auth_email_sign_in_btn"),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تسجيل الدخول بالبريد الإلكتروني")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(
                            onClick = { onModeChange(AuthScreenMode.FORGOT_PASSWORD) },
                            modifier = Modifier.testTag("auth_forgot_password_link"),
                        ) {
                            Text("نسيت كلمة المرور؟")
                        }
                    }
                }
                AuthScreenMode.REGISTER -> {
                    Button(
                        onClick = onRegister,
                        enabled = !state.isBusy,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .testTag("auth_register_btn"),
                    ) {
                        Text("إنشاء حساب جديد")
                    }
                }
                AuthScreenMode.FORGOT_PASSWORD -> {
                    Text(
                        text = "أدخل بريدك الإلكتروني وسنرسل لك رابطاً رسمياً من Firebase لإعادة تعيين كلمة المرور.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = onSendReset,
                        enabled = !state.isBusy,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .testTag("auth_send_reset_btn"),
                    ) {
                        Text("إرسال رابط إعادة تعيين كلمة المرور")
                    }
                    TextButton(
                        onClick = { onModeChange(AuthScreenMode.SIGN_IN) },
                        modifier = Modifier.align(Alignment.End),
                    ) {
                        Text("العودة إلى تسجيل الدخول")
                    }
                }
            }
        }
    }
}

@Composable
private fun PasswordPolicyChecklist(state: AuthUiState) {
    val policy = state.passwordPolicy
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                text = "سياسة كلمة المرور:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
            )
            PolicyLine("8 أحرف على الأقل", policy.hasMinLength)
            PolicyLine("حرف واحد على الأقل", policy.hasLetter)
            PolicyLine("رقم واحد على الأقل", policy.hasDigit)
            PolicyLine("بدون مسافات", policy.hasNoSpaces)
        }
    }
}

@Composable
private fun PolicyLine(label: String, passed: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = if (passed) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(15.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (passed) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SignedInAccountCard(
    user: AuthUserProfile,
    isBusy: Boolean,
    onResendVerification: () -> Unit,
    onRefreshVerification: () -> Unit,
    onOpenAccountManagement: () -> Unit,
    onOpenChangePassword: () -> Unit,
    onSignOut: () -> Unit,
    onRequestDelete: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_signed_in_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = user.effectiveDisplayLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    if (user.email.isNotBlank()) {
                        Text(
                            text = user.email,
                            style = MaterialTheme.typography.bodySmall.copy(textDirection = TextDirection.Ltr),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        text = "UID: ${user.uid}",
                        style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (!user.isAccountVerified) {
                Surface(
                    color = StatusWarning.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_verification_pending_card"),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Default.MarkEmailUnread, contentDescription = null, tint = StatusWarning)
                            Text(
                                text = "البريد الإلكتروني غير موثق بعد",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Text(
                            text = "لا يُعتبر الحساب موثقاً حتى تضغط على رابط التحقق المرسل إلى بريدك الإلكتروني.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = onResendVerification,
                                enabled = !isBusy,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("auth_resend_verification_btn"),
                            ) {
                                Text("إعادة الإرسال")
                            }
                            Button(
                                onClick = onRefreshVerification,
                                enabled = !isBusy,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("auth_refresh_verification_btn"),
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تحديث التحقق")
                            }
                        }
                    }
                }
            } else {
                Surface(
                    color = StatusSuccess.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess)
                        Text(
                            text = "حساب موثق • المزودون: ${user.providers.joinToString(" + ") { it.arabicLabel }}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = StatusSuccess,
                        )
                    }
                }
            }

            HorizontalDivider()

            Button(
                onClick = onOpenAccountManagement,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("auth_open_account_management_btn"),
            ) {
                Icon(Icons.Default.AccountCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("إدارة الحساب وربط وسائل الدخول")
            }

            if (user.hasEmailPasswordProvider) {
                OutlinedButton(
                    onClick = onOpenChangePassword,
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("auth_change_password_btn"),
                ) {
                    Icon(Icons.Default.Security, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("تغيير كلمة المرور")
                }
            }

            OutlinedButton(
                onClick = onSignOut,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("auth_sign_out_btn"),
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("تسجيل الخروج")
            }

            TextButton(
                onClick = onRequestDelete,
                enabled = !isBusy,
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("auth_delete_account_btn"),
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("حذف الحساب نهائياً")
            }
        }
    }
}

@Composable
private fun AuthLegalLinksCard(
    onOpenPrivacy: () -> Unit,
    onOpenTerms: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(
                onClick = onOpenPrivacy,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("auth_privacy_policy_link"),
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("سياسة الخصوصية")
            }
            TextButton(
                onClick = onOpenTerms,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("auth_terms_link"),
            ) {
                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("شروط الاستخدام")
            }
        }
    }
}
