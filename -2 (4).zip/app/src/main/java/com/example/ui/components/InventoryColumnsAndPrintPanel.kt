package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeService
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.toNumberFormatSpec
import com.example.domain.formatting.NumberFormatEngine.withNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.CellAlignment
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnLayoutResult
import com.example.domain.model.ColumnType
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.ComputedColumnWidth
import com.example.domain.model.InventoryBarcodeSourceMode
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.OverflowSuggestionType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.parseHexColor
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * WYSIWYG Live Count-Sheet Table matching PDF/Excel columns & barcode settings,
 * featuring sticky/pinned columns, horizontal drag-resize handles, and click-to-edit rows.
 */
@Composable
fun InventoryLiveTableView(
    items: List<InventoryCountItemEntity>,
    allProducts: List<ProductWithDetails>,
    inventoryConfig: InventorySheetConfig,
    layoutResult: ColumnLayoutResult,
    isSessionOpen: Boolean,
    onEditItem: (InventoryCountItemEntity) -> Unit,
    onOpenProductDetail: (Long) -> Unit,
    onAdjustColumnWidthDelta: (columnKey: String, deltaPt: Float) -> Unit,
    onResetColumnWidth: (columnKey: String) -> Unit,
    onOpenColumnsPanel: () -> Unit,
    modifier: Modifier = Modifier,
    onUpdateColumn: (ColumnConfigModel) -> Unit = {},
    barcodeService: BarcodeService? = null,
    defaultBarcodeType: BarcodeFormatType = BarcodeFormatType.CODE_128,
    onClickBarcodeCell: ((InventoryCountItemEntity) -> Unit)? = null,
) {
    val productMap = remember(allProducts) { allProducts.associateBy { it.product.id } }
    val timeFmt = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US) }

    val computedCols = layoutResult.computedColumns
    if (computedCols.isEmpty()) {
        Card(
            modifier = modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("جميع الأعمدة مخفية حالياً", fontWeight = FontWeight.Bold)
                Button(onClick = onOpenColumnsPanel) {
                    Text("إظهار وتخصيص الأعمدة")
                }
            }
        }
        return
    }

    val pinnedCols = remember(computedCols) { computedCols.filter { it.column.pinned } }
    val scrollableCols = remember(computedCols) { computedCols.filterNot { it.column.pinned } }
    val hScrollState = rememberScrollState()
    var activeResizeCol by remember { mutableStateOf<ColumnConfigModel?>(null) }
    var directEditingHeaderCol by remember { mutableStateOf<ColumnConfigModel?>(null) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (layoutResult.hasOverflow) {
            Surface(
                color = StatusWarning.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(18.dp))
                        Text(
                            text = "الأعمدة تتجاوز عرض الورقة (${inventoryConfig.paperSize.name} ${inventoryConfig.orientation.arabicLabel}) بـ ${layoutResult.overflowAmountPt.toInt()} نقطة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    TextButton(onClick = onOpenColumnsPanel) {
                        Text("حل سريع")
                    }
                }
            }
        }

        // Info hint bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "معاينة الجدول (${inventoryConfig.paperSize.name} • ${inventoryConfig.orientation.arabicLabel})" +
                    if (pinnedCols.isNotEmpty()) " • مثبت: ${pinnedCols.size}" else "",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = "اضغط على أي رأس عمود لتعديل الاسم والعرض",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().testTag("inventory_live_table"),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header row (Pinned columns fixed on the right/start + horizontal scrollable columns)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrandNavy),
                ) {
                    if (pinnedCols.isNotEmpty()) {
                        Row {
                            pinnedCols.forEach { computed ->
                                InventoryTableHeaderCell(
                                    computed = computed,
                                    isPinned = true,
                                    onClickHeader = { activeResizeCol = computed.column },
                                    onDragWidthDelta = { delta -> onAdjustColumnWidthDelta(computed.column.columnKey, delta) },
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(42.dp)
                                .background(BrandEmerald),
                        )
                    }
                    Row(modifier = Modifier.weight(1f).horizontalScroll(hScrollState)) {
                        scrollableCols.forEach { computed ->
                            InventoryTableHeaderCell(
                                computed = computed,
                                isPinned = false,
                                onClickHeader = { activeResizeCol = computed.column },
                                onDragWidthDelta = { delta -> onAdjustColumnWidthDelta(computed.column.columnKey, delta) },
                            )
                        }
                    }
                }

                if (items.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "لا توجد بنود في كشف الجرد بعد — امسح باركوداً لإدخال الكمية",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    items.forEachIndexed { rowIdx, item ->
                        val product = item.productId?.let { productMap[it] }
                        val rowBg = if (rowIdx % 2 == 1) {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                        val minRowH = if (inventoryConfig.renderBarcodeGraphic &&
                            computedCols.any { it.column.columnType == ColumnType.BARCODE }
                        ) {
                            56f
                        } else {
                            48f
                        }
                        val rowH = (computedCols.maxOfOrNull { it.column.cellHeightPt } ?: minRowH)
                            .coerceIn(34f, 160f)
                            .coerceAtLeast(minRowH)
                            .dp

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .clickable {
                                    if (isSessionOpen) {
                                        onEditItem(item)
                                    } else if (item.productId != null) {
                                        onOpenProductDetail(item.productId)
                                    }
                                },
                        ) {
                            if (pinnedCols.isNotEmpty()) {
                                Row {
                                    pinnedCols.forEach { computed ->
                                        InventoryTableBodyCell(
                                            rowIndex = rowIdx,
                                            item = item,
                                            product = product,
                                            computed = computed,
                                            config = inventoryConfig,
                                            timeFmt = timeFmt,
                                            rowHeightDp = rowH.value,
                                            barcodeService = barcodeService,
                                            defaultBarcodeType = defaultBarcodeType,
                                            onClickBarcodeCell = onClickBarcodeCell,
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(rowH)
                                        .background(BrandEmerald.copy(alpha = 0.45f)),
                                )
                            }
                            Row(modifier = Modifier.weight(1f).horizontalScroll(hScrollState)) {
                                scrollableCols.forEach { computed ->
                                    InventoryTableBodyCell(
                                        rowIndex = rowIdx,
                                        item = item,
                                        product = product,
                                        computed = computed,
                                        config = inventoryConfig,
                                        timeFmt = timeFmt,
                                        rowHeightDp = rowH.value,
                                        barcodeService = barcodeService,
                                        defaultBarcodeType = defaultBarcodeType,
                                        onClickBarcodeCell = onClickBarcodeCell,
                                    )
                                }
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        }
    }

    // Quick Header Width Adjustment Dialog when tapping any column header
    activeResizeCol?.let { col ->
        val latest = inventoryConfig.columns.firstOrNull { it.columnKey == col.columnKey } ?: col
        val computedW = computedCols.firstOrNull { it.column.columnKey == col.columnKey }?.widthPt ?: latest.manualWidthPt
        Dialog(
            onDismissRequest = { activeResizeCol = null },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "ضبط عرض العمود: ${latest.title}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "العرض الحالي: ${computedW.toInt()} نقطة (الافتراضي: ${InventoryColumnDefaults.defaultColumnForKey(latest.columnKey)?.manualWidthPt?.toInt() ?: 78} نقطة)",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = { onAdjustColumnWidthDelta(latest.columnKey, -16f) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("تضييق -16")
                        }
                        Button(
                            onClick = { onAdjustColumnWidthDelta(latest.columnKey, 16f) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("توسيع +16")
                        }
                    }
                    FilledTonalButton(
                        onClick = {
                            activeResizeCol = null
                            directEditingHeaderCol = latest
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("inv_header_edit_col_btn"),
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("تعديل اسم وخصائص هذا العمود")
                    }
                    TextButton(
                        onClick = {
                            onResetColumnWidth(latest.columnKey)
                            activeResizeCol = null
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("استعادة العرض الافتراضي لهذا العمود")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(
                            onClick = { activeResizeCol = null },
                            modifier = Modifier.heightIn(min = 48.dp),
                        ) { Text("تم") }
                    }
                }
            }
        }
    }

    directEditingHeaderCol?.let { targetCol ->
        val latest = inventoryConfig.columns.firstOrNull { it.columnKey == targetCol.columnKey } ?: targetCol
        InventoryColumnEditDialog(
            targetCol = latest,
            onDismiss = { directEditingHeaderCol = null },
            onResetToDefault = {
                onResetColumnWidth(latest.columnKey)
                directEditingHeaderCol = null
            },
            onSave = { updated ->
                onUpdateColumn(updated)
                directEditingHeaderCol = null
            },
        )
    }
}

@Composable
private fun InventoryTableHeaderCell(
    computed: ComputedColumnWidth,
    isPinned: Boolean,
    onClickHeader: () -> Unit,
    onDragWidthDelta: (Float) -> Unit,
) {
    val col = computed.column
    val widthDp = (computed.widthPt * 1.15f).dp
    var dragAccum by remember(col.columnKey) { mutableFloatStateOf(0f) }
    val headerBg = parseHexColor(col.headerBgColorHex, BrandNavy)
    val headerFg = parseHexColor(col.headerTextColorHex, Color.White)

    Box(
        modifier = Modifier
            .width(widthDp)
            .height(42.dp)
            .background(headerBg)
            .border(0.5.dp, Color.White.copy(alpha = 0.25f))
            .clickable(onClick = onClickHeader)
            .testTag("inv_table_header_${col.columnKey}"),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (isPinned) {
                Icon(
                    Icons.Default.PushPin,
                    contentDescription = "مثبت",
                    tint = BrandEmerald,
                    modifier = Modifier.size(12.dp).padding(end = 2.dp),
                )
            }
            Text(
                text = col.title,
                color = headerFg,
                fontSize = col.fontSizeSp.coerceIn(7f, 15f).sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
        // Edge resize handle
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(10.dp)
                .fillMaxHeight()
                .pointerInput(col.columnKey) {
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { _, dragAmount ->
                            // In RTL, dragging left (negative x) widens the column
                            dragAccum -= dragAmount * 0.55f
                            if (kotlin.math.abs(dragAccum) >= 6f) {
                                onDragWidthDelta(dragAccum)
                                dragAccum = 0f
                            }
                        },
                        onDragEnd = { dragAccum = 0f },
                    )
                },
        )
    }
}

@Composable
private fun InventoryTableBodyCell(
    rowIndex: Int,
    item: InventoryCountItemEntity,
    product: ProductWithDetails?,
    computed: ComputedColumnWidth,
    config: InventorySheetConfig,
    timeFmt: SimpleDateFormat,
    rowHeightDp: Float,
    barcodeService: BarcodeService? = null,
    defaultBarcodeType: BarcodeFormatType = BarcodeFormatType.CODE_128,
    onClickBarcodeCell: ((InventoryCountItemEntity) -> Unit)? = null,
) {
    val col = computed.column
    val widthDp = (computed.widthPt * 1.15f).dp
    Box(
        modifier = Modifier
            .width(widthDp)
            .height(rowHeightDp.dp)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            .padding(horizontal = 4.dp, vertical = 3.dp),
        contentAlignment = when (col.alignment) {
            CellAlignment.START -> Alignment.CenterStart
            CellAlignment.CENTER -> Alignment.Center
            CellAlignment.END -> Alignment.CenterEnd
        },
    ) {
        when {
            col.columnType == ColumnType.IMAGE -> {
                if (config.showProductImages) {
                    InventoryItemImageBox(
                        snapshotPath = item.productImagePath,
                        product = product,
                        contentDescription = item.productName,
                        modifier = Modifier.size((rowHeightDp - 8f).coerceAtLeast(24f).dp),
                    )
                } else {
                    Text("—", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            col.columnType == ColumnType.BARCODE && config.renderBarcodeGraphic -> {
                val code = InventoryColumnDefaults.resolveBarcodeValue(item, product, config.barcodeSourceMode)
                val fmt = InventoryColumnDefaults.resolveBarcodeFormat(item, product, config, defaultBarcodeType)
                BarcodeCellPreview(
                    productId = item.productId,
                    value = code,
                    format = fmt,
                    showTextBelow = config.showBarcodeTextBelow,
                    quietZoneModules = config.quietZoneModules,
                    barcodeService = barcodeService,
                    onClick = onClickBarcodeCell?.let { cb -> { cb(item) } },
                )
            }
            col.columnType == ColumnType.QR_CODE -> {
                val code = InventoryColumnDefaults.resolveBarcodeValue(item, product, config.barcodeSourceMode)
                    .ifBlank { item.productInternalCode.ifBlank { item.productName } }
                BarcodeCellPreview(
                    productId = item.productId,
                    value = code,
                    format = BarcodeFormatType.QR_CODE,
                    showTextBelow = false,
                    quietZoneModules = 2,
                    barcodeService = barcodeService,
                    onClick = onClickBarcodeCell?.let { cb -> { cb(item) } },
                )
            }
            else -> {
                val txt = resolvePreviewCellText(rowIndex, item, product, col, config, defaultBarcodeType, timeFmt)
                Text(
                    text = txt,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = col.fontSizeSp.coerceIn(8f, 13f).sp,
                        fontWeight = if (col.columnKey == "quantity") FontWeight.Bold else FontWeight.Normal,
                    ),
                    color = if (col.columnKey == "quantity") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    maxLines = if (col.wrapText) 2 else 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = when (col.alignment) {
                        CellAlignment.START -> TextAlign.Start
                        CellAlignment.CENTER -> TextAlign.Center
                        CellAlignment.END -> TextAlign.End
                    },
                )
            }
        }
    }
}

@Composable
private fun BarcodeCellPreview(
    productId: Long?,
    value: String,
    format: BarcodeFormatType,
    showTextBelow: Boolean,
    quietZoneModules: Int,
    barcodeService: BarcodeService?,
    onClick: (() -> Unit)? = null,
) {
    if (value.isBlank()) {
        Text("—", style = MaterialTheme.typography.labelSmall)
        return
    }
    CachedBarcodeImage(
        productId = productId,
        barcodeValue = value,
        format = format,
        barcodeService = barcodeService,
        baseWidthPx = if (format.is2D) 220 else 480,
        baseHeightPx = if (format.is2D) 220 else 160,
        showTextBelow = showTextBelow,
        quietZoneModules = quietZoneModules.coerceIn(4, 16),
        allowTapToZoom = onClick == null,
        onClick = onClick,
        modifier = Modifier.fillMaxSize(),
    )
}

private fun resolvePreviewCellText(
    rowIndex: Int,
    item: InventoryCountItemEntity,
    product: ProductWithDetails?,
    col: ColumnConfigModel,
    config: InventorySheetConfig,
    defaultBarcodeType: BarcodeFormatType,
    timeFmt: SimpleDateFormat,
): String {
    val baseKey = col.columnKey.substringBefore("_copy_")
    return when (baseKey) {
        "serial" -> (rowIndex + 1).toString()
        "internal_code" -> product?.product?.internalCode?.ifBlank { item.productInternalCode }
            ?: item.productInternalCode.ifBlank { "—" }
        "name" -> item.productName
        "barcode", "barcode_text" -> InventoryColumnDefaults.resolveBarcodeValue(item, product, config.barcodeSourceMode)
        "barcode_type" -> InventoryColumnDefaults.resolveBarcodeFormat(item, product, config, defaultBarcodeType).arabicLabel
        "quantity" -> NumberFormatEngine.formatDouble(item.countedQty, col)
        "base_qty" -> NumberFormatEngine.formatDouble(item.baseUnitEquivalentQty, col)
        "unit" -> item.unitType
        "conversion_factor" -> NumberFormatEngine.formatDouble(item.conversionFactor, col)
        "category" -> product?.product?.categoryName.orEmpty().ifBlank { "—" }
        "scanned_at" -> timeFmt.format(Date(item.scannedAt))
        "notes" -> item.notes
        else -> when (col.columnType) {
            ColumnType.SERIAL -> (rowIndex + 1).toString()
            ColumnType.QUANTITY, ColumnType.NUMBER -> NumberFormatEngine.formatDouble(item.countedQty, col)
            ColumnType.PRICE -> NumberFormatEngine.formatDouble(product?.product?.basePrice ?: 0.0, col)
            ColumnType.CURRENCY -> NumberFormatEngine.formatCurrencyAmount(
                product?.product?.basePrice ?: 0.0,
                product?.product?.currency ?: "",
                col.toNumberFormatSpec(),
            )
            ColumnType.PERCENTAGE -> "${NumberFormatEngine.formatDouble(0.0, col)}%"
            ColumnType.NOTES -> item.notes
            ColumnType.DATE -> timeFmt.format(Date(item.scannedAt))
            ColumnType.BARCODE -> InventoryColumnDefaults.resolveBarcodeValue(item, product, config.barcodeSourceMode)
            ColumnType.CUSTOM_FIELD -> {
                if (col.customFieldKey.isNotBlank() && product != null) {
                    try {
                        val map = Json.decodeFromString<Map<String, String>>(product.product.customFieldsJson)
                        map[col.customFieldKey].orEmpty()
                    } catch (_: Exception) {
                        ""
                    }
                } else {
                    ""
                }
            }
            else -> ""
        }
    }
}

/**
 * Complete Column, Barcode & Print Controller Modal Sheet for Inventory Count Sheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryColumnsAndPrintSheet(
    config: InventorySheetConfig,
    layoutResult: ColumnLayoutResult,
    onDismiss: () -> Unit,
    onToggleColumnVisible: (String) -> Unit,
    onToggleColumnPinned: (String) -> Unit,
    onMoveColumn: (Int, Int) -> Unit,
    onReorderColumnsByKeys: (List<String>) -> Unit,
    onAdjustColumnWidthDelta: (String, Float) -> Unit,
    onSetColumnWidth: (String, Float) -> Unit,
    onUpdateColumn: (ColumnConfigModel) -> Unit,
    onResetColumnWidth: (String) -> Unit,
    onResetAllColumns: () -> Unit,
    onUpdateColumnNumberFormat: (String, NumberFormatSpec) -> Unit = { _, _ -> },
    onResetDecimalDefaults: () -> Unit = {},
    onFitColumnsToPage: () -> Unit,
    onSetDistributionMode: (ColumnDistributionMode) -> Unit,
    onAddOptionalColumn: (ColumnConfigModel) -> Unit,
    onAddCustomColumn: (String, ColumnType, ColumnWidthPreset) -> Unit,
    onCloneColumn: (ColumnConfigModel) -> Unit,
    onDeleteColumn: (String) -> Unit,
    onUpdateConfig: ((InventorySheetConfig) -> InventorySheetConfig) -> Unit,
    onApplyOverflowSuggestion: (OverflowSuggestionType) -> Unit,
    onOpenPrintPreview: () -> Unit,
    onPrintNow: () -> Unit,
    onOpenSessionBarcodeFormatDialog: (() -> Unit)? = null,
    canUndoColumns: Boolean = false,
    canRedoColumns: Boolean = false,
    onUndoColumns: () -> Unit = {},
    onRedoColumns: () -> Unit = {},
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember { mutableIntStateOf(0) }
    var editingColumn by remember { mutableStateOf<ColumnConfigModel?>(null) }
    var decimalEditingColumn by remember { mutableStateOf<ColumnConfigModel?>(null) }
    var showAddColumnDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 640.dp)
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("تخصيص أعمدة الجرد والباركود والطباعة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق")
                }
            }

            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("الأعمدة") },
                    modifier = Modifier.testTag("inv_panel_tab_columns"),
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("الباركود والصور") },
                    modifier = Modifier.testTag("inv_panel_tab_barcode"),
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("الورقة والطباعة") },
                    modifier = Modifier.testTag("inv_panel_tab_print"),
                )
            }

            when (selectedTab) {
                0 -> ColumnsManagerTab(
                    config = config,
                    layoutResult = layoutResult,
                    onToggleVisible = onToggleColumnVisible,
                    onTogglePinned = onToggleColumnPinned,
                    onMoveColumn = onMoveColumn,
                    onReorderColumnsByKeys = onReorderColumnsByKeys,
                    onAdjustColumnWidthDelta = onAdjustColumnWidthDelta,
                    onResetColumnWidth = onResetColumnWidth,
                    onResetAllColumns = onResetAllColumns,
                    onResetDecimalDefaults = onResetDecimalDefaults,
                    onEditDecimalPlaces = { decimalEditingColumn = it },
                    onFitColumnsToPage = onFitColumnsToPage,
                    onSetDistributionMode = onSetDistributionMode,
                    onEditColumn = { editingColumn = it },
                    onCloneColumn = onCloneColumn,
                    onDeleteColumn = onDeleteColumn,
                    onOpenAddColumn = { showAddColumnDialog = true },
                    onApplyOverflowSuggestion = onApplyOverflowSuggestion,
                    canUndoColumns = canUndoColumns,
                    canRedoColumns = canRedoColumns,
                    onUndoColumns = onUndoColumns,
                    onRedoColumns = onRedoColumns,
                )
                1 -> BarcodeAndImagesTab(
                    config = config,
                    onUpdateConfig = onUpdateConfig,
                    onOpenSessionBarcodeFormatDialog = onOpenSessionBarcodeFormatDialog?.let { cb ->
                        {
                            onDismiss()
                            cb()
                        }
                    },
                )
                2 -> PrintAndPageTab(
                    config = config,
                    onUpdateConfig = onUpdateConfig,
                    onOpenPrintPreview = {
                        onDismiss()
                        onOpenPrintPreview()
                    },
                    onPrintNow = {
                        onDismiss()
                        onPrintNow()
                    },
                )
            }
        }
    }

    // Edit single column dialog (atomic save of title, preset, width, cellHeight, fontSize, colors, alignment, wrapText, decimals)
    editingColumn?.let { targetCol ->
        val current = config.columns.firstOrNull { it.columnKey == targetCol.columnKey } ?: targetCol
        InventoryColumnEditDialog(
            targetCol = current,
            onDismiss = { editingColumn = null },
            onResetToDefault = {
                onResetColumnWidth(current.columnKey)
                editingColumn = null
            },
            onSave = { updated ->
                onUpdateColumn(updated)
                editingColumn = null
            },
        )
    }

    decimalEditingColumn?.let { targetCol ->
        val latest = config.columns.firstOrNull { it.columnKey == targetCol.columnKey } ?: targetCol
        DecimalPlacesControlDialog(
            columnTitle = latest.title,
            currentSpec = latest.toNumberFormatSpec(),
            defaultSpec = NumberFormatEngine.defaultSpecForColumn(
                section = AppNumericSection.INVENTORY,
                columnKey = latest.columnKey,
                columnType = latest.columnType,
            ),
            onDismiss = { decimalEditingColumn = null },
            onSave = { spec ->
                onUpdateColumnNumberFormat(latest.columnKey, spec)
                decimalEditingColumn = null
            },
        )
    }

    // Add Optional / Custom Column Dialog
    if (showAddColumnDialog) {
        val existingKeys = config.columns.map { it.columnKey }.toSet()
        val optionalCols = InventoryColumnDefaults.optionalExtraColumns()
        var customTitle by remember { mutableStateOf("") }
        var customType by remember { mutableStateOf(ColumnType.TEXT) }
        var customPreset by remember { mutableStateOf(ColumnWidthPreset.MEDIUM) }

        Dialog(
            onDismissRequest = { showAddColumnDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "إضافة عمود لكشف الجرد",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("أعمدة جاهزة اختيارية:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Column(
                            modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            optionalCols.forEach { opt ->
                                val already = opt.columnKey in existingKeys
                                OutlinedButton(
                                    onClick = {
                                        onAddOptionalColumn(opt)
                                        showAddColumnDialog = false
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("inv_add_opt_col_${opt.columnKey}"),
                                ) {
                                    Text(if (already) "${opt.title} (إظهار)" else "+ إضافة: ${opt.title}")
                                }
                            }
                        }
                        HorizontalDivider()
                        Text("أو إنشاء عمود مخصص:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = customTitle,
                            onValueChange = { customTitle = it },
                            label = { Text("اسم العمود الجديد") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("inv_add_custom_col_title_input"),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            listOf(ColumnType.TEXT, ColumnType.NUMBER, ColumnType.NOTES, ColumnType.QR_CODE).forEach { ct ->
                                FilterChip(
                                    selected = customType == ct,
                                    onClick = { customType = ct },
                                    label = { Text(ct.arabicLabel) },
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(ColumnWidthPreset.NARROW, ColumnWidthPreset.MEDIUM, ColumnWidthPreset.WIDE).forEach { p ->
                                FilterChip(
                                    selected = customPreset == p,
                                    onClick = { customPreset = p },
                                    label = { Text(p.arabicLabel) },
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(onClick = { showAddColumnDialog = false }) { Text("إغلاق") }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = customTitle.trim().isNotEmpty(),
                            onClick = {
                                onAddCustomColumn(customTitle, customType, customPreset)
                                showAddColumnDialog = false
                            },
                            modifier = Modifier.testTag("inv_add_custom_col_confirm_btn"),
                        ) { Text("إضافة المخصص") }
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryColumnEditDialog(
    targetCol: ColumnConfigModel,
    onDismiss: () -> Unit,
    onResetToDefault: () -> Unit,
    onSave: (ColumnConfigModel) -> Unit,
) {
    val initialWidthTxt = remember(targetCol.columnKey) { targetCol.manualWidthPt.roundToInt().toString() }
    val initialHeightTxt = remember(targetCol.columnKey) { targetCol.cellHeightPt.roundToInt().toString() }
    val initialFontTxt = remember(targetCol.columnKey) {
        if (targetCol.fontSizeSp % 1f == 0f) targetCol.fontSizeSp.toInt().toString()
        else targetCol.fontSizeSp.toString()
    }

    var titleTxt by remember(targetCol.columnKey) { mutableStateOf(targetCol.title) }
    var titleError by remember(targetCol.columnKey) { mutableStateOf(false) }
    var preset by remember(targetCol.columnKey) { mutableStateOf(targetCol.presetWidth) }
    var widthTxt by remember(targetCol.columnKey) { mutableStateOf(initialWidthTxt) }
    var widthModified by remember(targetCol.columnKey) { mutableStateOf(false) }
    var cellHeightTxt by remember(targetCol.columnKey) { mutableStateOf(initialHeightTxt) }
    var heightModified by remember(targetCol.columnKey) { mutableStateOf(false) }
    var fontSizeTxt by remember(targetCol.columnKey) { mutableStateOf(initialFontTxt) }
    var fontModified by remember(targetCol.columnKey) { mutableStateOf(false) }
    var wrapTxt by remember(targetCol.columnKey) { mutableStateOf(targetCol.wrapText) }
    var align by remember(targetCol.columnKey) { mutableStateOf(targetCol.alignment) }
    var headerBgHex by remember(targetCol.columnKey) { mutableStateOf(targetCol.headerBgColorHex) }
    var decimalSpec by remember(targetCol.columnKey) { mutableStateOf(targetCol.toNumberFormatSpec()) }
    var showInlineDecimalDialog by remember(targetCol.columnKey) { mutableStateOf(false) }
    val isNumeric = NumberFormatEngine.isNumericColumnType(targetCol.columnType)

    fun submitSave() {
        val cleanedTitle = titleTxt.trim()
        if (cleanedTitle.isEmpty()) {
            titleError = true
            return
        }
        val nextWidth = if (widthModified) {
            parsePanelFloat(widthTxt)?.coerceIn(24f, 400f) ?: targetCol.manualWidthPt
        } else {
            targetCol.manualWidthPt
        }
        val nextHeight = if (heightModified) {
            parsePanelFloat(cellHeightTxt)?.coerceIn(22f, 200f) ?: targetCol.cellHeightPt
        } else {
            targetCol.cellHeightPt
        }
        val nextFont = if (fontModified) {
            parsePanelFloat(fontSizeTxt)?.coerceIn(6f, 18f) ?: targetCol.fontSizeSp
        } else {
            targetCol.fontSizeSp
        }
        onSave(
            targetCol.copy(
                title = cleanedTitle,
                presetWidth = preset,
                manualWidthPt = nextWidth,
                cellHeightPt = nextHeight,
                fontSizeSp = nextFont,
                alignment = align,
                wrapText = wrapTxt,
                headerBgColorHex = headerBgHex.trim().ifBlank { targetCol.headerBgColorHex },
            ).withNumberFormatSpec(decimalSpec),
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = AlertDialogDefaults.shape,
            color = AlertDialogDefaults.containerColor,
            tonalElevation = AlertDialogDefaults.TonalElevation,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .widthIn(max = 520.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    "تعديل خصائص العمود",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                        .testTag("inv_edit_col_fields_list"),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = titleTxt,
                        onValueChange = {
                            titleTxt = it
                            if (titleError && it.trim().isNotEmpty()) titleError = false
                        },
                        label = { Text("عنوان العمود *") },
                        isError = titleError,
                        supportingText = if (titleError) {
                            { Text("يرجى إدخال اسم غير فارغ للعمود") }
                        } else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { submitSave() }),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("inv_edit_col_title_input"),
                    )
                    Text("خيارات العرض السريع", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        ColumnWidthPreset.entries.forEach { p ->
                            FilterChip(
                                selected = preset == p,
                                onClick = {
                                    preset = p
                                    widthModified = true
                                    when (p) {
                                        ColumnWidthPreset.NARROW -> widthTxt = "48"
                                        ColumnWidthPreset.MEDIUM -> widthTxt = "80"
                                        ColumnWidthPreset.WIDE -> widthTxt = "132"
                                        ColumnWidthPreset.CUSTOM -> Unit
                                    }
                                },
                                label = { Text(p.arabicLabel) },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = widthTxt,
                            onValueChange = {
                                widthTxt = it
                                widthModified = true
                                preset = ColumnWidthPreset.CUSTOM
                            },
                            label = { Text("العرض اليدوي (pt)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("inv_edit_col_width_input"),
                        )
                        OutlinedTextField(
                            value = cellHeightTxt,
                            onValueChange = {
                                cellHeightTxt = it
                                heightModified = true
                            },
                            label = { Text("ارتفاع الخلية (pt)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("inv_edit_col_height_input"),
                        )
                    }
                    OutlinedTextField(
                        value = fontSizeTxt,
                        onValueChange = {
                            fontSizeTxt = it
                            fontModified = true
                        },
                        label = { Text("حجم الخط (sp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("inv_edit_col_font_size_input"),
                    )
                    if (isNumeric) {
                        OutlinedButton(
                            onClick = { showInlineDecimalDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("inv_edit_col_decimal_btn"),
                        ) {
                            Text("المنازل العشرية: ${NumberFormatEngine.arabicSummaryLabel(decimalSpec)}")
                        }
                    }
                    Text("المحاذاة", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        CellAlignment.entries.forEach { a ->
                            FilterChip(
                                selected = align == a,
                                onClick = { align = a },
                                label = { Text(a.arabicLabel, maxLines = 1) },
                            )
                        }
                    }
                    Text("لون رأس العمود (Hex)", style = MaterialTheme.typography.labelMedium)
                    val swatches = listOf("#0F172A", "#1E3A8A", "#047857", "#B45309", "#991B1B", "#475569")
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        swatches.forEach { hex ->
                            val selected = headerBgHex.equals(hex, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(parseHexColor(hex, BrandNavy))
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.6f),
                                        shape = RoundedCornerShape(6.dp),
                                    )
                                    .clickable { headerBgHex = hex },
                            )
                        }
                    }
                    OutlinedTextField(
                        value = headerBgHex,
                        onValueChange = { headerBgHex = it },
                        label = { Text("كود اللون (مثال: #0F172A)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("inv_edit_col_header_bg_input"),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("التفاف النص تلقائياً")
                        Switch(checked = wrapTxt, onCheckedChange = { wrapTxt = it })
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row {
                        TextButton(
                            onClick = onResetToDefault,
                            modifier = Modifier.heightIn(min = 48.dp),
                        ) { Text("الافتراضي") }
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.heightIn(min = 48.dp),
                        ) { Text("إلغاء") }
                    }
                    Button(
                        onClick = { submitSave() },
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("inv_edit_col_save_btn"),
                    ) { Text("حفظ") }
                }
            }
        }
    }

    if (showInlineDecimalDialog) {
        DecimalPlacesControlDialog(
            columnTitle = titleTxt.trim().ifBlank { targetCol.title },
            currentSpec = decimalSpec,
            defaultSpec = NumberFormatEngine.defaultSpecForColumn(
                section = AppNumericSection.INVENTORY,
                columnKey = targetCol.columnKey,
                columnType = targetCol.columnType,
            ),
            onDismiss = { showInlineDecimalDialog = false },
            onSave = { nextSpec ->
                decimalSpec = nextSpec
                showInlineDecimalDialog = false
            },
        )
    }
}

private fun parsePanelFloat(raw: String): Float? {
    val sb = StringBuilder(raw.length)
    for (ch in raw.trim()) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            '٫', '،', ',' -> sb.append('.')
            else -> sb.append(ch)
        }
    }
    return sb.toString().toFloatOrNull()
}

@Composable
private fun ColumnsManagerTab(
    config: InventorySheetConfig,
    layoutResult: ColumnLayoutResult,
    onToggleVisible: (String) -> Unit,
    onTogglePinned: (String) -> Unit,
    onMoveColumn: (Int, Int) -> Unit,
    onReorderColumnsByKeys: (List<String>) -> Unit,
    onAdjustColumnWidthDelta: (String, Float) -> Unit,
    onResetColumnWidth: (String) -> Unit,
    onResetAllColumns: () -> Unit,
    onResetDecimalDefaults: () -> Unit,
    onEditDecimalPlaces: (ColumnConfigModel) -> Unit,
    onFitColumnsToPage: () -> Unit,
    onSetDistributionMode: (ColumnDistributionMode) -> Unit,
    onEditColumn: (ColumnConfigModel) -> Unit,
    onCloneColumn: (ColumnConfigModel) -> Unit,
    onDeleteColumn: (String) -> Unit,
    onOpenAddColumn: () -> Unit,
    onApplyOverflowSuggestion: (OverflowSuggestionType) -> Unit,
    canUndoColumns: Boolean,
    canRedoColumns: Boolean,
    onUndoColumns: () -> Unit,
    onRedoColumns: () -> Unit,
) {
    val computedMap = remember(layoutResult) {
        layoutResult.computedColumns.associateBy { it.column.columnKey }
    }
    val sortedCols = remember(config.columns) { config.columns.sortedBy { it.sortOrder } }

    // Local drag state for smooth drag-and-drop column reordering
    val dragOrder = remember(sortedCols) {
        mutableStateListOf<ColumnConfigModel>().apply { addAll(sortedCols) }
    }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Quick action toolbar (with Undo / Redo matching ReportEditorScreen)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                enabled = canUndoColumns,
                onClick = onUndoColumns,
                modifier = Modifier.testTag("inv_columns_undo_btn"),
            ) {
                Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع")
            }
            IconButton(
                enabled = canRedoColumns,
                onClick = onRedoColumns,
                modifier = Modifier.testTag("inv_columns_redo_btn"),
            ) {
                Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة")
            }
            FilledTonalButton(
                onClick = onOpenAddColumn,
                modifier = Modifier.testTag("inv_add_column_btn"),
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("إضافة عمود")
            }
            OutlinedButton(
                onClick = onFitColumnsToPage,
                modifier = Modifier.testTag("inv_fit_columns_btn"),
            ) {
                Icon(Icons.Default.FitScreen, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("ملاءمة عرض الصفحة")
            }
            OutlinedButton(
                onClick = onResetDecimalDefaults,
                modifier = Modifier.testTag("inv_reset_decimals_btn"),
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("افتراضي المنازل العشرية")
            }
            OutlinedButton(
                onClick = onResetAllColumns,
                modifier = Modifier.testTag("inv_reset_all_columns_btn"),
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("استعادة الافتراضي للكل")
            }
        }

        // Distribution mode selector
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ColumnDistributionMode.entries.forEach { mode ->
                FilterChip(
                    selected = config.distributionMode == mode,
                    onClick = { onSetDistributionMode(mode) },
                    label = { Text(mode.arabicLabel) },
                )
            }
        }

        // Overflow suggestions if needed
        if (layoutResult.hasOverflow) {
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.4f)),
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("حلول مقترحة لتجاوز عرض الورقة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        layoutResult.suggestions.forEach { s ->
                            FilterChip(
                                selected = false,
                                onClick = { onApplyOverflowSuggestion(s.type) },
                                label = { Text(s.title) },
                            )
                        }
                    }
                }
            }
        }

        Text(
            text = "اسحب من ☰ لإعادة الترتيب، أو اضغط على أي عمود لتعديل اسمه وخصائصه — التعديلات تُحفظ وتُطبق فوراً",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .testTag("inv_columns_lazy_list"),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            itemsIndexed(dragOrder, key = { _, c -> c.columnKey }) { idx, col ->
                val isDragging = draggingKey == col.columnKey
                val widthPt = computedMap[col.columnKey]?.widthPt ?: col.manualWidthPt

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .zIndex(if (isDragging) 10f else 0f)
                        .offset { IntOffset(0, if (isDragging) dragOffsetY.roundToInt() else 0) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (col.visible) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    ),
                    border = BorderStroke(
                        width = if (isDragging) 2.dp else 1.dp,
                        color = if (isDragging) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEditColumn(col) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            // Drag handle
                            Icon(
                                Icons.Default.DragHandle,
                                contentDescription = "سحب لإعادة الترتيب",
                                modifier = Modifier
                                    .size(26.dp)
                                    .pointerInput(col.columnKey) {
                                        detectDragGestures(
                                            onDragStart = {
                                                draggingKey = col.columnKey
                                                dragOffsetY = 0f
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                dragOffsetY += dragAmount.y
                                                val itemStepPx = 110f
                                                val currentIndex = dragOrder.indexOfFirst { it.columnKey == col.columnKey }
                                                if (currentIndex >= 0) {
                                                    if (dragOffsetY > itemStepPx && currentIndex < dragOrder.lastIndex) {
                                                        val moved = dragOrder.removeAt(currentIndex)
                                                        dragOrder.add(currentIndex + 1, moved)
                                                        dragOffsetY -= itemStepPx
                                                    } else if (dragOffsetY < -itemStepPx && currentIndex > 0) {
                                                        val moved = dragOrder.removeAt(currentIndex)
                                                        dragOrder.add(currentIndex - 1, moved)
                                                        dragOffsetY += itemStepPx
                                                    }
                                                }
                                            },
                                            onDragEnd = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                                onReorderColumnsByKeys(dragOrder.map { it.columnKey })
                                            },
                                            onDragCancel = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                            },
                                        )
                                    },
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${idx + 1}. ${col.title}" + if (col.pinned) " (مثبت)" else "",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                val decimalSuffix = if (NumberFormatEngine.isNumericColumnType(col.columnType)) {
                                    " • ${NumberFormatEngine.shortBadgeLabel(col.toNumberFormatSpec())}"
                                } else ""
                                Text(
                                    text = "${col.columnType.arabicLabel} • العرض: ${widthPt.toInt()} pt$decimalSuffix",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }

                            IconButton(
                                onClick = { onTogglePinned(col.columnKey) },
                                modifier = Modifier.size(34.dp).testTag("inv_col_pin_${col.columnKey}"),
                            ) {
                                Icon(
                                    Icons.Default.PushPin,
                                    contentDescription = if (col.pinned) "إلغاء التثبيت" else "تثبيت العمود",
                                    tint = if (col.pinned) BrandEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp),
                                )
                            }

                            IconButton(
                                onClick = { onToggleVisible(col.columnKey) },
                                modifier = Modifier.size(34.dp).testTag("inv_col_vis_${col.columnKey}"),
                            ) {
                                Icon(
                                    if (col.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (col.visible) "إخفاء العمود" else "إظهار العمود",
                                    tint = if (col.visible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }

                        // Secondary quick controls row: move up/down, width -/+, reset, edit, clone, delete
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            IconButton(
                                enabled = idx > 0,
                                onClick = { onMoveColumn(idx, idx - 1) },
                                modifier = Modifier.size(32.dp).testTag("inv_col_up_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "تحريك لأعلى", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                enabled = idx < dragOrder.lastIndex,
                                onClick = { onMoveColumn(idx, idx + 1) },
                                modifier = Modifier.size(32.dp).testTag("inv_col_down_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "تحريك لأسفل", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { onAdjustColumnWidthDelta(col.columnKey, -10f) },
                                modifier = Modifier.size(32.dp).testTag("inv_col_narrow_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "تصغير العرض", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { onAdjustColumnWidthDelta(col.columnKey, 10f) },
                                modifier = Modifier.size(32.dp).testTag("inv_col_widen_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "تكبير العرض", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { onResetColumnWidth(col.columnKey) },
                                modifier = Modifier.size(32.dp).testTag("inv_col_reset_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.RestartAlt, contentDescription = "إعادة العرض الافتراضي", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { onEditColumn(col) },
                                modifier = Modifier.size(36.dp).testTag("inv_col_edit_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل الخصائص", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { onCloneColumn(col) },
                                modifier = Modifier.size(36.dp).testTag("inv_col_clone_${col.columnKey}"),
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "نسخ العمود", modifier = Modifier.size(16.dp))
                            }
                            if (dragOrder.size > 1) {
                                IconButton(
                                    onClick = { onDeleteColumn(col.columnKey) },
                                    modifier = Modifier.size(36.dp).testTag("inv_col_delete_${col.columnKey}"),
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف العمود", tint = StatusError, modifier = Modifier.size(16.dp))
                                }
                            }
                            if (NumberFormatEngine.isNumericColumnType(col.columnType)) {
                                Spacer(Modifier.width(4.dp))
                                FilterChip(
                                    selected = false,
                                    onClick = { onEditDecimalPlaces(col) },
                                    label = {
                                        Text(
                                            "المنازل العشرية: ${NumberFormatEngine.shortBadgeLabel(col.toNumberFormatSpec())}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    },
                                    modifier = Modifier.testTag("inv_col_decimal_${col.columnKey}"),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BarcodeAndImagesTab(
    config: InventorySheetConfig,
    onUpdateConfig: ((InventorySheetConfig) -> InventorySheetConfig) -> Unit,
    onOpenSessionBarcodeFormatDialog: (() -> Unit)? = null,
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (onOpenSessionBarcodeFormatDialog != null) {
            item {
                OutlinedButton(
                    onClick = onOpenSessionBarcodeFormatDialog,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("inv_sheet_change_session_barcode_format_btn"),
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("تغيير نوع الباركود لبنود عملية الجرد الحالية")
                }
            }
        }
        item {
            Text("مصدر الباركود الظاهر في كشف الجرد", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
                text = "عند مسح أي باركود بديل يتعرف النظام على الصنف فوراً، ويمكنك اختيار الباركود الذي يظهر في الكشف والطباعة.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InventoryBarcodeSourceMode.entries.forEach { mode ->
                    FilterChip(
                        selected = config.barcodeSourceMode == mode,
                        onClick = { onUpdateConfig { it.copy(barcodeSourceMode = mode) } },
                        label = { Text(mode.arabicLabel) },
                        modifier = Modifier.testTag("inv_barcode_source_${mode.name}"),
                    )
                }
            }
        }

        item {
            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("رسم الباركود بشكل مرئي قابل للمسح", fontWeight = FontWeight.SemiBold)
                    Text("إيقافه يعرض رقم الباركود كنص واضح فقط", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = config.renderBarcodeGraphic,
                    onCheckedChange = { checked -> onUpdateConfig { it.copy(renderBarcodeGraphic = checked) } },
                    modifier = Modifier.testTag("inv_barcode_graphic_switch"),
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("إظهار رقم الباركود أسفل الخطوط", fontWeight = FontWeight.SemiBold)
                    Text("يُبقي الأصفار البادئة كما هي (مثال: 001234)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    enabled = config.renderBarcodeGraphic,
                    checked = config.showBarcodeTextBelow,
                    onCheckedChange = { checked -> onUpdateConfig { it.copy(showBarcodeTextBelow = checked) } },
                )
            }
        }

        item {
            HorizontalDivider()
            Text("نوع / صيغة رسم الباركود", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(
                    selected = config.barcodeFormatOverride.equals("AUTO", true),
                    onClick = { onUpdateConfig { it.copy(barcodeFormatOverride = "AUTO") } },
                    label = { Text("تلقائي حسب الصنف") },
                )
                BarcodeEngine.PRIMARY_SUPPORTED_FORMATS.forEach { fmt ->
                    FilterChip(
                        selected = config.barcodeFormatOverride == fmt.name,
                        onClick = { onUpdateConfig { it.copy(barcodeFormatOverride = fmt.name) } },
                        label = { Text(fmt.arabicLabel) },
                    )
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        onUpdateConfig { it.copy(barcodeHeightPt = (it.barcodeHeightPt - 4f).coerceAtLeast(18f)) }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("تقليل ارتفاع الباركود (${config.barcodeHeightPt.toInt()}pt)") }
                OutlinedButton(
                    onClick = {
                        onUpdateConfig { it.copy(barcodeHeightPt = (it.barcodeHeightPt + 4f).coerceAtMost(56f)) }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("زيادة الارتفاع +4") }
            }
        }

        item {
            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("إظهار صور المنتجات داخل الجدول والتصدير", fontWeight = FontWeight.SemiBold)
                    Text("عند الإيقاف تبقى بيانات الكشف دون عرض الصور", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = config.showProductImages,
                    onCheckedChange = { checked -> onUpdateConfig { it.copy(showProductImages = checked) } },
                )
            }
        }
    }
}

@Composable
private fun PrintAndPageTab(
    config: InventorySheetConfig,
    onUpdateConfig: ((InventorySheetConfig) -> InventorySheetConfig) -> Unit,
    onOpenPrintPreview: () -> Unit,
    onPrintNow: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("حجم الورقة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                PaperSizeType.entries.forEach { size ->
                    FilterChip(
                        selected = config.paperSize == size,
                        onClick = { onUpdateConfig { it.copy(paperSize = size) } },
                        label = { Text(size.arabicLabel) },
                    )
                }
            }
        }

        item {
            Text("اتجاه الصفحة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PageOrientation.entries.forEach { ori ->
                    FilterChip(
                        selected = config.orientation == ori,
                        onClick = { onUpdateConfig { it.copy(orientation = ori) } },
                        label = { Text(ori.arabicLabel) },
                        modifier = Modifier.testTag("inv_orientation_${ori.name}"),
                    )
                }
            }
        }

        item {
            Text("الهوامش (مم)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(5f to "ضيق (5 مم)", 8f to "قياسي (8 مم)", 12f to "واسع (12 مم)").forEach { (mm, label) ->
                    FilterChip(
                        selected = kotlin.math.abs(config.marginStartMm - mm) < 0.5f,
                        onClick = {
                            onUpdateConfig {
                                it.copy(marginStartMm = mm, marginEndMm = mm, marginTopMm = mm + 2f, marginBottomMm = mm + 2f)
                            }
                        },
                        label = { Text(label) },
                    )
                }
            }
        }

        item {
            HorizontalDivider()
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("تكرار رأس الجدول في كل صفحة PDF")
                    Switch(
                        checked = config.repeatTableHeader,
                        onCheckedChange = { c -> onUpdateConfig { it.copy(repeatTableHeader = c) } },
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("ترقيم الصفحات (صفحة X من Y)")
                    Switch(
                        checked = config.showPageNumbers,
                        onCheckedChange = { c -> onUpdateConfig { it.copy(showPageNumbers = c) } },
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("تذييل إجمالي المنتجات والكميات")
                    Switch(
                        checked = config.showTotalsFooter,
                        onCheckedChange = { c -> onUpdateConfig { it.copy(showTotalsFooter = c) } },
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("إظهار ملاحظات الكشف في النهاية")
                    Switch(
                        checked = config.showSessionNotes,
                        onCheckedChange = { c -> onUpdateConfig { it.copy(showSessionNotes = c) } },
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("تقسيم الأعمدة الزائدة على صفحات أفقية")
                    Switch(
                        checked = config.splitHorizontalGroups,
                        onCheckedChange = { c -> onUpdateConfig { it.copy(splitHorizontalGroups = c) } },
                    )
                }
            }
        }

        item {
            HorizontalDivider()
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = onOpenPrintPreview,
                    modifier = Modifier.weight(1f).testTag("inv_sheet_preview_btn"),
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("معاينة قبل الطباعة")
                }
                Button(
                    onClick = onPrintNow,
                    modifier = Modifier.weight(1f).testTag("inv_sheet_print_btn"),
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("طباعة مباشرة")
                }
            }
        }
    }
}
