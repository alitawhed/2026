package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.ProductSelectionViewMode
import com.example.ui.theme.BrandEmerald
import java.util.Locale

private enum class InvPickerFilterOption(val label: String) {
    ALL("الكل"),
    HAS_IMAGES("لديها صور"),
    MULTI_BARCODE("متعددة الباركودات"),
    IN_SHEET("مسجل بالكشف"),
    NOT_IN_SHEET("غير مسجل بالكشف"),
}

private enum class InvPickerSortOption(val label: String) {
    NEWEST("الأحدث"),
    NAME_ASC("الاسم (أ - ي)"),
    PRICE_DESC("السعر (الأعلى)"),
    PRICE_ASC("السعر (الأقل)"),
}

@Composable
fun InventoryProductSearchDialog(
    allProducts: List<ProductWithDetails>,
    activeSession: InventorySessionWithDetails?,
    inventoryConfig: InventorySheetConfig,
    onDismiss: () -> Unit,
    onSelectProduct: (ProductWithDetails, String?) -> Unit,
    onLaunchCamera: () -> Unit,
    onCreateNewProduct: (String) -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterOption by remember { mutableStateOf(InvPickerFilterOption.ALL) }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var sortOption by remember { mutableStateOf(InvPickerSortOption.NEWEST) }
    var viewMode by remember { mutableStateOf(ProductSelectionViewMode.LIST) }

    var showCategoryMenu by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showViewModeMenu by remember { mutableStateOf(false) }

    var galleryTargetProduct by remember { mutableStateOf<ProductWithDetails?>(null) }
    var barcodeChoiceProduct by remember { mutableStateOf<ProductWithDetails?>(null) }

    val qtySpec = remember(inventoryConfig.columns) {
        NumberFormatEngine.resolveInventoryColumnSpec(inventoryConfig.columns, "quantity")
    }

    val sessionItemsByProductId = remember(activeSession) {
        activeSession?.items?.filter { it.productId != null }?.groupBy { it.productId!! }.orEmpty()
    }
    val sessionItemsByBarcode = remember(activeSession) {
        activeSession?.items?.associateBy { it.scannedBarcode }.orEmpty()
    }

    val categories = remember(allProducts) {
        listOf("الكل") + allProducts
            .mapNotNull { it.product.categoryName.trim().takeIf { c -> c.isNotEmpty() } }
            .distinct()
            .sorted()
    }

    val filteredProducts = remember(allProducts, searchQuery, filterOption, selectedCategory, sortOption, sessionItemsByProductId) {
        val q = searchQuery.trim()
        val unified = if (q.isEmpty()) {
            allProducts
        } else {
            allProducts.filter { item ->
                item.product.name.contains(q, ignoreCase = true) ||
                    item.product.internalCode.contains(q, ignoreCase = true) ||
                    item.product.description.contains(q, ignoreCase = true) ||
                    item.product.categoryName.contains(q, ignoreCase = true) ||
                    item.product.customFieldsJson.contains(q, ignoreCase = true) ||
                    item.barcodes.any { b ->
                        b.barcodeValue.contains(q, ignoreCase = true) ||
                            b.label.contains(q, ignoreCase = true) ||
                            b.description.contains(q, ignoreCase = true) ||
                            b.unitType.contains(q, ignoreCase = true)
                    }
            }
        }

        val matched = unified.filter { p ->
            val matchesCat = selectedCategory == "الكل" ||
                p.product.categoryName.equals(selectedCategory, ignoreCase = true)
            val inSheet = sessionItemsByProductId[p.product.id]?.isNotEmpty() == true
            val matchesFilter = when (filterOption) {
                InvPickerFilterOption.ALL -> true
                InvPickerFilterOption.HAS_IMAGES -> p.images.isNotEmpty()
                InvPickerFilterOption.MULTI_BARCODE -> p.barcodes.size > 1
                InvPickerFilterOption.IN_SHEET -> inSheet
                InvPickerFilterOption.NOT_IN_SHEET -> !inSheet
            }
            matchesCat && matchesFilter
        }

        when (sortOption) {
            InvPickerSortOption.NEWEST -> matched.sortedByDescending { it.product.updatedAt }
            InvPickerSortOption.NAME_ASC -> matched.sortedBy { it.product.name.lowercase(Locale.ROOT) }
            InvPickerSortOption.PRICE_DESC -> matched.sortedByDescending { it.product.basePrice }
            InvPickerSortOption.PRICE_ASC -> matched.sortedBy { it.product.basePrice }
        }
    }

    fun handlePickProduct(product: ProductWithDetails) {
        if (product.barcodes.size > 1) {
            barcodeChoiceProduct = product
        } else {
            val singleCode = product.primaryBarcode?.barcodeValue ?: product.barcodes.firstOrNull()?.barcodeValue
            onSelectProduct(product, singleCode)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            Scaffold(
                topBar = {
                    AppScreenTopBar(
                        title = "البحث عن منتج للجرد",
                        subtitle = activeSession?.let { "${it.session.title} • ${allProducts.size} منتج متاح" },
                        onBack = onDismiss,
                        actions = {
                            IconButton(
                                onClick = {
                                    onDismiss()
                                    onLaunchCamera()
                                },
                                modifier = Modifier.testTag("inv_picker_camera_btn"),
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود بالكاميرا")
                            }
                            Box {
                                IconButton(
                                    onClick = { showViewModeMenu = true },
                                    modifier = Modifier.testTag("inv_picker_view_mode_btn"),
                                ) {
                                    Icon(
                                        when (viewMode) {
                                            ProductSelectionViewMode.LIST -> Icons.AutoMirrored.Filled.FormatListBulleted
                                            ProductSelectionViewMode.GRID -> Icons.Default.GridView
                                            ProductSelectionViewMode.COMPACT -> Icons.Default.ViewHeadline
                                            ProductSelectionViewMode.DETAILED -> Icons.Default.ViewAgenda
                                        },
                                        contentDescription = "نمط العرض",
                                    )
                                }
                                DropdownMenu(expanded = showViewModeMenu, onDismissRequest = { showViewModeMenu = false }) {
                                    ProductSelectionViewMode.entries.forEach { mode ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    mode.arabicLabel,
                                                    fontWeight = if (viewMode == mode) FontWeight.Bold else FontWeight.Normal,
                                                )
                                            },
                                            onClick = {
                                                viewMode = mode
                                                showViewModeMenu = false
                                            },
                                        )
                                    }
                                }
                            }
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.testTag("inv_picker_close_btn"),
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        },
                    )
                },
                bottomBar = {
                    Surface(
                        tonalElevation = 2.dp,
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "المعروض: ${filteredProducts.size} • بالكشف: ${activeSession?.items?.size ?: 0}",
                                style = MaterialTheme.typography.labelMedium,
                            )
                            FilledTonalButton(
                                onClick = { onCreateNewProduct(searchQuery) },
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("inv_picker_create_product_btn"),
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("إضافة منتج جديد")
                            }
                        }
                    }
                },
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("بحث بالاسم، الباركود، GTIN، الرقم الداخلي، التصنيف...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("inv_picker_search_input"),
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box {
                            AssistChip(
                                onClick = { showCategoryMenu = true },
                                label = { Text("التصنيف: $selectedCategory") },
                            )
                            DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat) },
                                        onClick = {
                                            selectedCategory = cat
                                            showCategoryMenu = false
                                        },
                                    )
                                }
                            }
                        }

                        Box {
                            AssistChip(
                                onClick = { showSortMenu = true },
                                leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text(sortOption.label) },
                            )
                            DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                                InvPickerSortOption.entries.forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(opt.label) },
                                        onClick = {
                                            sortOption = opt
                                            showSortMenu = false
                                        },
                                    )
                                }
                            }
                        }

                        InvPickerFilterOption.entries.forEach { opt ->
                            FilterChip(
                                selected = filterOption == opt,
                                onClick = { filterOption = opt },
                                label = { Text(opt.label) },
                            )
                        }
                    }

                    if (filteredProducts.isEmpty()) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(16.dp),
                            ) {
                                EmptyStateCard(
                                    title = "لا توجد منتجات مطابقة",
                                    description = if (searchQuery.isNotBlank()) {
                                        "لم يتم العثور على منتج يطابق «${searchQuery.trim()}». يمكنك إضافته الآن للقاعدة الرئيسية وإدراجه في كشف الجرد مباشرة."
                                    } else {
                                        "جرّب تغيير كلمات البحث أو الفلاتر، أو أضف منتجاً جديداً للقاعدة الرئيسية."
                                    },
                                )
                                Button(
                                    onClick = { onCreateNewProduct(searchQuery) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("inv_picker_empty_create_btn"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("إضافة منتج جديد")
                                }
                                if (searchQuery.isNotBlank() || filterOption != InvPickerFilterOption.ALL || selectedCategory != "الكل") {
                                    TextButton(
                                        onClick = {
                                            searchQuery = ""
                                            filterOption = InvPickerFilterOption.ALL
                                            selectedCategory = "الكل"
                                        },
                                    ) {
                                        Text("إعادة ضبط البحث والفلاتر")
                                    }
                                }
                            }
                        }
                    } else {
                        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            val gridCols = if (maxWidth >= 600.dp) 3 else 2

                            if (viewMode == ProductSelectionViewMode.GRID) {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(gridCols),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(bottom = 12.dp),
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    gridItems(filteredProducts, key = { it.product.id }) { prod ->
                                        val recordedItems = sessionItemsByProductId[prod.product.id].orEmpty()
                                        val totalRecordedQty = recordedItems.sumOf { it.countedQty }
                                        InvPickerGridCard(
                                            product = prod,
                                            recordedLineCount = recordedItems.size,
                                            recordedSummary = if (recordedItems.isNotEmpty()) {
                                                NumberFormatEngine.formatDouble(totalRecordedQty, qtySpec)
                                            } else null,
                                            onSelect = { handlePickProduct(prod) },
                                            onOpenGallery = { galleryTargetProduct = prod },
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(bottom = 12.dp),
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    items(filteredProducts, key = { it.product.id }) { prod ->
                                        val recordedItems = sessionItemsByProductId[prod.product.id].orEmpty()
                                        val totalRecordedQty = recordedItems.sumOf { it.countedQty }
                                        val recordedSummary = if (recordedItems.isNotEmpty()) {
                                            val firstUnit = recordedItems.firstOrNull()?.unitType.orEmpty()
                                            "${NumberFormatEngine.formatDouble(totalRecordedQty, qtySpec)} $firstUnit".trim()
                                        } else null

                                        when (viewMode) {
                                            ProductSelectionViewMode.COMPACT -> InvPickerCompactRow(
                                                product = prod,
                                                recordedLineCount = recordedItems.size,
                                                recordedSummary = recordedSummary,
                                                onSelect = { handlePickProduct(prod) },
                                                onOpenGallery = { galleryTargetProduct = prod },
                                            )
                                            ProductSelectionViewMode.DETAILED -> InvPickerDetailedCard(
                                                product = prod,
                                                recordedLineCount = recordedItems.size,
                                                recordedSummary = recordedSummary,
                                                onSelect = { handlePickProduct(prod) },
                                                onOpenGallery = { galleryTargetProduct = prod },
                                            )
                                            else -> InvPickerListCard(
                                                product = prod,
                                                recordedLineCount = recordedItems.size,
                                                recordedSummary = recordedSummary,
                                                onSelect = { handlePickProduct(prod) },
                                                onOpenGallery = { galleryTargetProduct = prod },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Barcode/Unit selection dialog for multi-barcode products
    barcodeChoiceProduct?.let { prod ->
        var chosenBarcode by remember(prod.product.id) {
            mutableStateOf(prod.primaryBarcode?.barcodeValue ?: prod.barcodes.firstOrNull()?.barcodeValue.orEmpty())
        }
        AlertDialog(
            onDismissRequest = { barcodeChoiceProduct = null },
            title = {
                Text(
                    "اختر الباركود والوحدة — ${prod.product.name}",
                    fontWeight = FontWeight.Bold,
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        "هذا المنتج مرتبط بأكثر من باركود/وحدة. اختر الباركود المطلوب جرده:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    HorizontalDivider()
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(prod.barcodes, key = { it.id }) { bc ->
                            val existingForBc = sessionItemsByBarcode[bc.barcodeValue]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { chosenBarcode = bc.barcodeValue }
                                    .padding(horizontal = 4.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                RadioButton(
                                    selected = chosenBarcode == bc.barcodeValue,
                                    onClick = { chosenBarcode = bc.barcodeValue },
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(bc.barcodeValue, fontWeight = FontWeight.Bold)
                                    val factorSuffix = if (bc.conversionFactor != 1.0) {
                                        " (معامل × ${NumberFormatEngine.formatEditableNumber(bc.conversionFactor)})"
                                    } else ""
                                    Text(
                                        "${bc.label.ifBlank { bc.unitType }} • ${bc.unitType}$factorSuffix" +
                                            if (bc.isPrimary) " • رئيسي" else "",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    existingForBc?.let { prev ->
                                        Text(
                                            "مسجل مسبقاً: ${NumberFormatEngine.formatDouble(prev.countedQty, qtySpec)} ${prev.unitType}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = BrandEmerald,
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = chosenBarcode.isNotBlank(),
                    onClick = {
                        val selectedCode = chosenBarcode
                        barcodeChoiceProduct = null
                        onSelectProduct(prod, selectedCode)
                    },
                    modifier = Modifier.testTag("inv_picker_barcode_choice_confirm_btn"),
                ) {
                    Text("اختيار هذا الباركود")
                }
            },
            dismissButton = {
                TextButton(onClick = { barcodeChoiceProduct = null }) { Text("إلغاء") }
            },
        )
    }

    // Read-only image gallery preview dialog
    galleryTargetProduct?.let { prod ->
        InvProductGalleryDialog(
            product = prod,
            onDismiss = { galleryTargetProduct = null },
        )
    }
}

@Composable
private fun InvProductThumb(
    product: ProductWithDetails,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(modifier = modifier) {
        ProductEntityImageBox(
            image = product.primaryImage,
            contentDescription = product.product.name,
            preferThumbnail = true,
            contentScale = ContentScale.Crop,
            showDiagnosticsOnError = false,
            modifier = Modifier.fillMaxSize(),
            onClick = onClick,
        )
        if (product.images.size > 1) {
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Icon(Icons.Default.Collections, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                    Text("${product.images.size}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun InvPickerListCard(
    product: ProductWithDetails,
    recordedLineCount: Int,
    recordedSummary: String?,
    onSelect: () -> Unit,
    onOpenGallery: () -> Unit,
) {
    val primaryCode = product.primaryBarcode?.barcodeValue ?: product.product.internalCode
    val extraBarcodeCount = (product.barcodes.size - 1).coerceAtLeast(0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("inv_picker_item_${product.product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (recordedLineCount > 0) 1.5.dp else 1.dp,
            color = if (recordedLineCount > 0) BrandEmerald.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            InvProductThumb(
                product = product,
                modifier = Modifier.size(72.dp),
                onClick = onOpenGallery,
            )

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        product.product.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (recordedSummary != null) {
                        Surface(
                            color = BrandEmerald.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrandEmerald, modifier = Modifier.size(12.dp))
                                Text(
                                    "مسجل: $recordedSummary",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BrandEmerald,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }

                Text(
                    buildString {
                        if (product.product.internalCode.isNotBlank()) {
                            append("ID: ${product.product.internalCode} • ")
                        }
                        append(primaryCode.ifBlank { "بدون باركود" })
                        if (extraBarcodeCount > 0) append(" (+$extraBarcodeCount إضافي)")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        formatCurrencyValue(product.product.basePrice, product.product.currency),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    if (product.product.categoryName.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Text(
                                product.product.categoryName,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }

            FilledTonalButton(
                onClick = onSelect,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("inv_picker_select_btn_${product.product.id}"),
            ) {
                Icon(Icons.Default.Add, contentDescription = "اختيار المنتج", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("اختيار")
            }
        }
    }
}

@Composable
private fun InvPickerGridCard(
    product: ProductWithDetails,
    recordedLineCount: Int,
    recordedSummary: String?,
    onSelect: () -> Unit,
    onOpenGallery: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("inv_picker_item_${product.product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (recordedLineCount > 0) 1.5.dp else 1.dp,
            color = if (recordedLineCount > 0) BrandEmerald else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box {
                InvProductThumb(
                    product = product,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1.15f),
                    onClick = onOpenGallery,
                )
                if (recordedSummary != null) {
                    Badge(
                        containerColor = BrandEmerald,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                    ) {
                        Text("✓ $recordedSummary", color = Color.White)
                    }
                }
            }

            Text(
                product.product.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                buildString {
                    if (product.product.internalCode.isNotBlank()) {
                        append("${product.product.internalCode} • ")
                    }
                    append(product.primaryBarcode?.barcodeValue ?: "بدون باركود")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    formatCurrencyValue(product.product.basePrice, product.product.currency),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                )
                IconButton(
                    onClick = onSelect,
                    modifier = Modifier.size(48.dp),
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = "اختيار", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun InvPickerCompactRow(
    product: ProductWithDetails,
    recordedLineCount: Int,
    recordedSummary: String?,
    onSelect: () -> Unit,
    onOpenGallery: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        tonalElevation = 1.dp,
        border = BorderStroke(
            1.dp,
            if (recordedLineCount > 0) BrandEmerald else MaterialTheme.colorScheme.outlineVariant,
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("inv_picker_item_${product.product.id}"),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            InvProductThumb(product = product, modifier = Modifier.size(44.dp), onClick = onOpenGallery)
            Column(modifier = Modifier.weight(1f)) {
                Text(product.product.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${product.primaryBarcode?.barcodeValue ?: "-"} • ${formatCurrencyValue(product.product.basePrice, product.product.currency)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            if (recordedSummary != null) {
                Text(
                    recordedSummary,
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandEmerald,
                    fontWeight = FontWeight.Bold,
                )
            }
            IconButton(
                onClick = onSelect,
                modifier = Modifier.size(48.dp),
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = "اختيار", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun InvPickerDetailedCard(
    product: ProductWithDetails,
    recordedLineCount: Int,
    recordedSummary: String?,
    onSelect: () -> Unit,
    onOpenGallery: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("inv_picker_item_${product.product.id}"),
        border = BorderStroke(
            1.dp,
            if (recordedLineCount > 0) BrandEmerald else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InvProductThumb(product = product, modifier = Modifier.size(88.dp), onClick = onOpenGallery)
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(product.product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "الكود الداخلي: ${product.product.internalCode} • التصنيف: ${product.product.categoryName.ifBlank { "غير مصنف" }}",
                        style = MaterialTheme.typography.labelSmall,
                    )
                    if (product.product.manufacturer.isNotBlank() || product.product.originCountry.isNotBlank()) {
                        Text(
                            "${product.product.manufacturer} ${product.product.originCountry}".trim(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        formatCurrencyValue(product.product.basePrice, product.product.currency),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    if (recordedSummary != null) {
                        Text(
                            "مسجل بالكشف: $recordedSummary",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandEmerald,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            if (product.product.description.isNotBlank()) {
                Text(product.product.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                product.barcodes.forEach { b ->
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            if (b.isPrimary) "رئيسي: ${b.barcodeValue}" else b.barcodeValue,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        )
                    }
                }
            }
            Button(
                onClick = onSelect,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("اختيار وتحديد الكمية")
            }
        }
    }
}

@Composable
private fun InvProductGalleryDialog(
    product: ProductWithDetails,
    onDismiss: () -> Unit,
) {
    val images = remember(product) {
        product.images.sortedWith(compareByDescending<ProductImageEntity> { it.isPrimary }.thenBy { it.sortOrder })
    }
    var activeIndex by remember(images) { mutableIntStateOf(0) }
    var scale by remember(activeIndex) { mutableFloatStateOf(1f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (images.isEmpty()) "لا توجد صور" else "الصورة ${activeIndex + 1} من ${images.size}",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                if (images.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        ProductEntityImageBox(
                            image = null,
                            contentDescription = "بدون صورة",
                            modifier = Modifier.size(160.dp),
                        )
                    }
                } else {
                    val current = images[activeIndex.coerceIn(images.indices)]
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.08f))
                            .pointerInput(activeIndex) {
                                detectTransformGestures { _, _, zoom, _ ->
                                    scale = (scale * zoom).coerceIn(1f, 4f)
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        ProductEntityImageBox(
                            image = current,
                            contentDescription = product.product.name,
                            preferThumbnail = false,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(scaleX = scale, scaleY = scale),
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التكبير: ${String.format(Locale.US, "%.1fx", scale)}", style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = scale,
                            onValueChange = { scale = it },
                            valueRange = 1f..4f,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    if (images.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(images.indices.toList()) { idx ->
                                val img = images[idx]
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .border(
                                            width = if (idx == activeIndex) 2.5.dp else 1.dp,
                                            color = if (idx == activeIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                            shape = RoundedCornerShape(8.dp),
                                        ),
                                ) {
                                    ProductEntityImageBox(
                                        image = img,
                                        contentDescription = "صورة ${idx + 1}",
                                        preferThumbnail = true,
                                        modifier = Modifier.fillMaxSize(),
                                        onClick = { activeIndex = idx },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
