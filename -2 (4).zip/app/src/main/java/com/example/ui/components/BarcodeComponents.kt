package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.barcode.BarcodeService
import com.example.domain.model.BarcodeFormatType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CachedBarcodeImage(
    productId: Long?,
    barcodeValue: String,
    format: BarcodeFormatType,
    modifier: Modifier = Modifier,
    barcodeService: BarcodeService? = null,
    baseWidthPx: Int = 720,
    baseHeightPx: Int = 260,
    showTextBelow: Boolean = true,
    quietZoneModules: Int = 12,
    dpi: Int = 300,
    allowTapToZoom: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val clean = barcodeValue.trim()
    val cacheGenState = barcodeService?.cacheGeneration?.collectAsStateWithLifecycle(initialValue = 0L)
    val cacheGen = cacheGenState?.value ?: 0L

    var showZoom by remember { mutableStateOf(false) }

    val bitmap by produceState<Bitmap?>(
        initialValue = null,
        productId,
        clean,
        format,
        baseWidthPx,
        baseHeightPx,
        showTextBelow,
        quietZoneModules,
        dpi,
        cacheGen,
        barcodeService,
    ) {
        value = if (clean.isEmpty()) {
            null
        } else if (barcodeService != null) {
            barcodeService.getOrGenerateBarcodeBitmap(
                productId = productId,
                barcodeValue = clean,
                format = format,
                baseWidthPx = baseWidthPx,
                baseHeightPx = baseHeightPx,
                showText = showTextBelow,
                quietZoneModules = quietZoneModules,
                dpi = dpi,
            )
        } else {
            withContext(Dispatchers.IO) {
                BarcodeEngine.generateHighResBitmap(
                    value = clean,
                    format = format,
                    widthPx = baseWidthPx,
                    heightPx = baseHeightPx,
                    showText = showTextBelow,
                    quietZoneModules = quietZoneModules,
                )
            }
        }
    }

    val effectiveClick: (() -> Unit)? = when {
        onClick != null -> onClick
        allowTapToZoom && bitmap != null -> ({ showZoom = true })
        else -> null
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .then(
                if (effectiveClick != null) {
                    Modifier.clickable(onClick = effectiveClick)
                } else {
                    Modifier
                },
            ),
        // White high-contrast optical surface is required for optical barcode scannability
        color = Color.White,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        val currentBmp = bitmap
        if (currentBmp != null && !currentBmp.isRecycled) {
            Box(contentAlignment = Alignment.Center) {
                Image(
                    bitmap = currentBmp.asImageBitmap(),
                    contentDescription = "صورة باركود ${format.arabicLabel} للقيمة $clean",
                    contentScale = ContentScale.Fit,
                    filterQuality = FilterQuality.None,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = "تعذر رسم الباركود",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    text = if (clean.isEmpty()) "بدون رقم باركود" else "تعذر رسم (${format.arabicLabel})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }

    if (showZoom) {
        BarcodeZoomDialog(
            barcodeValue = clean,
            format = format,
            productId = productId,
            barcodeService = barcodeService,
            onDismiss = { showZoom = false },
        )
    }
}

@Composable
fun BarcodeZoomDialog(
    barcodeValue: String,
    format: BarcodeFormatType,
    productId: Long? = null,
    barcodeService: BarcodeService? = null,
    onDismiss: () -> Unit,
) {
    var zoomScale by remember { mutableFloatStateOf(1f) }

    val highResBitmap by produceState<Bitmap?>(initialValue = null, barcodeValue, format, productId, barcodeService) {
        value = if (barcodeService != null) {
            barcodeService.getOrGenerateBarcodeBitmap(
                productId = productId,
                barcodeValue = barcodeValue,
                format = format,
                baseWidthPx = 1200,
                baseHeightPx = if (format.is2D) 900 else 440,
                showText = true,
                quietZoneModules = 14,
                dpi = 600,
            )
        } else {
            withContext(Dispatchers.IO) {
                BarcodeEngine.generateHighResBitmap(
                    value = barcodeValue,
                    format = format,
                    widthPx = if (format.is2D) 900 else 1200,
                    heightPx = if (format.is2D) 900 else 440,
                    showText = true,
                    quietZoneModules = 14,
                )
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "معاينة وتكبير الباركود",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = format.arabicLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("barcode_zoom_close_button"),
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق المعاينة")
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 210.dp, max = 340.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                zoomScale = (zoomScale * zoom).coerceIn(1f, 3.5f)
                            }
                        },
                    color = Color.White,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    val bmp = highResBitmap
                    if (bmp != null && !bmp.isRecycled) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "باركود مكبر $barcodeValue",
                                contentScale = ContentScale.Fit,
                                filterQuality = FilterQuality.None,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .graphicsLayer(
                                        scaleX = zoomScale,
                                        scaleY = zoomScale,
                                    ),
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = "تعذر رسم الباركود بالصيغة الحالية (${format.arabicLabel})",
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = barcodeValue,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                ) {
                    listOf(1f to "1x", 1.75f to "1.75x", 2.5f to "2.5x").forEach { (target, label) ->
                        FilterChip(
                            selected = kotlin.math.abs(zoomScale - target) < 0.2f,
                            onClick = { zoomScale = target },
                            label = { Text(label) },
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("barcode_zoom_$label"),
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BarcodeFormatChangeDialog(
    barcodeValue: String,
    currentFormat: BarcodeFormatType,
    productName: String? = null,
    availableScopes: List<BarcodeFormatChangeScope>,
    initialScope: BarcodeFormatChangeScope = availableScopes.first(),
    bulkCount: Int = 0,
    onDismiss: () -> Unit,
    onConfirmChange: (
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefaultSetting: Boolean,
    ) -> Unit,
    onGenerateAlternativeInternal: (() -> Unit)? = null,
) {
    val cleanCode = barcodeValue.trim()
    var selectedFormat by remember(currentFormat) { mutableStateOf(currentFormat) }
    var selectedScope by remember(availableScopes, initialScope) {
        mutableStateOf(
            if (initialScope in availableScopes) initialScope else availableScopes.first(),
        )
    }
    var alsoUpdateDefault by remember { mutableStateOf(false) }
    var showBulkConfirmAlert by remember { mutableStateOf(false) }
    var showZoomPreview by remember { mutableStateOf(false) }

    val isBulkSampleMode = selectedScope == BarcodeFormatChangeScope.SELECTED_PRODUCTS && bulkCount > 1
    val validation = remember(cleanCode, selectedFormat) {
        BarcodeEngine.validate(cleanCode, selectedFormat)
    }

    val previewBitmap by produceState<Bitmap?>(
        initialValue = null,
        cleanCode,
        selectedFormat,
        validation.isValid,
    ) {
        value = if (cleanCode.isNotEmpty() && validation.isValid) {
            withContext(Dispatchers.IO) {
                BarcodeEngine.generateHighResBitmap(
                    value = cleanCode,
                    format = selectedFormat,
                    widthPx = if (selectedFormat.is2D) 420 else 760,
                    heightPx = if (selectedFormat.is2D) 420 else 250,
                    showText = true,
                    quietZoneModules = 12,
                )
            }
        } else {
            null
        }
    }

    val canConfirm = when {
        selectedScope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING -> true
        isBulkSampleMode -> true // Skips incompatible cleanly while keeping original numbers
        selectedScope == BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION -> true
        selectedScope == BarcodeFormatChangeScope.CURRENT_REPORT -> true
        else -> validation.isValid
    }

    val requiresSecondConfirm = selectedScope == BarcodeFormatChangeScope.SELECTED_PRODUCTS ||
        selectedScope == BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION ||
        selectedScope == BarcodeFormatChangeScope.CURRENT_REPORT

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = "تغيير نوع الباركود",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
                if (!productName.isNullOrBlank()) {
                    Text(
                        text = productName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Current Barcode Value + Current Format Pill
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (cleanCode.isNotEmpty()) {
                            Text(
                                text = "الرقم الأصلي (محفوظ دون تعديل): $cleanCode",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                fontWeight = FontWeight.SemiBold,
                            )
                        } else if (isBulkSampleMode) {
                            Text(
                                text = "تغيير جماعي لعدد $bulkCount منتج محدد",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(99.dp),
                        ) {
                            Text(
                                text = "النوع الحالي: ${currentFormat.arabicLabel}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            )
                        }
                    }
                }

                // Supported Formats Selector with Live Compatibility Indicator
                Text(
                    text = "اختر النوع الجديد المدعوم:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    BarcodeEngine.PRIMARY_SUPPORTED_FORMATS.forEach { fmt ->
                        val fmtValid = if (cleanCode.isEmpty()) true else BarcodeEngine.isCompatible(cleanCode, fmt)
                        val isSelected = selectedFormat == fmt
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFormat = fmt },
                            leadingIcon = if (isSelected) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            label = {
                                val badge = if (cleanCode.isNotEmpty() && !isBulkSampleMode) {
                                    if (fmtValid) " ✓" else " ✕"
                                } else ""
                                Text("${fmt.arabicLabel}$badge")
                            },
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("barcode_format_chip_${fmt.name.lowercase()}"),
                        )
                    }
                }

                Text(
                    text = BarcodeEngine.formatRequirementsArabic(selectedFormat),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // Live Preview or Clear Compatibility Error Banner
                if (cleanCode.isNotEmpty() && selectedScope != BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING && !isBulkSampleMode) {
                    if (validation.isValid) {
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showZoomPreview = true },
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                val bmp = previewBitmap
                                if (bmp != null && !bmp.isRecycled) {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "معاينة الباركود بصيغة ${selectedFormat.arabicLabel}",
                                        contentScale = ContentScale.Fit,
                                        filterQuality = FilterQuality.None,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(104.dp),
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Icon(
                                        Icons.Default.ZoomIn,
                                        contentDescription = "تكبير المعاينة",
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.primary,
                                    )
                                    Text(
                                        text = "معاينة حية (${selectedFormat.arabicLabel}) — اضغط للتكبير",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Icon(
                                        Icons.Default.WarningAmber,
                                        contentDescription = "عدم توافق الصيغة",
                                        tint = MaterialTheme.colorScheme.error,
                                    )
                                    Text(
                                        text = validation.errorMessage ?: "الرقم الحالي لا يطابق شروط ${selectedFormat.arabicLabel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Medium,
                                    )
                                }
                                Text(
                                    text = "يُحافظ النظام على الرقم الأصلي دون تعديل تلقائي.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                )
                                if (onGenerateAlternativeInternal != null) {
                                    OutlinedButton(
                                        onClick = {
                                            onDismiss()
                                            onGenerateAlternativeInternal()
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 48.dp)
                                            .testTag("generate_alternative_internal_barcode_btn"),
                                    ) {
                                        Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("إنشاء باركود داخلي بديل مع إبقاء الأصلي")
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider()

                // Scope Selection
                Text(
                    text = "نطاق التطبيق:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    availableScopes.forEach { scopeOption ->
                        val chosen = selectedScope == scopeOption
                        Surface(
                            color = if (chosen) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            } else {
                                Color.Transparent
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedScope = scopeOption }
                                .testTag("barcode_scope_${scopeOption.name.lowercase()}"),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                RadioButton(
                                    selected = chosen,
                                    onClick = { selectedScope = scopeOption },
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = scopeOption.arabicLabel,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Text(
                                        text = scopeOption.description,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }

                if (selectedScope != BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { alsoUpdateDefault = !alsoUpdateDefault }
                            .padding(vertical = 4.dp)
                            .testTag("barcode_also_update_default_checkbox"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = alsoUpdateDefault,
                            onCheckedChange = { alsoUpdateDefault = it },
                        )
                        Text(
                            text = "تعيين (${selectedFormat.arabicLabel}) أيضاً كافتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (requiresSecondConfirm) {
                        showBulkConfirmAlert = true
                    } else {
                        onConfirmChange(selectedFormat, selectedScope, alsoUpdateDefault)
                    }
                },
                enabled = canConfirm,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("confirm_barcode_format_change_btn"),
            ) {
                Text("تأكيد التغيير")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("cancel_barcode_format_change_btn"),
            ) {
                Text("إلغاء")
            }
        },
    )

    if (showBulkConfirmAlert) {
        val scopeSummary = when (selectedScope) {
            BarcodeFormatChangeScope.SELECTED_PRODUCTS ->
                "سيتم تحديث نوع الباركود للمنتجات المحددة ($bulkCount) إلى ${selectedFormat.arabicLabel}. أي منتج لا يتوافق رقمه مع هذه الصيغة سيتم تخطيه مع إبقاء رقمه الأصلي دون تعديل."
            BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION ->
                "سيتم تحديث نوع الباركود لبنود كشف الجرد الحالي فقط إلى ${selectedFormat.arabicLabel} مع تخطي البنود غير المتوافقة دون تغيير أرقامها."
            BarcodeFormatChangeScope.CURRENT_REPORT ->
                "سيتم تحديث نوع الباركود لجميع عناصر التقرير الحالي المتوافقة إلى ${selectedFormat.arabicLabel} مع تخطي غير المتوافق."
            else -> "تأكيد تنفيذ تغيير نوع الباركود؟"
        }
        AlertDialog(
            onDismissRequest = { showBulkConfirmAlert = false },
            title = { Text("تأكيد التغيير الجماعي", fontWeight = FontWeight.Bold) },
            text = { Text(scopeSummary) },
            confirmButton = {
                Button(
                    onClick = {
                        showBulkConfirmAlert = false
                        onConfirmChange(selectedFormat, selectedScope, alsoUpdateDefault)
                    },
                    modifier = Modifier.testTag("confirm_bulk_barcode_change_btn"),
                ) {
                    Text("نعم، تطبيق")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showBulkConfirmAlert = false },
                    modifier = Modifier.testTag("cancel_bulk_barcode_change_btn"),
                ) {
                    Text("تراجع")
                }
            },
        )
    }

    if (showZoomPreview && cleanCode.isNotEmpty() && validation.isValid) {
        BarcodeZoomDialog(
            barcodeValue = cleanCode,
            format = selectedFormat,
            productId = null,
            barcodeService = null,
            onDismiss = { showZoomPreview = false },
        )
    }
}
