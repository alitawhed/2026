package com.example.ui.navigation

import kotlinx.serialization.Serializable

sealed interface AppRoute {
    @Serializable
    data object Dashboard : AppRoute

    @Serializable
    data class Products(val initialFilter: String = "ALL") : AppRoute

    @Serializable
    data class ProductDetail(val productId: Long) : AppRoute

    @Serializable
    data class ProductEditor(
        val productId: Long = 0L,
        val prefillBarcode: String = "",
        val prefillBarcodeFormat: String = "",
        val prefillName: String = "",
        val returnSavedProductId: Boolean = false,
    ) : AppRoute

    @Serializable
    data class BarcodeScanner(
        val targetReportId: Long = 0L,
        val returnBarcodeOnly: Boolean = false,
    ) : AppRoute

    @Serializable
    data object ExcelImport : AppRoute

    @Serializable
    data object ReportsHub : AppRoute

    @Serializable
    data class ReportEditor(val reportId: Long) : AppRoute

    @Serializable
    data class ReportProductPicker(val reportId: Long) : AppRoute

    @Serializable
    data class PdfPreview(
        val reportId: Long = 0L,
        val pdfPath: String = "",
        val inventorySessionId: Long = 0L,
    ) : AppRoute

    @Serializable
    data object Templates : AppRoute

    @Serializable
    data object LabelPrinting : AppRoute

    @Serializable
    data object Archive : AppRoute

    @Serializable
    data object BackupRestore : AppRoute

    @Serializable
    data object Settings : AppRoute

    @Serializable
    data object ImageManager : AppRoute

    @Serializable
    data class ImageEditor(val imageId: Long) : AppRoute

    @Serializable
    data class PdfEditor(val initialPdfPath: String = "", val documentId: Long = 0L) : AppRoute

    @Serializable
    data object Inventory : AppRoute

    @Serializable
    data object AboutApp : AppRoute

    @Serializable
    data object ErrorDiagnostics : AppRoute

    @Serializable
    data object Auth : AppRoute

    @Serializable
    data object AccountManagement : AppRoute

    @Serializable
    data object Subscription : AppRoute

    @Serializable
    data object Privacy : AppRoute
}
