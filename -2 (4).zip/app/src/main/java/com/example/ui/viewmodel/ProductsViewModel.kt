package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.repository.DuplicateBarcodeException
import com.example.di.AppContainer
import com.example.domain.barcode.BarcodeChangeResult
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.SaveStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ProductFilterMode(val arabicLabel: String) {
    ALL("الكل"),
    NO_IMAGES("بدون صور"),
    MULTI_BARCODE("باركودات متعددة"),
    MISSING_BARCODE("بدون باركود"),
}

enum class ProductSortMode(val arabicLabel: String) {
    DATE_DESC("الأحدث تعديلاً"),
    NAME_ASC("الاسم (أ-ي)"),
    PRICE_ASC("السعر (الأقل)"),
    PRICE_DESC("السعر (الأعلى)"),
}

data class ProductsListUiState(
    val products: List<ProductWithDetails> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val origins: List<String> = emptyList(),
    val searchQuery: String = "",
    val filterMode: ProductFilterMode = ProductFilterMode.ALL,
    val selectedCategory: String = "",
    val selectedOrigin: String = "",
    val sortMode: ProductSortMode = ProductSortMode.DATE_DESC,
    val selectedProductIds: Set<Long> = emptySet(),
    val saveStatus: SaveStatus = SaveStatus.IDLE,
    val productsNumericConfig: ProductsNumericConfig = ProductsNumericConfig(),
)

class ProductsViewModel(private val container: AppContainer) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _filterMode = MutableStateFlow(ProductFilterMode.ALL)
    private val _selectedCategory = MutableStateFlow("")
    private val _selectedOrigin = MutableStateFlow("")
    private val _sortMode = MutableStateFlow(ProductSortMode.DATE_DESC)
    private val _selectedIds = MutableStateFlow<Set<Long>>(emptySet())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _duplicateConflict = MutableStateFlow<DuplicateBarcodeException?>(null)
    val duplicateConflict: StateFlow<DuplicateBarcodeException?> = _duplicateConflict.asStateFlow()

    val barcodeService = container.barcodeService
    val defaultBarcodeType: StateFlow<BarcodeFormatType> = container.barcodeService.defaultBarcodeTypeFlow

    val productsNumericConfig: StateFlow<ProductsNumericConfig> =
        container.settingsRepository.productsNumericConfigFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProductsNumericConfig())

    val uiState: StateFlow<ProductsListUiState> = combine(
        container.productRepository.allProducts,
        container.productRepository.allCategories,
        _searchQuery,
        _filterMode,
        _selectedCategory,
        _selectedOrigin,
        _sortMode,
        _selectedIds,
        container.productRepository.saveStatus,
        productsNumericConfig,
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val all = arr[0] as List<ProductWithDetails>
        @Suppress("UNCHECKED_CAST")
        val cats = arr[1] as List<CategoryEntity>
        val query = (arr[2] as String).trim()
        val filter = arr[3] as ProductFilterMode
        val catFilter = arr[4] as String
        val originFilter = arr[5] as String
        val sort = arr[6] as ProductSortMode
        @Suppress("UNCHECKED_CAST")
        val selected = arr[7] as Set<Long>
        val saveStatus = arr[8] as SaveStatus
        val numCfg = arr[9] as ProductsNumericConfig

        val origins = all.map { it.product.originCountry.trim() }.filter { it.isNotEmpty() }.distinct().sorted()
        val filtered = applyFiltersAndSort(
            all = all,
            repository = container.productRepository,
            query = query,
            filter = filter,
            catFilter = catFilter,
            originFilter = originFilter,
            sort = sort,
        )

        ProductsListUiState(
            products = filtered,
            categories = cats,
            origins = origins,
            searchQuery = query,
            filterMode = filter,
            selectedCategory = catFilter,
            selectedOrigin = originFilter,
            sortMode = sort,
            selectedProductIds = selected,
            saveStatus = saveStatus,
            productsNumericConfig = numCfg,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ProductsListUiState(),
    )

    fun updateProductsNumericConfig(config: ProductsNumericConfig) {
        viewModelScope.launch {
            container.settingsRepository.saveProductsNumericConfig(config)
            _message.value = "تم تحديث تنسيق أرقام شاشة المنتجات"
        }
    }

    fun resetProductsNumericConfig() {
        viewModelScope.launch {
            container.settingsRepository.resetProductsNumericConfig()
            _message.value = "تمت استعادة المنازل العشرية الافتراضية للمنتجات"
        }
    }

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setFilterMode(mode: ProductFilterMode) { _filterMode.value = mode }
    fun setSelectedCategory(cat: String) { _selectedCategory.value = cat }
    fun setSelectedOrigin(origin: String) { _selectedOrigin.value = origin }
    fun setSortMode(sort: ProductSortMode) { _sortMode.value = sort }

    fun toggleSelection(productId: Long) {
        val current = _selectedIds.value.toMutableSet()
        if (!current.add(productId)) current.remove(productId)
        _selectedIds.value = current
    }

    fun selectAllVisible() {
        _selectedIds.value = uiState.value.products.map { it.product.id }.toSet()
    }

    fun clearSelection() {
        _selectedIds.value = emptySet()
    }

    fun clearMessage() { _message.value = null }
    fun clearConflict() { _duplicateConflict.value = null }

    fun observeProduct(productId: Long) = container.productRepository.observeProduct(productId)

    suspend fun getProductOnce(productId: Long): ProductWithDetails? =
        container.database.productDao().getProductWithDetails(productId)

    suspend fun findByExactBarcode(code: String): ProductWithDetails? =
        container.productRepository.findProductByExactBarcode(code)

    suspend fun checkBarcodeConflict(code: String, excludeProductId: Long = 0L): ProductWithDetails? =
        container.productRepository.checkBarcodeConflict(code, excludeProductId)

    fun duplicateProduct(productId: Long, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            container.productRepository.duplicateProduct(productId)
                .onSuccess { newId ->
                    _message.value = "تم نسخ المنتج بنجاح"
                    onDone(newId)
                }
                .onFailure { _message.value = "تعذر نسخ المنتج: ${it.message}" }
        }
    }

    fun deleteProduct(productId: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            container.productRepository.deleteProduct(productId)
            _message.value = "تم حذف المنتج"
            onDone()
        }
    }

    fun deleteSelectedBulk() {
        val ids = _selectedIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            container.productRepository.deleteProductsBulk(ids)
            _selectedIds.value = emptySet()
            _message.value = "تم حذف ${ids.size} منتج"
        }
    }

    fun updateCategoryBulk(categoryName: String) {
        val ids = _selectedIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            container.productRepository.updateCategoryBulk(ids, categoryName)
            _selectedIds.value = emptySet()
            _message.value = "تم تحديث تصنيف ${ids.size} منتج"
        }
    }

    fun exportSelectedOrAllToExcel(asCsv: Boolean = false, onReady: (File) -> Unit) {
        viewModelScope.launch {
            try {
                val selected = _selectedIds.value
                val list = if (selected.isEmpty()) {
                    uiState.value.products
                } else {
                    uiState.value.products.filter { it.product.id in selected }
                }
                val numCfg = uiState.value.productsNumericConfig
                val file = withContext(Dispatchers.IO) {
                    val prefix = "products_${System.currentTimeMillis() / 1000}"
                    if (asCsv) container.excelExportEngine.exportProductsToCsv(list, prefix, numCfg)
                    else container.excelExportEngine.exportProductsToXlsx(list, prefix, productsNumericConfig = numCfg)
                }
                onReady(file)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                container.globalErrorMonitor.recordError(
                    throwable = t,
                    screenName = ScreenNames.PRODUCTS,
                    moduleName = DiagnosticModules.EXCEL,
                    operationName = if (asCsv) "تصدير المنتجات CSV" else "تصدير المنتجات Excel",
                )
                _message.value = "تعذر تصدير قائمة المنتجات: ${t.localizedMessage ?: "خطأ"}"
            }
        }
    }

    fun saveProduct(
        product: ProductEntity,
        barcodes: List<ProductBarcodeEntity>,
        images: List<ProductImageEntity>,
        onSaved: (Long) -> Unit,
    ) {
        viewModelScope.launch {
            if (product.name.isBlank()) {
                _message.value = "يرجى إدخال اسم المنتج"
                return@launch
            }
            container.productRepository.createOrUpdateProduct(product, barcodes, images)
                .onSuccess { id ->
                    _message.value = "تم حفظ المنتج بنجاح"
                    onSaved(id)
                }
                .onFailure { err ->
                    if (err is DuplicateBarcodeException) {
                        _duplicateConflict.value = err
                    } else {
                        _message.value = err.message ?: "تعذر حفظ المنتج"
                    }
                }
        }
    }

    fun addBarcodeToProduct(
        productId: Long,
        value: String,
        format: BarcodeFormatType,
        label: String,
        makePrimary: Boolean,
        description: String = "",
        unitType: String = "حبة",
        conversionFactor: Double = 1.0,
        onAdded: () -> Unit = {},
    ) {
        val validation = BarcodeEngine.validate(value, format)
        if (!validation.isValid) {
            _message.value = validation.errorMessage ?: "صيغة الباركود غير صالحة"
            return
        }
        viewModelScope.launch {
            container.productRepository.addBarcodeToProduct(
                productId = productId,
                barcodeValue = validation.normalizedValue,
                format = format,
                label = label,
                makePrimary = makePrimary,
                description = description,
                unitType = unitType,
                conversionFactor = conversionFactor,
            ).onSuccess {
                _message.value = "تمت إضافة الباركود"
                onAdded()
            }.onFailure { err ->
                if (err is DuplicateBarcodeException) {
                    _duplicateConflict.value = err
                } else {
                    _message.value = err.message
                }
            }
        }
    }

    fun updateBarcode(barcode: ProductBarcodeEntity, onDone: () -> Unit = {}) {
        val validation = BarcodeEngine.validate(barcode.barcodeValue, BarcodeFormatType.fromString(barcode.barcodeType))
        if (!validation.isValid) {
            _message.value = validation.errorMessage ?: "صيغة الباركود غير صالحة"
            return
        }
        viewModelScope.launch {
            container.productRepository.updateBarcode(barcode.copy(barcodeValue = validation.normalizedValue))
                .onSuccess {
                    _message.value = "تم تحديث الباركود"
                    onDone()
                }
                .onFailure { err ->
                    if (err is DuplicateBarcodeException) {
                        _duplicateConflict.value = err
                    } else {
                        _message.value = err.message
                    }
                }
        }
    }

    fun setPrimaryBarcode(productId: Long, barcodeId: Long) {
        viewModelScope.launch {
            container.productRepository.setPrimaryBarcode(productId, barcodeId)
        }
    }

    fun deleteBarcode(productId: Long, barcodeId: Long) {
        viewModelScope.launch {
            container.productRepository.deleteBarcode(productId, barcodeId)
        }
    }

    fun changeProductBarcodeFormat(
        productId: Long,
        barcodeId: Long,
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        viewModelScope.launch {
            val res = when (scope) {
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING -> {
                    val saved = container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
                    if (saved.isSuccess) {
                        BarcodeChangeResult(
                            success = true,
                            message = "تم تعيين ${targetFormat.arabicLabel} كنوع افتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                            appliedFormat = targetFormat,
                        )
                    } else {
                        BarcodeChangeResult(
                            success = false,
                            message = "تعذر تحديث النوع الافتراضي: ${saved.exceptionOrNull()?.message}",
                        )
                    }
                }
                else -> container.barcodeService.changeFormatForProductBarcode(
                    productId = productId,
                    barcodeId = barcodeId,
                    targetFormat = targetFormat,
                    alsoUpdateDefaultSetting = alsoUpdateDefault,
                )
            }
            _message.value = res.message
            onResult(res)
        }
    }

    fun changeBulkSelectedProductsBarcodeFormat(
        targetFormat: BarcodeFormatType,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        val ids = _selectedIds.value.toList()
        if (ids.isEmpty()) {
            _message.value = "يرجى تحديد منتج واحد على الأقل"
            return
        }
        viewModelScope.launch {
            val res = container.barcodeService.changeFormatBulkProducts(
                productIds = ids,
                targetFormat = targetFormat,
                alsoUpdateDefaultSetting = alsoUpdateDefault,
            )
            if (res.success && res.updatedCount > 0) {
                _selectedIds.value = emptySet()
            }
            _message.value = res.message
            onResult(res)
        }
    }

    fun generateAlternativeInternalBarcode(
        productId: Long,
        unitType: String = "حبة",
        conversionFactor: Double = 1.0,
        explicitFormat: BarcodeFormatType? = null,
        onDone: (ProductBarcodeEntity?) -> Unit = {},
    ) {
        viewModelScope.launch {
            container.barcodeService.generateAndAttachAlternativeInternalBarcode(
                productId = productId,
                unitType = unitType,
                conversionFactor = conversionFactor,
                explicitFormat = explicitFormat,
            ).onSuccess { created ->
                _message.value = "تم إنشاء باركود داخلي بديل (${BarcodeFormatType.fromString(created.barcodeType).arabicLabel}) مع إبقاء الباركود الأصلي كما هو"
                onDone(created)
            }.onFailure { err ->
                _message.value = err.message ?: "تعذر إنشاء باركود داخلي بديل"
                onDone(null)
            }
        }
    }

    suspend fun previewNewInternalBarcodeValue(seedProductId: Long, format: BarcodeFormatType): String =
        container.barcodeService.generateUniqueInternalValuePreview(seedProductId, format)

    fun addImageFromUri(productId: Long, uri: Uri, makePrimary: Boolean = false, onDone: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val saved = container.productRepository.addProductImageFromUri(productId, uri, makePrimary)
            withContext(Dispatchers.Main) {
                if (saved != null) {
                    _message.value = "تمت إضافة الصورة بنجاح"
                } else {
                    _message.value = "تعذر قراءة الصورة المختارة"
                }
                onDone()
            }
        }
    }

    fun addImagesFromUris(productId: Long, uris: List<Uri>, onDone: () -> Unit = {}) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val added = container.productRepository.addProductImagesFromUris(productId, uris)
            withContext(Dispatchers.Main) {
                if (added > 0) _message.value = "تمت إضافة $added صورة بنجاح"
                else _message.value = "تعذر قراءة الصور المختارة"
                onDone()
            }
        }
    }

    fun replaceImageFromUri(imageId: Long, uri: Uri, onDone: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = container.productRepository.replaceImageFromUri(imageId, uri)
            withContext(Dispatchers.Main) {
                _message.value = if (ok) "تم استبدال الصورة بنجاح" else "تعذر استبدال الصورة"
                onDone()
            }
        }
    }

    fun saveTempImageFromUri(uri: Uri, onStored: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val stored = container.mediaStorage.saveProductImageWithOriginal(uri)
            withContext(Dispatchers.Main) {
                if (stored != null) onStored(stored.activePath)
                else _message.value = "تعذر قراءة الصورة"
            }
        }
    }

    fun saveTempImagesFromUris(uris: List<Uri>, onStored: (List<com.example.data.storage.StoredImageFiles>) -> Unit) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val list = uris.mapNotNull { container.mediaStorage.saveProductImageWithOriginal(it) }
            withContext(Dispatchers.Main) {
                if (list.isNotEmpty()) onStored(list)
                else _message.value = "تعذر قراءة الصور المختارة"
            }
        }
    }

    fun setPrimaryImage(productId: Long, imageId: Long) {
        viewModelScope.launch {
            container.productRepository.setPrimaryImage(productId, imageId)
        }
    }

    fun rotateImage(filePath: String, onDone: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            container.mediaStorage.rotateImageFile(filePath, 90f)
            withContext(Dispatchers.Main) { onDone() }
        }
    }

    fun rotateImageById(imageId: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = container.productRepository.rotateProductImageById(imageId, 90)
            withContext(Dispatchers.Main) {
                if (ok) {
                    _message.value = "تم تدوير الصورة وتحديث المعاينة"
                    onDone()
                } else {
                    _message.value = "تعذر تدوير الصورة"
                }
            }
        }
    }

    private val _imageDiagnosticReport = MutableStateFlow<com.example.data.storage.ImageDiagnosticReport?>(null)
    val imageDiagnosticReport: StateFlow<com.example.data.storage.ImageDiagnosticReport?> = _imageDiagnosticReport.asStateFlow()

    private val _isRepairingImages = MutableStateFlow(false)
    val isRepairingImages: StateFlow<Boolean> = _isRepairingImages.asStateFlow()

    fun runImageAudit() {
        viewModelScope.launch {
            _isRepairingImages.value = true
            val report = container.imageService.auditAllProductImages()
            _imageDiagnosticReport.value = report
            _isRepairingImages.value = false
        }
    }

    fun repairBrokenImages(createBackupFirst: Boolean = true) {
        viewModelScope.launch {
            _isRepairingImages.value = true
            val res = container.imageService.repairBrokenImageReferences(
                backupEngine = container.backupRestoreEngine,
                createBackupFirst = createBackupFirst,
            )
            _imageDiagnosticReport.value = res.reportAfter
            _isRepairingImages.value = false
            _message.value = buildString {
                append("تم الفحص: تم إصلاح ${res.repairedCount} مرجع")
                if (res.thumbnailsRebuiltCount > 0) append(" • تحديث ${res.thumbnailsRebuiltCount} مصغرة")
                if (res.unrecoverableCount > 0) append(" • تعذر استعادة ${res.unrecoverableCount} ملف مفقود")
            }
        }
    }

    fun cropImage(
        filePath: String,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        onDone: () -> Unit = {},
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            container.mediaStorage.cropImageFile(filePath, left, top, right, bottom)
            withContext(Dispatchers.Main) { onDone() }
        }
    }

    fun cropImageById(
        imageId: Long,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        onDone: () -> Unit = {},
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = container.productRepository.cropProductImageById(imageId, left, top, right, bottom)
            withContext(Dispatchers.Main) {
                if (ok) {
                    _message.value = "تم قص الصورة وتحديث المعاينة"
                    onDone()
                } else {
                    _message.value = "تعذر قص الصورة"
                }
            }
        }
    }

    val pendingOrFailedImageDownloads: StateFlow<List<ProductImageDownloadEntity>> =
        container.database.productDao().observePendingOrFailedImageDownloads()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isRetryingImageDownloads = MutableStateFlow(false)
    val isRetryingImageDownloads: StateFlow<Boolean> = _isRetryingImageDownloads.asStateFlow()

    fun retryFailedUrlImageDownloads(downloadIds: List<Long>? = null) {
        if (_isRetryingImageDownloads.value) return
        viewModelScope.launch {
            _isRetryingImageDownloads.value = true
            try {
                val res = container.excelImportEngine.retryFailedImageDownloads(downloadIds = downloadIds)
                _message.value = "إعادة التحميل: نجح ${res.succeededCount} • فشل ${res.failedCount}"
                runImageAudit()
            } catch (e: Exception) {
                container.globalErrorMonitor.recordError(e, ScreenNames.PRODUCTS, DiagnosticModules.IMAGES, "إعادة تحميل صور المنتجات")
                _message.value = "تعذر إعادة التحميل: ${e.message}"
            } finally {
                _isRetryingImageDownloads.value = false
            }
        }
    }

    fun dismissFailedImageDownload(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            container.database.productDao().deleteImageDownloadById(id)
        }
    }

    fun reorderImages(productId: Long, images: List<ProductImageEntity>) {
        viewModelScope.launch {
            container.productRepository.reorderImages(productId, images)
        }
    }

    fun deleteImage(productId: Long, image: ProductImageEntity) {
        viewModelScope.launch {
            container.productRepository.deleteProductImage(productId, image)
        }
    }

    companion object {
        fun applyFiltersAndSort(
            all: List<ProductWithDetails>,
            repository: com.example.data.repository.ProductRepository,
            query: String = "",
            filter: ProductFilterMode = ProductFilterMode.ALL,
            catFilter: String = "",
            originFilter: String = "",
            sort: ProductSortMode = ProductSortMode.DATE_DESC,
        ): List<ProductWithDetails> {
            val baseMatched = repository.filterProductsUnified(all, query)
            return baseMatched.filter { item ->
                val p = item.product
                val matchesMode = when (filter) {
                    ProductFilterMode.ALL -> true
                    ProductFilterMode.NO_IMAGES -> item.images.isEmpty()
                    ProductFilterMode.MULTI_BARCODE -> item.barcodes.size > 1
                    ProductFilterMode.MISSING_BARCODE -> item.barcodes.isEmpty()
                }
                val matchesCat = catFilter.isEmpty() || p.categoryName.equals(catFilter, ignoreCase = true)
                val matchesOrigin = originFilter.isEmpty() || p.originCountry.equals(originFilter, ignoreCase = true)
                matchesMode && matchesCat && matchesOrigin
            }.let { list ->
                when (sort) {
                    ProductSortMode.DATE_DESC -> list.sortedByDescending { it.product.updatedAt }
                    ProductSortMode.NAME_ASC -> list.sortedBy { it.product.name }
                    ProductSortMode.PRICE_ASC -> list.sortedBy { it.product.basePrice }
                    ProductSortMode.PRICE_DESC -> list.sortedByDescending { it.product.basePrice }
                }
            }
        }
    }
}
