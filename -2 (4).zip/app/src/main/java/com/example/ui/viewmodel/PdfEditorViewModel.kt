package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.PdfDocumentWithPages
import com.example.data.local.entity.ProductWithDetails
import com.example.di.AppContainer
import com.example.domain.pdf.PdfEditableDocument
import com.example.domain.pdf.PdfOverlayItem
import com.example.domain.pdf.PdfOverlayType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PdfEditorUiState(
    val document: PdfEditableDocument? = null,
    val activePageIndex: Int = 0,
    val pagePreviewBitmap: Bitmap? = null,
    val selectedOverlayId: String? = null,
    val isBusy: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val lastExportedFile: File? = null,
    val extractedImages: List<File> = emptyList(),
    val extractedTextResult: String? = null,
)

class PdfEditorViewModel(private val container: AppContainer) : ViewModel() {

    private val _uiState = MutableStateFlow(PdfEditorUiState())
    val uiState: StateFlow<PdfEditorUiState> = _uiState.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val savedDocuments: StateFlow<List<PdfDocumentWithPages>> =
        container.database.pdfDocumentDao().observeAllDocuments()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProducts: StateFlow<List<ProductWithDetails>> =
        container.productRepository.allProducts
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val undoStack = ArrayDeque<PdfEditableDocument>()
    private val redoStack = ArrayDeque<PdfEditableDocument>()

    fun clearMessage() { _message.value = null }
    fun clearExtractedText() { _uiState.value = _uiState.value.copy(extractedTextResult = null) }

    fun initializeFromArgs(initialPdfPath: String, documentId: Long) {
        if (_uiState.value.document != null) return
        when {
            documentId > 0L -> openSavedDocument(documentId)
            initialPdfPath.isNotBlank() && File(initialPdfPath).exists() -> openInternalPdf(File(initialPdfPath))
        }
    }

    fun openPdfUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            val res = container.pdfEditorEngine.openPdfFromUri(uri)
            res.onSuccess { doc ->
                loadDocument(container.pdfEditorEngine.toEditableDocument(doc))
                _message.value = "تم فتح نسخة عمل آمنة (الملف الأصلي محفوظ)"
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(isBusy = false)
                _message.value = "فشل فتح PDF: ${err.message}"
            }
        }
    }

    fun openInternalPdf(file: File, sourceReportId: Long? = null) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            val res = container.pdfEditorEngine.openInternalPdfFile(file, file.nameWithoutExtension, sourceReportId)
            res.onSuccess { doc ->
                loadDocument(container.pdfEditorEngine.toEditableDocument(doc))
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(isBusy = false)
                _message.value = err.message ?: "تعذر فتح PDF"
            }
        }
    }

    fun openSavedDocument(docId: Long) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            val doc = withContext(Dispatchers.IO) { container.database.pdfDocumentDao().getDocumentOnce(docId) }
            if (doc != null) {
                loadDocument(container.pdfEditorEngine.toEditableDocument(doc))
            } else {
                _uiState.value = _uiState.value.copy(isBusy = false)
                _message.value = "المستند غير موجود"
            }
        }
    }

    fun deleteSavedDocument(docId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            container.database.pdfDocumentDao().deleteDocumentById(docId)
            withContext(Dispatchers.Main) {
                _message.value = "تم حذف سجل المستند"
            }
        }
    }

    private suspend fun loadDocument(editable: PdfEditableDocument) {
        undoStack.clear()
        redoStack.clear()
        _uiState.value = _uiState.value.copy(
            document = editable,
            activePageIndex = 0,
            selectedOverlayId = null,
            canUndo = false,
            canRedo = false,
            extractedImages = emptyList(),
            extractedTextResult = null,
        )
        refreshActivePreview()
    }

    private fun commitEdit(next: PdfEditableDocument, newPageIndex: Int = _uiState.value.activePageIndex) {
        val current = _uiState.value.document ?: return
        undoStack.addLast(current)
        if (undoStack.size > 25) undoStack.removeFirst()
        redoStack.clear()
        val safePage = newPageIndex.coerceIn(0, (next.pages.size - 1).coerceAtLeast(0))
        _uiState.value = _uiState.value.copy(
            document = next,
            activePageIndex = safePage,
            canUndo = undoStack.isNotEmpty(),
            canRedo = false,
        )
        viewModelScope.launch {
            container.pdfEditorEngine.saveWorkspaceState(next)
            refreshActivePreview()
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val current = _uiState.value.document ?: return
        val prev = undoStack.removeLast()
        redoStack.addLast(current)
        val safePage = _uiState.value.activePageIndex.coerceIn(0, (prev.pages.size - 1).coerceAtLeast(0))
        _uiState.value = _uiState.value.copy(
            document = prev,
            activePageIndex = safePage,
            canUndo = undoStack.isNotEmpty(),
            canRedo = true,
        )
        viewModelScope.launch {
            container.pdfEditorEngine.saveWorkspaceState(prev)
            refreshActivePreview()
        }
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val current = _uiState.value.document ?: return
        val next = redoStack.removeLast()
        undoStack.addLast(current)
        val safePage = _uiState.value.activePageIndex.coerceIn(0, (next.pages.size - 1).coerceAtLeast(0))
        _uiState.value = _uiState.value.copy(
            document = next,
            activePageIndex = safePage,
            canUndo = true,
            canRedo = redoStack.isNotEmpty(),
        )
        viewModelScope.launch {
            container.pdfEditorEngine.saveWorkspaceState(next)
            refreshActivePreview()
        }
    }

    fun selectPage(index: Int) {
        val doc = _uiState.value.document ?: return
        val safe = index.coerceIn(0, (doc.pages.size - 1).coerceAtLeast(0))
        _uiState.value = _uiState.value.copy(activePageIndex = safe, selectedOverlayId = null)
        viewModelScope.launch { refreshActivePreview() }
    }

    private suspend fun refreshActivePreview() {
        val doc = _uiState.value.document ?: return
        val idx = _uiState.value.activePageIndex.coerceIn(0, (doc.pages.size - 1).coerceAtLeast(0))
        _uiState.value = _uiState.value.copy(isBusy = true)
        val bmp = container.pdfEditorEngine.renderCompositePagePreview(doc, idx, 1.75f)
        val old = _uiState.value.pagePreviewBitmap
        _uiState.value = _uiState.value.copy(pagePreviewBitmap = bmp, isBusy = false)
        if (old != null && old !== bmp && !old.isRecycled) old.recycle()
    }

    fun rotateActivePage(deltaDegrees: Int = 90) {
        val doc = _uiState.value.document ?: return
        commitEdit(container.pdfEditorEngine.rotatePage(doc, _uiState.value.activePageIndex, deltaDegrees))
    }

    fun deleteActivePage() {
        val doc = _uiState.value.document ?: return
        if (doc.pages.size <= 1) {
            _message.value = "يجب بقاء صفحة واحدة على الأقل في المستند"
            return
        }
        val idx = _uiState.value.activePageIndex
        commitEdit(container.pdfEditorEngine.deletePage(doc, idx), newPageIndex = (idx - 1).coerceAtLeast(0))
    }

    fun moveActivePage(delta: Int) {
        val doc = _uiState.value.document ?: return
        val from = _uiState.value.activePageIndex
        val to = (from + delta).coerceIn(0, doc.pages.lastIndex)
        if (from != to) {
            commitEdit(container.pdfEditorEngine.movePage(doc, from, to), newPageIndex = to)
        }
    }

    fun insertBlankPageAfterActive() {
        val doc = _uiState.value.document ?: return
        val after = _uiState.value.activePageIndex
        commitEdit(container.pdfEditorEngine.insertBlankPage(doc, after), newPageIndex = after + 1)
    }

    fun cropActivePage(left: Float, top: Float, right: Float, bottom: Float) {
        val doc = _uiState.value.document ?: return
        commitEdit(container.pdfEditorEngine.cropPageMargins(doc, _uiState.value.activePageIndex, left, top, right, bottom))
    }

    fun mergeAnotherPdf(uri: Uri) {
        val doc = _uiState.value.document ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            container.pdfEditorEngine.appendPdfFromUri(doc, uri)
                .onSuccess { merged ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    commitEdit(merged)
                    _message.value = "تم دمج صفحات الملف الإضافي بنجاح"
                }
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    _message.value = err.message ?: "تعذر دمج PDF"
                }
        }
    }

    fun addOverlay(item: PdfOverlayItem) {
        val doc = _uiState.value.document ?: return
        val positioned = item.copy(pageIndex = _uiState.value.activePageIndex)
        _uiState.value = _uiState.value.copy(selectedOverlayId = positioned.id)
        commitEdit(doc.copy(overlays = doc.overlays + positioned))
    }

    fun addImageOverlayFromUri(uri: Uri) {
        val doc = _uiState.value.document ?: return
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                container.mediaStorage.saveBrandingImageFromUri(uri, "pdf_ov")
            }
            if (savedPath != null) {
                addOverlay(
                    PdfOverlayItem(
                        pageIndex = _uiState.value.activePageIndex,
                        type = PdfOverlayType.IMAGE,
                        xFraction = 0.25f,
                        yFraction = 0.25f,
                        widthFraction = 0.28f,
                        heightFraction = 0.16f,
                        imagePath = savedPath,
                    ),
                )
            } else {
                _message.value = "تعذر تحميل الصورة المختارة"
            }
        }
    }

    fun selectOverlay(id: String?) {
        _uiState.value = _uiState.value.copy(selectedOverlayId = id)
    }

    fun updateOverlay(updated: PdfOverlayItem) {
        val doc = _uiState.value.document ?: return
        commitEdit(doc.copy(overlays = doc.overlays.map { if (it.id == updated.id) updated else it }))
    }

    fun nudgeSelectedOverlay(dxFraction: Float, dyFraction: Float) {
        val doc = _uiState.value.document ?: return
        val id = _uiState.value.selectedOverlayId ?: return
        val current = doc.overlays.firstOrNull { it.id == id } ?: return
        updateOverlay(
            current.copy(
                xFraction = (current.xFraction + dxFraction).coerceIn(0f, 0.9f),
                yFraction = (current.yFraction + dyFraction).coerceIn(0f, 0.9f),
            ),
        )
    }

    fun deleteSelectedOverlay() {
        val doc = _uiState.value.document ?: return
        val id = _uiState.value.selectedOverlayId ?: return
        _uiState.value = _uiState.value.copy(selectedOverlayId = null)
        commitEdit(doc.copy(overlays = doc.overlays.filterNot { it.id == id }))
    }

    fun extractTextAndOcr() {
        val doc = _uiState.value.document ?: return
        val page = doc.pages.getOrNull(_uiState.value.activePageIndex) ?: return
        val bmp = _uiState.value.pagePreviewBitmap
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            val embeddedText = withContext(Dispatchers.IO) {
                if (page.sourcePdfPath.isNotBlank()) container.pdfEditorEngine.extractPlainPdfTextLiterals(File(page.sourcePdfPath))
                else ""
            }
            val ocrText = if (bmp != null) {
                container.pdfEditorEngine.recognizeTextOcr(bmp).getOrNull().orEmpty()
            } else ""
            val combined = buildString {
                if (embeddedText.isNotBlank()) appendLine(embeddedText)
                if (ocrText.isNotBlank() && ocrText != embeddedText) {
                    if (isNotEmpty()) appendLine("\n--- نص OCR ---")
                    appendLine(ocrText)
                }
            }.trim()
            _uiState.value = _uiState.value.copy(
                isBusy = false,
                extractedTextResult = combined,
            )
        }
    }

    fun applyTextEditWithCoverAndOverlay(editedText: String) {
        val doc = _uiState.value.document ?: return
        val pageIdx = _uiState.value.activePageIndex
        val cover = PdfOverlayItem(
            pageIndex = pageIdx,
            type = PdfOverlayType.COVER_BOX,
            xFraction = 0.08f,
            yFraction = 0.14f,
            widthFraction = 0.84f,
            heightFraction = 0.25f,
            fillColorHex = "#FFFFFF",
        )
        val textOv = PdfOverlayItem(
            pageIndex = pageIdx,
            type = PdfOverlayType.TEXT,
            xFraction = 0.10f,
            yFraction = 0.16f,
            widthFraction = 0.80f,
            heightFraction = 0.22f,
            text = editedText,
            fontSizeSp = 13f,
        )
        commitEdit(doc.copy(overlays = doc.overlays + listOf(cover, textOv)))
        clearExtractedText()
        _message.value = "تم إدراج النص المعدّل فوق منطقة التغطية ويمكنك تحريكه بحرية"
    }

    fun extractImagesFromDocument() {
        val doc = _uiState.value.document ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            val files = withContext(Dispatchers.IO) {
                doc.pages.mapNotNull { p -> p.sourcePdfPath.takeIf { it.isNotBlank() }?.let(::File) }
                    .distinctBy { it.absolutePath }
                    .flatMap { container.pdfEditorEngine.extractEmbeddedImagesFromPdf(it) }
            }
            _uiState.value = _uiState.value.copy(isBusy = false, extractedImages = files)
            _message.value = if (files.isNotEmpty()) "تم استخراج ${files.size} صورة من المستند" else "لم يُعثر على صور JPEG مضمنة قابلة للاستخراج"
        }
    }

    fun attachExtractedImageToProduct(imageFile: File, productId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val stored = container.mediaStorage.saveProductImageBytesWithOriginal(imageFile.readBytes())
            if (stored != null) {
                container.productRepository.addStoredImageTripletToProduct(
                    productId = productId,
                    storedPath = stored.activePath,
                    originalPath = stored.originalPath,
                    thumbnailPath = stored.thumbnailPath,
                    makePrimary = false,
                )
                withContext(Dispatchers.Main) {
                    _message.value = "تم حفظ الصورة وإرفاقها بالمنتج"
                }
            }
        }
    }

    fun saveEditedPdfCopy(customFileName: String? = null, onSaved: (File) -> Unit = {}) {
        val doc = _uiState.value.document ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            container.pdfEditorEngine.exportEditedPdf(doc, customFileName)
                .onSuccess { outFile ->
                    _uiState.value = _uiState.value.copy(isBusy = false, lastExportedFile = outFile)
                    _message.value = "تم حفظ النسخة المعدلة: ${outFile.name}"
                    onSaved(outFile)
                }
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    _message.value = "فشل حفظ PDF: ${err.message}"
                }
        }
    }

    fun extractPageRangeToNewPdf(fromPageOneBased: Int, toPageOneBased: Int, fileName: String, onExported: (File) -> Unit) {
        val doc = _uiState.value.document ?: return
        val start = (fromPageOneBased - 1).coerceIn(0, doc.pages.lastIndex)
        val end = (toPageOneBased - 1).coerceIn(start, doc.pages.lastIndex)
        val range = (start..end).toList()
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            container.pdfEditorEngine.exportEditedPdf(doc, fileName, range)
                .onSuccess { out ->
                    _uiState.value = _uiState.value.copy(isBusy = false, lastExportedFile = out)
                    _message.value = "تم استخراج ${range.size} صفحة في ${out.name}"
                    onExported(out)
                }
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    _message.value = err.message ?: "تعذر الاستخراج"
                }
        }
    }

    fun splitAllPages(onDone: (List<File>) -> Unit) {
        val doc = _uiState.value.document ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true)
            container.pdfEditorEngine.splitPdfIntoSeparateFiles(doc, doc.title.ifBlank { "split" })
                .onSuccess { files ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    _message.value = "تم تقسيم المستند إلى ${files.size} ملف PDF"
                    onDone(files)
                }
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(isBusy = false)
                    _message.value = err.message
                }
        }
    }

    override fun onCleared() {
        _uiState.value.pagePreviewBitmap?.recycle()
        super.onCleared()
    }
}
