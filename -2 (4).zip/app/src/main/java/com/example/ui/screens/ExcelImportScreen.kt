package com.example.ui.screens

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ExcelImageConflictPolicy
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.domain.excel.ExcelNewBarcodePolicy
import com.example.domain.excel.ExcelRowConflictType
import com.example.domain.excel.ExcelUrlImageStatus
import com.example.domain.excel.ExtractedExcelImage
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ProductImportField
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.PathImageBox
import com.example.ui.components.shareFileViaProvider
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.ExcelImportStep
import com.example.ui.viewmodel.ExcelImportViewModel
import com.example.ui.viewmodel.ExcelReviewFilter

@Composable
fun ExcelImportScreen(
    viewModel: ExcelImportViewModel,
    onBack: () -> Unit,
    onDoneGoToProducts: () -> Unit,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var zoomPreviewImage by remember { mutableStateOf<ExtractedExcelImage?>(null) }
    var pendingManualDownloadId by remember { mutableStateOf<Long?>(null) }
    var editingFailedDownload by remember { mutableStateOf<ProductImageDownloadEntity?>(null) }
    var showOfficialApiDialog by remember { mutableStateOf(false) }
    var showBackendSallaDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    LaunchedEffect(state.sallaAuthorizeUrl) {
        val url = state.sallaAuthorizeUrl ?: return@LaunchedEffect
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        }
        viewModel.clearSallaAuthorizeUrl()
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.loadExcelUri(it) }
    }
    val manualPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        val dlId = pendingManualDownloadId
        pendingManualDownloadId = null
        if (uris.isNotEmpty() && dlId != null) {
            viewModel.fulfillFailedDownloadManuallyMultiple(dlId, uris)
        }
    }
    val localFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { viewModel.importFailedImagesFromFolder(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "استيراد ملفات Excel",
                subtitle = when (state.step) {
                    ExcelImportStep.REVIEW_IMAGES -> "مراجعة المنتجات والصور والروابط قبل الاعتماد"
                    else -> "يدعم XLSX و XLS و CSV والصور المضمنة وروابط الصور"
                },
                onBack = {
                    if (state.step == ExcelImportStep.REVIEW_IMAGES) viewModel.backToMapping()
                    else onBack()
                },
                actions = {
                    if (state.step != ExcelImportStep.PICK_FILE && state.step != ExcelImportStep.IMPORTING) {
                        TextButton(onClick = { viewModel.reset() }) {
                            Text("ملف جديد")
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
        ) {
            when (state.step) {
                ExcelImportStep.PICK_FILE -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    Icons.Default.TableView,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(56.dp),
                                )
                                Text(
                                    "استيراد المنتجات والباركودات والصور",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    "يدعم استيراد آلاف السجلات على دفعات مع الحفاظ التام على الأصفار اليسرى للباركود وتنزيل صور المنتجات تلقائياً من الروابط أو الصور المضمنة.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (state.isLoadingFile) {
                                    CircularProgressIndicator()
                                } else {
                                    Button(
                                        onClick = {
                                            filePicker.launch(
                                                arrayOf(
                                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                                    "application/vnd.ms-excel",
                                                    "text/csv",
                                                    "text/comma-separated-values",
                                                    "*/*",
                                                ),
                                            )
                                        },
                                        modifier = Modifier.testTag("excel_pick_file_btn"),
                                    ) {
                                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("اختيار ملف Excel / CSV")
                                    }
                                }
                                state.errorMessage?.let { err ->
                                    Text(err, color = StatusError, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                ExcelImportStep.MAP_AND_PREVIEW -> {
                    val wb = state.workbook ?: return@Box
                    val sheet = state.activeSheet ?: return@Box

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("الملف: ${wb.fileName} (${wb.fileType})", fontWeight = FontWeight.Bold)
                                    if (wb.sheets.size > 1) {
                                        Text("اختر ورقة العمل:", style = MaterialTheme.typography.labelMedium)
                                        Row(
                                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            wb.sheets.forEachIndexed { idx, s ->
                                                FilterChip(
                                                    selected = idx == state.selectedSheetIndex,
                                                    onClick = { viewModel.selectSheet(idx) },
                                                    label = { Text(s.sheetName) },
                                                )
                                            }
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = state.hasHeaderRow,
                                            onCheckedChange = viewModel::toggleHasHeaderRow,
                                        )
                                        Text("الصف الأول يحتوي على عناوين الأعمدة")
                                    }
                                }
                            }
                        }

                        state.analysis?.let { analysis ->
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("تحليل ما قبل الاستيراد", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(
                                            "الإجمالي: ${analysis.totalRows}  •  جديد: ${analysis.newProductsCount}  •  مطابق لموجود: ${analysis.matchedProductsCount}  •  أخطاء: ${analysis.errorRowsCount}",
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                        Text(
                                            "باركودات جديدة لمنتج موجود: ${analysis.newBarcodesOnExistingCount}  •  تكرار داخل الملف: ${analysis.intraFileDuplicateRowsCount}  •  تعارض مع منتج آخر: ${analysis.foreignConflictRowsCount}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (analysis.foreignConflictRowsCount > 0 || analysis.intraFileDuplicateRowsCount > 0) StatusError else MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        if (analysis.anchoredImagesCount > 0 || analysis.unanchoredImages.isNotEmpty()) {
                                            Text("صور مرتبطة بالصفوف: ${analysis.anchoredImagesCount}  •  صور تحتاج ربطاً يدوياً: ${analysis.unanchoredImages.size}")
                                        }
                                        analysis.issues.take(6).forEach { issue ->
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Icon(
                                                    Icons.Default.Warning,
                                                    contentDescription = null,
                                                    tint = if (issue.isWarning) StatusWarning else StatusError,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                                Text(issue.message, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text("مطابقة أعمدة Excel مع قاعدة البيانات", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }

                        items(sheet.headers.indices.toList()) { colIdx ->
                            val header = sheet.headers[colIdx]
                            val sampleVal = sheet.rows.getOrNull(if (state.hasHeaderRow) 1 else 0)?.getOrNull(colIdx).orEmpty()
                            val selectedField = state.mappings[colIdx] ?: ProductImportField.IGNORE
                            var menuOpen by remember { mutableStateOf(false) }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(header, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "مثال: ${sampleVal.ifBlank { "—" }}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    Box {
                                        OutlinedButton(onClick = { menuOpen = true }) {
                                            Text(selectedField.arabicLabel)
                                        }
                                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                            ProductImportField.entries.forEach { f ->
                                                DropdownMenuItem(
                                                    text = { Text(f.arabicLabel) },
                                                    onClick = {
                                                        viewModel.updateColumnMapping(colIdx, f)
                                                        menuOpen = false
                                                    },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text("معاينة البيانات (أول 5 صفوف)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Column(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(8.dp)) {
                                    sheet.rows.take(6).forEachIndexed { rIdx, r ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            r.forEach { cell ->
                                                Text(
                                                    text = cell.ifBlank { "—" },
                                                    modifier = Modifier.width(105.dp).padding(vertical = 4.dp),
                                                    style = if (rIdx == 0 && state.hasHeaderRow) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodySmall,
                                                    fontWeight = if (rIdx == 0 && state.hasHeaderRow) FontWeight.Bold else FontWeight.Normal,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text("سياسة التعامل مع المنتجات المكررة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                ImportDuplicatePolicy.entries.forEach { pol ->
                                    FilterChip(
                                        selected = state.duplicatePolicy == pol,
                                        onClick = { viewModel.setDuplicatePolicy(pol) },
                                        label = { Text(pol.arabicLabel) },
                                    )
                                }
                            }
                            state.errorMessage?.let { err ->
                                Spacer(Modifier.height(6.dp))
                                Text(err, color = StatusError)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { viewModel.proceedToImageReview() },
                                    modifier = Modifier.weight(1f).height(50.dp).testTag("excel_review_images_btn"),
                                ) {
                                    Text("مراجعة الصور والصفوف")
                                }
                                Button(
                                    onClick = { viewModel.startImport() },
                                    modifier = Modifier.weight(1f).height(50.dp).testTag("excel_start_import_btn"),
                                ) {
                                    Text("استيراد مباشر")
                                }
                            }
                        }
                    }
                }

                ExcelImportStep.REVIEW_IMAGES -> {
                    val draft = state.reviewDraft ?: return@Box
                    val summary = remember(draft) { draft.computeSummary() }
                    val activeRows = draft.rows.filter { it.validationError == null && !it.skipRow }
                    val filteredRows = remember(draft, state.reviewFilter) {
                        draft.rows.filter { row ->
                            when (state.reviewFilter) {
                                ExcelReviewFilter.ALL -> true
                                ExcelReviewFilter.CONFLICTS_AND_DUPLICATES ->
                                    row.conflictType == ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT ||
                                        row.conflictType == ExcelRowConflictType.INTRA_FILE_DUPLICATE ||
                                        draft.isRowBlocking(row)
                                ExcelReviewFilter.WITH_IMAGE_URLS ->
                                    row.imageUrl.isNotBlank()
                                ExcelReviewFilter.IMAGE_CONFLICTS ->
                                    row.matchedExistingProductId != null && row.existingProductHasImage && row.imageUrl.isNotBlank()
                                ExcelReviewFilter.NEW_BARCODES_EXISTING ->
                                    row.conflictType == ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE
                                ExcelReviewFilter.NEW_PRODUCTS ->
                                    row.matchedExistingProductId == null && row.validationError == null
                                ExcelReviewFilter.SKIPPED_OR_ERRORS ->
                                    row.skipRow || row.validationError != null || row.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT
                            }
                        }
                    }

                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // 1. Live Pre-Import Summary Card (metrics + URL image counts + conflict alert)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(
                                1.dp,
                                if (summary.unresolvedBlockingCount > 0) StatusError else MaterialTheme.colorScheme.outlineVariant,
                            ),
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "ملخص مراجعة الاستيراد قبل الاعتماد",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    "الإجمالي: ${summary.totalRows}  •  جديد: ${summary.newProductsCount}  •  مطابق لموجود: ${summary.matchedProductsCount}  •  سيتم تحديثه: ${summary.needsUpdateCount}",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                                Text(
                                    "باركودات جديدة لموجود: ${summary.newBarcodesOnExistingCount}  •  مكرر بالملف: ${summary.intraFileDuplicatesCount}  •  تعارض منتج آخر: ${summary.foreignConflictsCount}  •  متخطى/أخطاء: ${summary.skippedOrErrorCount}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (summary.urlImagesCount > 0) {
                                    Text(
                                        "روابط صور: ${summary.urlImagesCount}  •  روابط غير صالحة: ${summary.invalidUrlImagesCount}  •  تعارض مع صور موجودة: ${summary.existingWithImageUrlConflictCount}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (summary.invalidUrlImagesCount > 0) StatusWarning else MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                }
                                if (summary.unresolvedBlockingCount > 0) {
                                    Text(
                                        "تنبيه: يوجد ${summary.unresolvedBlockingCount} صفاً بتعارض أو تكرار غير محلول يمنع الاعتماد النهائي.",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusError,
                                    )
                                }
                            }
                        }

                        // 2. Batch Conflict & URL Image Resolution Actions
                        if (summary.newBarcodesOnExistingCount > 0 ||
                            summary.intraFileDuplicatesCount > 0 ||
                            summary.foreignConflictsCount > 0 ||
                            summary.urlImagesCount > 0
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                if (summary.urlImagesCount > 0) {
                                    OutlinedButton(
                                        enabled = !state.isProbingPreviewUrls,
                                        onClick = { viewModel.probePreviewImageUrls() },
                                        modifier = Modifier.testTag("excel_probe_image_urls_btn"),
                                    ) {
                                        if (state.isProbingPreviewUrls) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(6.dp))
                                            Text("جارٍ معاينة الروابط...")
                                        } else {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("فحص ومعاينة روابط الصور")
                                        }
                                    }
                                }
                                if (summary.existingWithImageUrlConflictCount > 0) {
                                    OutlinedButton(
                                        onClick = { viewModel.applyImagePolicyToAllExistingConflicts(ExcelImageConflictPolicy.KEEP_EXISTING) },
                                        modifier = Modifier.testTag("excel_batch_keep_old_images_btn"),
                                    ) {
                                        Text("الإبقاء على كل القديمة")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.applyImagePolicyToAllExistingConflicts(ExcelImageConflictPolicy.REPLACE_PRIMARY) },
                                        modifier = Modifier.testTag("excel_batch_replace_images_btn"),
                                    ) {
                                        Text("استبدال كل الصور الحالية")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.applyImagePolicyToAllExistingConflicts(ExcelImageConflictPolicy.ADD_AS_ADDITIONAL) },
                                        modifier = Modifier.testTag("excel_batch_add_extra_images_btn"),
                                    ) {
                                        Text("إضافة كل الجديدة كإضافية")
                                    }
                                }
                                if (summary.newBarcodesOnExistingCount > 0) {
                                    OutlinedButton(
                                        onClick = { viewModel.applyPolicyToNewBarcodeRows(ExcelNewBarcodePolicy.ADD_AS_ALTERNATIVE) },
                                    ) {
                                        Text("إضافة كل الجديدة كبديلة")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.applyPolicyToNewBarcodeRows(ExcelNewBarcodePolicy.SET_AS_PRIMARY_KEEP_OLD) },
                                    ) {
                                        Text("جعل كل الجديدة رئيسية")
                                    }
                                }
                                if (summary.intraFileDuplicatesCount > 0) {
                                    OutlinedButton(
                                        onClick = { viewModel.skipSubsequentIntraFileDuplicates() },
                                        modifier = Modifier.testTag("excel_batch_skip_intra_dup_btn"),
                                    ) {
                                        Text("تخطي المكررات داخل الملف")
                                    }
                                }
                                if (summary.foreignConflictsCount > 0) {
                                    OutlinedButton(
                                        onClick = { viewModel.ignoreAllForeignConflicts() },
                                        modifier = Modifier.testTag("excel_batch_ignore_foreign_btn"),
                                    ) {
                                        Text("تجاهل الباركودات المتعارضة")
                                    }
                                    OutlinedButton(onClick = { viewModel.skipAllForeignConflicts() }) {
                                        Text("تخطي صفوف التعارض")
                                    }
                                }
                            }
                        }

                        // 3. Filter Chips
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            ExcelReviewFilter.entries.forEach { f ->
                                FilterChip(
                                    selected = state.reviewFilter == f,
                                    onClick = { viewModel.setReviewFilter(f) },
                                    label = { Text(f.arabicLabel) },
                                )
                            }
                        }

                        state.errorMessage?.let { err ->
                            Text(err, color = StatusError, style = MaterialTheme.typography.bodySmall)
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            if (draft.unlinkedImages.isNotEmpty() && state.reviewFilter == ExcelReviewFilter.ALL) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.08f)),
                                        border = BorderStroke(1.dp, StatusWarning),
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(
                                                "صور غير مرتبطة بصف محدد (${draft.unlinkedImages.size})",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            draft.unlinkedImages.forEach { unImg ->
                                                val bmp = remember(unImg.id) { BitmapFactory.decodeByteArray(unImg.bytes, 0, unImg.bytes.size) }
                                                var pickRowMenu by remember { mutableStateOf(false) }
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                ) {
                                                    if (bmp != null) {
                                                        Image(
                                                            bitmap = bmp.asImageBitmap(),
                                                            contentDescription = unImg.fileName,
                                                            contentScale = ContentScale.Crop,
                                                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).clickable { zoomPreviewImage = unImg },
                                                        )
                                                    }
                                                    Text(unImg.fileName, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Box {
                                                        OutlinedButton(onClick = { pickRowMenu = true }) {
                                                            Text("ربط بمنتج")
                                                        }
                                                        DropdownMenu(expanded = pickRowMenu, onDismissRequest = { pickRowMenu = false }) {
                                                            activeRows.sortedBy { it.images.size }.take(50).forEach { target ->
                                                                val hint = if (target.images.isEmpty()) " (بدون صور)" else " (${target.images.size})"
                                                                DropdownMenuItem(
                                                                    text = { Text("${target.displayRowNumber}: ${target.productName}$hint") },
                                                                    onClick = {
                                                                        viewModel.assignUnlinkedImageToDraftRow(unImg.id, target.sheetRowZeroBased)
                                                                        pickRowMenu = false
                                                                    },
                                                                )
                                                            }
                                                        }
                                                    }
                                                    IconButton(onClick = { viewModel.ignoreUnlinkedImage(unImg.id) }) {
                                                        Icon(Icons.Default.Close, contentDescription = "تجاهل الصورة")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            items(filteredRows.take(300), key = { it.sheetRowZeroBased }) { row ->
                                val isBlocking = draft.isRowBlocking(row)
                                val borderColor = when {
                                    row.validationError != null || isBlocking -> StatusError
                                    row.conflictType == ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE -> StatusWarning
                                    row.matchedExistingProductId != null -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.outlineVariant
                                }
                                var policyMenu by remember { mutableStateOf(false) }

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (row.skipRow) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                                    ),
                                    border = BorderStroke(if (isBlocking) 1.5.dp else 1.dp, borderColor),
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "صف ${row.displayRowNumber}: ${row.productName.ifBlank { "بدون اسم" }}",
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                Text(
                                                    text = "باركود: ${row.primaryBarcode.ifBlank { "—" }} • إضافي: ${row.extraBarcodes.size} • صور مضمنة: ${row.images.size}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                                Spacer(Modifier.height(4.dp))
                                                Row(
                                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                ) {
                                                    val isExistingProd = row.matchedExistingProductId != null
                                                    Surface(
                                                        color = if (isExistingProd) StatusInfo.copy(alpha = 0.14f) else StatusSuccess.copy(alpha = 0.14f),
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            text = if (isExistingProd) "موجود مسبقاً" else "منتج جديد",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = if (isExistingProd) StatusInfo else StatusSuccess,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            text = "الإجراء: ${row.proposedActionLabel(draft.policy)}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    if (row.imageUrl.isNotBlank() || row.urlImageStatus != ExcelUrlImageStatus.NONE) {
                                                        val (imgBg, imgFg) = when (row.urlImageStatus) {
                                                            ExcelUrlImageStatus.READY -> StatusSuccess.copy(alpha = 0.14f) to StatusSuccess
                                                            ExcelUrlImageStatus.FAILED -> StatusError.copy(alpha = 0.14f) to StatusError
                                                            ExcelUrlImageStatus.NONE -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
                                                        }
                                                        Surface(color = imgBg, shape = RoundedCornerShape(6.dp)) {
                                                            Text(
                                                                text = "صورة الرابط: ${row.urlImageStatus.arabicLabel}",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = imgFg,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    }
                                                }
                                                if (row.matchedExistingProductName != null) {
                                                    Text(
                                                        text = "مطابق لمنتج موجود (#${row.matchedExistingProductId}): ${row.matchedExistingProductName} (${row.matchedBy ?: ""})",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary,
                                                    )
                                                }
                                                if (row.imageUrl.isNotBlank()) {
                                                    Text(
                                                        text = "رابط الصورة: ${row.imageUrl}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }
                                                row.urlPreviewError?.let { urlErr ->
                                                    Text(
                                                        text = "تنبيه رابط الصورة: $urlErr",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = StatusError,
                                                    )
                                                }
                                                if (row.conflictDetails != null && row.conflictType != ExcelRowConflictType.MATCHED_EXISTING) {
                                                    Text(
                                                        text = row.conflictDetails,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = if (isBlocking) StatusError else StatusWarning,
                                                    )
                                                }
                                                row.validationError?.let { err ->
                                                    Text(err, color = StatusError, style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(
                                                    checked = !row.skipRow,
                                                    onCheckedChange = { viewModel.toggleSkipDraftRow(row.sheetRowZeroBased) },
                                                )
                                                Text("تضمين", style = MaterialTheme.typography.labelSmall)
                                            }
                                        }

                                        if (row.conflictType != ExcelRowConflictType.NONE && row.validationError == null) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                Text("قرار الباركود/الصف:", style = MaterialTheme.typography.labelSmall)
                                                Box {
                                                    OutlinedButton(onClick = { policyMenu = true }) {
                                                        Text(row.newBarcodePolicy.arabicLabel, style = MaterialTheme.typography.labelSmall)
                                                    }
                                                    DropdownMenu(expanded = policyMenu, onDismissRequest = { policyMenu = false }) {
                                                        val availablePolicies = when (row.conflictType) {
                                                            ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT,
                                                            ExcelRowConflictType.INTRA_FILE_DUPLICATE -> listOf(
                                                                ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE,
                                                                ExcelNewBarcodePolicy.SKIP_PRODUCT,
                                                            )
                                                            else -> ExcelNewBarcodePolicy.entries
                                                        }
                                                        availablePolicies.forEach { pol ->
                                                            DropdownMenuItem(
                                                                text = { Text(pol.arabicLabel) },
                                                                onClick = {
                                                                    viewModel.setRowBarcodePolicy(row.sheetRowZeroBased, pol)
                                                                    policyMenu = false
                                                                },
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if ((row.imageUrl.isNotBlank() || (row.matchedExistingProductId != null && row.existingProductHasImage)) && !row.skipRow) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                if (row.matchedExistingProductId != null) {
                                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                        PathImageBox(
                                                            filePath = row.existingProductImagePath,
                                                            contentDescription = "الصورة الحالية",
                                                            modifier = Modifier.size(64.dp),
                                                            shape = RoundedCornerShape(8.dp),
                                                        )
                                                        Text("الصورة الحالية", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                                if (row.imageUrl.isNotBlank()) {
                                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                        if (!row.urlPreviewThumbnailPath.isNullOrBlank()) {
                                                            PathImageBox(
                                                                filePath = row.urlPreviewThumbnailPath,
                                                                contentDescription = "معاينة الصورة الجديدة",
                                                                modifier = Modifier.size(64.dp),
                                                                shape = RoundedCornerShape(8.dp),
                                                            )
                                                        } else {
                                                            Surface(
                                                                modifier = Modifier.size(64.dp),
                                                                shape = RoundedCornerShape(8.dp),
                                                                color = if (row.urlImageStatus == ExcelUrlImageStatus.FAILED) {
                                                                    StatusError.copy(alpha = 0.12f)
                                                                } else {
                                                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                                                },
                                                            ) {
                                                                Box(contentAlignment = Alignment.Center) {
                                                                    Icon(
                                                                        imageVector = if (row.urlImageStatus == ExcelUrlImageStatus.FAILED) {
                                                                            Icons.Default.BrokenImage
                                                                        } else {
                                                                            Icons.Default.Image
                                                                        },
                                                                        contentDescription = "الصورة الجديدة من الرابط",
                                                                        tint = if (row.urlImageStatus == ExcelUrlImageStatus.FAILED) StatusError else MaterialTheme.colorScheme.primary,
                                                                    )
                                                                }
                                                            }
                                                        }
                                                        Text("الصورة الجديدة", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                                if (row.matchedExistingProductId != null && row.existingProductHasImage && row.imageUrl.isNotBlank()) {
                                                    var imgPolicyMenu by remember { mutableStateOf(false) }
                                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                        Text("سياسة تحديث الصورة:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                                        Box {
                                                            OutlinedButton(
                                                                onClick = { imgPolicyMenu = true },
                                                                modifier = Modifier.fillMaxWidth().testTag("row_img_policy_${row.displayRowNumber}"),
                                                            ) {
                                                                Text(
                                                                    row.imageConflictPolicy.arabicLabel,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    maxLines = 1,
                                                                    overflow = TextOverflow.Ellipsis,
                                                                )
                                                            }
                                                            DropdownMenu(expanded = imgPolicyMenu, onDismissRequest = { imgPolicyMenu = false }) {
                                                                ExcelImageConflictPolicy.entries.forEach { pol ->
                                                                    DropdownMenuItem(
                                                                        text = { Text(pol.arabicLabel) },
                                                                        onClick = {
                                                                            viewModel.setRowImageConflictPolicy(row.sheetRowZeroBased, pol)
                                                                            imgPolicyMenu = false
                                                                        },
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (row.images.isNotEmpty() && !row.skipRow) {
                                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                itemsIndexed(row.images, key = { _, im -> im.id }) { idx, img ->
                                                    val isPrim = (row.primaryImageId ?: row.images.firstOrNull()?.id) == img.id
                                                    val bmp = remember(img.id) { BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size) }
                                                    var moveMenu by remember { mutableStateOf(false) }

                                                    Card(
                                                        border = BorderStroke(
                                                            if (isPrim) 2.dp else 1.dp,
                                                            if (isPrim) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                        ),
                                                    ) {
                                                        Column(modifier = Modifier.width(120.dp)) {
                                                            if (bmp != null) {
                                                                Image(
                                                                    bitmap = bmp.asImageBitmap(),
                                                                    contentDescription = img.fileName,
                                                                    contentScale = ContentScale.Crop,
                                                                    modifier = Modifier
                                                                        .fillMaxWidth()
                                                                        .height(82.dp)
                                                                        .clickable { zoomPreviewImage = img },
                                                                )
                                                            }
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth().padding(2.dp),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                            ) {
                                                                IconButton(
                                                                    onClick = { viewModel.setDraftPrimaryImage(row.sheetRowZeroBased, img.id) },
                                                                    modifier = Modifier.size(28.dp),
                                                                ) {
                                                                    Icon(
                                                                        if (isPrim) Icons.Default.Star else Icons.Default.StarBorder,
                                                                        contentDescription = "رئيسية",
                                                                        tint = MaterialTheme.colorScheme.primary,
                                                                        modifier = Modifier.size(15.dp),
                                                                    )
                                                                }
                                                                IconButton(
                                                                    enabled = idx > 0,
                                                                    onClick = { viewModel.moveDraftImageOrder(row.sheetRowZeroBased, img.id, -1) },
                                                                    modifier = Modifier.size(24.dp),
                                                                ) {
                                                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, Modifier.size(14.dp))
                                                                }
                                                                IconButton(
                                                                    enabled = idx < row.images.lastIndex,
                                                                    onClick = { viewModel.moveDraftImageOrder(row.sheetRowZeroBased, img.id, +1) },
                                                                    modifier = Modifier.size(24.dp),
                                                                ) {
                                                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, Modifier.size(14.dp))
                                                                }
                                                                Box {
                                                                    IconButton(onClick = { moveMenu = true }, modifier = Modifier.size(26.dp)) {
                                                                        Icon(Icons.Default.DriveFileMove, contentDescription = "نقل لمنتج آخر", modifier = Modifier.size(15.dp))
                                                                    }
                                                                    DropdownMenu(expanded = moveMenu, onDismissRequest = { moveMenu = false }) {
                                                                        activeRows.filter { it.sheetRowZeroBased != row.sheetRowZeroBased }.take(40).forEach { target ->
                                                                            DropdownMenuItem(
                                                                                text = { Text("نقل إلى: ${target.productName}") },
                                                                                onClick = {
                                                                                    viewModel.moveImageBetweenDraftRows(img.id, row.sheetRowZeroBased, target.sheetRowZeroBased)
                                                                                    moveMenu = false
                                                                                },
                                                                            )
                                                                        }
                                                                        DropdownMenuItem(
                                                                            text = { Text("فصل إلى الصور غير المرتبطة") },
                                                                            onClick = {
                                                                                viewModel.removeImageFromDraftRow(row.sheetRowZeroBased, img.id, ignoreCompletely = false)
                                                                                moveMenu = false
                                                                            },
                                                                        )
                                                                        DropdownMenuItem(
                                                                            text = { Text("حذف/تجاهل الصورة") },
                                                                            onClick = {
                                                                                viewModel.removeImageFromDraftRow(row.sheetRowZeroBased, img.id, ignoreCompletely = true)
                                                                                moveMenu = false
                                                                            },
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (filteredRows.size > 300) {
                                item {
                                    Text(
                                        "يتم عرض أول 300 صف للمعاينة، وسيتم استيراد جميع الصفوف المطابقة (${filteredRows.size}) عند التأكيد.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.commitReviewDraft(draft) },
                            enabled = summary.unresolvedBlockingCount == 0,
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("excel_confirm_final_import_btn"),
                        ) {
                            Text(
                                if (summary.unresolvedBlockingCount > 0) {
                                    "حل التعارضات أولاً (${summary.unresolvedBlockingCount})"
                                } else {
                                    "اعتماد وتنفيذ الاستيراد النهائي"
                                },
                            )
                        }
                    }
                }

                ExcelImportStep.IMPORTING -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("جارٍ استيراد المنتجات والصور على دفعات...", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        val progress = if (state.progressTotal > 0) {
                            state.progressProcessed.toFloat() / state.progressTotal.toFloat()
                        } else 0f
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Text("بيانات المنتجات: ${state.progressProcessed} / ${state.progressTotal}")
                        if (state.imageDownloadProgressTotal > 0) {
                            Spacer(Modifier.height(14.dp))
                            val imgProgress = (state.imageDownloadProgressProcessed.toFloat() / state.imageDownloadProgressTotal.toFloat()).coerceIn(0f, 1f)
                            LinearProgressIndicator(progress = { imgProgress }, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Text("تنزيل الصور من الروابط: ${state.imageDownloadProgressProcessed} / ${state.imageDownloadProgressTotal}")
                        }
                    }
                }

                ExcelImportStep.SUMMARY_AND_IMAGES -> {
                    val report = state.finalReport ?: return@Box
                    val totalFileRows = report.insertedCount + report.updatedCount + report.skippedCount + report.errorCount
                    val isRecoveryBusy = state.isRetryingFailedImages || state.isProcessingFallback
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        state.errorMessage?.let { err ->
                            item {
                                Surface(
                                    color = StatusError.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, StatusError.copy(alpha = 0.4f)),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusError)
                                        Text(err, color = StatusError, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                        IconButton(onClick = { viewModel.clearError() }) {
                                            Icon(Icons.Default.Close, contentDescription = "إغلاق التنبيه", tint = StatusError)
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(
                                    1.5.dp,
                                    if (report.imageDownloadFailedCount > 0 || report.errorCount > 0) StatusWarning else StatusSuccess,
                                ),
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(
                                            if (report.imageDownloadFailedCount > 0) Icons.Default.Warning else Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = if (report.imageDownloadFailedCount > 0) StatusWarning else StatusSuccess,
                                        )
                                        Text("تقرير نتائج الاستيراد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Text("إجمالي صفوف الملف المعالجة: $totalFileRows")
                                    Text("إجمالي المنتجات المعالجة: ${report.totalProductsProcessed}")
                                    Text("منتجات جديدة مضافة: ${report.insertedCount}  •  محدّثة: ${report.updatedCount}  •  متجاهلة: ${report.skippedCount}")
                                    Text("باركودات مستوردة: ${report.barcodesImportedCount}")
                                    if (report.productsWithoutGtinCount > 0) {
                                        Text(
                                            "منتجات بدون باركود/GTIN وتحتاج إدخاله لاحقاً: ${report.productsWithoutGtinCount}",
                                            color = StatusWarning,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    }
                                    Text("إجمالي روابط الصور: ${report.totalImageUrlsCount}")
                                    Text("صور تم تحميلها والتحقق منها: ${report.verifiedDownloadedCount}")
                                    Text(
                                        "صور فشل تحميلها: ${report.imageDownloadFailedCount}",
                                        color = if (report.imageDownloadFailedCount > 0) StatusError else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (report.imageDownloadFailedCount > 0) FontWeight.Bold else FontWeight.Normal,
                                    )
                                    if (report.imageDownloadSkippedCount > 0) {
                                        Text("صور تم الإبقاء على القديمة لها: ${report.imageDownloadSkippedCount}")
                                    }
                                    Text("إجمالي الصور المرتبطة بالمنتجات: ${report.linkedImagesCount}")
                                    Text("أخطاء بيانات الصفوف: ${report.errorCount}")

                                    state.lastRetrySummary?.let { retrySummary ->
                                        Surface(
                                            color = StatusInfo.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp),
                                        ) {
                                            Text(
                                                retrySummary,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = StatusInfo,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                            )
                                        }
                                    }

                                    if (report.failedImageDownloads.isNotEmpty() || report.issues.isNotEmpty() || report.errorCount > 0) {
                                        Spacer(Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            if (report.failedImageDownloads.isNotEmpty()) {
                                                Button(
                                                    enabled = !isRecoveryBusy,
                                                    onClick = { viewModel.retryFailedImages() },
                                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("excel_retry_failed_images_btn"),
                                                ) {
                                                    if (state.isRetryingFailedImages) {
                                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                                        Spacer(Modifier.width(6.dp))
                                                    } else {
                                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(Modifier.width(6.dp))
                                                    }
                                                    Text("إعادة تحميل الصور الفاشلة")
                                                }
                                            }
                                            OutlinedButton(
                                                enabled = !isRecoveryBusy,
                                                onClick = {
                                                    viewModel.exportErrorReportToExcel { outFile ->
                                                        shareFileViaProvider(
                                                            context = context,
                                                            file = outFile,
                                                            mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                                            chooserTitle = "مشاركة تقرير أخطاء الاستيراد",
                                                        )
                                                    }
                                                },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("excel_export_errors_xlsx_btn"),
                                            ) {
                                                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(6.dp))
                                                Text("تصدير تقرير الأخطاء")
                                            }
                                        }
                                    }

                                    if (report.failedImageDownloads.isNotEmpty()) {
                                        val has403 = report.failedImageDownloads.any { it.httpStatusCode == 403 }
                                        if (has403) {
                                            Surface(
                                                color = StatusWarning.copy(alpha = 0.09f),
                                                shape = RoundedCornerShape(8.dp),
                                            ) {
                                                Text(
                                                    "سبب خطأ HTTP 403: بعض خوادم سلة (cdn.salla.sa) ترفض التنزيل المباشر من تطبيقات الهاتف كسياسة حماية، وليس بسبب صيغة WebP أو بيانات Excel. يمكنك الجلب عبر الخدمة الخلفية المرافقة، أو ربط متجر سلة عبر OAuth 2.0، أو مطابقة الصور من مجلد محلي بأسماء GTIN.",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                                )
                                            }
                                        }
                                        Text(
                                            "طرق استيراد الصور المصرح بها عند رفض الرابط:",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        Button(
                                            enabled = !isRecoveryBusy,
                                            onClick = { showBackendSallaDialog = true },
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("excel_backend_salla_btn"),
                                        ) {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("جلب عبر الخادم الخلفي / ربط سلة الرسمي (OAuth)")
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            OutlinedButton(
                                                enabled = !isRecoveryBusy,
                                                onClick = { localFolderPicker.launch(null) },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("excel_import_folder_fallback_btn"),
                                            ) {
                                                if (state.isProcessingFallback) {
                                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                                    Spacer(Modifier.width(6.dp))
                                                } else {
                                                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                }
                                                Text("مجلد GTIN محلي", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            OutlinedButton(
                                                enabled = !isRecoveryBusy,
                                                onClick = { showOfficialApiDialog = true },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("excel_official_api_fallback_btn"),
                                            ) {
                                                Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(6.dp))
                                                Text("API مخصص", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (report.failedImageDownloads.isNotEmpty()) {
                            item {
                                Text(
                                    "الصور التي تعذر تحميلها وتشخيص الأخطاء (${report.failedImageDownloads.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusError,
                                )
                            }
                            items(report.failedImageDownloads, key = { it.id }) { dl ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = StatusError.copy(alpha = 0.05f)),
                                    border = BorderStroke(1.dp, StatusError.copy(alpha = 0.4f)),
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.Top,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            Icon(Icons.Default.BrokenImage, contentDescription = null, tint = StatusError)
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("${dl.productName} (#${dl.productId})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                                if (dl.barcode.isNotBlank()) {
                                                    Text("باركود: ${dl.barcode}", style = MaterialTheme.typography.labelSmall)
                                                }
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                ) {
                                                    Surface(
                                                        color = StatusError.copy(alpha = 0.14f),
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            dl.failureCategory.ifBlank { "تعذر التحميل" },
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = StatusError,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    if (dl.httpStatusCode > 0) {
                                                        Surface(
                                                            color = StatusWarning.copy(alpha = 0.16f),
                                                            shape = RoundedCornerShape(6.dp),
                                                        ) {
                                                            Text(
                                                                "HTTP ${dl.httpStatusCode}",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = StatusWarning,
                                                                fontWeight = FontWeight.Bold,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    }
                                                    if (dl.attemptCount > 0) {
                                                        Text(
                                                            "محاولات: ${dl.attemptCount}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        )
                                                    }
                                                }
                                                Text(
                                                    dl.sourceUrl,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                if (dl.finalUrl.isNotBlank() && dl.finalUrl != dl.sourceUrl) {
                                                    Text(
                                                        "الرابط النهائي: ${dl.finalUrl}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }
                                                Text(
                                                    "السبب: ${dl.failureReason.ifBlank { "تعذر تنزيل الصورة" }}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = StatusError,
                                                )
                                            }
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            OutlinedButton(
                                                enabled = !isRecoveryBusy,
                                                onClick = { viewModel.retryFailedImages(listOf(dl.id)) },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("retry_dl_${dl.id}"),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("إعادة", maxLines = 1)
                                            }
                                            OutlinedButton(
                                                enabled = !isRecoveryBusy,
                                                onClick = { editingFailedDownload = dl },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("edit_url_dl_${dl.id}"),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("تعديل الرابط", maxLines = 1)
                                            }
                                            Button(
                                                enabled = !isRecoveryBusy,
                                                onClick = {
                                                    pendingManualDownloadId = dl.id
                                                    manualPhotoPicker.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                                    )
                                                },
                                                modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("manual_upload_dl_${dl.id}"),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            ) {
                                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("رفع يدوي", maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (state.remainingUnlinkedImages.isNotEmpty()) {
                            item {
                                Text(
                                    "صور مستخرجة تحتاج تحديد ارتباطها يدوياً (${state.remainingUnlinkedImages.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    "لم يتم التخمين التلقائي لضمان عدم ربط صورة بمنتج خاطئ.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            items(state.remainingUnlinkedImages, key = { it.id }) { img ->
                                var pickMenu by remember { mutableStateOf(false) }
                                val bmp = remember(img.id) { BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        if (bmp != null) {
                                            Image(
                                                bitmap = bmp.asImageBitmap(),
                                                contentDescription = img.fileName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)),
                                            )
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Text(img.fileName, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Box {
                                            OutlinedButton(onClick = { pickMenu = true }) {
                                                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("ربط بمنتج")
                                            }
                                            DropdownMenu(expanded = pickMenu, onDismissRequest = { pickMenu = false }) {
                                                state.allProductsForLinking.take(40).forEach { prod ->
                                                    DropdownMenuItem(
                                                        text = { Text(prod.product.name) },
                                                        onClick = {
                                                            viewModel.linkUnlinkedImageToProduct(img, prod.product.id)
                                                            pickMenu = false
                                                        },
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Button(
                                onClick = onDoneGoToProducts,
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("excel_done_btn"),
                            ) {
                                Text("عرض المنتجات المستوردة")
                            }
                        }
                    }
                }
            }
        }
    }

    zoomPreviewImage?.let { img ->
        val bmp = remember(img.id) { BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size) }
        var scale by remember { mutableFloatStateOf(1f) }
        AlertDialog(
            onDismissRequest = { zoomPreviewImage = null },
            title = { Text(img.fileName) },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ -> scale = (scale * zoom).coerceIn(1f, 4f) }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = img.fileName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale),
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { zoomPreviewImage = null }) { Text("إغلاق") }
            },
        )
    }

    editingFailedDownload?.let { dl ->
        var newUrlText by remember(dl.id) { mutableStateOf(dl.sourceUrl) }
        AlertDialog(
            onDismissRequest = { editingFailedDownload = null },
            title = { Text("تعديل رابط الصورة البديل") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "${dl.productName} • باركود: ${dl.barcode.ifBlank { "-" }}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    OutlinedTextField(
                        value = newUrlText,
                        onValueChange = { newUrlText = it },
                        label = { Text("الرابط الجديد (HTTPS أو HTTP)") },
                        singleLine = false,
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("edit_failed_url_input"),
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = newUrlText.isNotBlank(),
                    onClick = {
                        val updatedUrl = newUrlText.trim()
                        editingFailedDownload = null
                        viewModel.updateAndRetryFailedDownloadUrl(dl.id, updatedUrl)
                    },
                    modifier = Modifier.testTag("confirm_edit_failed_url_btn"),
                ) {
                    Text("حفظ وإعادة التحميل")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingFailedDownload = null }) { Text("إلغاء") }
            },
        )
    }

    if (showOfficialApiDialog) {
        var endpointText by remember { mutableStateOf("") }
        var headerNameText by remember { mutableStateOf("Authorization") }
        var headerValueText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showOfficialApiDialog = false },
            title = { Text("استيراد الصور عبر API مصدر رسمي") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "أدخل رابط HTTPS رسمي ومصرّح به فقط (يدعم قالب {barcode} أو {sku} أو ملف كتالوج JSON).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = endpointText,
                        onValueChange = { endpointText = it },
                        label = { Text("رابط HTTPS أو القالب") },
                        placeholder = { Text("https://api.supplier.com/images/{barcode}.webp") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("official_api_endpoint_input"),
                    )
                    OutlinedTextField(
                        value = headerNameText,
                        onValueChange = { headerNameText = it },
                        label = { Text("اسم ترويسة التفويض (اختياري)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = headerValueText,
                        onValueChange = { headerValueText = it },
                        label = { Text("رمز التفويض / API Key (اختياري)") },
                        placeholder = { Text("Bearer ...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = endpointText.isNotBlank(),
                    onClick = {
                        showOfficialApiDialog = false
                        viewModel.retryFailedUsingAuthorizedApi(
                            endpointOrTemplate = endpointText.trim(),
                            authHeaderName = headerNameText.trim().ifBlank { "Authorization" },
                            authHeaderValue = headerValueText.trim(),
                        )
                    },
                    modifier = Modifier.testTag("confirm_official_api_btn"),
                ) {
                    Text("جلب الصور الفاشلة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOfficialApiDialog = false }) { Text("إلغاء") }
            },
        )
    }

    if (showBackendSallaDialog) {
        var backendUrlInput by remember(state.backendServiceUrl) { mutableStateOf(state.backendServiceUrl) }
        var backendTokenInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showBackendSallaDialog = false },
            title = { Text("الخدمة الخلفية ومزامنة سلة الرسمية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "يتم تنزيل الصور عبر خادم HTTPS مخصص يتحقق من نوع المحتوى وحجم الملف، بينما تبقى مفاتيح Salla OAuth والرموز سرية داخل الخادم فقط.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = backendUrlInput,
                        onValueChange = { backendUrlInput = it },
                        label = { Text("رابط الخادم الخلفي (HTTPS)") },
                        placeholder = { Text("https://images.your-domain.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("backend_service_url_input"),
                    )
                    OutlinedTextField(
                        value = backendTokenInput,
                        onValueChange = { backendTokenInput = it },
                        label = { Text("رمز الوصول للخادم (اختياري - للجلسة فقط)") },
                        placeholder = { Text("BACKEND_ACCESS_TOKEN") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("backend_access_token_input"),
                    )
                    Button(
                        enabled = backendUrlInput.isNotBlank() && !state.isProcessingFallback,
                        onClick = {
                            showBackendSallaDialog = false
                            viewModel.saveAndRetryViaBackendService(backendUrlInput, backendTokenInput)
                        },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("confirm_backend_fetch_btn"),
                    ) {
                        Text("تنزيل الصور الفاشلة عبر الخادم")
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(8.dp),
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                "ربط متجر سلة الرسمي (OAuth 2.0)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                "النطاقات المطلوبة في بوابة شركاء سلة: products.read و offline_access مع ضبط Callback URL على /api/salla/auth/callback.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            state.sallaStatus?.let { st ->
                                val stLabel = when {
                                    st.connected -> "متجر سلة مربوط وجاهز للمزامنة"
                                    st.configured -> "التطبيق مهيأ وبانتظار تفويض التاجر"
                                    else -> "المفاتيح غير مضبوطة بعد على الخادم"
                                }
                                Text(
                                    stLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (st.connected) StatusSuccess else StatusWarning,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                OutlinedButton(
                                    enabled = backendUrlInput.isNotBlank() && !state.isProcessingFallback,
                                    onClick = { viewModel.checkSallaBackendStatus(backendUrlInput, backendTokenInput) },
                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("check_salla_status_btn"),
                                ) {
                                    Text("فحص الحالة", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                OutlinedButton(
                                    enabled = backendUrlInput.isNotBlank() && !state.isProcessingFallback,
                                    onClick = { viewModel.requestSallaOAuthUrl(backendUrlInput, backendTokenInput) },
                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("launch_salla_oauth_btn"),
                                ) {
                                    Text("ربط متجر سلة", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Button(
                                enabled = backendUrlInput.isNotBlank() && !state.isProcessingFallback,
                                onClick = {
                                    showBackendSallaDialog = false
                                    viewModel.syncSallaCatalogViaBackend(backendUrlInput, backendTokenInput)
                                },
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("sync_salla_catalog_btn"),
                            ) {
                                Text("مزامنة صور المنتجات من سلة API")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBackendSallaDialog = false }) { Text("إغلاق") }
            },
        )
    }
}
