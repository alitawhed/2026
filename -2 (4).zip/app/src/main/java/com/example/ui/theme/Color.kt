package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Commercial Executive Palette — Deep Slate Navy, Emerald Teal, Warm Gold Amber
val BrandNavy = Color(0xFF0F172A)
val BrandNavyContainer = Color(0xFF1E293B)
val BrandEmerald = Color(0xFF0D9488)
val BrandEmeraldDark = Color(0xFF0F766E)
val BrandEmeraldLight = Color(0xFF2DD4BF)
val BrandAmber = Color(0xFFD97706)
val BrandAmberLight = Color(0xFFFBBF24)

// Light Surface Hierarchy
val LightBackground = Color(0xFFF6F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAF0F6)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)
val LightOutlineVariant = Color(0xFFE2E8F0)

// Dark Surface Hierarchy
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)
val DarkOutlineVariant = Color(0xFF1E293B)

// Semantic Status Colors
val StatusSuccess = Color(0xFF16A34A)
val StatusSuccessContainer = Color(0xFFDCFCE7)
val StatusWarning = Color(0xFFD97706)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusError = Color(0xFFDC2626)
val StatusErrorContainer = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF0284C7)
val StatusInfoContainer = Color(0xFFE0F2FE)
