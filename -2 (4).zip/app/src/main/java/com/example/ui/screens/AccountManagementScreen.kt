package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.auth.AuthProviderType
import com.example.domain.auth.AuthUserProfile
import com.example.domain.auth.PasswordValidationResult
import com.example.ui.components.AppScreenTopBar
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun AccountManagementScreen(
    viewModel: AuthViewModel,
    activeWorkspaceLabel: String = "البيانات المحلية الافتراضية",
    onBack: () -> Unit,
    onOpenAuthScreen: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showLinkEmailDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var unlinkTarget by remember { mutableStateOf<AuthProviderType?>(null) }
    var showManualReauthDialog by remember { mutableStateOf(false) }
    var reauthPasswordInput by remember { mutableStateOf("") }
    var showLinkPassword by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.refreshConfigStatus()
    }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeStatusMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Top + WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal,
        ),
        topBar = {
            AppScreenTopBar(
                title = "إدارة الحساب والربط",
                subtitle = "وسائل الدخول والأمان وعزل البيانات",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 580.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("account_management_container"),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                state.errorMessage?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("account_mgmt_error_banner"),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }

                val user = state.currentUser
                if (user == null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("account_mgmt_signed_out_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(
                                text = "لا يوجد حساب مسجل حالياً",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "تعمل حالياً على مساحة العمل المحلية ($activeWorkspaceLabel). يمكنك تسجيل الدخول أو إنشاء حساب لإدارة ربط Google والبريد الإلكتروني.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Button(
                                onClick = onOpenAuthScreen,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("account_mgmt_go_auth_btn"),
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("الانتقال إلى تسجيل الدخول")
                            }
                        }
                    }
                } else {
                    AccountIdentitySummaryCard(
                        user = user,
                        activeWorkspaceLabel = activeWorkspaceLabel,
                        isBusy = state.isBusy,
                        onResendVerification = viewModel::resendVerificationEmail,
                        onRefreshVerification = viewModel::refreshEmailVerificationStatus,
                    )

                    LinkedProvidersCard(
                        user = user,
                        linkEmailInput = state.linkEmailInput,
                        linkPasswordInput = state.linkPasswordInput,
                        linkConfirmPasswordInput = state.linkConfirmPasswordInput,
                        linkPasswordPolicy = state.linkPasswordPolicy,
                        showLinkEmailForm = showLinkEmailDialog,
                        showLinkPassword = showLinkPassword,
                        isBusy = state.isBusy,
                        isGoogleReady = state.configStatus.isReadyForGoogleSignIn,
                        onLinkGoogle = { viewModel.linkGoogleAccount(context) },
                        onOpenLinkEmailForm = {
                            viewModel.updateLinkEmailPasswordInputs(email = user.email)
                            showLinkEmailDialog = true
                        },
                        onCloseLinkEmailForm = { showLinkEmailDialog = false },
                        onToggleShowLinkPassword = { showLinkPassword = !showLinkPassword },
                        onUpdateLinkInputs = { email, pass, confirm ->
                            viewModel.updateLinkEmailPasswordInputs(
                                email = email,
                                password = pass,
                                confirmPassword = confirm,
                            )
                        },
                        onSubmitLinkEmail = {
                            viewModel.linkEmailPassword()
                            showLinkEmailDialog = false
                        },
                        onChangePassword = { showChangePasswordDialog = true },
                        onRequestUnlink = { provider -> unlinkTarget = provider },
                    )

                    SecurityActionsCard(
                        user = user,
                        isBusy = state.isBusy,
                        onRequestReauth = { showManualReauthDialog = true },
                        onOpenPrivacyPolicy = onOpenPrivacyPolicy,
                        onSignOut = { viewModel.signOut(context) },
                        onRequestDelete = { showDeleteConfirmDialog = true },
                    )
                }
            }
        }
    }

    // Confirm Unlink Provider Dialog
    unlinkTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { unlinkTarget = null },
            title = { Text("تأكيد فك الربط", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل تريد فك ربط «${target.arabicLabel}» من حسابك؟ ستظل قادراً على الدخول بوسيلة الدخول الأخرى المرتبطة بنفس الحساب، ولن تتأثر بياناتك المحلية.",
                    style = MaterialTheme.typography.bodySmall,
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = target
                        unlinkTarget = null
                        viewModel.unlinkProvider(p)
                    },
                    modifier = Modifier.testTag("account_confirm_unlink_btn"),
                ) {
                    Text("فك الربط")
                }
            },
            dismissButton = {
                TextButton(onClick = { unlinkTarget = null }) {
                    Text("إلغاء")
                }
            },
        )
    }

    // Change Password Dialog
    if (showChangePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("تغيير كلمة المرور", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (state.currentUser?.hasEmailPasswordProvider == true) {
                        OutlinedTextField(
                            value = state.currentPasswordForChange,
                            onValueChange = { viewModel.updateChangePasswordInputs(currentPassword = it) },
                            label = { Text("كلمة المرور الحالية") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    OutlinedTextField(
                        value = state.newPasswordForChange,
                        onValueChange = { viewModel.updateChangePasswordInputs(newPassword = it) },
                        label = { Text("كلمة المرور الجديدة (8 أحرف مع رقم وحرف)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = state.confirmNewPasswordForChange,
                        onValueChange = { viewModel.updateChangePasswordInputs(confirmNewPassword = it) },
                        label = { Text("تأكيد كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.changePassword()
                        showChangePasswordDialog = false
                    },
                    enabled = !state.isBusy,
                ) {
                    Text("حفظ كلمة المرور")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }

    // Reauthentication Dialog (either manual request or Firebase requiresRecentLogin)
    if (state.requiresRecentLoginOperation != null || showManualReauthDialog) {
        val opLabel = state.requiresRecentLoginOperation ?: "تحديث جلسة الأمان"
        AlertDialog(
            onDismissRequest = {
                showManualReauthDialog = false
                viewModel.clearMessages()
            },
            title = { Text("إعادة تأكيد الهوية", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "لتأمين عملية «$opLabel» يرجى تأكيد هويتك الآن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (state.currentUser?.hasEmailPasswordProvider == true) {
                        OutlinedTextField(
                            value = reauthPasswordInput,
                            onValueChange = { reauthPasswordInput = it },
                            label = { Text("كلمة المرور الحالية") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_reauth_password_input"),
                        )
                        Button(
                            onClick = {
                                val pw = reauthPasswordInput
                                reauthPasswordInput = ""
                                showManualReauthDialog = false
                                viewModel.reauthenticateWithEmail(pw)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_reauth_email_btn"),
                        ) {
                            Text("تأكيد بكلمة المرور")
                        }
                    }
                    if (state.currentUser?.hasGoogleProvider == true) {
                        OutlinedButton(
                            onClick = {
                                showManualReauthDialog = false
                                viewModel.reauthenticateWithGoogle(context)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_reauth_google_btn"),
                        ) {
                            Text("تأكيد عبر حساب Google")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showManualReauthDialog = false
                        viewModel.clearMessages()
                    },
                ) {
                    Text("إغلاق")
                }
            },
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            icon = {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            },
            title = { Text("تأكيد حذف حساب Firebase", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "سيتم حذف حساب المصادقة في Firebase نهائياً.\n" +
                        "• تبقى بياناتك المحلية على الجهاز ونسخ ZIP الاحتياطية محفوظة كما هي.\n" +
                        "• اشتراكات Google Play تظل خاضعة لإدارة Google Play ويجب إلغاؤها من المتجر عند الحاجة.",
                    style = MaterialTheme.typography.bodySmall,
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteAccount()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("account_confirm_delete_btn"),
                ) {
                    Text("حذف الحساب نهائياً")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }
}

@Composable
private fun AccountIdentitySummaryCard(
    user: AuthUserProfile,
    activeWorkspaceLabel: String,
    isBusy: Boolean,
    onResendVerification: () -> Unit,
    onRefreshVerification: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("account_mgmt_profile_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = null,
                    tint = BrandNavy,
                    modifier = Modifier.size(42.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = user.effectiveDisplayLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    if (user.email.isNotBlank()) {
                        Text(
                            text = user.email,
                            style = MaterialTheme.typography.bodySmall.copy(textDirection = TextDirection.Ltr),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Text(
                        text = "معرّف الحساب الثابت (UID): ${user.uid}",
                        style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                        modifier = Modifier.testTag("account_uid_label"),
                    )
                    Text(
                        text = "مساحة العمل النشطة: $activeWorkspaceLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusInfo,
                    )
                }
            }

            if (!user.isAccountVerified) {
                Surface(
                    color = StatusWarning.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Default.MarkEmailUnread, contentDescription = null, tint = StatusWarning)
                            Text("البريد غير موثق بعد (مطلوب للربط والأمان)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = onResendVerification,
                                enabled = !isBusy,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            ) {
                                Text("إعادة الإرسال")
                            }
                            Button(
                                onClick = onRefreshVerification,
                                enabled = !isBusy,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تحديث التحقق")
                            }
                        }
                    }
                }
            } else {
                Surface(
                    color = StatusSuccess.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = StatusSuccess)
                        Text(
                            text = "حساب موثق وجاهز",
                            style = MaterialTheme.typography.labelMedium,
                            color = StatusSuccess,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LinkedProvidersCard(
    user: AuthUserProfile,
    linkEmailInput: String,
    linkPasswordInput: String,
    linkConfirmPasswordInput: String,
    linkPasswordPolicy: PasswordValidationResult,
    showLinkEmailForm: Boolean,
    showLinkPassword: Boolean,
    isBusy: Boolean,
    isGoogleReady: Boolean,
    onLinkGoogle: () -> Unit,
    onOpenLinkEmailForm: () -> Unit,
    onCloseLinkEmailForm: () -> Unit,
    onToggleShowLinkPassword: () -> Unit,
    onUpdateLinkInputs: (email: String?, pass: String?, confirm: String?) -> Unit,
    onSubmitLinkEmail: () -> Unit,
    onChangePassword: () -> Unit,
    onRequestUnlink: (AuthProviderType) -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("account_linked_providers_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = "طرق تسجيل الدخول المرتبطة بالحساب",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "ربط Google والبريد الإلكتروني يتم على نفس معرّف الحساب (UID) دون إنشاء حساب ثانٍ ودون دمج حسابات منفصلة تلقائياً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // Google Provider Row
            ProviderRowItem(
                title = AuthProviderType.GOOGLE.arabicLabel,
                isLinked = user.hasGoogleProvider,
                canUnlink = user.hasGoogleProvider && user.providers.size > 1,
                actionLabelWhenUnlinked = if (isGoogleReady) "ربط حساب Google" else "ربط Google (غير مهيأ)",
                isBusy = isBusy,
                linkTag = "account_link_google_btn",
                unlinkTag = "account_unlink_google_btn",
                onLink = onLinkGoogle,
                onUnlink = { onRequestUnlink(AuthProviderType.GOOGLE) },
            )

            HorizontalDivider()

            // Email/Password Provider Row
            ProviderRowItem(
                title = AuthProviderType.EMAIL_PASSWORD.arabicLabel,
                isLinked = user.hasEmailPasswordProvider,
                canUnlink = user.hasEmailPasswordProvider && user.providers.size > 1,
                actionLabelWhenUnlinked = "ربط بريد وكلمة مرور",
                isBusy = isBusy,
                linkTag = "account_link_email_btn",
                unlinkTag = "account_unlink_email_btn",
                onLink = onOpenLinkEmailForm,
                onUnlink = { onRequestUnlink(AuthProviderType.EMAIL_PASSWORD) },
            )

            if (!user.hasEmailPasswordProvider && showLinkEmailForm) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "إضافة البريد الإلكتروني وكلمة المرور لنفس الحساب",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        OutlinedTextField(
                            value = linkEmailInput,
                            onValueChange = { onUpdateLinkInputs(it, null, null) },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_link_email_input"),
                        )
                        OutlinedTextField(
                            value = linkPasswordInput,
                            onValueChange = { onUpdateLinkInputs(null, it, null) },
                            label = { Text("كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = onToggleShowLinkPassword) {
                                    Icon(
                                        imageVector = if (showLinkPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "إظهار أو إخفاء كلمة المرور",
                                    )
                                }
                            },
                            visualTransformation = if (showLinkPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_link_password_input"),
                        )
                        LinkPasswordPolicyBox(linkPasswordPolicy)
                        OutlinedTextField(
                            value = linkConfirmPasswordInput,
                            onValueChange = { onUpdateLinkInputs(null, null, it) },
                            label = { Text("تأكيد كلمة المرور") },
                            visualTransformation = if (showLinkPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_link_confirm_password_input"),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = onCloseLinkEmailForm,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            ) {
                                Text("إلغاء")
                            }
                            Button(
                                onClick = onSubmitLinkEmail,
                                enabled = !isBusy,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("account_confirm_link_email_btn"),
                            ) {
                                Text("ربط بالحساب")
                            }
                        }
                    }
                }
            }

            if (user.hasEmailPasswordProvider) {
                OutlinedButton(
                    onClick = onChangePassword,
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("account_change_password_btn"),
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("تغيير كلمة المرور")
                }
            }
        }
    }
}

@Composable
private fun ProviderRowItem(
    title: String,
    isLinked: Boolean,
    canUnlink: Boolean,
    actionLabelWhenUnlinked: String,
    isBusy: Boolean,
    linkTag: String,
    unlinkTag: String,
    onLink: () -> Unit,
    onUnlink: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(
                text = if (isLinked) "مرتبط حالياً بهذا الحساب" else "غير مرتبط",
                style = MaterialTheme.typography.labelSmall,
                color = if (isLinked) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (isLinked) {
            OutlinedButton(
                onClick = onUnlink,
                enabled = !isBusy && canUnlink,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag(unlinkTag),
            ) {
                Icon(Icons.Default.LinkOff, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (canUnlink) "فك الربط" else "أساسي")
            }
        } else {
            Button(
                onClick = onLink,
                enabled = !isBusy,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag(linkTag),
            ) {
                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(actionLabelWhenUnlinked)
            }
        }
    }
}

@Composable
private fun SecurityActionsCard(
    user: AuthUserProfile,
    isBusy: Boolean,
    onRequestReauth: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onSignOut: () -> Unit,
    onRequestDelete: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "الأمان وإدارة الجلسة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            OutlinedButton(
                onClick = onRequestReauth,
                enabled = !isBusy && user.providers.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("account_reauth_trigger_btn"),
            ) {
                Icon(Icons.Default.Security, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("إعادة تأكيد الهوية للعمليات الحساسة")
            }
            OutlinedButton(
                onClick = onOpenPrivacyPolicy,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("account_privacy_policy_btn"),
            ) {
                Icon(Icons.Default.Info, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("سياسة الخصوصية وحذف الحساب")
            }
            OutlinedButton(
                onClick = onSignOut,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("account_sign_out_btn"),
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("تسجيل الخروج (مع حفظ البيانات المحلية)")
            }
            TextButton(
                onClick = onRequestDelete,
                enabled = !isBusy,
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("account_delete_btn"),
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("حذف حساب Firebase نهائياً")
            }
        }
    }
}

@Composable
private fun LinkPasswordPolicyBox(policy: PasswordValidationResult) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            LinkPolicyRow("8 أحرف على الأقل", policy.hasMinLength)
            LinkPolicyRow("حرف واحد على الأقل", policy.hasLetter)
            LinkPolicyRow("رقم واحد على الأقل", policy.hasDigit)
            LinkPolicyRow("بدون مسافات", policy.hasNoSpaces)
        }
    }
}

@Composable
private fun LinkPolicyRow(label: String, passed: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = if (passed) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(14.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (passed) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
