package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.formatArabicDateTime
import com.example.ui.components.shareFileViaProvider
import com.example.ui.theme.StatusError
import com.example.ui.viewmodel.BackupRestoreViewModel
import java.io.File

@Composable
fun BackupRestoreScreen(
    viewModel: BackupRestoreViewModel,
    onBack: () -> Unit,
    onOpenDiagnostics: () -> Unit = {},
) {
    val history by viewModel.history.collectAsStateWithLifecycle()
    val isWorking by viewModel.isWorking.collectAsStateWithLifecycle()
    val pendingInspection by viewModel.pendingInspection.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val restoreError by viewModel.restoreError.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var customBackupName by remember { mutableStateOf("") }

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.inspectBackupUri(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "النسخ الاحتياطي والاستعادة",
                subtitle = "حفظ واسترجاع القاعدة والصور والقوالب في ملف ZIP",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (isWorking) {
                item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
            }

            restoreError?.let { errText ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "فشل استعادة النسخة الاحتياطية",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                            Text(
                                errText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = onOpenDiagnostics,
                                    modifier = Modifier.testTag("restore_error_diagnostics_btn"),
                                ) {
                                    Icon(Icons.Default.BugReport, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("عرض تفاصيل التشخيص")
                                }
                                TextButton(onClick = { viewModel.clearRestoreError() }) {
                                    Text("إخفاء")
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("إنشاء نسخة احتياطية شاملة (ZIP)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "تشمل: المنتجات، كافة الباركودات، جميع الصور، التقارير والأرشيف، القوالب، الأعمدة، وإعدادات التطبيق مع بصمات التحقق SHA-256 لنقل آمن بين الهواتف.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedTextField(
                            value = customBackupName,
                            onValueChange = { customBackupName = it },
                            label = { Text("اسم مخصص للنسخة (اختياري)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                enabled = !isWorking,
                                onClick = {
                                    viewModel.createBackup(customBackupName) { file ->
                                        shareFileViaProvider(context, file, "application/zip", "حفظ أو مشاركة النسخة الاحتياطية")
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("create_backup_btn"),
                            ) {
                                Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("إنشاء وحفظ النسخة")
                            }
                            FilledTonalButton(
                                enabled = !isWorking,
                                onClick = { zipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                                modifier = Modifier.weight(1f).testTag("restore_backup_btn"),
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("استعادة من ملف")
                            }
                        }
                    }
                }
            }

            item {
                Text("سجل النسخ الاحتياطي والاستعادة (${history.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            items(history, key = { it.id }) { h ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(h.fileName, fontWeight = FontWeight.Bold)
                            Text(
                                "${if (h.operationType == "RESTORE") "استعادة" else "نسخ احتياطي"} • ${formatArabicDateTime(h.createdAt)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                "منتجات: ${h.productCount} • باركودات: ${h.barcodeCount} • صور: ${h.imageCount} • تقارير: ${h.reportCount}",
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        if (h.filePath.isNotBlank() && File(h.filePath).exists()) {
                            IconButton(onClick = {
                                shareFileViaProvider(context, File(h.filePath), "application/zip", "مشاركة النسخة الاحتياطية")
                            }) {
                                Icon(Icons.Default.Share, contentDescription = "مشاركة")
                            }
                        }
                    }
                }
            }
        }
    }

    pendingInspection?.let { insp ->
        AlertDialog(
            onDismissRequest = { viewModel.clearPendingInspection() },
            title = { Text(if (insp.isValid) "ملخص النسخة الاحتياطية قبل الاستعادة" else "نسخة احتياطية غير صالحة") },
            text = {
                if (!insp.isValid) {
                    Text(insp.errorMessage ?: "الملف تالف", color = StatusError)
                } else {
                    val m = insp.manifest!!
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("التطبيق: ${m.appName} (${m.appVersion.ifBlank { "1.0" }})")
                        Text("تاريخ الإنشاء: ${formatArabicDateTime(m.createdAt)}")
                        Text("إصدار التنسيق: v${m.formatVersion} • مخطط القاعدة: v${m.databaseSchemaVersion}")
                        Text("المنتجات: ${m.productCount}")
                        Text("الباركودات: ${m.barcodeCount}")
                        Text("الصور والملفات: ${m.imageCount}")
                        Text("التقارير: ${m.reportCount}")
                        Text("القوالب: ${m.templateCount}")
                        Text("جلسات الجرد: ${m.inventorySessionCount} (${m.inventoryItemCount} بند)")
                        if (insp.missingFiles.isNotEmpty()) {
                            Text("تحذير: يوجد ${insp.missingFiles.size} ملف مفقود داخل الأرشيف.", color = StatusError)
                        }
                        if (insp.corruptedFiles.isNotEmpty()) {
                            Text("تحذير: يوجد ${insp.corruptedFiles.size} ملف تالف داخل الأرشيف وسيتم تخطيه.", color = StatusError)
                        }
                        Text(
                            "تنبيه: ستؤدي الاستعادة إلى استبدال البيانات الحالية بمحتويات هذه النسخة مع الحفاظ على بيانات الجهاز إذا فشل التحقق.",
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            },
            confirmButton = {
                if (insp.isValid) {
                    Button(
                        onClick = { viewModel.confirmAndRestore(insp.sourceDisplayName) },
                        modifier = Modifier.testTag("confirm_restore_btn"),
                    ) {
                        Text("تأكيد الاستعادة")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.clearPendingInspection() }) { Text("إلغاء") }
            },
        )
    }
}
