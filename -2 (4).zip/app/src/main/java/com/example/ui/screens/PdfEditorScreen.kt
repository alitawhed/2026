package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Merge
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Rectangle
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.di.AppContainer
import com.example.domain.pdf.PdfOverlayItem
import com.example.domain.pdf.PdfOverlayType
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintHelper
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatArabicDateTime
import com.example.ui.components.shareFileViaProvider
import com.example.ui.viewmodel.PdfEditorViewModel
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PdfEditorScreen(
    initialPdfPath: String,
    documentId: Long,
    container: AppContainer,
    viewModel: PdfEditorViewModel,
    onBack: () -> Unit,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val savedDocs by viewModel.savedDocuments.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(initialPdfPath, documentId) {
        viewModel.initializeFromArgs(initialPdfPath, documentId)
    }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val openPdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.openPdfUri(it) }
    }
    val mergePdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.mergeAnotherPdf(it) }
    }
    val overlayImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { viewModel.addImageOverlayFromUri(it) }
    }

    var activeToolTab by remember { mutableIntStateOf(0) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var showCropPageDialog by remember { mutableStateOf(false) }
    var showExtractRangeDialog by remember { mutableStateOf(false) }
    var showExtractedImagesDialog by remember { mutableStateOf(false) }

    val doc = state.document

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = doc?.title ?: "محرر PDF الاحترافي",
                subtitle = doc?.let { "صفحة ${state.activePageIndex + 1} من ${it.pages.size} • تحرير غير متلف" } ?: "تعديل ودمج وتقسيم واستخراج ملفات PDF",
                onBack = onBack,
                actions = {
                    if (doc != null) {
                        IconButton(enabled = state.canUndo, onClick = { viewModel.undo() }, modifier = Modifier.testTag("pdf_editor_undo")) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع")
                        }
                        IconButton(enabled = state.canRedo, onClick = { viewModel.redo() }, modifier = Modifier.testTag("pdf_editor_redo")) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة")
                        }
                        IconButton(
                            onClick = { viewModel.saveEditedPdfCopy() },
                            modifier = Modifier.testTag("pdf_editor_save_btn"),
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "حفظ نسخة PDF جديدة")
                        }
                        IconButton(onClick = {
                            viewModel.saveEditedPdfCopy { file ->
                                shareFileViaProvider(context, file, "application/pdf", "مشاركة PDF المعدل")
                            }
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "مشاركة PDF")
                        }
                        IconButton(
                            enabled = !state.isBusy,
                            onClick = {
                                viewModel.saveEditedPdfCopy { file ->
                                    val res = SafePdfPrintHelper.printPdfWithActivity(
                                        context = context,
                                        pdfFile = file,
                                        jobName = file.nameWithoutExtension,
                                    )
                                    if (res is PrintDispatchResult.Error) {
                                        scope.launch { snackbarHostState.showSnackbar(res.message) }
                                    }
                                }
                            },
                        ) {
                            Icon(Icons.Default.Print, contentDescription = "طباعة PDF")
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        if (doc == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(
                    onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("pdf_editor_open_file_btn"),
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("فتح ملف PDF من الجهاز للتحرير")
                }

                Text("مستندات PDF في مساحة العمل (${savedDocs.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                if (savedDocs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        EmptyStateCard(
                            title = "مساحة عمل PDF جاهزة",
                            description = "افتح أي ملف PDF من جهازك أو من معاينة أي تقرير لقص الصفحات وتدويرها ودمجها وإضافة النصوص والصور واستخراج المحتوى بأمان تام.",
                            icon = Icons.Default.PictureAsPdf,
                            actionLabel = "اختيار ملف PDF",
                            onAction = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                        )
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(savedDocs, key = { it.document.id }) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { viewModel.openSavedDocument(item.document.id) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Column {
                                            Text(item.document.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(
                                                "${item.pages.size} صفحة • ${if (item.document.isEditedCopy) "نسخة معدلة" else "أصلي في مساحة العمل"} • ${formatArabicDateTime(item.document.updatedAt)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                    IconButton(onClick = { viewModel.deleteSavedDocument(item.document.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف السجل", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return@Scaffold
        }

        // Active PDF Editor Workspace
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // Zoomable Page Canvas + Overlays Strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1E293B))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomScale = (zoomScale * zoom).coerceIn(1f, 3.8f)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                val bmp = state.pagePreviewBitmap
                if (state.isBusy) {
                    CircularProgressIndicator(color = Color.White)
                } else if (bmp != null) {
                    Surface(
                        shadowElevation = 6.dp,
                        color = Color.White,
                        modifier = Modifier
                            .padding(10.dp)
                            .graphicsLayer(scaleX = zoomScale, scaleY = zoomScale),
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "صفحة PDF",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                } else {
                    Text("تعذر عرض الصفحة", color = Color.White)
                }

                // Active Overlay Pills at Bottom-End for quick selection
                val pageOverlays = doc.overlays.filter { it.pageIndex == state.activePageIndex }
                if (pageOverlays.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        pageOverlays.forEachIndexed { idx, ov ->
                            FilterChip(
                                selected = state.selectedOverlayId == ov.id,
                                onClick = { viewModel.selectOverlay(if (state.selectedOverlayId == ov.id) null else ov.id) },
                                label = {
                                    Text(
                                        ov.text.takeIf { it.isNotBlank() }?.take(14) ?: "${ov.type.arabicLabel} #${idx + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                },
                            )
                        }
                    }
                }
            }

            // Selected Overlay Position & Delete Micro-Bar
            val selectedOverlay = doc.overlays.firstOrNull { it.id == state.selectedOverlayId }
            if (selectedOverlay != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("تحريك العنصر المحدد:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Row {
                            IconButton(onClick = { viewModel.nudgeSelectedOverlay(-0.04f, 0f) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "يسار")
                            }
                            IconButton(onClick = { viewModel.nudgeSelectedOverlay(0.04f, 0f) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "يمين")
                            }
                            IconButton(onClick = { viewModel.nudgeSelectedOverlay(0f, -0.04f) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "أعلى")
                            }
                            IconButton(onClick = { viewModel.nudgeSelectedOverlay(0f, 0.04f) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "أسفل")
                            }
                            IconButton(onClick = { viewModel.deleteSelectedOverlay() }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف العنصر", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            // Pages Strip
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(doc.pages, key = { idx, p -> "${p.id}_$idx" }) { idx, p ->
                    val selected = idx == state.activePageIndex
                    Surface(
                        onClick = { viewModel.selectPage(idx) },
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(
                                text = "ص ${idx + 1}" + (if (p.isBlankPage) " (فارغة)" else "") + (if (p.rotationDegrees != 0) " ${p.rotationDegrees}°" else ""),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }

            // Tool Category Tabs
            TabRow(selectedTabIndex = activeToolTab) {
                Tab(selected = activeToolTab == 0, onClick = { activeToolTab = 0 }, text = { Text("الصفحات") })
                Tab(selected = activeToolTab == 1, onClick = { activeToolTab = 1 }, text = { Text("نصوص وصور") })
                Tab(selected = activeToolTab == 2, onClick = { activeToolTab = 2 }, text = { Text("أشكال وتغطية") })
                Tab(selected = activeToolTab == 3, onClick = { activeToolTab = 3 }, text = { Text("استخراج وتقسيم") })
            }

            // Tool Action Strip
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (activeToolTab) {
                        0 -> {
                            OutlinedButton(onClick = { viewModel.rotateActivePage(270) }) {
                                Icon(Icons.AutoMirrored.Filled.RotateLeft, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تدوير يسار")
                            }
                            OutlinedButton(onClick = { viewModel.rotateActivePage(90) }) {
                                Icon(Icons.AutoMirrored.Filled.RotateRight, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تدوير يمين")
                            }
                            OutlinedButton(
                                enabled = state.activePageIndex > 0,
                                onClick = { viewModel.moveActivePage(-1) },
                            ) { Text("تقديم الصفحة") }
                            OutlinedButton(
                                enabled = state.activePageIndex < doc.pages.lastIndex,
                                onClick = { viewModel.moveActivePage(1) },
                            ) { Text("تأخير الصفحة") }
                            OutlinedButton(onClick = { viewModel.insertBlankPageAfterActive() }) {
                                Icon(Icons.Default.NoteAdd, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("صفحة فارغة")
                            }
                            OutlinedButton(onClick = { showCropPageDialog = true }) {
                                Icon(Icons.Default.Crop, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("قص الهوامش")
                            }
                            OutlinedButton(onClick = { mergePdfLauncher.launch(arrayOf("application/pdf")) }) {
                                Icon(Icons.Default.Merge, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("دمج ملف PDF")
                            }
                            OutlinedButton(
                                enabled = doc.pages.size > 1,
                                onClick = { viewModel.deleteActivePage() },
                            ) {
                                Icon(Icons.Default.Delete, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                                Spacer(Modifier.width(4.dp))
                                Text("حذف الصفحة")
                            }
                        }
                        1 -> {
                            Button(onClick = { showAddTextDialog = true }) {
                                Icon(Icons.Default.TextFields, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("إضافة نص عربي")
                            }
                            OutlinedButton(onClick = {
                                overlayImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) {
                                Icon(Icons.Default.AddPhotoAlternate, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("إدراج صورة/شعار")
                            }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.DATE_STAMP, xFraction = 0.65f, yFraction = 0.05f, widthFraction = 0.28f, heightFraction = 0.05f),
                                )
                            }) {
                                Icon(Icons.Default.CalendarToday, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("ختم التاريخ")
                            }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.PAGE_NUMBER, xFraction = 0.35f, yFraction = 0.93f, widthFraction = 0.30f, heightFraction = 0.05f),
                                )
                            }) {
                                Icon(Icons.Default.Numbers, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("رقم الصفحة")
                            }
                        }
                        2 -> {
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.COVER_BOX, xFraction = 0.15f, yFraction = 0.25f, widthFraction = 0.45f, heightFraction = 0.10f),
                                )
                            }) {
                                Text("صندوق تغطية أبيض")
                            }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.HIGHLIGHT, xFraction = 0.15f, yFraction = 0.20f, widthFraction = 0.50f, heightFraction = 0.05f),
                                )
                            }) {
                                Icon(Icons.Default.Highlight, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تظليل نص")
                            }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.RECTANGLE, xFraction = 0.20f, yFraction = 0.30f, widthFraction = 0.35f, heightFraction = 0.15f, colorHex = "#0D9488"),
                                )
                            }) {
                                Icon(Icons.Default.Rectangle, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("إطار مستطيل")
                            }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.LINE, xFraction = 0.12f, yFraction = 0.50f, widthFraction = 0.76f, heightFraction = 0.03f),
                                )
                            }) { Text("خط فاصل") }
                            OutlinedButton(onClick = {
                                viewModel.addOverlay(
                                    PdfOverlayItem(type = PdfOverlayType.CALLOUT, text = "ملاحظة هامة", xFraction = 0.20f, yFraction = 0.60f, widthFraction = 0.42f, heightFraction = 0.10f),
                                )
                            }) {
                                Icon(Icons.Default.EditNote, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("ملصق تعليق")
                            }
                        }
                        3 -> {
                            Button(onClick = { viewModel.extractTextAndOcr() }) {
                                Icon(Icons.Default.DocumentScanner, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("استخراج نص / OCR")
                            }
                            OutlinedButton(onClick = {
                                viewModel.extractImagesFromDocument()
                                showExtractedImagesDialog = true
                            }) {
                                Icon(Icons.Default.PhotoLibrary, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("استخراج الصور")
                            }
                            OutlinedButton(onClick = { showExtractRangeDialog = true }) {
                                Icon(Icons.Default.ContentCut, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("استخراج صفحات")
                            }
                            OutlinedButton(onClick = {
                                viewModel.splitAllPages { }
                            }) {
                                Icon(Icons.Default.CallSplit, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تقسيم كل الصفحات")
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Text Overlay Dialog
    if (showAddTextDialog) {
        var textInput by remember { mutableStateOf("") }
        var fontSize by remember { mutableFloatStateOf(14f) }
        var colorHex by remember { mutableStateOf("#0F172A") }
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text("إضافة نص داخل الصفحة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        label = { Text("النص (يدعم العربية والإنجليزية)") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("حجم الخط: ${fontSize.toInt()}pt")
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 8f..32f)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("#0F172A" to "أسود", "#0D9488" to "أخضر", "#DC2626" to "أحمر", "#1D4ED8" to "أزرق").forEach { (hex, lbl) ->
                            FilterChip(selected = colorHex == hex, onClick = { colorHex = hex }, label = { Text(lbl) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (textInput.isNotBlank()) {
                        viewModel.addOverlay(
                            PdfOverlayItem(
                                type = PdfOverlayType.TEXT,
                                text = textInput,
                                fontSizeSp = fontSize,
                                colorHex = colorHex,
                                xFraction = 0.12f,
                                yFraction = 0.16f,
                                widthFraction = 0.72f,
                                heightFraction = 0.16f,
                            ),
                        )
                    }
                    showAddTextDialog = false
                }) { Text("إدراج") }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) { Text("إلغاء") }
            },
        )
    }

    // Crop Page Margins Dialog
    if (showCropPageDialog && doc != null) {
        val page = doc.pages.getOrNull(state.activePageIndex)
        var left by remember { mutableFloatStateOf(page?.cropLeft ?: 0f) }
        var top by remember { mutableFloatStateOf(page?.cropTop ?: 0f) }
        var right by remember { mutableFloatStateOf(page?.cropRight ?: 1f) }
        var bottom by remember { mutableFloatStateOf(page?.cropBottom ?: 1f) }
        AlertDialog(
            onDismissRequest = { showCropPageDialog = false },
            title = { Text("قص هوامش الصفحة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("الهامش الأيسر: ${(left * 100).toInt()}%")
                    Slider(value = left, onValueChange = { left = it }, valueRange = 0f..0.35f)
                    Text("الهامش العلوي: ${(top * 100).toInt()}%")
                    Slider(value = top, onValueChange = { top = it }, valueRange = 0f..0.35f)
                    Text("الحد الأيمن: ${(right * 100).toInt()}%")
                    Slider(value = right, onValueChange = { right = it }, valueRange = 0.65f..1f)
                    Text("الحد السفلي: ${(bottom * 100).toInt()}%")
                    Slider(value = bottom, onValueChange = { bottom = it }, valueRange = 0.65f..1f)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.cropActivePage(left, top, right, bottom)
                    showCropPageDialog = false
                }) { Text("تطبيق القص") }
            },
            dismissButton = {
                TextButton(onClick = { showCropPageDialog = false }) { Text("إلغاء") }
            },
        )
    }

    // Extract Page Range Dialog
    if (showExtractRangeDialog && doc != null) {
        var fromPage by remember { mutableStateOf("1") }
        var toPage by remember { mutableStateOf(doc.pages.size.toString()) }
        var name by remember { mutableStateOf("${doc.title}_extract") }
        AlertDialog(
            onDismissRequest = { showExtractRangeDialog = false },
            title = { Text("استخراج صفحات محددة إلى ملف PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = fromPage, onValueChange = { fromPage = it }, label = { Text("من صفحة") }, singleLine = true)
                    OutlinedTextField(value = toPage, onValueChange = { toPage = it }, label = { Text("إلى صفحة") }, singleLine = true)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الملف المستخرج") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val f = fromPage.toIntOrNull() ?: 1
                    val t = toPage.toIntOrNull() ?: doc.pages.size
                    showExtractRangeDialog = false
                    viewModel.extractPageRangeToNewPdf(f, t, name) { outFile ->
                        shareFileViaProvider(context, outFile, "application/pdf", "مشاركة الصفحات المستخرجة")
                    }
                }) { Text("استخراج ومشاركة") }
            },
            dismissButton = {
                TextButton(onClick = { showExtractRangeDialog = false }) { Text("إلغاء") }
            },
        )
    }

    // OCR & Extracted Text Review Dialog (Transparent Latin OCR + RTL Arabic manual editing + Cover&Retype)
    state.extractedTextResult?.let { initialText ->
        var editableText by remember(initialText) { mutableStateOf(initialText) }
        AlertDialog(
            onDismissRequest = { viewModel.clearExtractedText() },
            title = { Text("مراجعة النص المستخرج (OCR / PDF)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "ملاحظة: محرك OCR المحلي يقرأ النصوص اللاتينية والأرقام آلياً؛ وللنصوص العربية الممسوحة يمكنك مراجعة أو كتابة النص الصحيح أدناه لإدراجه فوق صندوق تغطية.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = editableText,
                        onValueChange = { editableText = it },
                        label = { Text("النص المراجع") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (editableText.isNotBlank()) {
                        viewModel.applyTextEditWithCoverAndOverlay(editableText)
                    } else {
                        viewModel.clearExtractedText()
                    }
                }) { Text("تغطية وإدراج النص") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.clearExtractedText() }) { Text("إغلاق") }
            },
        )
    }

    // Extracted Embedded Images Dialog (Share or Attach to Product)
    if (showExtractedImagesDialog) {
        AlertDialog(
            onDismissRequest = { showExtractedImagesDialog = false },
            title = { Text("الصور المستخرجة من PDF (${state.extractedImages.size})") },
            text = {
                if (state.extractedImages.isEmpty()) {
                    Text("لا توجد صور JPEG مضمنة في ملف PDF هذا.")
                } else {
                    LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.extractedImages, key = { it.absolutePath }) { imgFile ->
                            val bmp = remember(imgFile.absolutePath) { BitmapFactory.decodeFile(imgFile.absolutePath) }
                            var prodMenu by remember { mutableStateOf(false) }
                            Card(border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = imgFile.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)),
                                        )
                                    }
                                    Text(imgFile.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    IconButton(onClick = { shareFileViaProvider(context, imgFile, "image/jpeg", "مشاركة صورة") }) {
                                        Icon(Icons.Default.Share, contentDescription = "مشاركة")
                                    }
                                    Box {
                                        OutlinedButton(onClick = { prodMenu = true }) { Text("للمنتج") }
                                        DropdownMenu(expanded = prodMenu, onDismissRequest = { prodMenu = false }) {
                                            allProducts.take(40).forEach { prod ->
                                                DropdownMenuItem(
                                                    text = { Text(prod.product.name) },
                                                    onClick = {
                                                        viewModel.attachExtractedImageToProduct(imgFile, prod.product.id)
                                                        prodMenu = false
                                                    },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExtractedImagesDialog = false }) { Text("إغلاق") }
            },
        )
    }
}
