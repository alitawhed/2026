package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.ColumnType

private data class DecimalOptionEntry(
    val id: String,
    val title: String,
    val sampleFormatted: String,
    val isAuto: Boolean,
    val decimals: Int,
)

@Composable
fun DecimalPlacesEditorContent(
    spec: NumberFormatSpec,
    defaultSpec: NumberFormatSpec,
    onSpecChange: (NumberFormatSpec) -> Unit,
    modifier: Modifier = Modifier,
) {
    val norm = spec.normalized()
    val optionEntries = remember {
        listOf(
            DecimalOptionEntry("decimal_opt_0", "صفر منازل عشرية", "20", false, 0),
            DecimalOptionEntry("decimal_opt_1", "منزلة عشرية واحدة", "20.0", false, 1),
            DecimalOptionEntry("decimal_opt_2", "منزلتان عشريتان", "20.00", false, 2),
            DecimalOptionEntry("decimal_opt_3", "ثلاث منازل عشرية", "20.000", false, 3),
            DecimalOptionEntry("decimal_opt_4", "أربع منازل عشرية", "20.0000", false, 4),
            DecimalOptionEntry("decimal_opt_5", "خمس منازل عشرية", "20.00000", false, 5),
            DecimalOptionEntry("decimal_opt_6", "ست منازل عشرية", "20.000000", false, 6),
            DecimalOptionEntry("decimal_opt_auto", "تلقائي حسب القيمة الأصلية", "1 / 15.5 / 15.25", true, 2),
        )
    }

    val previewSamples = remember(norm) {
        listOf(1.0, 20.0, 15.5, 15.25).map { sample ->
            NumberFormatEngine.formatDouble(sample, norm)
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = "معاينة فورية (1، 20، 15.5، 15.25):",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    previewSamples.forEach { formatted ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Text(
                                text = formatted,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            optionEntries.forEach { entry ->
                val selected = if (entry.isAuto) norm.autoDecimals else (!norm.autoDecimals && norm.decimalPlaces == entry.decimals)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        width = if (selected) 1.5.dp else 1.dp,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onSpecChange(
                                if (entry.isAuto) {
                                    norm.copy(autoDecimals = true)
                                } else {
                                    norm.copy(autoDecimals = false, decimalPlaces = entry.decimals)
                                },
                            )
                        }
                        .testTag(entry.id),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(
                                imageVector = if (selected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                text = entry.title,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            )
                        }
                        Text(
                            text = entry.sampleFormatted,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }

        HorizontalDivider()

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = "إخفاء الأصفار العشرية غير الضرورية",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "مثال: 20.00 تصبح 20 و 15.50 تصبح 15.5",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = norm.stripTrailingZeros,
                onCheckedChange = { onSpecChange(norm.copy(stripTrailingZeros = it)) },
                modifier = Modifier.testTag("decimal_strip_zeros_switch"),
            )
        }

        OutlinedButton(
            onClick = { onSpecChange(defaultSpec.normalized()) },
            modifier = Modifier.fillMaxWidth().testTag("decimal_reset_btn"),
        ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("استعادة الافتراضي (${NumberFormatEngine.arabicSummaryLabel(defaultSpec)})")
        }
    }
}

@Composable
fun DecimalPlacesControlDialog(
    columnTitle: String,
    currentSpec: NumberFormatSpec,
    defaultSpec: NumberFormatSpec,
    onDismiss: () -> Unit,
    onSave: (NumberFormatSpec) -> Unit,
) {
    var draft by remember(columnTitle, currentSpec) { mutableStateOf(currentSpec.normalized()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("المنازل العشرية: $columnTitle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = "ينطبق هذا الإعداد على هذا العمود فقط وبشكل مستقل",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                DecimalPlacesEditorContent(
                    spec = draft,
                    defaultSpec = defaultSpec,
                    onSpecChange = { draft = it },
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(draft) },
                modifier = Modifier.testTag("decimal_save_btn"),
            ) {
                Text("اعتماد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        },
    )
}

@Composable
fun ProductsNumericSettingsDialog(
    config: ProductsNumericConfig,
    onDismiss: () -> Unit,
    onSave: (ProductsNumericConfig) -> Unit,
    onResetDefaults: () -> Unit,
) {
    var draft by remember(config) { mutableStateOf(config) }
    var editingField by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنسيق أرقام شاشة المنتجات", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "إعدادات مستقلة لقسم المنتجات فقط ولا تؤثر على الجرد أو التقارير.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                ProductDecimalRowCard(
                    title = "كمية المنتج الافتراضية",
                    spec = draft.quantityFormat,
                    onClick = { editingField = "qty" },
                    tag = "products_decimal_qty_btn",
                )
                ProductDecimalRowCard(
                    title = "سعر المنتج",
                    spec = draft.priceFormat,
                    onClick = { editingField = "price" },
                    tag = "products_decimal_price_btn",
                )
                ProductDecimalRowCard(
                    title = "معامل التحويل للوحدات",
                    spec = draft.conversionFactorFormat,
                    onClick = { editingField = "factor" },
                    tag = "products_decimal_factor_btn",
                )
                OutlinedButton(
                    onClick = {
                        draft = ProductsNumericConfig()
                        onResetDefaults()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("products_decimal_reset_btn"),
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("استعادة افتراضيات المنتجات")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(draft)
                    onDismiss()
                },
                modifier = Modifier.testTag("products_decimal_save_btn"),
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )

    editingField?.let { field ->
        val (title, curSpec, defSpec) = when (field) {
            "qty" -> Triple(
                "كمية المنتج الافتراضية",
                draft.quantityFormat,
                NumberFormatEngine.defaultSpecForColumn(AppNumericSection.PRODUCTS, "quantity", ColumnType.QUANTITY),
            )
            "price" -> Triple(
                "سعر المنتج",
                draft.priceFormat,
                NumberFormatEngine.defaultSpecForColumn(AppNumericSection.PRODUCTS, "price", ColumnType.PRICE),
            )
            else -> Triple(
                "معامل التحويل للوحدات",
                draft.conversionFactorFormat,
                NumberFormatEngine.defaultSpecForColumn(AppNumericSection.PRODUCTS, "conversion_factor", ColumnType.NUMBER),
            )
        }
        DecimalPlacesControlDialog(
            columnTitle = title,
            currentSpec = curSpec,
            defaultSpec = defSpec,
            onDismiss = { editingField = null },
            onSave = { nextSpec ->
                draft = when (field) {
                    "qty" -> draft.copy(quantityFormat = nextSpec)
                    "price" -> draft.copy(priceFormat = nextSpec)
                    else -> draft.copy(conversionFactorFormat = nextSpec)
                }
                editingField = null
            },
        )
    }
}

@Composable
private fun ProductDecimalRowCard(
    title: String,
    spec: NumberFormatSpec,
    onClick: () -> Unit,
    tag: String,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).testTag(tag),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text(
                    NumberFormatEngine.arabicSummaryLabel(spec),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text("تعديل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}
