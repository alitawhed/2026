package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.di.AppContainer
import com.example.domain.billing.BillingActionResult
import com.example.domain.billing.BillingConnectionState
import com.example.domain.billing.PlayBillingConfiguration
import com.example.domain.billing.SubscriptionEntitlementState
import com.example.domain.billing.SubscriptionOfferUiModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SubscriptionUiState(
    val connectionState: BillingConnectionState = BillingConnectionState.IDLE,
    val offers: List<SubscriptionOfferUiModel> = emptyList(),
    val entitlement: SubscriptionEntitlementState = SubscriptionEntitlementState(),
    val billingConfig: PlayBillingConfiguration = PlayBillingConfiguration(),
    val currentUserEmail: String? = null,
    val currentUserUid: String? = null,
    val workspaceLabel: String = "",
    val isBusy: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
)

class SubscriptionViewModel(private val container: AppContainer) : ViewModel() {

    private val billingGateway = container.billingGateway
    private val localFeedback = MutableStateFlow<Pair<String?, String?>>(null to null)

    val uiState: StateFlow<SubscriptionUiState> = combine(
        billingGateway.connectionState,
        billingGateway.availableOffers,
        billingGateway.entitlementState,
        billingGateway.billingConfiguration,
        billingGateway.isBusy,
        billingGateway.lastStatusMessage,
        container.authGateway.authStateFlow,
        localFeedback,
    ) { arr ->
        val conn = arr[0] as BillingConnectionState
        @Suppress("UNCHECKED_CAST")
        val offers = arr[1] as List<SubscriptionOfferUiModel>
        val ent = arr[2] as SubscriptionEntitlementState
        val cfg = arr[3] as PlayBillingConfiguration
        val busy = arr[4] as Boolean
        val gatewayMsg = arr[5] as String?
        val authUser = arr[6] as com.example.domain.auth.AuthUserProfile?
        @Suppress("UNCHECKED_CAST")
        val feedback = arr[7] as Pair<String?, String?>

        SubscriptionUiState(
            connectionState = conn,
            offers = offers,
            entitlement = ent,
            billingConfig = cfg,
            currentUserEmail = authUser?.email,
            currentUserUid = authUser?.uid,
            workspaceLabel = container.workspaceIdentity.displayLabel,
            isBusy = busy,
            statusMessage = feedback.first ?: gatewayMsg,
            errorMessage = feedback.second,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SubscriptionUiState(
            connectionState = billingGateway.connectionState.value,
            offers = billingGateway.availableOffers.value,
            entitlement = billingGateway.entitlementState.value,
            billingConfig = billingGateway.billingConfiguration.value,
            currentUserEmail = container.authGateway.currentUser()?.email,
            currentUserUid = container.authGateway.currentUser()?.uid,
            workspaceLabel = container.workspaceIdentity.displayLabel,
            isBusy = billingGateway.isBusy.value,
        ),
    )

    fun refresh() {
        viewModelScope.launch {
            localFeedback.value = null to null
            when (val res = billingGateway.refreshProductsAndPurchases()) {
                is BillingActionResult.Success -> localFeedback.value = res.message to null
                is BillingActionResult.Pending -> localFeedback.value = res.message to null
                is BillingActionResult.Failure -> localFeedback.value = null to res.arabicMessage
                is BillingActionResult.Cancelled -> Unit
            }
        }
    }

    fun subscribe(activity: Activity, offer: SubscriptionOfferUiModel) {
        viewModelScope.launch {
            localFeedback.value = null to null
            val uid = container.entitlementManager.currentObfuscatedUid()
            when (val res = billingGateway.launchSubscriptionPurchase(activity, offer, uid)) {
                is BillingActionResult.Success -> localFeedback.value = res.message to null
                is BillingActionResult.Pending -> localFeedback.value = res.message to null
                is BillingActionResult.Cancelled -> localFeedback.value = res.message to null
                is BillingActionResult.Failure -> localFeedback.value = null to res.arabicMessage
            }
        }
    }

    fun restorePurchases() {
        viewModelScope.launch {
            localFeedback.value = null to null
            when (val res = billingGateway.restorePurchases()) {
                is BillingActionResult.Success -> localFeedback.value = res.message to null
                is BillingActionResult.Pending -> localFeedback.value = res.message to null
                is BillingActionResult.Failure -> localFeedback.value = null to res.arabicMessage
                is BillingActionResult.Cancelled -> Unit
            }
        }
    }

    fun openManageSubscriptions(context: Context) {
        billingGateway.openPlaySubscriptionsCenter(context)
    }

    fun consumeStatusMessage() {
        localFeedback.value = null to localFeedback.value.second
        billingGateway.consumeStatusMessage()
    }

    fun clearError() {
        localFeedback.value = localFeedback.value.first to null
    }
}
