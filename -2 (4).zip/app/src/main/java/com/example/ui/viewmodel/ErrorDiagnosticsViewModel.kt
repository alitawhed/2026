package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.di.AppContainer
import com.example.domain.diagnostics.DiagnosticSummaryStats
import com.example.domain.diagnostics.ErrorEventRecord
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.OperationLogRecord
import com.example.domain.diagnostics.OperationOutcome
import com.example.domain.diagnostics.RestoreDiagnosticsReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ErrorStatusFilter(val arabicLabel: String) {
    ALL("الكل"),
    NEW_UNREVIEWED("جديدة"),
    RECURRING("متكررة"),
    CRASHES("انهيارات"),
    HANDLED("تمت معالجتها"),
    REVIEWED("تمت مراجعتها"),
}

enum class DiagnosticsTab(val arabicLabel: String) {
    ERRORS("سجل الأخطاء"),
    OPERATIONS("سجل العمليات"),
}

class ErrorDiagnosticsViewModel(private val container: AppContainer) : ViewModel() {

    private val monitor = container.globalErrorMonitor

    val stats: StateFlow<DiagnosticSummaryStats> = monitor.stats
    val allErrors: StateFlow<List<ErrorEventRecord>> = monitor.errors
    val allOperations: StateFlow<List<OperationLogRecord>> = container.operationLogger.operations
    val lastRestoreDiagnostics: StateFlow<RestoreDiagnosticsReport?> = monitor.lastRestoreDiagnostics

    private val _selectedTab = MutableStateFlow(DiagnosticsTab.ERRORS)
    val selectedTab: StateFlow<DiagnosticsTab> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _severityFilter = MutableStateFlow<LogSeverity?>(null)
    val severityFilter: StateFlow<LogSeverity?> = _severityFilter.asStateFlow()

    private val _statusFilter = MutableStateFlow(ErrorStatusFilter.ALL)
    val statusFilter: StateFlow<ErrorStatusFilter> = _statusFilter.asStateFlow()

    private val _moduleFilter = MutableStateFlow<String?>(null)
    val moduleFilter: StateFlow<String?> = _moduleFilter.asStateFlow()

    private val _fingerprintFilter = MutableStateFlow<String?>(null)
    val fingerprintFilter: StateFlow<String?> = _fingerprintFilter.asStateFlow()

    private val _operationIdFilter = MutableStateFlow<String?>(null)
    val operationIdFilter: StateFlow<String?> = _operationIdFilter.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val availableModules: StateFlow<List<String>> = combine(allErrors, allOperations) { errs, ops ->
        (errs.map { it.moduleName } + ops.map { it.moduleName })
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredErrors: StateFlow<List<ErrorEventRecord>> = combine(
        allErrors,
        _searchQuery,
        _severityFilter,
        _statusFilter,
        _moduleFilter,
        _fingerprintFilter,
        _operationIdFilter,
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val list = arr[0] as List<ErrorEventRecord>
        val query = (arr[1] as String).trim()
        val severity = arr[2] as LogSeverity?
        val status = arr[3] as ErrorStatusFilter
        val module = arr[4] as String?
        val fp = arr[5] as String?
        val opIdFilter = arr[6] as String?

        list.filter { err ->
            val matchFp = fp == null || err.fingerprint == fp
            val matchOp = opIdFilter == null || err.linkedOperationId == opIdFilter
            val matchSeverity = severity == null || err.severity == severity
            val matchModule = module == null || err.moduleName == module
            val matchStatus = when (status) {
                ErrorStatusFilter.ALL -> true
                ErrorStatusFilter.NEW_UNREVIEWED -> !err.isReviewed
                ErrorStatusFilter.RECURRING -> err.occurrenceCount > 1
                ErrorStatusFilter.CRASHES -> err.isCrash || !err.wasHandled
                ErrorStatusFilter.HANDLED -> err.wasHandled
                ErrorStatusFilter.REVIEWED -> err.isReviewed
            }
            val matchQuery = query.isBlank() ||
                err.errorId.contains(query, ignoreCase = true) ||
                err.errorType.contains(query, ignoreCase = true) ||
                err.originalMessage.contains(query, ignoreCase = true) ||
                err.screenName.contains(query, ignoreCase = true) ||
                err.moduleName.contains(query, ignoreCase = true) ||
                err.operationName.contains(query, ignoreCase = true) ||
                err.linkedOperationId.contains(query, ignoreCase = true) ||
                err.failedStage.contains(query, ignoreCase = true) ||
                err.deviceSummary.contains(query, ignoreCase = true) ||
                err.appVersionSummary.contains(query, ignoreCase = true) ||
                err.sourceFile.contains(query, ignoreCase = true) ||
                err.functionName.contains(query, ignoreCase = true)
            matchFp && matchOp && matchSeverity && matchModule && matchStatus && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredOperations: StateFlow<List<OperationLogRecord>> = combine(
        allOperations,
        _searchQuery,
        _moduleFilter,
    ) { ops, query, module ->
        val q = query.trim()
        ops.filter { op ->
            val matchMod = module == null || op.moduleName == module
            val matchQ = q.isBlank() ||
                op.operationId.contains(q, ignoreCase = true) ||
                op.operationName.contains(q, ignoreCase = true) ||
                op.screenName.contains(q, ignoreCase = true) ||
                op.moduleName.contains(q, ignoreCase = true) ||
                op.currentStage.contains(q, ignoreCase = true) ||
                op.lastSuccessfulStage.contains(q, ignoreCase = true) ||
                op.failureReason.contains(q, ignoreCase = true) ||
                op.linkedErrorId.contains(q, ignoreCase = true)
            matchMod && matchQ
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: DiagnosticsTab) { _selectedTab.value = tab }
    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setSeverityFilter(sev: LogSeverity?) { _severityFilter.value = sev }
    fun setStatusFilter(status: ErrorStatusFilter) { _statusFilter.value = status }
    fun setModuleFilter(module: String?) { _moduleFilter.value = module }
    fun filterByFingerprint(fingerprint: String?) {
        _fingerprintFilter.value = fingerprint
        _selectedTab.value = DiagnosticsTab.ERRORS
    }
    fun filterByOperationId(operationId: String?) {
        _operationIdFilter.value = operationId?.takeIf { it.isNotBlank() }
        if (_operationIdFilter.value != null) {
            _selectedTab.value = DiagnosticsTab.ERRORS
        }
    }
    fun clearMessage() { _message.value = null }

    fun markReviewed(errorId: String, reviewed: Boolean = true) {
        monitor.markErrorReviewed(errorId, reviewed)
        _message.value = if (reviewed) "تم تعليم الخطأ كمراجَع" else "تمت إعادة فتح حالة الخطأ"
    }

    fun markAllReviewed() {
        monitor.markAllReviewed()
        _message.value = "تم تعليم جميع الأخطاء كمراجَعة"
    }

    fun clearAllLogs() {
        monitor.clearAllDiagnostics()
        _fingerprintFilter.value = null
        _operationIdFilter.value = null
        _message.value = "تم مسح سجلات التشخيص"
    }

    fun formatSingleError(error: ErrorEventRecord): String =
        container.diagnosticExportEngine.formatSingleErrorText(error)

    fun exportSingleError(error: ErrorEventRecord, onReady: (File) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = withContext(Dispatchers.IO) {
                container.diagnosticExportEngine.exportSingleErrorFile(error)
            }
            _isBusy.value = false
            res.onSuccess { file ->
                _message.value = "تم تصدير تفاصيل الخطأ (${file.name})"
                onReady(file)
            }.onFailure { err ->
                _message.value = "تعذر تصدير الخطأ: ${err.message}"
            }
        }
    }

    fun exportDiagnosticZip(onReady: (File) -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            val appName = withContext(Dispatchers.IO) {
                runCatching { container.settingsRepository.getSettingsOnce().appName }
                    .getOrDefault("مدير التقارير")
            }
            val res = withContext(Dispatchers.IO) {
                container.diagnosticExportEngine.exportDiagnosticBundleZip(appName)
            }
            _isBusy.value = false
            res.onSuccess { file ->
                _message.value = "تم إنشاء حزمة التشخيص المعقمة (${file.name})"
                onReady(file)
            }.onFailure { err ->
                _message.value = "تعذر تصدير حزمة التشخيص: ${err.message}"
            }
        }
    }
}
