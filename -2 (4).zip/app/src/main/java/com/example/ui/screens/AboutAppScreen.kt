package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Copyright
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.DeveloperIdentity
import com.example.ui.components.AppScreenTopBar
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandNavy
import kotlinx.coroutines.launch

private data class AboutFeatureSpec(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color,
)

private data class PendingDialTarget(
    val isPrimary: Boolean,
    val phoneNumber: String,
    val titleLabel: String,
)

private val WhatsAppPrimaryGreen = Color(0xFF25D366)
private val WhatsAppSecondaryTeal = Color(0xFF128C7E)
private val LauncherBadgeNavy = Color(0xFF141D2E)

@Composable
fun AboutAppScreen(
    onBack: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit = {},
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val versionInfo = remember(context) { DeveloperIdentity.resolveAppVersionInfo(context) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var pendingDial by remember { mutableStateOf<PendingDialTarget?>(null) }
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.45f

    val verifiedFeatures = remember {
        listOf(
            AboutFeatureSpec(
                title = "إدارة المنتجات",
                description = "إضافة المنتجات وتعديل بياناتها وأسعارها ووحداتها وتصنيفاتها وتنظيمها بسهولة.",
                icon = Icons.Default.Inventory2,
                accentColor = Color(0xFF0D9488),
            ),
            AboutFeatureSpec(
                title = "إدارة الصور",
                description = "إرفاق صور المنتجات، تعديلها غير تدميرياً، وضغطها وتخزينها محلياً بشكل منظم.",
                icon = Icons.Default.PhotoLibrary,
                accentColor = Color(0xFF7C3AED),
            ),
            AboutFeatureSpec(
                title = "مسح الباركود",
                description = "البحث عن المنتجات وجردها بسرعة باستخدام كاميرا الهاتف أو قارئ الباركود.",
                icon = Icons.Default.QrCodeScanner,
                accentColor = Color(0xFFD97706),
            ),
            AboutFeatureSpec(
                title = "أنواع الباركود",
                description = "دعم توليد وقراءة باركودات متعددة واختيار النوع الافتراضي مثل Code 128 أو EAN-13.",
                icon = Icons.Default.QrCode2,
                accentColor = Color(0xFF0284C7),
            ),
            AboutFeatureSpec(
                title = "إدارة الجرد",
                description = "تنظيم جلسات الجرد الفعلي وتسجيل الكميات والوحدات ومراجعة الفروقات فوراً.",
                icon = Icons.AutoMirrored.Filled.FactCheck,
                accentColor = Color(0xFF15803D),
            ),
            AboutFeatureSpec(
                title = "التقارير الاحترافية",
                description = "إعداد تقارير مخصصة للمنتجات والجرد مع ترويسة وتذييل ومعاينة مطابقة للورق.",
                icon = Icons.Default.Description,
                accentColor = Color(0xFF0F172A),
            ),
            AboutFeatureSpec(
                title = "تصدير PDF",
                description = "إخراج التقارير والجرد وملصقات الباركود بملفات PDF عالية الجودة وجاهزة للمشاركة.",
                icon = Icons.Default.PictureAsPdf,
                accentColor = Color(0xFFDC2626),
            ),
            AboutFeatureSpec(
                title = "تصدير Excel",
                description = "تصدير واستيراد جداول المنتجات وكشوف الجرد والتقارير بصيغ Excel وCSV.",
                icon = Icons.Default.TableView,
                accentColor = Color(0xFF16A34A),
            ),
            AboutFeatureSpec(
                title = "الطباعة",
                description = "طباعة التقارير وكشوف الجرد وملصقات الباركود مباشرة بمقاسات ورق متعددة.",
                icon = Icons.Default.Print,
                accentColor = Color(0xFF2563EB),
            ),
            AboutFeatureSpec(
                title = "التحكم بالأعمدة",
                description = "إظهار وإخفاء الأعمدة، تعديل ترتيبها وعرضها، وضبط المنازل العشرية لكل عمود.",
                icon = Icons.Default.ViewColumn,
                accentColor = Color(0xFF9333EA),
            ),
            AboutFeatureSpec(
                title = "النسخ الاحتياطي",
                description = "حفظ نسخة احتياطية مضغوطة بصيغة ZIP تشمل قاعدة البيانات والصور والملفات.",
                icon = Icons.Default.Backup,
                accentColor = Color(0xFF0369A1),
            ),
            AboutFeatureSpec(
                title = "استعادة البيانات",
                description = "استرجاع البيانات والصور والتقارير بأمان من النسخ الاحتياطية المحفوظة.",
                icon = Icons.Default.SettingsBackupRestore,
                accentColor = Color(0xFF0F766E),
            ),
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing.only(
                WindowInsetsSides.Top + WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal,
            ),
            topBar = {
                AppScreenTopBar(
                    title = "حول التطبيق",
                    subtitle = DeveloperIdentity.APP_NAME,
                    onBack = onBack,
                )
            },
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter,
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 760.dp)
                        .testTag("about_app_list"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    // 1 & 2 & 3. App Identity, Logo, Tagline & Actual Installed Version
                    item {
                        AboutIdentityHeroCard(
                            versionName = versionInfo.versionName,
                            versionCode = versionInfo.versionCode,
                            isDark = isDark,
                        )
                    }

                    // 4. App Description
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("about_description_card"),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                SectionHeaderRow(
                                    title = "نبذة عن التطبيق",
                                    icon = Icons.Default.Description,
                                    accent = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    text = DeveloperIdentity.ABOUT_DESCRIPTION,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }

                    // 5. Verified App Features
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("about_features_section"),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            SectionHeaderRow(
                                title = "مميزات التطبيق",
                                icon = Icons.Default.Verified,
                                accent = MaterialTheme.colorScheme.primary,
                            )
                            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                                val twoColumns = maxWidth >= 560.dp
                                if (twoColumns) {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        verifiedFeatures.chunked(2).forEach { pair ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            ) {
                                                pair.forEach { feature ->
                                                    AboutFeatureCard(
                                                        feature = feature,
                                                        modifier = Modifier.weight(1f),
                                                    )
                                                }
                                                if (pair.size == 1) {
                                                    Spacer(Modifier.weight(1f))
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        verifiedFeatures.forEach { feature ->
                                            AboutFeatureCard(
                                                feature = feature,
                                                modifier = Modifier.fillMaxWidth(),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 6 & 7. Immutable Developer Info + Direct Communication Buttons
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("about_developer_card"),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                SectionHeaderRow(
                                    title = "معلومات المطور",
                                    icon = Icons.Default.Engineering,
                                    accent = MaterialTheme.colorScheme.primary,
                                )

                                ReadOnlyDeveloperField(
                                    label = "اسم المطور",
                                    value = DeveloperIdentity.DEVELOPER_NAME,
                                    icon = Icons.Default.Engineering,
                                    forceLtr = false,
                                )
                                ReadOnlyDeveloperField(
                                    label = "البريد الإلكتروني",
                                    value = DeveloperIdentity.DEVELOPER_EMAIL,
                                    icon = Icons.Default.Email,
                                    forceLtr = true,
                                )
                                ReadOnlyDeveloperField(
                                    label = "رقم الجوال الأساسي",
                                    value = DeveloperIdentity.PRIMARY_PHONE_DISPLAY,
                                    icon = Icons.Default.Phone,
                                    forceLtr = true,
                                )
                                ReadOnlyDeveloperField(
                                    label = "رقم التواصل الثانوي",
                                    value = DeveloperIdentity.SECONDARY_PHONE_DISPLAY,
                                    icon = Icons.Default.Call,
                                    forceLtr = true,
                                )

                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = DeveloperIdentity.SIGNATURE_LINE,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Text(
                                    text = "وسائل التواصل المباشر",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )

                                // Primary WhatsApp Button
                                Button(
                                    onClick = {
                                        val ok = DeveloperIdentity.launchWhatsApp(context, isPrimary = true)
                                        if (!ok) {
                                            scope.launch {
                                                snackbarHostState.showSnackbar("تعذر فتح تطبيق واتساب أو المتصفح على هذا الجهاز")
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = WhatsAppPrimaryGreen,
                                        contentColor = Color.White,
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 52.dp)
                                        .testTag("about_whatsapp_primary_btn"),
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_whatsapp),
                                        contentDescription = "أيقونة واتساب",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp),
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(horizontalAlignment = Alignment.Start) {
                                        Text(
                                            text = "تواصل عبر واتساب",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                        )
                                        Text(
                                            text = DeveloperIdentity.PRIMARY_PHONE_DISPLAY,
                                            style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                                            color = Color.White.copy(alpha = 0.92f),
                                        )
                                    }
                                }

                                // Secondary WhatsApp Button
                                Button(
                                    onClick = {
                                        val ok = DeveloperIdentity.launchWhatsApp(context, isPrimary = false)
                                        if (!ok) {
                                            scope.launch {
                                                snackbarHostState.showSnackbar("تعذر فتح تطبيق واتساب أو المتصفح على هذا الجهاز")
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = WhatsAppSecondaryTeal,
                                        contentColor = Color.White,
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 52.dp)
                                        .testTag("about_whatsapp_secondary_btn"),
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_whatsapp),
                                        contentDescription = "أيقونة واتساب",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp),
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(horizontalAlignment = Alignment.Start) {
                                        Text(
                                            text = "واتساب – الرقم الثانوي",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                        )
                                        Text(
                                            text = DeveloperIdentity.SECONDARY_PHONE_DISPLAY,
                                            style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                                            color = Color.White.copy(alpha = 0.92f),
                                        )
                                    }
                                }

                                // Email Button
                                OutlinedButton(
                                    onClick = {
                                        val ok = DeveloperIdentity.launchEmail(context)
                                        if (!ok) {
                                            scope.launch {
                                                snackbarHostState.showSnackbar("لا يوجد تطبيق بريد إلكتروني متاح؛ يمكنك المراسلة عبر ${DeveloperIdentity.DEVELOPER_EMAIL}")
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 52.dp)
                                        .testTag("about_email_btn"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Email,
                                        contentDescription = "إرسال بريد إلكتروني",
                                        modifier = Modifier.size(20.dp),
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(horizontalAlignment = Alignment.Start) {
                                        Text(
                                            text = "إرسال بريد إلكتروني",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                        )
                                        Text(
                                            text = DeveloperIdentity.DEVELOPER_EMAIL,
                                            style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }

                                // Two Separate Dialer Buttons (Confirmation dialog before ACTION_DIAL)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            pendingDial = PendingDialTarget(
                                                isPrimary = true,
                                                phoneNumber = DeveloperIdentity.PRIMARY_PHONE_DISPLAY,
                                                titleLabel = "الاتصال بالرقم الأساسي",
                                            )
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 56.dp)
                                            .testTag("about_call_primary_btn"),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = "الاتصال بالرقم الأساسي",
                                            modifier = Modifier.size(18.dp),
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Column(horizontalAlignment = Alignment.Start) {
                                            Text(
                                                text = "الاتصال بالرقم الأساسي",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text(
                                                text = DeveloperIdentity.PRIMARY_PHONE_DISPLAY,
                                                style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            pendingDial = PendingDialTarget(
                                                isPrimary = false,
                                                phoneNumber = DeveloperIdentity.SECONDARY_PHONE_DISPLAY,
                                                titleLabel = "الاتصال بالرقم الثانوي",
                                            )
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 56.dp)
                                            .testTag("about_call_secondary_btn"),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Phone,
                                            contentDescription = "الاتصال بالرقم الثانوي",
                                            modifier = Modifier.size(18.dp),
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Column(horizontalAlignment = Alignment.Start) {
                                            Text(
                                                text = "الاتصال بالرقم الثانوي",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text(
                                                text = DeveloperIdentity.SECONDARY_PHONE_DISPLAY,
                                                style = MaterialTheme.typography.labelSmall.copy(textDirection = TextDirection.Ltr),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        OutlinedButton(
                            onClick = onOpenPrivacyPolicy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("about_privacy_btn"),
                        ) {
                            Icon(Icons.Default.PrivacyTip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("سياسة الخصوصية وحذف الحساب")
                        }
                    }

                    // 8. Intellectual Property & Copyright Footer (Exclusively on About App Screen)
                    item {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("about_copyright_footer"),
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Copyright,
                                        contentDescription = "حقوق الملكية الفكرية",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Text(
                                        text = DeveloperIdentity.COPYRIGHT_LINE,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center,
                                    )
                                }
                                Text(
                                    text = DeveloperIdentity.SIGNATURE_LINE,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                )
                            }
                        }
                    }
                }
            }
        }

        // Confirmation dialog before opening Android system dialer (ACTION_DIAL)
        pendingDial?.let { target ->
            AlertDialog(
                onDismissRequest = { pendingDial = null },
                modifier = Modifier.testTag("dial_confirm_dialog"),
                icon = {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                },
                title = {
                    Text(
                        text = target.titleLabel,
                        fontWeight = FontWeight.Bold,
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "سيتم فتح تطبيق الاتصال بالرقم التالي لتأكيد المكالمة يدوياً من جهازك:",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text(
                            text = target.phoneNumber,
                            style = MaterialTheme.typography.titleMedium.copy(textDirection = TextDirection.Ltr),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val selected = target
                            pendingDial = null
                            val launched = DeveloperIdentity.launchDialer(context, isPrimary = selected.isPrimary)
                            if (!launched) {
                                scope.launch {
                                    snackbarHostState.showSnackbar("تعذر فتح تطبيق الاتصال على هذا الجهاز")
                                }
                            }
                        },
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("dial_confirm_btn"),
                    ) {
                        Text("فتح شاشة الاتصال")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { pendingDial = null },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) {
                        Text("إلغاء")
                    }
                },
            )
        }
    }
}

@Composable
private fun AboutIdentityHeroCard(
    versionName: String,
    versionCode: Long,
    isDark: Boolean,
) {
    val heroColors = if (isDark) {
        listOf(Color(0xFF0B1322), Color(0xFF13263E), Color(0xFF0A4F48))
    } else {
        listOf(BrandNavy, Color(0xFF1C3557), BrandEmerald)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("about_hero_card")
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(colors = heroColors))
            .padding(22.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Current App Launcher Emblem Preserved Intact
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = LauncherBadgeNavy,
                border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.28f)),
                shadowElevation = 6.dp,
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_app_foreground_1795213452670),
                    contentDescription = "شعار تطبيق مدير التقارير",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(84.dp)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(16.dp)),
                )
            }

            Text(
                text = DeveloperIdentity.APP_NAME,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("about_app_name"),
            )

            Text(
                text = DeveloperIdentity.APP_TAGLINE,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
            )

            Surface(
                shape = RoundedCornerShape(50),
                color = Color.White.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                modifier = Modifier.testTag("about_version_badge"),
            ) {
                Text(
                    text = "الإصدار $versionName ($versionCode)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun SectionHeaderRow(
    title: String,
    icon: ImageVector,
    accent: Color,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(accent.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(19.dp),
            )
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun AboutFeatureCard(
    feature: AboutFeatureSpec,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(feature.accentColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = feature.icon,
                    contentDescription = feature.title,
                    tint = feature.accentColor,
                    modifier = Modifier.size(21.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = feature.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ReadOnlyDeveloperField(
    label: String,
    value: String,
    icon: ImageVector,
    forceLtr: Boolean,
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.48f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = value,
                    style = if (forceLtr) {
                        MaterialTheme.typography.titleSmall.copy(textDirection = TextDirection.Ltr)
                    } else {
                        MaterialTheme.typography.titleSmall
                    },
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}
