package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ReportWithDetails
import com.example.di.AppContainer
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ReportsArchiveUiState(
    val reports: List<ReportWithDetails> = emptyList(),
    val searchQuery: String = "",
    val onlyArchived: Boolean = false,
)

class ArchiveViewModel(private val container: AppContainer) : ViewModel() {
    private val _searchQuery = MutableStateFlow("")
    private val _onlyArchived = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val uiState: StateFlow<ReportsArchiveUiState> = combine(
        container.reportRepository.allReports,
        _searchQuery,
        _onlyArchived,
    ) { all, query, onlyArch ->
        val q = query.trim()
        val filtered = all.filter { r ->
            val matchArch = !onlyArch || r.report.isArchived
            val matchQ = if (q.isEmpty()) true else {
                r.report.reportNumber.contains(q, ignoreCase = true) ||
                    r.report.title.contains(q, ignoreCase = true) ||
                    r.report.clientName.contains(q, ignoreCase = true)
            }
            matchArch && matchQ
        }
        ReportsArchiveUiState(filtered, q, onlyArch)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReportsArchiveUiState())

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setOnlyArchived(arch: Boolean) { _onlyArchived.value = arch }
    fun clearMessage() { _message.value = null }

    fun createEmptyReport(templateId: Long? = null, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = container.reportRepository.createEmptyReport(templateId)
            onCreated(id)
        }
    }

    fun cloneReport(sourceId: Long, asNewDraft: Boolean, onCloned: (Long) -> Unit) {
        viewModelScope.launch {
            val id = container.reportRepository.cloneReport(sourceId, asNewDraft)
            _message.value = if (asNewDraft) "تم إنشاء تقرير جديد انطلاقاً من التقرير السابق" else "تم نسخ التقرير"
            onCloned(id)
        }
    }

    fun saveAsNewVersion(sourceId: Long, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = container.reportRepository.saveAsNewReportVersion(sourceId)
            _message.value = "تم إنشاء إصدار جديد مرتبط بالتقرير"
            onCreated(id)
        }
    }

    fun deleteReport(reportId: Long) {
        viewModelScope.launch {
            container.reportRepository.deleteReport(reportId)
            _message.value = "تم حذف التقرير"
        }
    }

    private val _isGeneratingPdf = MutableStateFlow(false)
    val isGeneratingPdf: StateFlow<Boolean> = _isGeneratingPdf.asStateFlow()

    fun generatePdf(reportDetails: ReportWithDetails, onReady: (File) -> Unit) {
        if (_isGeneratingPdf.value) return
        viewModelScope.launch {
            _isGeneratingPdf.value = true
            try {
                val settings = container.settingsRepository.getSettingsOnce()
                val result = withContext(Dispatchers.IO) {
                    container.pdfGeneratorEngine.generateReportPdf(reportDetails, settings)
                }
                onReady(result.file)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Exception) {
                container.globalErrorMonitor.recordError(e, ScreenNames.ARCHIVE, DiagnosticModules.PDF, "إنشاء ملف PDF من الأرشيف")
                _message.value = "تعذر إنشاء ملف PDF: ${e.localizedMessage ?: "خطأ"}"
            } finally {
                _isGeneratingPdf.value = false
            }
        }
    }

    fun postMessage(msg: String) {
        _message.value = msg
    }
}
