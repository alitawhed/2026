package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.domain.barcode.BarcodeEngine
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.FilterChip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.AddCircleOutline
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.BarcodeUnitType
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.CachedBarcodeImage
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.components.formatArabicDateTime
import com.example.ui.components.formatCurrencyValue
import com.example.ui.viewmodel.ProductsViewModel
import java.io.File

data class BarcodeDraftInput(
    val value: String,
    val format: BarcodeFormatType,
    val label: String,
    val description: String,
    val unitType: String,
    val conversionFactor: Double,
    val makePrimary: Boolean,
    val continueScanningAnother: Boolean = false,
)

@Composable
fun ProductDetailScreen(
    productId: Long,
    viewModel: ProductsViewModel,
    scannedBarcodeResult: Pair<String, String>? = null,
    onConsumeScannedBarcode: () -> Unit = {},
    onLaunchBarcodeCamera: () -> Unit = {},
    onBack: () -> Unit,
    onEditProduct: (Long) -> Unit,
    onJumpToProduct: (Long) -> Unit,
    onOpenImageEditor: (Long) -> Unit = {},
) {
    val productFlow = remember(productId) { viewModel.observeProduct(productId) }
    val productDetails by productFlow.collectAsStateWithLifecycle(initialValue = null)
    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val conflict by viewModel.duplicateConflict.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var imageRefreshTick by remember { mutableIntStateOf(0) }
    var previewStartIndex by remember { mutableStateOf<Int?>(null) }
    var cropTargetImage by remember { mutableStateOf<ProductImageEntity?>(null) }
    var replaceTargetImageId by remember { mutableStateOf<Long?>(null) }
    var showAddBarcodeDialog by remember { mutableStateOf(false) }
    var prefillScannedCode by remember { mutableStateOf("") }
    var prefillScannedFormat by remember { mutableStateOf<BarcodeFormatType?>(null) }
    var editingBarcode by remember { mutableStateOf<ProductBarcodeEntity?>(null) }
    var formatChangeBarcode by remember { mutableStateOf<ProductBarcodeEntity?>(null) }
    var deleteBarcodeTarget by remember { mutableStateOf<ProductBarcodeEntity?>(null) }
    var showDeleteProductConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(scannedBarcodeResult) {
        scannedBarcodeResult?.let { (code, fmtStr) ->
            val fmt = BarcodeFormatType.fromString(fmtStr)
            prefillScannedCode = code
            prefillScannedFormat = fmt
            showAddBarcodeDialog = true
            onConsumeScannedBarcode()
        }
    }

    // Zero-permission Photo Picker (Multi-select + Replace) & File Picker & Camera TakePicture
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.addImagesFromUris(productId, uris) {
                imageRefreshTick++
            }
        }
    }
    val replacePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val targetId = replaceTargetImageId
        replaceTargetImageId = null
        if (uri != null && targetId != null) {
            viewModel.replaceImageFromUri(targetId, uri) {
                imageRefreshTick++
            }
        }
    }
    val fileImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.addImagesFromUris(productId, uris) {
                imageRefreshTick++
            }
        }
    }
    var pendingCameraUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingCameraUri?.let {
            viewModel.addImageFromUri(productId, it) {
                imageRefreshTick++
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = productDetails?.product?.name ?: "تفاصيل المنتج",
                subtitle = productDetails?.product?.internalCode?.let { "ID: $it" },
                onBack = onBack,
                actions = {
                    if (productDetails != null) {
                        IconButton(onClick = { onEditProduct(productId) }, modifier = Modifier.testTag("detail_edit_btn")) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل المنتج")
                        }
                        IconButton(onClick = {
                            viewModel.duplicateProduct(productId) { newId -> onJumpToProduct(newId) }
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ المنتج")
                        }
                        IconButton(onClick = { showDeleteProductConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف المنتج", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        val details = productDetails
        val productsNumCfg by viewModel.productsNumericConfig.collectAsStateWithLifecycle()
        if (details == null) {
            Box(Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                Text("جارٍ تحميل بيانات المنتج...")
            }
            return@Scaffold
        }

        val orderedImages = details.images.sortedBy { it.sortOrder }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Product Images Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("صور المنتج (${orderedImages.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(onClick = {
                                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }) {
                                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = "من المعرض")
                                }
                                IconButton(onClick = {
                                    val tempFile = File(context.cacheDir, "cam_${System.currentTimeMillis()}.jpg")
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tempFile)
                                    pendingCameraUri = uri
                                    cameraLauncher.launch(uri)
                                }) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = "التقاط بالكاميرا")
                                }
                                IconButton(onClick = { fileImagePicker.launch(arrayOf("image/*")) }) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = "من الملفات")
                                }
                            }
                        }

                        if (orderedImages.isEmpty()) {
                            Text(
                                text = "لا توجد صور مضافة لهذا المنتج — يتم حفظ الصور دائماً داخل مساحة التطبيق",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                itemsIndexed(orderedImages, key = { _, img -> img.id }) { idx, img ->
                                    Card(
                                        border = BorderStroke(
                                            if (img.isPrimary) 2.dp else 1.dp,
                                            if (img.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                        ),
                                    ) {
                                        Column(modifier = Modifier.width(172.dp)) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(124.dp),
                                            ) {
                                                ProductEntityImageBox(
                                                    image = img,
                                                    contentDescription = details.product.name,
                                                    preferThumbnail = false,
                                                    refreshTag = imageRefreshTick,
                                                    shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp),
                                                    contentScale = ContentScale.Crop,
                                                    showDiagnosticsOnError = true,
                                                    onClick = { previewStartIndex = idx },
                                                    modifier = Modifier.fillMaxSize().testTag("detail_image_box_${img.id}"),
                                                )
                                                if (img.isPrimary) {
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.primary,
                                                        shape = RoundedCornerShape(bottomEnd = 8.dp),
                                                    ) {
                                                        Text(
                                                            "رئيسية",
                                                            color = MaterialTheme.colorScheme.onPrimary,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                }
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                            ) {
                                                IconButton(
                                                    onClick = { viewModel.setPrimaryImage(productId, img.id) },
                                                    modifier = Modifier.size(32.dp),
                                                ) {
                                                    Icon(
                                                        if (img.isPrimary) Icons.Default.Star else Icons.Default.StarBorder,
                                                        contentDescription = "تعيين رئيسية",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp),
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { onOpenImageEditor(img.id) },
                                                    modifier = Modifier.size(32.dp),
                                                ) {
                                                    Icon(Icons.Default.Tune, contentDescription = "تحرير احترافي", modifier = Modifier.size(18.dp))
                                                }
                                                IconButton(
                                                    onClick = {
                                                        replaceTargetImageId = img.id
                                                        replacePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                                    },
                                                    modifier = Modifier.size(32.dp),
                                                ) {
                                                    Icon(Icons.Default.SwapHoriz, contentDescription = "استبدال الصورة", modifier = Modifier.size(18.dp))
                                                }
                                                IconButton(
                                                    onClick = {
                                                        viewModel.rotateImageById(img.id) { imageRefreshTick++ }
                                                    },
                                                    modifier = Modifier.size(32.dp),
                                                ) {
                                                    Icon(Icons.Default.RotateRight, contentDescription = "تدوير", modifier = Modifier.size(18.dp))
                                                }
                                                IconButton(
                                                    onClick = { viewModel.deleteImage(productId, img) },
                                                    modifier = Modifier.size(32.dp),
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "حذف الصورة", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                            if (orderedImages.size > 1) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                                                    horizontalArrangement = Arrangement.Center,
                                                ) {
                                                    IconButton(
                                                        enabled = idx > 0,
                                                        onClick = {
                                                            val mutable = orderedImages.toMutableList()
                                                            val item = mutable.removeAt(idx)
                                                            mutable.add(idx - 1, item)
                                                            viewModel.reorderImages(productId, mutable)
                                                        },
                                                        modifier = Modifier.size(28.dp),
                                                    ) {
                                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "تقديم")
                                                    }
                                                    IconButton(
                                                        enabled = idx < orderedImages.lastIndex,
                                                        onClick = {
                                                            val mutable = orderedImages.toMutableList()
                                                            val item = mutable.removeAt(idx)
                                                            mutable.add(idx + 1, item)
                                                            viewModel.reorderImages(productId, mutable)
                                                        },
                                                        modifier = Modifier.size(28.dp),
                                                    ) {
                                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "تأخير")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Product Metadata Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("البيانات التجارية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        InfoLine(
                            "السعر الأساسي",
                            formatCurrencyValue(details.product.basePrice, details.product.currency, productsNumCfg.priceFormat),
                        )
                        InfoLine("التصنيف", details.product.categoryName.ifBlank { "غير محدد" })
                        InfoLine("بلد المنشأ", details.product.originCountry.ifBlank { "غير محدد" })
                        InfoLine("المصنع", details.product.manufacturer.ifBlank { "غير محدد" })
                        InfoLine(
                            "الكمية الافتراضية",
                            NumberFormatEngine.formatDouble(details.product.defaultQuantity, productsNumCfg.quantityFormat),
                        )
                        if (details.product.description.isNotBlank()) InfoLine("الوصف", details.product.description)
                        if (details.product.notes.isNotBlank()) InfoLine("ملاحظات", details.product.notes)
                        InfoLine("تاريخ الإضافة", formatArabicDateTime(details.product.createdAt))
                        InfoLine("آخر تعديل", formatArabicDateTime(details.product.updatedAt))
                    }
                }
            }

            // Unlimited Multi-Barcodes Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "الباركودات المرتبطة (${details.barcodes.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = { onLaunchBarcodeCamera() },
                                    modifier = Modifier.testTag("detail_scan_barcode_btn"),
                                ) {
                                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("مسح")
                                }
                                FilledTonalButton(
                                    onClick = {
                                        prefillScannedCode = ""
                                        prefillScannedFormat = null
                                        showAddBarcodeDialog = true
                                    },
                                    modifier = Modifier.testTag("add_barcode_btn"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("يدوياً")
                                }
                            }
                        }

                        if (details.barcodes.isEmpty()) {
                            Text(
                                "لا توجد باركودات مسجلة لهذا المنتج حتى الآن",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.generateAlternativeInternalBarcode(productId) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("detail_generate_alt_internal_barcode_btn"),
                        ) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إنشاء باركود داخلي بديل (${defaultBarcodeType.arabicLabel}) مع حفظ الأصلي")
                        }

                        if (details.barcodes.isNotEmpty()) {
                            details.barcodes.forEach { barcode ->
                                val fmt = BarcodeFormatType.fromString(barcode.barcodeType)
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (barcode.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    ),
                                    color = MaterialTheme.colorScheme.background,
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text(barcode.barcodeValue, fontWeight = FontWeight.Bold)
                                                    if (barcode.isPrimary) {
                                                        Surface(
                                                            color = MaterialTheme.colorScheme.primary,
                                                            shape = RoundedCornerShape(6.dp),
                                                        ) {
                                                            Text(
                                                                "رئيسي",
                                                                color = MaterialTheme.colorScheme.onPrimary,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    } else {
                                                        Surface(
                                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                                            shape = RoundedCornerShape(6.dp),
                                                        ) {
                                                            Text(
                                                                "بديل",
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    }
                                                }
                                                val factorLabel = NumberFormatEngine.formatDouble(
                                                    barcode.conversionFactor,
                                                    productsNumCfg.conversionFactorFormat,
                                                )
                                                Text(
                                                    "${fmt.arabicLabel} • الوحدة: ${barcode.unitType} (×$factorLabel)",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                                if (barcode.description.isNotBlank()) {
                                                    Text(
                                                        barcode.description,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary,
                                                    )
                                                }
                                            }
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            OutlinedButton(
                                                onClick = { formatChangeBarcode = barcode },
                                                modifier = Modifier
                                                    .heightIn(min = 48.dp)
                                                    .testTag("detail_change_barcode_format_${barcode.id}"),
                                            ) {
                                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("تغيير النوع")
                                            }
                                            Spacer(Modifier.weight(1f))
                                            Row {
                                                if (!barcode.isPrimary) {
                                                    IconButton(onClick = { viewModel.setPrimaryBarcode(productId, barcode.id) }) {
                                                        Icon(Icons.Default.StarBorder, contentDescription = "تعيين رئيسي")
                                                    }
                                                }
                                                IconButton(onClick = { editingBarcode = barcode }) {
                                                    Icon(Icons.Default.Edit, contentDescription = "تعديل الباركود")
                                                }
                                                IconButton(onClick = { deleteBarcodeTarget = barcode }) {
                                                    Icon(Icons.Default.Delete, contentDescription = "حذف الباركود", tint = MaterialTheme.colorScheme.error)
                                                }
                                            }
                                        }
                                        CachedBarcodeImage(
                                            productId = productId,
                                            barcodeValue = barcode.barcodeValue,
                                            format = fmt,
                                            barcodeService = viewModel.barcodeService,
                                            baseWidthPx = 760,
                                            baseHeightPx = if (fmt.is2D) 260 else 210,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(86.dp)
                                                .testTag("detail_barcode_image_${barcode.id}"),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Swipeable Multi-Image Gallery Preview Dialog with Pinch Zoom + Studio Editor shortcut
    previewStartIndex?.let { startIdx ->
        val galleryImages = productDetails?.images?.sortedBy { it.sortOrder }.orEmpty()
        if (galleryImages.isNotEmpty()) {
            val pagerState = rememberPagerState(
                initialPage = startIdx.coerceIn(0, galleryImages.lastIndex),
                pageCount = { galleryImages.size },
            )
            var scale by remember { mutableFloatStateOf(1f) }
            val activeImg = galleryImages.getOrNull(pagerState.currentPage)
            AlertDialog(
                onDismissRequest = { previewStartIndex = null },
                title = { Text("معرض الصور (${pagerState.currentPage + 1} / ${galleryImages.size})") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                        ) { page ->
                            val img = galleryImages[page]
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(page) {
                                        detectTransformGestures { _, _, zoom, _ ->
                                            scale = (scale * zoom).coerceIn(1f, 4f)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                ProductEntityImageBox(
                                    image = img,
                                    contentDescription = "معاينة مكبرة",
                                    preferThumbnail = false,
                                    refreshTag = imageRefreshTick,
                                    contentScale = ContentScale.Fit,
                                    showDiagnosticsOnError = true,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer(scaleX = scale, scaleY = scale),
                                )
                            }
                        }
                        if (galleryImages.size > 1) {
                            Text(
                                "اسحب يميناً أو يساراً للتنقل بين صور المنتج أو بإصبعين للتكبير",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val id = activeImg?.id
                        previewStartIndex = null
                        if (id != null) onOpenImageEditor(id)
                    }) {
                        Icon(Icons.Default.Tune, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تحرير احترافي")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { previewStartIndex = null }) { Text("إغلاق") }
                },
            )
        }
    }

    // Crop Image Dialog
    cropTargetImage?.let { img ->
        var hPad by remember { mutableFloatStateOf(0.1f) }
        var vPad by remember { mutableFloatStateOf(0.1f) }
        AlertDialog(
            onDismissRequest = { cropTargetImage = null },
            title = { Text("قص وتأطير الصورة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("قص أفقي: ${(hPad * 100).toInt()}% من كل جانب")
                    Slider(value = hPad, onValueChange = { hPad = it }, valueRange = 0f..0.35f)
                    Text("قص عمودي: ${(vPad * 100).toInt()}% من كل جانب")
                    Slider(value = vPad, onValueChange = { vPad = it }, valueRange = 0f..0.35f)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.cropImageById(img.id, hPad, vPad, 1f - hPad, 1f - vPad) {
                        imageRefreshTick++
                        cropTargetImage = null
                    }
                }) {
                    Text("تطبيق القص")
                }
            },
            dismissButton = {
                TextButton(onClick = { cropTargetImage = null }) { Text("إلغاء") }
            },
        )
    }

    // Add / Edit Barcode Dialog
    if (showAddBarcodeDialog || editingBarcode != null) {
        BarcodeEditorDialog(
            existing = editingBarcode,
            prefillValue = if (editingBarcode == null) prefillScannedCode else "",
            prefillFormat = if (editingBarcode == null) prefillScannedFormat else null,
            defaultFormat = defaultBarcodeType,
            onScanWithCamera = if (editingBarcode == null) {
                {
                    showAddBarcodeDialog = false
                    onLaunchBarcodeCamera()
                }
            } else null,
            onDismiss = {
                showAddBarcodeDialog = false
                editingBarcode = null
                prefillScannedCode = ""
                prefillScannedFormat = null
            },
            onSave = { draft ->
                val existing = editingBarcode
                if (existing == null) {
                    viewModel.addBarcodeToProduct(
                        productId = productId,
                        value = draft.value,
                        format = draft.format,
                        label = draft.label,
                        makePrimary = draft.makePrimary,
                        description = draft.description,
                        unitType = draft.unitType,
                        conversionFactor = draft.conversionFactor,
                    ) {
                        showAddBarcodeDialog = false
                        prefillScannedCode = ""
                        prefillScannedFormat = null
                        if (draft.continueScanningAnother) {
                            onLaunchBarcodeCamera()
                        }
                    }
                } else {
                    viewModel.updateBarcode(
                        existing.copy(
                            barcodeValue = draft.value,
                            barcodeType = draft.format.name,
                            label = draft.label,
                            description = draft.description,
                            unitType = draft.unitType,
                            conversionFactor = draft.conversionFactor,
                            isPrimary = draft.makePrimary,
                        ),
                    ) {
                        editingBarcode = null
                    }
                }
            },
        )
    }

    // Confirm Barcode Deletion
    deleteBarcodeTarget?.let { b ->
        ConfirmActionDialog(
            title = "حذف الباركود",
            message = "هل أنت متأكد من حذف الباركود (${b.barcodeValue}) من هذا المنتج؟",
            onConfirm = {
                viewModel.deleteBarcode(productId, b.id)
                deleteBarcodeTarget = null
            },
            onDismiss = { deleteBarcodeTarget = null },
        )
    }

    // Duplicate Barcode Conflict Dialog with Direct Jump to Existing Product
    conflict?.let { err ->
        AlertDialog(
            onDismissRequest = { viewModel.clearConflict() },
            title = { Text("تنبيه: باركود مكرر", fontWeight = FontWeight.Bold) },
            text = {
                Text("الباركود (${err.barcodeValue}) مسجل مسبقاً للمنتج: ${err.conflictingProductName}. لا يمكن تكرار نفس الباركود بين منتجات مختلفة.")
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.clearConflict()
                    onJumpToProduct(err.conflictingProductId)
                }) {
                    Text("الانتقال للمنتج الموجود")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.clearConflict() }) { Text("إغلاق") }
            },
        )
    }

    if (showDeleteProductConfirm) {
        ConfirmActionDialog(
            title = "حذف المنتج",
            message = "هل أنت متأكد من حذف هذا المنتج وكافة باركوداته وصوره؟",
            onConfirm = {
                showDeleteProductConfirm = false
                viewModel.deleteProduct(productId, onBack)
            },
            onDismiss = { showDeleteProductConfirm = false },
        )
    }

    formatChangeBarcode?.let { targetBc ->
        BarcodeFormatChangeDialog(
            barcodeValue = targetBc.barcodeValue,
            currentFormat = BarcodeFormatType.fromString(targetBc.barcodeType),
            productName = productDetails?.product?.name,
            availableScopes = listOf(
                BarcodeFormatChangeScope.CURRENT_PRODUCT,
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
            ),
            onDismiss = { formatChangeBarcode = null },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                viewModel.changeProductBarcodeFormat(
                    productId = productId,
                    barcodeId = targetBc.id,
                    targetFormat = targetFormat,
                    scope = scope,
                    alsoUpdateDefault = alsoUpdateDefault,
                ) {
                    formatChangeBarcode = null
                }
            },
            onGenerateAlternativeInternal = {
                viewModel.generateAlternativeInternalBarcode(
                    productId = productId,
                    unitType = targetBc.unitType,
                    conversionFactor = targetBc.conversionFactor,
                )
            },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun BarcodeEditorDialog(
    existing: ProductBarcodeEntity? = null,
    prefillValue: String = "",
    prefillFormat: BarcodeFormatType? = null,
    defaultFormat: BarcodeFormatType = BarcodeFormatType.CODE_128,
    onScanWithCamera: (() -> Unit)? = null,
    onDismiss: () -> Unit,
    onSave: (BarcodeDraftInput) -> Unit,
) {
    var value by remember(existing, prefillValue) {
        mutableStateOf(existing?.barcodeValue ?: prefillValue)
    }
    var format by remember(existing, prefillFormat, defaultFormat) {
        mutableStateOf(
            if (existing != null) BarcodeFormatType.fromString(existing.barcodeType)
            else (prefillFormat ?: defaultFormat),
        )
    }
    var unitType by remember(existing) {
        mutableStateOf(existing?.unitType?.ifBlank { "حبة" } ?: "حبة")
    }
    var conversionFactorText by remember(existing) {
        val factor = existing?.conversionFactor ?: 1.0
        mutableStateOf(if (factor % 1.0 == 0.0) factor.toLong().toString() else factor.toString())
    }
    var description by remember(existing) {
        mutableStateOf(existing?.description ?: existing?.label?.takeIf { it != unitType } ?: "")
    }
    var makePrimary by remember(existing) {
        mutableStateOf(existing?.isPrimary ?: false)
    }
    var formatMenu by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    existing != null -> "تعديل الباركود"
                    prefillValue.isNotBlank() -> "تم التقاط باركود — مراجعة وإضافة"
                    else -> "إضافة باركود جديد"
                },
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = {
                        value = it
                        validationError = null
                    },
                    label = { Text("قيمة الباركود (تحفظ الأصفار اليسارية)") },
                    isError = validationError != null,
                    supportingText = validationError?.let { err -> { Text(err) } },
                    singleLine = true,
                    trailingIcon = if (onScanWithCamera != null) {
                        {
                            IconButton(onClick = onScanWithCamera) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح بالكاميرا")
                            }
                        }
                    } else null,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_barcode_value"),
                )
                Box {
                    OutlinedButton(onClick = { formatMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("النوع: ${format.arabicLabel}")
                    }
                    DropdownMenu(expanded = formatMenu, onDismissRequest = { formatMenu = false }) {
                        BarcodeFormatType.entries.forEach { fmt ->
                            DropdownMenuItem(
                                text = { Text(fmt.arabicLabel) },
                                onClick = {
                                    format = fmt
                                    validationError = null
                                    formatMenu = false
                                },
                            )
                        }
                    }
                }
                Text("الوحدة المرتبطة بهذا الباركود:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    BarcodeUnitType.entries.forEach { unit ->
                        FilterChip(
                            selected = unitType == unit.arabicLabel,
                            onClick = {
                                unitType = unit.arabicLabel
                                if (unit == BarcodeUnitType.PIECE) {
                                    conversionFactorText = "1"
                                }
                            },
                            label = { Text(unit.arabicLabel) },
                        )
                    }
                }
                OutlinedTextField(
                    value = conversionFactorText,
                    onValueChange = { conversionFactorText = it; validationError = null },
                    label = { Text("معامل التحويل للوحدة الأساسية (حبة = 1، كرتون = 12...)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_barcode_factor"),
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("وصف إضافي للباركود (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = makePrimary, onCheckedChange = { makePrimary = it })
                    Text("تعيين كباركود رئيسي للمنتج")
                }
            }
        },
        confirmButton = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (existing == null && onScanWithCamera != null) {
                        FilledTonalButton(
                            onClick = {
                                val res = BarcodeEngine.validate(value, format)
                                val factor = conversionFactorText.replace(",", "").toDoubleOrNull()
                                if (!res.isValid) {
                                    validationError = res.errorMessage ?: "قيمة الباركود غير صالحة"
                                } else if (factor == null || factor <= 0.0) {
                                    validationError = "معامل التحويل يجب أن يكون أكبر من صفر"
                                } else {
                                    onSave(
                                        BarcodeDraftInput(
                                            value = res.normalizedValue,
                                            format = format,
                                            label = unitType,
                                            description = description.trim(),
                                            unitType = unitType,
                                            conversionFactor = factor,
                                            makePrimary = makePrimary,
                                            continueScanningAnother = true,
                                        ),
                                    )
                                }
                            },
                            modifier = Modifier.testTag("dialog_barcode_save_scan_next"),
                        ) {
                            Text("حفظ ومسح آخر")
                        }
                    }
                    Button(
                        onClick = {
                            val res = BarcodeEngine.validate(value, format)
                            val factor = conversionFactorText.replace(",", "").toDoubleOrNull()
                            if (!res.isValid) {
                                validationError = res.errorMessage ?: "قيمة الباركود غير صالحة"
                            } else if (factor == null || factor <= 0.0) {
                                validationError = "معامل التحويل يجب أن يكون أكبر من صفر"
                            } else {
                                onSave(
                                    BarcodeDraftInput(
                                        value = res.normalizedValue,
                                        format = format,
                                        label = unitType,
                                        description = description.trim(),
                                        unitType = unitType,
                                        conversionFactor = factor,
                                        makePrimary = makePrimary,
                                        continueScanningAnother = false,
                                    ),
                                )
                            }
                        },
                        modifier = Modifier.testTag("dialog_barcode_save"),
                    ) {
                        Text("حفظ")
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}
