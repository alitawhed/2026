package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.BackupHistoryEntity
import com.example.di.AppContainer
import com.example.domain.backup.BackupInspectionResult
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class BackupRestoreViewModel(private val container: AppContainer) : ViewModel() {

    val history: StateFlow<List<BackupHistoryEntity>> = container.database.backupDao()
        .observeBackupHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isWorking = MutableStateFlow(false)
    val isWorking: StateFlow<Boolean> = _isWorking.asStateFlow()

    private val _pendingInspection = MutableStateFlow<BackupInspectionResult?>(null)
    val pendingInspection: StateFlow<BackupInspectionResult?> = _pendingInspection.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _restoreError = MutableStateFlow<String?>(null)
    val restoreError: StateFlow<String?> = _restoreError.asStateFlow()

    fun clearMessage() { _message.value = null }
    fun clearRestoreError() { _restoreError.value = null }

    fun clearPendingInspection() {
        container.backupRestoreEngine.cleanupStagedInspection(_pendingInspection.value)
        _pendingInspection.value = null
    }

    fun createBackup(customName: String, onCreated: (File) -> Unit) {
        viewModelScope.launch {
            _isWorking.value = true
            try {
                val res = container.backupRestoreEngine.createBackupZip(customName)
                _isWorking.value = false
                res.onSuccess { file ->
                    _message.value = "تم إنشاء النسخة الاحتياطية بنجاح (${file.name})"
                    onCreated(file)
                }.onFailure { err ->
                    _message.value = "فشل إنشاء النسخة الاحتياطية: ${err.message}"
                }
            } catch (t: Throwable) {
                _isWorking.value = false
                container.globalErrorMonitor.recordError(
                    throwable = t,
                    screenName = ScreenNames.BACKUP_RESTORE,
                    moduleName = DiagnosticModules.BACKUP_RESTORE,
                    operationName = "إنشاء نسخة احتياطية",
                    severity = LogSeverity.ERROR,
                )
                _message.value = "فشل إنشاء النسخة الاحتياطية: ${t.message}"
            }
        }
    }

    fun inspectBackupUri(uri: Uri) {
        viewModelScope.launch {
            _isWorking.value = true
            _restoreError.value = null
            try {
                clearPendingInspection()
                val inspection = container.backupRestoreEngine.inspectBackupUri(uri)
                _isWorking.value = false
                _pendingInspection.value = inspection
            } catch (t: Throwable) {
                _isWorking.value = false
                container.globalErrorMonitor.recordError(
                    throwable = t,
                    screenName = ScreenNames.BACKUP_RESTORE,
                    moduleName = DiagnosticModules.BACKUP_RESTORE,
                    operationName = "فحص ملف النسخة المختار",
                    severity = LogSeverity.ERROR,
                )
                _restoreError.value = "تعذر فحص الملف: ${t.message}"
            }
        }
    }

    fun confirmAndRestore(fileName: String? = null) {
        val inspection = _pendingInspection.value ?: return
        if (!inspection.isValid) return
        val resolvedName = fileName ?: inspection.sourceDisplayName
        viewModelScope.launch {
            _isWorking.value = true
            _restoreError.value = null
            try {
                val res = if (inspection.stagedZipFilePath.isNotBlank()) {
                    container.backupRestoreEngine.restoreFromStagedZip(inspection.stagedZipFilePath, resolvedName)
                } else {
                    container.backupRestoreEngine.restoreFromBackupBytes(inspection.rawZipBytes, resolvedName)
                }
                _isWorking.value = false
                _pendingInspection.value = null
                res.onSuccess { manifest ->
                    _message.value = "تمت الاستعادة بنجاح: ${manifest.productCount} منتج، ${manifest.reportCount} تقرير"
                }.onFailure { err ->
                    val errText = "تعذر الاستعادة (تم الحفاظ على بيانات الجهاز الحالية): ${err.message}"
                    _message.value = errText
                    _restoreError.value = errText
                }
            } catch (t: Throwable) {
                _isWorking.value = false
                container.backupRestoreEngine.cleanupStagedInspection(inspection)
                _pendingInspection.value = null
                container.globalErrorMonitor.recordError(
                    throwable = t,
                    screenName = ScreenNames.BACKUP_RESTORE,
                    moduleName = DiagnosticModules.BACKUP_RESTORE,
                    operationName = "تأكيد استعادة النسخة",
                    severity = LogSeverity.CRITICAL,
                )
                val errText = "تعذر الاستعادة (تم الحفاظ على بيانات الجهاز الحالية): ${t.message}"
                _message.value = errText
                _restoreError.value = errText
            }
        }
    }

    override fun onCleared() {
        container.backupRestoreEngine.cleanupStagedInspection(_pendingInspection.value)
        super.onCleared()
    }
}
