package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportItemWithBarcodes
import com.example.data.storage.ImageEditParameters
import com.example.domain.model.ReportImageSourceType
import com.example.ui.viewmodel.ReportEditorViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@kotlin.OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportRowImageDialog(
    row: ReportItemWithBarcodes,
    sourceProduct: ProductWithDetails?,
    viewModel: ReportEditorViewModel,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    var showReportImageEditor by remember { mutableStateOf(false) }

    val primaryImgEntity = remember(row) {
        row.images.firstOrNull { it.isPrimary } ?: row.images.firstOrNull()
    }
    val currentSourceLabel = remember(primaryImgEntity) {
        ReportImageSourceType.fromString(primaryImgEntity?.imageSourceType).arabicLabel
    }

    var pendingCameraFile by remember { mutableStateOf<File?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            viewModel.replaceReportItemImageFromUri(row.item.id, uri)
            onDismiss()
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            viewModel.replaceReportItemImageFromUri(row.item.id, uri)
            onDismiss()
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture(),
    ) { success ->
        val f = pendingCameraFile
        if (success && f != null && f.exists() && f.length() > 0L) {
            viewModel.replaceReportItemImageFromUri(row.item.id, Uri.fromFile(f))
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("تغيير صورة التقرير للصف #${row.item.serialNumber}")
                Text(
                    row.item.productNameSnapshot,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "تنبيه: أي تعديل أو استبدال هنا خاص بهذا الصف في التقرير فقط ولا يغيّر صورة المنتج الأصلية.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )

                // Current Report Row Image Preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center,
                ) {
                    PathImageBox(
                        filePath = row.item.imageSnapshotPath,
                        contentDescription = row.item.productNameSnapshot,
                        contentScale = ContentScale.Fit,
                        showDiagnosticsOnError = true,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.BottomStart).padding(6.dp),
                    ) {
                        Text(
                            currentSourceLabel,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }

                // Edit & Restore Actions
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    if (row.item.imageSnapshotPath.isNotBlank() && File(row.item.imageSnapshotPath).exists()) {
                        Button(
                            onClick = { showReportImageEditor = true },
                            modifier = Modifier.testTag("report_edit_row_image_btn"),
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("تحرير الصورة للتقرير فقط")
                        }
                    }
                    if (sourceProduct?.primaryImage != null) {
                        OutlinedButton(
                            onClick = {
                                viewModel.restoreReportItemOriginalImage(row.item.id)
                                onDismiss()
                            },
                            modifier = Modifier.testTag("report_restore_product_image_btn"),
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("استعادة صورة المنتج الأساسية")
                        }
                    }
                }

                HorizontalDivider()
                Text("رفع أو التقاط صورة جديدة للتقرير:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    FilledTonalButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                            )
                        },
                        modifier = Modifier.testTag("report_pick_gallery_btn"),
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("من المعرض")
                    }
                    FilledTonalButton(
                        onClick = { filePickerLauncher.launch("image/*") },
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("من الملفات")
                    }
                    FilledTonalButton(
                        onClick = {
                            val dir = File(context.cacheDir, "camera_tmp").apply { mkdirs() }
                            val tmpFile = File(dir, "rpt_cam_${System.currentTimeMillis()}.jpg")
                            pendingCameraFile = tmpFile
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tmpFile)
                            cameraLauncher.launch(uri)
                        },
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("الكاميرا")
                    }
                }

                // Product's Other Images (if available)
                val productImages = sourceProduct?.images.orEmpty().sortedBy { it.sortOrder }
                if (productImages.isNotEmpty()) {
                    HorizontalDivider()
                    Text(
                        "اختيار من صور المنتج (${productImages.size}):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(productImages, key = { it.id }) { prodImg ->
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .border(1.5.dp, if (prodImg.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                            ) {
                                ProductEntityImageBox(
                                    image = prodImg,
                                    contentDescription = sourceProduct?.product?.name,
                                    preferThumbnail = true,
                                    modifier = Modifier.fillMaxSize(),
                                    onClick = {
                                        viewModel.replaceReportItemImageFromProductPath(
                                            itemId = row.item.id,
                                            sourcePath = prodImg.filePath,
                                            sourceType = if (prodImg.isPrimary) ReportImageSourceType.PRODUCT_PRIMARY else ReportImageSourceType.PRODUCT_GALLERY,
                                            sourceProductId = sourceProduct?.product?.id,
                                            sourceImageId = prodImg.id,
                                        )
                                        onDismiss()
                                    },
                                )
                                if (prodImg.isPrimary) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.align(Alignment.BottomStart).padding(3.dp),
                                    ) {
                                        Text("رئيسية", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
    )

    if (showReportImageEditor && row.item.imageSnapshotPath.isNotBlank()) {
        ReportOnlyImageEditorDialog(
            sourcePath = row.item.imageSnapshotPath,
            productTitle = row.item.productNameSnapshot,
            viewModel = viewModel,
            onDismiss = { showReportImageEditor = false },
            onSave = { params ->
                viewModel.applyReportOnlyImageEdits(
                    itemId = row.item.id,
                    sourcePathOverride = row.item.imageSnapshotPath,
                    params = params,
                ) { ok ->
                    if (ok) {
                        showReportImageEditor = false
                        onDismiss()
                    }
                }
            },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportOnlyImageEditorDialog(
    sourcePath: String,
    productTitle: String,
    viewModel: ReportEditorViewModel,
    onDismiss: () -> Unit,
    onSave: (ImageEditParameters) -> Unit,
) {
    var rotateDeg by remember { mutableIntStateOf(0) }
    var flipH by remember { mutableStateOf(false) }
    var flipV by remember { mutableStateOf(false) }
    var cropLeft by remember { mutableFloatStateOf(0f) }
    var cropTop by remember { mutableFloatStateOf(0f) }
    var cropRight by remember { mutableFloatStateOf(1f) }
    var cropBottom by remember { mutableFloatStateOf(1f) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var previewFill by remember { mutableStateOf(false) }

    val params = remember(rotateDeg, flipH, flipV, cropLeft, cropTop, cropRight, cropBottom, brightness, contrast, saturation) {
        ImageEditParameters(
            cropLeft = cropLeft,
            cropTop = cropTop,
            cropRight = cropRight,
            cropBottom = cropBottom,
            rotateDegrees = rotateDeg,
            flipHorizontal = flipH,
            flipVertical = flipV,
            brightness = brightness,
            contrast = contrast,
            saturation = saturation,
        )
    }

    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(sourcePath, params) {
        previewBitmap = withContext(Dispatchers.Default) {
            viewModel.renderEditedPreviewBitmap(sourcePath, params)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("تحرير الصورة للتقرير فقط", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(productTitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center,
                ) {
                    val bmp = previewBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = productTitle,
                            contentScale = if (previewFill) ContentScale.Crop else ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { rotateDeg = (rotateDeg + 90) % 360 }) {
                            Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("تدوير 90°")
                        }
                        FilterChip(
                            selected = flipH,
                            onClick = { flipH = !flipH },
                            leadingIcon = { Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("قلب أفقي") },
                        )
                        FilterChip(
                            selected = flipV,
                            onClick = { flipV = !flipV },
                            label = { Text("قلب عمودي") },
                        )
                        FilterChip(
                            selected = previewFill,
                            onClick = { previewFill = !previewFill },
                            label = { Text(if (previewFill) "ملء الإطار" else "ملاءمة كاملة") },
                        )
                    }

                    Text("قص سريع:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = cropLeft == 0f && cropTop == 0f && cropRight == 1f && cropBottom == 1f,
                            onClick = { cropLeft = 0f; cropTop = 0f; cropRight = 1f; cropBottom = 1f },
                            leadingIcon = { Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(15.dp)) },
                            label = { Text("كاملة") },
                        )
                        FilterChip(
                            selected = cropLeft == 0.1f && cropTop == 0.1f && cropRight == 0.9f && cropBottom == 0.9f,
                            onClick = { cropLeft = 0.1f; cropTop = 0.1f; cropRight = 0.9f; cropBottom = 0.9f },
                            label = { Text("قص الحواف 10%") },
                        )
                        FilterChip(
                            selected = cropLeft == 0.18f && cropTop == 0.18f && cropRight == 0.82f && cropBottom == 0.82f,
                            onClick = { cropLeft = 0.18f; cropTop = 0.18f; cropRight = 0.82f; cropBottom = 0.82f },
                            label = { Text("تركيز الوسط") },
                        )
                    }

                    Text("السطوع: ${brightness.toInt()}", style = MaterialTheme.typography.labelSmall)
                    Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -80f..80f)

                    Text("التباين: ${String.format("%.2f", contrast)}", style = MaterialTheme.typography.labelSmall)
                    Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.5f..2.0f)

                    Text("التشبع اللوني: ${String.format("%.2f", saturation)}", style = MaterialTheme.typography.labelSmall)
                    Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..2.0f)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            rotateDeg = 0; flipH = false; flipV = false
                            cropLeft = 0f; cropTop = 0f; cropRight = 1f; cropBottom = 1f
                            brightness = 0f; contrast = 1f; saturation = 1f
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text("إعادة ضبط")
                    }
                    Button(
                        onClick = { onSave(params) },
                        modifier = Modifier.weight(1.4f).testTag("report_editor_save_image_btn"),
                    ) {
                        Text("حفظ للتقرير فقط")
                    }
                }
            }
        }
    }
}

@Composable
fun MoveRowPositionDialog(
    title: String,
    totalRows: Int,
    initialPosition: Int = 1,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
) {
    var posText by remember { mutableStateOf(initialPosition.coerceIn(1, totalRows.coerceAtLeast(1)).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أدخل رقم الموضع المطلوب (من 1 إلى $totalRows):", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = posText,
                    onValueChange = { txt -> posText = txt.filter { it.isDigit() } },
                    label = { Text("رقم الصف المستهدف") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("move_row_pos_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pos = (posText.toIntOrNull() ?: 1).coerceIn(1, totalRows.coerceAtLeast(1))
                    onConfirm(pos)
                },
                modifier = Modifier.testTag("move_row_pos_confirm_btn"),
            ) {
                Text("نقل الآن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}
