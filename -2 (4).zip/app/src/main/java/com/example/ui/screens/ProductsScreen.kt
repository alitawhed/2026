package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.AddCircleOutline
import com.example.data.local.entity.ProductWithDetails
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.BarcodeFormatType
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.components.ProductsNumericSettingsDialog
import com.example.ui.components.formatCurrencyValue
import com.example.ui.components.shareFileViaProvider
import com.example.ui.viewmodel.ProductFilterMode
import com.example.ui.viewmodel.ProductSortMode
import com.example.ui.viewmodel.ProductsViewModel

@Composable
fun ProductsScreen(
    viewModel: ProductsViewModel,
    initialFilter: String = "ALL",
    onOpenDetail: (Long) -> Unit,
    onAddProduct: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenExcelImport: () -> Unit,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(initialFilter) {
        when (initialFilter) {
            "NO_IMAGES" -> viewModel.setFilterMode(ProductFilterMode.NO_IMAGES)
            "MULTI_BARCODE" -> viewModel.setFilterMode(ProductFilterMode.MULTI_BARCODE)
            "MISSING_BARCODE" -> viewModel.setFilterMode(ProductFilterMode.MISSING_BARCODE)
            else -> viewModel.setFilterMode(ProductFilterMode.ALL)
        }
    }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var showSortMenu by remember { mutableStateOf(false) }
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showOriginMenu by remember { mutableStateOf(false) }
    var showBulkDeleteConfirm by remember { mutableStateOf(false) }
    var showBulkCatDialog by remember { mutableStateOf(false) }
    var bulkCategoryInput by remember { mutableStateOf("") }
    var selectionMode by remember { mutableStateOf(false) }
    var showProductsDecimalDialog by remember { mutableStateOf(false) }
    var formatChangeTargetProduct by remember { mutableStateOf<ProductWithDetails?>(null) }
    var showBulkBarcodeFormatDialog by remember { mutableStateOf(false) }

    val inSelectionMode = selectionMode || state.selectedProductIds.isNotEmpty()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (inSelectionMode) {
                AppScreenTopBar(
                    title = "تم تحديد ${state.selectedProductIds.size}",
                    onBack = {
                        selectionMode = false
                        viewModel.clearSelection()
                    },
                    actions = {
                        TextButton(onClick = { viewModel.selectAllVisible() }) {
                            Text("تحديد الكل")
                        }
                        IconButton(
                            onClick = { showBulkBarcodeFormatDialog = true },
                            modifier = Modifier.testTag("products_bulk_barcode_format_btn"),
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = "تغيير نوع الباركود للمحدد")
                        }
                        IconButton(onClick = { showBulkCatDialog = true }) {
                            Icon(Icons.Default.Category, contentDescription = "تغيير التصنيف")
                        }
                        IconButton(onClick = {
                            viewModel.exportSelectedOrAllToExcel(false) { file ->
                                shareFileViaProvider(context, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "تصدير المنتجات Excel")
                            }
                        }) {
                            Icon(Icons.Default.Download, contentDescription = "تصدير المحدد Excel")
                        }
                        IconButton(onClick = { showBulkDeleteConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف المحدد", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                )
            } else {
                AppScreenTopBar(
                    title = "إدارة المنتجات",
                    subtitle = "${state.products.size} منتج في القاعدة",
                    saveStatus = state.saveStatus,
                    actions = {
                        IconButton(
                            onClick = onOpenExcelImport,
                            modifier = Modifier.testTag("products_import_excel_btn"),
                        ) {
                            Icon(Icons.Default.TableView, contentDescription = "استيراد Excel")
                        }
                        IconButton(
                            onClick = {
                                viewModel.exportSelectedOrAllToExcel(false) { file ->
                                    shareFileViaProvider(context, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "تصدير المنتجات Excel")
                                }
                            },
                            modifier = Modifier.testTag("products_export_excel_btn"),
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "تصدير Excel")
                        }
                        IconButton(
                            onClick = { showProductsDecimalDialog = true },
                            modifier = Modifier.testTag("products_decimal_settings_btn"),
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = "المنازل العشرية")
                        }
                        Box {
                            IconButton(onClick = { showSortMenu = true }) {
                                Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "ترتيب")
                            }
                            DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                                ProductSortMode.entries.forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text(mode.arabicLabel) },
                                        onClick = {
                                            viewModel.setSortMode(mode)
                                            showSortMenu = false
                                        },
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("المنازل العشرية للمنتجات") },
                                    onClick = {
                                        showSortMenu = false
                                        showProductsDecimalDialog = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("تحديد متعدد") },
                                    onClick = {
                                        selectionMode = true
                                        showSortMenu = false
                                    },
                                )
                            }
                        }
                    },
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddProduct,
                modifier = Modifier.testTag("add_product_fab"),
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة منتج")
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Search Bar + Camera Barcode Lookup
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::setSearchQuery,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("products_search_field"),
                placeholder = { Text("ابحث بالاسم أو ID أو أي باركود...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    Row {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح البحث")
                            }
                        }
                        IconButton(onClick = onOpenScanner, modifier = Modifier.testTag("products_scan_btn")) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
            )

            // Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProductFilterMode.entries.forEach { mode ->
                    FilterChip(
                        selected = state.filterMode == mode,
                        onClick = { viewModel.setFilterMode(mode) },
                        label = { Text(mode.arabicLabel) },
                        modifier = Modifier.testTag("filter_${mode.name}"),
                    )
                }

                Box {
                    FilterChip(
                        selected = state.selectedCategory.isNotEmpty(),
                        onClick = { showCategoryMenu = true },
                        label = { Text(state.selectedCategory.ifBlank { "التصنيف" }) },
                        leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    )
                    DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("كل التصنيفات") },
                            onClick = {
                                viewModel.setSelectedCategory("")
                                showCategoryMenu = false
                            },
                        )
                        state.categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = {
                                    viewModel.setSelectedCategory(cat.name)
                                    showCategoryMenu = false
                                },
                            )
                        }
                    }
                }

                if (state.origins.isNotEmpty()) {
                    Box {
                        FilterChip(
                            selected = state.selectedOrigin.isNotEmpty(),
                            onClick = { showOriginMenu = true },
                            label = { Text(state.selectedOrigin.ifBlank { "بلد المنشأ" }) },
                        )
                        DropdownMenu(expanded = showOriginMenu, onDismissRequest = { showOriginMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("كل البلدان") },
                                onClick = {
                                    viewModel.setSelectedOrigin("")
                                    showOriginMenu = false
                                },
                            )
                            state.origins.forEach { origin ->
                                DropdownMenuItem(
                                    text = { Text(origin) },
                                    onClick = {
                                        viewModel.setSelectedOrigin(origin)
                                        showOriginMenu = false
                                    },
                                )
                            }
                        }
                    }
                }
            }

            if (state.products.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStateCard(
                        title = "لا توجد منتجات مطابقة",
                        description = "أضف منتجاً جديداً أو عدّل معايير البحث والتصفية",
                        icon = Icons.Default.Inventory2,
                        actionLabel = "إضافة منتج",
                        onAction = onAddProduct,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.products, key = { it.product.id }) { item ->
                        ProductRowCard(
                            item = item,
                            numericConfig = state.productsNumericConfig,
                            inSelectionMode = inSelectionMode,
                            isSelected = item.product.id in state.selectedProductIds,
                            onClick = {
                                if (inSelectionMode) viewModel.toggleSelection(item.product.id)
                                else onOpenDetail(item.product.id)
                            },
                            onToggleSelect = {
                                selectionMode = true
                                viewModel.toggleSelection(item.product.id)
                            },
                            onChangeBarcodeFormat = { formatChangeTargetProduct = item },
                            onGenerateAlternativeBarcode = {
                                viewModel.generateAlternativeInternalBarcode(item.product.id)
                            },
                            onDuplicate = { viewModel.duplicateProduct(item.product.id) },
                            onDelete = { viewModel.deleteProduct(item.product.id) },
                        )
                    }
                }
            }
        }
    }

    if (showBulkDeleteConfirm) {
        ConfirmActionDialog(
            title = "حذف المنتجات المحددة",
            message = "هل أنت متأكد من حذف ${state.selectedProductIds.size} منتج؟ لن تتأثر التقارير المحفوظة سابقاً.",
            onConfirm = {
                viewModel.deleteSelectedBulk()
                selectionMode = false
                showBulkDeleteConfirm = false
            },
            onDismiss = { showBulkDeleteConfirm = false },
        )
    }

    if (showBulkCatDialog) {
        AlertDialog(
            onDismissRequest = { showBulkCatDialog = false },
            title = { Text("تحديث التصنيف للمنتجات المحددة") },
            text = {
                OutlinedTextField(
                    value = bulkCategoryInput,
                    onValueChange = { bulkCategoryInput = it },
                    label = { Text("اسم التصنيف") },
                    singleLine = true,
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateCategoryBulk(bulkCategoryInput)
                    selectionMode = false
                    showBulkCatDialog = false
                }) {
                    Text("تطبيق")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkCatDialog = false }) { Text("إلغاء") }
            },
        )
    }
    if (showProductsDecimalDialog) {
        ProductsNumericSettingsDialog(
            config = state.productsNumericConfig,
            onDismiss = { showProductsDecimalDialog = false },
            onSave = viewModel::updateProductsNumericConfig,
            onResetDefaults = viewModel::resetProductsNumericConfig,
        )
    }

    formatChangeTargetProduct?.let { targetProd ->
        val targetBc = targetProd.primaryBarcode ?: targetProd.barcodes.firstOrNull()
        val currentFmt = if (targetBc != null) {
            BarcodeEngine.parseFormatOrNull(targetBc.barcodeType) ?: defaultBarcodeType
        } else {
            defaultBarcodeType
        }
        BarcodeFormatChangeDialog(
            barcodeValue = targetBc?.barcodeValue.orEmpty(),
            currentFormat = currentFmt,
            productName = targetProd.product.name,
            availableScopes = if (targetBc != null) {
                listOf(
                    BarcodeFormatChangeScope.CURRENT_PRODUCT,
                    BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                )
            } else {
                listOf(BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING)
            },
            onDismiss = { formatChangeTargetProduct = null },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                if (targetBc != null) {
                    viewModel.changeProductBarcodeFormat(
                        productId = targetProd.product.id,
                        barcodeId = targetBc.id,
                        targetFormat = targetFormat,
                        scope = scope,
                        alsoUpdateDefault = alsoUpdateDefault,
                    ) {
                        formatChangeTargetProduct = null
                    }
                } else {
                    viewModel.changeProductBarcodeFormat(
                        productId = targetProd.product.id,
                        barcodeId = 0L,
                        targetFormat = targetFormat,
                        scope = BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                        alsoUpdateDefault = true,
                    ) {
                        formatChangeTargetProduct = null
                    }
                }
            },
            onGenerateAlternativeInternal = {
                viewModel.generateAlternativeInternalBarcode(targetProd.product.id)
            },
        )
    }

    if (showBulkBarcodeFormatDialog) {
        val selectedList = state.products.filter { it.product.id in state.selectedProductIds }
        val sampleBc = if (selectedList.size == 1) {
            selectedList.first().primaryBarcode ?: selectedList.first().barcodes.firstOrNull()
        } else null
        BarcodeFormatChangeDialog(
            barcodeValue = sampleBc?.barcodeValue.orEmpty(),
            currentFormat = sampleBc?.let { BarcodeFormatType.fromString(it.barcodeType) } ?: defaultBarcodeType,
            productName = if (selectedList.size == 1) selectedList.first().product.name else "تحديث جماعي (${selectedList.size} منتج)",
            availableScopes = listOf(
                BarcodeFormatChangeScope.SELECTED_PRODUCTS,
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
            ),
            bulkCount = selectedList.size,
            onDismiss = { showBulkBarcodeFormatDialog = false },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                if (scope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                    viewModel.changeProductBarcodeFormat(
                        productId = 0L,
                        barcodeId = 0L,
                        targetFormat = targetFormat,
                        scope = scope,
                        alsoUpdateDefault = true,
                    ) {
                        showBulkBarcodeFormatDialog = false
                    }
                } else {
                    viewModel.changeBulkSelectedProductsBarcodeFormat(
                        targetFormat = targetFormat,
                        alsoUpdateDefault = alsoUpdateDefault,
                    ) { res ->
                        if (res.success && res.updatedCount > 0) {
                            selectionMode = false
                        }
                        showBulkBarcodeFormatDialog = false
                    }
                }
            },
        )
    }
}

@Composable
private fun ProductRowCard(
    item: ProductWithDetails,
    numericConfig: ProductsNumericConfig,
    inSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onToggleSelect: () -> Unit,
    onChangeBarcodeFormat: () -> Unit,
    onGenerateAlternativeBarcode: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("product_card_${item.product.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (inSelectionMode) {
                IconButton(onClick = onToggleSelect) {
                    Icon(
                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "تحديد",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            ProductEntityImageBox(
                image = item.primaryImage,
                contentDescription = item.product.name,
                preferThumbnail = true,
                shape = RoundedCornerShape(12.dp),
                contentScale = ContentScale.Crop,
                showDiagnosticsOnError = false,
                modifier = Modifier.size(60.dp),
            )

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = item.product.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (item.product.categoryName.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Text(
                                text = item.product.categoryName,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = item.primaryBarcode?.barcodeValue ?: "بدون باركود",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (item.barcodes.size > 1) {
                        Badge { Text("+${item.barcodes.size - 1}") }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = formatCurrencyValue(item.product.basePrice, item.product.currency, numericConfig.priceFormat),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "كمية: ${NumberFormatEngine.formatDouble(item.product.defaultQuantity, numericConfig.quantityFormat)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (item.product.internalCode.isNotBlank()) {
                        Text(
                            text = "ID: ${item.product.internalCode}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.testTag("product_menu_btn_${item.product.id}"),
                ) {
                    Icon(Icons.Default.MoreVert, contentDescription = "خيارات المنتج")
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("تغيير نوع الباركود") },
                        leadingIcon = { Icon(Icons.Default.QrCode2, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onChangeBarcodeFormat()
                        },
                        modifier = Modifier.testTag("product_menu_change_barcode_format_${item.product.id}"),
                    )
                    DropdownMenuItem(
                        text = { Text("إنشاء باركود داخلي بديل") },
                        leadingIcon = { Icon(Icons.Default.AddCircleOutline, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onGenerateAlternativeBarcode()
                        },
                        modifier = Modifier.testTag("product_menu_alt_internal_barcode_${item.product.id}"),
                    )
                    DropdownMenuItem(
                        text = { Text("تحديد متعدد") },
                        onClick = {
                            showMenu = false
                            onToggleSelect()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("نسخ المنتج") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onDuplicate()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("حذف المنتج", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            showDeleteConfirm = true
                        },
                    )
                }
            }
        }
    }

    if (showDeleteConfirm) {
        ConfirmActionDialog(
            title = "حذف المنتج",
            message = "هل تريد حذف (${item.product.name})؟ لن تتأثر التقارير السابقة المحفوظة.",
            onConfirm = {
                showDeleteConfirm = false
                onDelete()
            },
            onDismiss = { showDeleteConfirm = false },
        )
    }
}
