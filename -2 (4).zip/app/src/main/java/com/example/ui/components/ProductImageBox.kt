package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.ImageNotSupported
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.storage.ImageResolution
import com.example.data.storage.ImageService

/**
 * Shared image container that cleanly handles:
 * - Loading indicator
 * - Reliable File-based Coil request (zero broken query-string suffixes on filesystem paths)
 * - Missing-image placeholder vs Corrupted/Unreachable diagnostic message + Retry action
 */
@Composable
fun ResolvedImageBox(
    resolution: ImageResolution,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    contentScale: ContentScale = ContentScale.Crop,
    backgroundColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    emptyIcon: ImageVector = Icons.Default.Inventory2,
    emptyLabel: String? = null,
    showDiagnosticsOnError: Boolean = true,
    onRetry: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var localRetryNonce by remember { mutableIntStateOf(0) }

    val baseMod = modifier
        .clip(shape)
        .background(backgroundColor)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)

    when (resolution) {
        is ImageResolution.Available -> {
            val request = remember(resolution.cacheKey, localRetryNonce) {
                ImageRequest.Builder(context)
                    .data(resolution.file)
                    .memoryCacheKey("${resolution.cacheKey}:$localRetryNonce")
                    .diskCacheKey("${resolution.cacheKey}:$localRetryNonce")
                    .crossfade(true)
                    .build()
            }
            SubcomposeAsyncImage(
                model = request,
                contentDescription = contentDescription,
                contentScale = contentScale,
                modifier = baseMod,
                loading = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    }
                },
                error = {
                    ImageErrorFallback(
                        title = "تعذر عرض الصورة",
                        showLabel = showDiagnosticsOnError,
                        onRetry = {
                            localRetryNonce++
                            onRetry?.invoke()
                        },
                    )
                },
            )
        }
        is ImageResolution.Missing -> {
            Box(modifier = baseMod, contentAlignment = Alignment.Center) {
                if (showDiagnosticsOnError) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.padding(4.dp),
                    ) {
                        Icon(
                            Icons.Default.ImageNotSupported,
                            contentDescription = contentDescription ?: "صورة مفقودة",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp),
                        )
                        Text(
                            "ملف مفقود",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center,
                        )
                        if (onRetry != null) {
                            IconButton(
                                onClick = {
                                    localRetryNonce++
                                    onRetry()
                                },
                                modifier = Modifier.size(24.dp),
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "إعادة المحاولة", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                } else {
                    Icon(
                        emptyIcon,
                        contentDescription = contentDescription,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        is ImageResolution.Corrupted -> {
            Box(modifier = baseMod, contentAlignment = Alignment.Center) {
                ImageErrorFallback(
                    title = "ملف تالف",
                    showLabel = showDiagnosticsOnError,
                    onRetry = {
                        localRetryNonce++
                        onRetry?.invoke()
                    },
                )
            }
        }
        ImageResolution.Empty -> {
            Box(modifier = baseMod, contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    modifier = Modifier.padding(4.dp),
                ) {
                    Icon(
                        emptyIcon,
                        contentDescription = contentDescription,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!emptyLabel.isNullOrBlank()) {
                        Text(
                            emptyLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageErrorFallback(
    title: String,
    showLabel: Boolean,
    onRetry: (() -> Unit)?,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Default.BrokenImage,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(24.dp),
        )
        if (showLabel) {
            Text(
                title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center,
            )
            if (onRetry != null) {
                IconButton(onClick = onRetry, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "إعادة المحاولة", modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

/**
 * Convenience helper for resolving and rendering a [ProductImageEntity] cleanly anywhere.
 */
@Composable
fun ProductEntityImageBox(
    image: ProductImageEntity?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    preferThumbnail: Boolean = true,
    refreshTag: Int = 0,
    shape: Shape = RoundedCornerShape(10.dp),
    contentScale: ContentScale = ContentScale.Crop,
    showDiagnosticsOnError: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var retryTick by remember { mutableIntStateOf(0) }
    val resolution = remember(image, preferThumbnail, refreshTag, retryTick) {
        resolveProductImageStateless(image, preferThumbnail, refreshTag + retryTick)
    }
    ResolvedImageBox(
        resolution = resolution,
        contentDescription = contentDescription,
        modifier = modifier,
        shape = shape,
        contentScale = contentScale,
        showDiagnosticsOnError = showDiagnosticsOnError,
        onRetry = { retryTick++ },
        onClick = onClick,
    )
}

@Composable
fun PathImageBox(
    filePath: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    refreshTag: Int = 0,
    shape: Shape = RoundedCornerShape(10.dp),
    contentScale: ContentScale = ContentScale.Crop,
    showDiagnosticsOnError: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    var retryTick by remember { mutableIntStateOf(0) }
    val resolution = remember(filePath, refreshTag, retryTick) {
        resolveRawPathStateless(filePath, refreshTag + retryTick)
    }
    ResolvedImageBox(
        resolution = resolution,
        contentDescription = contentDescription,
        modifier = modifier,
        shape = shape,
        contentScale = contentScale,
        showDiagnosticsOnError = showDiagnosticsOnError,
        onRetry = { retryTick++ },
        onClick = onClick,
    )
}

@Composable
fun InventoryItemImageBox(
    snapshotPath: String?,
    product: ProductWithDetails?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    preferThumbnail: Boolean = true,
    refreshTag: Int = 0,
    shape: Shape = RoundedCornerShape(10.dp),
    contentScale: ContentScale = ContentScale.Crop,
    showDiagnosticsOnError: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    var retryTick by remember { mutableIntStateOf(0) }
    val primary = product?.primaryImage
    val resolution = remember(snapshotPath, primary, preferThumbnail, refreshTag, retryTick) {
        resolveInventoryItemImageStateless(
            snapshotPath = snapshotPath,
            product = product,
            preferThumbnail = preferThumbnail,
            refreshTag = refreshTag + retryTick,
        )
    }
    ResolvedImageBox(
        resolution = resolution,
        contentDescription = contentDescription,
        modifier = modifier,
        shape = shape,
        contentScale = contentScale,
        showDiagnosticsOnError = showDiagnosticsOnError,
        onRetry = { retryTick++ },
        onClick = onClick,
    )
}

fun resolveInventoryItemImageStateless(
    snapshotPath: String?,
    product: ProductWithDetails?,
    preferThumbnail: Boolean = true,
    refreshTag: Int = 0,
): ImageResolution = ImageService.resolveInventoryItemImageStateless(
    snapshotPath = snapshotPath,
    product = product,
    preferThumbnail = preferThumbnail,
    refreshTag = refreshTag,
)

fun resolveProductImageStateless(
    image: ProductImageEntity?,
    preferThumbnail: Boolean = true,
    refreshTag: Int = 0,
): ImageResolution = ImageService.resolveProductImageStateless(
    image = image,
    preferThumbnail = preferThumbnail,
    refreshTag = refreshTag,
)

fun resolveRawPathStateless(
    path: String?,
    refreshTag: Int = 0,
): ImageResolution = ImageService.resolveRawPathStateless(
    path = path,
    refreshTag = refreshTag,
)
