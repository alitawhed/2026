package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.DuplicateBarcodeException
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.QrCode2
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.BarcodeFormatType
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.CachedBarcodeImage
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.viewmodel.ProductsViewModel
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Composable
fun ProductEditorScreen(
    productId: Long,
    prefillBarcode: String,
    prefillBarcodeFormat: String,
    viewModel: ProductsViewModel,
    prefillName: String = "",
    scannedBarcodeResult: Pair<String, String>? = null,
    onConsumeScannedBarcode: () -> Unit = {},
    onLaunchBarcodeCamera: () -> Unit = {},
    onBack: () -> Unit,
    onSaved: (Long) -> Unit,
    onJumpToConflictProduct: (Long) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val conflict by viewModel.duplicateConflict.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var initialized by remember { mutableStateOf(false) }
    var internalCode by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var categoryName by remember { mutableStateOf("") }
    var basePrice by remember { mutableStateOf("0") }
    var currency by remember { mutableStateOf("ر.س") }
    var originCountry by remember { mutableStateOf("") }
    var manufacturer by remember { mutableStateOf("") }
    var defaultQty by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var createdAt by remember { mutableStateOf(System.currentTimeMillis()) }

    val barcodes = remember { mutableStateListOf<ProductBarcodeEntity>() }
    val images = remember { mutableStateListOf<ProductImageEntity>() }
    val customFields = remember { mutableStateListOf<Pair<String, String>>() }

    var showBarcodeDialog by remember { mutableStateOf(false) }
    var editingBarcodeIdx by remember { mutableStateOf<Int?>(null) }
    var formatChangeBarcodeIdx by remember { mutableStateOf<Int?>(null) }
    var deleteBarcodeIdxConfirm by remember { mutableStateOf<Int?>(null) }
    var prefillCameraCode by remember { mutableStateOf("") }
    var prefillCameraFormat by remember { mutableStateOf<BarcodeFormatType?>(null) }
    var localBarcodeConflict by remember { mutableStateOf<DuplicateBarcodeException?>(null) }
    var showCustomFieldDialog by remember { mutableStateOf(false) }

    LaunchedEffect(scannedBarcodeResult) {
        scannedBarcodeResult?.let { (code, fmtStr) ->
            prefillCameraCode = code
            prefillCameraFormat = BarcodeFormatType.fromString(fmtStr)
            editingBarcodeIdx = null
            showBarcodeDialog = true
            onConsumeScannedBarcode()
        }
    }

    LaunchedEffect(productId, prefillBarcode, prefillName) {
        if (!initialized) {
            if (productId > 0L) {
                val existing = viewModel.getProductOnce(productId)
                if (existing != null) {
                    val p = existing.product
                    internalCode = p.internalCode
                    name = p.name
                    description = p.description
                    categoryName = p.categoryName
                    basePrice = NumberFormatEngine.formatEditableNumber(p.basePrice)
                    currency = p.currency
                    originCountry = p.originCountry
                    manufacturer = p.manufacturer
                    defaultQty = NumberFormatEngine.formatEditableNumber(p.defaultQuantity)
                    notes = p.notes
                    createdAt = p.createdAt
                    barcodes.clear()
                    barcodes.addAll(existing.barcodes)
                    images.clear()
                    images.addAll(existing.images.sortedBy { it.sortOrder })
                    try {
                        val map = Json.decodeFromString<Map<String, String>>(p.customFieldsJson)
                        customFields.clear()
                        map.entries.forEach { customFields.add(it.key to it.value) }
                    } catch (_: Exception) {
                    }
                }
            } else {
                if (prefillName.isNotBlank()) {
                    name = prefillName.trim()
                }
                if (prefillBarcode.isNotBlank()) {
                    val resolvedFmt = BarcodeEngine.parseFormatOrNull(prefillBarcodeFormat)
                        ?: BarcodeEngine.resolveCompatibleDefaultFormat(prefillBarcode, defaultBarcodeType)
                    barcodes.add(
                        ProductBarcodeEntity(
                            productId = 0L,
                            barcodeValue = prefillBarcode,
                            barcodeType = resolvedFmt.name,
                            label = "رئيسي",
                            isPrimary = true,
                        ),
                    )
                }
            }
            initialized = true
        }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.saveTempImagesFromUris(uris) { storedList ->
                storedList.forEach { stored ->
                    images.add(
                        ProductImageEntity(
                            productId = productId,
                            filePath = stored.activePath,
                            originalFilePath = stored.originalPath,
                            thumbnailPath = stored.thumbnailPath,
                            isPrimary = images.isEmpty(),
                            sortOrder = images.size,
                        ),
                    )
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = if (productId == 0L) "إضافة منتج جديد" else "تعديل المنتج",
                onBack = onBack,
                actions = {
                    Button(
                        onClick = {
                            val customMap = customFields
                                .filter { it.first.isNotBlank() }
                                .associate { it.first.trim() to it.second.trim() }
                            val entity = ProductEntity(
                                id = productId,
                                internalCode = internalCode.trim(),
                                name = name.trim(),
                                description = description.trim(),
                                categoryName = categoryName.trim(),
                                basePrice = basePrice.replace(",", "").toDoubleOrNull() ?: 0.0,
                                currency = currency.trim().ifBlank { "ر.س" },
                                originCountry = originCountry.trim(),
                                manufacturer = manufacturer.trim(),
                                defaultQuantity = defaultQty.replace(",", "").toDoubleOrNull()?.coerceAtLeast(0.0) ?: 1.0,
                                notes = notes.trim(),
                                customFieldsJson = Json.encodeToString(customMap),
                                createdAt = createdAt,
                            )
                            viewModel.saveProduct(entity, barcodes.toList(), images.toList()) { savedId ->
                                onSaved(savedId)
                            }
                        },
                        modifier = Modifier.padding(end = 8.dp).testTag("save_product_btn"),
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("حفظ")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج *") },
                    modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                    singleLine = true,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = internalCode,
                        onValueChange = { internalCode = it },
                        label = { Text("رقم التعريف الداخلي ID") },
                        modifier = Modifier.weight(1f).testTag("product_id_input"),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = categoryName,
                        onValueChange = { categoryName = it },
                        label = { Text("التصنيف") },
                        modifier = Modifier.weight(1f).testTag("product_category_input"),
                        singleLine = true,
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = basePrice,
                        onValueChange = { basePrice = it },
                        label = { Text("السعر الأساسي") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f).testTag("product_price_input"),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = currency,
                        onValueChange = { currency = it },
                        label = { Text("العملة") },
                        modifier = Modifier.weight(0.6f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = defaultQty,
                        onValueChange = { defaultQty = it },
                        label = { Text("الكمية الافتراضية") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(0.8f),
                        singleLine = true,
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = originCountry,
                        onValueChange = { originCountry = it },
                        label = { Text("بلد المنشأ") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = manufacturer,
                        onValueChange = { manufacturer = it },
                        label = { Text("اسم المصنع") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("وصف المنتج") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
            }
            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
            }

            // Multi-Barcode Editor Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("الباركودات (${barcodes.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = { onLaunchBarcodeCamera() },
                                    modifier = Modifier.testTag("editor_scan_barcode_btn"),
                                ) {
                                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("مسح")
                                }
                                FilledTonalButton(
                                    onClick = {
                                        prefillCameraCode = ""
                                        prefillCameraFormat = null
                                        editingBarcodeIdx = null
                                        showBarcodeDialog = true
                                    },
                                    modifier = Modifier.testTag("editor_add_barcode_btn"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("يدوياً")
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val code = viewModel.previewNewInternalBarcodeValue(productId, defaultBarcodeType)
                                    val now = System.currentTimeMillis()
                                    val makePrim = barcodes.none { it.isPrimary }
                                    barcodes.add(
                                        ProductBarcodeEntity(
                                            productId = productId,
                                            barcodeValue = code,
                                            barcodeType = defaultBarcodeType.name,
                                            label = if (makePrim) "رئيسي (داخلي)" else "داخلي بديل",
                                            unitType = "حبة",
                                            conversionFactor = 1.0,
                                            isPrimary = makePrim,
                                            createdAt = now,
                                            updatedAt = now,
                                        ),
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("editor_generate_internal_barcode_btn"),
                        ) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إنشاء باركود داخلي جديد (${defaultBarcodeType.arabicLabel})")
                        }
                        barcodes.forEachIndexed { idx, b ->
                            val itemFmt = BarcodeFormatType.fromString(b.barcodeType)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.background,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(b.barcodeValue, fontWeight = FontWeight.Bold)
                                            val factorLabel = if (b.conversionFactor == 1.0) "1" else b.conversionFactor.toString().removeSuffix(".0")
                                            Text(
                                                "${itemFmt.arabicLabel} • ${b.unitType} (×$factorLabel)" +
                                                    if (b.isPrimary) " (رئيسي)" else " (بديل)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                            if (b.description.isNotBlank()) {
                                                Text(b.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                        IconButton(
                                            onClick = { formatChangeBarcodeIdx = idx },
                                            modifier = Modifier.testTag("editor_change_barcode_format_$idx"),
                                        ) {
                                            Icon(Icons.Default.QrCode2, contentDescription = "تغيير نوع الباركود", tint = MaterialTheme.colorScheme.primary)
                                        }
                                        IconButton(onClick = {
                                            for (i in barcodes.indices) {
                                                barcodes[i] = barcodes[i].copy(isPrimary = i == idx)
                                            }
                                        }) {
                                            Icon(
                                                Icons.Default.Star,
                                                contentDescription = "تعيين رئيسي",
                                                tint = if (b.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                            )
                                        }
                                        IconButton(onClick = {
                                            editingBarcodeIdx = idx
                                            showBarcodeDialog = true
                                        }) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل الباركود")
                                        }
                                        IconButton(onClick = { deleteBarcodeIdxConfirm = idx }) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                    CachedBarcodeImage(
                                        productId = productId.takeIf { it > 0L },
                                        barcodeValue = b.barcodeValue,
                                        format = itemFmt,
                                        barcodeService = viewModel.barcodeService,
                                        baseWidthPx = 680,
                                        baseHeightPx = if (itemFmt.is2D) 220 else 180,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(64.dp)
                                            .testTag("editor_barcode_image_$idx"),
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Images Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("الصور (${images.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            FilledTonalButton(onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("إضافة صورة")
                            }
                        }
                        if (images.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(images) { idx, img ->
                                    Box(modifier = Modifier.size(88.dp)) {
                                        com.example.ui.components.ProductEntityImageBox(
                                            image = img,
                                            contentDescription = "صورة المنتج",
                                            preferThumbnail = true,
                                            shape = RoundedCornerShape(10.dp),
                                            contentScale = ContentScale.Crop,
                                            showDiagnosticsOnError = true,
                                            modifier = Modifier.fillMaxSize(),
                                        )
                                        IconButton(
                                            onClick = { images.removeAt(idx) },
                                            modifier = Modifier.align(Alignment.TopEnd).size(26.dp).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(50)),
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "حذف", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Custom Fields Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("حقول إضافية قابلة للتخصيص", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showCustomFieldDialog = true }) {
                                Text("+ حقل مخصص")
                            }
                        }
                        customFields.forEachIndexed { idx, (k, v) ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("$k: $v", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                IconButton(onClick = { customFields.removeAt(idx) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف حقل")
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }

    if (showBarcodeDialog) {
        val editingEntity = editingBarcodeIdx?.let { barcodes.getOrNull(it) }
        BarcodeEditorDialog(
            existing = editingEntity,
            prefillValue = if (editingEntity == null) prefillCameraCode else "",
            prefillFormat = if (editingEntity == null) prefillCameraFormat else null,
            defaultFormat = defaultBarcodeType,
            onScanWithCamera = if (editingEntity == null) {
                {
                    showBarcodeDialog = false
                    onLaunchBarcodeCamera()
                }
            } else null,
            onDismiss = {
                showBarcodeDialog = false
                editingBarcodeIdx = null
                prefillCameraCode = ""
                prefillCameraFormat = null
            },
            onSave = { draft ->
                scope.launch {
                    val idxEdit = editingBarcodeIdx
                    val dupInDraft = barcodes.withIndex().firstOrNull { (i, item) ->
                        i != idxEdit && item.barcodeValue == draft.value
                    }
                    if (dupInDraft != null) {
                        localBarcodeConflict = DuplicateBarcodeException(
                            draft.value,
                            productId,
                            name.ifBlank { "هذا المنتج" },
                        )
                        return@launch
                    }
                    val dbConflict = viewModel.checkBarcodeConflict(draft.value, excludeProductId = productId)
                    if (dbConflict != null) {
                        localBarcodeConflict = DuplicateBarcodeException(
                            draft.value,
                            dbConflict.product.id,
                            dbConflict.product.name,
                        )
                        return@launch
                    }

                    val now = System.currentTimeMillis()
                    val shouldBePrimary = draft.makePrimary || barcodes.none { it.isPrimary }
                    if (shouldBePrimary) {
                        for (i in barcodes.indices) {
                            barcodes[i] = barcodes[i].copy(isPrimary = false)
                        }
                    }
                    if (idxEdit != null && idxEdit in barcodes.indices) {
                        val old = barcodes[idxEdit]
                        barcodes[idxEdit] = old.copy(
                            barcodeValue = draft.value,
                            barcodeType = draft.format.name,
                            label = draft.label,
                            description = draft.description,
                            unitType = draft.unitType,
                            conversionFactor = draft.conversionFactor,
                            isPrimary = shouldBePrimary,
                            updatedAt = now,
                        )
                    } else {
                        barcodes.add(
                            ProductBarcodeEntity(
                                productId = productId,
                                barcodeValue = draft.value,
                                barcodeType = draft.format.name,
                                label = draft.label,
                                description = draft.description,
                                unitType = draft.unitType,
                                conversionFactor = draft.conversionFactor,
                                isPrimary = shouldBePrimary,
                                createdAt = now,
                                updatedAt = now,
                            ),
                        )
                    }
                    showBarcodeDialog = false
                    editingBarcodeIdx = null
                    prefillCameraCode = ""
                    prefillCameraFormat = null
                    if (draft.continueScanningAnother) {
                        onLaunchBarcodeCamera()
                    }
                }
            },
        )
    }

    deleteBarcodeIdxConfirm?.let { idx ->
        val target = barcodes.getOrNull(idx)
        if (target != null) {
            ConfirmActionDialog(
                title = "حذف الباركود",
                message = "هل أنت متأكد من إزالة الباركود (${target.barcodeValue})؟",
                onConfirm = {
                    barcodes.removeAt(idx)
                    if (barcodes.isNotEmpty() && barcodes.none { it.isPrimary }) {
                        barcodes[0] = barcodes[0].copy(isPrimary = true)
                    }
                    deleteBarcodeIdxConfirm = null
                },
                onDismiss = { deleteBarcodeIdxConfirm = null },
            )
        } else {
            deleteBarcodeIdxConfirm = null
        }
    }

    if (showCustomFieldDialog) {
        var fieldKey by remember { mutableStateOf("") }
        var fieldVal by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCustomFieldDialog = false },
            title = { Text("إضافة حقل مخصص") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = fieldKey, onValueChange = { fieldKey = it }, label = { Text("اسم الحقل (مثال: الوزن / الصلاحية)") }, singleLine = true)
                    OutlinedTextField(value = fieldVal, onValueChange = { fieldVal = it }, label = { Text("القيمة") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (fieldKey.isNotBlank()) customFields.add(fieldKey.trim() to fieldVal.trim())
                    showCustomFieldDialog = false
                }) { Text("إضافة") }
            },
            dismissButton = {
                TextButton(onClick = { showCustomFieldDialog = false }) { Text("إلغاء") }
            },
        )
    }

    (conflict ?: localBarcodeConflict)?.let { err ->
        AlertDialog(
            onDismissRequest = {
                viewModel.clearConflict()
                localBarcodeConflict = null
            },
            title = { Text("تنبيه: باركود مكرر") },
            text = { Text("الباركود (${err.barcodeValue}) مستخدم مسبقاً في المنتج: ${err.conflictingProductName}.") },
            confirmButton = {
                if (err.conflictingProductId > 0L && err.conflictingProductId != productId) {
                    Button(onClick = {
                        viewModel.clearConflict()
                        localBarcodeConflict = null
                        onJumpToConflictProduct(err.conflictingProductId)
                    }) { Text("الانتقال للمنتج الموجود") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    viewModel.clearConflict()
                    localBarcodeConflict = null
                }) { Text("تعديل الباركود") }
            },
        )
    }

    formatChangeBarcodeIdx?.let { idx ->
        val draftBc = barcodes.getOrNull(idx)
        if (draftBc != null) {
            BarcodeFormatChangeDialog(
                barcodeValue = draftBc.barcodeValue,
                currentFormat = BarcodeFormatType.fromString(draftBc.barcodeType),
                productName = name.ifBlank { "منتج قيد التحرير" },
                availableScopes = listOf(
                    BarcodeFormatChangeScope.CURRENT_PRODUCT,
                    BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                ),
                onDismiss = { formatChangeBarcodeIdx = null },
                onConfirmChange = { targetFormat, changeScope, alsoUpdateDefault ->
                    if (changeScope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                        viewModel.changeProductBarcodeFormat(
                            productId = productId,
                            barcodeId = draftBc.id,
                            targetFormat = targetFormat,
                            scope = changeScope,
                            alsoUpdateDefault = true,
                        ) {
                            formatChangeBarcodeIdx = null
                        }
                    } else {
                        barcodes[idx] = draftBc.copy(
                            barcodeType = targetFormat.name,
                            updatedAt = System.currentTimeMillis(),
                        )
                        if (draftBc.id > 0L && productId > 0L) {
                            viewModel.changeProductBarcodeFormat(
                                productId = productId,
                                barcodeId = draftBc.id,
                                targetFormat = targetFormat,
                                scope = changeScope,
                                alsoUpdateDefault = alsoUpdateDefault,
                            )
                        } else if (alsoUpdateDefault) {
                            viewModel.changeProductBarcodeFormat(
                                productId = productId,
                                barcodeId = 0L,
                                targetFormat = targetFormat,
                                scope = BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                                alsoUpdateDefault = true,
                            )
                        }
                        formatChangeBarcodeIdx = null
                    }
                },
            )
        } else {
            formatChangeBarcodeIdx = null
        }
    }
}
