package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.PhotoSizeSelectLarge
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.ProductImageEntity
import com.example.data.storage.ImageEditParameters
import com.example.di.AppContainer
import com.example.ui.components.AppScreenTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ImageEditorScreen(
    imageId: Long,
    container: AppContainer,
    onBack: () -> Unit,
    onSaved: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var imageEntity by remember { mutableStateOf<ProductImageEntity?>(null) }
    var sourceSampleBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isBusy by remember { mutableStateOf(true) }
    var activeTab by remember { mutableIntStateOf(0) }
    var zoomScale by remember { mutableFloatStateOf(1f) }

    var params by remember { mutableStateOf(ImageEditParameters()) }
    val undoStack = remember { mutableStateListOf<ImageEditParameters>() }
    val redoStack = remember { mutableStateListOf<ImageEditParameters>() }

    fun pushParams(next: ImageEditParameters) {
        if (next == params) return
        undoStack.add(params)
        if (undoStack.size > 30) undoStack.removeAt(0)
        redoStack.clear()
        params = next
    }

    fun reloadPreviewSource(entity: ProductImageEntity) {
        scope.launch {
            isBusy = true
            val bmp = withContext(Dispatchers.IO) {
                val loadPath = if (entity.filePath.isNotBlank() && File(entity.filePath).exists()) {
                    entity.filePath
                } else {
                    entity.originalFilePath
                }
                container.mediaStorage.decodeSampledBitmap(loadPath, 1080)
            }
            sourceSampleBitmap?.recycle()
            sourceSampleBitmap = bmp
            isBusy = false
        }
    }

    LaunchedEffect(imageId) {
        val loaded = withContext(Dispatchers.IO) {
            container.productRepository.getImageById(imageId)
        }
        imageEntity = loaded
        if (loaded != null) {
            reloadPreviewSource(loaded)
        } else {
            isBusy = false
        }
    }

    LaunchedEffect(sourceSampleBitmap, params) {
        val src = sourceSampleBitmap ?: return@LaunchedEffect
        val rendered = withContext(Dispatchers.Default) {
            container.mediaStorage.renderEditedBitmap(src, params)
        }
        val old = previewBitmap
        previewBitmap = rendered
        if (old != null && old !== rendered && !old.isRecycled) {
            old.recycle()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            sourceSampleBitmap?.recycle()
            previewBitmap?.recycle()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "محرر الصور الاحترافي",
                subtitle = if (imageEntity?.originalFilePath?.isNotBlank() == true) "تحرير غير متلف (الأصل محفوظ)" else null,
                onBack = onBack,
                actions = {
                    IconButton(
                        enabled = undoStack.isNotEmpty(),
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack.add(params)
                                params = undoStack.removeAt(undoStack.lastIndex)
                            }
                        },
                        modifier = Modifier.testTag("img_editor_undo"),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع")
                    }
                    IconButton(
                        enabled = redoStack.isNotEmpty(),
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack.add(params)
                                params = redoStack.removeAt(redoStack.lastIndex)
                            }
                        },
                        modifier = Modifier.testTag("img_editor_redo"),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة")
                    }
                    IconButton(
                        enabled = imageEntity?.originalFilePath?.isNotBlank() == true,
                        onClick = {
                            val entity = imageEntity ?: return@IconButton
                            scope.launch {
                                isBusy = true
                                val restored = withContext(Dispatchers.IO) {
                                    container.mediaStorage.restoreFromOriginal(entity.originalFilePath, entity.filePath)
                                }
                                if (restored != null) {
                                    container.productRepository.updateImagePathsNonDestructive(
                                        entity.id,
                                        restored.activePath,
                                        restored.originalPath,
                                        restored.thumbnailPath,
                                    )
                                    val updated = entity.copy(
                                        filePath = restored.activePath,
                                        originalFilePath = restored.originalPath,
                                        thumbnailPath = restored.thumbnailPath,
                                    )
                                    imageEntity = updated
                                    params = ImageEditParameters()
                                    undoStack.clear()
                                    redoStack.clear()
                                    reloadPreviewSource(updated)
                                    snackbarHostState.showSnackbar("تمت استعادة النسخة الأصلية بنجاح")
                                } else {
                                    isBusy = false
                                    snackbarHostState.showSnackbar("النسخة الأصلية غير متوفرة")
                                }
                            }
                        },
                        modifier = Modifier.testTag("img_editor_restore_original"),
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = "استعادة الأصل")
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Interactive Preview Box with Crop Overlay Guide & Pinch Zoom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0F172A))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomScale = (zoomScale * zoom).coerceIn(1f, 4f)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (isBusy) {
                    CircularProgressIndicator(color = Color.White)
                } else {
                    val bmp = previewBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "معاينة الصورة المحررة",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                                .graphicsLayer(scaleX = zoomScale, scaleY = zoomScale),
                        )
                        if (activeTab == 0) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                                val l = size.width * params.cropLeft
                                val t = size.height * params.cropTop
                                val r = size.width * params.cropRight
                                val b = size.height * params.cropBottom
                                drawRect(
                                    color = Color(0xFF14B8A6),
                                    topLeft = Offset(l, t),
                                    size = Size((r - l).coerceAtLeast(10f), (b - t).coerceAtLeast(10f)),
                                    style = Stroke(width = 3f),
                                )
                            }
                        }
                        Text(
                            text = "${bmp.width} × ${bmp.height} px",
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    } else {
                        Text("تعذر تحميل الصورة", color = Color.White)
                    }
                }
            }

            // Tool Category Tabs
            TabRow(selectedTabIndex = activeTab) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, icon = { Icon(Icons.Default.Crop, null) }, text = { Text("قص وتدوير") })
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, icon = { Icon(Icons.Default.Tune, null) }, text = { Text("الألوان") })
                Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, icon = { Icon(Icons.Default.AutoFixHigh, null) }, text = { Text("الخلفية") })
                Tab(selected = activeTab == 3, onClick = { activeTab = 3 }, icon = { Icon(Icons.Default.PhotoSizeSelectLarge, null) }, text = { Text("الحجم") })
            }

            // Controls Panel
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(185.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (activeTab) {
                        0 -> {
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                OutlinedButton(onClick = { pushParams(params.copy(rotateDegrees = (params.rotateDegrees + 270) % 360)) }) {
                                    Icon(Icons.AutoMirrored.Filled.RotateLeft, null, Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("يسار 90°")
                                }
                                OutlinedButton(onClick = { pushParams(params.copy(rotateDegrees = (params.rotateDegrees + 90) % 360)) }) {
                                    Icon(Icons.AutoMirrored.Filled.RotateRight, null, Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("يمين 90°")
                                }
                                OutlinedButton(onClick = { pushParams(params.copy(flipHorizontal = !params.flipHorizontal)) }) {
                                    Icon(Icons.Default.Flip, null, Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("قلب أفقي")
                                }
                                OutlinedButton(onClick = { pushParams(params.copy(flipVertical = !params.flipVertical)) }) {
                                    Text("قلب رأسي")
                                }
                            }
                            Text("نسبة القص الجاهزة:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = params.cropLeft == 0f && params.cropRight == 1f && params.cropTop == 0f && params.cropBottom == 1f,
                                    onClick = { pushParams(params.copy(cropLeft = 0f, cropTop = 0f, cropRight = 1f, cropBottom = 1f)) },
                                    label = { Text("حر / كامل") },
                                )
                                FilterChip(
                                    selected = false,
                                    onClick = { pushParams(params.copy(cropLeft = 0.1f, cropTop = 0.1f, cropRight = 0.9f, cropBottom = 0.9f)) },
                                    label = { Text("1:1 مربع") },
                                )
                                FilterChip(
                                    selected = false,
                                    onClick = { pushParams(params.copy(cropLeft = 0.05f, cropTop = 0.12f, cropRight = 0.95f, cropBottom = 0.88f)) },
                                    label = { Text("4:3") },
                                )
                                FilterChip(
                                    selected = false,
                                    onClick = { pushParams(params.copy(cropLeft = 0.02f, cropTop = 0.22f, cropRight = 0.98f, cropBottom = 0.78f)) },
                                    label = { Text("16:9") },
                                )
                            }
                            Text("قص أفقي (${((params.cropLeft) * 100).toInt()}% - ${((params.cropRight) * 100).toInt()}%)")
                            Slider(
                                value = params.cropLeft,
                                onValueChange = { l -> pushParams(params.copy(cropLeft = l.coerceAtMost(params.cropRight - 0.15f))) },
                                valueRange = 0f..0.4f,
                            )
                            Text("قص رأسي (${((params.cropTop) * 100).toInt()}% - ${((params.cropBottom) * 100).toInt()}%)")
                            Slider(
                                value = params.cropTop,
                                onValueChange = { t -> pushParams(params.copy(cropTop = t.coerceAtMost(params.cropBottom - 0.15f))) },
                                valueRange = 0f..0.4f,
                            )
                        }
                        1 -> {
                            Text("السطوع (${params.brightness.toInt()})")
                            Slider(
                                value = params.brightness,
                                onValueChange = { pushParams(params.copy(brightness = it)) },
                                valueRange = -80f..80f,
                            )
                            Text("التباين (${String.format(java.util.Locale.US, "%.2f", params.contrast)}x)")
                            Slider(
                                value = params.contrast,
                                onValueChange = { pushParams(params.copy(contrast = it)) },
                                valueRange = 0.5f..2.0f,
                            )
                            Text("التشبع (${String.format(java.util.Locale.US, "%.2f", params.saturation)}x)")
                            Slider(
                                value = params.saturation,
                                onValueChange = { pushParams(params.copy(saturation = it)) },
                                valueRange = 0f..2.0f,
                            )
                            Text("توازن الحرارة اللونية (${params.temperatureWarmth.toInt()})")
                            Slider(
                                value = params.temperatureWarmth,
                                onValueChange = { pushParams(params.copy(temperatureWarmth = it)) },
                                valueRange = -35f..35f,
                            )
                        }
                        2 -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("تنظيف وإزالة الخلفية الفاتحة", fontWeight = FontWeight.Bold)
                                    Text(
                                        "يزيل الخلفيات البيضاء والفاتحة تلقائياً ليظهر المنتج بشكل استوديو نظيف داخل التقارير",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Switch(
                                    checked = params.removeLightBackground,
                                    onCheckedChange = { pushParams(params.copy(removeLightBackground = it)) },
                                )
                            }
                            if (params.removeLightBackground) {
                                Text("حساسية إزالة الخلفية (${params.backgroundThreshold})")
                                Slider(
                                    value = params.backgroundThreshold.toFloat(),
                                    onValueChange = { pushParams(params.copy(backgroundThreshold = it.toInt())) },
                                    valueRange = 190f..252f,
                                )
                            }
                        }
                        3 -> {
                            Text("الدقة والضغط عند الحفظ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                listOf(0 to "الأصل", 1600 to "1600px", 1200 to "1200px", 800 to "800px").forEach { (dim, label) ->
                                    FilterChip(
                                        selected = params.targetMaxWidth == dim,
                                        onClick = { pushParams(params.copy(targetMaxWidth = dim, targetMaxHeight = dim)) },
                                        label = { Text(label) },
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = params.exportAsPng,
                                    onClick = { pushParams(params.copy(exportAsPng = true)) },
                                    label = { Text("PNG (يدعم الشفافية)") },
                                )
                                FilterChip(
                                    selected = !params.exportAsPng,
                                    onClick = { pushParams(params.copy(exportAsPng = false)) },
                                    label = { Text("JPEG مضغوط (${params.jpegQuality}%)") },
                                )
                            }
                            if (!params.exportAsPng) {
                                Text("جودة الضغط JPEG (${params.jpegQuality}%)")
                                Slider(
                                    value = params.jpegQuality.toFloat(),
                                    onValueChange = { pushParams(params.copy(jpegQuality = it.toInt())) },
                                    valueRange = 55f..100f,
                                )
                            }
                        }
                    }
                }
            }

            // Save Actions: Save Changes (keeps original intact!) OR Save As New Copy
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !isBusy && imageEntity != null,
                    onClick = {
                        val entity = imageEntity ?: return@OutlinedButton
                        scope.launch {
                            isBusy = true
                            val result = withContext(Dispatchers.IO) {
                                container.mediaStorage.applyImageEdits(
                                    sourceImagePath = entity.filePath,
                                    existingOriginalPath = entity.originalFilePath,
                                    activeFilePath = entity.filePath,
                                    params = params,
                                    saveAsNewCopy = true,
                                )
                            }
                            if (result != null) {
                                container.productRepository.addStoredImageTripletToProduct(
                                    productId = entity.productId,
                                    storedPath = result.activePath,
                                    originalPath = result.originalPath,
                                    thumbnailPath = result.thumbnailPath,
                                    makePrimary = false,
                                )
                                snackbarHostState.showSnackbar("تم حفظ نسخة جديدة مستقلة للمنتج")
                                onSaved()
                            } else {
                                snackbarHostState.showSnackbar("تعذر حفظ النسخة الجديدة")
                            }
                            isBusy = false
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("img_editor_save_copy_btn"),
                ) {
                    Icon(Icons.Default.ContentCopy, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("حفظ كنسخة جديدة")
                }

                Button(
                    enabled = !isBusy && imageEntity != null,
                    onClick = {
                        val entity = imageEntity ?: return@Button
                        scope.launch {
                            isBusy = true
                            val result = withContext(Dispatchers.IO) {
                                container.mediaStorage.applyImageEdits(
                                    sourceImagePath = entity.filePath,
                                    existingOriginalPath = entity.originalFilePath,
                                    activeFilePath = entity.filePath,
                                    params = params,
                                    saveAsNewCopy = false,
                                )
                            }
                            if (result != null) {
                                container.productRepository.updateImagePathsNonDestructive(
                                    imageId = entity.id,
                                    newActivePath = result.activePath,
                                    originalPath = result.originalPath,
                                    newThumbnailPath = result.thumbnailPath,
                                )
                                snackbarHostState.showSnackbar("تم حفظ التعديلات (الأصل محفوظ للاستعادة)")
                                onSaved()
                            } else {
                                snackbarHostState.showSnackbar("تعذر حفظ التعديلات")
                            }
                            isBusy = false
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("img_editor_save_btn"),
                ) {
                    Icon(Icons.Default.Check, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("حفظ التعديلات")
                }
            }
        }
    }
}
