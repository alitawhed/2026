package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ProductWithDetails
import com.example.di.AppContainer
import com.example.domain.barcode.BarcodeChangeResult
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.BarcodeFormatType
import com.example.domain.pdf.LabelPrintItem
import com.example.domain.pdf.LabelSheetConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LabelPrintingViewModel(private val container: AppContainer) : ViewModel() {

    val barcodeService = container.barcodeService
    val defaultBarcodeType: StateFlow<BarcodeFormatType> = container.barcodeService.defaultBarcodeTypeFlow

    val products: StateFlow<List<ProductWithDetails>> = container.productRepository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val productsNumericConfig: StateFlow<ProductsNumericConfig> =
        container.settingsRepository.productsNumericConfigFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProductsNumericConfig())

    private val _selectedLabels = MutableStateFlow<List<LabelPrintItem>>(emptyList())
    val selectedLabels: StateFlow<List<LabelPrintItem>> = _selectedLabels.asStateFlow()

    private val _config = MutableStateFlow(LabelSheetConfig())
    val config: StateFlow<LabelSheetConfig> = _config.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    fun clearMessage() { _message.value = null }
    fun postMessage(msg: String) { _message.value = msg }

    fun updateConfig(newConfig: LabelSheetConfig) {
        _config.value = newConfig
    }

    fun addBarcodeLabel(product: ProductWithDetails, barcodeValue: String, format: BarcodeFormatType, copies: Int = 1) {
        val current = _selectedLabels.value.toMutableList()
        val existingIdx = current.indexOfFirst { it.barcodeValue == barcodeValue }
        if (existingIdx >= 0) {
            val prev = current[existingIdx]
            current[existingIdx] = prev.copy(copies = (prev.copies + copies).coerceIn(1, 500))
        } else {
            val formattedPrice = NumberFormatEngine.formatCurrencyAmount(
                value = product.product.basePrice,
                currency = product.product.currency,
                spec = productsNumericConfig.value.priceFormat,
            )
            current.add(
                LabelPrintItem(
                    productName = product.product.name,
                    barcodeValue = barcodeValue,
                    barcodeFormat = format,
                    priceText = formattedPrice,
                    copies = copies.coerceIn(1, 500),
                ),
            )
        }
        _selectedLabels.value = current
    }

    fun updateCopies(barcodeValue: String, copies: Int) {
        _selectedLabels.value = _selectedLabels.value.map {
            if (it.barcodeValue == barcodeValue) it.copy(copies = copies.coerceIn(1, 500)) else it
        }
    }

    fun removeLabel(barcodeValue: String) {
        _selectedLabels.value = _selectedLabels.value.filterNot { it.barcodeValue == barcodeValue }
    }

    fun changeLabelBarcodeFormat(
        barcodeValue: String,
        targetFormat: BarcodeFormatType,
        scope: BarcodeFormatChangeScope,
        alsoUpdateDefault: Boolean = false,
        onResult: (BarcodeChangeResult) -> Unit = {},
    ) {
        viewModelScope.launch {
            if (scope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                val saved = container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
                val out = if (saved.isSuccess) {
                    BarcodeChangeResult(
                        success = true,
                        message = "تم تعيين ${targetFormat.arabicLabel} كنوع افتراضي للمنتجات الداخلية الجديدة مستقبلاً",
                        appliedFormat = targetFormat,
                    )
                } else {
                    BarcodeChangeResult(false, "تعذر تحديث النوع الافتراضي")
                }
                _message.value = out.message
                onResult(out)
                return@launch
            }

            val validation = BarcodeEngine.validate(barcodeValue, targetFormat)
            if (!validation.isValid) {
                val msg = validation.errorMessage ?: "القيمة غير متوافقة مع ${targetFormat.arabicLabel}"
                _message.value = msg
                onResult(BarcodeChangeResult(false, msg))
                return@launch
            }

            // Update live label list immediately so UI preview, SVG, PNG and PDF reflect the new format right away
            _selectedLabels.value = _selectedLabels.value.map { item ->
                if (item.barcodeValue == barcodeValue) item.copy(barcodeFormat = targetFormat) else item
            }

            if (scope == BarcodeFormatChangeScope.CURRENT_PRODUCT) {
                val match = products.value.firstNotNullOfOrNull { p ->
                    val bc = p.barcodes.firstOrNull { it.barcodeValue == barcodeValue }
                    if (bc != null) p.product.id to bc.id else null
                }
                if (match != null) {
                    val res = container.barcodeService.changeFormatForProductBarcode(
                        productId = match.first,
                        barcodeId = match.second,
                        targetFormat = targetFormat,
                        alsoUpdateDefaultSetting = alsoUpdateDefault,
                    )
                    _message.value = res.message
                    onResult(res)
                    return@launch
                }
            }

            if (alsoUpdateDefault) {
                container.barcodeService.updateDefaultBarcodeFormat(targetFormat)
            }
            val out = BarcodeChangeResult(
                success = true,
                message = "تم تحديث نوع الباركود للملصق إلى ${targetFormat.arabicLabel}",
                updatedCount = 1,
                appliedFormat = targetFormat,
            )
            _message.value = out.message
            onResult(out)
        }
    }

    fun exportLabelsPdf(onReady: (File) -> Unit) {
        if (_isBusy.value) return
        val items = _selectedLabels.value
        if (items.isEmpty()) {
            _message.value = "يرجى اختيار باركود واحد على الأقل"
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val result = withContext(Dispatchers.IO) {
                    container.labelPdfGenerator.generateLabelsPdf(
                        items,
                        _config.value,
                        "labels_${System.currentTimeMillis() / 1000}",
                    )
                }
                if (result.warnings.isNotEmpty()) _message.value = result.warnings.first()
                onReady(result.file)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Exception) {
                container.globalErrorMonitor.recordError(e, ScreenNames.LABEL_PRINTING, DiagnosticModules.PDF, "تصدير ملصقات الباركود PDF")
                _message.value = "تعذر تجهيز ملف الملصقات: ${e.localizedMessage ?: "خطأ"}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun exportSingleSvg(value: String, format: BarcodeFormatType, onReady: (File) -> Unit) {
        viewModelScope.launch {
            val trace = container.operationLogger.startOperation(
                screenName = ScreenNames.LABEL_PRINTING,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = "تصدير باركود SVG",
                initialStage = "إنشاء رسم المتجهات",
            )
            try {
                val file = withContext(Dispatchers.IO) {
                    val svg = BarcodeEngine.generateSvg(value, format, _config.value.labelWidthMm, _config.value.labelHeightMm, _config.value.showBarcodeValue)
                    File(container.mediaStorage.exportsDir, "barcode_${value.take(16)}.svg").apply {
                        writeText(svg, Charsets.UTF_8)
                    }
                }
                trace.succeed("تم حفظ ${file.name}")
                onReady(file)
            } catch (c: CancellationException) {
                trace.cancel("تم إلغاء تصدير SVG")
                throw c
            } catch (t: Throwable) {
                val err = container.globalErrorMonitor.recordError(t, ScreenNames.LABEL_PRINTING, DiagnosticModules.BARCODE_CAMERA, "تصدير باركود SVG", linkedOperationId = trace.operationId)
                trace.fail(t.message ?: "تعذر تصدير SVG", linkedErrorId = err.errorId)
                _message.value = "تعذر تصدير SVG: ${t.localizedMessage ?: "خطأ"}"
            }
        }
    }

    fun exportSingleHighDpiPng(value: String, format: BarcodeFormatType, dpi: Int, onReady: (File) -> Unit) {
        viewModelScope.launch {
            val trace = container.operationLogger.startOperation(
                screenName = ScreenNames.LABEL_PRINTING,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = "تصدير باركود PNG بدقة $dpi DPI",
                initialStage = "توليد صورة الباركود عالية الدقة",
            )
            try {
                val file = withContext(Dispatchers.IO) {
                    val mult = if (dpi >= 600) 2 else 1
                    val bmp = BarcodeEngine.generateHighResBitmap(value, format, 900 * mult, 340 * mult, _config.value.showBarcodeValue)
                        ?: throw IllegalStateException("تعذر توليد صورة الباركود")
                    try {
                        File(container.mediaStorage.exportsDir, "barcode_${value.take(16)}_${dpi}dpi.png").apply {
                            outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                        }
                    } finally {
                        if (!bmp.isRecycled) bmp.recycle()
                    }
                }
                trace.succeed("تم حفظ ${file.name}")
                onReady(file)
            } catch (c: CancellationException) {
                trace.cancel("تم إلغاء تصدير PNG")
                throw c
            } catch (t: Throwable) {
                val err = container.globalErrorMonitor.recordError(t, ScreenNames.LABEL_PRINTING, DiagnosticModules.BARCODE_CAMERA, "تصدير باركود PNG", linkedOperationId = trace.operationId)
                trace.fail(t.message ?: "تعذر تصدير PNG", linkedErrorId = err.errorId)
                _message.value = "تعذر تصدير PNG: ${t.localizedMessage ?: "خطأ"}"
            }
        }
    }
}
