package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material3.LinearProgressIndicator
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.entity.ReportWithDetails
import com.example.di.AppContainer
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.PageOrientation
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintHelper
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatArabicDate
import com.example.ui.components.formatCurrencyValue
import com.example.ui.components.shareFileViaProvider
import com.example.ui.viewmodel.ArchiveViewModel

@Composable
fun ArchiveScreen(
    viewModel: ArchiveViewModel,
    container: AppContainer,
    onOpenReportEditor: (Long) -> Unit,
    onOpenPdfPreview: (Long, String) -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenPdfEditor: (String) -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val isGeneratingPdf by viewModel.isGeneratingPdf.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var deleteTarget by remember { mutableStateOf<ReportWithDetails?>(null) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "التقارير والأرشيف",
                subtitle = "${state.reports.size} تقرير محفوظ",
                actions = {
                    TextButton(onClick = onOpenTemplates) {
                        Text("القوالب")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.createEmptyReport(onCreated = onOpenReportEditor) },
                modifier = Modifier.testTag("create_report_fab"),
            ) {
                Icon(Icons.Default.Add, contentDescription = "تقرير جديد فارغ")
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::setSearchQuery,
                placeholder = { Text("بحث برقم التقرير أو اسم العميل أو العنوان...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("archive_search_field"),
                shape = RoundedCornerShape(14.dp),
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !state.onlyArchived,
                    onClick = { viewModel.setOnlyArchived(false) },
                    label = { Text("جميع التقارير") },
                )
                FilterChip(
                    selected = state.onlyArchived,
                    onClick = { viewModel.setOnlyArchived(true) },
                    label = { Text("المؤرشفة فقط") },
                )
            }
            if (isGeneratingPdf) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            if (state.reports.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStateCard(
                        title = "لا توجد تقارير محفوظة",
                        description = "كل تقرير يبدأ فارغاً ويحتفظ بلقطة ثابتة (Snapshot) مستقلة عن تعديلات المنتجات",
                        icon = Icons.Default.Archive,
                        actionLabel = "إنشاء تقرير جديد",
                        onAction = { viewModel.createEmptyReport(onCreated = onOpenReportEditor) },
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.reports, key = { it.report.id }) { rep ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenReportEditor(rep.report.id) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Text(
                                                rep.report.title,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            if (rep.report.versionNumber > 1) {
                                                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(6.dp)) {
                                                    Text("V${rep.report.versionNumber}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                }
                                            }
                                            if (rep.report.isArchived) {
                                                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(6.dp)) {
                                                    Text("مؤرشف", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                }
                                            }
                                        }
                                        Text(
                                            "${rep.report.reportNumber} • ${formatArabicDate(rep.report.reportDate)} • العميل: ${rep.report.clientName.ifBlank { "—" }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    val repTotalSpec = NumberFormatEngine.resolveReportTotalSpec(
                                        rep.columns.map { it.toDomainModel() },
                                    )
                                    Text(
                                        formatCurrencyValue(rep.items.sumOf { it.item.lineTotal }, rep.report.currency, repTotalSpec),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Row {
                                        TextButton(
                                            onClick = {
                                                viewModel.saveAsNewVersion(rep.report.id, onCreated = onOpenReportEditor)
                                            },
                                            contentPadding = PaddingValues(horizontal = 6.dp),
                                        ) {
                                            Text("إصدار جديد")
                                        }
                                        TextButton(
                                            onClick = {
                                                viewModel.cloneReport(rep.report.id, asNewDraft = true, onCloned = onOpenReportEditor)
                                            },
                                            contentPadding = PaddingValues(horizontal = 6.dp),
                                        ) {
                                            Text("تقرير منه")
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            viewModel.generatePdf(rep) { file ->
                                                onOpenPdfPreview(rep.report.id, file.absolutePath)
                                            }
                                        }) {
                                            Icon(Icons.Default.PictureAsPdf, contentDescription = "معاينة PDF")
                                        }
                                        IconButton(onClick = {
                                            viewModel.generatePdf(rep) { file ->
                                                onOpenPdfEditor(file.absolutePath)
                                            }
                                        }) {
                                            Icon(Icons.Default.EditNote, contentDescription = "تحرير في محرر PDF")
                                        }
                                        IconButton(onClick = {
                                            viewModel.generatePdf(rep) { file ->
                                                shareFileViaProvider(context, file, "application/pdf", "مشاركة PDF")
                                            }
                                        }) {
                                            Icon(Icons.Default.Share, contentDescription = "مشاركة")
                                        }
                                        IconButton(
                                            enabled = !isGeneratingPdf,
                                            onClick = {
                                                viewModel.generatePdf(rep) { file ->
                                                    val res = SafePdfPrintHelper.printPdfWithActivity(
                                                        context = context,
                                                        pdfFile = file,
                                                        jobName = rep.report.title,
                                                        isLandscape = PageOrientation.fromString(rep.report.orientation) == PageOrientation.LANDSCAPE,
                                                    )
                                                    if (res is PrintDispatchResult.Error) {
                                                        viewModel.postMessage(res.message)
                                                    }
                                                }
                                            },
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = "طباعة")
                                        }
                                        IconButton(onClick = {
                                            viewModel.cloneReport(rep.report.id, asNewDraft = false, onCloned = onOpenReportEditor)
                                        }) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ التقرير")
                                        }
                                        IconButton(onClick = { deleteTarget = rep }) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف التقرير", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteTarget?.let { rep ->
        ConfirmActionDialog(
            title = "حذف التقرير",
            message = "هل أنت متأكد من حذف (${rep.report.title})؟ لن يتم حذف أي منتج من قاعدة البيانات.",
            onConfirm = {
                viewModel.deleteReport(rep.report.id)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null },
        )
    }
}
