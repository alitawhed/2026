package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.TemplateDefaults
import com.example.data.local.entity.ReportTemplateEntity
import com.example.domain.billing.FeatureAccessDecision
import com.example.domain.billing.ProFeature
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.components.shareFileViaProvider
import com.example.ui.viewmodel.TemplatesViewModel
import java.io.File

@Composable
fun TemplatesScreen(
    viewModel: TemplatesViewModel,
    onBack: (() -> Unit)? = null,
    onOpenNewReport: (Long) -> Unit,
    onOpenSubscription: () -> Unit = {},
) {
    val templates by viewModel.templates.collectAsStateWithLifecycle()
    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var previewTemplate by remember { mutableStateOf<ReportTemplateEntity?>(null) }
    var editTemplate by remember { mutableStateOf<ReportTemplateEntity?>(null) }
    var deleteConfirmTemplate by remember { mutableStateOf<ReportTemplateEntity?>(null) }
    var upgradePromptFeature by remember { mutableStateOf<ProFeature?>(null) }

    fun requirePro(feature: ProFeature, onGranted: () -> Unit) {
        when (viewModel.checkProAccess(feature)) {
            is FeatureAccessDecision.Allowed -> onGranted()
            is FeatureAccessDecision.RequiresProUpgrade -> upgradePromptFeature = feature
        }
    }

    val importTemplatePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val raw = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }
            if (!raw.isNullOrBlank()) viewModel.importTemplateJson(raw)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "مكتبة قوالب التقارير",
                subtitle = "${templates.size} قالباً بتخطيطات متباينة",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        requirePro(ProFeature.PRO_TEMPLATE_CUSTOMIZATION) {
                            importTemplatePicker.launch(arrayOf("application/json", "*/*"))
                        }
                    }) {
                        Icon(Icons.Default.FileUpload, contentDescription = "استيراد قالب JSON")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(templates, key = { it.id }) { tpl ->
                val cols = remember(tpl.columnsConfigJson) { TemplateDefaults.decodeColumns(tpl.columnsConfigJson) }
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("template_card_${tpl.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        if (tpl.isDefault) 1.5.dp else 1.dp,
                        if (tpl.isDefault) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(tpl.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    if (tpl.isDefault) {
                                        Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(6.dp)) {
                                            Text(
                                                "افتراضي",
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            )
                                        }
                                    }
                                }
                                Text(tpl.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { viewModel.setDefault(tpl.id) }) {
                                Icon(
                                    if (tpl.isDefault) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "تعيين افتراضي",
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }

                        Text(
                            "الورق: ${tpl.paperSize} (${PageOrientation.fromString(tpl.orientation).arabicLabel}) • الأعمدة (${cols.size}): ${cols.joinToString("، ") { it.title }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Button(
                                onClick = { viewModel.createReportFromTemplate(tpl.id, onOpenNewReport) },
                                modifier = Modifier.weight(1f).testTag("apply_template_${tpl.id}"),
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تطبيق في تقرير جديد")
                            }
                            IconButton(onClick = { previewTemplate = tpl }) {
                                Icon(Icons.Default.Visibility, contentDescription = "معاينة القالب")
                            }
                            IconButton(onClick = {
                                requirePro(ProFeature.PRO_TEMPLATE_CUSTOMIZATION) { editTemplate = tpl }
                            }) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل القالب")
                            }
                            IconButton(onClick = {
                                requirePro(ProFeature.PRO_TEMPLATE_CUSTOMIZATION) { viewModel.duplicateTemplate(tpl) }
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "نسخ القالب")
                            }
                            IconButton(onClick = {
                                val jsonStr = viewModel.exportTemplateJson(tpl)
                                val outFile = File(context.cacheDir, "template_${tpl.id}.json")
                                outFile.writeText(jsonStr, Charsets.UTF_8)
                                shareFileViaProvider(context, outFile, "application/json", "تصدير القالب")
                            }) {
                                Icon(Icons.Default.Share, contentDescription = "تصدير القالب")
                            }
                            if (!tpl.isBuiltIn) {
                                IconButton(onClick = { deleteConfirmTemplate = tpl }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    previewTemplate?.let { tpl ->
        val cols = TemplateDefaults.decodeColumns(tpl.columnsConfigJson)
        AlertDialog(
            onDismissRequest = { previewTemplate = null },
            title = { Text("معاينة تخطيط: ${tpl.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الورق: ${tpl.paperSize} • الاتجاه: ${PageOrientation.fromString(tpl.orientation).arabicLabel}")
                    Text("التوزيع: ${tpl.distributionMode}")
                    Text("الأعمدة:", fontWeight = FontWeight.Bold)
                    cols.forEachIndexed { idx, c ->
                        Text("${idx + 1}. ${c.title} (${c.columnType.arabicLabel}) — ارتفاع الخلية ${c.cellHeightPt.toInt()}pt")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    previewTemplate = null
                    viewModel.createReportFromTemplate(tpl.id, onOpenNewReport)
                }) { Text("استخدام القالب") }
            },
            dismissButton = {
                TextButton(onClick = { previewTemplate = null }) { Text("إغلاق") }
            },
        )
    }

    editTemplate?.let { tpl ->
        var name by remember { mutableStateOf(tpl.name) }
        var desc by remember { mutableStateOf(tpl.description) }
        var paperSize by remember { mutableStateOf(tpl.paperSize) }
        var orientation by remember { mutableStateOf(tpl.orientation) }

        AlertDialog(
            onDismissRequest = { editTemplate = null },
            title = { Text("تعديل القالب") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم القالب") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("الوصف") })
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PaperSizeType.entries.forEach { ps ->
                            FilterChip(selected = paperSize == ps.name, onClick = { paperSize = ps.name }, label = { Text(ps.name) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PageOrientation.entries.forEach { ori ->
                            FilterChip(selected = orientation == ori.name, onClick = { orientation = ori.name }, label = { Text(ori.arabicLabel) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveTemplate(tpl.copy(name = name, description = desc, paperSize = paperSize, orientation = orientation))
                    editTemplate = null
                }) { Text("حفظ") }
            },
            dismissButton = {
                TextButton(onClick = { editTemplate = null }) { Text("إلغاء") }
            },
        )
    }

    deleteConfirmTemplate?.let { tpl ->
        ConfirmActionDialog(
            title = "حذف القالب",
            message = "هل تريد حذف القالب (${tpl.name})؟",
            onConfirm = {
                viewModel.deleteTemplate(tpl)
                deleteConfirmTemplate = null
            },
            onDismiss = { deleteConfirmTemplate = null },
        )
    }

    upgradePromptFeature?.let { feature ->
        ProUpgradeDialog(
            feature = feature,
            currentStatus = entitlementState.status,
            onGoToSubscriptions = onOpenSubscription,
            onDismiss = { upgradePromptFeature = null },
        )
    }
}
