package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size as AndroidSize
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.di.AppContainer
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.BarcodeFormatType
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.components.formatCurrencyValue
import com.example.ui.theme.BrandEmeraldLight
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.example.domain.barcode.CameraAnalysisExecutorManager
import com.example.domain.diagnostics.GlobalErrorMonitor

private data class ScanHistoryEntry(
    val code: String,
    val format: BarcodeFormatType,
    val timestamp: Long,
    val matchedProductId: Long?,
    val matchedProductName: String?,
)

@kotlin.OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun BarcodeScannerScreen(
    container: AppContainer,
    targetReportId: Long = 0L,
    returnBarcodeOnly: Boolean = false,
    onBack: () -> Unit,
    onOpenProductDetail: (Long) -> Unit,
    onCreateNewProductWithBarcode: (String, String) -> Unit,
    onAddedToReportAndBack: () -> Unit,
    onReturnBarcode: (String, String) -> Unit = { _, _ -> },
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val settings by container.settingsRepository.settingsFlow.collectAsStateWithLifecycle(
        initialValue = AppSettingsEntity(),
    )
    val productsNumCfg by container.settingsRepository.productsNumericConfigFlow.collectAsStateWithLifecycle(
        initialValue = ProductsNumericConfig(),
    )
    val allProducts by container.productRepository.allProducts.collectAsStateWithLifecycle(
        initialValue = emptyList(),
    )

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            container.globalErrorMonitor.recordCustomError(
                screenName = ScreenNames.BARCODE_SCANNER,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = "طلب إذن الكاميرا لمسح الباركود",
                errorType = "CameraPermissionDenied",
                message = "تم رفض إذن الكاميرا (CAMERA) من قبل المستخدم أو النظام",
                wasHandled = true,
                severity = LogSeverity.WARNING,
            )
        }
    }
    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var cameraActive by remember { mutableStateOf(true) }
    var useFrontCamera by remember { mutableStateOf(false) }
    var cameraRestartTick by remember { mutableIntStateOf(0) }
    var cameraErrorMsg by remember { mutableStateOf<String?>(null) }

    var flashOn by remember(settings.cameraFlashDefault) { mutableStateOf(settings.cameraFlashDefault) }
    var continuousScan by remember(settings.cameraContinuousScan) { mutableStateOf(settings.cameraContinuousScan) }
    var autoAddWhenTargetReport by remember(targetReportId) { mutableStateOf(targetReportId > 0L) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var zoomRatio by remember { mutableFloatStateOf(1.0f) }
    var maxZoomRatio by remember { mutableFloatStateOf(4.0f) }
    var hasFlashUnit by remember { mutableStateOf(false) }
    var focusTapOffset by remember { mutableStateOf<Offset?>(null) }

    // Enabled barcode formats persisted in AppSettingsEntity.scannerEnabledFormats (empty = all)
    val enabledFormats = remember(settings.scannerEnabledFormats) {
        parseEnabledFormats(settings.scannerEnabledFormats)
    }
    var showFormatsDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showLinkExistingDialog by remember { mutableStateOf(false) }

    val defaultBarcodeFormat by container.barcodeService.defaultBarcodeTypeFlow.collectAsStateWithLifecycle()

    var manualInput by remember { mutableStateOf("") }
    var lastScannedCode by remember { mutableStateOf("") }
    var lastScannedFormat by remember(defaultBarcodeFormat) { mutableStateOf(defaultBarcodeFormat) }
    var lastScanTimestamp by remember { mutableLongStateOf(0L) }
    var matchedProduct by remember { mutableStateOf<ProductWithDetails?>(null) }
    var hasSearched by remember { mutableStateOf(false) }
    var addedFeedback by remember { mutableStateOf<String?>(null) }
    var linkFeedbackError by remember { mutableStateOf<String?>(null) }
    var hasReturnedBarcode by remember { mutableStateOf(false) }

    val scanHistory = remember { mutableStateListOf<ScanHistoryEntry>() }

    LaunchedEffect(focusTapOffset) {
        if (focusTapOffset != null) {
            delay(1100L)
            focusTapOffset = null
        }
    }

    fun triggerScanFeedback(beep: Boolean, vibrate: Boolean) {
        if (beep) {
            try {
                ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85).startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            } catch (_: Exception) {
            }
        }
        if (vibrate) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v?.vibrate(70)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun handleBarcodeLookup(code: String, format: BarcodeFormatType, fromCamera: Boolean) {
        // Strictly preserve leading zeros & raw digits/symbols (only trim outer whitespace)
        val clean = code.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        // Anti-duplicate cooldown (2.5 seconds for same barcode from camera)
        if (fromCamera && clean == lastScannedCode && (now - lastScanTimestamp) < 2500L) {
            return
        }
        lastScannedCode = clean
        lastScannedFormat = format
        lastScanTimestamp = now
        manualInput = clean
        addedFeedback = null
        linkFeedbackError = null

        if (fromCamera) {
            triggerScanFeedback(settings.scanBeepEnabled, settings.scanVibrateEnabled)
            if (!continuousScan) cameraActive = false
        }

        if (returnBarcodeOnly) {
            if (fromCamera) {
                if (hasReturnedBarcode) return
                hasReturnedBarcode = true
                onReturnBarcode(clean, format.name)
                return
            }
            hasSearched = true
            matchedProduct = null
            return
        }

        scope.launch {
            val found = container.productRepository.findProductByExactBarcode(clean)
            matchedProduct = found
            hasSearched = true
            scanHistory.removeAll { it.code == clean && (now - it.timestamp) < 1500L }
            scanHistory.add(
                0,
                ScanHistoryEntry(
                    code = clean,
                    format = format,
                    timestamp = now,
                    matchedProductId = found?.product?.id,
                    matchedProductName = found?.product?.name,
                ),
            )
            if (scanHistory.size > 30) {
                scanHistory.removeRange(30, scanHistory.size)
            }
            if (found != null && targetReportId > 0L && autoAddWhenTargetReport) {
                container.reportRepository.addProductToReport(targetReportId, found, clean)
                addedFeedback = "تمت إضافة (${found.product.name}) إلى التقرير"
            }
        }
    }

    LaunchedEffect(flashOn, boundCamera, hasFlashUnit) {
        if (hasFlashUnit) {
            try {
                boundCamera?.cameraControl?.enableTorch(flashOn)
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(zoomRatio, boundCamera) {
        try {
            boundCamera?.cameraControl?.setZoomRatio(zoomRatio.coerceIn(1.0f, maxZoomRatio))
        } catch (_: Exception) {
        }
    }

    Scaffold(
        topBar = {
            AppScreenTopBar(
                title = if (returnBarcodeOnly) "التقاط باركود بالكاميرا" else "ماسح الباركود والكاميرا",
                subtitle = when {
                    returnBarcodeOnly -> "وجّه الكاميرا نحو الباركود لإعادته تلقائياً"
                    targetReportId > 0L -> "مسح مباشر وإضافة ذكية إلى التقرير"
                    else -> "ML Kit + ZXing هجين متعدد الزوايا"
                },
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { showHistoryDialog = true },
                        modifier = Modifier.testTag("scanner_history_btn"),
                    ) {
                        Icon(Icons.Default.History, contentDescription = "سجل المسح")
                    }
                    IconButton(
                        onClick = { showFormatsDialog = true },
                        modifier = Modifier.testTag("scanner_formats_btn"),
                    ) {
                        Icon(Icons.Default.FilterList, contentDescription = "صيغ الباركود المدعومة")
                    }
                    if (hasCameraPermission && cameraActive) {
                        IconButton(
                            onClick = { useFrontCamera = !useFrontCamera },
                            modifier = Modifier.testTag("scanner_switch_camera_btn"),
                        ) {
                            Icon(Icons.Default.Cameraswitch, contentDescription = "تبديل الكاميرا")
                        }
                        if (hasFlashUnit) {
                            IconButton(
                                onClick = { flashOn = !flashOn },
                                modifier = Modifier.testTag("scanner_flash_btn"),
                            ) {
                                Icon(
                                    if (flashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "الفلاش",
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = { cameraActive = !cameraActive },
                        modifier = Modifier.testTag("scanner_toggle_btn"),
                    ) {
                        Icon(
                            if (cameraActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = if (cameraActive) "إيقاف الكاميرا" else "تشغيل الكاميرا",
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Camera Preview + Viewfinder Frame + Tap to Focus + Pinch Zoom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                if (!hasCameraPermission) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(16.dp),
                    ) {
                        Text("يرجى منح صلاحية الكاميرا لمسح الباركود", color = Color.White)
                        Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                            Text("تفعيل الكاميرا")
                        }
                    }
                } else if (!cameraActive) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                        Text("الكاميرا متوقفة", color = Color.White)
                        Button(onClick = {
                            cameraErrorMsg = null
                            cameraActive = true
                            cameraRestartTick++
                        }) { Text("تشغيل الكاميرا") }
                    }
                } else if (cameraErrorMsg != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(16.dp),
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFFCA5A5), modifier = Modifier.size(40.dp))
                        Text(
                            cameraErrorMsg ?: "تعذر تشغيل بث الكاميرا",
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Button(
                            onClick = {
                                cameraErrorMsg = null
                                cameraRestartTick++
                            },
                            modifier = Modifier.testTag("scanner_retry_camera_btn"),
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("إعادة تشغيل الكاميرا")
                        }
                    }
                } else {
                    CameraBarcodeAnalyzerView(
                        executorManager = container.cameraAnalysisExecutorManager,
                        errorMonitor = container.globalErrorMonitor,
                        useFrontCamera = useFrontCamera,
                        restartTick = cameraRestartTick,
                        allowedFormats = enabledFormats,
                        onBarcodeDetected = { text, fmt ->
                            handleBarcodeLookup(text, fmt, fromCamera = true)
                        },
                        onCameraBound = { camera ->
                            boundCamera = camera
                            hasFlashUnit = camera.cameraInfo.hasFlashUnit()
                            if (!hasFlashUnit) flashOn = false
                            val camMaxZoom = camera.cameraInfo.zoomState.value?.maxZoomRatio ?: 4.0f
                            maxZoomRatio = camMaxZoom.coerceIn(1.5f, 8.0f)
                            zoomRatio = zoomRatio.coerceIn(1.0f, maxZoomRatio)
                            cameraErrorMsg = null
                        },
                        onCameraError = { err ->
                            cameraErrorMsg = err
                            container.globalErrorMonitor.recordCustomError(
                                screenName = ScreenNames.BARCODE_SCANNER,
                                moduleName = DiagnosticModules.BARCODE_CAMERA,
                                operationName = "تهيئة وتشغيل كاميرا مسح الباركود",
                                errorType = "CameraInitializationException",
                                message = err,
                                wasHandled = true,
                                severity = LogSeverity.ERROR,
                            )
                        },
                        onTapFocus = { tapOffset ->
                            focusTapOffset = tapOffset
                        },
                        onPinchZoom = { scaleChange ->
                            zoomRatio = (zoomRatio * scaleChange).coerceIn(1.0f, maxZoomRatio)
                        },
                    )
                    // Scan Target Reticle + Focus Indicator Overlay
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val frameW = size.width * 0.76f
                        val frameH = size.height * 0.56f
                        val left = (size.width - frameW) / 2f
                        val top = (size.height - frameH) / 2f
                        drawRoundRect(
                            color = BrandEmeraldLight,
                            topLeft = Offset(left, top),
                            size = Size(frameW, frameH),
                            cornerRadius = CornerRadius(18f, 18f),
                            style = Stroke(width = 4f),
                        )
                        drawLine(
                            color = Color.Red.copy(alpha = 0.85f),
                            start = Offset(left + 12f, size.height / 2f),
                            end = Offset(left + frameW - 12f, size.height / 2f),
                            strokeWidth = 2.5f,
                        )
                        focusTapOffset?.let { tap ->
                            drawCircle(
                                color = Color.Yellow,
                                radius = 34f,
                                center = tap,
                                style = Stroke(width = 3f),
                            )
                        }
                    }

                    // Active format / camera status pill at top-start of preview
                    Surface(
                        color = Color.Black.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp),
                    ) {
                        Text(
                            text = if (enabledFormats.size == BarcodeFormatType.entries.size) {
                                "جميع الصيغ (12) • المس للتركيز"
                            } else {
                                "${enabledFormats.size} صيغ مفعّلة • المس للتركيز"
                            },
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }

            // Zoom Slider Bar
            if (hasCameraPermission && cameraActive && cameraErrorMsg == null && maxZoomRatio > 1.05f) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "التكبير", modifier = Modifier.size(20.dp))
                    Text(
                        String.format(Locale.US, "%.1fx", zoomRatio),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Slider(
                        value = zoomRatio,
                        onValueChange = { zoomRatio = it },
                        valueRange = 1.0f..maxZoomRatio,
                        modifier = Modifier.weight(1f).testTag("scanner_zoom_slider"),
                    )
                }
            }

            // Scan Mode & Quick Controls
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                FilterChip(
                    selected = continuousScan,
                    onClick = { continuousScan = !continuousScan },
                    label = { Text("مسح متواصل") },
                )
                if (hasFlashUnit) {
                    FilterChip(
                        selected = flashOn,
                        onClick = { flashOn = !flashOn },
                        label = { Text("الفلاش") },
                    )
                }
                AssistChip(
                    onClick = { showFormatsDialog = true },
                    leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = {
                        Text(
                            if (enabledFormats.size == BarcodeFormatType.entries.size) "كل الصيغ" else "الصيغ (${enabledFormats.size})",
                        )
                    },
                )
                if (targetReportId > 0L) {
                    FilterChip(
                        selected = autoAddWhenTargetReport,
                        onClick = { autoAddWhenTargetReport = !autoAddWhenTargetReport },
                        label = { Text(if (autoAddWhenTargetReport) "إضافة تلقائية للتقرير" else "مراجعة قبل الإضافة") },
                    )
                    OutlinedButton(onClick = onAddedToReportAndBack) {
                        Text("عودة للتقرير")
                    }
                }
            }

            // Manual Input / Paste Barcode
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = manualInput,
                    onValueChange = { manualInput = it },
                    label = { Text("إدخال أو لصق الباركود يدوياً") },
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("scanner_manual_input"),
                    trailingIcon = {
                        IconButton(onClick = {
                            clipboard.getText()?.text?.let { manualInput = it.trim() }
                        }) {
                            Icon(Icons.Default.ContentPaste, contentDescription = "لصق")
                        }
                    },
                )
                Button(
                    onClick = {
                        val resolved = BarcodeEngine.resolveCompatibleDefaultFormat(manualInput, defaultBarcodeFormat)
                        handleBarcodeLookup(manualInput, resolved, fromCamera = false)
                    },
                    modifier = Modifier.height(54.dp).testTag("scanner_manual_search_btn"),
                ) {
                    Icon(Icons.Default.Search, contentDescription = "بحث")
                }
            }

            // Scan Result Card
            if (hasSearched && returnBarcodeOnly && lastScannedCode.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("scanner_return_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("تم التقاط الباركود", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("$lastScannedCode (${lastScannedFormat.arabicLabel})", fontWeight = FontWeight.Bold)
                        Button(
                            onClick = { onReturnBarcode(lastScannedCode, lastScannedFormat.name) },
                            modifier = Modifier.fillMaxWidth().testTag("scanner_confirm_return_btn"),
                        ) {
                            Text("اعتماد هذا الباركود والمتابعة")
                        }
                    }
                }
            } else if (hasSearched) {
                val found = matchedProduct
                if (found != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("scanner_found_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ProductEntityImageBox(
                                    image = found.primaryImage,
                                    contentDescription = found.product.name,
                                    preferThumbnail = true,
                                    contentScale = ContentScale.Crop,
                                    showDiagnosticsOnError = false,
                                    modifier = Modifier.size(64.dp),
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(found.product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        "الباركود: $lastScannedCode (${lastScannedFormat.arabicLabel})",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                    if (found.barcodes.size > 1) {
                                        Text(
                                            "عدد باركودات المنتج: ${found.barcodes.size}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary,
                                        )
                                    }
                                    Text(
                                        formatCurrencyValue(found.product.basePrice, found.product.currency, productsNumCfg.priceFormat),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                            addedFeedback?.let { msg ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    Text(msg, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (targetReportId > 0L && addedFeedback == null) {
                                    FilledTonalButton(
                                        onClick = {
                                            scope.launch {
                                                container.reportRepository.addProductToReport(targetReportId, found, lastScannedCode)
                                                addedFeedback = "تمت إضافة (${found.product.name}) إلى التقرير"
                                            }
                                        },
                                        modifier = Modifier.weight(1f).testTag("scanner_manual_add_report_btn"),
                                    ) {
                                        Text("إضافة للتقرير")
                                    }
                                }
                                Button(
                                    onClick = { onOpenProductDetail(found.product.id) },
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Text("فتح تفاصيل المنتج")
                                }
                            }
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("scanner_not_found_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("لم يتم العثور على منتج بهذا الباركود", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text("القيمة الممسوحة: $lastScannedCode (${lastScannedFormat.arabicLabel})", style = MaterialTheme.typography.bodySmall)
                            linkFeedbackError?.let {
                                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            FilledTonalButton(
                                onClick = {
                                    onCreateNewProductWithBarcode(lastScannedCode, lastScannedFormat.name)
                                },
                                modifier = Modifier.fillMaxWidth().testTag("scanner_create_product_btn"),
                            ) {
                                Icon(Icons.Default.AddCircle, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("إضافة منتج جديد وتعبئة الباركود تلقائياً")
                            }
                            OutlinedButton(
                                onClick = { showLinkExistingDialog = true },
                                modifier = Modifier.fillMaxWidth().testTag("scanner_link_existing_btn"),
                            ) {
                                Icon(Icons.Default.Link, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("ربط هذا الباركود بمنتج حالي")
                            }
                        }
                    }
                }
            }

            // Recent Scan History Quick Strip
            if (scanHistory.isNotEmpty()) {
                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "آخر عمليات المسح (${scanHistory.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    TextButton(onClick = { scanHistory.clear() }) {
                        Text("مسح السجل")
                    }
                }
                val sdf = remember { SimpleDateFormat("HH:mm:ss", Locale("ar")) }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scanHistory.take(4).forEach { entry ->
                        Surface(
                            tonalElevation = 1.dp,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    handleBarcodeLookup(entry.code, entry.format, fromCamera = false)
                                },
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(entry.code, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        entry.matchedProductName ?: "غير مسجل • ${entry.format.arabicLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (entry.matchedProductName != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Text(sdf.format(Date(entry.timestamp)), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    // Supported Formats Settings Dialog
    if (showFormatsDialog) {
        var selected by remember(enabledFormats) { mutableStateOf(enabledFormats) }
        AlertDialog(
            onDismissRequest = { showFormatsDialog = false },
            title = { Text("تحديد صيغ الباركود المفعّلة") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { selected = BarcodeFormatType.entries.toSet() }) {
                            Text("تحديد الكل")
                        }
                        TextButton(
                            onClick = {
                                selected = setOf(
                                    BarcodeFormatType.EAN_13,
                                    BarcodeFormatType.EAN_8,
                                    BarcodeFormatType.UPC_A,
                                    BarcodeFormatType.CODE_128,
                                    BarcodeFormatType.QR_CODE,
                                )
                            },
                        ) {
                            Text("الشائعة فقط")
                        }
                    }
                    BarcodeFormatType.entries.forEach { fmt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selected = if (fmt in selected) {
                                        if (selected.size > 1) selected - fmt else selected
                                    } else {
                                        selected + fmt
                                    }
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = fmt in selected,
                                onCheckedChange = { checked ->
                                    selected = if (checked) {
                                        selected + fmt
                                    } else if (selected.size > 1) {
                                        selected - fmt
                                    } else {
                                        selected
                                    }
                                },
                            )
                            Text(fmt.arabicLabel, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val encoded = if (selected.size == BarcodeFormatType.entries.size) {
                        ""
                    } else {
                        selected.joinToString(",") { it.name }
                    }
                    scope.launch {
                        container.settingsRepository.saveSettings(
                            settings.copy(scannerEnabledFormats = encoded),
                        )
                    }
                    showFormatsDialog = false
                }) {
                    Text("حفظ وتطبيق")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFormatsDialog = false }) {
                    Text("إلغاء")
                }
            },
        )
    }

    // Full Scan History Dialog
    if (showHistoryDialog) {
        val sdf = remember { SimpleDateFormat("HH:mm:ss", Locale("ar")) }
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = { Text("سجل عمليات المسح (${scanHistory.size})") },
            text = {
                if (scanHistory.isEmpty()) {
                    Text("لا توجد عمليات مسح في هذه الجلسة بعد")
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(scanHistory) { entry ->
                            Surface(
                                tonalElevation = 2.dp,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showHistoryDialog = false
                                        handleBarcodeLookup(entry.code, entry.format, fromCamera = false)
                                    },
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(entry.code, fontWeight = FontWeight.Bold)
                                        Text(
                                            entry.matchedProductName ?: "غير مرتبط بمنتج • ${entry.format.arabicLabel}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (entry.matchedProductName != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    Text(sdf.format(Date(entry.timestamp)), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) { Text("إغلاق") }
            },
        )
    }

    // Link Unregistered Barcode to Existing Product Dialog
    if (showLinkExistingDialog) {
        var searchQuery by remember { mutableStateOf("") }
        val filtered = remember(allProducts, searchQuery) {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) {
                allProducts.take(40)
            } else {
                allProducts.filter { p ->
                    p.product.name.lowercase().contains(q) ||
                        p.product.internalCode.lowercase().contains(q) ||
                        p.barcodes.any { it.barcodeValue.lowercase().contains(q) }
                }.take(40)
            }
        }
        AlertDialog(
            onDismissRequest = { showLinkExistingDialog = false },
            title = { Text("ربط الباركود بمنتج حالي") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        "الباركود: $lastScannedCode",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("ابحث بالاسم أو الرقم الداخلي") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(filtered, key = { it.product.id }) { item ->
                            Surface(
                                tonalElevation = 1.dp,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch {
                                            val res = container.productRepository.addBarcodeToProduct(
                                                productId = item.product.id,
                                                barcodeValue = lastScannedCode,
                                                format = lastScannedFormat,
                                                label = "ممسوح بالكاميرا",
                                                makePrimary = false,
                                            )
                                            res.onSuccess {
                                                showLinkExistingDialog = false
                                                val refreshed = container.productRepository.findProductByExactBarcode(lastScannedCode)
                                                matchedProduct = refreshed
                                                addedFeedback = "تم ربط الباركود بالمنتج (${item.product.name})"
                                            }.onFailure { err ->
                                                linkFeedbackError = err.message ?: "تعذر ربط الباركود"
                                                showLinkExistingDialog = false
                                            }
                                        }
                                    },
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    ProductEntityImageBox(
                                        image = item.primaryImage,
                                        contentDescription = item.product.name,
                                        preferThumbnail = true,
                                        showDiagnosticsOnError = false,
                                        modifier = Modifier.size(44.dp),
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            item.product.name,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(
                                            item.primaryBarcode?.barcodeValue ?: item.product.internalCode,
                                            style = MaterialTheme.typography.labelSmall,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showLinkExistingDialog = false }) { Text("إلغاء") }
            },
        )
    }
}

@SuppressLint("RestrictedApi")
@OptIn(ExperimentalGetImage::class)
@Composable
private fun CameraBarcodeAnalyzerView(
    executorManager: CameraAnalysisExecutorManager,
    errorMonitor: GlobalErrorMonitor,
    useFrontCamera: Boolean,
    restartTick: Int,
    allowedFormats: Set<BarcodeFormatType>,
    onBarcodeDetected: (String, BarcodeFormatType) -> Unit,
    onCameraBound: (Camera) -> Unit,
    onCameraError: (String) -> Unit,
    onTapFocus: (Offset) -> Unit,
    onPinchZoom: (Float) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }
    val previewView = remember {
        PreviewView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var activeCamera by remember { mutableStateOf<Camera?>(null) }

    val mlKitScanner = remember(allowedFormats, lifecycleOwner, useFrontCamera, restartTick, executorManager) {
        val formatInts = allowedFormats.map { toMlKitFormat(it) }
        val builder = if (formatInts.isEmpty()) {
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
        } else if (formatInts.size == 1) {
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(formatInts.first())
        } else {
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(formatInts.first(), *formatInts.drop(1).toIntArray())
        }
        val options = builder
            .setExecutor(executorManager.executor)
            .build()
        BarcodeScanning.getClient(options)
    }

    val sessionHandle = remember(mlKitScanner, executorManager) {
        executorManager.newSession(mlKitScanner)
    }

    DisposableEffect(sessionHandle) {
        onDispose {
            // Defer closing ML Kit scanner until all in-flight Task callbacks finish
            sessionHandle.disposeAndCloseWhenIdle()
        }
    }

    DisposableEffect(lifecycleOwner, useFrontCamera, restartTick, sessionHandle) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        val frameProcessing = AtomicBoolean(false)
        val bindTrace = errorMonitor.operationLogger.startOperation(
            screenName = ScreenNames.BARCODE_SCANNER,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "تشغيل محلل الكاميرا والباركود",
            initialStage = "تهيئة CameraProvider",
        )
        var boundAnalysis: ImageAnalysis? = null

        val listener = Runnable {
            if (sessionHandle.isDisposed) {
                bindTrace.cancel("تمت مغادرة الشاشة قبل اكتمال تهيئة الكاميرا")
                return@Runnable
            }
            try {
                val cameraProvider = providerFuture.get()
                val selector = if (useFrontCamera) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }

                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            AndroidSize(1280, 720),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                        ),
                    )
                    .build()

                val preview = Preview.Builder()
                    .setResolutionSelector(resolutionSelector)
                    .build()
                    .also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }

                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(resolutionSelector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                boundAnalysis = analysis

                val analysisExecutor = executorManager.executor
                analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    if (sessionHandle.isDisposed || !frameProcessing.compareAndSet(false, true)) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    if (!sessionHandle.beginAsyncWork()) {
                        imageProxy.close()
                        frameProcessing.set(false)
                        return@setAnalyzer
                    }

                    var released = false
                    fun releaseFrameResources() {
                        if (!released) {
                            released = true
                            runCatching { imageProxy.close() }
                            frameProcessing.set(false)
                            sessionHandle.endAsyncWork()
                        }
                    }

                    try {
                        val rotation = imageProxy.imageInfo.rotationDegrees
                        val imgWidth = imageProxy.width
                        val imgHeight = imageProxy.height
                        val plane = imageProxy.planes.firstOrNull()
                        val rowStride = plane?.rowStride ?: imgWidth

                        // Copy tight/padded Y buffer synchronously before ImageProxy closes
                        val yBytes: ByteArray? = plane?.let { p ->
                            val buf = p.buffer
                            val duplicate = buf.duplicate()
                            duplicate.rewind()
                            ByteArray(duplicate.remaining()).also { duplicate.get(it) }
                        }

                        val mediaImage = imageProxy.image
                        if (mediaImage != null && !sessionHandle.isDisposed) {
                            val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
                            mlKitScanner.process(inputImage)
                                .addOnSuccessListener(analysisExecutor) { barcodes ->
                                    try {
                                        if (sessionHandle.isDisposed) return@addOnSuccessListener
                                        val valid = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }
                                        if (valid != null && !valid.rawValue.isNullOrBlank()) {
                                            val detectedFormat = fromMlKitFormat(valid.format)
                                            val raw = valid.rawValue!!
                                            releaseFrameResources()
                                            executorManager.postUiIfActive(sessionHandle, previewView) {
                                                onBarcodeDetected(raw, detectedFormat)
                                            }
                                        } else {
                                            val zxing = if (yBytes != null && !sessionHandle.isDisposed) {
                                                BarcodeEngine.decodeYuvFrameWithRotation(
                                                    yuvBytes = yBytes,
                                                    width = imgWidth,
                                                    height = imgHeight,
                                                    rowStride = rowStride,
                                                    rotationDegrees = rotation,
                                                    allowedFormats = allowedFormats,
                                                    tryInverted = true,
                                                )
                                            } else null
                                            releaseFrameResources()
                                            if (zxing != null && !sessionHandle.isDisposed) {
                                                executorManager.postUiIfActive(sessionHandle, previewView) {
                                                    onBarcodeDetected(zxing.text, zxing.format)
                                                }
                                            }
                                        }
                                    } finally {
                                        releaseFrameResources()
                                    }
                                }
                                .addOnFailureListener(analysisExecutor) { mlErr ->
                                    try {
                                        if (sessionHandle.isDisposed) return@addOnFailureListener
                                        val zxing = if (yBytes != null) {
                                            BarcodeEngine.decodeYuvFrameWithRotation(
                                                yuvBytes = yBytes,
                                                width = imgWidth,
                                                height = imgHeight,
                                                rowStride = rowStride,
                                                rotationDegrees = rotation,
                                                allowedFormats = allowedFormats,
                                                tryInverted = true,
                                            )
                                        } else null
                                        releaseFrameResources()
                                        if (zxing != null && !sessionHandle.isDisposed) {
                                            executorManager.postUiIfActive(sessionHandle, previewView) {
                                                onBarcodeDetected(zxing.text, zxing.format)
                                            }
                                        } else if (mlErr !is RejectedExecutionException) {
                                            // Transient frame decode failure is only logged if fatal/rejected
                                        }
                                    } finally {
                                        releaseFrameResources()
                                    }
                                }
                                .addOnCanceledListener(analysisExecutor) {
                                    releaseFrameResources()
                                }
                        } else {
                            val zxing = if (yBytes != null && !sessionHandle.isDisposed) {
                                BarcodeEngine.decodeYuvFrameWithRotation(
                                    yuvBytes = yBytes,
                                    width = imgWidth,
                                    height = imgHeight,
                                    rowStride = rowStride,
                                    rotationDegrees = rotation,
                                    allowedFormats = allowedFormats,
                                    tryInverted = true,
                                )
                            } else null
                            releaseFrameResources()
                            if (zxing != null && !sessionHandle.isDisposed) {
                                executorManager.postUiIfActive(sessionHandle, previewView) {
                                    onBarcodeDetected(zxing.text, zxing.format)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        releaseFrameResources()
                        errorMonitor.recordError(
                            throwable = e,
                            screenName = ScreenNames.BARCODE_SCANNER,
                            moduleName = DiagnosticModules.BARCODE_CAMERA,
                            operationName = "تحليل إطار الباركود",
                            wasHandled = true,
                            severity = LogSeverity.WARNING,
                        )
                    }
                }

                bindTrace.stage("ربط الكاميرا والمحلل بدورة الحياة")
                cameraProvider.unbindAll()
                val camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    analysis,
                )
                activeCamera = camera
                onCameraBound(camera)
                bindTrace.succeed("الكاميرا والمحلل جاهزان")
            } catch (e: Exception) {
                val errRec = errorMonitor.recordError(
                    throwable = e,
                    screenName = ScreenNames.BARCODE_SCANNER,
                    moduleName = DiagnosticModules.BARCODE_CAMERA,
                    operationName = "تشغيل محلل الكاميرا والباركود",
                    linkedOperationId = bindTrace.operationId,
                )
                bindTrace.fail(e.message ?: "تعذر فتح الكاميرا", errRec.errorId)
                if (!sessionHandle.isDisposed) {
                    onCameraError("تعذر فتح الكاميرا: ${e.message ?: "خطأ غير متوقع"}")
                }
            }
        }
        providerFuture.addListener(listener, mainExecutor)
        onDispose {
            sessionHandle.disposeAndCloseWhenIdle()
            runCatching { boundAnalysis?.clearAnalyzer() }
            if (providerFuture.isDone) {
                runCatching { providerFuture.get().unbindAll() }
            } else {
                providerFuture.addListener(
                    { runCatching { providerFuture.get().unbindAll() } },
                    mainExecutor,
                )
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(activeCamera) {
                detectTapGestures { offset ->
                    onTapFocus(offset)
                    val camera = activeCamera ?: return@detectTapGestures
                    try {
                        val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                        val action = FocusMeteringAction.Builder(
                            point,
                            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE,
                        ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                        camera.cameraControl.startFocusAndMetering(action)
                    } catch (_: Exception) {
                    }
                }
            }
            .pointerInput(activeCamera) {
                detectTransformGestures { _, _, zoom, _ ->
                    if (zoom != 1f) {
                        onPinchZoom(zoom)
                    }
                }
            },
    ) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
    }
}

private fun parseEnabledFormats(raw: String): Set<BarcodeFormatType> {
    if (raw.isBlank()) return BarcodeFormatType.entries.toSet()
    val parsed = raw.split(",")
        .mapNotNull { token ->
            val trimmed = token.trim()
            BarcodeFormatType.entries.firstOrNull { it.name == trimmed }
        }
        .toSet()
    return parsed.ifEmpty { BarcodeFormatType.entries.toSet() }
}

private fun toMlKitFormat(format: BarcodeFormatType): Int = when (format) {
    BarcodeFormatType.EAN_13 -> Barcode.FORMAT_EAN_13
    BarcodeFormatType.EAN_8 -> Barcode.FORMAT_EAN_8
    BarcodeFormatType.UPC_A -> Barcode.FORMAT_UPC_A
    BarcodeFormatType.UPC_E -> Barcode.FORMAT_UPC_E
    BarcodeFormatType.CODE_128 -> Barcode.FORMAT_CODE_128
    BarcodeFormatType.CODE_39 -> Barcode.FORMAT_CODE_39
    BarcodeFormatType.ITF -> Barcode.FORMAT_ITF
    BarcodeFormatType.CODABAR -> Barcode.FORMAT_CODABAR
    BarcodeFormatType.QR_CODE -> Barcode.FORMAT_QR_CODE
    BarcodeFormatType.DATA_MATRIX -> Barcode.FORMAT_DATA_MATRIX
    BarcodeFormatType.PDF_417 -> Barcode.FORMAT_PDF417
    BarcodeFormatType.AZTEC -> Barcode.FORMAT_AZTEC
}

private fun fromMlKitFormat(mlKitFormat: Int): BarcodeFormatType = when (mlKitFormat) {
    Barcode.FORMAT_EAN_13 -> BarcodeFormatType.EAN_13
    Barcode.FORMAT_EAN_8 -> BarcodeFormatType.EAN_8
    Barcode.FORMAT_UPC_A -> BarcodeFormatType.UPC_A
    Barcode.FORMAT_UPC_E -> BarcodeFormatType.UPC_E
    Barcode.FORMAT_CODE_128 -> BarcodeFormatType.CODE_128
    Barcode.FORMAT_CODE_39 -> BarcodeFormatType.CODE_39
    Barcode.FORMAT_ITF -> BarcodeFormatType.ITF
    Barcode.FORMAT_CODABAR -> BarcodeFormatType.CODABAR
    Barcode.FORMAT_QR_CODE -> BarcodeFormatType.QR_CODE
    Barcode.FORMAT_DATA_MATRIX -> BarcodeFormatType.DATA_MATRIX
    Barcode.FORMAT_PDF417 -> BarcodeFormatType.PDF_417
    Barcode.FORMAT_AZTEC -> BarcodeFormatType.AZTEC
    else -> BarcodeFormatType.CODE_128
}
