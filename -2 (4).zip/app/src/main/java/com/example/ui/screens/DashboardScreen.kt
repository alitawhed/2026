package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.HideImage
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.domain.formatting.NumberFormatEngine
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatArabicDate
import com.example.ui.components.formatCurrencyValue
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.DashboardViewModel
import java.io.File
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onAddProduct: () -> Unit,
    onImportExcel: () -> Unit,
    onOpenImageManager: () -> Unit,
    onCreateReport: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenInventory: () -> Unit,
    onOpenPdfEditor: () -> Unit,
    onOpenProducts: (String) -> Unit,
    onOpenProductDetail: (Long) -> Unit,
    onOpenReportEditor: (Long) -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenLabels: () -> Unit,
    onOpenArchive: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenAccount: () -> Unit = {},
    onOpenSubscription: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val stats = state.stats
    val settings = state.settings

    LaunchedEffect(Unit) {
        viewModel.refreshStorageUsage()
    }

    val storageText = rememberStorageLabel(stats.usedStorageBytes)
    val backupStatusText = if (stats.lastBackupTimestamp != null) {
        formatArabicDate(stats.lastBackupTimestamp)
    } else {
        "لم يُنشأ بعد"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)),
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
        // Executive Welcome & Identity Hero Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(BrandNavy, Color(0xFF1E3A5F), BrandEmerald.copy(alpha = 0.85f)),
                        ),
                    )
                    .padding(20.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = settings.appName,
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "مرحباً بك • ${settings.companyName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.82f),
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(
                                onClick = onOpenAccount,
                                modifier = Modifier.testTag("dashboard_account_btn"),
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = "الحساب وتسجيل الدخول", tint = Color.White)
                            }
                            IconButton(
                                onClick = onOpenAbout,
                                modifier = Modifier.testTag("dashboard_about_btn"),
                            ) {
                                Icon(Icons.Default.Info, contentDescription = "حول التطبيق", tint = Color.White)
                            }
                            IconButton(
                                onClick = onOpenBackup,
                                modifier = Modifier.testTag("dashboard_backup_btn"),
                            ) {
                                Icon(Icons.Default.Backup, contentDescription = "النسخ الاحتياطي", tint = Color.White)
                            }
                            IconButton(
                                onClick = onOpenSettings,
                                modifier = Modifier.testTag("dashboard_settings_btn"),
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = Color.White)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable(onClick = onOpenAbout),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    text = "حول التطبيق والدعم",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        Surface(
                            color = Color.White.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .clickable(onClick = onOpenSubscription)
                                .testTag("dashboard_subscription_btn"),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = "الباقات والاشتراك",
                                    tint = Color(0xFFFDE68A),
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    text = "الاشتراك Pro",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }

        // All 8 Core Quick Action Shortcuts + Labels & Templates
        item {
            Text(
                text = "اختصارات العمليات السريعة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 4,
            ) {
                QuickShortcutCard(
                    title = "إضافة منتج",
                    icon = Icons.Default.AddBox,
                    tint = BrandEmerald,
                    modifier = Modifier.weight(1f).testTag("shortcut_add_product"),
                    onClick = onAddProduct,
                )
                QuickShortcutCard(
                    title = "استيراد Excel",
                    icon = Icons.Default.TableView,
                    tint = StatusInfo,
                    modifier = Modifier.weight(1f).testTag("shortcut_import_excel"),
                    onClick = onImportExcel,
                )
                QuickShortcutCard(
                    title = "إدارة الصور",
                    icon = Icons.Default.PhotoLibrary,
                    tint = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f).testTag("shortcut_image_manager"),
                    onClick = onOpenImageManager,
                )
                QuickShortcutCard(
                    title = "مسح باركود",
                    icon = Icons.Default.QrCodeScanner,
                    tint = BrandAmber,
                    modifier = Modifier.weight(1f).testTag("shortcut_scan_barcode"),
                    onClick = onOpenScanner,
                )
                QuickShortcutCard(
                    title = "إنشاء تقرير",
                    icon = Icons.AutoMirrored.Filled.NoteAdd,
                    tint = BrandNavy,
                    modifier = Modifier.weight(1f).testTag("shortcut_create_report"),
                    onClick = onCreateReport,
                )
                QuickShortcutCard(
                    title = "محرر PDF",
                    icon = Icons.Default.EditNote,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.weight(1f).testTag("shortcut_pdf_editor"),
                    onClick = onOpenPdfEditor,
                )
                QuickShortcutCard(
                    title = "الأرشيف",
                    icon = Icons.Default.Archive,
                    tint = StatusSuccess,
                    modifier = Modifier.weight(1f).testTag("shortcut_archive"),
                    onClick = onOpenArchive,
                )
                QuickShortcutCard(
                    title = "نسخ احتياطي",
                    icon = Icons.Default.Backup,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f).testTag("shortcut_backup"),
                    onClick = onOpenBackup,
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                FilledTonalButton(
                    onClick = onOpenInventory,
                    modifier = Modifier.weight(1f).testTag("shortcut_inventory"),
                ) {
                    Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("الجرد بالباركود")
                }
                FilledTonalButton(
                    onClick = onOpenLabels,
                    modifier = Modifier.weight(1f).testTag("shortcut_labels"),
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("ملصقات الباركود")
                }
            }
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(
                onClick = onOpenTemplates,
                modifier = Modifier.fillMaxWidth().testTag("shortcut_templates"),
            ) {
                Icon(Icons.AutoMirrored.Filled.LibraryBooks, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("مكتبة القوالب")
            }
        }

        // All 12 Live Database & Storage KPIs
        item {
            Text(
                text = "إحصائيات قاعدة البيانات المباشرة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "إجمالي المنتجات",
                        value = stats.totalProducts.toString(),
                        icon = Icons.Default.Inventory2,
                        accent = BrandEmerald,
                        modifier = Modifier.weight(1f).testTag("kpi_total_products"),
                        onClick = { onOpenProducts("ALL") },
                    )
                    StatKpiCard(
                        title = "إجمالي الباركودات",
                        value = stats.totalBarcodes.toString(),
                        icon = Icons.Default.QrCode2,
                        accent = StatusInfo,
                        modifier = Modifier.weight(1f).testTag("kpi_total_barcodes"),
                        onClick = { onOpenProducts("ALL") },
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "متعددة الباركودات",
                        value = stats.productsWithMultipleBarcodes.toString(),
                        icon = Icons.Default.Layers,
                        accent = BrandAmber,
                        modifier = Modifier.weight(1f).testTag("kpi_multi_barcode"),
                        onClick = { onOpenProducts("MULTI_BARCODE") },
                    )
                    StatKpiCard(
                        title = "إجمالي الصور",
                        value = stats.totalImages.toString(),
                        icon = Icons.Default.PhotoLibrary,
                        accent = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f).testTag("kpi_total_images"),
                        onClick = onOpenImageManager,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "منتجات بدون صور",
                        value = stats.productsWithoutImages.toString(),
                        icon = Icons.Default.HideImage,
                        accent = StatusWarning,
                        modifier = Modifier.weight(1f).testTag("kpi_no_images"),
                        onClick = { onOpenProducts("NO_IMAGES") },
                    )
                    StatKpiCard(
                        title = "متعددة الصور",
                        value = stats.multiImageProducts.toString(),
                        icon = Icons.Default.Collections,
                        accent = BrandEmerald,
                        modifier = Modifier.weight(1f).testTag("kpi_multi_image"),
                        onClick = onOpenImageManager,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "إجمالي التقارير",
                        value = stats.totalReports.toString(),
                        icon = Icons.Default.Description,
                        accent = BrandNavy,
                        modifier = Modifier.weight(1f).testTag("kpi_total_reports"),
                        onClick = onOpenArchive,
                    )
                    StatKpiCard(
                        title = "تقارير اليوم",
                        value = stats.todaysReports.toString(),
                        icon = Icons.Default.Today,
                        accent = StatusInfo,
                        modifier = Modifier.weight(1f).testTag("kpi_todays_reports"),
                        onClick = onOpenArchive,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "التقارير المؤرشفة",
                        value = stats.archivedReports.toString(),
                        icon = Icons.Default.Archive,
                        accent = StatusSuccess,
                        modifier = Modifier.weight(1f).testTag("kpi_archived_reports"),
                        onClick = onOpenArchive,
                    )
                    StatKpiCard(
                        title = "التقارير المحفوظة",
                        value = stats.savedReports.toString(),
                        icon = Icons.Default.Save,
                        accent = BrandEmerald,
                        modifier = Modifier.weight(1f).testTag("kpi_saved_reports"),
                        onClick = onOpenArchive,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatKpiCard(
                        title = "آخر نسخ احتياطي",
                        value = backupStatusText,
                        icon = Icons.Default.Backup,
                        accent = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f).testTag("kpi_backup_status"),
                        onClick = onOpenBackup,
                        compactValue = true,
                    )
                    StatKpiCard(
                        title = "مساحة التخزين",
                        value = storageText,
                        icon = Icons.Default.Storage,
                        accent = BrandNavy,
                        modifier = Modifier.weight(1f).testTag("kpi_storage_usage"),
                        onClick = onOpenImageManager,
                        compactValue = true,
                    )
                }
            }
        }

        // Recent Reports
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "آخر التقارير المنشأة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                TextButton(onClick = onOpenArchive) {
                    Text("عرض الكل")
                }
            }
        }

        if (state.recentReports.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "لا توجد تقارير بعد",
                    description = "أنشئ أول تقرير تجاري فارغ واختر المنتجات والأعمدة والقالب المناسب",
                    icon = Icons.Default.Description,
                    actionLabel = "إنشاء تقرير جديد",
                    onAction = onCreateReport,
                )
            }
        } else {
            items(state.recentReports, key = { "rep_${it.report.id}" }) { r ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenReportEditor(r.report.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = r.report.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "${r.report.reportNumber} • ${r.items.size} صنف • ${formatArabicDate(r.report.reportDate)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        val repTotalSpec = NumberFormatEngine.resolveReportTotalSpec(
                            r.columns.map { it.toDomainModel() },
                        )
                        Text(
                            text = formatCurrencyValue(r.items.sumOf { it.item.lineTotal }, r.report.currency, repTotalSpec),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }

        // Recent Products
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "آخر المنتجات المضافة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                TextButton(onClick = { onOpenProducts("ALL") }) {
                    Text("إدارة المنتجات")
                }
            }
        }

        if (state.recentProducts.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "قاعدة المنتجات فارغة",
                    description = "أضف منتجاتك يدوياً، أو عبر الماسح الضوئي، أو باستيراد ملف Excel / CSV",
                    icon = Icons.Default.Inventory2,
                    actionLabel = "إضافة منتج الآن",
                    onAction = onAddProduct,
                )
            }
        } else {
            items(state.recentProducts, key = { "prd_${it.product.id}" }) { p ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenProductDetail(p.product.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        com.example.ui.components.ProductEntityImageBox(
                            image = p.primaryImage,
                            contentDescription = p.product.name,
                            preferThumbnail = true,
                            shape = RoundedCornerShape(10.dp),
                            contentScale = ContentScale.Crop,
                            showDiagnosticsOnError = false,
                            modifier = Modifier.size(48.dp),
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = p.product.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "باركود: ${p.primaryBarcode?.barcodeValue ?: "بدون"} (${p.barcodes.size}) • صور (${p.images.size})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(
                            text = formatCurrencyValue(p.product.basePrice, p.product.currency, state.productsNumericConfig.priceFormat),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

private fun rememberStorageLabel(bytes: Long): String {
    if (bytes <= 0L) return "0 KB"
    val kb = bytes / 1024f
    return if (kb < 1024f) {
        String.format(Locale.US, "%.0f KB", kb)
    } else {
        String.format(Locale.US, "%.2f MB", kb / 1024f)
    }
}

@Composable
private fun QuickShortcutCard(
    title: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun StatKpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    compactValue: Boolean = false,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = value,
                    style = if (compactValue) MaterialTheme.typography.titleSmall else MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = accent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(20.dp))
            }
        }
    }
}
