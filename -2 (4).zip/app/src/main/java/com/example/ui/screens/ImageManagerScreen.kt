package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.viewmodel.ProductsViewModel

@Composable
fun ImageManagerScreen(
    viewModel: ProductsViewModel,
    onBack: () -> Unit,
    onOpenProductDetail: (Long) -> Unit,
    onOpenImageEditor: (Long) -> Unit,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val diagnosticReport by viewModel.imageDiagnosticReport.collectAsStateWithLifecycle()
    val isRepairing by viewModel.isRepairingImages.collectAsStateWithLifecycle()
    val failedUrlDownloads by viewModel.pendingOrFailedImageDownloads.collectAsStateWithLifecycle()
    val isRetryingUrlDownloads by viewModel.isRetryingImageDownloads.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.runImageAudit()
    }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    var filterTab by remember { mutableIntStateOf(0) } // 0: All with images, 1: Multi-image, 2: Missing images
    var searchQuery by remember { mutableStateOf("") }
    var targetProductForPicker by remember { mutableStateOf(0L) }
    var isGridMode by remember { mutableStateOf(false) }
    var selectedProductFilterId by remember { mutableStateOf<Long?>(null) }
    var productFilterMenuOpen by remember { mutableStateOf(false) }
    var previewTarget by remember { mutableStateOf<Pair<ProductWithDetails, Int>?>(null) }
    var deleteConfirmTarget by remember { mutableStateOf<Pair<ProductWithDetails, ProductImageEntity>?>(null) }

    val multiPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10),
    ) { uris ->
        if (uris.isNotEmpty() && targetProductForPicker > 0L) {
            viewModel.addImagesFromUris(targetProductForPicker, uris)
        }
    }

    val filteredProducts = remember(state.products, filterTab, searchQuery, selectedProductFilterId) {
        val q = searchQuery.trim()
        state.products.filter { item ->
            val matchProductFilter = selectedProductFilterId == null || item.product.id == selectedProductFilterId
            val matchTab = when (filterTab) {
                0 -> item.images.isNotEmpty()
                1 -> item.images.size > 1
                else -> item.images.isEmpty()
            }
            val matchQuery = if (q.isEmpty()) true else {
                item.product.name.contains(q, true) ||
                    item.product.internalCode.contains(q, true) ||
                    item.barcodes.any { it.barcodeValue.contains(q, true) }
            }
            matchProductFilter && matchTab && matchQuery
        }
    }

    val totalImages = state.products.sumOf { it.images.size }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "إدارة الصور والمعرض",
                subtitle = "$totalImages صورة محفوظة • ${state.products.count { it.images.isEmpty() }} منتج بدون صور",
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { isGridMode = !isGridMode },
                        modifier = Modifier.testTag("image_manager_view_toggle"),
                    ) {
                        Icon(
                            if (isGridMode) Icons.AutoMirrored.Filled.FormatListBulleted else Icons.Default.GridView,
                            contentDescription = if (isGridMode) "عرض قائمة" else "عرض شبكة",
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث في صور المنتجات بالاسم أو الباركود...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("image_manager_search"),
                shape = RoundedCornerShape(14.dp),
            )

            // Automated Image Database Diagnostic & Safe Repair Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.HealthAndSafety, null, tint = MaterialTheme.colorScheme.primary)
                            Text("فحص وتشخيص صور القاعدة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        if (isRepairing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        }
                    }
                    diagnosticReport?.let { rep ->
                        Text(
                            "الإجمالي: ${rep.totalImageRecords}  •  سليمة: ${rep.loadableCount}  •  مفقودة/تالفة: ${rep.missingFilesCount + rep.corruptedCount}  •  مصغرات ناقصة: ${rep.missingThumbnailCount}",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (rep.missingFilesCount + rep.corruptedCount > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            enabled = !isRepairing,
                            onClick = { viewModel.runImageAudit() },
                            modifier = Modifier.weight(1f).testTag("image_audit_btn"),
                        ) {
                            Text("إعادة الفحص")
                        }
                        Button(
                            enabled = !isRepairing,
                            onClick = { viewModel.repairBrokenImages(createBackupFirst = true) },
                            modifier = Modifier.weight(1f).testTag("image_repair_btn"),
                        ) {
                            Icon(Icons.Default.Build, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إصلاح آمن")
                        }
                    }
                }
            }

            if (failedUrlDownloads.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.BrokenImage, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Text(
                                    "تنزيلات صور Excel الفاشلة/المعلقة (${failedUrlDownloads.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            if (isRetryingUrlDownloads) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            }
                        }
                        failedUrlDownloads.take(4).forEach { dl ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f).clickable { onOpenProductDetail(dl.productId) },
                                ) {
                                    Text(
                                        "${dl.productName} (#${dl.productId})",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        dl.failureReason.ifBlank { dl.sourceUrl },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                IconButton(
                                    enabled = !isRetryingUrlDownloads,
                                    onClick = { viewModel.retryFailedUrlImageDownloads(listOf(dl.id)) },
                                    modifier = Modifier.size(32.dp),
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "إعادة تنزيل الصورة", modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    enabled = !isRetryingUrlDownloads,
                                    onClick = { viewModel.dismissFailedImageDownload(dl.id) },
                                    modifier = Modifier.size(32.dp),
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "تجاهل السجل", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                        if (failedUrlDownloads.size > 4) {
                            Text(
                                "+ ${failedUrlDownloads.size - 4} سجل إضافي جاهز لإعادة التنزيل",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Button(
                            enabled = !isRetryingUrlDownloads,
                            onClick = { viewModel.retryFailedUrlImageDownloads() },
                            modifier = Modifier.fillMaxWidth().testTag("image_manager_retry_failed_btn"),
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إعادة تحميل الصور الفاشلة")
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    val selectedName = state.products.firstOrNull { it.product.id == selectedProductFilterId }?.product?.name
                    AssistChip(
                        onClick = { productFilterMenuOpen = true },
                        leadingIcon = { Icon(Icons.Default.FilterList, null, Modifier.size(16.dp)) },
                        label = { Text(selectedName ?: "كل المنتجات") },
                    )
                    DropdownMenu(expanded = productFilterMenuOpen, onDismissRequest = { productFilterMenuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("جميع المنتجات") },
                            onClick = {
                                selectedProductFilterId = null
                                productFilterMenuOpen = false
                            },
                        )
                        state.products.take(40).forEach { prod ->
                            DropdownMenuItem(
                                text = { Text("${prod.product.name} (${prod.images.size})") },
                                onClick = {
                                    selectedProductFilterId = prod.product.id
                                    productFilterMenuOpen = false
                                },
                            )
                        }
                    }
                }
                FilterChip(
                    selected = filterTab == 0,
                    onClick = { filterTab = 0 },
                    label = { Text("المنتجات المصورة (${state.products.count { it.images.isNotEmpty() }})") },
                )
                FilterChip(
                    selected = filterTab == 1,
                    onClick = { filterTab = 1 },
                    label = { Text("متعددة الصور (${state.products.count { it.images.size > 1 }})") },
                )
                FilterChip(
                    selected = filterTab == 2,
                    onClick = { filterTab = 2 },
                    label = { Text("بدون صور (${state.products.count { it.images.isEmpty() }})") },
                )
            }

            if (filteredProducts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStateCard(
                        title = "لا توجد نتائج مطابقة",
                        description = "أضف صوراً للمنتجات أو بدّل التبويب لعرض المنتجات الأخرى",
                        icon = Icons.Default.Collections,
                    )
                }
            } else if (isGridMode && filterTab != 2) {
                val flatGallery = remember(filteredProducts) {
                    filteredProducts.flatMap { prod ->
                        prod.images.sortedBy { it.sortOrder }.mapIndexed { idx, img -> Triple(prod, img, idx) }
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    gridItems(flatGallery, key = { (_, img, _) -> img.id }) { (prod, img, idx) ->
                        Card(
                            border = BorderStroke(
                                if (img.isPrimary) 2.dp else 1.dp,
                                if (img.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            ),
                        ) {
                            Column {
                                Box(modifier = Modifier.fillMaxWidth().aspectRatio(1.1f)) {
                                    ProductEntityImageBox(
                                        image = img,
                                        contentDescription = prod.product.name,
                                        preferThumbnail = true,
                                        contentScale = ContentScale.Crop,
                                        showDiagnosticsOnError = true,
                                        onClick = { previewTarget = prod to idx },
                                        modifier = Modifier.fillMaxSize(),
                                    )
                                    if (img.isPrimary) {
                                        Surface(color = MaterialTheme.colorScheme.primary) {
                                            Text(
                                                "رئيسية",
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            )
                                        }
                                    }
                                }
                                Text(
                                    prod.product.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp).clickable { onOpenProductDetail(prod.product.id) },
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    IconButton(onClick = { viewModel.setPrimaryImage(prod.product.id, img.id) }, modifier = Modifier.size(32.dp)) {
                                        Icon(if (img.isPrimary) Icons.Default.Star else Icons.Default.StarBorder, contentDescription = "تعيين رئيسية", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { onOpenImageEditor(img.id) }, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Default.Edit, contentDescription = "تحرير", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { deleteConfirmTarget = prod to img }, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(filteredProducts, key = { it.product.id }) { prod ->
                        val ordered = prod.images.sortedBy { it.sortOrder }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(
                                        modifier = Modifier.weight(1f).clickable { onOpenProductDetail(prod.product.id) },
                                    ) {
                                        Text(
                                            prod.product.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(
                                            "${ordered.size} صورة • ${prod.primaryBarcode?.barcodeValue ?: prod.product.internalCode}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    FilledTonalButton(
                                        onClick = {
                                            targetProductForPicker = prod.product.id
                                            multiPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        },
                                    ) {
                                        Icon(Icons.Default.AddPhotoAlternate, null, Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("إضافة صور")
                                    }
                                }

                                if (ordered.isNotEmpty()) {
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(ordered.size, key = { idx -> ordered[idx].id }) { idx ->
                                            val img = ordered[idx]
                                            Card(
                                                border = BorderStroke(
                                                    if (img.isPrimary) 2.dp else 1.dp,
                                                    if (img.isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                ),
                                            ) {
                                                Column(modifier = Modifier.width(126.dp)) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(100.dp),
                                                    ) {
                                                        ProductEntityImageBox(
                                                            image = img,
                                                            contentDescription = prod.product.name,
                                                            preferThumbnail = true,
                                                            shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                                                            contentScale = ContentScale.Crop,
                                                            showDiagnosticsOnError = true,
                                                            onClick = { previewTarget = prod to idx },
                                                            modifier = Modifier.fillMaxSize(),
                                                        )
                                                        if (img.isPrimary) {
                                                            Surface(color = MaterialTheme.colorScheme.primary) {
                                                                Text(
                                                                    "رئيسية",
                                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                                )
                                                            }
                                                        }
                                                    }
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth().padding(2.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                    ) {
                                                        IconButton(onClick = { viewModel.setPrimaryImage(prod.product.id, img.id) }, modifier = Modifier.size(30.dp)) {
                                                            Icon(
                                                                if (img.isPrimary) Icons.Default.Star else Icons.Default.StarBorder,
                                                                contentDescription = "تعيين رئيسية",
                                                                modifier = Modifier.size(16.dp),
                                                            )
                                                        }
                                                        IconButton(onClick = { onOpenImageEditor(img.id) }, modifier = Modifier.size(30.dp)) {
                                                            Icon(Icons.Default.Edit, contentDescription = "تحرير الصورة", modifier = Modifier.size(16.dp))
                                                        }
                                                        IconButton(onClick = { deleteConfirmTarget = prod to img }, modifier = Modifier.size(30.dp)) {
                                                            Icon(Icons.Default.Delete, contentDescription = "حذف الصورة", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    previewTarget?.let { (prod, startIdx) ->
        val galleryImages = prod.images.sortedBy { it.sortOrder }
        if (galleryImages.isNotEmpty()) {
            val pagerState = rememberPagerState(
                initialPage = startIdx.coerceIn(0, galleryImages.lastIndex),
                pageCount = { galleryImages.size },
            )
            var zoom by remember { mutableFloatStateOf(1f) }
            val currentImg = galleryImages.getOrNull(pagerState.currentPage)
            AlertDialog(
                onDismissRequest = { previewTarget = null },
                title = { Text("${prod.product.name} (${pagerState.currentPage + 1}/${galleryImages.size})") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .clip(RoundedCornerShape(12.dp)),
                        ) { pIdx ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(pIdx) {
                                        detectTransformGestures { _, _, scaleChange, _ ->
                                            zoom = (zoom * scaleChange).coerceIn(1f, 4f)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                ProductEntityImageBox(
                                    image = galleryImages[pIdx],
                                    contentDescription = prod.product.name,
                                    preferThumbnail = false,
                                    contentScale = ContentScale.Fit,
                                    showDiagnosticsOnError = true,
                                    modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = zoom, scaleY = zoom),
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val id = currentImg?.id
                        previewTarget = null
                        if (id != null) onOpenImageEditor(id)
                    }) {
                        Text("تحرير الصورة")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { previewTarget = null }) { Text("إغلاق") }
                },
            )
        }
    }

    deleteConfirmTarget?.let { (prod, img) ->
        ConfirmActionDialog(
            title = "حذف الصورة",
            message = "هل أنت متأكد من حذف هذه الصورة من المنتج (${prod.product.name})؟",
            onConfirm = {
                viewModel.deleteImage(prod.product.id, img)
                deleteConfirmTarget = null
            },
            onDismiss = { deleteConfirmTarget = null },
        )
    }
}
