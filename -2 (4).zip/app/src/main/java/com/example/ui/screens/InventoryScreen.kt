package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.repository.InventoryScanLookupResult
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeFormatChangeScope
import com.example.domain.billing.FeatureAccessDecision
import com.example.domain.billing.ProFeature
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventoryItemStatus
import com.example.domain.model.InventorySessionStatus
import com.example.ui.components.AppScreenTopBar
import com.example.ui.components.BarcodeFormatChangeDialog
import com.example.ui.components.CachedBarcodeImage
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InventoryColumnsAndPrintSheet
import com.example.ui.components.InventoryItemImageBox
import com.example.ui.components.InventoryLiveTableView
import com.example.ui.components.InventoryProductSearchDialog
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.components.ProductEntityImageBox
import com.example.ui.components.formatArabicDateTime
import com.example.ui.components.openFileViaProvider
import com.example.ui.components.shareFileViaProvider
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.DuplicatePromptStep
import com.example.ui.viewmodel.InventoryListFilter
import com.example.ui.viewmodel.InventoryViewMode
import com.example.ui.viewmodel.InventoryViewModel
import com.example.ui.viewmodel.parseInventoryDecimal
import java.util.Locale

@Composable
fun InventoryScreen(
    viewModel: InventoryViewModel,
    scannedBarcodeResult: Pair<String, String>? = null,
    onConsumeScannedBarcode: () -> Unit = {},
    createdProductId: Long? = null,
    onConsumeCreatedProductId: () -> Unit = {},
    onBack: () -> Unit,
    onLaunchBarcodeCamera: () -> Unit,
    onOpenProductDetail: (Long) -> Unit,
    onCreateNewProductWithBarcode: (String, String) -> Unit,
    onCreateNewProductFromSearch: (String) -> Unit = { _ -> },
    onOpenPdfPreview: (inventorySessionId: Long, pdfPath: String) -> Unit = { _, _ -> },
    onOpenSubscription: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val defaultBarcodeType by viewModel.defaultBarcodeType.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val qtyFocusRequester = remember { FocusRequester() }

    var showNewSessionDialog by remember { mutableStateOf(false) }
    var showEditSessionDialog by remember { mutableStateOf(false) }
    var showSessionMenu by remember { mutableStateOf(false) }
    var showDeleteSessionConfirm by remember { mutableStateOf(false) }
    var showColumnsAndPrintSheet by remember { mutableStateOf(false) }
    var showProductSearchDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<InventoryCountItemEntity?>(null) }
    var deletingItem by remember { mutableStateOf<InventoryCountItemEntity?>(null) }
    var formatChangeInvItem by remember { mutableStateOf<InventoryCountItemEntity?>(null) }
    var showSessionBarcodeFormatDialog by remember { mutableStateOf(false) }
    var showPendingBarcodeFormatDialog by remember { mutableStateOf(false) }
    var upgradePromptFeature by remember { mutableStateOf<ProFeature?>(null) }

    fun requirePro(feature: ProFeature, onGranted: () -> Unit) {
        when (viewModel.checkProFeature(feature)) {
            is FeatureAccessDecision.Allowed -> onGranted()
            is FeatureAccessDecision.RequiresProUpgrade -> upgradePromptFeature = feature
        }
    }

    LaunchedEffect(scannedBarcodeResult) {
        if (scannedBarcodeResult != null) {
            val (code, fmt) = scannedBarcodeResult
            viewModel.lookupBarcode(code, fmt)
            onConsumeScannedBarcode()
        }
    }

    LaunchedEffect(createdProductId) {
        val pid = createdProductId
        if (pid != null && pid > 0L) {
            showProductSearchDialog = false
            viewModel.onNewProductCreatedFromEditor(pid)
            onConsumeCreatedProductId()
        }
    }

    LaunchedEffect(state.pendingScanLookup) {
        if (state.pendingScanLookup != null) {
            try {
                qtyFocusRequester.requestFocus()
            } catch (_: Exception) {
                // Ignore if field isn't attached yet
            }
        }
    }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    val activeSession = state.activeSession
    val sessionStatus = activeSession?.let { InventorySessionStatus.fromString(it.session.status) }
    val isSessionOpen = sessionStatus == InventorySessionStatus.OPEN

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            AppScreenTopBar(
                title = "كشف الجرد بالباركود",
                subtitle = activeSession?.let {
                    "${InventoryColumnDefaults.sheetNumberForSession(it.session.id)} • ${it.session.title}"
                } ?: "إعداد وطباعة كشوف كميات الجرد",
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { showColumnsAndPrintSheet = true },
                        modifier = Modifier.testTag("inventory_columns_panel_btn"),
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "تخصيص الأعمدة والطباعة")
                    }
                    IconButton(
                        onClick = { showNewSessionDialog = true },
                        modifier = Modifier.testTag("inventory_new_session_btn"),
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "كشف جرد جديد")
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("inventory_main_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.isBusy) {
                item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
            }

            // 1. Count Sheet Header & Session Controls
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        if (activeSession == null) {
                            EmptyStateCard(
                                title = "لا توجد كشوف جرد بعد",
                                description = "أنشئ كشف جرد جديداً لمسح باركودات المنتجات وتسجيل الكميات الفعلية وتصديرها أو طباعتها.",
                                icon = Icons.AutoMirrored.Filled.FactCheck,
                                actionLabel = "إنشاء كشف جرد جديد",
                                onAction = { showNewSessionDialog = true },
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { showSessionMenu = true },
                                        modifier = Modifier.fillMaxWidth().testTag("inventory_session_selector"),
                                    ) {
                                        Text(
                                            text = "${InventoryColumnDefaults.sheetNumberForSession(activeSession.session.id)} • ${activeSession.session.title} (${state.sessions.size})",
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    DropdownMenu(expanded = showSessionMenu, onDismissRequest = { showSessionMenu = false }) {
                                        state.sessions.forEach { s ->
                                            val stLabel = if (s.session.status == InventorySessionStatus.OPEN.name) "مفتوح" else "مغلق"
                                            DropdownMenuItem(
                                                text = {
                                                    Text("${InventoryColumnDefaults.sheetNumberForSession(s.session.id)} • ${s.session.title} — $stLabel (${s.items.size} بند)")
                                                },
                                                onClick = {
                                                    viewModel.selectSession(s.session.id)
                                                    showSessionMenu = false
                                                },
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                val badgeColor = if (isSessionOpen) BrandEmerald else StatusWarning
                                Surface(
                                    color = badgeColor.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(99.dp),
                                ) {
                                    Text(
                                        text = if (isSessionOpen) "مفتوح للإدخال" else "مغلق",
                                        color = badgeColor,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    )
                                }
                            }

                            val items = activeSession.sortedItems
                            val distinctProducts = items.map { it.productId ?: it.scannedBarcode }.distinct().size
                            val totalQty = items.sumOf { it.countedQty }
                            val invQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                state.inventoryConfig.columns,
                                "quantity",
                            )
                            val invFactorSpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                state.inventoryConfig.columns,
                                "conversion_factor",
                            )

                            Surface(
                                color = StatusInfo.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    text = "كشف كميات فقط — لا يُجري قيوداً محاسبية ولا يعدّل أرصدة المنتجات المسجلة.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusInfo,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }

                            Text(
                                text = "التاريخ: ${formatArabicDateTime(activeSession.session.sessionDate)}  •  منتجات مختلفة: $distinctProducts  •  عدد السطور: ${items.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = "مجموع الكميات الفعلية المدخلة: ${NumberFormatEngine.formatDouble(totalQty, invQtySpec)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            if (activeSession.session.notes.isNotBlank()) {
                                Text(
                                    text = "ملاحظات الكشف: ${activeSession.session.notes}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }

                            // Print, Preview, Export & Column Customization Action Bar
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Button(
                                    enabled = !state.isBusy,
                                    onClick = {
                                        viewModel.generatePreviewPdf { sid, path ->
                                            onOpenPdfPreview(sid, path)
                                        }
                                    },
                                    modifier = Modifier.testTag("inventory_preview_pdf_btn"),
                                ) {
                                    Icon(Icons.Default.Preview, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("معاينة قبل الطباعة")
                                }

                                FilledTonalButton(
                                    enabled = !state.isBusy,
                                    onClick = { viewModel.printInventoryPdf(context) },
                                    modifier = Modifier.testTag("inventory_print_pdf_btn"),
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("طباعة")
                                }

                                FilledTonalButton(
                                    enabled = !state.isBusy,
                                    onClick = {
                                        requirePro(ProFeature.PRO_ADVANCED_INVENTORY_TOOLS) {
                                            viewModel.exportInventoryPdf { file ->
                                                openFileViaProvider(context, file, "application/pdf")
                                            }
                                        }
                                    },
                                    modifier = Modifier.testTag("inventory_export_pdf_btn"),
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("PDF")
                                }

                                FilledTonalButton(
                                    enabled = !state.isBusy,
                                    onClick = {
                                        requirePro(ProFeature.PRO_ADVANCED_INVENTORY_TOOLS) {
                                            viewModel.exportInventoryExcel { file ->
                                                shareFileViaProvider(
                                                    context,
                                                    file,
                                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                                    "مشاركة كشف الجرد Excel",
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.testTag("inventory_export_excel_btn"),
                                ) {
                                    Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Excel")
                                }

                                OutlinedButton(
                                    onClick = { showColumnsAndPrintSheet = true },
                                    modifier = Modifier.testTag("inventory_customize_columns_btn"),
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("الأعمدة والطباعة")
                                }

                                OutlinedButton(
                                    enabled = activeSession.items.isNotEmpty(),
                                    onClick = { showSessionBarcodeFormatDialog = true },
                                    modifier = Modifier.testTag("inventory_session_barcode_format_btn"),
                                ) {
                                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("نوع باركود الكشف")
                                }

                                OutlinedButton(onClick = { showEditSessionDialog = true }) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تعديل الكشف")
                                }

                                if (isSessionOpen) {
                                    OutlinedButton(onClick = { viewModel.closeActiveSession() }) {
                                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("إغلاق الكشف")
                                    }
                                } else {
                                    OutlinedButton(onClick = { viewModel.reopenActiveSession() }) {
                                        Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("إعادة فتح الكشف")
                                    }
                                }

                                IconButton(
                                    onClick = { showDeleteSessionConfirm = true },
                                    modifier = Modifier.testTag("inventory_delete_session_btn"),
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف الكشف", tint = StatusError)
                                }
                            }
                        }
                    }
                }
            }

            if (activeSession != null) {
                // 2. Barcode Scanner & Manual Barcode Input
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "مسح أو إدخال الباركود لإدخال الكمية",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "امسح بالكاميرا أو القارئ الخارجي أو أدخل الباركود يدوياً، أو ابحث عن المنتج بالاسم من القاعدة الرئيسية.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            if (!isSessionOpen) {
                                Text(
                                    text = "هذا الكشف مغلق حالياً للعرض والطباعة والتصدير. يمكنك إعادة فتحه لإضافة بنود.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusWarning,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OutlinedTextField(
                                    value = state.barcodeInput,
                                    onValueChange = viewModel::onBarcodeInputChange,
                                    enabled = isSessionOpen,
                                    label = { Text("الباركود (الأساسي أو أي بديل)") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(
                                        onSearch = { viewModel.lookupBarcode(state.barcodeInput) },
                                        onDone = { viewModel.lookupBarcode(state.barcodeInput) },
                                    ),
                                    modifier = Modifier.weight(1f).testTag("inventory_barcode_input"),
                                )
                                Button(
                                    enabled = isSessionOpen,
                                    onClick = { viewModel.lookupBarcode(state.barcodeInput) },
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("inventory_lookup_btn"),
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = "بحث", modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("بحث")
                                }
                                FilledTonalButton(
                                    enabled = isSessionOpen,
                                    onClick = onLaunchBarcodeCamera,
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("inventory_camera_scan_btn"),
                                ) {
                                    Icon(Icons.Default.QrCodeScanner, contentDescription = "كاميرا", modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("كاميرا")
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                FilledTonalButton(
                                    enabled = isSessionOpen,
                                    onClick = { showProductSearchDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 48.dp)
                                        .testTag("inventory_search_product_btn"),
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("البحث عن منتج")
                                }
                                OutlinedButton(
                                    enabled = isSessionOpen,
                                    onClick = { onCreateNewProductFromSearch("") },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("inventory_new_product_quick_btn"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("منتج جديد")
                                }
                            }
                        }
                    }
                }

                // 3. Pending Scan Count Entry Card (Auto-focuses quantity, NEVER increments automatically!)
                state.pendingScanLookup?.let { lookup ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                            border = BorderStroke(
                                1.5.dp,
                                if (lookup is InventoryScanLookupResult.MatchedRegistered) BrandEmerald else StatusWarning,
                            ),
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                when (lookup) {
                                    is InventoryScanLookupResult.MatchedRegistered -> {
                                        val p = lookup.product
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        ) {
                                            ProductEntityImageBox(
                                                image = p.primaryImage,
                                                contentDescription = p.product.name,
                                                preferThumbnail = true,
                                                modifier = Modifier.size(58.dp),
                                            )
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(p.product.name, fontWeight = FontWeight.Bold)
                                                Text(
                                                    "رقم المنتج: ${p.product.internalCode.ifBlank { "—" }}  •  الباركود: ${lookup.barcodeValue} (${if (lookup.isAlternativeBarcode) "بديل" else "أساسي"})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                )
                                                val scanFactorSpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                                    state.inventoryConfig.columns,
                                                    "conversion_factor",
                                                )
                                                val scanQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                                    state.inventoryConfig.columns,
                                                    "quantity",
                                                )
                                                Text(
                                                    "الوحدة المرتبطة بالباركود: ${lookup.unitType}" +
                                                        if (lookup.conversionFactor != 1.0) " (معامل × ${NumberFormatEngine.formatDouble(lookup.conversionFactor, scanFactorSpec)})" else "",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                lookup.existingItemInSession?.let { prev ->
                                                    Text(
                                                        "مسجل مسبقاً بنفس الباركود: ${NumberFormatEngine.formatDouble(prev.countedQty, scanQtySpec)} ${prev.unitType}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = StatusWarning,
                                                        fontWeight = FontWeight.Bold,
                                                    )
                                                }
                                                if (lookup.otherUnitsInSession.isNotEmpty()) {
                                                    Text(
                                                        "ملاحظة: الصنف مسجل في سطر مستقل بوحدة أخرى: ${lookup.otherUnitsInSession.joinToString("، ")}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = StatusInfo,
                                                    )
                                                }
                                            }
                                            IconButton(onClick = { viewModel.dismissPendingLookup() }) {
                                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                                            }
                                        }
                                    }
                                    is InventoryScanLookupResult.UnregisteredBarcode -> {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning)
                                            Spacer(Modifier.width(8.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("باركود غير مسجل في قاعدة المنتجات", fontWeight = FontWeight.Bold, color = StatusWarning)
                                                Text("الباركود: ${lookup.barcodeValue} (${lookup.barcodeType})", style = MaterialTheme.typography.labelSmall)
                                            }
                                            IconButton(onClick = { viewModel.dismissPendingLookup() }) {
                                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                                            }
                                        }
                                    }
                                }

                                // Non-blocking cached barcode preview + inline format switcher
                                val pendingProductId = (lookup as? InventoryScanLookupResult.MatchedRegistered)?.product?.product?.id
                                val pendingCode = when (lookup) {
                                    is InventoryScanLookupResult.MatchedRegistered -> lookup.barcodeValue
                                    is InventoryScanLookupResult.UnregisteredBarcode -> lookup.barcodeValue
                                }
                                val pendingRawType = when (lookup) {
                                    is InventoryScanLookupResult.MatchedRegistered -> lookup.barcodeType
                                    is InventoryScanLookupResult.UnregisteredBarcode -> lookup.barcodeType
                                }
                                val pendingFmt = BarcodeEngine.parseFormatOrNull(pendingRawType)
                                    ?: BarcodeEngine.resolveCompatibleDefaultFormat(pendingCode, defaultBarcodeType)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    CachedBarcodeImage(
                                        productId = pendingProductId,
                                        barcodeValue = pendingCode,
                                        format = pendingFmt,
                                        barcodeService = viewModel.barcodeService,
                                        baseHeightPx = if (pendingFmt.is2D) 180 else 140,
                                        baseWidthPx = if (pendingFmt.is2D) 180 else 500,
                                        showTextBelow = state.inventoryConfig.showBarcodeTextBelow,
                                        quietZoneModules = state.inventoryConfig.quietZoneModules,
                                        allowTapToZoom = true,
                                        modifier = Modifier.weight(1f).height(62.dp),
                                    )
                                    OutlinedButton(
                                        onClick = { showPendingBarcodeFormatDialog = true },
                                        modifier = Modifier
                                            .heightIn(min = 48.dp)
                                            .testTag("inventory_pending_change_format_btn"),
                                    ) {
                                        Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(pendingFmt.arabicLabel, maxLines = 1)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    OutlinedTextField(
                                        value = state.qtyInput,
                                        onValueChange = viewModel::onQtyInputChange,
                                        label = { Text("الكمية الفعلية (أدخل الرقم ثم أكّد)") },
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Decimal,
                                            imeAction = ImeAction.Done,
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = { viewModel.submitPendingCount() },
                                        ),
                                        singleLine = true,
                                        modifier = Modifier
                                            .weight(1f)
                                            .focusRequester(qtyFocusRequester)
                                            .testTag("inventory_qty_input"),
                                    )
                                    OutlinedTextField(
                                        value = state.notesInput,
                                        onValueChange = viewModel::onNotesInputChange,
                                        label = { Text("ملاحظات (اختياري)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                }

                                if (lookup is InventoryScanLookupResult.MatchedRegistered) {
                                    if (lookup.product.barcodes.size > 1) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        ) {
                                            lookup.product.barcodes.forEach { bc ->
                                                val isChosen = bc.barcodeValue == lookup.barcodeValue
                                                FilterChip(
                                                    selected = isChosen,
                                                    onClick = {
                                                        if (!isChosen) {
                                                            viewModel.selectProductForInventory(lookup.product, bc.barcodeValue)
                                                        }
                                                    },
                                                    label = {
                                                        Text("${bc.unitType}: ${bc.barcodeValue}")
                                                    },
                                                )
                                            }
                                        }
                                    }
                                    val enteredVal = parseInventoryDecimal(state.qtyInput)
                                    if (enteredVal != null && enteredVal >= 0.0 && lookup.conversionFactor != 1.0) {
                                        val baseQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                            state.inventoryConfig.columns,
                                            "base_qty",
                                        )
                                        Text(
                                            text = "المكافئ بالوحدة الأساسية: ${NumberFormatEngine.formatDouble(enteredVal * lookup.conversionFactor, baseQtySpec)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = BrandEmerald,
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }
                                    Button(
                                        enabled = !state.isSubmittingCount,
                                        onClick = { viewModel.submitPendingCount() },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 48.dp)
                                            .testTag("inventory_submit_count_btn"),
                                    ) {
                                        Text("إضافة إلى الجرد")
                                    }
                                } else if (lookup is InventoryScanLookupResult.UnregisteredBarcode) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        OutlinedButton(
                                            onClick = { onCreateNewProductWithBarcode(lookup.barcodeValue, lookup.barcodeType) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 48.dp)
                                                .testTag("inventory_create_product_btn"),
                                        ) {
                                            Text("تسجيل كمنتج جديد")
                                        }
                                        Button(
                                            enabled = !state.isSubmittingCount,
                                            onClick = { viewModel.submitPendingCount() },
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 48.dp)
                                                .testTag("inventory_add_unregistered_btn"),
                                        ) {
                                            Text("تثبيته كبند غير مسجل")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. Filter, Search & View Mode Switch (Table WYSIWYG vs Cards)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = state.searchQuery,
                            onValueChange = viewModel::onSearchQueryChange,
                            label = { Text("بحث في كشف الجرد (اسم المنتج، رقم المنتج، الباركود، الملاحظات)") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("inventory_search_input"),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                InventoryListFilter.entries.forEach { f ->
                                    FilterChip(
                                        selected = state.listFilter == f,
                                        onClick = { viewModel.setListFilter(f) },
                                        label = { Text(f.arabicLabel) },
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilterChip(
                                    selected = state.viewMode == InventoryViewMode.TABLE,
                                    onClick = { viewModel.setViewMode(InventoryViewMode.TABLE) },
                                    label = { Text("جدول") },
                                    leadingIcon = { Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.testTag("inventory_mode_table_btn"),
                                )
                                FilterChip(
                                    selected = state.viewMode == InventoryViewMode.CARDS,
                                    onClick = { viewModel.setViewMode(InventoryViewMode.CARDS) },
                                    label = { Text("بطاقات") },
                                    leadingIcon = { Icon(Icons.Default.ViewAgenda, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.testTag("inventory_mode_cards_btn"),
                                )
                            }
                        }
                    }
                }

                // 5. Filtered Count Sheet Items
                val q = state.searchQuery.trim().lowercase(Locale.ROOT)
                val filteredItems = activeSession.sortedItems.filter { item ->
                    val matchesSearch = q.isEmpty() ||
                        item.productName.lowercase(Locale.ROOT).contains(q) ||
                        item.productInternalCode.lowercase(Locale.ROOT).contains(q) ||
                        item.scannedBarcode.lowercase(Locale.ROOT).contains(q) ||
                        item.notes.lowercase(Locale.ROOT).contains(q)
                    if (!matchesSearch) return@filter false

                    val isUnreg = item.productId == null || item.status == InventoryItemStatus.UNREGISTERED.name
                    when (state.listFilter) {
                        InventoryListFilter.ALL -> true
                        InventoryListFilter.REGISTERED_COUNTED -> !isUnreg
                        InventoryListFilter.UNREGISTERED_ONLY -> isUnreg
                    }
                }

                if (state.viewMode == InventoryViewMode.TABLE) {
                    item {
                        InventoryLiveTableView(
                            items = filteredItems,
                            allProducts = state.allProducts,
                            inventoryConfig = state.inventoryConfig,
                            layoutResult = state.layoutResult,
                            isSessionOpen = isSessionOpen,
                            onEditItem = { editingItem = it },
                            onOpenProductDetail = onOpenProductDetail,
                            onAdjustColumnWidthDelta = viewModel::adjustColumnManualWidthDelta,
                            onResetColumnWidth = viewModel::resetColumnWidthToDefault,
                            onOpenColumnsPanel = { showColumnsAndPrintSheet = true },
                            onUpdateColumn = viewModel::updateColumn,
                            barcodeService = viewModel.barcodeService,
                            defaultBarcodeType = defaultBarcodeType,
                            onClickBarcodeCell = if (isSessionOpen) ({ formatChangeInvItem = it }) else null,
                        )
                    }
                } else {
                    if (filteredItems.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "لا توجد بنود في كشف الجرد",
                                description = "امسح باركوداً بالكاميرا أو أدخله يدوياً لتسجيل الكميات الفعلية.",
                                icon = Icons.Default.Inventory,
                            )
                        }
                    } else {
                        items(filteredItems, key = { "inv_item_${it.id}" }) { item ->
                            val isUnreg = item.productId == null || item.status == InventoryItemStatus.UNREGISTERED.name
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    val cardFactorSpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                        state.inventoryConfig.columns,
                                        "conversion_factor",
                                    )
                                    val cardQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(
                                        state.inventoryConfig.columns,
                                        "quantity",
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    ) {
                                        InventoryItemImageBox(
                                            snapshotPath = item.productImagePath,
                                            product = item.productId?.let { pid -> state.allProducts.firstOrNull { it.product.id == pid } },
                                            contentDescription = item.productName,
                                            modifier = Modifier.size(46.dp),
                                        )
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .then(
                                                    if (item.productId != null) {
                                                        Modifier.clickable { onOpenProductDetail(item.productId) }
                                                    } else Modifier,
                                                ),
                                        ) {
                                            Text(item.productName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(
                                                "الباركود: ${item.scannedBarcode} • ${item.unitType}" +
                                                    if (item.conversionFactor != 1.0) " (×${NumberFormatEngine.formatDouble(item.conversionFactor, cardFactorSpec)})" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                            if (item.productInternalCode.isNotBlank()) {
                                                Text(
                                                    "رقم المنتج: ${item.productInternalCode}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                )
                                            }
                                        }
                                        Surface(
                                            color = (if (isUnreg) StatusWarning else BrandEmerald).copy(alpha = 0.14f),
                                            shape = RoundedCornerShape(99.dp),
                                        ) {
                                            Text(
                                                text = if (isUnreg) "غير مسجل" else "${NumberFormatEngine.formatDouble(item.countedQty, cardQtySpec)} ${item.unitType}",
                                                color = if (isUnreg) StatusWarning else BrandEmerald,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            )
                                        }
                                    }

                                    val itemProduct = item.productId?.let { pid -> state.allProducts.firstOrNull { it.product.id == pid } }
                                    val resolvedCardCode = InventoryColumnDefaults.resolveBarcodeValue(
                                        item = item,
                                        product = itemProduct,
                                        mode = state.inventoryConfig.barcodeSourceMode,
                                    )
                                    val resolvedCardFormat = InventoryColumnDefaults.resolveBarcodeFormat(
                                        item = item,
                                        product = itemProduct,
                                        config = state.inventoryConfig,
                                        defaultFormat = defaultBarcodeType,
                                    )
                                    if (resolvedCardCode.isNotBlank() && state.inventoryConfig.renderBarcodeGraphic) {
                                        CachedBarcodeImage(
                                            productId = item.productId,
                                            barcodeValue = resolvedCardCode,
                                            format = resolvedCardFormat,
                                            barcodeService = viewModel.barcodeService,
                                            baseWidthPx = if (resolvedCardFormat.is2D) 220 else 560,
                                            baseHeightPx = if (resolvedCardFormat.is2D) 220 else 150,
                                            showTextBelow = state.inventoryConfig.showBarcodeTextBelow,
                                            quietZoneModules = state.inventoryConfig.quietZoneModules,
                                            allowTapToZoom = true,
                                            modifier = Modifier.fillMaxWidth().height(68.dp),
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(
                                            text = "الكمية المسجلة: ${NumberFormatEngine.formatDouble(item.countedQty, cardQtySpec)} ${item.unitType}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                        if (isSessionOpen) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                TextButton(
                                                    onClick = { formatChangeInvItem = item },
                                                    modifier = Modifier.testTag("inv_item_change_format_${item.id}"),
                                                ) {
                                                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text(resolvedCardFormat.arabicLabel)
                                                }
                                                if (isUnreg) {
                                                    TextButton(onClick = { onCreateNewProductWithBarcode(item.scannedBarcode, item.barcodeType) }) {
                                                        Text("تسجيل كمنتج")
                                                    }
                                                }
                                                IconButton(onClick = { editingItem = item }, modifier = Modifier.size(34.dp)) {
                                                    Icon(Icons.Default.Edit, contentDescription = "تعديل الكمية", modifier = Modifier.size(18.dp))
                                                }
                                                IconButton(onClick = { deletingItem = item }, modifier = Modifier.size(34.dp)) {
                                                    Icon(Icons.Default.Delete, contentDescription = "حذف السطر", tint = StatusError, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                    if (item.notes.isNotBlank()) {
                                        Text("ملاحظات: ${item.notes}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Columns, Barcode & Print Controller Modal Sheet
    if (showColumnsAndPrintSheet) {
        InventoryColumnsAndPrintSheet(
            config = state.inventoryConfig,
            layoutResult = state.layoutResult,
            onDismiss = { showColumnsAndPrintSheet = false },
            onToggleColumnVisible = viewModel::toggleColumnVisibility,
            onToggleColumnPinned = viewModel::toggleColumnPinned,
            onMoveColumn = viewModel::moveColumn,
            onReorderColumnsByKeys = viewModel::reorderColumnsByKeys,
            onAdjustColumnWidthDelta = viewModel::adjustColumnManualWidthDelta,
            onSetColumnWidth = viewModel::setColumnManualWidth,
            onUpdateColumn = viewModel::updateColumn,
            onResetColumnWidth = viewModel::resetColumnWidthToDefault,
            onResetAllColumns = viewModel::resetAllColumnsToDefault,
            onUpdateColumnNumberFormat = viewModel::updateColumnNumberFormat,
            onResetDecimalDefaults = viewModel::resetDecimalDefaults,
            onFitColumnsToPage = viewModel::fitColumnsToPageWidth,
            onSetDistributionMode = viewModel::setDistributionMode,
            onAddOptionalColumn = viewModel::addOptionalColumn,
            onAddCustomColumn = viewModel::addCustomColumn,
            onCloneColumn = viewModel::cloneColumn,
            onDeleteColumn = viewModel::deleteColumn,
            onUpdateConfig = viewModel::updateInventoryConfig,
            onApplyOverflowSuggestion = viewModel::applyOverflowSuggestion,
            onOpenPrintPreview = {
                viewModel.generatePreviewPdf { sid, path ->
                    onOpenPdfPreview(sid, path)
                }
            },
            onPrintNow = { viewModel.printInventoryPdf(context) },
            onOpenSessionBarcodeFormatDialog = { showSessionBarcodeFormatDialog = true },
            canUndoColumns = state.canUndoColumns,
            canRedoColumns = state.canRedoColumns,
            onUndoColumns = viewModel::undoColumns,
            onRedoColumns = viewModel::redoColumns,
        )
    }

    // In-flow Smart Product Search & Picker Dialog (matches ReportProductPickerScreen UX)
    if (showProductSearchDialog && activeSession != null) {
        InventoryProductSearchDialog(
            allProducts = state.allProducts,
            activeSession = activeSession,
            inventoryConfig = state.inventoryConfig,
            onDismiss = { showProductSearchDialog = false },
            onSelectProduct = { product, chosenBarcode ->
                showProductSearchDialog = false
                viewModel.selectProductForInventory(product, chosenBarcode)
            },
            onLaunchCamera = {
                showProductSearchDialog = false
                onLaunchBarcodeCamera()
            },
            onCreateNewProduct = { query ->
                showProductSearchDialog = false
                onCreateNewProductFromSearch(query)
            },
        )
    }

    // Create Session Dialog
    if (showNewSessionDialog) {
        var title by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        Dialog(
            onDismissRequest = { showNewSessionDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "إنشاء كشف جرد جديد",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("اسم كشف الجرد (مثال: جرد مستودع الرياض) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_session_title_input"),
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات الكشف (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(onClick = { showNewSessionDialog = false }) { Text("إلغاء") }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = title.trim().isNotEmpty(),
                            onClick = {
                                viewModel.createSession(title, notes)
                                showNewSessionDialog = false
                            },
                            modifier = Modifier.testTag("confirm_new_session_btn"),
                        ) {
                            Text("إنشاء وبدء الجرد")
                        }
                    }
                }
            }
        }
    }

    // Edit Session Title / Notes Dialog
    if (showEditSessionDialog && activeSession != null) {
        var title by remember(activeSession.session.id) { mutableStateOf(activeSession.session.title) }
        var notes by remember(activeSession.session.id) { mutableStateOf(activeSession.session.notes) }
        Dialog(
            onDismissRequest = { showEditSessionDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "تعديل بيانات كشف الجرد",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("اسم كشف الجرد *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات الكشف") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(onClick = { showEditSessionDialog = false }) { Text("إلغاء") }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = title.trim().isNotEmpty(),
                            onClick = {
                                viewModel.updateActiveSessionDetails(title, notes)
                                showEditSessionDialog = false
                            },
                        ) { Text("حفظ") }
                    }
                }
            }
        }
    }

    // Immediate Duplicate Barcode Dialog (CHOOSE / ADD_QUANTITY / REPLACE_QUANTITY / CANCEL)
    state.duplicatePrompt?.let { prompt ->
        val prev = prompt.existingItem
        val dupQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(
            state.inventoryConfig.columns,
            "quantity",
        )
        val prodName = when (val lr = prompt.lookupResult) {
            is InventoryScanLookupResult.MatchedRegistered -> lr.product.product.name
            is InventoryScanLookupResult.UnregisteredBarcode -> prev.productName.ifBlank { "بند غير مسجل" }
        }
        val parsedEnteredQty = parseInventoryDecimal(prompt.qtyInputText)

        Dialog(
            onDismissRequest = { if (!prompt.isSubmitting) viewModel.dismissDuplicatePrompt() },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState())
                        .testTag("dup_prompt_dialog"),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning)
                        Text(
                            text = "هذا المنتج مسجل مسبقاً في كشف الجرد",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("dup_prompt_title"),
                        )
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp),
                        ) {
                            Text(prodName, fontWeight = FontWeight.Bold)
                            Text(
                                text = "الباركود: ${prev.scannedBarcode}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = "الكمية المسجلة سابقاً: ${NumberFormatEngine.formatDouble(prev.countedQty, dupQtySpec)} ${prev.unitType}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    prompt.unitConflictMessage?.let { conflict ->
                        Surface(
                            color = StatusError.copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, StatusError.copy(alpha = 0.45f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = conflict,
                                color = StatusError,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(8.dp),
                            )
                        }
                    }

                    when (prompt.step) {
                        DuplicatePromptStep.CHOOSE -> {
                            Text(
                                text = "اختر الإجراء المطلوب لهذا الصنف:",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        DuplicatePromptStep.ADD_QUANTITY -> {
                            OutlinedTextField(
                                value = prompt.qtyInputText,
                                onValueChange = viewModel::onDuplicatePromptQtyChange,
                                label = { Text("الكمية المراد إضافتها") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Decimal,
                                    imeAction = ImeAction.Done,
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { viewModel.confirmDuplicatePrompt() },
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("dup_prompt_qty_input"),
                            )
                            OutlinedTextField(
                                value = prompt.notesInputText,
                                onValueChange = viewModel::onDuplicatePromptNotesChange,
                                label = { Text("ملاحظات (اختياري)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("dup_prompt_notes_input"),
                            )
                            val newFormatted = parsedEnteredQty?.let { NumberFormatEngine.formatDouble(it, dupQtySpec) } ?: "—"
                            val finalFormatted = parsedEnteredQty?.let {
                                NumberFormatEngine.formatDouble(prev.countedQty + it, dupQtySpec)
                            } ?: "—"
                            Surface(
                                color = BrandEmerald.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp),
                                ) {
                                    Text(
                                        text = "السابقة: ${NumberFormatEngine.formatDouble(prev.countedQty, dupQtySpec)} + الجديدة: $newFormatted",
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                    Text(
                                        text = "الكمية النهائية: $finalFormatted ${prev.unitType}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = BrandEmerald,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.testTag("dup_prompt_final_qty_preview"),
                                    )
                                }
                            }
                        }
                        DuplicatePromptStep.REPLACE_QUANTITY -> {
                            OutlinedTextField(
                                value = prompt.qtyInputText,
                                onValueChange = viewModel::onDuplicatePromptQtyChange,
                                label = { Text("الكمية الجديدة المعدلة") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Decimal,
                                    imeAction = ImeAction.Done,
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { viewModel.confirmDuplicatePrompt() },
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("dup_prompt_qty_input"),
                            )
                            OutlinedTextField(
                                value = prompt.notesInputText,
                                onValueChange = viewModel::onDuplicatePromptNotesChange,
                                label = { Text("ملاحظات (اختياري)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("dup_prompt_notes_input"),
                            )
                            val newFormatted = parsedEnteredQty?.let { NumberFormatEngine.formatDouble(it, dupQtySpec) } ?: "—"
                            Text(
                                text = "سيتم استبدال الكمية من ${NumberFormatEngine.formatDouble(prev.countedQty, dupQtySpec)} إلى $newFormatted ${prev.unitType}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }

                    prompt.errorMessage?.let { err ->
                        Text(
                            text = err,
                            color = StatusError,
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }

                    when (prompt.step) {
                        DuplicatePromptStep.CHOOSE -> {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Button(
                                    enabled = prompt.unitConflictMessage == null && !prompt.isSubmitting,
                                    onClick = { viewModel.chooseDuplicatePromptStep(DuplicatePromptStep.ADD_QUANTITY) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("dup_prompt_choose_add_btn"),
                                ) {
                                    Text("إضافة كمية فوق السابقة")
                                }
                                FilledTonalButton(
                                    enabled = !prompt.isSubmitting,
                                    onClick = { viewModel.chooseDuplicatePromptStep(DuplicatePromptStep.REPLACE_QUANTITY) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("dup_prompt_choose_replace_btn"),
                                ) {
                                    Text("تعديل الكمية السابقة")
                                }
                                TextButton(
                                    enabled = !prompt.isSubmitting,
                                    onClick = { viewModel.dismissDuplicatePrompt() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("dup_prompt_cancel_btn"),
                                ) {
                                    Text("إلغاء")
                                }
                            }
                        }
                        DuplicatePromptStep.ADD_QUANTITY, DuplicatePromptStep.REPLACE_QUANTITY -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                TextButton(
                                    enabled = !prompt.isSubmitting,
                                    onClick = { viewModel.chooseDuplicatePromptStep(DuplicatePromptStep.CHOOSE) },
                                    modifier = Modifier.heightIn(min = 48.dp),
                                ) {
                                    Text("رجوع")
                                }
                                TextButton(
                                    enabled = !prompt.isSubmitting,
                                    onClick = { viewModel.dismissDuplicatePrompt() },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("dup_prompt_cancel_btn"),
                                ) {
                                    Text("إلغاء")
                                }
                                Spacer(Modifier.width(6.dp))
                                Button(
                                    enabled = parsedEnteredQty != null && !prompt.isSubmitting,
                                    onClick = { viewModel.confirmDuplicatePrompt() },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("dup_prompt_confirm_btn"),
                                ) {
                                    Text(if (prompt.step == DuplicatePromptStep.ADD_QUANTITY) "تأكيد الإضافة" else "تأكيد التعديل")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit Item Quantity Dialog
    editingItem?.let { item ->
        var qtyTxt by remember(item.id) { mutableStateOf(NumberFormatEngine.formatEditableNumber(item.countedQty)) }
        var noteTxt by remember(item.id) { mutableStateOf(item.notes) }
        Dialog(
            onDismissRequest = { editingItem = null },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 520.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        "تعديل كمية السطر",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(item.productName, fontWeight = FontWeight.SemiBold)
                    Text("الباركود: ${item.scannedBarcode} • ${item.unitType}", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = qtyTxt,
                        onValueChange = { qtyTxt = it },
                        label = { Text("الكمية الجديدة (تقبل 0 والعشري)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = noteTxt,
                        onValueChange = { noteTxt = it },
                        label = { Text("ملاحظات") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(onClick = { editingItem = null }) { Text("إلغاء") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            viewModel.updateItemQuantity(item.id, qtyTxt, noteTxt)
                            editingItem = null
                        }) {
                            Text("حفظ التعديل")
                        }
                    }
                }
            }
        }
    }

    // Delete Item Confirmation
    deletingItem?.let { item ->
        ConfirmActionDialog(
            title = "حذف سطر من الكشف",
            message = "هل تريد حذف «${item.productName}» (${item.scannedBarcode}) من كشف الجرد الحالي؟",
            confirmLabel = "حذف السطر",
            isDestructive = true,
            onConfirm = {
                viewModel.deleteItem(item)
                deletingItem = null
            },
            onDismiss = { deletingItem = null },
        )
    }

    // Delete Session Confirmation
    if (showDeleteSessionConfirm && activeSession != null) {
        ConfirmActionDialog(
            title = "حذف كشف الجرد",
            message = "سيتم حذف كشف «${activeSession.session.title}» وجميع البنود المسجلة فيه نهائياً دون التأثير على قاعدة المنتجات.",
            confirmLabel = "حذف الكشف",
            isDestructive = true,
            onConfirm = {
                viewModel.deleteActiveSession()
                showDeleteSessionConfirm = false
            },
            onDismiss = { showDeleteSessionConfirm = false },
        )
    }

    // In-Place Barcode Format Dialog for Pending Lookup
    if (showPendingBarcodeFormatDialog) {
        state.pendingScanLookup?.let { lookup ->
            val code = when (lookup) {
                is InventoryScanLookupResult.MatchedRegistered -> lookup.barcodeValue
                is InventoryScanLookupResult.UnregisteredBarcode -> lookup.barcodeValue
            }
            val prodName = (lookup as? InventoryScanLookupResult.MatchedRegistered)?.product?.product?.name
            val rawFmt = when (lookup) {
                is InventoryScanLookupResult.MatchedRegistered -> lookup.barcodeType
                is InventoryScanLookupResult.UnregisteredBarcode -> lookup.barcodeType
            }
            val currentFmt = BarcodeEngine.parseFormatOrNull(rawFmt)
                ?: BarcodeEngine.resolveCompatibleDefaultFormat(code, defaultBarcodeType)
            val scopes = buildList {
                add(BarcodeFormatChangeScope.CURRENT_INVENTORY_ITEM)
                if (lookup is InventoryScanLookupResult.MatchedRegistered) {
                    add(BarcodeFormatChangeScope.CURRENT_PRODUCT)
                }
                add(BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING)
            }
            BarcodeFormatChangeDialog(
                barcodeValue = code,
                currentFormat = currentFmt,
                productName = prodName,
                availableScopes = scopes,
                initialScope = BarcodeFormatChangeScope.CURRENT_INVENTORY_ITEM,
                onDismiss = { showPendingBarcodeFormatDialog = false },
                onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                    viewModel.changePendingLookupBarcodeFormat(
                        targetFormat = targetFormat,
                        scope = scope,
                        alsoUpdateDefault = alsoUpdateDefault,
                    ) { res ->
                        if (res.success) showPendingBarcodeFormatDialog = false
                    }
                },
            )
        }
    }

    // In-Place Barcode Format Dialog for Existing Inventory Item
    formatChangeInvItem?.let { targetItem ->
        val prod = targetItem.productId?.let { pid -> state.allProducts.firstOrNull { it.product.id == pid } }
        val currentFmt = BarcodeEngine.parseFormatOrNull(targetItem.barcodeType)
            ?: BarcodeEngine.resolveCompatibleDefaultFormat(targetItem.scannedBarcode, defaultBarcodeType)
        val scopes = buildList {
            add(BarcodeFormatChangeScope.CURRENT_INVENTORY_ITEM)
            if (targetItem.productId != null) {
                add(BarcodeFormatChangeScope.CURRENT_PRODUCT)
            }
            add(BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION)
            add(BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING)
        }
        BarcodeFormatChangeDialog(
            barcodeValue = targetItem.scannedBarcode,
            currentFormat = currentFmt,
            productName = prod?.product?.name ?: targetItem.productName,
            availableScopes = scopes,
            initialScope = BarcodeFormatChangeScope.CURRENT_INVENTORY_ITEM,
            bulkCount = activeSession?.items?.size ?: 0,
            onDismiss = { formatChangeInvItem = null },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                viewModel.changeInventoryItemBarcodeFormat(
                    item = targetItem,
                    targetFormat = targetFormat,
                    scope = scope,
                    alsoUpdateDefault = alsoUpdateDefault,
                ) { res ->
                    if (res.success) formatChangeInvItem = null
                }
            },
        )
    }

    // In-Place Barcode Format Dialog for Entire Current Inventory Session
    if (showSessionBarcodeFormatDialog && activeSession != null) {
        val sampleItem = activeSession.items.firstOrNull()
        val currentFmt = BarcodeEngine.parseFormatOrNull(sampleItem?.barcodeType) ?: defaultBarcodeType
        BarcodeFormatChangeDialog(
            barcodeValue = "",
            currentFormat = currentFmt,
            productName = "بنود كشف الجرد (${activeSession.items.size})",
            availableScopes = listOf(
                BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION,
                BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
            ),
            initialScope = BarcodeFormatChangeScope.CURRENT_INVENTORY_SESSION,
            bulkCount = activeSession.items.size,
            onDismiss = { showSessionBarcodeFormatDialog = false },
            onConfirmChange = { targetFormat, scope, alsoUpdateDefault ->
                if (scope == BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING) {
                    viewModel.barcodeService.let {
                        val firstItem = activeSession.items.firstOrNull()
                        if (firstItem != null) {
                            viewModel.changeInventoryItemBarcodeFormat(
                                item = firstItem,
                                targetFormat = targetFormat,
                                scope = BarcodeFormatChangeScope.FUTURE_DEFAULT_SETTING,
                                alsoUpdateDefault = true,
                            ) { res -> if (res.success) showSessionBarcodeFormatDialog = false }
                        } else {
                            showSessionBarcodeFormatDialog = false
                        }
                    }
                } else {
                    viewModel.changeCurrentSessionBarcodeFormat(
                        targetFormat = targetFormat,
                        alsoUpdateDefault = alsoUpdateDefault,
                    ) { res ->
                        if (res.success) showSessionBarcodeFormatDialog = false
                    }
                }
            },
        )
    }

    upgradePromptFeature?.let { feature ->
        ProUpgradeDialog(
            feature = feature,
            currentStatus = entitlementState.status,
            onGoToSubscriptions = onOpenSubscription,
            onDismiss = { upgradePromptFeature = null },
        )
    }
}
