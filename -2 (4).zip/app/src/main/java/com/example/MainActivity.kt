package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.automirrored.outlined.LibraryBooks
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.di.AppContainer
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.ThemeMode
import com.example.ui.components.shareFileViaProvider
import com.example.ui.navigation.AppRoute
import com.example.ui.screens.AccountManagementScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.AboutAppScreen
import com.example.ui.screens.ArchiveScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.BarcodeScannerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ErrorDiagnosticsScreen
import com.example.ui.screens.ExcelImportScreen
import com.example.ui.screens.ImageEditorScreen
import com.example.ui.screens.ImageManagerScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LabelPrintingScreen
import com.example.ui.screens.PdfEditorScreen
import com.example.ui.screens.PdfPreviewScreen
import com.example.ui.screens.PrivacyAndDeletionScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ProductEditorScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportEditorScreen
import com.example.ui.screens.ReportProductPickerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.TemplatesScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.ArchiveViewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.BackupRestoreViewModel
import com.example.ui.viewmodel.DashboardViewModel
import com.example.ui.viewmodel.ErrorDiagnosticsViewModel
import com.example.ui.viewmodel.ExcelImportViewModel
import com.example.ui.viewmodel.InventoryViewModel
import com.example.ui.viewmodel.LabelPrintingViewModel
import com.example.ui.viewmodel.PdfEditorViewModel
import com.example.ui.viewmodel.ProductsViewModel
import com.example.ui.viewmodel.ReportEditorViewModel
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.SubscriptionViewModel
import com.example.ui.viewmodel.TemplatesViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as? ReportManagerApplication
        val fallbackContainer = rememberFallbackContainer(app)
        setContent {
            val shared = app?.sharedServices ?: fallbackContainer.sharedServices
            val activeWorkspace by shared.workspaceManager.activeWorkspace.collectAsStateWithLifecycle()
            val container = remember(activeWorkspace.workspaceId, shared) {
                shared.workspaceManager.containerForWorkspace(activeWorkspace)
            }
            LaunchedEffect(activeWorkspace.workspaceId) {
                AppDatabase.ensureSeeded(container.database)
                container.globalErrorMonitor.attachDaoProvider { container.database.diagnosticsDao() }
            }
            val settings by container.settingsRepository.settingsFlow.collectAsStateWithLifecycle(
                initialValue = AppSettingsEntity(),
            )
            ReportManagerTheme(
                themeMode = ThemeMode.fromString(settings.themeMode),
                accentHex = settings.accentColorHex,
                fontFamilyKey = settings.fontFamilyKey,
            ) {
                key(activeWorkspace.workspaceId) {
                    ReportManagerApp(container)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = application as? ReportManagerApplication ?: return
        app.sharedServices.billingGateway.connectAndRefresh()
    }

    private fun rememberFallbackContainer(app: ReportManagerApplication?): AppContainer {
        return app?.container ?: AppContainer(applicationContext)
    }
}

private data class TopLevelNavItem(
    val label: String,
    val route: AppRoute,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

@Composable
fun ReportManagerApp(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val previousCrashAlert by container.globalErrorMonitor.previousCrashAlert.collectAsStateWithLifecycle()

    DisposableEffect(navController, container) {
        val listener = NavController.OnDestinationChangedListener { _, destination, _ ->
            container.globalErrorMonitor.updateCurrentScreen(ScreenNames.resolveRouteName(destination.route))
        }
        navController.addOnDestinationChangedListener(listener)
        onDispose { navController.removeOnDestinationChangedListener(listener) }
    }

    val topLevelItems = remember {
        listOf(
            TopLevelNavItem("الرئيسية", AppRoute.Dashboard, Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "nav_dashboard"),
            TopLevelNavItem("المنتجات", AppRoute.Products(), Icons.Filled.Inventory2, Icons.Outlined.Inventory2, "nav_products"),
            TopLevelNavItem("التقارير", AppRoute.Archive, Icons.Filled.Description, Icons.Outlined.Description, "nav_archive"),
            TopLevelNavItem("القوالب", AppRoute.Templates, Icons.AutoMirrored.Filled.LibraryBooks, Icons.AutoMirrored.Outlined.LibraryBooks, "nav_templates"),
            TopLevelNavItem("الإعدادات", AppRoute.Settings, Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings"),
        )
    }

    val isTopLevel = currentDest?.let { dest ->
        dest.hasRoute<AppRoute.Dashboard>() ||
            dest.hasRoute<AppRoute.Products>() ||
            dest.hasRoute<AppRoute.Archive>() ||
            dest.hasRoute<AppRoute.Templates>() ||
            dest.hasRoute<AppRoute.Settings>()
    } ?: true

    val factory = remember(container) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
                DashboardViewModel::class.java -> DashboardViewModel(container) as T
                ProductsViewModel::class.java -> ProductsViewModel(container) as T
                ExcelImportViewModel::class.java -> ExcelImportViewModel(container) as T
                TemplatesViewModel::class.java -> TemplatesViewModel(container) as T
                ArchiveViewModel::class.java -> ArchiveViewModel(container) as T
                BackupRestoreViewModel::class.java -> BackupRestoreViewModel(container) as T
                SettingsViewModel::class.java -> SettingsViewModel(container) as T
                LabelPrintingViewModel::class.java -> LabelPrintingViewModel(container) as T
                PdfEditorViewModel::class.java -> PdfEditorViewModel(container) as T
                InventoryViewModel::class.java -> InventoryViewModel(container) as T
                ErrorDiagnosticsViewModel::class.java -> ErrorDiagnosticsViewModel(container) as T
                AuthViewModel::class.java -> AuthViewModel(container) as T
                SubscriptionViewModel::class.java -> SubscriptionViewModel(container) as T
                else -> throw IllegalArgumentException("Unknown ViewModel: $modelClass")
            }
        }
    }

    val productsVm: ProductsViewModel = viewModel(factory = factory)
    val archiveVm: ArchiveViewModel = viewModel(factory = factory)

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (isTopLevel && !useRail) {
                    NavigationBar {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                is AppRoute.Dashboard -> currentDest?.hasRoute<AppRoute.Dashboard>() == true
                                is AppRoute.Products -> currentDest?.hasRoute<AppRoute.Products>() == true
                                is AppRoute.Archive -> currentDest?.hasRoute<AppRoute.Archive>() == true
                                is AppRoute.Templates -> currentDest?.hasRoute<AppRoute.Templates>() == true
                                is AppRoute.Settings -> currentDest?.hasRoute<AppRoute.Settings>() == true
                                else -> false
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo(AppRoute.Dashboard) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label,
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag(item.testTag),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                if (isTopLevel && useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                is AppRoute.Dashboard -> currentDest?.hasRoute<AppRoute.Dashboard>() == true
                                is AppRoute.Products -> currentDest?.hasRoute<AppRoute.Products>() == true
                                is AppRoute.Archive -> currentDest?.hasRoute<AppRoute.Archive>() == true
                                is AppRoute.Templates -> currentDest?.hasRoute<AppRoute.Templates>() == true
                                is AppRoute.Settings -> currentDest?.hasRoute<AppRoute.Settings>() == true
                                else -> false
                            }
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo(AppRoute.Dashboard) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label,
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag(item.testTag),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoute.Dashboard,
                    ) {
                        composable<AppRoute.Dashboard> {
                            val vm: DashboardViewModel = viewModel(factory = factory)
                            DashboardScreen(
                                viewModel = vm,
                                onAddProduct = { navController.navigate(AppRoute.ProductEditor()) },
                                onImportExcel = { navController.navigate(AppRoute.ExcelImport) },
                                onOpenImageManager = { navController.navigate(AppRoute.ImageManager) },
                                onCreateReport = {
                                    scope.launch {
                                        val reportId = container.reportRepository.createEmptyReport()
                                        navController.navigate(AppRoute.ReportEditor(reportId))
                                    }
                                },
                                onOpenScanner = { navController.navigate(AppRoute.BarcodeScanner()) },
                                onOpenInventory = { navController.navigate(AppRoute.Inventory) },
                                onOpenPdfEditor = { navController.navigate(AppRoute.PdfEditor()) },
                                onOpenProducts = { filter -> navController.navigate(AppRoute.Products(filter)) },
                                onOpenProductDetail = { pid -> navController.navigate(AppRoute.ProductDetail(pid)) },
                                onOpenReportEditor = { rid -> navController.navigate(AppRoute.ReportEditor(rid)) },
                                onOpenTemplates = { navController.navigate(AppRoute.Templates) },
                                onOpenLabels = { navController.navigate(AppRoute.LabelPrinting) },
                                onOpenArchive = { navController.navigate(AppRoute.Archive) },
                                onOpenBackup = { navController.navigate(AppRoute.BackupRestore) },
                                onOpenSettings = { navController.navigate(AppRoute.Settings) },
                                onOpenAbout = { navController.navigate(AppRoute.AboutApp) },
                                onOpenAccount = { navController.navigate(AppRoute.Auth) },
                                onOpenSubscription = { navController.navigate(AppRoute.Subscription) },
                            )
                        }

                        composable<AppRoute.Products> { entry ->
                            val args = entry.toRoute<AppRoute.Products>()
                            ProductsScreen(
                                viewModel = productsVm,
                                initialFilter = args.initialFilter,
                                onOpenDetail = { pid -> navController.navigate(AppRoute.ProductDetail(pid)) },
                                onAddProduct = { navController.navigate(AppRoute.ProductEditor()) },
                                onOpenScanner = { navController.navigate(AppRoute.BarcodeScanner()) },
                                onOpenExcelImport = { navController.navigate(AppRoute.ExcelImport) },
                            )
                        }

                        composable<AppRoute.ProductDetail> { entry ->
                            val args = entry.toRoute<AppRoute.ProductDetail>()
                            val defaultFmt by container.barcodeService.defaultBarcodeTypeFlow.collectAsStateWithLifecycle()
                            val scannedValue by entry.savedStateHandle
                                .getStateFlow<String?>("scanned_barcode_value", null)
                                .collectAsStateWithLifecycle()
                            val scannedFormat by entry.savedStateHandle
                                .getStateFlow("scanned_barcode_format", defaultFmt.name)
                                .collectAsStateWithLifecycle()
                            val scannedPair = scannedValue?.let { it to scannedFormat }

                            ProductDetailScreen(
                                productId = args.productId,
                                viewModel = productsVm,
                                scannedBarcodeResult = scannedPair,
                                onConsumeScannedBarcode = {
                                    entry.savedStateHandle.remove<String>("scanned_barcode_value")
                                    entry.savedStateHandle.remove<String>("scanned_barcode_format")
                                },
                                onLaunchBarcodeCamera = {
                                    navController.navigate(AppRoute.BarcodeScanner(returnBarcodeOnly = true))
                                },
                                onBack = { navController.popBackStack() },
                                onEditProduct = { pid -> navController.navigate(AppRoute.ProductEditor(productId = pid)) },
                                onJumpToProduct = { pid ->
                                    navController.navigate(AppRoute.ProductDetail(pid)) {
                                        launchSingleTop = false
                                    }
                                },
                                onOpenImageEditor = { imgId -> navController.navigate(AppRoute.ImageEditor(imgId)) },
                            )
                        }

                        composable<AppRoute.ProductEditor> { entry ->
                            val args = entry.toRoute<AppRoute.ProductEditor>()
                            val defaultFmt by container.barcodeService.defaultBarcodeTypeFlow.collectAsStateWithLifecycle()
                            val scannedValue by entry.savedStateHandle
                                .getStateFlow<String?>("scanned_barcode_value", null)
                                .collectAsStateWithLifecycle()
                            val scannedFormat by entry.savedStateHandle
                                .getStateFlow("scanned_barcode_format", defaultFmt.name)
                                .collectAsStateWithLifecycle()
                            val scannedPair = scannedValue?.let { it to scannedFormat }

                            ProductEditorScreen(
                                productId = args.productId,
                                prefillBarcode = args.prefillBarcode,
                                prefillBarcodeFormat = args.prefillBarcodeFormat,
                                viewModel = productsVm,
                                prefillName = args.prefillName,
                                scannedBarcodeResult = scannedPair,
                                onConsumeScannedBarcode = {
                                    entry.savedStateHandle.remove<String>("scanned_barcode_value")
                                    entry.savedStateHandle.remove<String>("scanned_barcode_format")
                                },
                                onLaunchBarcodeCamera = {
                                    navController.navigate(AppRoute.BarcodeScanner(returnBarcodeOnly = true))
                                },
                                onBack = { navController.popBackStack() },
                                onSaved = { savedId ->
                                    if (args.returnSavedProductId) {
                                        navController.previousBackStackEntry?.savedStateHandle?.set("created_product_id", savedId)
                                        navController.popBackStack()
                                    } else {
                                        navController.popBackStack()
                                        if (args.productId == 0L) {
                                            navController.navigate(AppRoute.ProductDetail(savedId))
                                        }
                                    }
                                },
                                onJumpToConflictProduct = { pid ->
                                    navController.navigate(AppRoute.ProductDetail(pid))
                                },
                            )
                        }

                        composable<AppRoute.BarcodeScanner> { entry ->
                            val args = entry.toRoute<AppRoute.BarcodeScanner>()
                            BarcodeScannerScreen(
                                container = container,
                                targetReportId = args.targetReportId,
                                returnBarcodeOnly = args.returnBarcodeOnly,
                                onBack = { navController.popBackStack() },
                                onOpenProductDetail = { pid -> navController.navigate(AppRoute.ProductDetail(pid)) },
                                onCreateNewProductWithBarcode = { code, fmt ->
                                    navController.navigate(
                                        AppRoute.ProductEditor(
                                            productId = 0L,
                                            prefillBarcode = code,
                                            prefillBarcodeFormat = fmt,
                                        ),
                                    )
                                },
                                onAddedToReportAndBack = { navController.popBackStack() },
                                onReturnBarcode = { code, fmt ->
                                    navController.previousBackStackEntry?.savedStateHandle?.apply {
                                        set("scanned_barcode_format", fmt)
                                        set("scanned_barcode_value", code)
                                    }
                                    navController.popBackStack()
                                },
                            )
                        }

                        composable<AppRoute.Inventory> { entry ->
                            val invVm: InventoryViewModel = viewModel(factory = factory)
                            val scannedValue by entry.savedStateHandle
                                .getStateFlow<String?>("scanned_barcode_value", null)
                                .collectAsStateWithLifecycle()
                            val scannedFormat by entry.savedStateHandle
                                .getStateFlow<String?>("scanned_barcode_format", null)
                                .collectAsStateWithLifecycle()
                            val scannedPair = scannedValue?.let { it to scannedFormat.orEmpty() }
                            val createdProductId by entry.savedStateHandle
                                .getStateFlow<Long?>("created_product_id", null)
                                .collectAsStateWithLifecycle()

                            InventoryScreen(
                                viewModel = invVm,
                                scannedBarcodeResult = scannedPair,
                                onConsumeScannedBarcode = {
                                    entry.savedStateHandle.remove<String>("scanned_barcode_value")
                                    entry.savedStateHandle.remove<String>("scanned_barcode_format")
                                },
                                createdProductId = createdProductId,
                                onConsumeCreatedProductId = {
                                    entry.savedStateHandle.remove<Long>("created_product_id")
                                },
                                onBack = { navController.popBackStack() },
                                onLaunchBarcodeCamera = {
                                    navController.navigate(AppRoute.BarcodeScanner(returnBarcodeOnly = true))
                                },
                                onOpenProductDetail = { pid -> navController.navigate(AppRoute.ProductDetail(pid)) },
                                onCreateNewProductWithBarcode = { code, fmt ->
                                    navController.navigate(
                                        AppRoute.ProductEditor(
                                            productId = 0L,
                                            prefillBarcode = code,
                                            prefillBarcodeFormat = fmt,
                                            returnSavedProductId = true,
                                        ),
                                    )
                                },
                                onCreateNewProductFromSearch = { queryText ->
                                    val trimmed = queryText.trim()
                                    val looksLikeCode = trimmed.length >= 4 && trimmed.all { it.isDigit() }
                                    navController.navigate(
                                        AppRoute.ProductEditor(
                                            productId = 0L,
                                            prefillBarcode = if (looksLikeCode) trimmed else "",
                                            prefillName = if (!looksLikeCode) trimmed else "",
                                            returnSavedProductId = true,
                                        ),
                                    )
                                },
                                onOpenPdfPreview = { invSessionId, pdfPath ->
                                    navController.navigate(
                                        AppRoute.PdfPreview(
                                            reportId = 0L,
                                            pdfPath = pdfPath,
                                            inventorySessionId = invSessionId,
                                        ),
                                    )
                                },
                                onOpenSubscription = { navController.navigate(AppRoute.Subscription) },
                            )
                        }

                        composable<AppRoute.ExcelImport> {
                            val vm: ExcelImportViewModel = viewModel(factory = factory)
                            ExcelImportScreen(
                                viewModel = vm,
                                onBack = { navController.popBackStack() },
                                onDoneGoToProducts = {
                                    navController.navigate(AppRoute.Products()) {
                                        popUpTo(AppRoute.Dashboard)
                                    }
                                },
                            )
                        }

                        composable<AppRoute.Archive> {
                            ArchiveScreen(
                                viewModel = archiveVm,
                                container = container,
                                onOpenReportEditor = { rid -> navController.navigate(AppRoute.ReportEditor(rid)) },
                                onOpenPdfPreview = { rid, path -> navController.navigate(AppRoute.PdfPreview(rid, path)) },
                                onOpenTemplates = { navController.navigate(AppRoute.Templates) },
                                onOpenPdfEditor = { path -> navController.navigate(AppRoute.PdfEditor(initialPdfPath = path)) },
                            )
                        }

                        composable<AppRoute.ReportEditor> { entry ->
                            val args = entry.toRoute<AppRoute.ReportEditor>()
                            val editorFactory = remember(args.reportId, container) {
                                object : ViewModelProvider.Factory {
                                    @Suppress("UNCHECKED_CAST")
                                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                                        return ReportEditorViewModel(args.reportId, container) as T
                                    }
                                }
                            }
                            val editorVm: ReportEditorViewModel = viewModel(
                                key = "report_editor_${args.reportId}",
                                factory = editorFactory,
                            )
                            ReportEditorScreen(
                                viewModel = editorVm,
                                onBack = { navController.popBackStack() },
                                onOpenVisualProductPicker = { rid -> navController.navigate(AppRoute.ReportProductPicker(rid)) },
                                onOpenScannerForReport = { rid -> navController.navigate(AppRoute.BarcodeScanner(targetReportId = rid)) },
                                onOpenPdfPreview = { rid, path -> navController.navigate(AppRoute.PdfPreview(rid, path)) },
                                onCreatedNewVersion = { newRid -> navController.navigate(AppRoute.ReportEditor(newRid)) },
                                onOpenSubscription = { navController.navigate(AppRoute.Subscription) },
                            )
                        }

                        composable<AppRoute.ReportProductPicker> { entry ->
                            val args = entry.toRoute<AppRoute.ReportProductPicker>()
                            ReportProductPickerScreen(
                                reportId = args.reportId,
                                container = container,
                                onBack = { navController.popBackStack() },
                                onOpenScannerForReport = { rid -> navController.navigate(AppRoute.BarcodeScanner(targetReportId = rid)) },
                            )
                        }

                        composable<AppRoute.PdfPreview> { entry ->
                            val args = entry.toRoute<AppRoute.PdfPreview>()
                            PdfPreviewScreen(
                                reportId = args.reportId,
                                initialPdfPath = args.pdfPath,
                                inventorySessionId = args.inventorySessionId,
                                container = container,
                                onBack = { navController.popBackStack() },
                                onOpenPdfEditor = { path -> navController.navigate(AppRoute.PdfEditor(initialPdfPath = path)) },
                            )
                        }

                        composable<AppRoute.Templates> {
                            val vm: TemplatesViewModel = viewModel(factory = factory)
                            TemplatesScreen(
                                viewModel = vm,
                                onBack = if (navController.previousBackStackEntry != null) {
                                    { navController.popBackStack() }
                                } else null,
                                onOpenNewReport = { rid -> navController.navigate(AppRoute.ReportEditor(rid)) },
                                onOpenSubscription = { navController.navigate(AppRoute.Subscription) },
                            )
                        }

                        composable<AppRoute.LabelPrinting> {
                            val vm: LabelPrintingViewModel = viewModel(factory = factory)
                            LabelPrintingScreen(
                                viewModel = vm,
                                onBack = { navController.popBackStack() },
                            )
                        }

                        composable<AppRoute.BackupRestore> {
                            val vm: BackupRestoreViewModel = viewModel(factory = factory)
                            BackupRestoreScreen(
                                viewModel = vm,
                                onBack = { navController.popBackStack() },
                                onOpenDiagnostics = { navController.navigate(AppRoute.ErrorDiagnostics) },
                            )
                        }

                        composable<AppRoute.Settings> {
                            val vm: SettingsViewModel = viewModel(factory = factory)
                            SettingsScreen(
                                viewModel = vm,
                                onBack = null,
                                onOpenBackup = { navController.navigate(AppRoute.BackupRestore) },
                                onOpenAbout = { navController.navigate(AppRoute.AboutApp) },
                                onOpenDiagnostics = { navController.navigate(AppRoute.ErrorDiagnostics) },
                                onOpenAccount = { navController.navigate(AppRoute.Auth) },
                                onOpenSubscription = { navController.navigate(AppRoute.Subscription) },
                                onOpenPrivacy = { navController.navigate(AppRoute.Privacy) },
                            )
                        }

                        composable<AppRoute.ErrorDiagnostics> {
                            val vm: ErrorDiagnosticsViewModel = viewModel(factory = factory)
                            ErrorDiagnosticsScreen(
                                viewModel = vm,
                                onBack = { navController.popBackStack() },
                            )
                        }

                        composable<AppRoute.ImageManager> {
                            ImageManagerScreen(
                                viewModel = productsVm,
                                onBack = { navController.popBackStack() },
                                onOpenProductDetail = { pid -> navController.navigate(AppRoute.ProductDetail(pid)) },
                                onOpenImageEditor = { imgId -> navController.navigate(AppRoute.ImageEditor(imgId)) },
                            )
                        }

                        composable<AppRoute.ImageEditor> { entry ->
                            val args = entry.toRoute<AppRoute.ImageEditor>()
                            ImageEditorScreen(
                                imageId = args.imageId,
                                container = container,
                                onBack = { navController.popBackStack() },
                                onSaved = { navController.popBackStack() },
                            )
                        }

                        composable<AppRoute.PdfEditor> { entry ->
                            val args = entry.toRoute<AppRoute.PdfEditor>()
                            val pdfVm: PdfEditorViewModel = viewModel(
                                key = "pdf_editor_${args.documentId}_${args.initialPdfPath.hashCode()}",
                                factory = factory,
                            )
                            PdfEditorScreen(
                                initialPdfPath = args.initialPdfPath,
                                documentId = args.documentId,
                                container = container,
                                viewModel = pdfVm,
                                onBack = { navController.popBackStack() },
                            )
                        }

                        composable<AppRoute.AboutApp> {
                            AboutAppScreen(
                                onBack = { navController.popBackStack() },
                                onOpenPrivacyPolicy = { navController.navigate(AppRoute.Privacy) },
                            )
                        }

                        composable<AppRoute.Auth> {
                            val authVm: AuthViewModel = viewModel(factory = factory)
                            AuthScreen(
                                viewModel = authVm,
                                onBack = { navController.popBackStack() },
                                onContinueLocally = { navController.popBackStack() },
                                onOpenAccountManagement = { navController.navigate(AppRoute.AccountManagement) },
                                onOpenPrivacyPolicy = { navController.navigate(AppRoute.Privacy) },
                            )
                        }

                        composable<AppRoute.AccountManagement> {
                            val authVm: AuthViewModel = viewModel(factory = factory)
                            AccountManagementScreen(
                                viewModel = authVm,
                                activeWorkspaceLabel = container.workspaceIdentity.displayLabel,
                                onBack = { navController.popBackStack() },
                                onOpenAuthScreen = { navController.navigate(AppRoute.Auth) },
                                onOpenPrivacyPolicy = { navController.navigate(AppRoute.Privacy) },
                            )
                        }

                        composable<AppRoute.Subscription> {
                            val subVm: SubscriptionViewModel = viewModel(factory = factory)
                            SubscriptionScreen(
                                viewModel = subVm,
                                onBack = { navController.popBackStack() },
                                onOpenSettingsAdmin = { navController.navigate(AppRoute.Settings) },
                                onOpenPrivacyPolicy = { navController.navigate(AppRoute.Privacy) },
                            )
                        }

                        composable<AppRoute.Privacy> {
                            PrivacyAndDeletionScreen(
                                billingGateway = container.billingGateway,
                                onBack = { navController.popBackStack() },
                                onOpenAccountManagement = { navController.navigate(AppRoute.AccountManagement) },
                            )
                        }
                    }
                }
            }
        }
    }

    previousCrashAlert?.let { crash ->
        AlertDialog(
            onDismissRequest = { container.globalErrorMonitor.dismissPreviousCrashAlert() },
            title = { Text("تم رصد انهيار في الجلسة السابقة") },
            text = {
                Text(
                    "توقف التطبيق في الجلسة السابقة عند: ${crash.screenName}\n" +
                        "الخطأ: ${crash.errorType} — ${crash.originalMessage.take(180)}\n" +
                        "يمكنك مراجعة التفاصيل أو تصدير حزمة التشخيص الآمنة.",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        container.globalErrorMonitor.dismissPreviousCrashAlert()
                        navController.navigate(AppRoute.ErrorDiagnostics)
                    },
                ) {
                    Text("فتح مركز التشخيص")
                }
            },
            dismissButton = {
                androidx.compose.foundation.layout.Row {
                    TextButton(
                        onClick = {
                            scope.launch {
                                val res = withContext(Dispatchers.IO) {
                                    container.diagnosticExportEngine.exportDiagnosticBundleZip()
                                }
                                container.globalErrorMonitor.dismissPreviousCrashAlert()
                                res.getOrNull()?.let { zip ->
                                    shareFileViaProvider(context, zip, "application/zip", "مشاركة تقرير التشخيص (ZIP)")
                                }
                            }
                        },
                    ) {
                        Text("تصدير التقرير")
                    }
                    TextButton(onClick = { container.globalErrorMonitor.dismissPreviousCrashAlert() }) {
                        Text("إغلاق")
                    }
                }
            },
        )
    }
}
