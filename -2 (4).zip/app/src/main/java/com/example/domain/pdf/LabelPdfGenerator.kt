package com.example.domain.pdf

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.storage.MediaStorageManager
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.CellAlignment
import com.example.domain.model.MM_TO_PT
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.ceil
import kotlin.math.floor

data class LabelPrintItem(
    val productName: String,
    val barcodeValue: String,
    val barcodeFormat: BarcodeFormatType,
    val priceText: String = "",
    val copies: Int = 1,
)

data class LabelSheetConfig(
    val labelWidthMm: Float = 50f,
    val labelHeightMm: Float = 30f,
    val pageWidthMm: Float = 210f,
    val pageHeightMm: Float = 297f,
    val marginMm: Float = 8f,
    val gapMm: Float = 3f,
    val showProductName: Boolean = true,
    val showBarcodeValue: Boolean = true,
    val showPrice: Boolean = true,
    val quietZoneModules: Int = 8,
)

class LabelPdfGenerator(
    private val context: Context,
    private val mediaStorage: MediaStorageManager,
    private val sessionFactory: PdfSessionFactory = AndroidPdfSessionFactory(),
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    fun generateLabelsPdf(
        items: List<LabelPrintItem>,
        config: LabelSheetConfig,
        fileName: String = "barcode_labels",
    ): PdfGenerationResult {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.LABEL_PRINTING,
            moduleName = DiagnosticModules.PDF,
            operationName = "إنشاء ملصقات الباركود PDF",
            initialStage = "تهيئة شبكة الملصقات (${items.size} صنف)",
        )
        val expanded = items.flatMap { item ->
            List(item.copies.coerceIn(1, 500)) { item }
        }
        val pageW = (config.pageWidthMm * MM_TO_PT).let { ceil(it).toInt() }.coerceAtLeast(120)
        val pageH = (config.pageHeightMm * MM_TO_PT).let { ceil(it).toInt() }.coerceAtLeast(120)
        val marginPt = config.marginMm * MM_TO_PT
        val gapPt = config.gapMm * MM_TO_PT
        val labelW = (config.labelWidthMm * MM_TO_PT).coerceAtLeast(48f)
        val labelH = (config.labelHeightMm * MM_TO_PT).coerceAtLeast(36f)

        val colsPerRow = floor(((pageW - marginPt * 2f + gapPt) / (labelW + gapPt))).toInt().coerceAtLeast(1)
        val rowsPerPage = floor(((pageH - marginPt * 2f + gapPt) / (labelH + gapPt))).toInt().coerceAtLeast(1)
        val labelsPerPage = colsPerRow * rowsPerPage

        val typeface = try {
            ResourcesCompat.getFont(context, R.font.cairo)
        } catch (_: Exception) {
            Typeface.DEFAULT
        }

        val pdfDocument = sessionFactory.create()
        val warnings = mutableListOf<String>()
        try {
            val chunks = if (expanded.isEmpty()) listOf(emptyList()) else expanded.chunked(labelsPerPage)
            trace?.stage("رسم ملصقات الباركود", "ملصقات=${expanded.size} | صفحات=${chunks.size}")
            chunks.forEachIndexed { pageIdx, chunk ->
                val canvas = pdfDocument.beginPage(pageW, pageH, pageIdx + 1)
                canvas.drawColor(Color.WHITE)

                val borderPaint = Paint().apply {
                    color = Color.rgb(203, 213, 225)
                    style = Paint.Style.STROKE
                    strokeWidth = 0.5f
                }
                val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.BLACK
                    textSize = (labelH * 0.14f).coerceIn(6.5f, 11f)
                    this.typeface = Typeface.create(typeface, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                }
                val pricePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(15, 23, 42)
                    textSize = (labelH * 0.13f).coerceIn(6f, 10f)
                    this.typeface = typeface
                    textAlign = Paint.Align.CENTER
                }

                chunk.forEachIndexed { idx, label ->
                    val r = idx / colsPerRow
                    val c = idx % colsPerRow
                    val x = marginPt + c * (labelW + gapPt)
                    val y = marginPt + r * (labelH + gapPt)
                    val box = RectF(x, y, x + labelW, y + labelH)
                    canvas.drawRoundRect(box, 3f, 3f, borderPaint)

                    var topCursor = y + 4f
                    if (config.showProductName && label.productName.isNotBlank()) {
                        val clipped = label.productName.take(28)
                        canvas.drawText(clipped, box.centerX(), topCursor + titlePaint.textSize, titlePaint)
                        topCursor += titlePaint.textSize + 3f
                    }
                    val bottomReserved = if (config.showPrice && label.priceText.isNotBlank()) pricePaint.textSize + 5f else 3f
                    val barcodeRect = RectF(
                        box.left + 4f,
                        topCursor,
                        box.right - 4f,
                        (box.bottom - bottomReserved).coerceAtLeast(topCursor + 12f),
                    )
                    val ok = BarcodeEngine.drawVectorOnCanvas(
                        canvas = canvas,
                        value = label.barcodeValue,
                        format = label.barcodeFormat,
                        bounds = barcodeRect,
                        showText = config.showBarcodeValue,
                        textSizePt = (labelH * 0.12f).coerceIn(5.5f, 9f),
                        quietZoneModules = config.quietZoneModules,
                        alignment = CellAlignment.CENTER,
                    )
                    if (!ok) {
                        warnings.add("مقاس الملصق غير كافٍ للباركود: ${label.barcodeValue}")
                    }
                    if (config.showPrice && label.priceText.isNotBlank()) {
                        canvas.drawText(label.priceText, box.centerX(), box.bottom - 3f, pricePaint)
                    }
                }
                pdfDocument.endPage()
            }

            trace?.stage("حفظ ملف ملصقات PDF")
            val clean = fileName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "labels" }
            val outFile = File(mediaStorage.exportsDir, if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
            FileOutputStream(outFile).use { fos -> pdfDocument.writeTo(fos) }
            trace?.succeed("تم حفظ ${outFile.name} (${chunks.size} صفحة)")
            return PdfGenerationResult(outFile, chunks.size, warnings.distinct())
        } catch (c: kotlinx.coroutines.CancellationException) {
            trace?.cancel("تم إلغاء إنشاء ملصقات الباركود")
            throw c
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.LABEL_PRINTING,
                moduleName = DiagnosticModules.PDF,
                operationName = "إنشاء ملصقات الباركود PDF",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر إنشاء ملصقات PDF", linkedErrorId = err?.errorId.orEmpty())
            throw t
        } finally {
            pdfDocument.close()
        }
    }

    fun printPdfFile(
        pdfFile: File,
        jobName: String,
        activityContext: Context? = null,
        isLandscape: Boolean = false,
    ): PrintDispatchResult {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.LABEL_PRINTING,
            moduleName = DiagnosticModules.PDF,
            operationName = "طباعة ملصقات PDF ($jobName)",
            initialStage = "إرسال مهمة الطباعة للنظام",
        )
        val res = SafePdfPrintHelper.printPdfWithActivity(
            context = activityContext ?: context,
            pdfFile = pdfFile,
            jobName = jobName,
            isLandscape = isLandscape,
        )
        when (res) {
            is PrintDispatchResult.Started -> trace?.succeed("تم إرسال مهمة الطباعة (${res.pageCount} صفحة)")
            is PrintDispatchResult.Error -> {
                val err = errorMonitor?.recordCustomError(
                    screenName = ScreenNames.LABEL_PRINTING,
                    moduleName = DiagnosticModules.PDF,
                    operationName = "طباعة ملصقات الباركود PDF",
                    errorType = "PrintDispatchError",
                    message = res.message,
                    linkedOperationId = trace?.operationId.orEmpty(),
                )
                trace?.fail(res.message, linkedErrorId = err?.errorId.orEmpty())
            }
        }
        return res
    }
}
