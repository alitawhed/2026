package com.example.domain.model

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import com.example.BuildConfig

/**
 * Immutable programmatic developer & application identity.
 * Deliberately decoupled from Room AppSettings, Company Info, Products,
 * Inventory, Reports, Excel Imports, PDF Exports, and Backups.
 *
 * Displayed EXCLUSIVELY on the "About App" (حول التطبيق) screen.
 */
object DeveloperIdentity {
    const val APP_NAME = "مدير التقارير"
    const val APP_TAGLINE = "إدارة ذكية للمنتجات والجرد والتقارير"

    const val ABOUT_DESCRIPTION =
        "مدير التقارير هو تطبيق متكامل يهدف إلى تسهيل إدارة بيانات المنتجات وتنظيم عمليات الجرد وإعداد التقارير بطريقة عملية واحترافية.\n\n" +
            "يوفر التطبيق أدوات لإضافة المنتجات وإدارة بياناتها وصورها، والبحث عنها باستخدام الباركود ومسحه بكاميرا الهاتف، وتنظيم عمليات الجرد وتسجيل الكميات، مع إمكانية إعداد تقارير احترافية وتصديرها بصيغ PDF وExcel وطباعتها بسهولة.\n\n" +
            "كما يهتم التطبيق بحماية البيانات وسهولة الوصول إليها، من خلال نظام النسخ الاحتياطي واستعادة البيانات، ليكون أداة عملية تساعد المستخدم على تنظيم أعماله وتحسين دقة وسرعة إنجاز المهام اليومية."

    const val DEVELOPER_NAME = "المهندس علي توحيد"
    const val DEVELOPER_EMAIL = "s2x518u@gmail.com"
    const val PRIMARY_PHONE_DISPLAY = "00966573928022"
    const val SECONDARY_PHONE_DISPLAY = "00967771084252"

    const val PRIMARY_WHATSAPP_WA_NUMBER = "966573928022"
    const val SECONDARY_WHATSAPP_WA_NUMBER = "967771084252"

    const val PRIMARY_WHATSAPP_BASE_URL = "https://wa.me/$PRIMARY_WHATSAPP_WA_NUMBER"
    const val SECONDARY_WHATSAPP_BASE_URL = "https://wa.me/$SECONDARY_WHATSAPP_WA_NUMBER"

    const val PRIMARY_WHATSAPP_MESSAGE =
        "مرحباً مهندس علي، أتواصل معك بخصوص تطبيق مدير التقارير، وأرغب في الاستفسار عن التطبيق أو تقديم ملاحظة أو طلب مساعدة"

    const val SECONDARY_WHATSAPP_MESSAGE =
        "مرحباً، أتواصل مع مطور تطبيق مدير التقارير بخصوص الدعم والاستفسارات"

    const val EMAIL_SUBJECT = "استفسار بخصوص تطبيق مدير التقارير"
    const val EMAIL_BODY = "مرحباً، لدي استفسار بخصوص تطبيق مدير التقارير"

    const val SIGNATURE_LINE = "تطوير وبرمجة المهندس علي توحيد"
    const val COPYRIGHT_LINE = "© جميع الحقوق محفوظة – مدير التقارير"

    data class AppVersionInfo(
        val versionName: String,
        val versionCode: Long,
    )

    fun resolveAppVersionInfo(context: Context): AppVersionInfo {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, 0)
            }
            val name = pkgInfo.versionName?.takeIf { it.isNotBlank() } ?: BuildConfig.VERSION_NAME
            val code = PackageInfoCompat.getLongVersionCode(pkgInfo).takeIf { it > 0L }
                ?: BuildConfig.VERSION_CODE.toLong()
            AppVersionInfo(versionName = name, versionCode = code)
        } catch (_: Exception) {
            AppVersionInfo(
                versionName = BuildConfig.VERSION_NAME.ifBlank { "1.0" },
                versionCode = BuildConfig.VERSION_CODE.toLong().coerceAtLeast(1L),
            )
        }
    }

    fun buildWhatsAppUri(isPrimary: Boolean): Uri {
        val base = if (isPrimary) PRIMARY_WHATSAPP_BASE_URL else SECONDARY_WHATSAPP_BASE_URL
        val msg = if (isPrimary) PRIMARY_WHATSAPP_MESSAGE else SECONDARY_WHATSAPP_MESSAGE
        return Uri.parse("$base?text=${Uri.encode(msg)}")
    }

    fun buildEmailMailtoUri(): Uri {
        return Uri.parse(
            "mailto:$DEVELOPER_EMAIL?subject=${Uri.encode(EMAIL_SUBJECT)}&body=${Uri.encode(EMAIL_BODY)}",
        )
    }

    fun buildEmailWebFallbackUri(): Uri {
        return Uri.parse(
            "https://mail.google.com/mail/?view=cm&fs=1&to=${Uri.encode(DEVELOPER_EMAIL)}&su=${Uri.encode(EMAIL_SUBJECT)}&body=${Uri.encode(EMAIL_BODY)}",
        )
    }

    fun buildDialUri(isPrimary: Boolean): Uri {
        val num = if (isPrimary) PRIMARY_PHONE_DISPLAY else SECONDARY_PHONE_DISPLAY
        return Uri.parse("tel:$num")
    }

    fun buildWhatsAppIntent(context: Context, isPrimary: Boolean): Intent {
        val uri = buildWhatsAppUri(isPrimary)
        val installedWhatsAppPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
            isPackageInstalled(context, pkg)
        }
        return Intent(Intent.ACTION_VIEW, uri).apply {
            if (installedWhatsAppPkg != null) {
                setPackage(installedWhatsAppPkg)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildBrowserWhatsAppIntent(isPrimary: Boolean): Intent {
        return Intent(Intent.ACTION_VIEW, buildWhatsAppUri(isPrimary)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildEmailIntent(): Intent {
        return Intent(Intent.ACTION_SENDTO, buildEmailMailtoUri()).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildEmailBrowserFallbackIntent(): Intent {
        return Intent(Intent.ACTION_VIEW, buildEmailWebFallbackUri()).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildDialIntent(isPrimary: Boolean): Intent {
        return Intent(Intent.ACTION_DIAL, buildDialUri(isPrimary)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun launchWhatsApp(context: Context, isPrimary: Boolean): Boolean {
        return try {
            context.startActivity(buildWhatsAppIntent(context, isPrimary))
            true
        } catch (_: ActivityNotFoundException) {
            try {
                context.startActivity(buildBrowserWhatsAppIntent(isPrimary))
                true
            } catch (_: Exception) {
                false
            }
        } catch (_: Exception) {
            try {
                context.startActivity(buildBrowserWhatsAppIntent(isPrimary))
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    fun launchEmail(context: Context): Boolean {
        val emailIntent = buildEmailIntent()
        val hasEmailApp = runCatching {
            context.packageManager.resolveActivity(emailIntent, 0) != null
        }.getOrDefault(false)

        if (hasEmailApp) {
            try {
                context.startActivity(emailIntent)
                return true
            } catch (_: Exception) {
                // Fall through to browser fallback below
            }
        }

        return try {
            context.startActivity(buildEmailBrowserFallbackIntent())
            true
        } catch (_: Exception) {
            // Last resort try emailIntent directly in case resolveActivity was filtered
            try {
                context.startActivity(emailIntent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    fun launchDialer(context: Context, isPrimary: Boolean): Boolean {
        return try {
            context.startActivity(buildDialIntent(isPrimary))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun isPackageInstalled(context: Context, packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
