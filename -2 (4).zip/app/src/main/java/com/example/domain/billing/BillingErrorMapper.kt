package com.example.domain.billing

import com.android.billingclient.api.BillingClient.BillingResponseCode
import com.android.billingclient.api.BillingClient.OnPurchasesUpdatedSubResponseCode
import com.android.billingclient.api.BillingResult

object BillingErrorMapper {

    fun toArabicMessage(result: BillingResult): String {
        val subCode = result.onPurchasesUpdatedSubResponseCode
        if (subCode == OnPurchasesUpdatedSubResponseCode.PAYMENT_DECLINED_DUE_TO_INSUFFICIENT_FUNDS) {
            return "تعذر إتمام الدفع بسبب عدم كفاية الرصيد في وسيلة الدفع."
        }
        if (subCode == OnPurchasesUpdatedSubResponseCode.USER_INELIGIBLE) {
            return "هذا العرض الترويجي أو التجربة المجانية غير مؤهل لهذا الحساب؛ يمكنك الاشتراك بالخطة الأساسية."
        }
        return toArabicMessage(result.responseCode, result.debugMessage)
    }

    fun toArabicMessage(responseCode: Int, debugMessage: String = ""): String {
        return when (responseCode) {
            BillingResponseCode.OK -> "تمت العملية بنجاح."
            BillingResponseCode.USER_CANCELED -> "تم إلغاء عملية الاشتراك من قِبل المستخدم."
            BillingResponseCode.SERVICE_UNAVAILABLE,
            BillingResponseCode.NETWORK_ERROR,
            -> "تعذر الاتصال بخدمة Google Play. تحقق من اتصال الإنترنت وحاول مجدداً."
            BillingResponseCode.SERVICE_DISCONNECTED -> "انقطع الاتصال بخدمة Google Play؛ جاري إعادة المحاولة."
            BillingResponseCode.BILLING_UNAVAILABLE -> "خدمة الفوترة عبر Google Play غير متاحة على هذا الجهاز أو الحساب."
            BillingResponseCode.ITEM_UNAVAILABLE -> "باقة الاشتراك المحددة غير متاحة حالياً في Google Play Console أو لا تطابق معرف المنتج المُعد."
            BillingResponseCode.DEVELOPER_ERROR -> "إعدادات الفوترة أو معرفات المنتجات غير مكتملة في Google Play Console (راجع معرف المنتج والخطة الأساسية)."
            BillingResponseCode.ITEM_ALREADY_OWNED -> "لديك بالفعل اشتراك نشط في هذا المنتج؛ استخدم خيار «استعادة المشتريات» لتفعيله."
            BillingResponseCode.ITEM_NOT_OWNED -> "لم يتم العثور على ملكية نشطة لهذا الاشتراك."
            BillingResponseCode.FEATURE_NOT_SUPPORTED -> "إصدار متجر Google Play على هذا الجهاز لا يدعم ميزة الاشتراكات المطلوبة."
            BillingResponseCode.ERROR -> {
                if (debugMessage.isNotBlank()) {
                    "حدث خطأ في خدمة Google Play Billing ($debugMessage)."
                } else {
                    "حدث خطأ غير متوقع في خدمة Google Play Billing."
                }
            }
            else -> "تعذر إتمام عملية الفوترة (رمز الاستجابة: $responseCode)."
        }
    }
}
