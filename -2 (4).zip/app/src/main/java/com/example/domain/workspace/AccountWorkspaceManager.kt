package com.example.domain.workspace

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.di.AppContainer
import com.example.di.SharedAppServices
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.AuthUserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest

sealed interface WorkspaceIdentity {
    val workspaceId: String
    val databaseName: String
    val displayLabel: String
    val ownerUid: String?

    data object Local : WorkspaceIdentity {
        override val workspaceId: String = "local"
        override val databaseName: String = AppDatabase.LEGACY_DATABASE_NAME
        override val displayLabel: String = "مساحة العمل المحلية (بيانات الجهاز)"
        override val ownerUid: String? = null
    }

    data class Account(
        val uid: String,
        val safeKey: String,
        val email: String = "",
    ) : WorkspaceIdentity {
        override val workspaceId: String = "uid_$safeKey"
        override val databaseName: String = "${AppDatabase.LEGACY_DATABASE_NAME}_$safeKey"
        override val displayLabel: String =
            if (email.isNotBlank()) "مساحة الحساب: $email" else "مساحة الحساب (${uid.take(8)})"
        override val ownerUid: String = uid
    }
}

data class WorkspaceDiskSummary(
    val workspaceId: String,
    val databaseName: String,
    val existsOnDisk: Boolean,
    val storageDirPath: String,
)

/**
 * Coordinates strict local-data isolation across device-local mode and authenticated accounts
 * without altering `report_manager_db` schema (v11) or `BackupRestoreEngine` (v6).
 *
 * Guarantees:
 * - Pre-existing device data in `report_manager_db` and `context.filesDir` remains untouched as [WorkspaceIdentity.Local].
 * - Legacy data is NEVER auto-moved, merged, or linked into newly signed-in accounts.
 * - Switching from Account A to Account B isolates both Room DB and media directories.
 * - Signing out, deleting a Firebase account, or subscription expiration NEVER deletes any local database, image, or ZIP backup.
 */
class AccountWorkspaceManager(
    context: Context,
    private val authGateway: AuthGateway,
    private val sharedServices: SharedAppServices,
) {
    private val appContext: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val containerLock = Any()
    private val workspaceContainers = mutableMapOf<String, AppContainer>()

    private val _activeWorkspace = MutableStateFlow(resolveIdentity(authGateway.currentUser()))
    val activeWorkspace: StateFlow<WorkspaceIdentity> = _activeWorkspace.asStateFlow()

    init {
        scope.launch {
            authGateway.authStateFlow.collect { user ->
                val next = resolveIdentity(user)
                if (_activeWorkspace.value.workspaceId != next.workspaceId ||
                    _activeWorkspace.value.displayLabel != next.displayLabel
                ) {
                    _activeWorkspace.value = next
                }
            }
        }
    }

    fun syncWithCurrentUser(): WorkspaceIdentity {
        val next = resolveIdentity(authGateway.currentUser())
        _activeWorkspace.value = next
        return next
    }

    fun resolveIdentity(user: AuthUserProfile?): WorkspaceIdentity {
        if (user == null || user.uid.isBlank()) {
            return WorkspaceIdentity.Local
        }
        return WorkspaceIdentity.Account(
            uid = user.uid,
            safeKey = sanitizeUidToWorkspaceKey(user.uid),
            email = user.email,
        )
    }

    fun resolveStorageDir(identity: WorkspaceIdentity): File {
        return when (identity) {
            is WorkspaceIdentity.Local -> appContext.filesDir
            is WorkspaceIdentity.Account -> File(appContext.filesDir, "workspaces/${identity.safeKey}").apply {
                mkdirs()
            }
        }
    }

    fun containerForWorkspace(identity: WorkspaceIdentity): AppContainer {
        return synchronized(containerLock) {
            workspaceContainers[identity.workspaceId] ?: AppContainer(
                context = appContext,
                workspaceIdentity = identity,
                sharedServices = sharedServices,
            ).also {
                workspaceContainers[identity.workspaceId] = it
            }
        }
    }

    fun currentContainer(): AppContainer = containerForWorkspace(activeWorkspace.value)

    fun inspectWorkspaceDiskSummary(identity: WorkspaceIdentity): WorkspaceDiskSummary {
        val dbFile = appContext.getDatabasePath(identity.databaseName)
        val storageDir = resolveStorageDir(identity)
        return WorkspaceDiskSummary(
            workspaceId = identity.workspaceId,
            databaseName = identity.databaseName,
            existsOnDisk = dbFile.exists() || storageDir.exists(),
            storageDirPath = storageDir.absolutePath,
        )
    }

    companion object {
        fun sanitizeUidToWorkspaceKey(uid: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(uid.trim().toByteArray(Charsets.UTF_8))
            return digest.take(12).joinToString("") { "%02x".format(it) }
        }
    }
}
