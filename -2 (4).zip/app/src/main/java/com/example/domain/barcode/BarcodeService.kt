package com.example.domain.barcode

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.BarcodeFormatType
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.math.abs

enum class BarcodeFormatChangeScope(val arabicLabel: String, val description: String) {
    CURRENT_PRODUCT(
        arabicLabel = "المنتج الحالي فقط",
        description = "تطبيق التغيير على هذا الباركود للمنتج الحالي دون المساس ببقية المنتجات",
    ),
    SELECTED_PRODUCTS(
        arabicLabel = "المنتجات المحددة",
        description = "تطبيق التغيير على المنتجات المحددة المتوافقة مع تخطي غير المتوافق دون تغيير الأرقام",
    ),
    CURRENT_INVENTORY_ITEM(
        arabicLabel = "بند الجرد الحالي فقط",
        description = "تحديث عرض الباركود لهذا البند داخل كشف الجرد الحالي فقط",
    ),
    CURRENT_INVENTORY_SESSION(
        arabicLabel = "منتجات عملية الجرد الحالية فقط",
        description = "تحديث نوع الباركود لبنود كشف الجرد الحالي المتوافقة فقط",
    ),
    CURRENT_REPORT_ITEM(
        arabicLabel = "صف التقرير الحالي فقط",
        description = "تحديث نوع الباركود لنسخة هذا المنتج داخل التقرير الحالي فقط",
    ),
    CURRENT_REPORT(
        arabicLabel = "جميع عناصر التقرير الحالي",
        description = "تحديث نوع الباركود لكل البنود المتوافقة داخل التقرير الحالي",
    ),
    CURRENT_LABEL_ONLY(
        arabicLabel = "الملصق الحالي فقط",
        description = "تغيير نوع المعاينة والطباعة للملصق المحدد حالياً دون تعديل سجل المنتج",
    ),
    FUTURE_DEFAULT_SETTING(
        arabicLabel = "المنتجات الداخلية الجديدة مستقبلاً",
        description = "تعيين هذا النوع كإعداد افتراضي لجميع الباركودات الداخلية والمنتجات الجديدة",
    ),
}

data class BarcodeChangeResult(
    val success: Boolean,
    val message: String,
    val updatedCount: Int = 0,
    val skippedIncompatible: List<String> = emptyList(),
    val appliedFormat: BarcodeFormatType? = null,
)

data class IncompatibleBarcodeAuditItem(
    val productId: Long,
    val barcodeId: Long,
    val productName: String,
    val barcodeValue: String,
    val recordedFormat: String,
    val validationError: String,
    val suggestedCompatibleFormat: BarcodeFormatType,
)

data class BarcodeLegacyAuditReport(
    val totalProducts: Int,
    val totalBarcodes: Int,
    val missingImageCacheCount: Int,
    val unspecifiedFormatCount: Int,
    val staleInventorySnapshotCount: Int,
    val incompatibleBarcodes: List<IncompatibleBarcodeAuditItem>,
)

data class BarcodeRepairResult(
    val inspectedBarcodes: Int,
    val generatedImagesCount: Int,
    val fixedUnspecifiedFormatsCount: Int,
    val syncedInventorySnapshotsCount: Int,
    val convertedIncompatibleWithApprovalCount: Int,
    val skippedIncompatibleWithoutApprovalCount: Int,
    val skippedDetails: List<String>,
)

@Serializable
private data class BarcodeVersionIndexPayload(
    val versions: Map<String, Long> = emptyMap(),
)

/**
 * Centralized service managing barcode validation, format settings, format changes with explicit scopes,
 * isolated bitmap/disk caching (keyed by productId + value + format + imageVersion), and safe legacy repair.
 */
class BarcodeService(
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val productDao = db.productDao()
    private val inventoryDao = db.inventoryDao()
    private val reportDao = db.reportDao()
    private val settingsDao = db.settingsDao()

    private val scope = CoroutineScope(
        SupervisorJob() +
            Dispatchers.IO +
            CoroutineExceptionHandler { _, _ -> /* Prevent background teardown crash propagation */ },
    )

    internal fun closeForTest() {
        runBlocking {
            scope.coroutineContext[Job]?.cancelAndJoin()
        }
    }
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val versionLock = Any()
    private val versionIndexFile: File by lazy {
        File(mediaStorage.barcodeCacheDir, "barcode_cache_versions.json")
    }
    private var versionMapLoaded = false
    private val versionMap = linkedMapOf<String, Long>()

    private val _cacheGeneration = MutableStateFlow(0L)
    val cacheGeneration: StateFlow<Long> = _cacheGeneration.asStateFlow()

    val defaultBarcodeTypeFlow: StateFlow<BarcodeFormatType> = settingsDao.observeSettings()
        .map { entity ->
            BarcodeEngine.parseFormatOrNull(entity?.defaultBarcodeType) ?: BarcodeFormatType.CODE_128
        }
        .catch { /* Ignore database closed cleanly on teardown */ }
        .stateIn(
            scope = scope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = BarcodeFormatType.CODE_128,
        )

    private val memoryCache: LruCache<String, Bitmap> by lazy {
        val maxKb = ((Runtime.getRuntime().maxMemory() / 1024L) / 16L).toInt().coerceIn(2048, 8192)
        object : LruCache<String, Bitmap>(maxKb) {
            override fun sizeOf(key: String, value: Bitmap): Int =
                (value.allocationByteCount / 1024).coerceAtLeast(1)
        }
    }

    suspend fun getDefaultBarcodeType(): BarcodeFormatType = withContext(Dispatchers.IO) {
        val saved = settingsDao.getSettingsOnce()?.defaultBarcodeType
        BarcodeEngine.parseFormatOrNull(saved) ?: BarcodeFormatType.CODE_128
    }

    suspend fun updateDefaultBarcodeFormat(targetFormat: BarcodeFormatType): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                db.withTransaction {
                    val current = settingsDao.getSettingsOnce()
                    val now = System.currentTimeMillis()
                    if (current == null) {
                        settingsDao.saveSettings(
                            AppSettingsEntity(
                                defaultBarcodeType = targetFormat.name,
                                updatedAt = now,
                            ),
                        )
                    } else {
                        settingsDao.updateDefaultBarcodeType(
                            defaultBarcodeType = targetFormat.name,
                            updatedAt = now,
                        )
                    }
                }
                Result.success(Unit)
            } catch (e: Exception) {
                errorMonitor?.recordError(
                    e,
                    ScreenNames.SETTINGS,
                    DiagnosticModules.SETTINGS,
                    "تحديث نوع الباركود الافتراضي",
                )
                Result.failure(e)
            }
        }

    fun resolveDefaultForNewBarcode(value: String): BarcodeFormatType {
        val currentDefault = defaultBarcodeTypeFlow.value
        return BarcodeEngine.resolveCompatibleDefaultFormat(value, currentDefault)
    }

    suspend fun resolveDefaultForNewBarcodeAsync(value: String): BarcodeFormatType {
        val savedDefault = getDefaultBarcodeType()
        return BarcodeEngine.resolveCompatibleDefaultFormat(value, savedDefault)
    }

    fun currentImageVersion(productId: Long?, barcodeValue: String): Long {
        val key = versionKey(productId, barcodeValue)
        synchronized(versionLock) {
            ensureVersionMapLoadedLocked()
            return versionMap[key] ?: 1L
        }
    }

    fun buildCacheKey(
        productId: Long?,
        barcodeValue: String,
        format: BarcodeFormatType,
        showText: Boolean = true,
        quietZoneModules: Int = 12,
        dpi: Int = 300,
        baseWidthPx: Int = 720,
        baseHeightPx: Int = 260,
        imageVersion: Long = currentImageVersion(productId, barcodeValue),
    ): String {
        val pid = productId ?: 0L
        return "$pid|${barcodeValue.trim()}|${format.name}|v$imageVersion|t=$showText|q=$quietZoneModules|dpi=$dpi|w=$baseWidthPx|h=$baseHeightPx"
    }

    suspend fun getOrGenerateBarcodeBitmap(
        productId: Long?,
        barcodeValue: String,
        format: BarcodeFormatType,
        baseWidthPx: Int = 720,
        baseHeightPx: Int = 260,
        showText: Boolean = true,
        quietZoneModules: Int = 12,
        dpi: Int = 300,
        forceRegenerate: Boolean = false,
    ): Bitmap? = withContext(Dispatchers.IO) {
        val clean = barcodeValue.trim()
        if (clean.isEmpty()) return@withContext null
        if (!BarcodeEngine.isCompatible(clean, format)) return@withContext null

        val version = currentImageVersion(productId, clean)
        val cacheKey = buildCacheKey(
            productId = productId,
            barcodeValue = clean,
            format = format,
            showText = showText,
            quietZoneModules = quietZoneModules,
            dpi = dpi,
            baseWidthPx = baseWidthPx,
            baseHeightPx = baseHeightPx,
            imageVersion = version,
        )

        if (!forceRegenerate) {
            memoryCache.get(cacheKey)?.let { cached ->
                if (!cached.isRecycled) return@withContext cached
            }
        }

        val diskFile = diskCacheFile(productId, clean, version, cacheKey)
        if (!forceRegenerate && diskFile.exists() && diskFile.length() > 0L) {
            val decoded = try {
                BitmapFactory.decodeFile(diskFile.absolutePath)
            } catch (_: Exception) {
                null
            }
            if (decoded != null) {
                memoryCache.put(cacheKey, decoded)
                return@withContext decoded
            }
        }

        val dpiScale = (dpi / 300f).coerceIn(0.65f, 2.5f)
        val scaledW = if (format.is2D) {
            (minOf(baseWidthPx, baseHeightPx) * dpiScale).toInt().coerceIn(220, 1800)
        } else {
            (baseWidthPx * dpiScale).toInt().coerceIn(320, 2400)
        }
        val scaledH = if (format.is2D) {
            scaledW
        } else {
            (baseHeightPx * dpiScale).toInt().coerceIn(140, 900)
        }

        val generated = BarcodeEngine.generateHighResBitmap(
            value = clean,
            format = format,
            widthPx = scaledW,
            heightPx = scaledH,
            showText = showText,
            quietZoneModules = quietZoneModules,
        ) ?: return@withContext null

        writeBitmapToDiskAtomic(generated, diskFile)
        memoryCache.put(cacheKey, generated)
        generated
    }

    /**
     * Generates/verifies PNG on disk without touching the in-memory LruCache (OOM-safe for bulk repair).
     */
    suspend fun ensureBarcodeDiskImageOnly(
        productId: Long?,
        barcodeValue: String,
        format: BarcodeFormatType,
        baseWidthPx: Int = 720,
        baseHeightPx: Int = 260,
        showText: Boolean = true,
        quietZoneModules: Int = 12,
        dpi: Int = 300,
    ): Boolean = withContext(Dispatchers.IO) {
        val clean = barcodeValue.trim()
        if (clean.isEmpty() || !BarcodeEngine.isCompatible(clean, format)) return@withContext false
        val version = currentImageVersion(productId, clean)
        val cacheKey = buildCacheKey(
            productId = productId,
            barcodeValue = clean,
            format = format,
            showText = showText,
            quietZoneModules = quietZoneModules,
            dpi = dpi,
            baseWidthPx = baseWidthPx,
            baseHeightPx = baseHeightPx,
            imageVersion = version,
        )
        val diskFile = diskCacheFile(productId, clean, version, cacheKey)
        if (diskFile.exists() && diskFile.length() > 0L) return@withContext true

        val generated = BarcodeEngine.generateHighResBitmap(
            value = clean,
            format = format,
            widthPx = if (format.is2D) minOf(baseWidthPx, baseHeightPx).coerceAtLeast(320) else baseWidthPx,
            heightPx = if (format.is2D) minOf(baseWidthPx, baseHeightPx).coerceAtLeast(320) else baseHeightPx,
            showText = showText,
            quietZoneModules = quietZoneModules,
        ) ?: return@withContext false
        val ok = writeBitmapToDiskAtomic(generated, diskFile)
        if (!generated.isRecycled) generated.recycle()
        ok
    }

    fun hasCachedDiskImage(
        productId: Long?,
        barcodeValue: String,
        format: BarcodeFormatType,
        baseWidthPx: Int = 720,
        baseHeightPx: Int = 260,
        showText: Boolean = true,
        quietZoneModules: Int = 12,
        dpi: Int = 300,
    ): Boolean {
        val clean = barcodeValue.trim()
        if (clean.isEmpty()) return false
        val version = currentImageVersion(productId, clean)
        val cacheKey = buildCacheKey(
            productId = productId,
            barcodeValue = clean,
            format = format,
            showText = showText,
            quietZoneModules = quietZoneModules,
            dpi = dpi,
            baseWidthPx = baseWidthPx,
            baseHeightPx = baseHeightPx,
            imageVersion = version,
        )
        val file = diskCacheFile(productId, clean, version, cacheKey)
        return file.exists() && file.length() > 0L
    }

    fun generateSvg(
        value: String,
        format: BarcodeFormatType,
        widthMm: Float = 50f,
        heightMm: Float = 22f,
        showText: Boolean = true,
        quietZoneModules: Int = 10,
    ): String = BarcodeEngine.generateSvg(value, format, widthMm, heightMm, showText, quietZoneModules)

    fun bumpVersionAndInvalidate(productId: Long?, barcodeValue: String): Long {
        val clean = barcodeValue.trim()
        val key = versionKey(productId, clean)
        val prefix = "bc_${entityPrefixHash(productId, clean)}_"
        val newVersion: Long
        synchronized(versionLock) {
            ensureVersionMapLoadedLocked()
            newVersion = (versionMap[key] ?: 1L) + 1L
            versionMap[key] = newVersion
            persistVersionMapLocked()
        }
        // Evict stale memory entries for this (productId, barcodeValue) pair cleanly
        val pidPrefix = "${productId ?: 0L}|$clean|"
        val snapshotKeys = memoryCache.snapshot().keys
        snapshotKeys.forEach { k ->
            if (k.startsWith(pidPrefix)) {
                memoryCache.remove(k)
            }
        }
        // Delete stale disk files for this entity
        runCatching {
            mediaStorage.barcodeCacheDir.listFiles { f ->
                f.name.startsWith(prefix) && f.name.endsWith(".png")
            }?.forEach { it.delete() }
        }
        _cacheGeneration.value = _cacheGeneration.value + 1L
        return newVersion
    }

    suspend fun prewarmProductBarcodeImage(
        productId: Long,
        barcodeValue: String,
        format: BarcodeFormatType,
    ) {
        if (barcodeValue.isBlank()) return
        ensureBarcodeDiskImageOnly(productId, barcodeValue, format)
    }

    // ==================== Scoped Format Switching ====================

    /**
     * Changes the format for ONE specific barcode record of ONE product without mutating barcodeValue.
     */
    suspend fun changeFormatForProductBarcode(
        productId: Long,
        barcodeId: Long,
        targetFormat: BarcodeFormatType,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "تغيير نوع باركود المنتج #$productId",
            initialStage = "التحقق من توافق الرقم مع ${targetFormat.arabicLabel}",
        )
        try {
            val barcode = productDao.getBarcodeById(barcodeId)
                ?: return@withContext BarcodeChangeResult(false, "سجل الباركود غير موجود")
            val validation = BarcodeEngine.validate(barcode.barcodeValue, targetFormat)
            if (!validation.isValid) {
                val msg = validation.errorMessage ?: "القيمة غير متوافقة مع ${targetFormat.arabicLabel}"
                trace?.warn(msg)
                return@withContext BarcodeChangeResult(false, msg)
            }

            val now = System.currentTimeMillis()
            db.withTransaction {
                productDao.updateBarcode(barcode.copy(barcodeType = targetFormat.name, updatedAt = now))
                productDao.getProductWithDetails(productId)?.product?.let {
                    productDao.updateProduct(it.copy(updatedAt = now))
                }
                // Sync any open/existing InventoryCountItems pointing to this product barcode
                val invItems = inventoryDao.getCountItemsForProductOnce(productId)
                invItems.filter { it.scannedBarcode == barcode.barcodeValue }.forEach { item ->
                    if (item.barcodeType != targetFormat.name) {
                        inventoryDao.updateCountItem(item.copy(barcodeType = targetFormat.name, updatedAt = now))
                    }
                }
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            bumpVersionAndInvalidate(productId, barcode.barcodeValue)
            prewarmProductBarcodeImage(productId, barcode.barcodeValue, targetFormat)
            trace?.succeed("تم التغيير إلى ${targetFormat.arabicLabel}")
            BarcodeChangeResult(
                success = true,
                message = "تم تحديث نوع الباركود إلى ${targetFormat.arabicLabel}",
                updatedCount = 1,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCTS,
                DiagnosticModules.BARCODE_CAMERA,
                "تغيير نوع باركود المنتج",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر تغيير نوع الباركود", err?.errorId.orEmpty())
            BarcodeChangeResult(false, "تعذر تغيير نوع الباركود: ${e.message}")
        }
    }

    /**
     * Bulk changes format across explicitly selected products only.
     * Skips incompatible barcode values WITHOUT ever altering original numbers.
     */
    suspend fun changeFormatBulkProducts(
        productIds: List<Long>,
        targetFormat: BarcodeFormatType,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        if (productIds.isEmpty()) {
            return@withContext BarcodeChangeResult(false, "لم يتم تحديد أي منتجات")
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "تغيير جماعي لنوع الباركود (${productIds.size} منتج)",
            initialStage = "فحص التوافق وتطبيق التغييرات",
        )
        var updatedCount = 0
        val skipped = mutableListOf<String>()
        val changedPairs = mutableListOf<Pair<Long, String>>()
        try {
            val now = System.currentTimeMillis()
            db.withTransaction {
                for (pid in productIds.distinct()) {
                    val details = productDao.getProductWithDetails(pid) ?: continue
                    val targetBarcode = details.primaryBarcode ?: details.barcodes.firstOrNull()
                    if (targetBarcode == null) {
                        skipped.add("${details.product.name} (لا يملك باركود)")
                        continue
                    }
                    val validation = BarcodeEngine.validate(targetBarcode.barcodeValue, targetFormat)
                    if (!validation.isValid) {
                        skipped.add("${details.product.name} [${targetBarcode.barcodeValue}]: ${validation.errorMessage}")
                        continue
                    }
                    productDao.updateBarcode(
                        targetBarcode.copy(barcodeType = targetFormat.name, updatedAt = now),
                    )
                    productDao.updateProduct(details.product.copy(updatedAt = now))
                    inventoryDao.getCountItemsForProductOnce(pid)
                        .filter { it.scannedBarcode == targetBarcode.barcodeValue }
                        .forEach { inv ->
                            inventoryDao.updateCountItem(inv.copy(barcodeType = targetFormat.name, updatedAt = now))
                        }
                    changedPairs.add(pid to targetBarcode.barcodeValue)
                    updatedCount++
                }
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            changedPairs.forEach { (pid, value) ->
                bumpVersionAndInvalidate(pid, value)
                ensureBarcodeDiskImageOnly(pid, value, targetFormat)
            }
            val msg = buildString {
                append("تم تحديث نوع الباركود لـ $updatedCount منتج إلى ${targetFormat.arabicLabel}")
                if (skipped.isNotEmpty()) {
                    append(" وتخطي ${skipped.size} غير متوافق دون تغيير أرقامها")
                }
            }
            trace?.succeed(msg)
            BarcodeChangeResult(
                success = updatedCount > 0 || alsoUpdateDefaultSetting,
                message = if (updatedCount == 0 && skipped.isNotEmpty()) {
                    "تعذر التغيير: جميع المنتجات المحددة غير متوافقة مع ${targetFormat.arabicLabel}"
                } else {
                    msg
                },
                updatedCount = updatedCount,
                skippedIncompatible = skipped,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCTS,
                DiagnosticModules.BARCODE_CAMERA,
                "تغيير جماعي لنوع الباركود",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل التغيير الجماعي", err?.errorId.orEmpty())
            BarcodeChangeResult(false, "تعذر تنفيذ التغيير الجماعي: ${e.message}")
        }
    }

    /**
     * Changes barcode format for a single inventory count item inside [sessionId].
     * When [alsoUpdateProductCatalog] is false (default for inventory-only scope), Products table is NOT touched.
     */
    suspend fun changeFormatForInventoryItem(
        sessionId: Long,
        itemId: Long,
        targetFormat: BarcodeFormatType,
        alsoUpdateProductCatalog: Boolean = false,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        try {
            val item = inventoryDao.getCountItemById(itemId)
                ?: return@withContext BarcodeChangeResult(false, "بند الجرد غير موجود")
            if (item.sessionId != sessionId) {
                return@withContext BarcodeChangeResult(false, "البند لا ينتمي لعملية الجرد الحالية")
            }
            val validation = BarcodeEngine.validate(item.scannedBarcode, targetFormat)
            if (!validation.isValid) {
                return@withContext BarcodeChangeResult(
                    false,
                    validation.errorMessage ?: "قيمة الباركود غير متوافقة مع ${targetFormat.arabicLabel}",
                )
            }

            val now = System.currentTimeMillis()
            db.withTransaction {
                inventoryDao.updateCountItem(item.copy(barcodeType = targetFormat.name, updatedAt = now))
                inventoryDao.getSessionWithDetails(sessionId)?.session?.let { sess ->
                    inventoryDao.updateSession(sess.copy(updatedAt = now))
                }
                if (alsoUpdateProductCatalog && item.productId != null) {
                    val prod = productDao.getProductWithDetails(item.productId)
                    val matchingBc = prod?.barcodes?.firstOrNull { it.barcodeValue == item.scannedBarcode }
                    if (matchingBc != null) {
                        productDao.updateBarcode(matchingBc.copy(barcodeType = targetFormat.name, updatedAt = now))
                        productDao.updateProduct(prod.product.copy(updatedAt = now))
                    }
                }
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            bumpVersionAndInvalidate(item.productId, item.scannedBarcode)
            ensureBarcodeDiskImageOnly(item.productId, item.scannedBarcode, targetFormat)
            BarcodeChangeResult(
                success = true,
                message = "تم تحديث نوع الباركود إلى ${targetFormat.arabicLabel}",
                updatedCount = 1,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.INVENTORY, DiagnosticModules.BARCODE_CAMERA, "تغيير نوع باركود في الجرد")
            BarcodeChangeResult(false, "تعذر تحديث النوع: ${e.message}")
        }
    }

    /**
     * Changes format across compatible items in [sessionId] ONLY.
     */
    suspend fun changeFormatForInventorySession(
        sessionId: Long,
        targetFormat: BarcodeFormatType,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        try {
            val details = inventoryDao.getSessionWithDetails(sessionId)
                ?: return@withContext BarcodeChangeResult(false, "جلسة الجرد غير موجودة")
            var updated = 0
            val skipped = mutableListOf<String>()
            val changed = mutableListOf<Pair<Long?, String>>()
            val now = System.currentTimeMillis()

            db.withTransaction {
                details.items.forEach { item ->
                    val v = BarcodeEngine.validate(item.scannedBarcode, targetFormat)
                    if (!v.isValid) {
                        skipped.add("${item.productName} [${item.scannedBarcode}]")
                    } else {
                        inventoryDao.updateCountItem(item.copy(barcodeType = targetFormat.name, updatedAt = now))
                        changed.add(item.productId to item.scannedBarcode)
                        updated++
                    }
                }
                inventoryDao.updateSession(details.session.copy(updatedAt = now))
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            changed.forEach { (pid, code) ->
                bumpVersionAndInvalidate(pid, code)
                ensureBarcodeDiskImageOnly(pid, code, targetFormat)
            }
            val msg = buildString {
                append("تم تحديث نوع الباركود لـ $updated بند في عملية الجرد الحالية")
                if (skipped.isNotEmpty()) append(" وتخطي ${skipped.size} غير متوافق")
            }
            BarcodeChangeResult(
                success = updated > 0 || alsoUpdateDefaultSetting,
                message = if (updated == 0 && skipped.isNotEmpty()) {
                    "تعذر التغيير: بنود الجرد غير متوافقة مع ${targetFormat.arabicLabel}"
                } else {
                    msg
                },
                updatedCount = updated,
                skippedIncompatible = skipped,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.INVENTORY, DiagnosticModules.BARCODE_CAMERA, "تغيير نوع الباركود لعملية الجرد")
            BarcodeChangeResult(false, "تعذر تحديث بنود الجرد: ${e.message}")
        }
    }

    /**
     * Changes barcode format for a single item inside [reportId].
     */
    suspend fun changeFormatForReportItem(
        reportId: Long,
        itemId: Long,
        targetFormat: BarcodeFormatType,
        alsoUpdateProductCatalog: Boolean = false,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        try {
            val details = reportDao.getReportWithDetails(reportId)
                ?: return@withContext BarcodeChangeResult(false, "التقرير غير موجود")
            val row = details.items.firstOrNull { it.item.id == itemId }
                ?: return@withContext BarcodeChangeResult(false, "صف التقرير غير موجود")
            val code = row.item.primaryBarcodeSnapshot
            val validation = BarcodeEngine.validate(code, targetFormat)
            if (!validation.isValid) {
                return@withContext BarcodeChangeResult(
                    false,
                    validation.errorMessage ?: "الباركود غير متوافق مع ${targetFormat.arabicLabel}",
                )
            }
            val now = System.currentTimeMillis()
            db.withTransaction {
                reportDao.updateReportItem(row.item.copy(primaryBarcodeTypeSnapshot = targetFormat.name))
                if (row.barcodes.isNotEmpty()) {
                    val updatedBarcodes = row.barcodes.map { b ->
                        if (b.barcodeValue == code) b.copy(barcodeType = targetFormat.name) else b
                    }
                    reportDao.insertReportItemBarcodes(updatedBarcodes)
                }
                reportDao.updateReport(details.report.copy(updatedAt = now))
                if (alsoUpdateProductCatalog && row.item.sourceProductId != null) {
                    val prod = productDao.getProductWithDetails(row.item.sourceProductId)
                    val matchingBc = prod?.barcodes?.firstOrNull { it.barcodeValue == code }
                    if (matchingBc != null) {
                        productDao.updateBarcode(matchingBc.copy(barcodeType = targetFormat.name, updatedAt = now))
                        productDao.updateProduct(prod.product.copy(updatedAt = now))
                    }
                }
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            bumpVersionAndInvalidate(row.item.sourceProductId, code)
            ensureBarcodeDiskImageOnly(row.item.sourceProductId, code, targetFormat)
            BarcodeChangeResult(
                success = true,
                message = "تم تغيير نوع باركود العنصر إلى ${targetFormat.arabicLabel}",
                updatedCount = 1,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.BARCODE_CAMERA, "تغيير نوع باركود بالتقرير")
            BarcodeChangeResult(false, "تعذر تغيير النوع: ${e.message}")
        }
    }

    /**
     * Changes barcode format across all compatible items inside [reportId].
     */
    suspend fun changeFormatForReport(
        reportId: Long,
        targetFormat: BarcodeFormatType,
        alsoUpdateDefaultSetting: Boolean = false,
    ): BarcodeChangeResult = withContext(Dispatchers.IO) {
        try {
            val details = reportDao.getReportWithDetails(reportId)
                ?: return@withContext BarcodeChangeResult(false, "التقرير غير موجود")
            var updated = 0
            val skipped = mutableListOf<String>()
            val changed = mutableListOf<Pair<Long?, String>>()
            val now = System.currentTimeMillis()
            db.withTransaction {
                details.items.forEach { row ->
                    val code = row.item.primaryBarcodeSnapshot
                    val v = BarcodeEngine.validate(code, targetFormat)
                    if (!v.isValid) {
                        skipped.add("${row.item.productNameSnapshot} [$code]")
                    } else {
                        reportDao.updateReportItem(row.item.copy(primaryBarcodeTypeSnapshot = targetFormat.name))
                        if (row.barcodes.isNotEmpty()) {
                            reportDao.insertReportItemBarcodes(
                                row.barcodes.map { b ->
                                    if (b.barcodeValue == code) b.copy(barcodeType = targetFormat.name) else b
                                },
                            )
                        }
                        changed.add(row.item.sourceProductId to code)
                        updated++
                    }
                }
                reportDao.updateReport(details.report.copy(updatedAt = now))
            }
            if (alsoUpdateDefaultSetting) {
                updateDefaultBarcodeFormat(targetFormat)
            }
            changed.forEach { (pid, code) ->
                bumpVersionAndInvalidate(pid, code)
                ensureBarcodeDiskImageOnly(pid, code, targetFormat)
            }
            val msg = buildString {
                append("تم تحديث نوع الباركود لـ $updated عنصر في التقرير")
                if (skipped.isNotEmpty()) append(" وتخطي ${skipped.size} غير متوافق")
            }
            BarcodeChangeResult(
                success = updated > 0 || alsoUpdateDefaultSetting,
                message = if (updated == 0 && skipped.isNotEmpty()) {
                    "تعذر التغيير: بنود التقرير غير متوافقة مع ${targetFormat.arabicLabel}"
                } else {
                    msg
                },
                updatedCount = updated,
                skippedIncompatible = skipped,
                appliedFormat = targetFormat,
            )
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.BARCODE_CAMERA, "تغيير نوع باركود التقرير")
            BarcodeChangeResult(false, "تعذر تحديث التقرير: ${e.message}")
        }
    }

    // ==================== Alternative Internal Barcode Generation ====================

    /**
     * Explicitly creates and attaches a brand-new internal barcode using the user's saved default barcode type
     * (or [explicitFormat]), strictly keeping ALL existing GTIN/EAN/UPC barcodes and isPrimary intact!
     */
    suspend fun generateAndAttachAlternativeInternalBarcode(
        productId: Long,
        unitType: String = "حبة",
        conversionFactor: Double = 1.0,
        description: String = "باركود داخلي بديل",
        explicitFormat: BarcodeFormatType? = null,
    ): Result<ProductBarcodeEntity> = withContext(Dispatchers.IO) {
        if (conversionFactor <= 0.0) {
            return@withContext Result.failure(IllegalArgumentException("معامل التحويل يجب أن يكون أكبر من صفر"))
        }
        try {
            val targetFormat = explicitFormat ?: getDefaultBarcodeType()
            val candidateValue = generateUniqueCandidateForFormat(productId, targetFormat)
                ?: return@withContext Result.failure(IllegalStateException("تعذر توليد رمز فريد متوافق مع ${targetFormat.arabicLabel}"))

            val now = System.currentTimeMillis()
            val inserted = db.withTransaction {
                val prod = productDao.getProductWithDetails(productId)
                    ?: throw IllegalArgumentException("المنتج غير موجود")
                val hasAnyPrimary = prod.barcodes.any { it.isPrimary }
                val cleanUnit = unitType.trim().ifBlank { "حبة" }
                val entity = ProductBarcodeEntity(
                    productId = productId,
                    barcodeValue = candidateValue,
                    barcodeType = targetFormat.name,
                    label = "داخلي بديل ($cleanUnit)",
                    description = description.trim(),
                    unitType = cleanUnit,
                    conversionFactor = conversionFactor,
                    isPrimary = !hasAnyPrimary,
                    createdAt = now,
                    updatedAt = now,
                )
                val id = productDao.insertBarcode(entity)
                productDao.updateProduct(prod.product.copy(updatedAt = now))
                entity.copy(id = id)
            }
            bumpVersionAndInvalidate(productId, inserted.barcodeValue)
            prewarmProductBarcodeImage(productId, inserted.barcodeValue, targetFormat)
            Result.success(inserted)
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.PRODUCT_DETAIL, DiagnosticModules.BARCODE_CAMERA, "توليد باركود داخلي بديل")
            Result.failure(e)
        }
    }

    suspend fun generateUniqueInternalValuePreview(
        seedProductId: Long,
        format: BarcodeFormatType,
    ): String = withContext(Dispatchers.IO) {
        generateUniqueCandidateForFormat(seedProductId, format)
            ?: "INT-${seedProductId.coerceAtLeast(1L)}-${(1000..9999).random()}"
    }

    private suspend fun generateUniqueCandidateForFormat(
        productId: Long,
        format: BarcodeFormatType,
    ): String? {
        repeat(40) { attempt ->
            val raw = when (format) {
                BarcodeFormatType.EAN_13 -> {
                    val body12 = buildNumericBody(prefix = "200", length = 12, seed = productId + attempt * 7919L)
                    body12 + computeGs1CheckDigit(body12)
                }
                BarcodeFormatType.EAN_8 -> {
                    val body7 = buildNumericBody(prefix = "20", length = 7, seed = productId + attempt * 3571L)
                    body7 + computeGs1CheckDigit(body7)
                }
                BarcodeFormatType.UPC_A -> {
                    val body11 = buildNumericBody(prefix = "04", length = 11, seed = productId + attempt * 5113L)
                    body11 + computeGs1CheckDigit(body11)
                }
                BarcodeFormatType.UPC_E -> {
                    val tail = abs((productId * 97L + System.nanoTime() + attempt * 131L) % 1_000_000L)
                        .toString()
                        .padStart(6, '0')
                    "0$tail" // 7 digits: UPCEWriter calculates the 8th check digit or finds valid form
                }
                BarcodeFormatType.ITF -> {
                    val num = abs((productId * 10000L + System.currentTimeMillis() % 100000L + attempt * 97L))
                        .toString()
                        .padStart(10, '0')
                        .take(10)
                    if (num.length % 2 == 0) num else "0$num"
                }
                else -> {
                    val suffix = ((System.nanoTime() + attempt * 37L) and 0xFFFF).toString(16).uppercase().padStart(4, '0')
                    "INT-${productId.coerceAtLeast(1L)}-$suffix"
                }
            }

            // If 7-digit UPC-E candidate was created, normalize to 8-digit encodable UPC-E if valid
            val finalCode = if (format == BarcodeFormatType.UPC_E && raw.length == 7) {
                (0..9).firstNotNullOfOrNull { cd ->
                    val eight = "$raw$cd"
                    if (BarcodeEngine.isCompatible(eight, BarcodeFormatType.UPC_E)) eight else null
                } ?: raw
            } else {
                raw
            }

            if (BarcodeEngine.isCompatible(finalCode, format) && productDao.findBarcodeExact(finalCode) == null) {
                return finalCode
            }
        }
        return null
    }

    private fun buildNumericBody(prefix: String, length: Int, seed: Long): String {
        val remainLen = (length - prefix.length).coerceAtLeast(1)
        val timePart = (System.nanoTime() / 1000L) xor seed
        val num = abs(timePart).toString().padStart(remainLen, '0').takeLast(remainLen)
        return (prefix + num).take(length)
    }

    private fun computeGs1CheckDigit(body: String): Char {
        var sum = 0
        val reversed = body.reversed()
        for (i in reversed.indices) {
            val d = reversed[i].digitToInt()
            sum += if (i % 2 == 0) d * 3 else d
        }
        val cd = (10 - (sum % 10)) % 10
        return ('0' + cd)
    }

    // ==================== Safe Legacy Audit & OOM-Safe Batch Repair ====================

    suspend fun auditLegacyBarcodes(): BarcodeLegacyAuditReport = withContext(Dispatchers.IO) {
        val productsById = productDao.getAllProductsOnce().associateBy { it.id }
        val allBarcodes = productDao.getAllBarcodesOnce()
        val allInvItems = inventoryDao.getAllCountItemsOnce()
        val defaultFmt = getDefaultBarcodeType()

        var missingImages = 0
        var unspecifiedFormats = 0
        val incompatible = mutableListOf<IncompatibleBarcodeAuditItem>()

        val barcodeLookup = HashMap<Pair<Long, String>, ProductBarcodeEntity>(allBarcodes.size)
        for (b in allBarcodes) {
            barcodeLookup[b.productId to b.barcodeValue] = b
            val parsedFmt = BarcodeEngine.parseFormatOrNull(b.barcodeType)
            if (parsedFmt == null) {
                unspecifiedFormats++
                val resolved = BarcodeEngine.resolveCompatibleDefaultFormat(b.barcodeValue, defaultFmt)
                if (!hasCachedDiskImage(b.productId, b.barcodeValue, resolved)) {
                    missingImages++
                }
            } else {
                val validation = BarcodeEngine.validate(b.barcodeValue, parsedFmt)
                if (!validation.isValid) {
                    val prodName = productsById[b.productId]?.name ?: "#${b.productId}"
                    incompatible.add(
                        IncompatibleBarcodeAuditItem(
                            productId = b.productId,
                            barcodeId = b.id,
                            productName = prodName,
                            barcodeValue = b.barcodeValue,
                            recordedFormat = b.barcodeType,
                            validationError = validation.errorMessage ?: "غير متوافق",
                            suggestedCompatibleFormat = BarcodeEngine.resolveCompatibleDefaultFormat(
                                b.barcodeValue,
                                BarcodeFormatType.CODE_128,
                            ),
                        ),
                    )
                } else if (!hasCachedDiskImage(b.productId, b.barcodeValue, parsedFmt)) {
                    missingImages++
                }
            }
        }

        var staleInvCount = 0
        for (inv in allInvItems) {
            val pid = inv.productId ?: continue
            val catalogBc = barcodeLookup[pid to inv.scannedBarcode] ?: continue
            val invFmt = BarcodeEngine.parseFormatOrNull(inv.barcodeType)
            val catFmt = BarcodeEngine.parseFormatOrNull(catalogBc.barcodeType)
            if (catFmt != null && invFmt != catFmt && BarcodeEngine.isCompatible(inv.scannedBarcode, catFmt)) {
                staleInvCount++
            }
        }

        BarcodeLegacyAuditReport(
            totalProducts = productsById.size,
            totalBarcodes = allBarcodes.size,
            missingImageCacheCount = missingImages,
            unspecifiedFormatCount = unspecifiedFormats,
            staleInventorySnapshotCount = staleInvCount,
            incompatibleBarcodes = incompatible,
        )
    }

    /**
     * Safely audits and repairs legacy barcodes in OOM-safe chunks.
     * NEVER deletes products, NEVER modifies ProductEntity.id/internalCode, NEVER modifies barcode digits.
     * Only changes incompatible format tags (e.g. invalid GS1 check-digit tagged EAN_13) if [convertIncompatibleFormatWithUserApproval] is true.
     */
    suspend fun repairLegacyProductBarcodes(
        convertIncompatibleFormatWithUserApproval: Boolean = false,
        chunkSize: Int = 50,
        onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
    ): BarcodeRepairResult = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.SETTINGS,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "فحص وإصلاح باركودات المنتجات القديمة",
            initialStage = "تحميل قائمة الباركودات بأمان",
        )
        val allBarcodes = productDao.getAllBarcodesOnce()
        val productsById = productDao.getAllProductsOnce().associateBy { it.id }
        val defaultFmt = getDefaultBarcodeType()
        val total = allBarcodes.size

        var generatedImages = 0
        var fixedUnspecified = 0
        var syncedInv = 0
        var convertedIncompatible = 0
        var skippedIncompatible = 0
        val skippedDetails = mutableListOf<String>()
        var processed = 0
        val now = System.currentTimeMillis()

        val validFormatByPair = HashMap<Pair<Long, String>, BarcodeFormatType>(total)

        for (chunk in allBarcodes.chunked(chunkSize.coerceAtLeast(10))) {
            yield()
            db.withTransaction {
                for (b in chunk) {
                    val parsed = BarcodeEngine.parseFormatOrNull(b.barcodeType)
                    val targetFmt: BarcodeFormatType? = when {
                        parsed == null -> {
                            val resolved = BarcodeEngine.resolveCompatibleDefaultFormat(b.barcodeValue, defaultFmt)
                            productDao.updateBarcode(b.copy(barcodeType = resolved.name, updatedAt = now))
                            fixedUnspecified++
                            resolved
                        }
                        BarcodeEngine.isCompatible(b.barcodeValue, parsed) -> parsed
                        convertIncompatibleFormatWithUserApproval -> {
                            val compatible = BarcodeEngine.resolveCompatibleDefaultFormat(
                                b.barcodeValue,
                                BarcodeFormatType.CODE_128,
                            )
                            productDao.updateBarcode(b.copy(barcodeType = compatible.name, updatedAt = now))
                            convertedIncompatible++
                            compatible
                        }
                        else -> {
                            val prodName = productsById[b.productId]?.name ?: "#${b.productId}"
                            skippedIncompatible++
                            if (skippedDetails.size < 100) {
                                skippedDetails.add("$prodName [${b.barcodeValue}]: مرمّز كـ ${parsed.arabicLabel} مع عدم توافق الرقم")
                            }
                            null
                        }
                    }

                    if (targetFmt != null) {
                        validFormatByPair[b.productId to b.barcodeValue] = targetFmt
                    }
                }
            }

            // Generate missing disk PNGs outside SQLite transaction & without flooding LruCache
            for (b in chunk) {
                val fmt = validFormatByPair[b.productId to b.barcodeValue]
                if (fmt != null && !hasCachedDiskImage(b.productId, b.barcodeValue, fmt)) {
                    if (ensureBarcodeDiskImageOnly(b.productId, b.barcodeValue, fmt)) {
                        generatedImages++
                    }
                }
                processed++
            }
            onProgress(processed, total)
        }

        // Sync stale InventoryCountItems.barcodeType snapshots without changing scanned numbers or quantities
        val allInvItems = inventoryDao.getAllCountItemsOnce()
        for (invChunk in allInvItems.chunked(chunkSize.coerceAtLeast(10))) {
            yield()
            db.withTransaction {
                for (inv in invChunk) {
                    val pid = inv.productId ?: continue
                    val targetFmt = validFormatByPair[pid to inv.scannedBarcode] ?: continue
                    val currentInvFmt = BarcodeEngine.parseFormatOrNull(inv.barcodeType)
                    if (currentInvFmt != targetFmt) {
                        inventoryDao.updateCountItem(inv.copy(barcodeType = targetFmt.name, updatedAt = now))
                        syncedInv++
                    }
                }
            }
        }

        _cacheGeneration.value = _cacheGeneration.value + 1L
        val summary = BarcodeRepairResult(
            inspectedBarcodes = total,
            generatedImagesCount = generatedImages,
            fixedUnspecifiedFormatsCount = fixedUnspecified,
            syncedInventorySnapshotsCount = syncedInv,
            convertedIncompatibleWithApprovalCount = convertedIncompatible,
            skippedIncompatibleWithoutApprovalCount = skippedIncompatible,
            skippedDetails = skippedDetails,
        )
        trace?.succeed(
            "فُحص $total | صُوّر $generatedImages | صُحّح $fixedUnspecified | زُومن جرد $syncedInv",
        )
        summary
    }

    // ==================== Version Index Helpers ====================

    private fun versionKey(productId: Long?, barcodeValue: String): String =
        "${productId ?: 0L}|${barcodeValue.trim()}"

    private fun entityPrefixHash(productId: Long?, barcodeValue: String): String =
        sha256Hex(versionKey(productId, barcodeValue)).take(12)

    private fun diskCacheFile(
        productId: Long?,
        barcodeValue: String,
        imageVersion: Long,
        fullCacheKey: String,
    ): File {
        val prefix = entityPrefixHash(productId, barcodeValue)
        val tail = sha256Hex(fullCacheKey).take(16)
        return File(mediaStorage.barcodeCacheDir, "bc_${prefix}_v${imageVersion}_$tail.png")
    }

    private fun writeBitmapToDiskAtomic(bitmap: Bitmap, dest: File): Boolean {
        return try {
            dest.parentFile?.mkdirs()
            val tmp = File(dest.parentFile, "${dest.name}.tmp")
            FileOutputStream(tmp).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            if (dest.exists()) dest.delete()
            tmp.renameTo(dest)
        } catch (_: Exception) {
            false
        }
    }

    private fun ensureVersionMapLoadedLocked() {
        if (versionMapLoaded) return
        versionMapLoaded = true
        runCatching {
            if (versionIndexFile.exists()) {
                val raw = versionIndexFile.readText()
                if (raw.isNotBlank()) {
                    val payload = json.decodeFromString<BarcodeVersionIndexPayload>(raw)
                    versionMap.putAll(payload.versions)
                }
            }
        }
    }

    private fun persistVersionMapLocked() {
        runCatching {
            versionIndexFile.parentFile?.mkdirs()
            val tmp = File(versionIndexFile.parentFile, "${versionIndexFile.name}.tmp")
            tmp.writeText(json.encodeToString(BarcodeVersionIndexPayload(versionMap.toMap())))
            if (versionIndexFile.exists()) versionIndexFile.delete()
            tmp.renameTo(versionIndexFile)
        }
    }

    private fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
