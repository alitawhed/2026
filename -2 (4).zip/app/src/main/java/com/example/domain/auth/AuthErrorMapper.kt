package com.example.domain.auth

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthEmailException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException

object AuthErrorMapper {

    fun isNetworkAvailable(context: Context): Boolean {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return@runCatching true
            val network = cm.activeNetwork ?: return@runCatching false
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }.getOrDefault(true)
    }

    fun mapException(
        throwable: Throwable,
        operationLabel: String = "العملية",
        pendingGoogleIdToken: String? = null,
    ): AuthActionResult {
        if (throwable is FirebaseAuthUserCollisionException) {
            val code = throwable.errorCode
            val email = throwable.email.orEmpty()
            return if (code == "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL") {
                AuthActionResult.AccountCollision(
                    email = email,
                    existingProviderHint = AuthProviderType.EMAIL_PASSWORD.arabicLabel,
                    message = "هذا البريد الإلكتروني مرتبط مسبقاً بطريقة تسجيل دخول أخرى. يرجى تسجيل الدخول بالطريقة الأصلية أولاً ثم ربط الحساب من إعدادات الحساب.",
                    pendingGoogleIdToken = pendingGoogleIdToken,
                )
            } else if (code == "ERROR_CREDENTIAL_ALREADY_IN_USE") {
                AuthActionResult.Failure(
                    errorCode = code,
                    userMessageArabic = "بيانات الدخول هذه مرتبطة بالفعل بحساب آخر. لا يمكن دمج حسابين تلقائياً دون التحقق.",
                    technicalReason = throwable.message.orEmpty(),
                )
            } else {
                AuthActionResult.Failure(
                    errorCode = code,
                    userMessageArabic = "يوجد حساب مسجل مسبقاً بهذا البريد الإلكتروني. جرّب تسجيل الدخول أو استعادة كلمة المرور.",
                    technicalReason = throwable.message.orEmpty(),
                )
            }
        }

        if (throwable is FirebaseAuthRecentLoginRequiredException) {
            return AuthActionResult.RequiresRecentLogin(
                operationLabel = operationLabel,
                message = "لأغراض الأمان، يتطلب تنفيذ «$operationLabel» إعادة تسجيل الدخول للتحقق من هويتك أولاً.",
            )
        }

        if (throwable is FirebaseNetworkException) {
            return AuthActionResult.Failure(
                errorCode = "ERROR_NETWORK_REQUEST_FAILED",
                userMessageArabic = "تعذر الاتصال بالإنترنت أو بخوادم المصادقة. تحقق من الشبكة وحاول مرة أخرى.",
                technicalReason = throwable.message.orEmpty(),
                isNetworkError = true,
            )
        }

        if (throwable is FirebaseTooManyRequestsException) {
            return AuthActionResult.Failure(
                errorCode = "ERROR_TOO_MANY_REQUESTS",
                userMessageArabic = "تم تنفيذ محاولات كثيرة متتالية. يرجى الانتظار بضع دقائق ثم المحاولة مرة أخرى.",
                technicalReason = throwable.message.orEmpty(),
            )
        }

        if (throwable is FirebaseAuthWeakPasswordException) {
            return AuthActionResult.Failure(
                errorCode = throwable.errorCode,
                userMessageArabic = "كلمة المرور ضعيفة جداً. يجب أن تحتوي على ${AuthInputValidator.MIN_PASSWORD_LENGTH} أحرف على الأقل وتجمع بين حروف وأرقام.",
                technicalReason = throwable.message.orEmpty(),
            )
        }

        if (throwable is FirebaseAuthInvalidCredentialsException) {
            return AuthActionResult.Failure(
                errorCode = throwable.errorCode,
                userMessageArabic = mapCodeToArabic(throwable.errorCode),
                technicalReason = throwable.message.orEmpty(),
            )
        }

        if (throwable is FirebaseAuthInvalidUserException) {
            return AuthActionResult.Failure(
                errorCode = throwable.errorCode,
                userMessageArabic = mapCodeToArabic(throwable.errorCode),
                technicalReason = throwable.message.orEmpty(),
            )
        }

        if (throwable is FirebaseAuthEmailException) {
            return AuthActionResult.Failure(
                errorCode = throwable.errorCode,
                userMessageArabic = "تعذر إرسال رسالة البريد الإلكتروني. تأكد من صحة عنوان البريد وحاول لاحقاً.",
                technicalReason = throwable.message.orEmpty(),
            )
        }

        if (throwable is FirebaseAuthException) {
            val code = throwable.errorCode
            if (code == "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL") {
                return AuthActionResult.AccountCollision(
                    email = "",
                    existingProviderHint = AuthProviderType.EMAIL_PASSWORD.arabicLabel,
                    message = "هذا البريد مرتبط بمزود دخول آخر. يرجى الدخول بالطريقة المرتبطة مسبقاً ثم ربط حساب Google من إدارة الحساب.",
                    pendingGoogleIdToken = pendingGoogleIdToken,
                )
            }
            if (code == "ERROR_REQUIRES_RECENT_LOGIN") {
                return AuthActionResult.RequiresRecentLogin(
                    operationLabel = operationLabel,
                    message = "لأغراض الأمان، يرجى إعادة تأكيد هويتك قبل إتمام «$operationLabel».",
                )
            }
            return AuthActionResult.Failure(
                errorCode = code,
                userMessageArabic = mapCodeToArabic(code),
                technicalReason = throwable.message.orEmpty(),
                isNetworkError = code == "ERROR_NETWORK_REQUEST_FAILED",
            )
        }

        val msg = throwable.message.orEmpty()
        val looksLikeNetwork = msg.contains("network", ignoreCase = true) ||
            msg.contains("timeout", ignoreCase = true) ||
            msg.contains("Unable to resolve host", ignoreCase = true)

        return AuthActionResult.Failure(
            errorCode = throwable::class.java.simpleName,
            userMessageArabic = if (looksLikeNetwork) {
                "تعذر الاتصال بالإنترنت. يرجى التحقق من الشبكة والمحاولة مرة أخرى."
            } else {
                "تعذر إتمام العملية: ${msg.ifBlank { "خطأ غير متوقع" }}"
            },
            technicalReason = msg,
            isNetworkError = looksLikeNetwork,
        )
    }

    fun mapCodeToArabic(errorCode: String): String = when (errorCode) {
        "ERROR_INVALID_EMAIL" -> "صيغة البريد الإلكتروني غير صالحة."
        "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" ->
            "البريد الإلكتروني أو كلمة المرور غير صحيحة أو انتهت صلاحية بيانات الدخول."
        "ERROR_USER_NOT_FOUND" -> "لا يوجد حساب مسجل بهذا البريد الإلكتروني."
        "ERROR_USER_DISABLED" -> "تم تعطيل هذا الحساب من قبل إدارة النظام."
        "ERROR_EMAIL_ALREADY_IN_USE" ->
            "هذا البريد الإلكتروني مسجل مسبقاً. يمكنك تسجيل الدخول أو استعادة كلمة المرور."
        "ERROR_WEAK_PASSWORD" ->
            "كلمة المرور ضعيفة؛ يرجى اختيار كلمة مرور أقوى (8 أحرف مع حروف وأرقام)."
        "ERROR_TOO_MANY_REQUESTS" ->
            "تم تجاوز عدد المحاولات المسموح به مؤقتاً. انتظر قليلاً ثم أعد المحاولة."
        "ERROR_OPERATION_NOT_ALLOWED" ->
            "طريقة تسجيل الدخول هذه غير مفعّلة حالياً في إعدادات Firebase Console لهذا المشروع."
        "ERROR_PROVIDER_ALREADY_LINKED" ->
            "طريقة تسجيل الدخول هذه مرتبطة بالفعل بهذا الحساب."
        "ERROR_NO_SUCH_PROVIDER" ->
            "مزود تسجيل الدخول هذا غير مرتبط بالحساب الحالي."
        "ERROR_USER_TOKEN_EXPIRED", "ERROR_INVALID_USER_TOKEN" ->
            "انتهت صلاحية الجلسة؛ يرجى إعادة تسجيل الدخول."
        "ERROR_NETWORK_REQUEST_FAILED" ->
            "انقطع الاتصال بالشبكة أثناء التواصل مع خادم المصادقة."
        "ERROR_REQUIRES_RECENT_LOGIN" ->
            "يتطلب هذا الإجراء إعادة المصادقة الحديثة قبل تنفيذه."
        "ERROR_CREDENTIAL_ALREADY_IN_USE" ->
            "بيانات الاعتماد هذه مستخدمة بالفعل في حساب آخر."
        "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" ->
            "هذا البريد الإلكتروني مرتبط بمزود تسجيل دخول مختلف. سجّل الدخول أولاً بالطريقة السابقة ثم قم بالربط بأمان."
        else -> "حدث خطأ أثناء المصادقة ($errorCode). يرجى المحاولة لاحقاً."
    }
}
