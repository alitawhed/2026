package com.example.domain.pdf

import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

interface PdfSession {
    fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas
    fun endPage()
    fun writeTo(outputStream: OutputStream)
    fun close()
}

fun interface PdfSessionFactory {
    fun create(): PdfSession
}

class AndroidPdfSessionFactory : PdfSessionFactory {
    override fun create(): PdfSession = AndroidPdfSession()
}

private class AndroidPdfSession : PdfSession {
    private val doc = PdfDocument()
    private var currentPage: PdfDocument.Page? = null

    override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
        val info = PdfDocument.PageInfo.Builder(widthPt, heightPt, pageNumber).create()
        val page = doc.startPage(info)
        currentPage = page
        return page.canvas
    }

    override fun endPage() {
        currentPage?.let { doc.finishPage(it) }
        currentPage = null
    }

    override fun writeTo(outputStream: OutputStream) {
        doc.writeTo(outputStream)
    }

    override fun close() {
        doc.close()
    }
}
