package com.example.domain.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.entity.PdfDocumentEntity
import com.example.data.local.entity.PdfDocumentWithPages
import com.example.data.local.entity.PdfPageEntity
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.math.roundToInt

enum class PdfOverlayType(val arabicLabel: String) {
    TEXT("نص عربي / إنجليزي"),
    IMAGE("صورة / شعار / توقيع"),
    DATE_STAMP("ختم التاريخ"),
    PAGE_NUMBER("رقم الصفحة"),
    RECTANGLE("إطار مستطيل"),
    LINE("خط"),
    HIGHLIGHT("تظليل نص"),
    COVER_BOX("صندوق تغطية (مسح وإعادة كتابة)"),
    CALLOUT("ملصق / تعليق"),
}

@Serializable
data class PdfOverlayItem(
    val id: String = UUID.randomUUID().toString(),
    val pageIndex: Int = 0,
    val type: PdfOverlayType = PdfOverlayType.TEXT,
    val xFraction: Float = 0.15f,
    val yFraction: Float = 0.15f,
    val widthFraction: Float = 0.35f,
    val heightFraction: Float = 0.08f,
    val text: String = "",
    val imagePath: String = "",
    val colorHex: String = "#0F172A",
    val fillColorHex: String = "#FFFFFF",
    val fontSizeSp: Float = 14f,
    val strokeWidthPt: Float = 2f,
    val alpha: Float = 1f,
)

@Serializable
data class PdfEditablePage(
    val id: String = UUID.randomUUID().toString(),
    val sourcePdfPath: String = "",
    val sourcePageIndex: Int = 0,
    val rotationDegrees: Int = 0,
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropRight: Float = 1f,
    val cropBottom: Float = 1f,
    val isBlankPage: Boolean = false,
    val blankWidthPt: Float = 595f,
    val blankHeightPt: Float = 842f,
    val extractedText: String = "",
)

data class PdfEditableDocument(
    val documentId: Long = 0L,
    val title: String,
    val fileName: String,
    val originalPdfPath: String,
    val workingPdfPath: String,
    val pages: List<PdfEditablePage>,
    val overlays: List<PdfOverlayItem>,
    val sourceReportId: Long? = null,
)

data class PdfRenderOutput(
    val pageCount: Int,
    val pageWidthPt: Float,
    val pageHeightPt: Float,
    val bitmap: Bitmap?,
)

interface PdfPageRenderer {
    fun getPageCount(file: File): Int
    fun renderPage(file: File, pageIndex: Int, scaleFactor: Float = 2.0f): PdfRenderOutput
}

class AndroidPdfPageRenderer : PdfPageRenderer {
    override fun getPageCount(file: File): Int {
        if (!file.exists()) return 0
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            renderer.pageCount
        } catch (_: Exception) {
            0
        } finally {
            renderer?.close()
            pfd?.close()
        }
    }

    override fun renderPage(file: File, pageIndex: Int, scaleFactor: Float): PdfRenderOutput {
        if (!file.exists()) return PdfRenderOutput(0, 595f, 842f, null)
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val total = renderer.pageCount
            if (total <= 0) return PdfRenderOutput(0, 595f, 842f, null)
            val safeIdx = pageIndex.coerceIn(0, total - 1)
            val page = renderer.openPage(safeIdx)
            val pw = page.width.toFloat().coerceAtLeast(100f)
            val ph = page.height.toFloat().coerceAtLeast(100f)
            val bmpW = (pw * scaleFactor).roundToInt().coerceIn(200, 2600)
            val bmpH = (ph * scaleFactor).roundToInt().coerceIn(200, 3500)
            val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            PdfRenderOutput(total, pw, ph, bitmap)
        } catch (_: Exception) {
            PdfRenderOutput(0, 595f, 842f, null)
        } finally {
            renderer?.close()
            pfd?.close()
        }
    }
}

class PdfEditorEngine(
    private val context: Context,
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val sessionFactory: PdfSessionFactory = AndroidPdfSessionFactory(),
    private val pageRenderer: PdfPageRenderer = AndroidPdfPageRenderer(),
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun openPdfFromUri(
        uri: Uri,
        titleHint: String = "",
        sourceReportId: Long? = null,
    ): Result<PdfDocumentWithPages> = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PDF_EDITOR,
            moduleName = DiagnosticModules.PDF,
            operationName = "فتح ملف PDF للتحرير",
            initialStage = "نسخ ملف PDF إلى مساحة العمل الآمنة",
        )
        try {
            val resolvedName = titleHint.ifBlank { queryDisplayName(uri) }
            val workspaceCopy = mediaStorage.copyUriToPdfWorkspace(uri, resolvedName)
                ?: run {
                    val err = IllegalStateException("تعذر استيراد ملف PDF إلى مساحة العمل")
                    val rec = errorMonitor?.recordError(err, ScreenNames.PDF_EDITOR, DiagnosticModules.PDF, "فتح PDF من URI للتحرير", linkedOperationId = trace?.operationId.orEmpty())
                    trace?.fail(err.message.orEmpty(), linkedErrorId = rec?.errorId.orEmpty())
                    return@withContext Result.failure(err)
                }
            trace?.stage("تحليل صفحات PDF")
            val res = openWorkspaceFile(workspaceCopy, resolvedName.substringBeforeLast('.'), sourceReportId)
            res.onSuccess { trace?.succeed("تم فتح ${it.document.title} (${it.pages.size} صفحة)") }
                .onFailure { trace?.fail(it.message ?: "تعذر حفظ سجل المستند") }
            res
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء فتح PDF")
            throw c
        } catch (e: Exception) {
            val rec = errorMonitor?.recordError(e, ScreenNames.PDF_EDITOR, DiagnosticModules.PDF, "فتح PDF من URI للتحرير", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(e.message ?: "خطأ فتح PDF", linkedErrorId = rec?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun openInternalPdfFile(
        file: File,
        title: String = file.nameWithoutExtension,
        sourceReportId: Long? = null,
    ): Result<PdfDocumentWithPages> = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PDF_EDITOR,
            moduleName = DiagnosticModules.PDF,
            operationName = "فتح PDF داخلي (${file.name})",
            initialStage = "نسخ إلى مساحة العمل",
        )
        try {
            val workspaceCopy = mediaStorage.copyPdfToWorkspace(file)
                ?: run {
                    val err = IllegalStateException("ملف PDF غير موجود")
                    trace?.fail(err.message.orEmpty())
                    return@withContext Result.failure(err)
                }
            trace?.stage("قراءة صفحات المستند")
            val res = openWorkspaceFile(workspaceCopy, title, sourceReportId)
            res.onSuccess { trace?.succeed("تم فتح ${it.document.title}") }
                .onFailure { trace?.fail(it.message ?: "تعذر فتح المستند") }
            res
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء فتح PDF الداخلي")
            throw c
        } catch (e: Exception) {
            val rec = errorMonitor?.recordError(e, ScreenNames.PDF_EDITOR, DiagnosticModules.PDF, "فتح ملف PDF داخلي للتحرير", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(e.message ?: "خطأ فتح PDF", linkedErrorId = rec?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    private suspend fun openWorkspaceFile(
        workspaceFile: File,
        title: String,
        sourceReportId: Long?,
    ): Result<PdfDocumentWithPages> {
        val pageCount = pageRenderer.getPageCount(workspaceFile).coerceAtLeast(1)
        val now = System.currentTimeMillis()
        val docEntity = PdfDocumentEntity(
            title = title.ifBlank { workspaceFile.nameWithoutExtension },
            fileName = workspaceFile.name,
            workingFilePath = workspaceFile.absolutePath,
            originalFilePath = workspaceFile.absolutePath,
            pageCount = pageCount,
            fileSizeBytes = workspaceFile.length(),
            sourceReportId = sourceReportId,
            annotationsJson = "[]",
            isEditedCopy = false,
            createdAt = now,
            updatedAt = now,
        )
        val docId = db.pdfDocumentDao().insertDocument(docEntity)
        val pages = (0 until pageCount).map { idx ->
            PdfPageEntity(
                documentId = docId,
                sourcePdfPath = workspaceFile.absolutePath,
                sourcePageIndex = idx,
                sortOrder = idx,
            )
        }
        db.pdfDocumentDao().insertPages(pages)
        val loaded = db.pdfDocumentDao().getDocumentOnce(docId)
            ?: return Result.failure(IllegalStateException("تعذر حفظ سجل المستند"))
        return Result.success(loaded)
    }

    fun toEditableDocument(doc: PdfDocumentWithPages): PdfEditableDocument {
        val overlays = try {
            json.decodeFromString<List<PdfOverlayItem>>(doc.document.annotationsJson)
        } catch (_: Exception) {
            emptyList()
        }
        val pages = doc.sortedPages.map { p ->
            PdfEditablePage(
                id = "${p.id}_${p.sortOrder}",
                sourcePdfPath = p.sourcePdfPath,
                sourcePageIndex = p.sourcePageIndex,
                rotationDegrees = p.rotationDegrees,
                cropLeft = p.cropLeftFraction,
                cropTop = p.cropTopFraction,
                cropRight = p.cropRightFraction,
                cropBottom = p.cropBottomFraction,
                isBlankPage = p.isBlankPage,
                blankWidthPt = p.blankWidthPt,
                blankHeightPt = p.blankHeightPt,
                extractedText = p.extractedText,
            )
        }
        return PdfEditableDocument(
            documentId = doc.document.id,
            title = doc.document.title,
            fileName = doc.document.fileName,
            originalPdfPath = doc.document.originalFilePath,
            workingPdfPath = doc.document.workingFilePath,
            pages = pages,
            overlays = overlays,
            sourceReportId = doc.document.sourceReportId,
        )
    }

    suspend fun saveWorkspaceState(editable: PdfEditableDocument) = withContext(Dispatchers.IO) {
        if (editable.documentId <= 0L) return@withContext
        val existing = db.pdfDocumentDao().getDocumentOnce(editable.documentId)?.document ?: return@withContext
        db.pdfDocumentDao().updateDocument(
            existing.copy(
                title = editable.title,
                workingFilePath = editable.workingPdfPath,
                pageCount = editable.pages.size,
                annotationsJson = json.encodeToString(editable.overlays),
                updatedAt = System.currentTimeMillis(),
            ),
        )
        db.pdfDocumentDao().deletePagesForDocument(editable.documentId)
        val entities = editable.pages.mapIndexed { idx, p ->
            PdfPageEntity(
                documentId = editable.documentId,
                sourcePdfPath = p.sourcePdfPath,
                sourcePageIndex = p.sourcePageIndex,
                sortOrder = idx,
                rotationDegrees = p.rotationDegrees,
                cropLeftFraction = p.cropLeft,
                cropTopFraction = p.cropTop,
                cropRightFraction = p.cropRight,
                cropBottomFraction = p.cropBottom,
                isBlankPage = p.isBlankPage,
                blankWidthPt = p.blankWidthPt,
                blankHeightPt = p.blankHeightPt,
                extractedText = p.extractedText,
            )
        }
        if (entities.isNotEmpty()) {
            db.pdfDocumentDao().insertPages(entities)
        }
    }

    fun rotatePage(doc: PdfEditableDocument, pageIndex: Int, deltaDegrees: Int = 90): PdfEditableDocument {
        val updated = doc.pages.mapIndexed { idx, p ->
            if (idx == pageIndex) {
                val rot = (((p.rotationDegrees + deltaDegrees) % 360) + 360) % 360
                p.copy(rotationDegrees = rot)
            } else p
        }
        return doc.copy(pages = updated)
    }

    fun deletePage(doc: PdfEditableDocument, pageIndex: Int): PdfEditableDocument {
        if (doc.pages.size <= 1 || pageIndex !in doc.pages.indices) return doc
        val updatedPages = doc.pages.filterIndexed { idx, _ -> idx != pageIndex }
        val updatedOverlays = doc.overlays
            .filterNot { it.pageIndex == pageIndex }
            .map { if (it.pageIndex > pageIndex) it.copy(pageIndex = it.pageIndex - 1) else it }
        return doc.copy(pages = updatedPages, overlays = updatedOverlays)
    }

    fun movePage(doc: PdfEditableDocument, fromIndex: Int, toIndex: Int): PdfEditableDocument {
        if (fromIndex !in doc.pages.indices || toIndex !in doc.pages.indices || fromIndex == toIndex) return doc
        val list = doc.pages.toMutableList()
        val moved = list.removeAt(fromIndex)
        list.add(toIndex, moved)
        val updatedOverlays = doc.overlays.map { ov ->
            val newIdx = when (ov.pageIndex) {
                fromIndex -> toIndex
                in (minOf(fromIndex, toIndex)..maxOf(fromIndex, toIndex)) ->
                    if (fromIndex < toIndex) ov.pageIndex - 1 else ov.pageIndex + 1
                else -> ov.pageIndex
            }
            ov.copy(pageIndex = newIdx)
        }
        return doc.copy(pages = list, overlays = updatedOverlays)
    }

    fun insertBlankPage(
        doc: PdfEditableDocument,
        afterIndex: Int = doc.pages.lastIndex,
        widthPt: Float = 595f,
        heightPt: Float = 842f,
    ): PdfEditableDocument {
        val insertPos = (afterIndex + 1).coerceIn(0, doc.pages.size)
        val list = doc.pages.toMutableList()
        list.add(
            insertPos,
            PdfEditablePage(
                isBlankPage = true,
                blankWidthPt = widthPt,
                blankHeightPt = heightPt,
            ),
        )
        val updatedOverlays = doc.overlays.map { ov ->
            if (ov.pageIndex >= insertPos) ov.copy(pageIndex = ov.pageIndex + 1) else ov
        }
        return doc.copy(pages = list, overlays = updatedOverlays)
    }

    fun cropPageMargins(
        doc: PdfEditableDocument,
        pageIndex: Int,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
    ): PdfEditableDocument {
        val l = left.coerceIn(0f, 0.45f)
        val t = top.coerceIn(0f, 0.45f)
        val r = right.coerceIn(l + 0.15f, 1f)
        val b = bottom.coerceIn(t + 0.15f, 1f)
        val updated = doc.pages.mapIndexed { idx, p ->
            if (idx == pageIndex) p.copy(cropLeft = l, cropTop = t, cropRight = r, cropBottom = b) else p
        }
        return doc.copy(pages = updated)
    }

    suspend fun appendPdfFromUri(doc: PdfEditableDocument, secondUri: Uri): Result<PdfEditableDocument> =
        withContext(Dispatchers.IO) {
            val trace = errorMonitor?.operationLogger?.startOperation(
                screenName = ScreenNames.PDF_EDITOR,
                moduleName = DiagnosticModules.PDF,
                operationName = "دمج ملف PDF",
                initialStage = "استيراد الملف الإضافي",
            )
            try {
                val secondFile = mediaStorage.copyUriToPdfWorkspace(secondUri, "merge_${System.currentTimeMillis()}.pdf")
                    ?: run {
                        val err = IllegalStateException("تعذر فتح ملف PDF للدمج")
                        trace?.fail(err.message.orEmpty())
                        return@withContext Result.failure(err)
                    }
                trace?.stage("دمج الصفحات")
                val res = appendPdfFile(doc, secondFile)
                res.onSuccess { trace?.succeed("عدد الصفحات بعد الدمج=${it.pages.size}") }
                    .onFailure { trace?.fail(it.message ?: "تعذر دمج PDF") }
                res
            } catch (c: CancellationException) {
                trace?.cancel("تم إلغاء دمج PDF")
                throw c
            } catch (e: Exception) {
                val rec = errorMonitor?.recordError(e, ScreenNames.PDF_EDITOR, DiagnosticModules.PDF, "دمج ملف PDF", linkedOperationId = trace?.operationId.orEmpty())
                trace?.fail(e.message ?: "تعذر دمج PDF", linkedErrorId = rec?.errorId.orEmpty())
                Result.failure(e)
            }
        }

    fun appendPdfFile(doc: PdfEditableDocument, secondFile: File): Result<PdfEditableDocument> {
        val count = pageRenderer.getPageCount(secondFile)
        if (count <= 0) return Result.failure(IllegalStateException("ملف PDF المدمج لا يحتوي على صفحات صالحة"))
        val extraPages = (0 until count).map { idx ->
            PdfEditablePage(
                sourcePdfPath = secondFile.absolutePath,
                sourcePageIndex = idx,
            )
        }
        return Result.success(doc.copy(pages = doc.pages + extraPages))
    }

    /**
     * Renders a single composite preview Bitmap for any page in [doc] (with crop, rotation, and overlays applied).
     */
    suspend fun renderCompositePagePreview(
        doc: PdfEditableDocument,
        pageIndex: Int,
        scaleFactor: Float = 2.0f,
    ): Bitmap? = withContext(Dispatchers.IO) {
        val page = doc.pages.getOrNull(pageIndex) ?: return@withContext null
        val (baseW, baseH, pageBmp) = renderTransformedBasePage(page, scaleFactor)
        val outBmp = Bitmap.createBitmap(
            (baseW * scaleFactor).roundToInt().coerceAtLeast(240),
            (baseH * scaleFactor).roundToInt().coerceAtLeast(240),
            Bitmap.Config.ARGB_8888,
        )
        val canvas = Canvas(outBmp)
        canvas.drawColor(Color.WHITE)
        if (pageBmp != null) {
            canvas.drawBitmap(pageBmp, null, RectF(0f, 0f, outBmp.width.toFloat(), outBmp.height.toFloat()), null)
            pageBmp.recycle()
        }
        drawOverlaysOnCanvas(
            canvas = canvas,
            pageWidth = outBmp.width.toFloat(),
            pageHeight = outBmp.height.toFloat(),
            overlays = doc.overlays.filter { it.pageIndex == pageIndex },
            pageNumberOneBased = pageIndex + 1,
            totalPages = doc.pages.size,
        )
        outBmp
    }

    /**
     * Non-destructive export: builds a fresh edited PDF copy in [MediaStorageManager.editedPdfsDir]
     * without altering the original file.
     */
    suspend fun exportEditedPdf(
        doc: PdfEditableDocument,
        outputFileName: String? = null,
        selectedPageIndices: List<Int>? = null,
        renderScale: Float = 2.0f,
    ): Result<File> = withContext(Dispatchers.IO) {
        if (doc.pages.isEmpty()) return@withContext Result.failure(IllegalStateException("المستند لا يحتوي على صفحات"))
        val indices = (selectedPageIndices ?: doc.pages.indices.toList())
            .filter { it in doc.pages.indices }
        if (indices.isEmpty()) return@withContext Result.failure(IllegalStateException("لم يتم تحديد صفحات صالحة"))

        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PDF_EDITOR,
            moduleName = DiagnosticModules.PDF,
            operationName = "تصدير PDF المعدل (${doc.title})",
            initialStage = "معالجة ${indices.size} صفحة",
        )
        val pdfSession = sessionFactory.create()
        try {
            indices.forEachIndexed { outIdx, srcIdx ->
                val page = doc.pages[srcIdx]
                val (ptW, ptH, baseBmp) = renderTransformedBasePage(page, renderScale)
                val outW = ptW.roundToInt().coerceIn(120, 2000)
                val outH = ptH.roundToInt().coerceIn(120, 2600)
                val canvas = pdfSession.beginPage(outW, outH, outIdx + 1)
                canvas.drawColor(Color.WHITE)
                if (baseBmp != null) {
                    canvas.drawBitmap(baseBmp, null, RectF(0f, 0f, outW.toFloat(), outH.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
                    baseBmp.recycle()
                }
                drawOverlaysOnCanvas(
                    canvas = canvas,
                    pageWidth = outW.toFloat(),
                    pageHeight = outH.toFloat(),
                    overlays = doc.overlays.filter { it.pageIndex == srcIdx },
                    pageNumberOneBased = outIdx + 1,
                    totalPages = indices.size,
                )
                pdfSession.endPage()
            }

            trace?.stage("كتابة ملف PDF المعدل")
            val clean = (outputFileName ?: "${doc.title}_edited_${System.currentTimeMillis() / 1000}")
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .ifBlank { "edited_document" }
            val outFile = File(mediaStorage.editedPdfsDir, if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
            FileOutputStream(outFile).use { fos -> pdfSession.writeTo(fos) }

            if (doc.documentId > 0L) {
                val updatedDoc = doc.copy(workingPdfPath = outFile.absolutePath)
                saveWorkspaceState(updatedDoc)
                db.pdfDocumentDao().getDocumentOnce(doc.documentId)?.document?.let { ent ->
                    db.pdfDocumentDao().updateDocument(
                        ent.copy(
                            workingFilePath = outFile.absolutePath,
                            fileSizeBytes = outFile.length(),
                            isEditedCopy = true,
                            pageCount = doc.pages.size,
                            updatedAt = System.currentTimeMillis(),
                        ),
                    )
                }
            }
            trace?.succeed("تم تصدير ${outFile.name}")
            Result.success(outFile)
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء تصدير PDF المعدل")
            throw c
        } catch (e: Exception) {
            val rec = errorMonitor?.recordError(e, ScreenNames.PDF_EDITOR, DiagnosticModules.PDF, "تصدير ملف PDF المعدل", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(e.message ?: "تعذر تصدير PDF", linkedErrorId = rec?.errorId.orEmpty())
            Result.failure(e)
        } finally {
            pdfSession.close()
        }
    }

    suspend fun splitPdfIntoSeparateFiles(
        doc: PdfEditableDocument,
        baseName: String,
    ): Result<List<File>> = withContext(Dispatchers.IO) {
        val outFiles = mutableListOf<File>()
        doc.pages.indices.forEach { idx ->
            val res = exportEditedPdf(
                doc = doc,
                outputFileName = "${baseName}_page_${idx + 1}",
                selectedPageIndices = listOf(idx),
            )
            res.getOrNull()?.let { outFiles.add(it) }
                ?: return@withContext Result.failure(res.exceptionOrNull() ?: IllegalStateException("تعذر تقسيم الصفحة ${idx + 1}"))
        }
        Result.success(outFiles)
    }

    /**
     * Scans PDF bytes for embedded JPEG XObject images (SOI FF D8 FF ... EOI FF D9) and verifies decodability.
     */
    suspend fun extractEmbeddedImagesFromPdf(pdfFile: File): List<File> = withContext(Dispatchers.IO) {
        if (!pdfFile.exists() || pdfFile.length() > 32L * 1024L * 1024L) return@withContext emptyList()
        val bytes = pdfFile.readBytes()
        val extracted = mutableListOf<File>()
        var i = 0
        var count = 0
        while (i < bytes.size - 3 && count < 40) {
            if (bytes[i] == 0xFF.toByte() && bytes[i + 1] == 0xD8.toByte() && bytes[i + 2] == 0xFF.toByte()) {
                var endIdx = -1
                var j = i + 3
                while (j < bytes.size - 1 && (j - i) < 8_000_000) {
                    if (bytes[j] == 0xFF.toByte() && bytes[j + 1] == 0xD9.toByte()) {
                        endIdx = j + 2
                        break
                    }
                    j++
                }
                if (endIdx > i + 128) {
                    val slice = bytes.copyOfRange(i, endIdx)
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(slice, 0, slice.size, opts)
                    if (opts.outWidth >= 24 && opts.outHeight >= 24) {
                        val outFile = File(mediaStorage.exportsDir, "pdf_img_${System.currentTimeMillis()}_$count.jpg")
                        FileOutputStream(outFile).use { it.write(slice) }
                        extracted.add(outFile)
                        count++
                        i = endIdx
                        continue
                    }
                }
            }
            i++
        }
        extracted
    }

    /**
     * Extracts plain parenthesized PDF text literals (BT ... ET) when present in uncompressed PDF content.
     */
    fun extractPlainPdfTextLiterals(pdfFile: File): String {
        if (!pdfFile.exists() || pdfFile.length() > 32L * 1024L * 1024L) return ""
        return try {
            val raw = pdfFile.readBytes().toString(Charsets.ISO_8859_1)
            val regex = Regex("\\(([^()]{2,240})\\)\\s*Tj")
            val matches = regex.findAll(raw).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.toList()
            matches.take(80).joinToString("\n")
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Runs on-device ML Kit text recognition on the currently rendered PDF page bitmap.
     */
    suspend fun recognizeTextOcr(bitmap: Bitmap): Result<String> = withContext(Dispatchers.Default) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PDF_EDITOR,
            moduleName = DiagnosticModules.PDF,
            operationName = "التعرف الضوئي على النص OCR في PDF",
            initialStage = "تشغيل محرك ML Kit OCR",
        )
        suspendCancellableCoroutine { cont ->
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            val taskInFlight = AtomicBoolean(false)
            val closedFlag = AtomicBoolean(false)
            fun closeSafelyOnce() {
                if (closedFlag.compareAndSet(false, true)) {
                    runCatching { recognizer.close() }
                }
            }
            cont.invokeOnCancellation {
                trace?.cancel("تم إلغاء عملية OCR")
                if (!taskInFlight.get()) {
                    closeSafelyOnce()
                }
            }
            try {
                val inputImage = InputImage.fromBitmap(bitmap, 0)
                taskInFlight.set(true)
                recognizer.process(inputImage)
                    .addOnSuccessListener { result ->
                        val text = result.text.trim()
                        if (cont.isActive) {
                            trace?.succeed("تم استخراج ${text.length} حرف")
                            cont.resume(Result.success(text))
                        }
                    }
                    .addOnFailureListener { err ->
                        if (cont.isActive) {
                            val rec = errorMonitor?.recordError(
                                throwable = err,
                                screenName = ScreenNames.PDF_EDITOR,
                                moduleName = DiagnosticModules.PDF,
                                operationName = "التعرف الضوئي على النص OCR في PDF",
                                linkedOperationId = trace?.operationId.orEmpty(),
                            )
                            trace?.fail(err.message ?: "فشل OCR", linkedErrorId = rec?.errorId.orEmpty())
                            cont.resume(Result.failure(err))
                        }
                    }
                    .addOnCompleteListener {
                        taskInFlight.set(false)
                        closeSafelyOnce()
                    }
            } catch (e: Exception) {
                taskInFlight.set(false)
                closeSafelyOnce()
                if (cont.isActive) {
                    val rec = errorMonitor?.recordError(
                        throwable = e,
                        screenName = ScreenNames.PDF_EDITOR,
                        moduleName = DiagnosticModules.PDF,
                        operationName = "التعرف الضوئي على النص OCR في PDF",
                        linkedOperationId = trace?.operationId.orEmpty(),
                    )
                    trace?.fail(e.message ?: "فشل OCR", linkedErrorId = rec?.errorId.orEmpty())
                    cont.resume(Result.failure(e))
                }
            }
        }
    }

    private fun renderTransformedBasePage(page: PdfEditablePage, scaleFactor: Float): Triple<Float, Float, Bitmap?> {
        if (page.isBlankPage || page.sourcePdfPath.isBlank()) {
            val rot = ((page.rotationDegrees % 360) + 360) % 360
            val swap = rot == 90 || rot == 270
            val w = if (swap) page.blankHeightPt else page.blankWidthPt
            val h = if (swap) page.blankWidthPt else page.blankHeightPt
            return Triple(w, h, null)
        }
        val rendered = pageRenderer.renderPage(File(page.sourcePdfPath), page.sourcePageIndex, scaleFactor)
        val rawBmp = rendered.bitmap
        val origW = rendered.pageWidthPt.coerceAtLeast(100f)
        val origH = rendered.pageHeightPt.coerceAtLeast(100f)
        if (rawBmp == null) {
            return Triple(origW, origH, null)
        }

        // Apply Crop
        val cl = page.cropLeft.coerceIn(0f, 0.45f)
        val ct = page.cropTop.coerceIn(0f, 0.45f)
        val cr = page.cropRight.coerceIn(cl + 0.1f, 1f)
        val cb = page.cropBottom.coerceIn(ct + 0.1f, 1f)
        val cropX = (cl * rawBmp.width).roundToInt().coerceIn(0, rawBmp.width - 1)
        val cropY = (ct * rawBmp.height).roundToInt().coerceIn(0, rawBmp.height - 1)
        val cropW = ((cr - cl) * rawBmp.width).roundToInt().coerceIn(8, rawBmp.width - cropX)
        val cropH = ((cb - ct) * rawBmp.height).roundToInt().coerceIn(8, rawBmp.height - cropY)
        var current = if (cropX > 0 || cropY > 0 || cropW < rawBmp.width || cropH < rawBmp.height) {
            Bitmap.createBitmap(rawBmp, cropX, cropY, cropW, cropH).also { rawBmp.recycle() }
        } else {
            rawBmp
        }

        var ptW = origW * (cr - cl)
        var ptH = origH * (cb - ct)

        // Apply Rotation
        val rot = ((page.rotationDegrees % 360) + 360) % 360
        if (rot != 0) {
            val m = Matrix().apply { postRotate(rot.toFloat()) }
            val rotated = Bitmap.createBitmap(current, 0, 0, current.width, current.height, m, true)
            current.recycle()
            current = rotated
            if (rot == 90 || rot == 270) {
                val tmp = ptW
                ptW = ptH
                ptH = tmp
            }
        }
        return Triple(ptW, ptH, current)
    }

    private fun drawOverlaysOnCanvas(
        canvas: Canvas,
        pageWidth: Float,
        pageHeight: Float,
        overlays: List<PdfOverlayItem>,
        pageNumberOneBased: Int,
        totalPages: Int,
    ) {
        val cairo = try {
            ResourcesCompat.getFont(context, R.font.cairo)
        } catch (_: Exception) {
            Typeface.DEFAULT
        }
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        overlays.forEach { ov ->
            val left = ov.xFraction.coerceIn(0f, 0.95f) * pageWidth
            val top = ov.yFraction.coerceIn(0f, 0.95f) * pageHeight
            val w = (ov.widthFraction.coerceIn(0.03f, 1f) * pageWidth).coerceAtMost(pageWidth - left)
            val h = (ov.heightFraction.coerceIn(0.02f, 1f) * pageHeight).coerceAtMost(pageHeight - top)
            val box = RectF(left, top, left + w, top + h)

            val strokeColor = parseAndroidColor(ov.colorHex, Color.parseColor("#0F172A"))
            val fillColor = parseAndroidColor(ov.fillColorHex, Color.WHITE)
            val scaleFactor = (pageWidth / 595f).coerceIn(0.5f, 4f)

            when (ov.type) {
                PdfOverlayType.COVER_BOX -> {
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = fillColor
                        style = Paint.Style.FILL
                        alpha = (ov.alpha * 255).roundToInt().coerceIn(20, 255)
                    }
                    canvas.drawRect(box, p)
                }
                PdfOverlayType.HIGHLIGHT -> {
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb(95, 250, 204, 21)
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(box, p)
                }
                PdfOverlayType.RECTANGLE -> {
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = strokeColor
                        style = Paint.Style.STROKE
                        strokeWidth = ov.strokeWidthPt * scaleFactor
                    }
                    canvas.drawRect(box, p)
                }
                PdfOverlayType.LINE -> {
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = strokeColor
                        strokeWidth = ov.strokeWidthPt * scaleFactor
                    }
                    canvas.drawLine(box.left, box.centerY(), box.right, box.centerY(), p)
                }
                PdfOverlayType.CALLOUT -> {
                    val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.parseColor("#FEF3C7")
                        style = Paint.Style.FILL
                    }
                    val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.parseColor("#D97706")
                        style = Paint.Style.STROKE
                        strokeWidth = 1.5f * scaleFactor
                    }
                    canvas.drawRoundRect(box, 6f * scaleFactor, 6f * scaleFactor, bg)
                    canvas.drawRoundRect(box, 6f * scaleFactor, 6f * scaleFactor, border)
                    drawRtlStaticText(canvas, ov.text, box, strokeColor, ov.fontSizeSp * scaleFactor, cairo)
                }
                PdfOverlayType.IMAGE -> {
                    if (ov.imagePath.isNotBlank() && File(ov.imagePath).exists()) {
                        val bmp = mediaStorage.decodeSampledBitmap(ov.imagePath, 1200)
                        if (bmp != null) {
                            val srcRect = Rect(0, 0, bmp.width, bmp.height)
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                alpha = (ov.alpha * 255).roundToInt().coerceIn(30, 255)
                            }
                            canvas.drawBitmap(bmp, srcRect, box, paint)
                            bmp.recycle()
                        }
                    }
                }
                PdfOverlayType.DATE_STAMP -> {
                    val label = ov.text.ifBlank { "التاريخ: $todayStr" }
                    drawRtlStaticText(canvas, label, box, strokeColor, ov.fontSizeSp * scaleFactor, cairo)
                }
                PdfOverlayType.PAGE_NUMBER -> {
                    val label = ov.text.ifBlank { "صفحة $pageNumberOneBased من $totalPages" }
                    drawRtlStaticText(canvas, label, box, strokeColor, ov.fontSizeSp * scaleFactor, cairo)
                }
                PdfOverlayType.TEXT -> {
                    if (ov.text.isNotBlank()) {
                        drawRtlStaticText(canvas, ov.text, box, strokeColor, ov.fontSizeSp * scaleFactor, cairo)
                    }
                }
            }
        }
    }

    private fun drawRtlStaticText(
        canvas: Canvas,
        text: String,
        box: RectF,
        textColor: Int,
        textSizePx: Float,
        typeface: Typeface?,
    ) {
        if (text.isBlank()) return
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = textSizePx.coerceIn(7f, 72f)
            this.typeface = typeface ?: Typeface.DEFAULT
        }
        val availW = box.width().toInt().coerceAtLeast(24)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, availW)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.clipRect(box)
        canvas.translate(box.left + 2f, box.top + 2f)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun parseAndroidColor(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(idx) ?: "document.pdf"
            }
        }
        return uri.lastPathSegment ?: "document.pdf"
    }
}
