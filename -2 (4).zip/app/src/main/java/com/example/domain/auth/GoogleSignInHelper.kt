package com.example.domain.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.ScreenNames
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

sealed interface GoogleCredentialFetchResult {
    data class IdToken(val token: String) : GoogleCredentialFetchResult
    data object Cancelled : GoogleCredentialFetchResult
    data object NotConfigured : GoogleCredentialFetchResult
    data class Failure(val arabicMessage: String, val isNetworkOrUnavailable: Boolean = false) : GoogleCredentialFetchResult
}

/**
 * Official Google Sign-In helper using Jetpack Credential Manager (`GetSignInWithGoogleOption`).
 * One credential option per GetCredentialRequest for API 36 responsiveness.
 */
class GoogleSignInHelper(
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    suspend fun requestGoogleIdToken(
        context: Context,
        webClientId: String?,
    ): GoogleCredentialFetchResult {
        if (webClientId.isNullOrBlank()) {
            return GoogleCredentialFetchResult.NotConfigured
        }
        val activity = context.findActivity()
            ?: return GoogleCredentialFetchResult.Failure(
                "تعذر فتح نافذة اختيار حساب Google من هذا السياق.",
            )

        return try {
            val signInOption = GetSignInWithGoogleOption.Builder(webClientId)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()
            val credentialManager = CredentialManager.create(activity)
            val result = credentialManager.getCredential(
                context = activity,
                request = request,
            )
            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdCred = GoogleIdTokenCredential.createFrom(credential.data)
                GoogleCredentialFetchResult.IdToken(googleIdCred.idToken)
            } else {
                GoogleCredentialFetchResult.Failure("نوع بيانات اعتماد Google المستلم غير مدعوم.")
            }
        } catch (e: GetCredentialCancellationException) {
            errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.AUTH,
                moduleName = DiagnosticModules.AUTH,
                operationName = "إلغاء نافذة Google Sign-In",
                wasHandled = true,
                severity = LogSeverity.INFO,
            )
            GoogleCredentialFetchResult.Cancelled
        } catch (e: NoCredentialException) {
            errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.AUTH,
                moduleName = DiagnosticModules.AUTH,
                operationName = "لا توجد حسابات Google متاحة على الجهاز",
                wasHandled = true,
                severity = LogSeverity.WARNING,
            )
            GoogleCredentialFetchResult.Failure(
                "لم يتم العثور على حساب Google جاهز على الجهاز أو تعذر التحقق من شهادة التطبيق في Firebase.",
                isNetworkOrUnavailable = true,
            )
        } catch (e: GetCredentialException) {
            errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.AUTH,
                moduleName = DiagnosticModules.AUTH,
                operationName = "طلب Google Sign-In عبر Credential Manager",
                wasHandled = true,
                severity = LogSeverity.WARNING,
            )
            GoogleCredentialFetchResult.Failure(
                "تعذر إتمام تسجيل الدخول عبر Google. تحقق من اتصال الإنترنت وإعدادات Firebase.",
                isNetworkOrUnavailable = true,
            )
        } catch (t: Throwable) {
            errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.AUTH,
                moduleName = DiagnosticModules.AUTH,
                operationName = "Google Sign-In",
                wasHandled = true,
                severity = LogSeverity.ERROR,
            )
            GoogleCredentialFetchResult.Failure("حدث خطأ غير متوقع أثناء تشغيل Google Sign-In.")
        }
    }

    suspend fun clearCredentialState(context: Context) {
        runCatching {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        }
    }

    private tailrec fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
}
