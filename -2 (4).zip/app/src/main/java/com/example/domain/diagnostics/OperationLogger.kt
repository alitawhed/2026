package com.example.domain.diagnostics

import com.example.data.local.dao.DiagnosticsDao
import com.example.data.local.entity.OperationLogEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

class OperationTrace internal constructor(
    val operationId: String,
    private val logger: OperationLogger,
) {
    fun stage(stageName: String, detail: String = "", status: String = "DONE") {
        logger.appendStage(operationId, stageName, detail, status)
    }

    fun succeed(detail: String = "") {
        logger.finishOperation(
            operationId = operationId,
            outcome = OperationOutcome.SUCCESS,
            severity = LogSeverity.INFO,
            detail = detail,
        )
    }

    fun warn(detail: String) {
        logger.finishOperation(
            operationId = operationId,
            outcome = OperationOutcome.WARNING,
            severity = LogSeverity.WARNING,
            failureReason = detail,
            detail = detail,
        )
    }

    fun cancel(reason: String = "تم إلغاء العملية") {
        logger.finishOperation(
            operationId = operationId,
            outcome = OperationOutcome.CANCELLED,
            severity = LogSeverity.INFO,
            failureReason = reason,
            detail = reason,
        )
    }

    fun fail(reason: String, linkedErrorId: String = "", severity: LogSeverity = LogSeverity.ERROR) {
        logger.finishOperation(
            operationId = operationId,
            outcome = OperationOutcome.FAILED,
            severity = severity,
            failureReason = reason,
            linkedErrorId = linkedErrorId,
        )
    }

    fun snapshotStages(): List<OperationStageRecord> =
        logger.getOperationStages(operationId)
}

class OperationLogger(
    private val fileStore: DiagnosticsFileStore,
    private var diagnosticsDaoProvider: (() -> DiagnosticsDao?)? = null,
) {
    private val lock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val records = mutableListOf<OperationLogRecord>()
    private val _operations = MutableStateFlow<List<OperationLogRecord>>(emptyList())
    val operations: StateFlow<List<OperationLogRecord>> = _operations.asStateFlow()

    @Volatile
    var activeOperationId: String = ""
        private set

    @Volatile
    var activeOperationName: String = "idle"
        private set

    @Volatile
    var activeStageName: String = ""
        private set

    @Volatile
    private var onOperationsChangedListener: (() -> Unit)? = null

    init {
        loadFromStore()
    }

    fun setOnOperationsChangedListener(listener: (() -> Unit)?) {
        onOperationsChangedListener = listener
        listener?.invoke()
    }

    fun attachDaoProvider(provider: () -> DiagnosticsDao?) {
        diagnosticsDaoProvider = provider
    }

    fun loadFromStore() {
        synchronized(lock) {
            val loaded = fileStore.readAllOperations()
            records.clear()
            records.addAll(loaded)
            _operations.value = records.toList()
        }
        onOperationsChangedListener?.invoke()
    }

    fun startOperation(
        screenName: String,
        moduleName: String,
        operationName: String,
        initialStage: String = "بدأت العملية",
    ): OperationTrace {
        val opId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val cleanInitialStage = DiagnosticSanitizer.sanitizeText(initialStage, 180)
        val rec = OperationLogRecord(
            operationId = opId,
            startTime = now,
            endTime = 0L,
            screenName = DiagnosticSanitizer.sanitizeText(screenName, 120),
            moduleName = DiagnosticSanitizer.sanitizeText(moduleName, 80),
            operationName = DiagnosticSanitizer.sanitizeText(operationName, 160),
            severity = LogSeverity.INFO,
            outcome = OperationOutcome.RUNNING,
            currentStage = cleanInitialStage,
            lastSuccessfulStage = "",
            interruptedAbnormally = false,
            stages = listOf(
                OperationStageRecord(
                    stageName = cleanInitialStage,
                    timestamp = now,
                    status = "STARTED",
                ),
            ),
        )
        activeOperationId = opId
        activeOperationName = rec.operationName
        activeStageName = cleanInitialStage
        val snapshot: List<OperationLogRecord>
        synchronized(lock) {
            records.add(0, rec)
            if (records.size > DiagnosticsFileStore.MAX_IN_MEMORY_OPS) {
                records.subList(DiagnosticsFileStore.MAX_IN_MEMORY_OPS, records.size).clear()
            }
            snapshot = records.toList()
            _operations.value = snapshot
        }
        persistDurableSynchronous(rec, snapshot)
        onOperationsChangedListener?.invoke()
        return OperationTrace(opId, this)
    }

    fun logQuickEvent(
        screenName: String,
        moduleName: String,
        operationName: String,
        outcome: OperationOutcome = OperationOutcome.SUCCESS,
        severity: LogSeverity = LogSeverity.INFO,
        detail: String = "",
    ) {
        val normalizedOutcome = if (outcome == OperationOutcome.STARTED || outcome == OperationOutcome.RUNNING) {
            OperationOutcome.SUCCESS
        } else {
            outcome
        }
        val now = System.currentTimeMillis()
        val cleanOpName = DiagnosticSanitizer.sanitizeText(operationName, 160)
        val rec = OperationLogRecord(
            operationId = UUID.randomUUID().toString(),
            startTime = now,
            endTime = now,
            screenName = DiagnosticSanitizer.sanitizeText(screenName, 120),
            moduleName = DiagnosticSanitizer.sanitizeText(moduleName, 80),
            operationName = cleanOpName,
            severity = severity,
            outcome = normalizedOutcome,
            currentStage = cleanOpName,
            lastSuccessfulStage = if (normalizedOutcome == OperationOutcome.SUCCESS) cleanOpName else "",
            failureReason = if (normalizedOutcome == OperationOutcome.FAILED || normalizedOutcome == OperationOutcome.CANCELLED) {
                DiagnosticSanitizer.sanitizeText(detail, 500)
            } else {
                ""
            },
            stages = listOf(
                OperationStageRecord(
                    stageName = cleanOpName,
                    timestamp = now,
                    status = normalizedOutcome.name,
                    detail = DiagnosticSanitizer.sanitizeText(detail, 400),
                ),
            ),
        )
        val snapshot: List<OperationLogRecord>
        synchronized(lock) {
            records.add(0, rec)
            if (records.size > DiagnosticsFileStore.MAX_IN_MEMORY_OPS) {
                records.subList(DiagnosticsFileStore.MAX_IN_MEMORY_OPS, records.size).clear()
            }
            snapshot = records.toList()
            _operations.value = snapshot
        }
        persistDurableSynchronous(rec, snapshot)
        onOperationsChangedListener?.invoke()
    }

    internal fun appendStage(
        operationId: String,
        stageName: String,
        detail: String = "",
        status: String = "DONE",
    ) {
        val now = System.currentTimeMillis()
        val cleanStage = DiagnosticSanitizer.sanitizeText(stageName, 180)
        var updated: OperationLogRecord? = null
        var snapshot: List<OperationLogRecord>? = null
        synchronized(lock) {
            val idx = records.indexOfFirst { it.operationId == operationId }
            if (idx >= 0) {
                val cur = records[idx]
                val stage = OperationStageRecord(
                    stageName = cleanStage,
                    timestamp = now,
                    status = status,
                    detail = DiagnosticSanitizer.sanitizeText(detail, 400),
                )
                val nextLastSuccess = if (status in setOf("DONE", "SUCCESS", "OK", "PASSED", "VERIFIED")) {
                    cleanStage
                } else {
                    cur.lastSuccessfulStage
                }
                updated = cur.copy(
                    currentStage = cleanStage,
                    lastSuccessfulStage = nextLastSuccess,
                    stages = (cur.stages + stage).takeLast(50),
                )
                records[idx] = updated!!
                snapshot = records.toList()
                _operations.value = snapshot!!
            }
        }
        if (activeOperationId == operationId) {
            activeStageName = cleanStage
        }
        if (updated != null && snapshot != null) {
            persistDurableSynchronous(updated!!, snapshot!!)
            onOperationsChangedListener?.invoke()
        }
    }

    fun appendPostRestartVerificationStage(
        operationId: String,
        stageName: String,
        passed: Boolean,
        detail: String,
        linkedErrorId: String = "",
    ) {
        val now = System.currentTimeMillis()
        val cleanStage = DiagnosticSanitizer.sanitizeText(stageName, 180)
        var updated: OperationLogRecord? = null
        var snapshot: List<OperationLogRecord>? = null
        synchronized(lock) {
            val idx = records.indexOfFirst { it.operationId == operationId }
            if (idx >= 0) {
                val cur = records[idx]
                val stage = OperationStageRecord(
                    stageName = cleanStage,
                    timestamp = now,
                    status = if (passed) "DONE" else "FAILED",
                    detail = DiagnosticSanitizer.sanitizeText(detail, 400),
                )
                updated = cur.copy(
                    endTime = now,
                    currentStage = cleanStage,
                    lastSuccessfulStage = if (passed) cleanStage else cur.lastSuccessfulStage,
                    outcome = if (passed) cur.outcome else OperationOutcome.FAILED,
                    severity = if (passed) cur.severity else LogSeverity.CRITICAL,
                    failureReason = if (passed) cur.failureReason else DiagnosticSanitizer.sanitizeText(detail, 600),
                    linkedErrorId = linkedErrorId.ifBlank { cur.linkedErrorId },
                    stages = (cur.stages + stage).takeLast(50),
                )
                records[idx] = updated!!
                snapshot = records.toList()
                _operations.value = snapshot!!
            }
        }
        if (updated != null && snapshot != null) {
            persistDurableSynchronous(updated!!, snapshot!!)
            onOperationsChangedListener?.invoke()
        }
    }

    internal fun finishOperation(
        operationId: String,
        outcome: OperationOutcome,
        severity: LogSeverity,
        failureReason: String = "",
        linkedErrorId: String = "",
        detail: String = "",
    ) {
        val now = System.currentTimeMillis()
        var updated: OperationLogRecord? = null
        var snapshot: List<OperationLogRecord>? = null
        synchronized(lock) {
            val idx = records.indexOfFirst { it.operationId == operationId }
            if (idx >= 0) {
                val cur = records[idx]
                val finalStageLabel = when (outcome) {
                    OperationOutcome.SUCCESS -> "اكتملت العملية بنجاح"
                    OperationOutcome.WARNING -> "اكتملت مع تحذير"
                    OperationOutcome.FAILED -> "فشلت العملية عند: ${cur.currentStage.ifBlank { cur.operationName }}"
                    OperationOutcome.CANCELLED -> "تم إلغاء العملية"
                    OperationOutcome.STARTED, OperationOutcome.RUNNING -> "تحديث"
                }
                val finalStage = OperationStageRecord(
                    stageName = finalStageLabel,
                    timestamp = now,
                    status = outcome.name,
                    detail = DiagnosticSanitizer.sanitizeText(
                        detail.ifBlank { failureReason },
                        400,
                    ),
                )
                val lastSuccess = if (outcome == OperationOutcome.SUCCESS) {
                    finalStageLabel
                } else {
                    cur.lastSuccessfulStage.ifBlank {
                        cur.stages.lastOrNull {
                            it.status in setOf("DONE", "SUCCESS", "OK", "PASSED", "STARTED")
                        }?.stageName.orEmpty()
                    }
                }
                updated = cur.copy(
                    endTime = now,
                    outcome = outcome,
                    severity = severity,
                    currentStage = if (outcome == OperationOutcome.SUCCESS) finalStageLabel else cur.currentStage.ifBlank { finalStageLabel },
                    lastSuccessfulStage = lastSuccess,
                    failureReason = DiagnosticSanitizer.sanitizeText(failureReason, 600),
                    linkedErrorId = linkedErrorId.ifBlank { cur.linkedErrorId },
                    stages = (cur.stages + finalStage).takeLast(50),
                )
                records[idx] = updated!!
                snapshot = records.toList()
                _operations.value = snapshot!!
            }
        }
        if (activeOperationId == operationId) {
            activeOperationId = ""
            activeOperationName = "idle"
            activeStageName = ""
        }
        if (updated != null && snapshot != null) {
            persistDurableSynchronous(updated!!, snapshot!!)
            onOperationsChangedListener?.invoke()
        }
    }

    /**
     * On startup or crash recovery, transitions any leftover STARTED/RUNNING operations
     * from a terminated/crashed session to FAILED with interruptedAbnormally = true,
     * preserving currentStage and lastSuccessfulStage.
     */
    fun reconcileInterruptedOperations(
        crashErrorId: String = "",
        crashDescription: String = "",
    ): List<OperationLogRecord> {
        val now = System.currentTimeMillis()
        val reconciled = mutableListOf<OperationLogRecord>()
        var snapshot: List<OperationLogRecord>? = null
        synchronized(lock) {
            for (i in records.indices) {
                val cur = records[i]
                if (cur.outcome == OperationOutcome.RUNNING || cur.outcome == OperationOutcome.STARTED) {
                    val lastSuccess = cur.lastSuccessfulStage.ifBlank {
                        cur.stages.lastOrNull { it.status in setOf("DONE", "SUCCESS", "OK", "STARTED") }?.stageName.orEmpty()
                    }
                    val stageAtCrash = cur.currentStage.ifBlank {
                        cur.stages.lastOrNull()?.stageName ?: cur.operationName
                    }
                    val reason = DiagnosticSanitizer.sanitizeText(
                        crashDescription.ifBlank {
                            "انقطع التشغيل بشكل غير طبيعي أثناء المرحلة: $stageAtCrash"
                        },
                        600,
                    )
                    val interruptedStage = OperationStageRecord(
                        stageName = "انقطاع غير متوقع للتطبيق قبل اكتمال العملية",
                        timestamp = now,
                        status = "INTERRUPTED",
                        detail = reason,
                    )
                    val fixed = cur.copy(
                        endTime = now,
                        outcome = OperationOutcome.FAILED,
                        severity = LogSeverity.CRITICAL,
                        currentStage = stageAtCrash,
                        lastSuccessfulStage = lastSuccess,
                        interruptedAbnormally = true,
                        failureReason = reason,
                        linkedErrorId = crashErrorId.ifBlank { cur.linkedErrorId },
                        stages = (cur.stages + interruptedStage).takeLast(50),
                    )
                    records[i] = fixed
                    reconciled.add(fixed)
                }
            }
            if (reconciled.isNotEmpty()) {
                snapshot = records.toList()
                _operations.value = snapshot!!
            }
        }
        if (reconciled.isNotEmpty() && snapshot != null) {
            fileStore.writeAllOperations(snapshot!!, syncToDisk = true)
            scope.launch {
                reconciled.forEach { rec -> mirrorToRoom(rec) }
            }
            onOperationsChangedListener?.invoke()
        }
        return reconciled
    }

    fun linkOperationsToError(operationIds: List<String>, errorId: String) {
        if (operationIds.isEmpty() || errorId.isBlank()) return
        val targetIds = operationIds.toSet()
        val updatedList = mutableListOf<OperationLogRecord>()
        var snapshot: List<OperationLogRecord>? = null
        synchronized(lock) {
            for (i in records.indices) {
                val cur = records[i]
                if (cur.operationId in targetIds && cur.linkedErrorId.isBlank()) {
                    val fixed = cur.copy(linkedErrorId = errorId)
                    records[i] = fixed
                    updatedList.add(fixed)
                }
            }
            if (updatedList.isNotEmpty()) {
                snapshot = records.toList()
                _operations.value = snapshot!!
            }
        }
        if (updatedList.isNotEmpty() && snapshot != null) {
            fileStore.writeAllOperations(snapshot!!, syncToDisk = true)
            scope.launch {
                updatedList.forEach { rec -> mirrorToRoom(rec) }
            }
            onOperationsChangedListener?.invoke()
        }
    }

    internal fun getOperationStages(operationId: String): List<OperationStageRecord> {
        synchronized(lock) {
            return records.firstOrNull { it.operationId == operationId }?.stages.orEmpty()
        }
    }

    fun getLastFailedOperation(): OperationLogRecord? {
        synchronized(lock) {
            return records.firstOrNull { it.outcome == OperationOutcome.FAILED }
        }
    }

    fun clearAll() {
        activeOperationId = ""
        activeOperationName = "idle"
        activeStageName = ""
        synchronized(lock) {
            records.clear()
            _operations.value = emptyList()
        }
        fileStore.writeAllOperations(emptyList(), syncToDisk = true)
        scope.launch {
            runCatching { diagnosticsDaoProvider?.invoke()?.clearAllOperations() }
        }
        onOperationsChangedListener?.invoke()
    }

    private fun persistDurableSynchronous(record: OperationLogRecord, snapshot: List<OperationLogRecord>) {
        fileStore.writeAllOperations(snapshot, syncToDisk = true)
        scope.launch {
            mirrorToRoom(record)
        }
    }

    private suspend fun mirrorToRoom(record: OperationLogRecord) {
        if (record.moduleName == "SQLite" || record.moduleName == DiagnosticModules.SQLITE) return
        runCatching {
            diagnosticsDaoProvider?.invoke()?.upsertOperation(
                OperationLogEntity(
                    operationId = record.operationId,
                    startTime = record.startTime,
                    endTime = record.endTime,
                    screenName = record.screenName,
                    moduleName = record.moduleName,
                    operationName = record.operationName,
                    severity = record.severity.name,
                    outcome = record.outcome.name,
                    currentStage = record.currentStage,
                    lastSuccessfulStage = record.lastSuccessfulStage,
                    interruptedAbnormally = record.interruptedAbnormally,
                    failureReason = record.failureReason,
                    linkedErrorId = record.linkedErrorId,
                    stagesJson = json.encodeToString(record.stages),
                ),
            )
        }
    }
}
