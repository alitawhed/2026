package com.example.domain.excel

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.ImageDownloadStatus
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportWithDetails
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.toNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.ColumnType
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.PageOrientation
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExcelExportEngine(
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {

    fun exportProductsToXlsx(
        products: List<ProductWithDetails>,
        fileName: String,
        sheetName: String = "المنتجات",
        includeImages: Boolean = true,
        productsNumericConfig: ProductsNumericConfig = ProductsNumericConfig(),
    ): File {
        val headers = listOf(
            "ID",
            "اسم المنتج",
            "الباركود الرئيسي",
            "باركودات إضافية",
            "الوحدات ومعاملات التحويل",
            "التصنيف",
            "السعر الأساسي",
            "العملة",
            "بلد المنشأ",
            "المصنع",
            "الكمية الافتراضية",
            "الوصف",
            "ملاحظات",
            "الصورة",
        )
        val colWidths = listOf(14, 28, 20, 26, 30, 16, 14, 10, 14, 18, 14, 28, 24, 16)
        val numericCols = setOf(6, 10)
        val numericFormats = mapOf(
            6 to productsNumericConfig.priceFormat,
            10 to productsNumericConfig.quantityFormat,
        )
        val imageCol = if (includeImages) 13 else null

        val rows = products.map { p ->
            val primaryCode = p.primaryBarcode?.barcodeValue.orEmpty()
            val extraCodes = p.barcodes.filter { it.barcodeValue != primaryCode }.joinToString(", ") { it.barcodeValue }
            val unitSummary = p.barcodes.joinToString(" | ") { b ->
                val prefix = if (b.isPrimary) "[رئيسي] " else ""
                val convStr = NumberFormatEngine.formatDouble(
                    b.conversionFactor,
                    productsNumericConfig.conversionFactorFormat,
                )
                "$prefix${b.barcodeValue}: ${b.unitType}×$convStr"
            }
            listOf(
                p.product.internalCode,
                p.product.name,
                primaryCode,
                extraCodes,
                unitSummary,
                p.product.categoryName,
                p.product.basePrice.toString(),
                p.product.currency,
                p.product.originCountry,
                p.product.manufacturer,
                p.product.defaultQuantity.toString(),
                p.product.description,
                p.product.notes,
                "",
            )
        }
        val imagePaths = products.map { it.primaryImage?.filePath }

        val outFile = File(mediaStorage.exportsDir, ensureExt(fileName, "xlsx"))
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تصدير المنتجات إلى Excel",
            initialStage = "كتابة ${rows.size} منتج",
        )
        try {
            writeXlsxWorkbook(
                outFile = outFile,
                sheetName = sanitizeSheetName(sheetName),
                headers = headers,
                rows = rows,
                colWidths = colWidths,
                numericColumnIndices = numericCols,
                columnNumberFormats = numericFormats,
                imageColumnIndex = imageCol,
                imagePathsPerRow = imagePaths,
                landscape = true,
            )
            trace?.succeed("تم تصدير ${outFile.name}")
            return outFile
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.PRODUCTS,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "تصدير المنتجات إلى Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر التصدير إلى Excel", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    fun exportInventoryReportToXlsx(
        sessionDetails: InventorySessionWithDetails,
        allProducts: List<ProductWithDetails>,
        fileName: String,
        inventoryConfig: InventorySheetConfig = InventorySheetConfig(),
    ): File {
        val productMap = allProducts.associateBy { it.product.id }
        val items = sessionDetails.sortedItems
        val visibleCols = inventoryConfig.columns.filter { it.visible }.sortedBy { it.sortOrder }
            .ifEmpty { InventoryColumnDefaults.defaultColumns() }

        val headers = visibleCols.map { it.title }
        val colWidths = visibleCols.map { col ->
            val baseKey = col.columnKey.substringBefore("_copy_")
            val defaultW = when (col.columnType) {
                ColumnType.SERIAL -> 8
                ColumnType.IMAGE -> 16
                ColumnType.BARCODE -> 22
                ColumnType.QR_CODE -> 18
                ColumnType.TEXT -> when (baseKey) {
                    "name" -> 30
                    "barcode_text" -> 22
                    else -> 16
                }
                ColumnType.NOTES -> 26
                else -> 14
            }
            val ptBased = (col.manualWidthPt / 4.2f).toInt().coerceIn(8, 52)
            maxOf(defaultW, ptBased)
        }
        val numericCols = visibleCols.mapIndexedNotNull { idx, col ->
            if (col.columnType in setOf(
                    ColumnType.SERIAL,
                    ColumnType.QUANTITY,
                    ColumnType.NUMBER,
                    ColumnType.PRICE,
                    ColumnType.CURRENCY,
                    ColumnType.PERCENTAGE,
                )
            ) {
                idx
            } else {
                null
            }
        }.toSet()
        val numericFormats = visibleCols.mapIndexedNotNull { idx, col ->
            when {
                col.columnType == ColumnType.SERIAL -> idx to NumberFormatSpec(
                    decimalPlaces = 0,
                    autoDecimals = false,
                    stripTrailingZeros = false,
                    useGrouping = false,
                )
                idx in numericCols -> idx to col.toNumberFormatSpec()
                else -> null
            }
        }.toMap()
        val imageColIdx = if (inventoryConfig.showProductImages) {
            visibleCols.indexOfFirst { it.columnType == ColumnType.IMAGE }.takeIf { it >= 0 }
        } else {
            null
        }
        val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        val rows = items.mapIndexed { idx, item ->
            val product = item.productId?.let { productMap[it] }
            visibleCols.map { col ->
                val baseKey = col.columnKey.substringBefore("_copy_")
                when (baseKey) {
                    "serial" -> (idx + 1).toString()
                    "image" -> ""
                    "internal_code" -> product?.product?.internalCode?.ifBlank { item.productInternalCode }
                        ?: item.productInternalCode
                    "name" -> item.productName
                    "barcode", "barcode_text", "qr_code" -> InventoryColumnDefaults.resolveBarcodeValue(
                        item = item,
                        product = product,
                        mode = inventoryConfig.barcodeSourceMode,
                    )
                    "barcode_type" -> InventoryColumnDefaults.resolveBarcodeFormat(item, product, inventoryConfig).arabicLabel
                    "quantity" -> item.countedQty.toString()
                    "base_qty" -> item.baseUnitEquivalentQty.toString()
                    "unit" -> item.unitType
                    "conversion_factor" -> item.conversionFactor.toString()
                    "category" -> product?.product?.categoryName.orEmpty()
                    "scanned_at" -> timeFmt.format(Date(item.scannedAt))
                    "notes" -> item.notes
                    else -> when (col.columnType) {
                        ColumnType.SERIAL -> (idx + 1).toString()
                        ColumnType.IMAGE -> ""
                        ColumnType.QUANTITY, ColumnType.NUMBER -> item.countedQty.toString()
                        ColumnType.PRICE, ColumnType.CURRENCY -> (product?.product?.basePrice ?: 0.0).toString()
                        ColumnType.PERCENTAGE -> "0"
                        ColumnType.BARCODE, ColumnType.QR_CODE -> InventoryColumnDefaults.resolveBarcodeValue(
                            item,
                            product,
                            inventoryConfig.barcodeSourceMode,
                        )
                        ColumnType.NOTES -> item.notes
                        ColumnType.DATE -> timeFmt.format(Date(item.scannedAt))
                        else -> ""
                    }
                }
            }
        }
        val imagePaths = items.map { item ->
            val product = item.productId?.let { productMap[it] }
            listOfNotNull(
                item.productImagePath.takeIf { it.isNotBlank() },
                product?.primaryImage?.filePath?.takeIf { it.isNotBlank() },
                product?.primaryImage?.originalFilePath?.takeIf { it.isNotBlank() },
                product?.primaryImage?.thumbnailPath?.takeIf { it.isNotBlank() },
            ).firstOrNull { File(it).exists() }.orEmpty()
        }

        val sheetNumber = InventoryColumnDefaults.sheetNumberForSession(sessionDetails.session.id)
        val distinctProducts = items.map { it.productId ?: it.scannedBarcode }.distinct().size
        val totalQty = items.sumOf { it.countedQty }
        val qtySpec = NumberFormatEngine.resolveInventoryColumnSpec(inventoryConfig.columns, "quantity")
        val metaHeaders = listOf("البيان", "القيمة")
        val metaRows = listOf(
            listOf("رقم الكشف", sheetNumber),
            listOf("عنوان الكشف", sessionDetails.session.title),
            listOf("التاريخ", dateFmt.format(Date(sessionDetails.session.sessionDate))),
            listOf("عدد المنتجات المختلفة", distinctProducts.toString()),
            listOf("عدد البنود", items.size.toString()),
            listOf("مجموع الكميات", NumberFormatEngine.formatDouble(totalQty, qtySpec)),
            listOf("ملاحظات الكشف", sessionDetails.session.notes),
        )

        val landscape = inventoryConfig.orientation == PageOrientation.LANDSCAPE
        val outFile = File(mediaStorage.exportsDir, ensureExt(fileName, "xlsx"))
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تصدير كشف الجرد Excel ($sheetNumber)",
            initialStage = "كتابة ${rows.size} بند جرد",
        )
        try {
            writeMultiSheetXlsxWorkbook(
                outFile = outFile,
                sheets = listOf(
                    XlsxSheetSpec(
                        name = sanitizeSheetName("كشف الجرد"),
                        headers = headers,
                        rows = rows,
                        colWidths = colWidths,
                        numericColumnIndices = numericCols,
                        columnNumberFormats = numericFormats,
                        imageColumnIndex = imageColIdx,
                        imagePathsPerRow = imagePaths,
                        landscape = landscape,
                    ),
                    XlsxSheetSpec(
                        name = sanitizeSheetName("بيانات الكشف"),
                        headers = metaHeaders,
                        rows = metaRows,
                        colWidths = listOf(24, 38),
                        numericColumnIndices = emptySet(),
                        landscape = landscape,
                    ),
                ),
            )
            trace?.succeed("تم تصدير ${outFile.name}")
            return outFile
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "تصدير كشف الجرد Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر تصدير كشف الجرد Excel", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    fun exportReportToXlsx(
        reportDetails: ReportWithDetails,
        fileName: String,
        sheetName: String = "التقرير",
    ): File {
        val visibleCols = reportDetails.sortedColumns.map { it.toDomainModel() }.filter { it.visible }
        val headers = visibleCols.map { it.title }
        val colWidths = visibleCols.map { col ->
            when (col.columnType) {
                ColumnType.SERIAL -> 8
                ColumnType.TEXT, ColumnType.NOTES -> 28
                ColumnType.BARCODE, ColumnType.QR_CODE -> 22
                ColumnType.IMAGE -> 16
                else -> 15
            }
        }
        val numericCols = visibleCols.mapIndexedNotNull { idx, col ->
            if (col.columnType in setOf(ColumnType.PRICE, ColumnType.CURRENCY, ColumnType.QUANTITY, ColumnType.NUMBER, ColumnType.PERCENTAGE, ColumnType.SERIAL)) idx else null
        }.toSet()
        val numericFormats = visibleCols.mapIndexedNotNull { idx, col ->
            when {
                col.columnType == ColumnType.SERIAL -> idx to NumberFormatSpec(
                    decimalPlaces = 0,
                    autoDecimals = false,
                    stripTrailingZeros = false,
                    useGrouping = false,
                )
                idx in numericCols -> idx to col.toNumberFormatSpec()
                else -> null
            }
        }.toMap()
        val imageColIdx = visibleCols.indexOfFirst { it.columnType == ColumnType.IMAGE }.takeIf { it >= 0 }
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        val rows = reportDetails.sortedItems.mapIndexed { rowIdx, row ->
            val item = row.item
            visibleCols.map { col ->
                when (col.columnType) {
                    ColumnType.SERIAL -> (rowIdx + 1).toString()
                    ColumnType.IMAGE -> ""
                    ColumnType.BARCODE, ColumnType.QR_CODE -> item.primaryBarcodeSnapshot
                    ColumnType.PRICE -> item.unitPrice.toString()
                    ColumnType.CURRENCY -> {
                        if (col.columnKey == "price") item.unitPrice.toString() else item.lineTotal.toString()
                    }
                    ColumnType.QUANTITY -> item.quantity.toString()
                    ColumnType.NUMBER -> {
                        when (col.columnKey) {
                            "subtotal" -> (item.unitPrice * item.quantity).toString()
                            "discount_amount" -> (item.unitPrice * item.quantity - item.lineTotal).coerceAtLeast(0.0).toString()
                            else -> (col.customFieldKey.toDoubleOrNull() ?: item.quantity).toString()
                        }
                    }
                    ColumnType.PERCENTAGE -> item.discountPercent.toString()
                    ColumnType.DATE -> dateFormat.format(Date(reportDetails.report.reportDate))
                    ColumnType.NOTES -> item.notes
                    else -> when (col.columnKey) {
                        "name" -> item.productNameSnapshot
                        "barcode_text" -> item.primaryBarcodeSnapshot
                        "barcode_type" -> item.primaryBarcodeTypeSnapshot
                        "category" -> item.categorySnapshot
                        "origin" -> item.originCountrySnapshot
                        "manufacturer" -> item.manufacturerSnapshot
                        "internal_code" -> item.sourceProductId?.toString().orEmpty()
                        else -> item.productNameSnapshot
                    }
                }
            }
        }
        val imagePaths = reportDetails.sortedItems.map { row ->
            row.item.imageSnapshotPath.takeIf { it.isNotBlank() && File(it).exists() }
                ?: row.images.sortedBy { it.sortOrder }.firstNotNullOfOrNull { im ->
                    im.filePath.takeIf { p -> p.isNotBlank() && File(p).exists() }
                }.orEmpty()
        }
        val landscape = PageOrientation.fromString(reportDetails.report.orientation) == PageOrientation.LANDSCAPE

        val outFile = File(mediaStorage.exportsDir, ensureExt(fileName, "xlsx"))
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تصدير التقرير إلى Excel (${reportDetails.report.reportNumber})",
            initialStage = "كتابة ${rows.size} صف في المصنف",
        )
        try {
            writeXlsxWorkbook(
                outFile = outFile,
                sheetName = sanitizeSheetName(sheetName),
                headers = headers,
                rows = rows,
                colWidths = colWidths,
                numericColumnIndices = numericCols,
                columnNumberFormats = numericFormats,
                imageColumnIndex = imageColIdx,
                imagePathsPerRow = imagePaths,
                landscape = landscape,
            )
            trace?.succeed("تم تصدير ${outFile.name}")
            return outFile
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.REPORT_EDITOR,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "تصدير التقرير إلى Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر تصدير التقرير إلى Excel", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    fun exportProductsToCsv(
        products: List<ProductWithDetails>,
        fileName: String,
        productsNumericConfig: ProductsNumericConfig = ProductsNumericConfig(),
    ): File {
        val outFile = File(mediaStorage.exportsDir, ensureExt(fileName, "csv"))
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تصدير المنتجات إلى CSV",
            initialStage = "كتابة ${products.size} منتج بصيغة UTF-8",
        )
        try {
            outFile.outputStream().use { fos ->
                // UTF-8 BOM for Arabic Excel compatibility
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                val writer = fos.bufferedWriter(Charsets.UTF_8)
                writer.appendLine("ID,اسم المنتج,الباركود الرئيسي,باركودات إضافية,الوحدات ومعاملات التحويل,التصنيف,السعر الأساسي,العملة,بلد المنشأ,المصنع,الكمية الافتراضية,الوصف,ملاحظات")
                for (p in products) {
                    val primaryCode = p.primaryBarcode?.barcodeValue.orEmpty()
                    val extraCodes = p.barcodes.filter { it.barcodeValue != primaryCode }.joinToString(" | ") { it.barcodeValue }
                    val unitsInfo = p.barcodes.joinToString(" | ") { b ->
                        val convStr = NumberFormatEngine.formatDouble(
                            b.conversionFactor,
                            productsNumericConfig.conversionFactorFormat,
                        )
                        "${b.barcodeValue}:${b.unitType}x$convStr"
                    }
                    val line = listOf(
                        p.product.internalCode,
                        p.product.name,
                        primaryCode,
                        extraCodes,
                        unitsInfo,
                        p.product.categoryName,
                        NumberFormatEngine.formatDouble(
                            p.product.basePrice,
                            productsNumericConfig.priceFormat.copy(useGrouping = false),
                        ),
                        p.product.currency,
                        p.product.originCountry,
                        p.product.manufacturer,
                        NumberFormatEngine.formatDouble(
                            p.product.defaultQuantity,
                            productsNumericConfig.quantityFormat.copy(useGrouping = false),
                        ),
                        p.product.description,
                        p.product.notes,
                    ).joinToString(",") { csvEscape(it) }
                    writer.appendLine(line)
                }
                writer.flush()
            }
            trace?.succeed("تم تصدير ${outFile.name}")
            return outFile
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.PRODUCTS,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "تصدير المنتجات إلى CSV",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر تصدير CSV", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    fun exportImageImportErrorsToXlsx(
        downloads: List<ProductImageDownloadEntity>,
        importIssues: List<ImportValidationIssue> = emptyList(),
        fileName: String = "image_import_errors_${System.currentTimeMillis() / 1000}",
    ): File {
        val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val headers = listOf(
            "رقم الصف",
            "رقم المنتج (ProductID)",
            "الباركود",
            "اسم المنتج",
            "رابط الصورة",
            "حالة التنزيل",
            "فئة التشخيص",
            "رمز HTTP",
            "سبب الخطأ",
            "الرابط النهائي",
            "عدد المحاولات",
            "سجل التشخيص",
            "تاريخ التحديث",
        )
        val failedOrIssueRows = downloads
            .filter { it.status == ImageDownloadStatus.FAILED.name || it.failureReason.isNotBlank() }
            .ifEmpty { downloads }
            .map { dl ->
                val statusLabel = ImageDownloadStatus.entries.firstOrNull { it.name == dl.status }?.arabicLabel ?: dl.status
                listOf(
                    if (dl.excelRowNumber > 0) dl.excelRowNumber.toString() else "—",
                    dl.productId.toString(),
                    dl.barcode,
                    dl.productName,
                    dl.sourceUrl,
                    statusLabel,
                    dl.failureCategory.ifBlank { "—" },
                    if (dl.httpStatusCode > 0) dl.httpStatusCode.toString() else "—",
                    dl.failureReason.ifBlank { "—" },
                    dl.finalUrl.ifBlank { "—" },
                    dl.attemptCount.toString(),
                    dl.diagnosticLog.ifBlank { "—" },
                    if (dl.updatedAt > 0L) timeFmt.format(Date(dl.updatedAt)) else "—",
                )
            }

        val validationRows = importIssues.map { issue ->
            listOf(
                if (issue.rowNumber > 0) issue.rowNumber.toString() else "—",
                "—",
                "—",
                "تحقق الصف",
                "—",
                if (issue.isWarning) "تحذير" else "خطأ صف",
                "تحقق البيانات",
                "—",
                issue.message,
                "—",
                "—",
                "—",
                timeFmt.format(Date()),
            )
        }

        val allRows = (failedOrIssueRows + validationRows).ifEmpty {
            listOf(listOf("—", "—", "—", "لا توجد أخطاء", "—", "سليم", "—", "—", "—", "—", "0", "—", timeFmt.format(Date())))
        }

        val outFile = File(mediaStorage.exportsDir, ensureExt(fileName, "xlsx"))
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.EXCEL_IMPORT,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تصدير أخطاء استيراد الصور إلى Excel",
            initialStage = "كتابة ${allRows.size} سجل",
        )
        try {
            writeXlsxWorkbook(
                outFile = outFile,
                sheetName = sanitizeSheetName("أخطاء استيراد الصور"),
                headers = headers,
                rows = allRows,
                colWidths = listOf(10, 18, 18, 26, 40, 16, 26, 12, 42, 36, 12, 36, 18),
                numericColumnIndices = setOf(0, 1, 7, 10),
                columnNumberFormats = mapOf(
                    0 to NumberFormatSpec(decimalPlaces = 0, useGrouping = false),
                    1 to NumberFormatSpec(decimalPlaces = 0, useGrouping = false),
                    7 to NumberFormatSpec(decimalPlaces = 0, useGrouping = false),
                    10 to NumberFormatSpec(decimalPlaces = 0, useGrouping = false),
                ),
                imageColumnIndex = null,
                imagePathsPerRow = emptyList(),
                landscape = true,
            )
            trace?.succeed("تم تصدير ${outFile.name}")
            return outFile
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.EXCEL_IMPORT,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "تصدير أخطاء استيراد الصور إلى Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر التصدير إلى Excel", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    private fun csvEscape(value: String): String {
        val needsQuotes = value.contains(',') || value.contains('"') || value.contains('\n') || value.contains('\r')
        val escaped = value.replace("\"", "\"\"")
        return if (needsQuotes) "\"$escaped\"" else escaped
    }

    private data class XlsxSheetSpec(
        val name: String,
        val headers: List<String>,
        val rows: List<List<String>>,
        val colWidths: List<Int>,
        val numericColumnIndices: Set<Int>,
        val columnNumberFormats: Map<Int, NumberFormatSpec> = emptyMap(),
        val imageColumnIndex: Int? = null,
        val imagePathsPerRow: List<String?> = emptyList(),
        val landscape: Boolean = true,
    )

    private fun writeXlsxWorkbook(
        outFile: File,
        sheetName: String,
        headers: List<String>,
        rows: List<List<String>>,
        colWidths: List<Int>,
        numericColumnIndices: Set<Int>,
        columnNumberFormats: Map<Int, NumberFormatSpec> = emptyMap(),
        imageColumnIndex: Int?,
        imagePathsPerRow: List<String?>,
        landscape: Boolean,
    ) {
        writeMultiSheetXlsxWorkbook(
            outFile = outFile,
            sheets = listOf(
                XlsxSheetSpec(
                    name = sheetName,
                    headers = headers,
                    rows = rows,
                    colWidths = colWidths,
                    numericColumnIndices = numericColumnIndices,
                    columnNumberFormats = columnNumberFormats,
                    imageColumnIndex = imageColumnIndex,
                    imagePathsPerRow = imagePathsPerRow,
                    landscape = landscape,
                ),
            ),
        )
    }

    private fun writeMultiSheetXlsxWorkbook(
        outFile: File,
        sheets: List<XlsxSheetSpec>,
    ) {
        data class EmbeddedPic(val rowOneBased: Int, val colZeroBased: Int, val mediaName: String, val pngBytes: ByteArray)

        val firstSheet = sheets.first()
        val embeddedPics = mutableListOf<EmbeddedPic>()
        if (firstSheet.imageColumnIndex != null) {
            firstSheet.rows.indices.forEach { rowIdx ->
                val path = firstSheet.imagePathsPerRow.getOrNull(rowIdx).orEmpty()
                if (path.isNotBlank() && File(path).exists()) {
                    val thumbBytes = createCompressedPngThumbnail(path, 120)
                    if (thumbBytes != null) {
                        embeddedPics.add(
                            EmbeddedPic(
                                rowOneBased = rowIdx + 1,
                                colZeroBased = firstSheet.imageColumnIndex,
                                mediaName = "image${embeddedPics.size + 1}.png",
                                pngBytes = thumbBytes,
                            ),
                        )
                    }
                }
            }
        }
        val hasDrawings = embeddedPics.isNotEmpty()

        // Collect all distinct Excel format codes used across sheets (s="3"+ -> numFmtId 165+)
        val defaultNumFormatCode = NumberFormatEngine.excelNumFmtCode(NumberFormatSpec(decimalPlaces = 0, autoDecimals = true))
        val formatCodeOrder = linkedMapOf<String, Int>()
        formatCodeOrder[defaultNumFormatCode] = 0 // s="3"
        sheets.forEach { sheet ->
            sheet.numericColumnIndices.forEach { cIdx ->
                val spec = sheet.columnNumberFormats[cIdx]
                val code = if (spec != null) NumberFormatEngine.excelNumFmtCode(spec) else defaultNumFormatCode
                if (code !in formatCodeOrder) {
                    formatCodeOrder[code] = formatCodeOrder.size
                }
            }
        }

        FileOutputStream(outFile).use { fos ->
            ZipOutputStream(fos).use { zos ->
                // 1. [Content_Types].xml
                writeZipEntry(
                    zos,
                    "[Content_Types].xml",
                    buildString {
                        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                        append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
                        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-officedocument.relationships+xml"/>""")
                        append("""<Default Extension="xml" ContentType="application/xml"/>""")
                        if (hasDrawings) append("""<Default Extension="png" ContentType="image/png"/>""")
                        append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
                        sheets.indices.forEach { sIdx ->
                            append("""<Override PartName="/xl/worksheets/sheet${sIdx + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
                        }
                        append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
                        if (hasDrawings) {
                            append("""<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>""")
                        }
                        append("</Types>")
                    },
                )

                // 2. _rels/.rels
                writeZipEntry(
                    zos,
                    "_rels/.rels",
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""",
                )

                // 3. xl/workbook.xml
                val workbookXml = buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
                    append("<sheets>")
                    sheets.forEachIndexed { sIdx, spec ->
                        append("""<sheet name="${xmlEscape(spec.name)}" sheetId="${sIdx + 1}" r:id="rId${sIdx + 1}"/>""")
                    }
                    append("</sheets></workbook>")
                }
                writeZipEntry(zos, "xl/workbook.xml", workbookXml)

                // 4. xl/_rels/workbook.xml.rels
                val workbookRels = buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                    sheets.indices.forEach { sIdx ->
                        append("""<Relationship Id="rId${sIdx + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${sIdx + 1}.xml"/>""")
                    }
                    append("""<Relationship Id="rId${sheets.size + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
                    append("</Relationships>")
                }
                writeZipEntry(zos, "xl/_rels/workbook.xml.rels", workbookRels)

                // 5. xl/styles.xml (Header navy fill, explicit '@' format for barcodes, dynamic per-column decimal formats)
                val stylesXml = buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                    append("""<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
                    append("""<numFmts count="${1 + formatCodeOrder.size}">""")
                    append("""<numFmt numFmtId="164" formatCode="@"/>""")
                    formatCodeOrder.forEach { (code, orderIdx) ->
                        val numFmtId = 165 + orderIdx
                        append("""<numFmt numFmtId="$numFmtId" formatCode="${xmlEscape(code)}"/>""")
                    }
                    append("</numFmts>")
                    append("""<fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts>""")
                    append("""<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F172A"/></patternFill></fill></fills>""")
                    append("""<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFCBD5E1"/></left><right style="thin"><color rgb="FFCBD5E1"/></right><top style="thin"><color rgb="FFCBD5E1"/></top><bottom style="thin"><color rgb="FFCBD5E1"/></bottom></border></borders>""")
                    append("""<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>""")
                    append("""<cellXfs count="${3 + formatCodeOrder.size}">""")
                    // 0: default text
                    append("""<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>""")
                    // 1: header
                    append("""<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>""")
                    // 2: '@' explicit text
                    append("""<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>""")
                    // 3+: numeric formats
                    formatCodeOrder.forEach { (_, orderIdx) ->
                        val numFmtId = 165 + orderIdx
                        append("""<xf numFmtId="$numFmtId" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>""")
                    }
                    append("</cellXfs>")
                    append("</styleSheet>")
                }
                writeZipEntry(zos, "xl/styles.xml", stylesXml)

                // 6. xl/worksheets/sheet{n}.xml (RTL view + exact <v> numeric values + dynamic per-column styles + '@' barcodes)
                sheets.forEachIndexed { sIdx, spec ->
                    val sheetHasDrawings = (sIdx == 0) && hasDrawings
                    val sheetXml = buildString {
                        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                        append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
                        append("""<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>""")
                        append("<cols>")
                        spec.colWidths.forEachIndexed { idx, w ->
                            append("""<col min="${idx + 1}" max="${idx + 1}" width="$w" customWidth="1"/>""")
                        }
                        append("</cols>")
                        append("<sheetData>")

                        // Header row (Row 1)
                        append("""<row r="1" ht="28" customHeight="1">""")
                        spec.headers.forEachIndexed { cIdx, h ->
                            val ref = "${colLetter(cIdx)}1"
                            append("""<c r="$ref" s="1" t="inlineStr"><is><t>${xmlEscape(h)}</t></is></c>""")
                        }
                        append("</row>")

                        // Data rows
                        val rowHeight = if (sheetHasDrawings) 56 else 22
                        spec.rows.forEachIndexed { rIdx, rowVals ->
                            val excelRow = rIdx + 2
                            append("""<row r="$excelRow" ht="$rowHeight" customHeight="1">""")
                            rowVals.forEachIndexed { cIdx, rawVal ->
                                val ref = "${colLetter(cIdx)}$excelRow"
                                val numVal = if (cIdx in spec.numericColumnIndices) rawVal.toDoubleOrNull() else null
                                if (numVal != null) {
                                    val colSpec = spec.columnNumberFormats[cIdx]
                                    val fmtCode = if (colSpec != null) NumberFormatEngine.excelNumFmtCode(colSpec) else defaultNumFormatCode
                                    val styleIdx = 3 + (formatCodeOrder[fmtCode] ?: 0)
                                    val exactNumStr = NumberFormatEngine.formatEditableNumber(numVal)
                                    append("""<c r="$ref" s="$styleIdx"><v>$exactNumStr</v></c>""")
                                } else {
                                    // Style 2 = '@' explicit text cell so Excel preserves leading zeros on barcodes
                                    append("""<c r="$ref" s="2" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(rawVal)}</t></is></c>""")
                                }
                            }
                            append("</row>")
                        }
                        append("</sheetData>")
                        append("""<pageSetup orientation="${if (spec.landscape) "landscape" else "portrait"}" paperSize="9"/>""")
                        if (sheetHasDrawings) {
                            append("""<drawing r:id="rId1"/>""")
                        }
                        append("</worksheet>")
                    }
                    writeZipEntry(zos, "xl/worksheets/sheet${sIdx + 1}.xml", sheetXml)
                }

                if (hasDrawings) {
                    writeZipEntry(
                        zos,
                        "xl/worksheets/_rels/sheet1.xml.rels",
                        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>
</Relationships>""",
                    )

                    val drawingRels = buildString {
                        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                        embeddedPics.forEachIndexed { idx, pic ->
                            append("""<Relationship Id="rId${idx + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${pic.mediaName}"/>""")
                        }
                        append("</Relationships>")
                    }
                    writeZipEntry(zos, "xl/drawings/_rels/drawing1.xml.rels", drawingRels)

                    val drawingXml = buildString {
                        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                        append("""<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
                        embeddedPics.forEachIndexed { idx, pic ->
                            append("""<xdr:twoCellAnchor editAs="oneCell">""")
                            append("""<xdr:from><xdr:col>${pic.colZeroBased}</xdr:col><xdr:colOff>30000</xdr:colOff><xdr:row>${pic.rowOneBased}</xdr:row><xdr:rowOff>30000</xdr:rowOff></xdr:from>""")
                            append("""<xdr:to><xdr:col>${pic.colZeroBased + 1}</xdr:col><xdr:colOff>-30000</xdr:colOff><xdr:row>${pic.rowOneBased + 1}</xdr:row><xdr:rowOff>-30000</xdr:rowOff></xdr:to>""")
                            append("""<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="${idx + 2}" name="Picture ${idx + 1}"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId${idx + 1}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/>""")
                            append("</xdr:twoCellAnchor>")
                        }
                        append("</xdr:wsDr>")
                    }
                    writeZipEntry(zos, "xl/drawings/drawing1.xml", drawingXml)

                    embeddedPics.forEach { pic ->
                        zos.putNextEntry(ZipEntry("xl/media/${pic.mediaName}"))
                        zos.write(pic.pngBytes)
                        zos.closeEntry()
                    }
                }
            }
        }
    }

    private fun createCompressedPngThumbnail(path: String, maxSize: Int): ByteArray? {
        return try {
            val bmp = mediaStorage.decodeSampledBitmap(path, maxSize) ?: return null
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            bmp.recycle()
            out.toByteArray()
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "تضمين صورة في ملف Excel")
            null
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, entryName: String, content: String) {
        zos.putNextEntry(ZipEntry(entryName))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun colLetter(indexZeroBased: Int): String {
        var idx = indexZeroBased
        val sb = StringBuilder()
        while (idx >= 0) {
            sb.insert(0, ('A' + (idx % 26)))
            idx = (idx / 26) - 1
        }
        return sb.toString()
    }

    private fun sanitizeSheetName(name: String): String =
        name.replace(Regex("[\\\\/?*\\[\\]:]"), "_").take(31).ifBlank { "Sheet1" }

    private fun ensureExt(fileName: String, ext: String): String {
        val clean = fileName.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "export" }
        return if (clean.lowercase(Locale.ROOT).endsWith(".$ext")) clean else "$clean.$ext"
    }

    private fun xmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
