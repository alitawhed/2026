package com.example.domain.layout

import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnLayoutResult
import com.example.domain.model.ColumnType
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.ComputedColumnWidth
import com.example.domain.model.OverflowSuggestion
import com.example.domain.model.OverflowSuggestionType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PageSpec
import com.example.domain.model.PaperSizeType
import kotlin.math.round

/**
 * Single shared layout engine used identically by:
 * 1. Report Editor Table
 * 2. Visual Column Designer Live Preview
 * 3. Final PDF Generator
 */
object ColumnLayoutEngine {

    fun smartWeight(column: ColumnConfigModel): Float {
        val presetMultiplier = when (column.presetWidth) {
            ColumnWidthPreset.NARROW -> 0.72f
            ColumnWidthPreset.MEDIUM -> 1.0f
            ColumnWidthPreset.WIDE -> 1.42f
            ColumnWidthPreset.CUSTOM -> (column.manualWidthPt / 78f).coerceIn(0.45f, 3.0f)
        }
        val baseWeight = when (column.columnType) {
            ColumnType.SERIAL -> 0.48f
            ColumnType.TEXT -> when (column.columnKey) {
                "name" -> 2.35f
                "internal_code" -> 1.05f
                "unit", "barcode_type" -> 0.90f
                "barcode_text" -> 1.45f
                else -> 1.25f
            }
            ColumnType.NOTES -> 1.65f
            ColumnType.BARCODE -> 1.75f
            ColumnType.QR_CODE -> 1.05f
            ColumnType.IMAGE -> 1.05f
            ColumnType.MULTI_IMAGE -> 1.85f
            ColumnType.PRICE, ColumnType.CURRENCY -> 0.95f
            ColumnType.QUANTITY, ColumnType.PERCENTAGE, ColumnType.NUMBER -> 0.82f
            ColumnType.DATE -> 0.95f
            ColumnType.LINK, ColumnType.DROPDOWN, ColumnType.CUSTOM_FIELD -> 1.15f
        }
        return (baseWeight * presetMultiplier).coerceAtLeast(0.35f)
    }

    fun effectiveMinWidth(column: ColumnConfigModel): Float {
        val intrinsicMin = when (column.columnType) {
            ColumnType.SERIAL -> 24f
            ColumnType.BARCODE -> 76f // Ensures barcodes remain scannable with quiet zone
            ColumnType.QR_CODE -> 44f
            ColumnType.IMAGE -> 38f
            ColumnType.MULTI_IMAGE -> 76f
            ColumnType.TEXT -> when (column.columnKey) {
                "name" -> 78f
                "unit", "internal_code", "barcode_type" -> 38f
                else -> 48f
            }
            ColumnType.NOTES -> 52f
            ColumnType.PRICE, ColumnType.CURRENCY -> 46f
            ColumnType.QUANTITY, ColumnType.PERCENTAGE, ColumnType.NUMBER -> 36f
            else -> 42f
        }
        return maxOf(column.minWidthPt, intrinsicMin)
    }

    fun calculateLayout(
        pageSpec: PageSpec,
        allColumns: List<ColumnConfigModel>,
        distributionMode: ColumnDistributionMode,
        splitHorizontalGroups: Boolean = false,
    ): ColumnLayoutResult {
        val visibleColumns = allColumns
            .filter { it.visible }
            .sortedBy { it.sortOrder }

        val usableWidth = pageSpec.usableWidthPt
        if (visibleColumns.isEmpty()) {
            return ColumnLayoutResult(
                usableWidthPt = usableWidth,
                totalAllocatedWidthPt = 0f,
                computedColumns = emptyList(),
                hasOverflow = false,
                overflowAmountPt = 0f,
                suggestions = emptyList(),
                columnGroups = emptyList(),
            )
        }

        val minWidths = visibleColumns.map { effectiveMinWidth(it) }
        val sumMinWidths = minWidths.sum()
        val hasOverflow = sumMinWidths > usableWidth + 0.5f
        val overflowAmount = (sumMinWidths - usableWidth).coerceAtLeast(0f)

        val suggestions = if (hasOverflow) {
            buildOverflowSuggestions(pageSpec, overflowAmount)
        } else {
            emptyList()
        }

        if (hasOverflow && splitHorizontalGroups) {
            // User explicitly approved splitting into horizontal column groups across pages
            val groups = buildHorizontalGroups(visibleColumns, usableWidth, distributionMode)
            val flattened = groups.flatten()
            return ColumnLayoutResult(
                usableWidthPt = usableWidth,
                totalAllocatedWidthPt = flattened.sumOf { it.widthPt.toDouble() }.toFloat(),
                computedColumns = flattened,
                hasOverflow = true,
                overflowAmountPt = overflowAmount,
                suggestions = suggestions,
                columnGroups = groups,
            )
        }

        val rawWidths: MutableList<Float> = when (distributionMode) {
            ColumnDistributionMode.EQUAL -> {
                val perCol = usableWidth / visibleColumns.size.toFloat()
                MutableList(visibleColumns.size) { idx ->
                    if (hasOverflow) minWidths[idx] else perCol.coerceIn(minWidths[idx], visibleColumns[idx].maxWidthPt.coerceAtLeast(minWidths[idx]))
                }
            }
            ColumnDistributionMode.MANUAL -> {
                val manual = visibleColumns.mapIndexed { idx, col ->
                    col.manualWidthPt.coerceAtLeast(minWidths[idx])
                }
                val manualSum = manual.sum()
                if (!hasOverflow && manualSum > 0f) {
                    val scale = usableWidth / manualSum
                    manual.mapIndexed { idx, w ->
                        (w * scale).coerceAtLeast(minWidths[idx])
                    }.toMutableList()
                } else {
                    manual.toMutableList()
                }
            }
            ColumnDistributionMode.AUTO_FIT -> {
                distributeAutoFit(visibleColumns, minWidths, usableWidth)
            }
        }

        // Reconcile rounding or clamping delta so visible columns fill 100% of usableWidth when no overflow
        if (!hasOverflow) {
            reconcileTotalWidth(rawWidths, visibleColumns, minWidths, usableWidth)
        }

        val computed = visibleColumns.mapIndexed { idx, col ->
            ComputedColumnWidth(
                column = col,
                widthPt = (round(rawWidths[idx] * 100f) / 100f),
                horizontalGroupIndex = 0,
            )
        }

        return ColumnLayoutResult(
            usableWidthPt = usableWidth,
            totalAllocatedWidthPt = computed.sumOf { it.widthPt.toDouble() }.toFloat(),
            computedColumns = computed,
            hasOverflow = hasOverflow,
            overflowAmountPt = overflowAmount,
            suggestions = suggestions,
            columnGroups = listOf(computed),
        )
    }

    private fun distributeAutoFit(
        columns: List<ColumnConfigModel>,
        minWidths: List<Float>,
        usableWidth: Float,
    ): MutableList<Float> {
        val count = columns.size
        val result = MutableList(count) { idx -> minWidths[idx] }
        val minSum = minWidths.sum()
        if (minSum >= usableWidth) return result

        var remaining = usableWidth - minSum
        val maxWidths = columns.mapIndexed { idx, col ->
            col.maxWidthPt.coerceAtLeast(minWidths[idx] + 20f)
        }
        val weights = columns.map { smartWeight(it) }.toMutableList()
        val locked = BooleanArray(count) { false }

        // Water-filling weighted distribution respecting maxWidthPt
        var iterations = 0
        while (remaining > 0.25f && iterations < 8) {
            iterations++
            val activeWeightSum = weights.indices.sumOf { if (!locked[it]) weights[it].toDouble() else 0.0 }.toFloat()
            if (activeWeightSum <= 0f) break

            var redistributed = 0f
            for (i in 0 until count) {
                if (locked[i]) continue
                val share = remaining * (weights[i] / activeWeightSum)
                val capacity = maxWidths[i] - result[i]
                if (share >= capacity) {
                    result[i] += capacity
                    redistributed += capacity
                    locked[i] = true
                } else {
                    result[i] += share
                    redistributed += share
                }
            }
            remaining -= redistributed
            if (redistributed < 0.1f) break
        }

        // If all columns hit maxWidthPt and extra space remains, expand flexible text/notes columns proportionally
        if (remaining > 0.5f) {
            val flexIndices = columns.indices.filter {
                columns[it].columnType == ColumnType.TEXT ||
                    columns[it].columnType == ColumnType.NOTES ||
                    columns[it].columnType == ColumnType.CUSTOM_FIELD
            }.ifEmpty { columns.indices.toList() }
            val extraEach = remaining / flexIndices.size.toFloat()
            flexIndices.forEach { result[it] += extraEach }
        }
        return result
    }

    private fun reconcileTotalWidth(
        widths: MutableList<Float>,
        columns: List<ColumnConfigModel>,
        minWidths: List<Float>,
        usableWidth: Float,
    ) {
        val currentSum = widths.sum()
        val delta = usableWidth - currentSum
        if (kotlin.math.abs(delta) < 0.01f) return

        // Prefer absorbing residual in the widest flexible column (name / notes / widest)
        val targetIdx = columns.indices
            .filter { columns[it].columnType == ColumnType.TEXT || columns[it].columnType == ColumnType.NOTES }
            .maxByOrNull { widths[it] }
            ?: widths.indices.maxByOrNull { widths[it] }
            ?: 0

        val candidate = widths[targetIdx] + delta
        if (candidate >= minWidths[targetIdx]) {
            widths[targetIdx] = candidate
        } else {
            // Distribute deficit across columns that have room above minWidth
            var need = -delta
            for (i in widths.indices) {
                val room = widths[i] - minWidths[i]
                if (room > 0f) {
                    val take = minOf(room, need)
                    widths[i] -= take
                    need -= take
                    if (need <= 0.01f) break
                }
            }
        }
    }

    private fun buildHorizontalGroups(
        visibleColumns: List<ColumnConfigModel>,
        usableWidth: Float,
        distributionMode: ColumnDistributionMode,
    ): List<List<ComputedColumnWidth>> {
        val groups = mutableListOf<MutableList<ColumnConfigModel>>()
        var currentGroup = mutableListOf<ColumnConfigModel>()
        var currentMinSum = 0f

        for (col in visibleColumns) {
            val minW = effectiveMinWidth(col)
            if (currentGroup.isNotEmpty() && currentMinSum + minW > usableWidth) {
                groups.add(currentGroup)
                currentGroup = mutableListOf()
                currentMinSum = 0f
            }
            currentGroup.add(col)
            currentMinSum += minW
        }
        if (currentGroup.isNotEmpty()) groups.add(currentGroup)

        return groups.mapIndexed { groupIdx, cols ->
            val minWidths = cols.map { effectiveMinWidth(it) }
            val widths = when (distributionMode) {
                ColumnDistributionMode.EQUAL -> MutableList(cols.size) { usableWidth / cols.size }
                else -> distributeAutoFit(cols, minWidths, usableWidth)
            }
            reconcileTotalWidth(widths, cols, minWidths, usableWidth)
            cols.mapIndexed { idx, col ->
                ComputedColumnWidth(col, round(widths[idx] * 100f) / 100f, groupIdx)
            }
        }
    }

    private fun buildOverflowSuggestions(
        pageSpec: PageSpec,
        overflowAmountPt: Float,
    ): List<OverflowSuggestion> {
        val list = mutableListOf<OverflowSuggestion>()
        if (pageSpec.orientation == PageOrientation.PORTRAIT) {
            list.add(
                OverflowSuggestion(
                    OverflowSuggestionType.SWITCH_LANDSCAPE,
                    "تحويل الورقة إلى الوضع الأفقي",
                    "يمنحك عرضاً أوسع للأعمدة المتعددة دون تصغير الخط أو الباركود",
                ),
            )
        }
        if (pageSpec.marginStartMm > 5f || pageSpec.marginEndMm > 5f) {
            list.add(
                OverflowSuggestion(
                    OverflowSuggestionType.REDUCE_MARGINS,
                    "تقليل الهوامش الجانبية إلى 5 مم",
                    "يوفر مساحة أفقية إضافية داخل الصفحة الحالية",
                ),
            )
        }
        if (pageSpec.paperSize != PaperSizeType.A3) {
            list.add(
                OverflowSuggestion(
                    OverflowSuggestionType.LARGER_PAPER_A3,
                    "اختيار حجم ورق أكبر (A3)",
                    "مناسب للجداول التفصيلية التي تحتوي على أعمدة كثيرة",
                ),
            )
        }
        list.add(
            OverflowSuggestion(
                OverflowSuggestionType.SPLIT_HORIZONTAL_GROUPS,
                "توزيع الأعمدة على مجموعات أفقية",
                "طباعة الأعمدة الإضافية في مجموعة متابعة مع الحفاظ على وضوح كل عمود",
            ),
        )
        list.add(
            OverflowSuggestion(
                OverflowSuggestionType.MANUAL_WIDTHS,
                "ضبط عروض الأعمدة يدوياً",
                "تعديل العروض الدنيا أو تفعيل الوضع اليدوي (فائض ${overflowAmountPt.toInt()} نقطة)",
            ),
        )
        return list
    }
}
