package com.example.domain.diagnostics

import android.content.Context
import android.os.Build
import com.example.BuildConfig
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class DiagnosticAppDeviceSummary(
    val appName: String,
    val applicationId: String,
    val appVersionName: String,
    val appVersionCode: Int,
    val databaseSchemaVersion: Int,
    val androidVersionRelease: String,
    val androidSdkInt: Int,
    val deviceManufacturer: String,
    val deviceModel: String,
    val supportedAbis: List<String>,
    val freeInternalStorageMb: Long,
    val diagnosticLogsSizeBytes: Long,
    val exportedAt: Long,
    val exportedAtIso: String,
    val privacyGuarantee: String = "NO_PASSWORDS_NO_TOKENS_NO_API_KEYS_NO_DATABASE_CONTENTS",
)

@Serializable
data class RecurringErrorSummary(
    val fingerprint: String,
    val errorType: String,
    val moduleName: String,
    val screenName: String,
    val operationName: String,
    val totalOccurrences: Int,
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    val severity: LogSeverity,
    val sampleMessage: String,
)

class DiagnosticExportEngine(
    private val context: Context,
    private val errorMonitor: GlobalErrorMonitor,
    private val databaseSchemaVersion: Int = 11,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    val diagnosticExportsDir: File
        get() = File(context.filesDir, "diagnostic_exports").apply { mkdirs() }

    fun formatSingleErrorText(error: ErrorEventRecord): String {
        val dt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(error.timestamp))
        val firstDt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(error.firstSeenAt))
        val lastDt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(error.lastSeenAt))
        return buildString {
            appendLine("=== تقرير تشخيص خطأ — مدير التقارير ===")
            appendLine("معرّف الخطأ (ID): ${error.errorId}")
            appendLine("البصمة (Fingerprint): ${error.fingerprint}")
            appendLine("التاريخ والوقت: $dt")
            appendLine("مستوى الخطورة: ${error.severity.arabicLabel} (${error.severity.name})")
            appendLine("انهيار غير معالج: ${if (!error.wasHandled) "نعم" else "لا (معالج)"}")
            appendLine("الشاشة: ${error.screenName}")
            appendLine("الوحدة: ${error.moduleName}")
            appendLine("العملية: ${error.operationName}")
            if (error.linkedOperationId.isNotBlank()) {
                appendLine("معرّف العملية المرتبطة (operationId): ${error.linkedOperationId}")
            }
            if (error.failedStage.isNotBlank()) {
                appendLine("المرحلة التي فشل عندها: ${error.failedStage}")
            }
            if (error.deviceSummary.isNotBlank()) {
                appendLine("معلومات الجهاز: ${error.deviceSummary}")
            }
            if (error.appVersionSummary.isNotBlank()) {
                appendLine("إصدار التطبيق: ${error.appVersionSummary}")
            }
            appendLine("نوع الخطأ: ${error.errorType}")
            appendLine("الرسالة: ${DiagnosticSanitizer.sanitizeText(error.originalMessage)}")
            appendLine("الملف البرمجي: ${error.sourceFile}:${error.lineNumber}")
            appendLine("الدالة: ${error.functionName}")
            appendLine("عدد مرات التكرار: ${error.occurrenceCount} (أول ظهور: $firstDt | آخر ظهور: $lastDt)")
            appendLine("حالة المراجعة: ${if (error.isReviewed) "تمت المراجعة" else "جديد"}")
            appendLine("ملخص حالة التطبيق: ${DiagnosticSanitizer.sanitizeText(error.appStateSummary)}")
            appendLine("--- تتبع المكدس (Stack Trace) ---")
            appendLine(DiagnosticSanitizer.sanitizeText(error.stackTrace, 12_000))
        }
    }

    fun exportSingleErrorFile(error: ErrorEventRecord): Result<File> {
        val trace = errorMonitor.operationLogger.startOperation(
            screenName = ScreenNames.ERROR_DIAGNOSTICS,
            moduleName = DiagnosticModules.STORAGE,
            operationName = "تصدير تفاصيل خطأ واحد",
            initialStage = "تهيئة نص التقرير",
        )
        return try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outFile = File(diagnosticExportsDir, "error_${error.errorId.take(8)}_$stamp.txt")
            val text = formatSingleErrorText(error)
            trace.stage("كتابة ملف تفاصيل الخطأ", outFile.name)
            outFile.writeText(text, Charsets.UTF_8)
            check(outFile.exists() && outFile.length() > 0L) { "فشل التحقق من وجود ملف الخطأ" }
            trace.succeed("تم حفظ ${outFile.name}")
            Result.success(outFile)
        } catch (t: Throwable) {
            val err = errorMonitor.recordError(
                throwable = t,
                screenName = ScreenNames.ERROR_DIAGNOSTICS,
                moduleName = DiagnosticModules.STORAGE,
                operationName = "تصدير تفاصيل خطأ واحد",
                linkedOperationId = trace.operationId,
            )
            trace.fail(t.message ?: "فشل تصدير تفاصيل الخطأ", err.errorId)
            Result.failure(t)
        }
    }

    /**
     * Generates a dedicated Diagnostic ZIP strictly isolated from business Backup ZIPs,
     * stripped of secrets/tokens/database contents, logs every file creation stage, verifies
     * ZIP readability via ZipInputStream after closing, and marks SUCCESS only after verification.
     */
    fun exportDiagnosticBundleZip(appName: String = "مدير التقارير"): Result<File> {
        val trace = errorMonitor.operationLogger.startOperation(
            screenName = ScreenNames.ERROR_DIAGNOSTICS,
            moduleName = DiagnosticModules.SYSTEM,
            operationName = "تصدير حزمة التشخيص ZIP",
            initialStage = "بدء التصدير وجمع السجلات المعقمة",
        )
        var outZip: File? = null
        return try {
            errorMonitor.refreshStats()
            val errors = errorMonitor.errors.value.map { sanitizeErrorRecord(it) }
            val lastRestore = errorMonitor.lastRestoreDiagnostics.value

            val recurring = errors
                .groupBy { it.fingerprint }
                .values
                .map { group ->
                    val latest = group.maxByOrNull { it.lastSeenAt } ?: group.first()
                    RecurringErrorSummary(
                        fingerprint = latest.fingerprint,
                        errorType = latest.errorType,
                        moduleName = latest.moduleName,
                        screenName = latest.screenName,
                        operationName = latest.operationName,
                        totalOccurrences = group.sumOf { it.occurrenceCount },
                        firstSeenAt = group.minOf { it.firstSeenAt },
                        lastSeenAt = group.maxOf { it.lastSeenAt },
                        severity = latest.severity,
                        sampleMessage = latest.originalMessage,
                    )
                }
                .filter { it.totalOccurrences > 1 }
                .sortedByDescending { it.totalOccurrences }

            val now = System.currentTimeMillis()
            val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date(now))
            val deviceInfo = DiagnosticAppDeviceSummary(
                appName = appName,
                applicationId = BuildConfig.APPLICATION_ID,
                appVersionName = BuildConfig.VERSION_NAME,
                appVersionCode = BuildConfig.VERSION_CODE,
                databaseSchemaVersion = databaseSchemaVersion,
                androidVersionRelease = Build.VERSION.RELEASE ?: "unknown",
                androidSdkInt = Build.VERSION.SDK_INT,
                deviceManufacturer = Build.MANUFACTURER.orEmpty(),
                deviceModel = Build.MODEL.orEmpty(),
                supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty(),
                freeInternalStorageMb = context.filesDir.usableSpace / (1024L * 1024L),
                diagnosticLogsSizeBytes = errorMonitor.fileStore.totalDiagnosticStorageBytes(),
                exportedAt = now,
                exportedAtIso = iso,
            )

            val stackTracesTxt = buildString {
                if (errors.isEmpty()) {
                    appendLine("لا توجد أخطاء مسجلة.")
                } else {
                    errors.forEachIndexed { idx, err ->
                        appendLine("================ [#${idx + 1}] ================")
                        appendLine(formatSingleErrorText(err))
                        appendLine()
                    }
                }
            }

            // Prepare payloads & record each generated file stage clearly BEFORE finalizing operation_logs.json
            val entriesToWrite = linkedMapOf<String, ByteArray>()

            fun stageEntry(entryName: String, content: String) {
                val bytes = content.toByteArray(Charsets.UTF_8)
                check(bytes.isNotEmpty()) { "المحتوى المولد للملف $entryName فارغ" }
                entriesToWrite[entryName] = bytes
                trace.stage("تم إنشاء ملف $entryName", "${bytes.size} بايت")
            }

            stageEntry("device_and_app_info.json", json.encodeToString(deviceInfo))
            stageEntry("error_logs.json", json.encodeToString(errors))
            stageEntry("recurring_errors.json", json.encodeToString(recurring))
            stageEntry("stack_traces.txt", stackTracesTxt)
            if (lastRestore != null) {
                stageEntry("last_restore_diagnostics.json", json.encodeToString(lastRestore))
            }

            errorMonitor.refreshStats()
            val liveStats = errorMonitor.stats.value
            stageEntry("diagnostic_summary.json", json.encodeToString(liveStats))

            // Capture operations snapshot with all prior completed ops + current export stages cleanly finalized
            trace.stage("تجهيز operation_logs.json")
            val operations = errorMonitor.operationLogger.operations.value.map { op ->
                val adjusted = if (op.operationId == trace.operationId) {
                    op.copy(
                        endTime = System.currentTimeMillis(),
                        outcome = OperationOutcome.SUCCESS,
                        severity = LogSeverity.INFO,
                        currentStage = "اكتملت عملية تجهيز وتصدير حزمة التشخيص ZIP",
                        lastSuccessfulStage = "تجهيز operation_logs.json",
                    )
                } else {
                    op
                }
                sanitizeOperationRecord(adjusted)
            }
            val opsBytes = json.encodeToString(operations).toByteArray(Charsets.UTF_8)
            check(opsBytes.isNotEmpty()) { "فشل تجهيز operation_logs.json" }
            entriesToWrite["operation_logs.json"] = opsBytes

            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(now))
            val zipFile = File(diagnosticExportsDir, "diagnostics_report_$stamp.zip")
            outZip = zipFile

            trace.stage("كتابة وضغط ملفات التشخيص داخل ZIP", "${entriesToWrite.size} ملف")
            FileOutputStream(zipFile).use { fos ->
                ZipOutputStream(fos).use { zos ->
                    entriesToWrite.forEach { (name, bytes) ->
                        zos.putNextEntry(ZipEntry(name))
                        zos.write(bytes)
                        zos.closeEntry()
                    }
                }
            }

            // Verify closed ZIP file is non-empty and every entry is readable
            trace.stage("التحقق من سلامة وإمكانية قراءة ملفات حزمة ZIP")
            val verifiedEntries = mutableMapOf<String, Int>()
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                val buf = ByteArray(8192)
                var entry = zis.nextEntry
                while (entry != null) {
                    var total = 0
                    while (true) {
                        val read = zis.read(buf)
                        if (read <= 0) break
                        total += read
                    }
                    verifiedEntries[entry.name] = total
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            val missingInZip = entriesToWrite.keys.filter { key -> (verifiedEntries[key] ?: 0) <= 0 }
            check(missingInZip.isEmpty()) {
                "فشل التحقق من ملفات ZIP المصدرة: ${missingInZip.joinToString()}"
            }

            trace.succeed("تم تصدير والتحقق من ${zipFile.name} (${verifiedEntries.size} ملفات، ${zipFile.length()} بايت)")
            Result.success(zipFile)
        } catch (t: Throwable) {
            outZip?.takeIf { it.exists() && it.length() == 0L }?.delete()
            val recorded = errorMonitor.recordError(
                throwable = t,
                screenName = ScreenNames.ERROR_DIAGNOSTICS,
                moduleName = DiagnosticModules.STORAGE,
                operationName = "تصدير حزمة التشخيص ZIP",
                linkedOperationId = trace.operationId,
            )
            trace.fail(t.message ?: "فشل إنشاء حزمة التشخيص", recorded.errorId)
            Result.failure(t)
        }
    }

    private fun sanitizeErrorRecord(rec: ErrorEventRecord): ErrorEventRecord = rec.copy(
        originalMessage = DiagnosticSanitizer.sanitizeText(rec.originalMessage),
        stackTrace = DiagnosticSanitizer.sanitizeText(rec.stackTrace, 12_000),
        appStateSummary = DiagnosticSanitizer.sanitizeText(rec.appStateSummary, 1000),
        operationName = DiagnosticSanitizer.sanitizeText(rec.operationName, 200),
        failedStage = DiagnosticSanitizer.sanitizeText(rec.failedStage, 180),
    )

    private fun sanitizeOperationRecord(op: OperationLogRecord): OperationLogRecord = op.copy(
        operationName = DiagnosticSanitizer.sanitizeText(op.operationName, 200),
        currentStage = DiagnosticSanitizer.sanitizeText(op.currentStage, 200),
        lastSuccessfulStage = DiagnosticSanitizer.sanitizeText(op.lastSuccessfulStage, 200),
        failureReason = DiagnosticSanitizer.sanitizeText(op.failureReason, 600),
        stages = op.stages.map { st ->
            st.copy(
                stageName = DiagnosticSanitizer.sanitizeText(st.stageName, 200),
                detail = DiagnosticSanitizer.sanitizeText(st.detail, 400),
            )
        },
    )
}
