package com.example.domain.diagnostics

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import java.io.File

data class MemoryPressureEvaluation(
    val trimLevel: Int,
    val shouldLogWarning: Boolean,
    val shouldTrimCaches: Boolean,
    val severity: LogSeverity,
    val categoryLabel: String,
    val availRamMb: Long,
    val totalRamMb: Long,
    val isSystemLowMemory: Boolean,
    val heapUsedMb: Long,
    val heapMaxMb: Long,
) {
    fun toDiagnosticMessage(): String =
        "$categoryLabel (trimLevel=$trimLevel | RAM متاح=${availRamMb}MB/${totalRamMb}MB | Heap=${heapUsedMb}MB/${heapMaxMb}MB | lowMemory=$isSystemLowMemory)"
}

object MemoryPressureAdvisor {

    @Suppress("DEPRECATION")
    fun evaluate(context: Context, trimLevel: Int): MemoryPressureEvaluation {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        if (am != null) {
            am.getMemoryInfo(memInfo)
        }
        val availRamMb = (memInfo.availMem / (1024L * 1024L)).coerceAtLeast(0L)
        val totalRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(0L)
        val rt = Runtime.getRuntime()
        val heapUsedMb = ((rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)).coerceAtLeast(0L)
        val heapMaxMb = (rt.maxMemory() / (1024L * 1024L)).coerceAtLeast(1L)

        // Note: TRIM_MEMORY_UI_HIDDEN (20) simply indicates app UI went to background (app switch / picker),
        // NOT critical RAM exhaustion. Do not generate false LowMemoryWarning entries for normal UI_HIDDEN!
        return when {
            trimLevel == ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = false,
                shouldTrimCaches = true,
                severity = LogSeverity.INFO,
                categoryLabel = "انتقال الواجهة للخلفية (UI_HIDDEN)",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )

            trimLevel == ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = false,
                shouldTrimCaches = true,
                severity = LogSeverity.INFO,
                categoryLabel = "انخفاض طفيف في الذاكرة المتاحة",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )

            trimLevel == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = true,
                shouldTrimCaches = true,
                severity = if (memInfo.lowMemory) LogSeverity.ERROR else LogSeverity.WARNING,
                categoryLabel = "ضغط متوسط على ذاكرة التشغيل (RAM)",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )

            trimLevel == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                trimLevel >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE ||
                memInfo.lowMemory -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = true,
                shouldTrimCaches = true,
                severity = if (memInfo.lowMemory || trimLevel >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
                    LogSeverity.ERROR
                } else {
                    LogSeverity.WARNING
                },
                categoryLabel = "ضغط حقيقي مرتفع على ذاكرة التشغيل (RAM)",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )

            trimLevel >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = trimLevel >= ComponentCallbacks2.TRIM_MEMORY_MODERATE,
                shouldTrimCaches = true,
                severity = LogSeverity.WARNING,
                categoryLabel = "تقليص ذاكرة التطبيق في الخلفية",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )

            else -> MemoryPressureEvaluation(
                trimLevel = trimLevel,
                shouldLogWarning = false,
                shouldTrimCaches = false,
                severity = LogSeverity.INFO,
                categoryLabel = "تنبيه ذاكرة عادي",
                availRamMb = availRamMb,
                totalRamMb = totalRamMb,
                isSystemLowMemory = memInfo.lowMemory,
                heapUsedMb = heapUsedMb,
                heapMaxMb = heapMaxMb,
            )
        }
    }

    /**
     * Releases ONLY safe transient caches (cacheDir temp previews & stale restore staging).
     * Strictly NEVER deletes filesDir user images, exports, backups, or SQLite database files.
     */
    fun releaseDisposableTempCaches(context: Context, aggressive: Boolean): Int {
        var deletedCount = 0
        val cacheRoot = context.cacheDir ?: return 0
        val urlPreviews = File(cacheRoot, "url_previews")
        if (urlPreviews.exists()) {
            urlPreviews.listFiles()?.forEach { f ->
                if (runCatching { f.deleteRecursively() }.getOrDefault(false)) deletedCount++
            }
        }
        if (aggressive) {
            val cutoffMs = System.currentTimeMillis() - 10 * 60 * 1000L
            val stagingDir = File(cacheRoot, "restore_staging")
            if (stagingDir.exists()) {
                stagingDir.listFiles()?.forEach { child ->
                    if (child.lastModified() < cutoffMs) {
                        if (runCatching { child.deleteRecursively() }.getOrDefault(false)) deletedCount++
                    }
                }
            }
            val tempImagesDir = File(cacheRoot, "image_manager_disk_cache")
            if (tempImagesDir.exists()) {
                tempImagesDir.listFiles()?.take(50)?.forEach { f ->
                    if (runCatching { f.deleteRecursively() }.getOrDefault(false)) deletedCount++
                }
            }
        }
        return deletedCount
    }
}
