package com.example.domain.diagnostics

import android.os.Build
import java.security.MessageDigest

data class StackLocationInfo(
    val sourceFile: String,
    val lineNumber: Int,
    val functionName: String,
)

object DiagnosticSanitizer {

    private val bearerRegex = Regex("(?i)(bearer\\s+)[A-Za-z0-9\\-._~+/]+=*")
    private val keyValueSecretRegex = Regex(
        "(?i)(password|passcode|pwd|secret|token|access_token|refresh_token|client_secret|api_key|apikey|authorization|x-api-key|session_id|cookie)\\s*[:=]\\s*[^\\s,;\"'}]+",
    )
    private val urlQuerySecretRegex = Regex(
        "(?i)([?&](?:token|access_token|refresh_token|code|key|apikey|api_key|secret|signature|sig)=)[^&\\s]+",
    )
    private val emailRegex = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")

    fun sanitizeText(raw: String?, maxLength: Int = 4000): String {
        if (raw.isNullOrBlank()) return ""
        var clean = raw
            .replace(bearerRegex, "$1[REDACTED]")
            .replace(keyValueSecretRegex, "$1=[REDACTED]")
            .replace(urlQuerySecretRegex, "$1[REDACTED]")
            .replace(emailRegex, "[EMAIL_REDACTED]")
        if (clean.length > maxLength) {
            clean = clean.take(maxLength) + "\n... [truncated]"
        }
        return clean
    }

    fun formatSanitizedStackTrace(throwable: Throwable, maxLines: Int = 80): String {
        val raw = throwable.stackTraceToString()
        val lines = sanitizeText(raw, maxLength = 12_000).lineSequence().take(maxLines).toList()
        return lines.joinToString("\n")
    }

    fun extractStackLocation(throwable: Throwable, appPackagePrefix: String = "com.example"): StackLocationInfo {
        val allFrames = buildList {
            var cur: Throwable? = throwable
            var depth = 0
            while (cur != null && depth < 5) {
                addAll(cur.stackTrace)
                cur = cur.cause
                depth++
            }
        }
        val preferred = allFrames.firstOrNull { frame ->
            frame.className.startsWith(appPackagePrefix) &&
                !frame.className.contains("GlobalErrorMonitor") &&
                !frame.className.contains("OperationLogger")
        } ?: allFrames.firstOrNull { frame ->
            frame.className.startsWith(appPackagePrefix)
        } ?: allFrames.firstOrNull()

        return if (preferred != null) {
            StackLocationInfo(
                sourceFile = preferred.fileName ?: preferred.className.substringAfterLast('.'),
                lineNumber = preferred.lineNumber.coerceAtLeast(0),
                functionName = "${preferred.className.substringAfterLast('.')}.${preferred.methodName}",
            )
        } else {
            StackLocationInfo(
                sourceFile = "Unknown",
                lineNumber = 0,
                functionName = "Unknown",
            )
        }
    }

    fun computeFingerprint(
        errorType: String,
        moduleName: String,
        location: StackLocationInfo,
    ): String {
        val raw = "$errorType|$moduleName|${location.sourceFile}|${location.functionName}|${location.lineNumber}"
        return try {
            val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
            digest.take(12).joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            raw.hashCode().toUInt().toString(16)
        }
    }

    fun buildSafeAppStateSummary(
        currentScreen: String,
        activeOperation: String,
        appVersionName: String,
        appVersionCode: Int,
        freeInternalMb: Long,
        wasPreviousCrashDetected: Boolean,
        extraNonSensitiveMeta: Map<String, String> = emptyMap(),
    ): String {
        val parts = linkedMapOf(
            "screen" to currentScreen.ifBlank { "unknown" },
            "activeOp" to activeOperation.ifBlank { "idle" },
            "appVersion" to "$appVersionName ($appVersionCode)",
            "androidSdk" to Build.VERSION.SDK_INT.toString(),
            "device" to "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            "freeInternalMb" to freeInternalMb.toString(),
            "priorCrashDetected" to wasPreviousCrashDetected.toString(),
        )
        extraNonSensitiveMeta.forEach { (k, v) ->
            val safeKey = sanitizeText(k, 40)
            if (safeKey.isNotBlank()) {
                parts[safeKey] = sanitizeText(v, 180)
            }
        }
        return parts.entries.joinToString(" | ") { "${it.key}=${it.value}" }
    }
}
