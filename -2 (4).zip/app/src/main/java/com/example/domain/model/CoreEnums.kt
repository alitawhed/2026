package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class BarcodeFormatType(val arabicLabel: String, val is2D: Boolean = false) {
    EAN_13("EAN-13"),
    EAN_8("EAN-8"),
    UPC_A("UPC-A"),
    UPC_E("UPC-E"),
    CODE_128("Code 128"),
    CODE_39("Code 39"),
    ITF("ITF-14 / Interleaved 2of5"),
    CODABAR("Codabar"),
    QR_CODE("QR Code", is2D = true),
    DATA_MATRIX("Data Matrix", is2D = true),
    PDF_417("PDF417", is2D = true),
    AZTEC("Aztec", is2D = true);

    companion object {
        fun fromString(value: String?): BarcodeFormatType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: CODE_128
    }
}

@Serializable
enum class PaperSizeType(val arabicLabel: String, val widthMm: Float, val heightMm: Float) {
    A4("A4 (210 × 297 مم)", 210f, 297f),
    A3("A3 (297 × 420 مم)", 297f, 420f),
    A5("A5 (148 × 210 مم)", 148f, 210f),
    LETTER("Letter (215.9 × 279.4 مم)", 215.9f, 279.4f),
    CUSTOM("حجم مخصص", 210f, 297f);

    companion object {
        fun fromString(value: String?): PaperSizeType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: A4
    }
}

@Serializable
enum class PageOrientation(val arabicLabel: String) {
    PORTRAIT("عمودي"),
    LANDSCAPE("أفقي");

    companion object {
        fun fromString(value: String?): PageOrientation =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: PORTRAIT
    }
}

@Serializable
enum class ColumnType(val arabicLabel: String) {
    SERIAL("رقم تسلسلي"),
    TEXT("نص"),
    NUMBER("رقم"),
    PRICE("سعر"),
    CURRENCY("عملة"),
    QUANTITY("كمية"),
    DATE("تاريخ"),
    IMAGE("صورة"),
    MULTI_IMAGE("صور متعددة"),
    BARCODE("باركود"),
    QR_CODE("QR Code"),
    PERCENTAGE("نسبة مئوية"),
    NOTES("ملاحظات"),
    LINK("رابط"),
    DROPDOWN("قائمة خيارات"),
    CUSTOM_FIELD("حقل مخصص");

    companion object {
        fun fromString(value: String?): ColumnType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: TEXT
    }
}

@Serializable
enum class ColumnDistributionMode(val arabicLabel: String) {
    AUTO_FIT("تلقائي (ملاءمة عرض الورقة)"),
    EQUAL("متساوٍ"),
    MANUAL("يدوي");

    companion object {
        fun fromString(value: String?): ColumnDistributionMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: AUTO_FIT
    }
}

@Serializable
enum class ColumnWidthPreset(val arabicLabel: String) {
    NARROW("ضيق"),
    MEDIUM("متوسط"),
    WIDE("واسع"),
    CUSTOM("مخصص");

    companion object {
        fun fromString(value: String?): ColumnWidthPreset =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: MEDIUM
    }
}

@Serializable
enum class CellAlignment(val arabicLabel: String) {
    START("يمين (بداية)"),
    CENTER("وسط"),
    END("يسار (نهاية)");

    companion object {
        fun fromString(value: String?): CellAlignment =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: START
    }
}

@Serializable
enum class DuplicateProductBehavior(val arabicLabel: String) {
    INCREMENT_QTY("زيادة الكمية في الصف الموجود"),
    NEW_ROW("إنشاء صف جديد"),
    PREVENT("منع التكرار");

    companion object {
        fun fromString(value: String?): DuplicateProductBehavior =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: INCREMENT_QTY
    }
}

@Serializable
enum class TemplateKind(val arabicLabel: String, val description: String) {
    OFFICIAL_COMMERCIAL("تقرير تجاري رسمي", "تخطيط عرض أسعار وفاتورة تجارية متكامل مع الإجماليات والختم والتوقيع"),
    PRICE_LIST("قائمة أسعار", "جدول مدمج وواضح لعرض الأسعار والعملة والباركود الرئيسي"),
    PRODUCT_CATALOG("كتالوج منتجات", "صفوف مرتفعة لعرض الصور الكبيرة والوصف والمصنع ورمز QR"),
    INVENTORY("تقرير جرد", "أعمدة مخصصة للمخزون والكميات والفروقات والملاحظات"),
    PHOTO_REPORT("تقرير منتجات بالصور", "تركيز بصري على صور المنتجات عالية الجودة مع الأسعار"),
    BARCODE_REPORT("تقرير باركودات", "أعمدة واسعة مخصصة لطباعة الباركودات القابلة للمسح بدقة عالية"),
    QUANTITY_REPORT("تقرير كميات", "تركيز على الكميات الافتراضية والمعتمدة وإجمالي الوحدات"),
    SUMMARY_REPORT("تقرير مختصر", "تقرير موجز وسريع من 4 أعمدة أساسية للمراجعة الفورية"),
    DETAILED_REPORT("تقرير تفصيلي", "عرض أفقي شامل لجميع تفاصيل المنتج والباركودات والأسعار والخصومات"),
    BLANK_CUSTOM("قالب فارغ قابل للتصميم", "بداية مرنة بأعمدة أساسية لتصميم تقريرك من الصفر");

    companion object {
        fun fromString(value: String?): TemplateKind =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: OFFICIAL_COMMERCIAL
    }
}

@Serializable
enum class ThemeMode(val arabicLabel: String) {
    SYSTEM("تلقائي حسب النظام"),
    LIGHT("الوضع الفاتح"),
    DARK("الوضع الداكن");

    companion object {
        fun fromString(value: String?): ThemeMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: SYSTEM
    }
}

enum class SaveStatus(val arabicLabel: String) {
    IDLE("جاهز"),
    SAVING("جارٍ الحفظ..."),
    SAVED("تم الحفظ"),
    ERROR("تعذر الحفظ")
}

@Serializable
enum class ProductSelectionViewMode(val arabicLabel: String) {
    LIST("قائمة بالصور"),
    GRID("شبكة بطاقات"),
    COMPACT("عرض مدمج"),
    DETAILED("عرض تفصيلي");

    companion object {
        fun fromString(value: String?): ProductSelectionViewMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: LIST
    }
}

@Serializable
enum class ReportRowSortMode(val arabicLabel: String) {
    MANUAL("ترتيب يدوي (مخصص)"),
    NAME_ASC("الاسم (أ - ي)"),
    BARCODE_ASC("الباركود (تصاعدي)"),
    PRICE_DESC("السعر (الأعلى أولاً)"),
    PRICE_ASC("السعر (الأقل أولاً)"),
    QTY_DESC("الكمية (الأعلى أولاً)"),
    CATEGORY_ASC("التصنيف");

    companion object {
        fun fromString(value: String?): ReportRowSortMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: MANUAL
    }
}

@Serializable
enum class ReportImageSourceType(val arabicLabel: String) {
    PRODUCT_PRIMARY("صورة المنتج الأساسية"),
    PRODUCT_GALLERY("من معرض صور المنتج"),
    REPORT_UPLOAD("صورة مرفوعة للتقرير فقط"),
    REPORT_EDITED("نسخة محررة للتقرير فقط");

    companion object {
        fun fromString(value: String?): ReportImageSourceType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: PRODUCT_PRIMARY
    }
}

@Serializable
enum class BarcodeUnitType(val arabicLabel: String) {
    PIECE("حبة"),
    BOX("علبة"),
    CARTON("كرتون"),
    LARGE_PACK("عبوة كبيرة"),
    SMALL_PACK("عبوة صغيرة");

    companion object {
        fun fromString(value: String?): BarcodeUnitType =
            entries.firstOrNull {
                it.name.equals(value, ignoreCase = true) || it.arabicLabel == value?.trim()
            } ?: PIECE
    }
}

@Serializable
enum class InventorySessionStatus(val arabicLabel: String) {
    OPEN("قيد الجرد (مفتوح)"),
    CLOSED("مغلق"),
    RECONCILED("معتمد ومسوى");

    companion object {
        fun fromString(value: String?): InventorySessionStatus =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: OPEN
    }
}

@Serializable
enum class InventoryItemStatus(val arabicLabel: String) {
    COUNTED("تم جرده"),
    UNREGISTERED("غير مسجل");

    companion object {
        fun fromString(value: String?): InventoryItemStatus =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: COUNTED
    }
}
