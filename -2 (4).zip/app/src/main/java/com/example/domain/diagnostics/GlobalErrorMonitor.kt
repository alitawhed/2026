package com.example.domain.diagnostics

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import com.example.BuildConfig
import com.example.data.local.dao.DiagnosticsDao
import com.example.data.local.entity.ErrorLogEntity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

object ScreenNames {
    const val DASHBOARD = "الصفحة الرئيسية ولوحة التحكم"
    const val PRODUCTS = "شاشة المنتجات"
    const val PRODUCT_DETAIL = "تفاصيل المنتج"
    const val PRODUCT_EDITOR = "إضافة وتعديل المنتجات"
    const val IMAGES = "صور المنتجات والمعرض"
    const val IMAGE_EDITOR = "محرر الصور"
    const val BARCODE_SCANNER = "الباركود ومسح الكاميرا"
    const val EXCEL_IMPORT = "استيراد وتصدير Excel"
    const val ARCHIVE = "الأرشيف والتقارير"
    const val REPORT_EDITOR = "محرر التقارير"
    const val REPORT_PICKER = "منتقي منتجات التقرير"
    const val PDF_PREVIEW = "معاينة وطباعة PDF"
    const val PDF_EDITOR = "محرر PDF"
    const val TEMPLATES = "القوالب"
    const val LABEL_PRINTING = "طباعة الملصقات"
    const val INVENTORY = "الجرد وإدارة الكميات"
    const val BACKUP_RESTORE = "النسخ الاحتياطي والاستعادة"
    const val SETTINGS = "الإعدادات العامة"
    const val ABOUT = "حول التطبيق"
    const val ERROR_DIAGNOSTICS = "مركز تشخيص الأخطاء"
    const val AUTH = "تسجيل الدخول والحساب"
    const val ACCOUNT = "إدارة الحساب"
    const val SUBSCRIPTION = "الاشتراكات والمزايا"
    const val PRIVACY = "الخصوصية وحذف الحساب"

    fun resolveRouteName(routeName: String?): String {
        if (routeName.isNullOrBlank()) return DASHBOARD
        return when {
            routeName.contains("Dashboard") -> DASHBOARD
            routeName.contains("Products") -> PRODUCTS
            routeName.contains("ProductDetail") -> PRODUCT_DETAIL
            routeName.contains("ProductEditor") -> PRODUCT_EDITOR
            routeName.contains("ImageManager") -> IMAGES
            routeName.contains("ImageEditor") -> IMAGE_EDITOR
            routeName.contains("BarcodeScanner") -> BARCODE_SCANNER
            routeName.contains("ExcelImport") -> EXCEL_IMPORT
            routeName.contains("Archive") -> ARCHIVE
            routeName.contains("ReportEditor") -> REPORT_EDITOR
            routeName.contains("ReportProductPicker") -> REPORT_PICKER
            routeName.contains("PdfPreview") -> PDF_PREVIEW
            routeName.contains("PdfEditor") -> PDF_EDITOR
            routeName.contains("Templates") -> TEMPLATES
            routeName.contains("LabelPrinting") -> LABEL_PRINTING
            routeName.contains("Inventory") -> INVENTORY
            routeName.contains("BackupRestore") -> BACKUP_RESTORE
            routeName.contains("ErrorDiagnostics") -> ERROR_DIAGNOSTICS
            routeName.contains("Settings") -> SETTINGS
            routeName.contains("AboutApp") -> ABOUT
            routeName.contains("Auth") -> AUTH
            routeName.contains("AccountManagement") -> ACCOUNT
            routeName.contains("Subscription") -> SUBSCRIPTION
            routeName.contains("Privacy") -> PRIVACY
            else -> routeName.substringAfterLast('.').substringBefore('/')
        }
    }
}

object DiagnosticModules {
    const val DASHBOARD = "لوحة التحكم"
    const val PRODUCTS = "المنتجات"
    const val IMAGES = "الصور والمعرض"
    const val BARCODE_CAMERA = "الكاميرا والباركود"
    const val EXCEL = "Excel"
    const val REPORTS = "التقارير"
    const val PDF = "PDF والطباعة"
    const val INVENTORY = "الجرد والكميات"
    const val BACKUP_RESTORE = "النسخ الاحتياطي والاستعادة"
    const val SQLITE = "SQLite"
    const val STORAGE = "التخزين والملفات"
    const val NAVIGATION = "التنقل والواجهة"
    const val SETTINGS = "الإعدادات"
    const val SYSTEM = "النظام والانهيارات"
    const val AUTH = "المصادقة والحسابات"
    const val BILLING = "الاشتراكات والفوترة"
    const val WORKSPACE = "عزل مساحات العمل"
}

class GlobalErrorMonitor(
    private val context: Context,
    val fileStore: DiagnosticsFileStore,
    val operationLogger: OperationLogger,
    private var diagnosticsDaoProvider: (() -> DiagnosticsDao?)? = null,
) {
    private val lock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val errorsList = mutableListOf<ErrorEventRecord>()

    @Volatile
    var currentScreenName: String = ScreenNames.DASHBOARD
        private set

    @Volatile
    var priorCrashDetected: Boolean = false
        private set

    private val _errors = MutableStateFlow<List<ErrorEventRecord>>(emptyList())
    val errors: StateFlow<List<ErrorEventRecord>> = _errors.asStateFlow()

    private val _stats = MutableStateFlow(DiagnosticSummaryStats())
    val stats: StateFlow<DiagnosticSummaryStats> = _stats.asStateFlow()

    private val _previousCrashAlert = MutableStateFlow<ErrorEventRecord?>(null)
    val previousCrashAlert: StateFlow<ErrorEventRecord?> = _previousCrashAlert.asStateFlow()

    private val _lastRestoreDiagnostics = MutableStateFlow<RestoreDiagnosticsReport?>(null)
    val lastRestoreDiagnostics: StateFlow<RestoreDiagnosticsReport?> = _lastRestoreDiagnostics.asStateFlow()

    @Volatile
    private var handlersInstalled = false
    private var previousUncaughtHandler: Thread.UncaughtExceptionHandler? = null

    init {
        reloadFromStore()
        operationLogger.setOnOperationsChangedListener {
            refreshStats()
        }
    }

    fun attachDaoProvider(provider: () -> DiagnosticsDao?) {
        diagnosticsDaoProvider = provider
        operationLogger.attachDaoProvider(provider)
    }

    fun updateCurrentScreen(screenName: String) {
        if (screenName.isNotBlank()) {
            currentScreenName = screenName
        }
    }

    fun reloadFromStore() {
        synchronized(lock) {
            val loadedErrors = fileStore.readAllErrors()
            errorsList.clear()
            errorsList.addAll(loadedErrors)
            _errors.value = errorsList.toList()
            _lastRestoreDiagnostics.value = fileStore.readLastRestoreDiagnostics()
            recomputeStatsLocked()
        }
    }

    fun refreshStats() {
        synchronized(lock) {
            recomputeStatsLocked()
        }
    }

    fun installGlobalHandlers(application: Application? = null) {
        if (!handlersInstalled) {
            handlersInstalled = true
            previousUncaughtHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                try {
                    recordFatalCrashSynchronous(thread.name, throwable)
                } catch (_: Throwable) {
                    // Never break crash handling itself
                } finally {
                    previousUncaughtHandler?.uncaughtException(thread, throwable)
                }
            }
        }

        // Check if previous launch terminated with an uncaught crash or system exit
        var recoveredCrash: ErrorEventRecord? = fileStore.consumePendingCrash()
        if (recoveredCrash != null) {
            priorCrashDetected = true
            upsertErrorRecord(recoveredCrash)
            _previousCrashAlert.value = recoveredCrash
        } else if (application != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            recoveredCrash = inspectHistoricalExitReasons(application)
        }

        // Always detect and reconcile any leftover STARTED/RUNNING operations from an abnormally terminated process
        val reconciledOps = operationLogger.reconcileInterruptedOperations(
            crashErrorId = recoveredCrash?.errorId.orEmpty(),
            crashDescription = recoveredCrash?.let {
                "${it.errorType}: ${it.originalMessage}"
            }.orEmpty(),
        )
        if (reconciledOps.isNotEmpty()) {
            val primaryOp = reconciledOps.first()
            if (recoveredCrash != null && recoveredCrash.linkedOperationId.isBlank()) {
                val linkedCrash = recoveredCrash.copy(
                    linkedOperationId = primaryOp.operationId,
                    failedStage = recoveredCrash.failedStage.ifBlank { primaryOp.currentStage },
                )
                upsertErrorRecord(linkedCrash)
                _previousCrashAlert.value = linkedCrash
            } else if (recoveredCrash == null) {
                priorCrashDetected = true
                val interruptionErr = recordCustomError(
                    screenName = primaryOp.screenName,
                    moduleName = primaryOp.moduleName,
                    operationName = primaryOp.operationName,
                    errorType = "InterruptedOperationOnExit",
                    message = "انقطع التشغيل بشكل غير طبيعي قبل إكمال العملية (${primaryOp.operationName}) عند مرحلة: ${primaryOp.currentStage}. آخر مرحلة ناجحة: ${primaryOp.lastSuccessfulStage.ifBlank { "لا يوجد" }}",
                    wasHandled = false,
                    severity = LogSeverity.CRITICAL,
                    linkedOperationId = primaryOp.operationId,
                    failedStage = primaryOp.currentStage,
                    extraMeta = mapOf(
                        "lastSuccessfulStage" to primaryOp.lastSuccessfulStage,
                        "reconciledCount" to reconciledOps.size.toString(),
                    ),
                )
                operationLogger.linkOperationsToError(
                    operationIds = reconciledOps.map { it.operationId },
                    errorId = interruptionErr.errorId,
                )
                _previousCrashAlert.value = interruptionErr
            }
        }
        refreshStats()
    }

    private fun inspectHistoricalExitReasons(application: Application): ErrorEventRecord? {
        return runCatching {
            val prefs = application.getSharedPreferences("diagnostics_prefs", Context.MODE_PRIVATE)
            val lastHandledExitTs = prefs.getLong("last_handled_exit_ts", 0L)
            val am = application.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return null
            val reasons = am.getHistoricalProcessExitReasons(application.packageName, 0, 8)
            val exitInfo = reasons.firstOrNull { info ->
                info.timestamp > lastHandledExitTs && (
                    info.reason == ApplicationExitInfo.REASON_CRASH ||
                        info.reason == ApplicationExitInfo.REASON_CRASH_NATIVE ||
                        info.reason == ApplicationExitInfo.REASON_ANR ||
                        info.reason == ApplicationExitInfo.REASON_LOW_MEMORY ||
                        info.reason == ApplicationExitInfo.REASON_SIGNALED ||
                        info.reason == ApplicationExitInfo.REASON_INITIALIZATION_FAILURE
                    )
            } ?: return null

            prefs.edit().putLong("last_handled_exit_ts", exitInfo.timestamp).apply()
            val alreadyLogged = synchronized(lock) {
                errorsList.any { it.isCrash && kotlin.math.abs(it.timestamp - exitInfo.timestamp) < 5_000L }
            }
            if (alreadyLogged) return null

            priorCrashDetected = true
            val reasonLabel = when (exitInfo.reason) {
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "NativeCrash"
                ApplicationExitInfo.REASON_ANR -> "ApplicationNotResponding"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "LowMemoryKill"
                ApplicationExitInfo.REASON_SIGNALED -> "SignalTermination"
                ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "InitFailure"
                else -> "ProcessCrash"
            }

            val rawDesc = exitInfo.description?.trim().orEmpty()
            val traceExcerpt = readBoundedTraceExcerpt(exitInfo)
            val subReasonValue = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                runCatching {
                    ApplicationExitInfo::class.java.getMethod("getSubReason").invoke(exitInfo)?.toString()
                }.getOrNull() ?: "n/a"
            } else {
                "n/a"
            }
            val pssMb = (exitInfo.pss / 1024L).coerceAtLeast(0L)
            val rssMb = (exitInfo.rss / 1024L).coerceAtLeast(0L)
            val importanceLabel = mapImportanceLabel(exitInfo.importance)

            val enrichedMessage = buildString {
                append("انتهاء غير متوقع للعملية: $reasonLabel")
                if (rawDesc.isNotBlank() && !rawDesc.equals("crash", ignoreCase = true)) {
                    append(" — ").append(rawDesc)
                } else {
                    append(" (الوصف النظامي الخام: ${rawDesc.ifBlank { "غير متوفر" }})")
                }
                append(" | الأهمية=$importanceLabel | status=${exitInfo.status} | subReason=$subReasonValue")
                append(" | PSS=${pssMb}MB, RSS=${rssMb}MB | pid=${exitInfo.pid}")
            }

            val stackContent = buildString {
                appendLine("=== تفاصيل ApplicationExitInfo الكاملة ===")
                appendLine("Process: ${exitInfo.processName} (pid=${exitInfo.pid})")
                appendLine("Reason: $reasonLabel (code=${exitInfo.reason}, subReason=$subReasonValue, status=${exitInfo.status})")
                appendLine("Importance: $importanceLabel (${exitInfo.importance})")
                appendLine("Memory Footprint: PSS=${pssMb}MB | RSS=${rssMb}MB")
                appendLine("System Description: ${rawDesc.ifBlank { "<empty>" }}")
                if (traceExcerpt.isNotBlank()) {
                    appendLine("--- مقتطف تتبع النظام (Trace Stream) ---")
                    appendLine(traceExcerpt)
                } else {
                    appendLine("ملاحظة: نظام التشغيل لم يُرفق ملف trace إضافي لهذا الخروج (شائع عند قتل العملية الفوري من النظام أو انقطاع بدون JVM stack).")
                }
            }

            val sanitizedMsg = DiagnosticSanitizer.sanitizeText(enrichedMessage, 1500)
            val sanitizedTrace = DiagnosticSanitizer.sanitizeText(stackContent, 8000)

            val rec = ErrorEventRecord(
                errorId = UUID.randomUUID().toString(),
                timestamp = exitInfo.timestamp,
                screenName = currentScreenName,
                moduleName = DiagnosticModules.SYSTEM,
                operationName = "انتهاء غير متوقع للعملية السابقة",
                errorType = reasonLabel,
                originalMessage = sanitizedMsg,
                stackTrace = sanitizedTrace,
                sourceFile = "SystemProcess(${exitInfo.processName})",
                lineNumber = exitInfo.status,
                functionName = "ApplicationExitInfo.reason=${exitInfo.reason}",
                appStateSummary = buildAppState(
                    mapOf(
                        "exitReason" to exitInfo.reason.toString(),
                        "exitSubReason" to subReasonValue,
                        "importance" to importanceLabel,
                        "pssMb" to pssMb.toString(),
                    ),
                ),
                wasHandled = false,
                severity = LogSeverity.CRITICAL,
                fingerprint = "system_exit_${exitInfo.reason}_${subReasonValue}_${exitInfo.status}",
                occurrenceCount = 1,
                firstSeenAt = exitInfo.timestamp,
                lastSeenAt = exitInfo.timestamp,
                isReviewed = false,
                deviceSummary = buildDeviceSummary(),
                appVersionSummary = buildAppVersionSummary(),
                isCrash = true,
            )
            upsertErrorRecord(rec)
            _previousCrashAlert.value = rec
            rec
        }.getOrNull()
    }

    private fun readBoundedTraceExcerpt(info: ApplicationExitInfo): String {
        return runCatching {
            info.traceInputStream?.use { stream ->
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                    val sb = StringBuilder()
                    var lines = 0
                    while (lines < 60 && sb.length < 4000) {
                        val line = reader.readLine() ?: break
                        sb.appendLine(line)
                        lines++
                    }
                    sb.toString().trim()
                }
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun mapImportanceLabel(importance: Int): String = when (importance) {
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "Foreground"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "ForegroundService"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "Visible"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED -> "Cached"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_GONE -> "Gone"
        else -> "Level($importance)"
    }

    fun dismissPreviousCrashAlert() {
        _previousCrashAlert.value = null
    }

    fun coroutineExceptionHandler(
        screenName: String? = null,
        moduleName: String = DiagnosticModules.SYSTEM,
        operationName: String = "عملية خلفية غير متوقعة",
        onHandled: ((Throwable) -> Unit)? = null,
    ): CoroutineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        recordError(
            throwable = throwable,
            screenName = screenName ?: currentScreenName,
            moduleName = moduleName,
            operationName = operationName,
            wasHandled = onHandled != null,
            severity = LogSeverity.CRITICAL,
        )
        onHandled?.invoke(throwable)
    }

    fun recordFatalCrashSynchronous(threadName: String, throwable: Throwable): ErrorEventRecord {
        val activeOpId = operationLogger.activeOperationId
        val activeStage = operationLogger.activeStageName
        val rec = buildRecord(
            throwable = throwable,
            screenName = currentScreenName,
            moduleName = inferModuleFromStack(throwable, currentScreenName),
            operationName = "انهيار غير معالج (${DiagnosticSanitizer.sanitizeText(threadName, 40)})",
            wasHandled = false,
            severity = LogSeverity.CRITICAL,
            linkedOperationId = activeOpId,
            failedStage = activeStage,
            isCrash = true,
            extraMeta = mapOf("thread" to threadName),
        )
        fileStore.writePendingCrashSynchronous(rec)
        fileStore.appendErrorSynchronous(rec)
        operationLogger.reconcileInterruptedOperations(
            crashErrorId = rec.errorId,
            crashDescription = "${rec.errorType}: ${rec.originalMessage}",
        )
        return rec
    }

    fun recordError(
        throwable: Throwable,
        screenName: String = currentScreenName,
        moduleName: String = inferModuleFromStack(throwable, screenName),
        operationName: String,
        wasHandled: Boolean = true,
        severity: LogSeverity = inferSeverity(throwable, wasHandled),
        linkedOperationId: String = "",
        failedStage: String = "",
        isCrash: Boolean = !wasHandled,
        extraMeta: Map<String, String> = emptyMap(),
    ): ErrorEventRecord {
        val resolvedOpId = linkedOperationId.ifBlank { operationLogger.activeOperationId }
        val resolvedStage = failedStage.ifBlank {
            if (resolvedOpId.isNotBlank() && resolvedOpId == operationLogger.activeOperationId) {
                operationLogger.activeStageName
            } else {
                extraMeta["stage"].orEmpty()
            }
        }
        val rec = buildRecord(
            throwable = throwable,
            screenName = screenName,
            moduleName = moduleName,
            operationName = operationName,
            wasHandled = wasHandled,
            severity = severity,
            linkedOperationId = resolvedOpId,
            failedStage = resolvedStage,
            isCrash = isCrash,
            extraMeta = extraMeta,
        )
        upsertErrorRecord(rec)
        return rec
    }

    fun recordCustomError(
        screenName: String = currentScreenName,
        moduleName: String,
        operationName: String,
        errorType: String,
        message: String,
        wasHandled: Boolean = true,
        severity: LogSeverity = LogSeverity.ERROR,
        linkedOperationId: String = "",
        failedStage: String = "",
        stackTraceOverride: String = "",
        extraMeta: Map<String, String> = emptyMap(),
    ): ErrorEventRecord {
        val now = System.currentTimeMillis()
        val resolvedOpId = linkedOperationId.ifBlank { operationLogger.activeOperationId }
        val resolvedStage = failedStage.ifBlank {
            if (resolvedOpId.isNotBlank() && resolvedOpId == operationLogger.activeOperationId) {
                operationLogger.activeStageName
            } else {
                extraMeta["stage"].orEmpty()
            }
        }
        val callerTrace = if (stackTraceOverride.isNotBlank()) {
            DiagnosticSanitizer.sanitizeText(stackTraceOverride, 8000)
        } else {
            val frames = Thread.currentThread().stackTrace.drop(3).take(25)
            frames.joinToString("\n") { "at ${it.className}.${it.methodName}(${it.fileName}:${it.lineNumber})" }
        }
        val appFrame = Thread.currentThread().stackTrace.drop(3).firstOrNull {
            it.className.startsWith("com.example") && !it.className.contains("GlobalErrorMonitor")
        }
        val loc = StackLocationInfo(
            sourceFile = appFrame?.fileName ?: "AppRuntime",
            lineNumber = (appFrame?.lineNumber ?: 0).coerceAtLeast(0),
            functionName = appFrame?.let { "${it.className.substringAfterLast('.')}.${it.methodName}" } ?: operationName,
        )
        val rec = ErrorEventRecord(
            errorId = UUID.randomUUID().toString(),
            timestamp = now,
            screenName = DiagnosticSanitizer.sanitizeText(screenName, 120),
            moduleName = DiagnosticSanitizer.sanitizeText(moduleName, 80),
            operationName = DiagnosticSanitizer.sanitizeText(operationName, 160),
            errorType = DiagnosticSanitizer.sanitizeText(errorType, 120),
            originalMessage = DiagnosticSanitizer.sanitizeText(message, 1500),
            stackTrace = callerTrace,
            sourceFile = loc.sourceFile,
            lineNumber = loc.lineNumber,
            functionName = loc.functionName,
            appStateSummary = buildAppState(extraMeta),
            wasHandled = wasHandled,
            severity = severity,
            fingerprint = DiagnosticSanitizer.computeFingerprint(errorType, moduleName, loc),
            occurrenceCount = 1,
            firstSeenAt = now,
            lastSeenAt = now,
            isReviewed = false,
            linkedOperationId = resolvedOpId,
            failedStage = DiagnosticSanitizer.sanitizeText(resolvedStage, 180),
            deviceSummary = buildDeviceSummary(),
            appVersionSummary = buildAppVersionSummary(),
            isCrash = !wasHandled && severity == LogSeverity.CRITICAL,
        )
        upsertErrorRecord(rec)
        return rec
    }

    inline fun <T> runGuarded(
        screenName: String = currentScreenName,
        moduleName: String,
        operationName: String,
        defaultValue: T,
        block: () -> T,
    ): T {
        return try {
            block()
        } catch (t: Throwable) {
            recordError(
                throwable = t,
                screenName = screenName,
                moduleName = moduleName,
                operationName = operationName,
                wasHandled = true,
            )
            defaultValue
        }
    }

    fun saveRestoreDiagnostics(report: RestoreDiagnosticsReport) {
        fileStore.saveLastRestoreDiagnostics(report)
        _lastRestoreDiagnostics.value = report
    }

    fun markErrorReviewed(errorId: String, reviewed: Boolean = true) {
        var updated: ErrorEventRecord? = null
        synchronized(lock) {
            val idx = errorsList.indexOfFirst { it.errorId == errorId }
            if (idx >= 0) {
                val next = errorsList[idx].copy(isReviewed = reviewed)
                updated = next
                errorsList[idx] = next
                _errors.value = errorsList.toList()
                recomputeStatsLocked()
            }
        }
        updated?.let { persistErrorsAsync(it) }
    }

    fun markAllReviewed() {
        synchronized(lock) {
            for (i in errorsList.indices) {
                errorsList[i] = errorsList[i].copy(isReviewed = true)
            }
            _errors.value = errorsList.toList()
            recomputeStatsLocked()
        }
        scope.launch {
            runCatching {
                val snapshot = synchronized(lock) { errorsList.toList() }
                fileStore.writeAllErrors(snapshot)
            }
            runCatching { diagnosticsDaoProvider?.invoke()?.markAllErrorsReviewed() }
        }
    }

    fun clearAllDiagnostics() {
        synchronized(lock) {
            errorsList.clear()
            _errors.value = emptyList()
            recomputeStatsLocked()
        }
        operationLogger.clearAll()
        scope.launch {
            runCatching { fileStore.clearAllLogs() }
            runCatching { diagnosticsDaoProvider?.invoke()?.clearAllErrors() }
        }
    }

    fun getSimilarErrors(fingerprint: String): List<ErrorEventRecord> {
        synchronized(lock) {
            return errorsList.filter { it.fingerprint == fingerprint }
        }
    }

    fun getErrorsForOperation(operationId: String): List<ErrorEventRecord> {
        if (operationId.isBlank()) return emptyList()
        synchronized(lock) {
            return errorsList.filter { it.linkedOperationId == operationId }
        }
    }

    private fun buildRecord(
        throwable: Throwable,
        screenName: String,
        moduleName: String,
        operationName: String,
        wasHandled: Boolean,
        severity: LogSeverity,
        linkedOperationId: String = "",
        failedStage: String = "",
        isCrash: Boolean = !wasHandled,
        extraMeta: Map<String, String> = emptyMap(),
    ): ErrorEventRecord {
        val now = System.currentTimeMillis()
        val loc = DiagnosticSanitizer.extractStackLocation(throwable)
        val errType = throwable::class.java.simpleName.ifBlank { throwable::class.java.name }
        val msg = DiagnosticSanitizer.sanitizeText(
            throwable.message ?: throwable.localizedMessage ?: errType,
            1500,
        )
        return ErrorEventRecord(
            errorId = UUID.randomUUID().toString(),
            timestamp = now,
            screenName = DiagnosticSanitizer.sanitizeText(screenName, 120),
            moduleName = DiagnosticSanitizer.sanitizeText(moduleName, 80),
            operationName = DiagnosticSanitizer.sanitizeText(operationName, 160),
            errorType = errType,
            originalMessage = msg,
            stackTrace = DiagnosticSanitizer.formatSanitizedStackTrace(throwable),
            sourceFile = loc.sourceFile,
            lineNumber = loc.lineNumber,
            functionName = loc.functionName,
            appStateSummary = buildAppState(extraMeta),
            wasHandled = wasHandled,
            severity = severity,
            fingerprint = DiagnosticSanitizer.computeFingerprint(errType, moduleName, loc),
            occurrenceCount = 1,
            firstSeenAt = now,
            lastSeenAt = now,
            isReviewed = false,
            linkedOperationId = linkedOperationId,
            failedStage = DiagnosticSanitizer.sanitizeText(failedStage, 180),
            deviceSummary = buildDeviceSummary(),
            appVersionSummary = buildAppVersionSummary(),
            isCrash = isCrash,
        )
    }

    private fun upsertErrorRecord(incoming: ErrorEventRecord) {
        var finalRec: ErrorEventRecord
        synchronized(lock) {
            val existingIdx = errorsList.indexOfFirst {
                it.fingerprint == incoming.fingerprint && !it.isReviewed
            }
            if (existingIdx >= 0) {
                val prev = errorsList[existingIdx]
                finalRec = prev.copy(
                    timestamp = incoming.timestamp,
                    lastSeenAt = incoming.timestamp,
                    occurrenceCount = prev.occurrenceCount + 1,
                    screenName = incoming.screenName,
                    operationName = incoming.operationName,
                    originalMessage = incoming.originalMessage.ifBlank { prev.originalMessage },
                    stackTrace = incoming.stackTrace.ifBlank { prev.stackTrace },
                    appStateSummary = incoming.appStateSummary,
                    wasHandled = prev.wasHandled && incoming.wasHandled,
                    severity = if (incoming.severity.priority > prev.severity.priority) incoming.severity else prev.severity,
                    linkedOperationId = incoming.linkedOperationId.ifBlank { prev.linkedOperationId },
                    failedStage = incoming.failedStage.ifBlank { prev.failedStage },
                    deviceSummary = incoming.deviceSummary.ifBlank { prev.deviceSummary },
                    appVersionSummary = incoming.appVersionSummary.ifBlank { prev.appVersionSummary },
                    isCrash = prev.isCrash || incoming.isCrash,
                )
                errorsList.removeAt(existingIdx)
                errorsList.add(0, finalRec)
            } else {
                finalRec = incoming
                errorsList.add(0, finalRec)
                if (errorsList.size > DiagnosticsFileStore.MAX_IN_MEMORY_ERRORS) {
                    errorsList.subList(DiagnosticsFileStore.MAX_IN_MEMORY_ERRORS, errorsList.size).clear()
                }
            }
            _errors.value = errorsList.toList()
            recomputeStatsLocked()
        }
        persistErrorsAsync(finalRec)
    }

    private fun recomputeStatsLocked() {
        val list = errorsList
        val ops = operationLogger.operations.value
        _stats.value = DiagnosticSummaryStats(
            totalErrors = list.size,
            newErrorsCount = list.count { !it.isReviewed },
            recurringErrorsCount = list.count { it.occurrenceCount > 1 },
            criticalErrorsCount = list.count { it.severity == LogSeverity.CRITICAL },
            handledErrorsCount = list.count { it.wasHandled },
            unreviewedCrashesCount = list.count { it.isCrash && !it.isReviewed },
            totalOperationsCount = ops.size,
            failedOperationsCount = ops.count { it.outcome == OperationOutcome.FAILED },
            cancelledOperationsCount = ops.count { it.outcome == OperationOutcome.CANCELLED },
            lastCrash = list.firstOrNull { it.isCrash } ?: list.firstOrNull { !it.wasHandled },
            lastFailedOperation = ops.firstOrNull { it.outcome == OperationOutcome.FAILED },
        )
    }

    private fun persistErrorsAsync(record: ErrorEventRecord) {
        val snapshot = synchronized(lock) { errorsList.toList() }
        fileStore.writeAllErrors(snapshot)
        scope.launch {
            if (record.moduleName != DiagnosticModules.SQLITE && record.moduleName != DiagnosticModules.BACKUP_RESTORE) {
                runCatching {
                    diagnosticsDaoProvider?.invoke()?.upsertError(
                        ErrorLogEntity(
                            errorId = record.errorId,
                            timestamp = record.timestamp,
                            screenName = record.screenName,
                            moduleName = record.moduleName,
                            operationName = record.operationName,
                            errorType = record.errorType,
                            originalMessage = record.originalMessage,
                            stackTrace = record.stackTrace,
                            sourceFile = record.sourceFile,
                            lineNumber = record.lineNumber,
                            functionName = record.functionName,
                            appStateSummary = record.appStateSummary,
                            wasHandled = record.wasHandled,
                            severity = record.severity.name,
                            fingerprint = record.fingerprint,
                            occurrenceCount = record.occurrenceCount,
                            firstSeenAt = record.firstSeenAt,
                            lastSeenAt = record.lastSeenAt,
                            isReviewed = record.isReviewed,
                            linkedOperationId = record.linkedOperationId,
                            failedStage = record.failedStage,
                            deviceSummary = record.deviceSummary,
                            appVersionSummary = record.appVersionSummary,
                            isCrash = record.isCrash,
                        ),
                    )
                }
            }
        }
    }

    private fun buildAppState(extraMeta: Map<String, String> = emptyMap()): String {
        val freeMb = runCatching { context.filesDir.usableSpace / (1024L * 1024L) }.getOrDefault(0L)
        return DiagnosticSanitizer.buildSafeAppStateSummary(
            currentScreen = currentScreenName,
            activeOperation = operationLogger.activeOperationName,
            appVersionName = BuildConfig.VERSION_NAME,
            appVersionCode = BuildConfig.VERSION_CODE,
            freeInternalMb = freeMb,
            wasPreviousCrashDetected = priorCrashDetected,
            extraNonSensitiveMeta = extraMeta,
        )
    }

    private fun buildDeviceSummary(): String {
        val deviceName = "${Build.MANUFACTURER.orEmpty()} ${Build.MODEL.orEmpty()}".trim().ifBlank { "Android Device" }
        val rel = Build.VERSION.RELEASE ?: "unknown"
        return "$deviceName • Android $rel (SDK ${Build.VERSION.SDK_INT})"
    }

    private fun buildAppVersionSummary(): String =
        "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

    private fun inferSeverity(t: Throwable, wasHandled: Boolean): LogSeverity = when {
        !wasHandled -> LogSeverity.CRITICAL
        t is OutOfMemoryError -> LogSeverity.CRITICAL
        t.javaClass.name.contains("SQLite", ignoreCase = true) -> LogSeverity.CRITICAL
        t is SecurityException -> LogSeverity.ERROR
        else -> LogSeverity.ERROR
    }

    private fun inferModuleFromStack(t: Throwable, screen: String): String {
        val trace = t.stackTraceToString()
        return when {
            trace.contains("backup", ignoreCase = true) -> DiagnosticModules.BACKUP_RESTORE
            trace.contains("sqlite", ignoreCase = true) || trace.contains("room", ignoreCase = true) -> DiagnosticModules.SQLITE
            trace.contains("excel", ignoreCase = true) || trace.contains("poi", ignoreCase = true) -> DiagnosticModules.EXCEL
            trace.contains("pdf", ignoreCase = true) -> DiagnosticModules.PDF
            trace.contains("BarcodeScanner", ignoreCase = true) || trace.contains("Camera", ignoreCase = true) -> DiagnosticModules.BARCODE_CAMERA
            trace.contains("Inventory", ignoreCase = true) -> DiagnosticModules.INVENTORY
            trace.contains("Image", ignoreCase = true) || trace.contains("Bitmap", ignoreCase = true) -> DiagnosticModules.IMAGES
            trace.contains("MediaStorage", ignoreCase = true) -> DiagnosticModules.STORAGE
            trace.contains("Report", ignoreCase = true) -> DiagnosticModules.REPORTS
            trace.contains("Product", ignoreCase = true) -> DiagnosticModules.PRODUCTS
            else -> screen
        }
    }
}
