package com.example.domain.billing

import kotlinx.serialization.Serializable

enum class SubscriptionPlanType(val arabicTitle: String) {
    FREE("الباقة المجانية"),
    PRO_MONTHLY("الباقة الاحترافية — شهري"),
    PRO_YEARLY("الباقة الاحترافية — سنوي"),
}

enum class SubscriptionStatus(
    val arabicLabel: String,
    val isProEntitled: Boolean,
) {
    FREE("الباقة المجانية (غير مشترك)", false),
    TRIAL("فترة تجربة مجانية نشطة", true),
    ACTIVE("اشتراك نشط", true),
    CANCELLED_GRACE("ملغي — متاح حتى نهاية الفترة / فترة السماح", true),
    PENDING("بانتظار إتمام الدفع عبر Google Play", false),
    ON_HOLD_EXPIRED("اشتراك منتهي أو معلّق الدفع", false),
}

enum class VerificationMode(val arabicLabel: String) {
    CLIENT_PLAY_BILLING("تحقق محلي عبر Google Play Billing (بدون خادم)"),
    NOT_VERIFIED("غير متحقق بعد"),
}

enum class BillingConnectionState(val arabicLabel: String) {
    IDLE("غير متصل بخدمة الفوترة بعد"),
    CONNECTING("جاري الاتصال بمتجر Google Play..."),
    CONNECTED("متصل بخدمة Google Play Billing"),
    UNAVAILABLE("خدمة Google Play Billing غير متاحة على هذا الجهاز"),
    ERROR("تعذر الاتصال بخدمة Google Play Billing"),
}

@Serializable
data class PlayBillingConfiguration(
    val subscriptionProductId: String = "",
    val monthlyProductId: String = "",
    val yearlyProductId: String = "",
    val monthlyBasePlanId: String = "",
    val yearlyBasePlanId: String = "",
    val trialOfferId: String = "",
    val updatedAtMs: Long = 0L,
) {
    fun allConfiguredProductIds(): List<String> =
        listOf(subscriptionProductId, monthlyProductId, yearlyProductId)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()

    val isConfigured: Boolean
        get() = allConfiguredProductIds().isNotEmpty()
}

data class SubscriptionOfferUiModel(
    val productId: String,
    val basePlanId: String,
    val offerId: String? = null,
    val offerToken: String,
    val planType: SubscriptionPlanType,
    val title: String,
    val description: String = "",
    val formattedPrice: String,
    val priceCurrencyCode: String = "",
    val billingPeriodIso: String = "",
    val billingPeriodArabic: String = "",
    val hasFreeTrial: Boolean = false,
    val freeTrialDays: Int = 0,
    val freeTrialLabel: String? = null,
)

@Serializable
data class SubscriptionEntitlementState(
    val status: SubscriptionStatus = SubscriptionStatus.FREE,
    val planType: SubscriptionPlanType = SubscriptionPlanType.FREE,
    val activeProductId: String? = null,
    val activeBasePlanId: String? = null,
    val purchaseToken: String? = null,
    val orderId: String? = null,
    val isAutoRenewing: Boolean = false,
    val purchaseTimeMs: Long = 0L,
    val isAcknowledged: Boolean = false,
    val linkedAuthUid: String? = null,
    val verificationMode: VerificationMode = VerificationMode.CLIENT_PLAY_BILLING,
    val isOfflineFallback: Boolean = false,
    val lastCheckedMs: Long = 0L,
) {
    val isProEntitled: Boolean
        get() = status.isProEntitled
}

sealed class BillingActionResult {
    data class Success(val message: String) : BillingActionResult()
    data class Pending(val message: String) : BillingActionResult()
    data class Cancelled(val message: String) : BillingActionResult()
    data class Failure(
        val arabicMessage: String,
        val responseCode: Int? = null,
        val isRecoverable: Boolean = true,
    ) : BillingActionResult()
}

enum class FreeFeature(
    val arabicTitle: String,
    val arabicDescription: String,
) {
    ACCOUNT_MANAGEMENT("إدارة الحساب وتسجيل الدخول", "تسجيل الدخول عبر Google أو البريد الإلكتروني وإدارة الحساب"),
    PRODUCT_MANAGEMENT("إدارة المنتجات", "إضافة المنتجات وتعديلها وإدارة الأسعار والصور"),
    BARCODE_SCANNING("مسح الباركود بالكاميرا", "البحث الفوري وإدخال الباركود وتوليده"),
    INVENTORY_BASIC("إدارة الكميات والجرد الأساسي", "تسجيل الكميات والوحدات ومتابعة جلسات الجرد"),
    VIEW_HISTORY_AND_LOGS("عرض السجلات والبيانات السابقة", "استعراض كافة السجلات والتقارير السابقة بالكامل"),
    BACKUP_AND_RESTORE("النسخ الاحتياطي والاستعادة (ZIP)", "إنشاء واستعادة النسخ الاحتياطية الكاملة بحرية دائمة"),
    READ_LEGACY_DATA("الوصول الدائم للبيانات القديمة", "الاطلاع على كل البيانات والتقارير السابقة حتى بعد انتهاء الاشتراك"),
}

enum class ProFeature(
    val arabicTitle: String,
    val arabicDescription: String,
) {
    PRO_REPORTS_AND_EXPORT(
        "التقارير الاحترافية وتصدير PDF وExcel المتقدم",
        "توليد وتصدير التقارير الاحترافية المتقدمة بصيغ PDF وExcel.",
    ),
    PRO_TEMPLATE_CUSTOMIZATION(
        "تخصيص تصميم التقارير والقوالب",
        "إنشاء وتعديل واستيراد ونسخ قوالب التقارير الاحترافية.",
    ),
    PRO_ADVANCED_COLUMN_STYLING(
        "التحكم المتقدم في الأعمدة والتنسيقات",
        "تخصيص الترويسة والتذييل والباركود وتخطيط الأعمدة المتقدم في التقارير.",
    ),
    PRO_ADVANCED_INVENTORY_TOOLS(
        "أدوات وتقارير الجرد الاحترافية",
        "تصدير كشوف وتقارير الجرد الاحترافية بصيغ PDF وExcel.",
    ),
}

sealed interface FeatureAccessDecision {
    data object Allowed : FeatureAccessDecision
    data class RequiresProUpgrade(
        val feature: ProFeature,
        val currentStatus: SubscriptionStatus,
        val isBillingConfigured: Boolean,
    ) : FeatureAccessDecision
}

object BillingPeriodParser {
    fun parseDays(isoPeriod: String): Int {
        val raw = isoPeriod.trim().uppercase()
        if (!raw.startsWith("P") || raw.length < 3) return 0
        val value = raw.drop(1).dropLast(1).toIntOrNull() ?: return 0
        return when (raw.last()) {
            'D' -> value
            'W' -> value * 7
            'M' -> value * 30
            'Y' -> value * 365
            else -> 0
        }
    }

    fun toArabicPeriodLabel(isoPeriod: String): String {
        return when (isoPeriod.trim().uppercase()) {
            "P1W" -> "أسبوعياً"
            "P1M" -> "شهرياً"
            "P3M" -> "كل 3 أشهر"
            "P6M" -> "كل 6 أشهر"
            "P1Y" -> "سنوياً"
            else -> isoPeriod.ifBlank { "دوري" }
        }
    }
}
