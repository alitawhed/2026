package com.example.domain.diagnostics

import kotlinx.serialization.Serializable

@Serializable
enum class LogSeverity(val arabicLabel: String, val priority: Int) {
    DEBUG("تصحيح", 1),
    INFO("معلومات", 2),
    WARNING("تحذير", 3),
    ERROR("خطأ", 4),
    CRITICAL("حرج", 5),
}

@Serializable
enum class OperationOutcome(val arabicLabel: String) {
    STARTED("بدأت"),
    RUNNING("قيد التنفيذ"),
    SUCCESS("نجح"),
    WARNING("تحذير"),
    FAILED("فشل"),
    CANCELLED("أُلغيت"),
}

@Serializable
data class ErrorEventRecord(
    val errorId: String,
    val timestamp: Long,
    val screenName: String,
    val moduleName: String,
    val operationName: String,
    val errorType: String,
    val originalMessage: String,
    val stackTrace: String,
    val sourceFile: String,
    val lineNumber: Int,
    val functionName: String,
    val appStateSummary: String,
    val wasHandled: Boolean,
    val severity: LogSeverity,
    val fingerprint: String,
    val occurrenceCount: Int = 1,
    val firstSeenAt: Long = timestamp,
    val lastSeenAt: Long = timestamp,
    val isReviewed: Boolean = false,
    val linkedOperationId: String = "",
    val failedStage: String = "",
    val deviceSummary: String = "",
    val appVersionSummary: String = "",
    val isCrash: Boolean = false,
) {
    val isRecurring: Boolean get() = occurrenceCount > 1
}

@Serializable
data class OperationStageRecord(
    val stageName: String,
    val timestamp: Long,
    val status: String,
    val detail: String = "",
)

@Serializable
data class OperationLogRecord(
    val operationId: String,
    val startTime: Long,
    val endTime: Long = 0L,
    val screenName: String,
    val moduleName: String,
    val operationName: String,
    val severity: LogSeverity = LogSeverity.INFO,
    val outcome: OperationOutcome = OperationOutcome.RUNNING,
    val currentStage: String = "",
    val lastSuccessfulStage: String = "",
    val interruptedAbnormally: Boolean = false,
    val failureReason: String = "",
    val linkedErrorId: String = "",
    val stages: List<OperationStageRecord> = emptyList(),
)

@Serializable
data class RestoreVerificationCheck(
    val checkName: String,
    val passed: Boolean,
    val detail: String = "",
)

@Serializable
data class PendingRestoreVerification(
    val operationId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expectedProducts: Int = 0,
    val expectedImages: Int = 0,
    val expectedReports: Int = 0,
)

@Serializable
data class RestoreDiagnosticsReport(
    val timestamp: Long = System.currentTimeMillis(),
    val operationId: String = "",
    val phase: String = "INSPECT",
    val outcome: String = "UNKNOWN",
    val sourceFormatVersion: Int = 0,
    val sourceSchemaVersion: Int = 0,
    val targetSchemaVersion: Int = 0,
    val sourceAppVersion: String = "",
    val targetAppVersion: String = "",
    val zipSizeBytes: Long = 0L,
    val assetFilesInZip: Int = 0,
    val missingFiles: List<String> = emptyList(),
    val corruptedFiles: List<String> = emptyList(),
    val stageTimeline: List<OperationStageRecord> = emptyList(),
    val verificationChecks: List<RestoreVerificationCheck> = emptyList(),
    val targetDataPreservedOnFailure: Boolean = true,
    val failureStage: String = "",
    val failureReason: String = "",
)

@Serializable
data class DiagnosticSummaryStats(
    val totalErrors: Int = 0,
    val newErrorsCount: Int = 0,
    val recurringErrorsCount: Int = 0,
    val criticalErrorsCount: Int = 0,
    val handledErrorsCount: Int = 0,
    val unreviewedCrashesCount: Int = 0,
    val totalOperationsCount: Int = 0,
    val failedOperationsCount: Int = 0,
    val cancelledOperationsCount: Int = 0,
    val lastCrash: ErrorEventRecord? = null,
    val lastFailedOperation: OperationLogRecord? = null,
)
