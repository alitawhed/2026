package com.example.domain.billing

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class BillingConfigStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
    }

    private val _configuration = MutableStateFlow(loadConfigInternal())
    val configuration: StateFlow<PlayBillingConfiguration> = _configuration.asStateFlow()

    private fun loadConfigInternal(): PlayBillingConfiguration {
        val raw = prefs.getString(KEY_CONFIG_JSON, null) ?: return PlayBillingConfiguration()
        return runCatching { json.decodeFromString<PlayBillingConfiguration>(raw) }
            .getOrElse { PlayBillingConfiguration() }
    }

    fun currentConfiguration(): PlayBillingConfiguration = _configuration.value

    fun saveConfiguration(config: PlayBillingConfiguration) {
        val cleaned = config.copy(
            subscriptionProductId = config.subscriptionProductId.trim(),
            monthlyProductId = config.monthlyProductId.trim(),
            yearlyProductId = config.yearlyProductId.trim(),
            monthlyBasePlanId = config.monthlyBasePlanId.trim(),
            yearlyBasePlanId = config.yearlyBasePlanId.trim(),
            trialOfferId = config.trialOfferId.trim(),
            updatedAtMs = System.currentTimeMillis(),
        )
        prefs.edit().putString(KEY_CONFIG_JSON, json.encodeToString(cleaned)).apply()
        _configuration.value = cleaned
    }

    fun clearConfiguration() {
        prefs.edit().remove(KEY_CONFIG_JSON).apply()
        _configuration.value = PlayBillingConfiguration()
    }

    fun saveCachedEntitlement(state: SubscriptionEntitlementState) {
        prefs.edit().putString(KEY_ENTITLEMENT_JSON, json.encodeToString(state)).apply()
    }

    fun loadCachedEntitlement(): SubscriptionEntitlementState {
        val raw = prefs.getString(KEY_ENTITLEMENT_JSON, null) ?: return SubscriptionEntitlementState()
        return runCatching { json.decodeFromString<SubscriptionEntitlementState>(raw) }
            .getOrElse { SubscriptionEntitlementState() }
    }

    fun clearCachedEntitlement() {
        prefs.edit().remove(KEY_ENTITLEMENT_JSON).apply()
    }

    companion object {
        private const val PREFS_NAME = "play_billing_store"
        private const val KEY_CONFIG_JSON = "play_billing_config_v1"
        private const val KEY_ENTITLEMENT_JSON = "cached_entitlement_v1"
    }
}
