package com.example.domain.excel

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Xml
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ExcelImageConflictPolicy
import com.example.data.local.entity.ImageDownloadStatus
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.storage.AuthorizedApiHeader
import com.example.data.storage.BackendImageSyncService
import com.example.data.storage.HttpUrlRemoteImageTransport
import com.example.data.storage.ImageResolution
import com.example.data.storage.ImageService
import com.example.data.storage.MediaStorageManager
import com.example.data.storage.RemoteImageBytesResult
import com.example.data.storage.RemoteImageDownloader
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.data.storage.RemoteImageFailureKind
import com.example.data.storage.RemoteImageTransport
import com.example.data.storage.RemoteImageUrlValidator
import com.example.data.storage.StoredImageFiles
import com.example.domain.model.BarcodeFormatType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.apache.poi.hssf.usermodel.HSSFClientAnchor
import org.apache.poi.hssf.usermodel.HSSFPicture
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.DataFormatter
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.math.BigDecimal
import java.net.URI
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream

enum class ImportDuplicatePolicy(val arabicLabel: String) {
    SKIP("تجاهل السجلات المكررة"),
    UPDATE("تحديث المنتجات الموجودة"),
    IMPORT_NEW_ONLY("استيراد المنتجات الجديدة فقط"),
}

enum class ExcelNewBarcodePolicy(val arabicLabel: String) {
    ADD_AS_ALTERNATIVE("إضافة كباركود بديل"),
    SET_AS_PRIMARY_KEEP_OLD("تعيين كأساسي مع إبقاء القديم"),
    IGNORE_NEW_BARCODE("تجاهل الباركود الجديد"),
    SKIP_PRODUCT("تخطي المنتج بالكامل"),
}

enum class ExcelRowConflictType(val arabicLabel: String) {
    NONE("منتج جديد"),
    MATCHED_EXISTING("مطابق دون تعارض"),
    EXISTING_PRODUCT_NEW_BARCODE("باركود جديد لمنتج موجود"),
    FOREIGN_BARCODE_CONFLICT("تعارض: باركود مملوك لمنتج آخر"),
    INTRA_FILE_DUPLICATE("باركود مكرر داخل الملف"),
}

enum class ProductImportField(val arabicLabel: String) {
    IGNORE("تجاهل هذا العمود"),
    INTERNAL_CODE("رقم التعريف (ID)"),
    NAME("اسم المنتج *"),
    PRIMARY_BARCODE("الباركود الرئيسي"),
    EXTRA_BARCODE("باركود إضافي"),
    BARCODE_TYPE("نوع الباركود"),
    IMAGE_URL("رابط صورة المنتج"),
    DESCRIPTION("وصف المنتج"),
    CATEGORY("التصنيف"),
    BASE_PRICE("السعر الأساسي"),
    CURRENCY("العملة"),
    ORIGIN_COUNTRY("بلد المنشأ"),
    MANUFACTURER("اسم المصنع"),
    DEFAULT_QUANTITY("الكمية الافتراضية"),
    NOTES("ملاحظات"),
}

enum class ExcelUrlImageStatus(val arabicLabel: String) {
    NONE("بدون رابط"),
    READY("جاهزة"),
    FAILED("فاشلة"),
}

data class ExtractedExcelImage(
    val id: String,
    val fileName: String,
    val bytes: ByteArray,
    val anchoredRowZeroBased: Int?,
    val anchoredColZeroBased: Int?,
)

data class ParsedSheetData(
    val sheetName: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    val extractedImages: List<ExtractedExcelImage>,
    val hasHeaderRow: Boolean = true,
)

data class ParsedWorkbookResult(
    val fileName: String,
    val fileType: String,
    val sheets: List<ParsedSheetData>,
)

data class ImportValidationIssue(
    val rowNumber: Int,
    val message: String,
    val isWarning: Boolean = false,
)

data class ImportPreviewAnalysis(
    val totalRows: Int,
    val newProductsCount: Int,
    val matchedProductsCount: Int,
    val duplicateRowsCount: Int,
    val newBarcodesOnExistingCount: Int,
    val intraFileDuplicateRowsCount: Int,
    val foreignConflictRowsCount: Int,
    val errorRowsCount: Int,
    val anchoredImagesCount: Int,
    val unanchoredImages: List<ExtractedExcelImage>,
    val issues: List<ImportValidationIssue>,
)

data class ExcelReviewRowDraft(
    val sheetRowZeroBased: Int,
    val displayRowNumber: Int,
    val internalCode: String,
    val productName: String,
    val primaryBarcode: String,
    val extraBarcodes: List<String>,
    val categoryName: String,
    val basePrice: Double,
    val currency: String,
    val originCountry: String,
    val manufacturer: String,
    val defaultQuantity: Double,
    val description: String,
    val notes: String,
    val matchedExistingProductId: Long?,
    val matchedExistingProductName: String? = null,
    val matchedBy: String? = null,
    val conflictType: ExcelRowConflictType = ExcelRowConflictType.NONE,
    val newBarcodesForExisting: List<String> = emptyList(),
    val foreignConflictBarcodes: Map<String, String> = emptyMap(),
    val intraFileDuplicateRows: Map<String, List<Int>> = emptyMap(),
    val conflictDetails: String? = null,
    val newBarcodePolicy: ExcelNewBarcodePolicy = ExcelNewBarcodePolicy.ADD_AS_ALTERNATIVE,
    val images: List<ExtractedExcelImage>,
    val primaryImageId: String? = images.firstOrNull()?.id,
    val skipRow: Boolean = false,
    val validationError: String? = null,
    val imageUrl: String = "",
    val existingProductImagePath: String? = null,
    val existingProductHasImage: Boolean = false,
    val imageConflictPolicy: ExcelImageConflictPolicy = ExcelImageConflictPolicy.KEEP_EXISTING,
    val urlImageStatus: ExcelUrlImageStatus = ExcelUrlImageStatus.NONE,
    val urlPreviewThumbnailPath: String? = null,
    val urlPreviewError: String? = null,
    val imageUrls: List<String> = if (imageUrl.isBlank()) emptyList() else ExcelImportEngine.splitCellImageUrls(imageUrl),
    val explicitBarcodeType: String = "",
) {
    val hasBlockingConflict: Boolean
        get() {
            if (skipRow || validationError != null || newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
                return false
            }
            return when (conflictType) {
                ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT,
                ExcelRowConflictType.INTRA_FILE_DUPLICATE -> {
                    newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE
                }
                else -> false
            }
        }

    fun proposedActionLabel(duplicatePolicy: ImportDuplicatePolicy): String = when {
        validationError != null -> "خطأ في البيانات"
        skipRow || newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT -> "تخطي"
        matchedExistingProductId == null -> "إضافة جديد"
        duplicatePolicy == ImportDuplicatePolicy.IMPORT_NEW_ONLY -> "تخطي (موجود)"
        duplicatePolicy == ImportDuplicatePolicy.UPDATE -> "تحديث المنتج"
        newBarcodesForExisting.isNotEmpty() && newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE -> "تحديث باركود لموجود"
        imageUrl.isNotBlank() && (!existingProductHasImage || imageConflictPolicy != ExcelImageConflictPolicy.KEEP_EXISTING) -> "تحديث الصورة"
        else -> "تخطي"
    }
}

data class ExcelReviewSummaryCounts(
    val totalRows: Int,
    val newProductsCount: Int,
    val matchedProductsCount: Int,
    val needsUpdateCount: Int,
    val newBarcodesOnExistingCount: Int,
    val intraFileDuplicatesCount: Int,
    val foreignConflictsCount: Int,
    val skippedOrErrorCount: Int,
    val unresolvedBlockingCount: Int,
    val urlImagesCount: Int = 0,
    val invalidUrlImagesCount: Int = 0,
    val existingWithImageUrlConflictCount: Int = 0,
)

data class ExcelPreImportReview(
    val rows: List<ExcelReviewRowDraft>,
    val unlinkedImages: List<ExtractedExcelImage>,
    val ignoredImages: List<ExtractedExcelImage> = emptyList(),
    val policy: ImportDuplicatePolicy = ImportDuplicatePolicy.SKIP,
    val defaultCurrency: String = "ر.س",
) {
    fun isRowBlocking(row: ExcelReviewRowDraft): Boolean {
        if (row.skipRow || row.validationError != null || row.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
            return false
        }
        return when (row.conflictType) {
            ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT ->
                row.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE
            ExcelRowConflictType.INTRA_FILE_DUPLICATE -> {
                if (row.newBarcodePolicy == ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE) {
                    false
                } else {
                    row.intraFileDuplicateRows.any { (code, _) ->
                        rows.count { other ->
                            !other.skipRow &&
                                other.validationError == null &&
                                other.newBarcodePolicy != ExcelNewBarcodePolicy.SKIP_PRODUCT &&
                                other.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE &&
                                (other.primaryBarcode == code || code in other.extraBarcodes)
                        } > 1
                    }
                }
            }
            else -> false
        }
    }

    fun computeSummary(): ExcelReviewSummaryCounts {
        var newCount = 0
        var matchedCount = 0
        var updateCount = 0
        var newBarcodesCount = 0
        var intraDupCount = 0
        var foreignCount = 0
        var skippedOrErr = 0
        var blocking = 0

        var urlCount = 0
        var invalidUrlCount = 0
        var existingImageConflicts = 0

        for (r in rows) {
            if (isRowBlocking(r)) blocking++
            if (r.validationError != null || r.skipRow || r.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
                skippedOrErr++
                continue
            }
            if (r.imageUrl.isNotBlank()) {
                urlCount++
                if (r.urlImageStatus == ExcelUrlImageStatus.FAILED) invalidUrlCount++
                if (r.matchedExistingProductId != null && r.existingProductHasImage) {
                    existingImageConflicts++
                }
            }
            if (r.conflictType == ExcelRowConflictType.INTRA_FILE_DUPLICATE) intraDupCount++
            if (r.conflictType == ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT) foreignCount++
            if (r.conflictType == ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE) newBarcodesCount++

            if (r.matchedExistingProductId == null) {
                if (r.conflictType == ExcelRowConflictType.NONE || !isRowBlocking(r)) {
                    newCount++
                }
            } else {
                matchedCount++
                if (policy == ImportDuplicatePolicy.UPDATE) {
                    updateCount++
                }
            }
        }
        return ExcelReviewSummaryCounts(
            totalRows = rows.size,
            newProductsCount = newCount,
            matchedProductsCount = matchedCount,
            needsUpdateCount = updateCount,
            newBarcodesOnExistingCount = newBarcodesCount,
            intraFileDuplicatesCount = intraDupCount,
            foreignConflictsCount = foreignCount,
            skippedOrErrorCount = skippedOrErr,
            unresolvedBlockingCount = blocking,
            urlImagesCount = urlCount,
            invalidUrlImagesCount = invalidUrlCount,
            existingWithImageUrlConflictCount = existingImageConflicts,
        )
    }
}

data class ExcelImportFinalReport(
    val insertedCount: Int,
    val updatedCount: Int,
    val skippedCount: Int,
    val errorCount: Int,
    val barcodesImportedCount: Int,
    val autoLinkedImagesCount: Int,
    val unlinkedImages: List<ExtractedExcelImage>,
    val importedProductIdsByRow: Map<Int, Long>,
    val issues: List<ImportValidationIssue>,
    val imageDownloadSuccessCount: Int = 0,
    val imageDownloadFailedCount: Int = 0,
    val imageDownloadSkippedCount: Int = 0,
    val downloadBatchId: String = "",
    val imageDownloadRecords: List<ProductImageDownloadEntity> = emptyList(),
    val failedImageDownloads: List<ProductImageDownloadEntity> = emptyList(),
    val totalProductsProcessed: Int = insertedCount + updatedCount + skippedCount,
    val totalImageUrlsCount: Int = imageDownloadSuccessCount + imageDownloadFailedCount + imageDownloadSkippedCount,
    val verifiedDownloadedCount: Int = imageDownloadSuccessCount,
    val linkedImagesCount: Int = autoLinkedImagesCount,
    val productsWithoutGtinCount: Int = 0,
)

data class RetryImageDownloadsResult(
    val totalAttempted: Int,
    val succeededCount: Int,
    val failedCount: Int,
    val skippedCount: Int,
    val updatedRecords: List<ProductImageDownloadEntity>,
)

data class UrlImagePreviewProbeResult(
    val url: String,
    val status: ExcelUrlImageStatus,
    val previewThumbnailPath: String? = null,
    val errorReason: String? = null,
)

data class OfficialApiImageConfig(
    val endpointOrTemplate: String,
    val authHeaderName: String = "Authorization",
    val authHeaderValue: String = "",
)

data class LocalFolderImageCandidate(
    val fileName: String,
    val openBytes: suspend () -> ByteArray?,
)

data class FolderImageImportResult(
    val scannedFilesCount: Int,
    val matchedCount: Int,
    val succeededCount: Int,
    val failedCount: Int,
    val updatedRecords: List<ProductImageDownloadEntity>,
    val errors: List<String> = emptyList(),
    val extraLinkedCount: Int = 0,
    val unmatchedFiles: List<String> = emptyList(),
)

data class SallaCatalogSyncReport(
    val fetchedProductsCount: Int,
    val matchedProductsCount: Int,
    val createdProductsCount: Int,
    val linkedImagesCount: Int,
    val failedImagesCount: Int,
    val errors: List<String> = emptyList(),
)

class ExcelImportConflictException(message: String) : IllegalStateException(message)

class ExcelImportEngine(
    private val context: Context,
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val remoteDownloader: RemoteImageDownloader = RemoteImageDownloader(mediaStorage),
    private val backendSyncService: BackendImageSyncService = BackendImageSyncService(),
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val barcodeService: com.example.domain.barcode.BarcodeService? = null,
) {
    private val productWriteMutexes = ConcurrentHashMap<Long, Mutex>()

    private fun mutexForProduct(productId: Long): Mutex =
        productWriteMutexes.getOrPut(productId) { Mutex() }

    suspend fun parseUri(uri: Uri, fileNameHint: String = ""): Result<ParsedWorkbookResult> =
        withContext(Dispatchers.IO) {
            val trace = errorMonitor?.operationLogger?.startOperation(
                screenName = ScreenNames.EXCEL_IMPORT,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "قراءة ملف Excel للاستيراد",
                initialStage = "فتح الملف من URI",
            )
            try {
                val resolvedName = fileNameHint.ifBlank { queryDisplayName(uri) }
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: run {
                        val err = IllegalStateException("تعذر فتح الملف المختار")
                        val rec = errorMonitor?.recordError(err, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "قراءة ملف Excel من URI", linkedOperationId = trace?.operationId.orEmpty())
                        trace?.fail(err.message.orEmpty(), linkedErrorId = rec?.errorId.orEmpty())
                        return@withContext Result.failure(err)
                    }
                trace?.stage("تحليل أوراق العمل ($resolvedName)")
                val res = parseBytes(bytes, resolvedName)
                res.onSuccess { wb ->
                    trace?.succeed("تم تحليل ${wb.fileType}: ${wb.sheets.size} ورقة عمل")
                }.onFailure { err ->
                    trace?.fail(err.message ?: "تعذر تحليل ملف Excel")
                }
                res
            } catch (c: CancellationException) {
                trace?.cancel("تم إلغاء قراءة ملف Excel")
                throw c
            } catch (e: Exception) {
                val rec = errorMonitor?.recordError(e, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "قراءة ملف Excel من URI", linkedOperationId = trace?.operationId.orEmpty())
                trace?.fail(e.message ?: "خطأ قراءة ملف Excel", linkedErrorId = rec?.errorId.orEmpty())
                Result.failure(e)
            }
        }

    fun parseBytes(bytes: ByteArray, fileName: String): Result<ParsedWorkbookResult> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.EXCEL_IMPORT,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "تحليل مصنف Excel ($fileName)",
            initialStage = "كشف نوع المصنف واستخراج الصفوف",
        )
        return try {
            val lower = fileName.lowercase(Locale.ROOT)
            val isZip = bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
            val isOle2 = bytes.size >= 8 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()

            val sheets = when {
                lower.endsWith(".xlsx") || isZip -> parseXlsx(bytes)
                lower.endsWith(".xls") || isOle2 -> parseXls(bytes)
                else -> listOf(parseCsv(bytes))
            }
            val typeLabel = when {
                lower.endsWith(".xlsx") || isZip -> "XLSX"
                lower.endsWith(".xls") || isOle2 -> "XLS"
                else -> "CSV"
            }
            trace?.succeed("تمت قراءة $typeLabel (${sheets.size} ورقة)")
            Result.success(ParsedWorkbookResult(fileName, typeLabel, sheets))
        } catch (e: Exception) {
            val rec = errorMonitor?.recordError(e, ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "تحليل بيانات ملف Excel ($fileName)", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(e.message ?: "تعذر تحليل ملف Excel", linkedErrorId = rec?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    fun suggestMappings(headers: List<String>): Map<Int, ProductImportField> =
        suggestMappings(headers, emptyList())

    fun suggestMappings(
        headers: List<String>,
        sampleRows: List<List<String>>,
    ): Map<Int, ProductImportField> {
        val map = mutableMapOf<Int, ProductImportField>()
        headers.forEachIndexed { idx, rawHeader ->
            val h = rawHeader.trim().lowercase(Locale.ROOT)
            val cleanNoPunct = h.trim('.', ':', ' ', '\t')
            val isRowSerialColumn = cleanNoPunct in setOf(
                "no", "no.", "#", "row", "serial", "s.n", "sn", "الرقم", "م", "ت", "التسلسل", "رقم التسلسل",
            )
            val field = when {
                isRowSerialColumn -> ProductImportField.IGNORE
                h.contains("نوع الباركود") || h.contains("barcode_type") || h.contains("barcode type") || h.contains("barcodetype") || h == "format" || h.contains("صيغة الباركود") -> ProductImportField.BARCODE_TYPE
                h.contains("باركودات إضافية") || h.contains("باركود إضافي") || (h.contains("باركود") && h.contains("إضاف")) || h.contains("extra") || h.contains("barcode2") || h.contains("barcode 2") || h.contains("alt_barcode") -> ProductImportField.EXTRA_BARCODE
                h.contains("gtin") || h.contains("ean") || h.contains("upc") || h.contains("باركود") || h.contains("barcode") -> ProductImportField.PRIMARY_BARCODE
                (h.contains("رابط") && (h.contains("صور") || h.contains("img") || h.contains("image") || h.contains("url") || h.contains("photo") || h.contains("pic"))) ||
                    h.contains("image") || h.contains("img_url") || h.contains("imgurl") || h.contains("photo") || h.contains("picture") || h.contains("thumbnail") || h == "img" || h == "pic" || h == "صورة" || h.contains("صورة المنتج") || h.contains("صور المنتج") || h.contains("رابط الصورة") -> ProductImportField.IMAGE_URL
                h.contains("اسم") || h.contains("أسم") || h.contains("product") || h.contains("name") || h.contains("الصنف") -> ProductImportField.NAME
                h == "id" || h.contains("معرف") || h.contains("رمز") || h.contains("code") || h.contains("sku") -> ProductImportField.INTERNAL_CODE
                h.contains("وصف") || h.contains("desc") -> ProductImportField.DESCRIPTION
                h.contains("تصنيف") || h.contains("فئة") || h.contains("category") -> ProductImportField.CATEGORY
                h.contains("سعر") || h.contains("price") -> ProductImportField.BASE_PRICE
                h.contains("عملة") || h.contains("currency") -> ProductImportField.CURRENCY
                h.contains("منشأ") || h.contains("بلد") || h.contains("origin") || h.contains("country") -> ProductImportField.ORIGIN_COUNTRY
                h.contains("مصنع") || h.contains("شركة") || h.contains("brand") || h.contains("manufacturer") -> ProductImportField.MANUFACTURER
                h.contains("كمية") || h.contains("qty") || h.contains("quantity") -> ProductImportField.DEFAULT_QUANTITY
                h.contains("ملاحظ") || h.contains("note") -> ProductImportField.NOTES
                else -> ProductImportField.IGNORE
            }
            map[idx] = field
        }

        // Disambiguate when multiple columns matched PRIMARY_BARCODE (e.g. Salla Excel has empty 'الباركود' + populated 'GTIN')
        val primaryCandidates = map.entries.filter { it.value == ProductImportField.PRIMARY_BARCODE }.map { it.key }
        if (primaryCandidates.size > 1) {
            val gtinCandidate = primaryCandidates.firstOrNull { headers.getOrNull(it)?.contains("gtin", ignoreCase = true) == true }
            val chosenCol = if (sampleRows.isNotEmpty()) {
                primaryCandidates.maxByOrNull { col ->
                    val nonEmpty = sampleRows.count { row -> row.getOrNull(col)?.trim()?.isNotEmpty() == true }
                    val bonus = if (col == gtinCandidate) 1 else 0
                    nonEmpty * 10 + bonus
                }
            } else {
                gtinCandidate ?: primaryCandidates.first()
            }
            if (chosenCol != null) {
                primaryCandidates.filter { it != chosenCol }.forEach { otherCol ->
                    val hasSampleValues = sampleRows.any { row -> row.getOrNull(otherCol)?.trim()?.isNotEmpty() == true }
                    map[otherCol] = if (hasSampleValues) ProductImportField.EXTRA_BARCODE else ProductImportField.IGNORE
                }
            }
        }
        return map
    }

    suspend fun analyzeBeforeImport(
        sheet: ParsedSheetData,
        mappings: Map<Int, ProductImportField>,
        hasHeaderRow: Boolean,
    ): ImportPreviewAnalysis = withContext(Dispatchers.IO) {
        val review = buildPreImportReviewDraft(
            sheet = sheet,
            mappings = mappings,
            hasHeaderRow = hasHeaderRow,
            policy = ImportDuplicatePolicy.SKIP,
        )
        val dataStartRow = if (hasHeaderRow) 1 else 0
        val maxRowIdx = sheet.rows.lastIndex
        val anchored = sheet.extractedImages.filter {
            val r = it.anchoredRowZeroBased
            r != null && r in dataStartRow..maxRowIdx
        }
        val unanchored = sheet.extractedImages.filter { img -> anchored.none { it.id == img.id } }

        val issues = mutableListOf<ImportValidationIssue>()
        if (mappings.entries.none { it.value == ProductImportField.NAME }) {
            issues.add(ImportValidationIssue(0, "لم يتم تحديد عمود اسم المنتج", isWarning = false))
        }

        var newCount = 0
        var matchedCount = 0
        var dupCount = 0
        var newBarcodesOnExistingCount = 0
        var intraDupCount = 0
        var foreignConflictCount = 0
        var errCount = 0

        for (r in review.rows) {
            if (r.validationError != null) {
                errCount++
                if (issues.size < 120) {
                    issues.add(ImportValidationIssue(r.displayRowNumber, r.validationError, isWarning = false))
                }
                continue
            }
            for (b in (listOf(r.primaryBarcode) + r.extraBarcodes).filter { it.isNotEmpty() }) {
                if (b.contains("E+", ignoreCase = true)) {
                    if (issues.size < 120) {
                        issues.add(
                            ImportValidationIssue(
                                r.displayRowNumber,
                                "الصف ${r.displayRowNumber}: الباركود ($b) بصيغة علمية — يُنصح بتحويل العمود إلى نص في Excel",
                                isWarning = true,
                            ),
                        )
                    }
                }
            }
            when (r.conflictType) {
                ExcelRowConflictType.NONE -> newCount++
                ExcelRowConflictType.MATCHED_EXISTING -> {
                    matchedCount++
                    dupCount++
                }
                ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE -> {
                    matchedCount++
                    newBarcodesOnExistingCount++
                    dupCount++
                    if (issues.size < 120 && r.conflictDetails != null) {
                        issues.add(ImportValidationIssue(r.displayRowNumber, r.conflictDetails, isWarning = true))
                    }
                }
                ExcelRowConflictType.INTRA_FILE_DUPLICATE -> {
                    intraDupCount++
                    dupCount++
                    if (issues.size < 120 && r.conflictDetails != null) {
                        issues.add(ImportValidationIssue(r.displayRowNumber, r.conflictDetails, isWarning = false))
                    }
                }
                ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT -> {
                    foreignConflictCount++
                    dupCount++
                    if (issues.size < 120 && r.conflictDetails != null) {
                        issues.add(ImportValidationIssue(r.displayRowNumber, r.conflictDetails, isWarning = false))
                    }
                }
            }
        }

        ImportPreviewAnalysis(
            totalRows = review.rows.size,
            newProductsCount = newCount,
            matchedProductsCount = matchedCount,
            duplicateRowsCount = dupCount,
            newBarcodesOnExistingCount = newBarcodesOnExistingCount,
            intraFileDuplicateRowsCount = intraDupCount,
            foreignConflictRowsCount = foreignConflictCount,
            errorRowsCount = errCount,
            anchoredImagesCount = anchored.size,
            unanchoredImages = unanchored,
            issues = issues,
        )
    }

    /**
     * Builds an editable pre-import review classifying every row for:
     * - Existing product matches (by internalCode or barcode)
     * - New barcodes discovered for an existing product
     * - Foreign barcode ownership conflicts (blocked by default)
     * - Intra-file duplicate barcodes with exact row numbers
     * - Row-anchored multiple images and unlinked images
     */
    suspend fun buildPreImportReviewDraft(
        sheet: ParsedSheetData,
        mappings: Map<Int, ProductImportField>,
        hasHeaderRow: Boolean,
        policy: ImportDuplicatePolicy,
        defaultCurrency: String = "ر.س",
    ): ExcelPreImportReview = withContext(Dispatchers.IO) {
        val dataStartRowZeroBased = if (hasHeaderRow) 1 else 0
        val dataRows = if (hasHeaderRow && sheet.rows.isNotEmpty()) sheet.rows.drop(1) else sheet.rows

        val nameCol = mappings.entries.firstOrNull { it.value == ProductImportField.NAME }?.key
        val idCol = mappings.entries.firstOrNull { it.value == ProductImportField.INTERNAL_CODE }?.key
        val primaryBarcodeCols = mappings.entries.filter { it.value == ProductImportField.PRIMARY_BARCODE }.map { it.key }
        val extraBarcodeCols = mappings.entries.filter { it.value == ProductImportField.EXTRA_BARCODE }.map { it.key }
        val barcodeTypeCol = mappings.entries.firstOrNull { it.value == ProductImportField.BARCODE_TYPE }?.key
        val imageUrlCols = mappings.entries.filter { it.value == ProductImportField.IMAGE_URL }.map { it.key }
        val descCol = mappings.entries.firstOrNull { it.value == ProductImportField.DESCRIPTION }?.key
        val catCol = mappings.entries.firstOrNull { it.value == ProductImportField.CATEGORY }?.key
        val priceCol = mappings.entries.firstOrNull { it.value == ProductImportField.BASE_PRICE }?.key
        val currencyCol = mappings.entries.firstOrNull { it.value == ProductImportField.CURRENCY }?.key
        val originCol = mappings.entries.firstOrNull { it.value == ProductImportField.ORIGIN_COUNTRY }?.key
        val mfgCol = mappings.entries.firstOrNull { it.value == ProductImportField.MANUFACTURER }?.key
        val qtyCol = mappings.entries.firstOrNull { it.value == ProductImportField.DEFAULT_QUANTITY }?.key
        val notesCol = mappings.entries.firstOrNull { it.value == ProductImportField.NOTES }?.key

        val existingProducts = db.productDao().getAllProductsWithDetailsOnce()
        val productsById = existingProducts.associateBy { it.product.id }
        val productsByInternalCode = existingProducts
            .filter { it.product.internalCode.isNotBlank() }
            .associateBy { it.product.internalCode.trim().uppercase(Locale.ROOT) }
        val existingBarcodeOwner = db.productDao().getAllBarcodesOnce()
            .associateBy { it.barcodeValue }

        val imagesByRowZeroBased = mutableMapOf<Int, MutableList<ExtractedExcelImage>>()
        val unlinkedImages = mutableListOf<ExtractedExcelImage>()
        for (img in sheet.extractedImages) {
            val anchorRow = img.anchoredRowZeroBased
            if (anchorRow != null && anchorRow >= dataStartRowZeroBased && anchorRow < sheet.rows.size) {
                imagesByRowZeroBased.getOrPut(anchorRow) { mutableListOf() }.add(img)
            } else {
                unlinkedImages.add(img)
            }
        }
        imagesByRowZeroBased.values.forEach { list ->
            list.sortBy { it.anchoredColZeroBased ?: Int.MAX_VALUE }
        }

        // First pass: collect intra-file barcode occurrences with 1-based Excel row numbers
        val fileRowsPerBarcode = mutableMapOf<String, MutableList<Int>>()
        val parsedRowValues = dataRows.mapIndexed { idx, row ->
            val sheetRowZeroBased = idx + dataStartRowZeroBased
            val displayRow = sheetRowZeroBased + 1
            val name = nameCol?.let { row.getOrNull(it)?.trim() }.orEmpty()
            val primaryCandidates = primaryBarcodeCols
                .mapNotNull { col -> row.getOrNull(col)?.let(::normalizeBarcodeCellValue)?.takeIf { it.isNotEmpty() } }
            val primaryBarcode = primaryCandidates.firstOrNull().orEmpty()
            val secondaryFromPrimaryCols = primaryCandidates.drop(1)
            val extraBarcodes = (secondaryFromPrimaryCols + extraBarcodeCols.flatMap { col ->
                row.getOrNull(col)?.split(',', ';', '|', '\n').orEmpty()
                    .map(::normalizeBarcodeCellValue)
                    .filter { it.isNotEmpty() }
            }).filter { it.isNotEmpty() && it != primaryBarcode }.distinct()
            if (name.isNotBlank()) {
                val codesInRow = buildList {
                    if (primaryBarcode.isNotEmpty()) add(primaryBarcode)
                    addAll(extraBarcodes)
                }.distinct()
                codesInRow.forEach { code ->
                    fileRowsPerBarcode.getOrPut(code) { mutableListOf() }.add(displayRow)
                }
            }
            Triple(sheetRowZeroBased, row, Triple(name, primaryBarcode, extraBarcodes))
        }

        val draftRows = parsedRowValues.map { (sheetRowZeroBased, row, extracted) ->
            val displayRow = sheetRowZeroBased + 1
            val (name, primaryBarcode, extraBarcodes) = extracted
            val internalCode = idCol?.let { row.getOrNull(it)?.trim() }.orEmpty()
            val rowImgs = imagesByRowZeroBased[sheetRowZeroBased].orEmpty()

            if (name.isBlank() && rowImgs.isNotEmpty()) {
                unlinkedImages.addAll(rowImgs)
            }

            val allCodes = buildList {
                if (primaryBarcode.isNotEmpty()) add(primaryBarcode)
                addAll(extraBarcodes)
            }.distinct()

            val matchedByInternal = internalCode.takeIf { it.isNotBlank() }
                ?.let { productsByInternalCode[it.uppercase(Locale.ROOT)] }
            val matchedByBarcodes = allCodes.mapNotNull { code ->
                existingBarcodeOwner[code]?.let { b -> code to productsById[b.productId] }
            }.filter { it.second != null }

            val targetProduct = matchedByInternal ?: matchedByBarcodes.firstOrNull()?.second
            val matchedByLabel = when {
                matchedByInternal != null -> "رقم التعريف ($internalCode)"
                matchedByBarcodes.isNotEmpty() -> "الباركود (${matchedByBarcodes.first().first})"
                else -> null
            }

            // Detect barcodes owned by a DIFFERENT product
            val foreignMap = mutableMapOf<String, String>()
            for (code in allCodes) {
                val owner = existingBarcodeOwner[code]
                if (owner != null && (targetProduct == null || owner.productId != targetProduct.product.id)) {
                    val ownerName = productsById[owner.productId]?.product?.let { "${it.name} [${it.internalCode}]" }
                        ?: "#${owner.productId}"
                    foreignMap[code] = ownerName
                }
            }

            // Detect intra-file duplicates
            val intraDupMap = mutableMapOf<String, List<Int>>()
            for (code in allCodes) {
                val rowsWithCode = fileRowsPerBarcode[code].orEmpty()
                if (rowsWithCode.size > 1) {
                    val otherRows = rowsWithCode.filter { it != displayRow }
                    if (otherRows.isNotEmpty()) {
                        intraDupMap[code] = rowsWithCode
                    }
                }
            }

            // Detect new barcodes not yet in DB that belong to matched product row
            val newBarcodes = if (targetProduct != null) {
                allCodes.filter { code -> existingBarcodeOwner[code] == null && !foreignMap.containsKey(code) }
            } else {
                emptyList()
            }

            val isSubsequentIntraDup = intraDupMap.any { (_, rowsList) -> rowsList.firstOrNull() != displayRow }

            val conflictType = when {
                name.isBlank() -> ExcelRowConflictType.NONE
                foreignMap.isNotEmpty() -> ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT
                intraDupMap.isNotEmpty() && isSubsequentIntraDup -> ExcelRowConflictType.INTRA_FILE_DUPLICATE
                targetProduct != null && newBarcodes.isNotEmpty() -> ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE
                targetProduct != null -> ExcelRowConflictType.MATCHED_EXISTING
                intraDupMap.isNotEmpty() -> ExcelRowConflictType.INTRA_FILE_DUPLICATE
                else -> ExcelRowConflictType.NONE
            }

            val conflictDetails = when (conflictType) {
                ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT -> {
                    val desc = foreignMap.entries.joinToString("؛ ") { (c, owner) -> "$c ⇐ $owner" }
                    "صف $displayRow: الباركود ($desc) مرتبط مسبقاً بمنتج آخر ولا يمكن نقله تلقائياً"
                }
                ExcelRowConflictType.INTRA_FILE_DUPLICATE -> {
                    val desc = intraDupMap.entries.joinToString("؛ ") { (c, rowsList) ->
                        "$c في الصفوف ${rowsList.joinToString(", ")}"
                    }
                    "صف $displayRow: تكرار باركود داخل الملف ($desc)"
                }
                ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE -> {
                    "صف $displayRow: منتج موجود (${targetProduct?.product?.name}) ومعه باركودات جديدة (${newBarcodes.joinToString(", ")})"
                }
                ExcelRowConflictType.MATCHED_EXISTING -> {
                    "صف $displayRow: مطابق للمنتج (${targetProduct?.product?.name})"
                }
                ExcelRowConflictType.NONE -> null
            }

            val rawImageUrls = imageUrlCols
                .flatMap { col -> splitCellImageUrls(row.getOrNull(col).orEmpty()) }
                .distinct()
            val rawImageUrl = rawImageUrls.joinToString("\n")
            val urlValidations = rawImageUrls.map { RemoteImageUrlValidator.validateSyntax(it) }
            val firstInvalidUrl = urlValidations.firstOrNull { !it.isValid }
            val urlStatus = when {
                rawImageUrls.isEmpty() -> ExcelUrlImageStatus.NONE
                firstInvalidUrl == null -> ExcelUrlImageStatus.READY
                else -> ExcelUrlImageStatus.FAILED
            }
            val existingImgResolution = ImageService.resolveProductImageStateless(
                targetProduct?.primaryImage,
                preferThumbnail = true,
            )
            val existingPrimaryImgPath = (existingImgResolution as? ImageResolution.Available)?.file?.absolutePath
            val existingHasImage = existingPrimaryImgPath != null
            val defaultImgConflictPolicy = if (existingHasImage) {
                ExcelImageConflictPolicy.KEEP_EXISTING
            } else {
                ExcelImageConflictPolicy.REPLACE_PRIMARY
            }

            ExcelReviewRowDraft(
                sheetRowZeroBased = sheetRowZeroBased,
                displayRowNumber = displayRow,
                internalCode = internalCode,
                productName = name,
                primaryBarcode = primaryBarcode,
                extraBarcodes = extraBarcodes,
                categoryName = catCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
                basePrice = priceCol?.let { row.getOrNull(it)?.trim()?.replace(",", "")?.toDoubleOrNull() } ?: 0.0,
                currency = currencyCol?.let { row.getOrNull(it)?.trim() }?.ifBlank { defaultCurrency } ?: defaultCurrency,
                originCountry = originCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
                manufacturer = mfgCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
                defaultQuantity = qtyCol?.let { row.getOrNull(it)?.trim()?.replace(",", "")?.toDoubleOrNull() }?.coerceAtLeast(0.0) ?: 1.0,
                description = descCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
                notes = notesCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
                matchedExistingProductId = targetProduct?.product?.id,
                matchedExistingProductName = targetProduct?.product?.name,
                matchedBy = matchedByLabel,
                conflictType = conflictType,
                newBarcodesForExisting = newBarcodes,
                foreignConflictBarcodes = foreignMap,
                intraFileDuplicateRows = intraDupMap,
                conflictDetails = conflictDetails,
                newBarcodePolicy = ExcelNewBarcodePolicy.ADD_AS_ALTERNATIVE,
                images = if (name.isBlank()) emptyList() else rowImgs,
                primaryImageId = rowImgs.firstOrNull()?.id,
                validationError = if (name.isBlank()) "الصف $displayRow: اسم المنتج فارغ" else null,
                imageUrl = rawImageUrl,
                existingProductImagePath = existingPrimaryImgPath,
                existingProductHasImage = existingHasImage,
                imageConflictPolicy = defaultImgConflictPolicy,
                urlImageStatus = urlStatus,
                urlPreviewError = firstInvalidUrl?.errorReason,
                imageUrls = rawImageUrls,
                explicitBarcodeType = barcodeTypeCol?.let { row.getOrNull(it)?.trim() }.orEmpty(),
            )
        }

        ExcelPreImportReview(
            rows = draftRows,
            unlinkedImages = unlinkedImages,
            policy = policy,
            defaultCurrency = defaultCurrency,
        )
    }

    /**
     * Probes a single URL during pre-import review to verify downloadability and generate a cached preview thumbnail.
     */
    suspend fun probeUrlForReview(rawUrl: String): UrlImagePreviewProbeResult = withContext(Dispatchers.IO) {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return@withContext UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.NONE)
        }
        val syntax = RemoteImageUrlValidator.validateSyntax(trimmed)
        if (!syntax.isValid) {
            return@withContext UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.FAILED, null, syntax.errorReason)
        }
        when (val res = remoteDownloader.downloadAndVerifyBytes(trimmed)) {
            is com.example.data.storage.RemoteImageBytesResult.Failure -> {
                return@withContext UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.FAILED, null, res.reason)
            }
            is RemoteImageBytesResult.Success -> {
                val previewDir = File(context.cacheDir, "url_previews").apply { mkdirs() }
                val urlHash = RemoteImageDownloader.sha256Hex(trimmed.toByteArray()).take(24)
                val previewFile = File(previewDir, "prev_${urlHash}.${res.detectedExtension}")
                return@withContext try {
                    FileOutputStream(previewFile).use { it.write(res.bytes) }
                    UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.READY, previewFile.absolutePath, null)
                } catch (_: Exception) {
                    UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.READY, null, null)
                }
            }
        }
        UrlImagePreviewProbeResult(trimmed, ExcelUrlImageStatus.FAILED, null, "تعذر فحص الصورة")
    }

    /**
     * Executes reviewed import in two safe phases:
     * 1) Atomic Room database transaction for all products, barcodes, categories, embedded images, and queued URL image tasks.
     *    Any exception in Phase 1 rolls back 100% of DB & disk writes before rethrowing.
     * 2) Concurrent batched remote image download + verification + local storage + ProductID linking outside the DB lock.
     *    Individual image download failures NEVER halt or roll back imported products/barcodes and remain retryable.
     */
    suspend fun commitReviewedImport(
        review: ExcelPreImportReview,
        onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
        beforeCommitHook: suspend () -> Unit = {},
        onImageDownloadProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
    ): ExcelImportFinalReport = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.EXCEL_IMPORT,
            moduleName = DiagnosticModules.EXCEL,
            operationName = "استيراد منتجات وصور من Excel (${review.rows.size} صف)",
            initialStage = "فحص تعارضات الباركود",
        )
        val blockingRows = review.rows.filter { row ->
            if (row.skipRow || row.validationError != null || row.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
                return@filter false
            }
            when (row.conflictType) {
                ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT ->
                    row.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE
                ExcelRowConflictType.INTRA_FILE_DUPLICATE -> {
                    if (row.newBarcodePolicy == ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE) {
                        false
                    } else {
                        row.intraFileDuplicateRows.any { (code, _) ->
                            review.rows.count { other ->
                                !other.skipRow &&
                                    other.validationError == null &&
                                    other.newBarcodePolicy != ExcelNewBarcodePolicy.SKIP_PRODUCT &&
                                    other.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE &&
                                    (other.primaryBarcode == code || code in other.extraBarcodes)
                            } > 1
                        }
                    }
                }
                else -> false
            }
        }
        if (blockingRows.isNotEmpty()) {
            val first = blockingRows.first()
            val conflictMsg = "يوجد ${blockingRows.size} صفاً يحتوي على تعارض باركود غير محلول (مثال: ${first.conflictDetails ?: "صف ${first.displayRowNumber}"}). يُرجى معالجته أولاً."
            trace?.warn(conflictMsg)
            throw ExcelImportConflictException(conflictMsg)
        }

        val total = review.rows.size
        val productDao = db.productDao()
        val categoryDao = db.categoryDao()
        val savedDefaultBarcodeFormat = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
            db.settingsDao().getSettingsOnce()?.defaultBarcodeType,
        ) ?: BarcodeFormatType.CODE_128
        val importedBarcodePrewarms = mutableListOf<Triple<Long, String, BarcodeFormatType>>()

        val existingBarcodeMap = productDao.getAllBarcodesOnce()
            .associateBy { it.barcodeValue }
            .toMutableMap()
        val existingCategories = categoryDao.getAllCategoriesOnce()
            .associate { it.name to it.id }
            .toMutableMap()

        var inserted = 0
        var updated = 0
        var skipped = 0
        var errors = 0
        var barcodesCount = 0
        var embeddedImagesCount = 0
        val issues = mutableListOf<ImportValidationIssue>()
        val productIdByRowZeroBased = mutableMapOf<Int, Long>()
        val remainingUnlinked = review.unlinkedImages.toMutableList()
        val writtenImagePaths = mutableListOf<String>()
        val downloadBatchId = UUID.randomUUID().toString()
        val queuedDownloads = mutableListOf<ProductImageDownloadEntity>()
        val urlOnlyExistingDownloadIds = mutableSetOf<Long>()

        try {
            trace?.stage("حفظ المنتجات والباركودات في معاملة SQLite", "صفوف=$total")
            db.withTransaction {
                val now = System.currentTimeMillis()
                review.rows.forEachIndexed { idx, row ->
                    if (row.validationError != null || row.productName.isBlank()) {
                        errors++
                        if (issues.size < 200) {
                            issues.add(
                                ImportValidationIssue(
                                    row.displayRowNumber,
                                    row.validationError ?: "الصف ${row.displayRowNumber}: اسم المنتج فارغ",
                                ),
                            )
                        }
                        if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                            onProgress(idx + 1, total)
                        }
                        return@forEachIndexed
                    }
                    if (row.skipRow || row.newBarcodePolicy == ExcelNewBarcodePolicy.SKIP_PRODUCT) {
                        skipped++
                        if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                            onProgress(idx + 1, total)
                        }
                        return@forEachIndexed
                    }

                    val allBarcodesForRow = buildList {
                        if (row.primaryBarcode.isNotEmpty()) add(row.primaryBarcode to true)
                        row.extraBarcodes.forEach { add(it to false) }
                    }
                    val lookupBarcodes = if (row.newBarcodePolicy == ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE) {
                        allBarcodesForRow.filterNot { (code, _) -> row.foreignConflictBarcodes.containsKey(code) }
                    } else {
                        allBarcodesForRow
                    }
                    val matchedExistingId = row.matchedExistingProductId
                        ?: lookupBarcodes.firstNotNullOfOrNull { (code, _) -> existingBarcodeMap[code]?.productId }

                    val hasNewBarcodesForExisting = matchedExistingId != null &&
                        row.newBarcodesForExisting.isNotEmpty() &&
                        row.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE

                    val categoryId = if (row.categoryName.isNotEmpty()) {
                        existingCategories[row.categoryName] ?: categoryDao.insertCategory(
                            CategoryEntity(name = row.categoryName),
                        ).also { existingCategories[row.categoryName] = it }
                    } else null

                    val existingDetails = matchedExistingId?.let { productDao.getProductWithDetails(it) }
                    val existingProduct = existingDetails?.product
                    val existingProductHasValidImg = existingDetails?.images?.any { im ->
                        ImageService.resolveProductImageStateless(im, preferThumbnail = true) is ImageResolution.Available
                    } == true

                    val rowUrlList = (row.imageUrls.ifEmpty { splitCellImageUrls(row.imageUrl) }).distinct()

                    val wantsUrlDownloadForRow = rowUrlList.isNotEmpty() && (
                        matchedExistingId == null ||
                            (review.policy != ImportDuplicatePolicy.IMPORT_NEW_ONLY &&
                                (!existingProductHasValidImg || row.imageConflictPolicy != ExcelImageConflictPolicy.KEEP_EXISTING))
                        )

                    val productId: Long = if (matchedExistingId != null) {
                        if (existingProduct != null) {
                            if (review.policy == ImportDuplicatePolicy.IMPORT_NEW_ONLY) {
                                skipped++
                                productIdByRowZeroBased[row.sheetRowZeroBased] = existingProduct.id
                                if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                                    onProgress(idx + 1, total)
                                }
                                return@forEachIndexed
                            } else if (review.policy == ImportDuplicatePolicy.UPDATE) {
                                productDao.updateProduct(
                                    existingProduct.copy(
                                        internalCode = row.internalCode.ifBlank { existingProduct.internalCode },
                                        name = row.productName,
                                        description = row.description.ifBlank { existingProduct.description },
                                        categoryId = categoryId ?: existingProduct.categoryId,
                                        categoryName = row.categoryName.ifBlank { existingProduct.categoryName },
                                        basePrice = row.basePrice,
                                        currency = row.currency,
                                        originCountry = row.originCountry.ifBlank { existingProduct.originCountry },
                                        manufacturer = row.manufacturer.ifBlank { existingProduct.manufacturer },
                                        defaultQuantity = row.defaultQuantity,
                                        notes = row.notes.ifBlank { existingProduct.notes },
                                        updatedAt = now,
                                    ),
                                )
                                updated++
                            } else if (hasNewBarcodesForExisting) {
                                // Product matched with new barcodes; apply new barcodes cleanly without overwriting core fields
                                updated++
                            } else if (!wantsUrlDownloadForRow) {
                                skipped++
                                productIdByRowZeroBased[row.sheetRowZeroBased] = existingProduct.id
                                // Record SKIPPED status for each URL if URL existed but policy kept old image
                                if (rowUrlList.isNotEmpty() && existingProductHasValidImg) {
                                    rowUrlList.forEach { singleUrl ->
                                        val rec = ProductImageDownloadEntity(
                                            batchId = downloadBatchId,
                                            productId = existingProduct.id,
                                            barcode = row.primaryBarcode.ifBlank { row.extraBarcodes.firstOrNull().orEmpty() },
                                            productName = existingProduct.name,
                                            sourceUrl = singleUrl,
                                            status = ImageDownloadStatus.SKIPPED.name,
                                            failureReason = "تم الإبقاء على الصورة الحالية للمنتج حسب السياسة المختارة",
                                            imagePolicy = row.imageConflictPolicy.name,
                                            excelRowNumber = row.displayRowNumber,
                                            createdAt = now,
                                            updatedAt = now,
                                        )
                                        val rid = productDao.insertImageDownload(rec)
                                        queuedDownloads.add(rec.copy(id = rid))
                                    }
                                }
                                if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                                    onProgress(idx + 1, total)
                                }
                                return@forEachIndexed
                            } else {
                                // Existing product untouched otherwise, but pending URL image download will run in Phase 2;
                                // updated vs skipped will be finalized based on download outcome.
                            }
                            existingProduct.id
                        } else {
                            skipped++
                            if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                                onProgress(idx + 1, total)
                            }
                            return@forEachIndexed
                        }
                    } else {
                        val newProd = ProductEntity(
                            internalCode = row.internalCode.ifBlank { "IMP-${row.displayRowNumber.toString().padStart(4, '0')}" },
                            name = row.productName,
                            description = row.description,
                            categoryId = categoryId,
                            categoryName = row.categoryName,
                            basePrice = row.basePrice,
                            currency = row.currency,
                            originCountry = row.originCountry,
                            manufacturer = row.manufacturer,
                            defaultQuantity = row.defaultQuantity,
                            notes = row.notes,
                            createdAt = now,
                            updatedAt = now,
                        )
                        val id = productDao.insertProduct(newProd)
                        inserted++
                        id
                    }

                    productIdByRowZeroBased[row.sheetRowZeroBased] = productId

                    // Apply barcode policy
                    if (row.newBarcodePolicy != ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE || matchedExistingId == null) {
                        val productAlreadyHasPrimary = existingBarcodeMap.values.any {
                            it.productId == productId && it.isPrimary
                        }
                        var promotedNewPrimaryId: Long? = null

                        for ((code, isRowPrimary) in allBarcodesForRow) {
                            val existingOwner = existingBarcodeMap[code]
                            if (row.newBarcodePolicy == ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE) {
                                if (existingOwner != null || row.intraFileDuplicateRows.containsKey(code)) {
                                    continue
                                }
                            }
                            if (existingOwner != null) {
                                if (existingOwner.productId != productId) {
                                    if (issues.size < 200) {
                                        issues.add(
                                            ImportValidationIssue(
                                                row.displayRowNumber,
                                                "تم تجاهل الباركود ($code) لارتباطه بمنتج آخر",
                                                isWarning = true,
                                            ),
                                        )
                                    }
                                    continue
                                }
                                if (isRowPrimary && row.newBarcodePolicy == ExcelNewBarcodePolicy.SET_AS_PRIMARY_KEEP_OLD) {
                                    promotedNewPrimaryId = existingOwner.id
                                }
                                continue
                            }

                            val explicitRowFmt = if (isRowPrimary) row.explicitBarcodeType else ""
                            val fmt = inferBarcodeFormat(
                                value = code,
                                explicitFormatRaw = explicitRowFmt,
                                preferredDefault = savedDefaultBarcodeFormat,
                            )
                            val makePrimary = when {
                                matchedExistingId == null -> isRowPrimary && !productAlreadyHasPrimary
                                row.newBarcodePolicy == ExcelNewBarcodePolicy.SET_AS_PRIMARY_KEEP_OLD -> isRowPrimary
                                row.newBarcodePolicy == ExcelNewBarcodePolicy.ADD_AS_ALTERNATIVE -> !productAlreadyHasPrimary && isRowPrimary
                                else -> false
                            }
                            val entity = ProductBarcodeEntity(
                                productId = productId,
                                barcodeValue = code,
                                barcodeType = fmt.name,
                                label = if (makePrimary) "رئيسي" else "بديل مستورد",
                                isPrimary = makePrimary,
                                updatedAt = now,
                            )
                            val insertedBarcodeId = productDao.insertBarcode(entity)
                            val persisted = entity.copy(id = insertedBarcodeId)
                            existingBarcodeMap[code] = persisted
                            importedBarcodePrewarms.add(Triple(productId, code, fmt))
                            if (makePrimary && row.newBarcodePolicy == ExcelNewBarcodePolicy.SET_AS_PRIMARY_KEEP_OLD) {
                                promotedNewPrimaryId = insertedBarcodeId
                            }
                            barcodesCount++
                        }

                        if (promotedNewPrimaryId != null) {
                            productDao.setPrimaryBarcode(productId, promotedNewPrimaryId)
                            existingBarcodeMap.entries.forEach { entry ->
                                if (entry.value.productId == productId) {
                                    existingBarcodeMap[entry.key] = entry.value.copy(
                                        isPrimary = entry.value.id == promotedNewPrimaryId,
                                    )
                                }
                            }
                        }
                    }

                    // Embedded spreadsheet images attached to row
                    if (matchedExistingId == null || review.policy == ImportDuplicatePolicy.UPDATE) {
                        val existingImgCount = productDao.getProductWithDetails(productId)?.images?.size ?: 0
                        val primaryId = row.primaryImageId ?: row.images.firstOrNull()?.id
                        row.images.forEachIndexed { imgIdx, img ->
                            val stored = mediaStorage.saveProductImageBytesWithOriginal(img.bytes)
                            if (stored != null) {
                                writtenImagePaths.add(stored.activePath)
                                stored.originalPath.takeIf { it.isNotBlank() }?.let { writtenImagePaths.add(it) }
                                stored.thumbnailPath.takeIf { it.isNotBlank() }?.let { writtenImagePaths.add(it) }
                                productDao.insertImage(
                                    ProductImageEntity(
                                        productId = productId,
                                        filePath = stored.activePath,
                                        originalFilePath = stored.originalPath,
                                        thumbnailPath = stored.thumbnailPath,
                                        isPrimary = (img.id == primaryId) && existingImgCount == 0,
                                        sortOrder = existingImgCount + imgIdx,
                                        downloadedAt = now,
                                        downloadStatus = ImageDownloadStatus.SUCCESS.name,
                                    ),
                                )
                                embeddedImagesCount++
                            } else {
                                remainingUnlinked.add(img)
                            }
                        }
                    }

                    // Queue URL image download task(s) linked by actual ProductID (supports multiple URLs per product)
                    if (rowUrlList.isNotEmpty()) {
                        val effectiveBarcode = if (row.newBarcodePolicy == ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE) {
                            listOfNotNull(
                                row.primaryBarcode.takeIf { it.isNotBlank() && !row.foreignConflictBarcodes.containsKey(it) },
                                row.extraBarcodes.firstOrNull { !row.foreignConflictBarcodes.containsKey(it) },
                            ).firstOrNull().orEmpty()
                        } else {
                            row.primaryBarcode.ifBlank { row.extraBarcodes.firstOrNull().orEmpty() }
                        }
                        val effectiveName = existingProduct?.name?.takeIf { review.policy != ImportDuplicatePolicy.UPDATE } ?: row.productName
                        if (wantsUrlDownloadForRow) {
                            rowUrlList.forEachIndexed { urlIdx, singleUrl ->
                                // URL #0 uses row policy; subsequent URLs for the same product always append as additional images!
                                val effectivePolicy = if (urlIdx == 0) {
                                    row.imageConflictPolicy
                                } else {
                                    ExcelImageConflictPolicy.ADD_AS_ADDITIONAL
                                }
                                val pendingRec = ProductImageDownloadEntity(
                                    batchId = downloadBatchId,
                                    productId = productId,
                                    barcode = effectiveBarcode,
                                    productName = effectiveName,
                                    sourceUrl = singleUrl,
                                    status = ImageDownloadStatus.PENDING.name,
                                    imagePolicy = effectivePolicy.name,
                                    excelRowNumber = row.displayRowNumber,
                                    createdAt = now,
                                    updatedAt = now,
                                )
                                val insertedDlId = productDao.insertImageDownload(pendingRec)
                                queuedDownloads.add(pendingRec.copy(id = insertedDlId))
                                if (matchedExistingId != null &&
                                    review.policy == ImportDuplicatePolicy.SKIP &&
                                    !hasNewBarcodesForExisting
                                ) {
                                    urlOnlyExistingDownloadIds.add(insertedDlId)
                                }
                            }
                        } else if (matchedExistingId != null && existingProductHasValidImg && row.imageConflictPolicy == ExcelImageConflictPolicy.KEEP_EXISTING) {
                            rowUrlList.forEach { singleUrl ->
                                val skipRec = ProductImageDownloadEntity(
                                    batchId = downloadBatchId,
                                    productId = productId,
                                    barcode = effectiveBarcode,
                                    productName = effectiveName,
                                    sourceUrl = singleUrl,
                                    status = ImageDownloadStatus.SKIPPED.name,
                                    failureReason = "تم الإبقاء على الصورة الحالية للمنتج حسب السياسة المختارة",
                                    imagePolicy = row.imageConflictPolicy.name,
                                    excelRowNumber = row.displayRowNumber,
                                    createdAt = now,
                                    updatedAt = now,
                                )
                                val skipId = productDao.insertImageDownload(skipRec)
                                queuedDownloads.add(skipRec.copy(id = skipId))
                            }
                        }
                    }

                    if ((idx + 1) % 25 == 0 || idx == review.rows.lastIndex) {
                        onProgress(idx + 1, total)
                    }
                }
                beforeCommitHook()
            }
        } catch (c: CancellationException) {
            writtenImagePaths.forEach { path -> mediaStorage.deleteFileIfInternal(path) }
            trace?.cancel("تم إلغاء معاملة استيراد Excel")
            throw c
        } catch (t: Throwable) {
            writtenImagePaths.forEach { path -> mediaStorage.deleteFileIfInternal(path) }
            val rec = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.EXCEL_IMPORT,
                moduleName = DiagnosticModules.EXCEL,
                operationName = "معاملة استيراد منتجات Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "فشل حفظ منتجات Excel", linkedErrorId = rec?.errorId.orEmpty())
            throw t
        }

        barcodeService?.let { svc ->
            importedBarcodePrewarms.forEach { (pid, code, fmt) ->
                svc.ensureBarcodeDiskImageOnly(pid, code, fmt)
            }
        }

        try {
            // Phase 2: Download remote image URLs concurrently outside transaction
            val pendingTasks = queuedDownloads.filter { it.status == ImageDownloadStatus.PENDING.name }
            if (pendingTasks.isNotEmpty()) {
                trace?.stage("تنزيل روابط صور المنتجات", "روابط=${pendingTasks.size}")
                processImageDownloadQueue(pendingTasks, onProgress = onImageDownloadProgress)
            }

            trace?.stage("تلخيص نتائج الاستيراد والصور")
            val finalBatchRecords = productDao.getImageDownloadsByBatchOnce(downloadBatchId)
            val urlOnlyProductsUpdated = mutableSetOf<Long>()
            val urlOnlyProductsAttempted = mutableSetOf<Long>()
            finalBatchRecords.forEach { rec ->
                if (rec.id in urlOnlyExistingDownloadIds) {
                    urlOnlyProductsAttempted.add(rec.productId)
                    if (rec.status == ImageDownloadStatus.SUCCESS.name) {
                        urlOnlyProductsUpdated.add(rec.productId)
                    }
                }
            }
            updated += urlOnlyProductsUpdated.size
            skipped += (urlOnlyProductsAttempted - urlOnlyProductsUpdated).size

            val urlSuccessCount = finalBatchRecords.count { it.status == ImageDownloadStatus.SUCCESS.name }
            val urlFailedRecords = finalBatchRecords.filter { it.status == ImageDownloadStatus.FAILED.name }
            val urlSkippedCount = finalBatchRecords.count { it.status == ImageDownloadStatus.SKIPPED.name }
            val missingGtinCount = review.rows.count {
                !it.skipRow && it.validationError == null && it.primaryBarcode.isBlank() && it.extraBarcodes.isEmpty()
            }

            urlFailedRecords.forEach { failed ->
                if (issues.size < 250) {
                    issues.add(
                        ImportValidationIssue(
                            rowNumber = failed.excelRowNumber,
                            message = "فشل تنزيل صورة (${failed.productName}): ${failed.failureReason}",
                            isWarning = true,
                        ),
                    )
                }
            }

            val summaryDetail = "جديد=$inserted • محدث=$updated • صور ناجحة=$urlSuccessCount • فشل=${urlFailedRecords.size}"
            if (urlFailedRecords.isNotEmpty() || errors > 0) {
                trace?.warn(summaryDetail)
            } else {
                trace?.succeed(summaryDetail)
            }

            ExcelImportFinalReport(
                insertedCount = inserted,
                updatedCount = updated,
                skippedCount = skipped,
                errorCount = errors,
                barcodesImportedCount = barcodesCount,
                autoLinkedImagesCount = embeddedImagesCount + urlSuccessCount,
                unlinkedImages = remainingUnlinked,
                importedProductIdsByRow = productIdByRowZeroBased,
                issues = issues,
                imageDownloadSuccessCount = urlSuccessCount,
                imageDownloadFailedCount = urlFailedRecords.size,
                imageDownloadSkippedCount = urlSkippedCount,
                downloadBatchId = downloadBatchId,
                imageDownloadRecords = finalBatchRecords,
                failedImageDownloads = urlFailedRecords,
                totalProductsProcessed = inserted + updated + skipped,
                totalImageUrlsCount = finalBatchRecords.size,
                verifiedDownloadedCount = urlSuccessCount,
                linkedImagesCount = embeddedImagesCount + urlSuccessCount,
                productsWithoutGtinCount = missingGtinCount,
            )
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء مرحلة تنزيل صور Excel")
            throw c
        } catch (t: Throwable) {
            val rec = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.EXCEL_IMPORT,
                moduleName = DiagnosticModules.IMAGES,
                operationName = "مرحلة تنزيل صور Excel",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "خطأ في تنزيل صور Excel", linkedErrorId = rec?.errorId.orEmpty())
            throw t
        }
    }

    /**
     * Retries failed or pending URL image downloads directly from persistent DB records
     * without re-importing or duplicating any products. Works safely across app restarts.
     */
    suspend fun retryFailedImageDownloads(
        downloadIds: List<Long>? = null,
        batchId: String? = null,
        onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
    ): RetryImageDownloadsResult = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.EXCEL_IMPORT,
            moduleName = DiagnosticModules.IMAGES,
            operationName = "إعادة تحميل صور المنتجات الفاشلة",
            initialStage = "جمع روابط الصور المتعثرة",
        )
        try {
            val productDao = db.productDao()
            val targets = when {
                !downloadIds.isNullOrEmpty() -> productDao.getImageDownloadsByIdsOnce(downloadIds)
                    .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
                !batchId.isNullOrBlank() -> productDao.getImageDownloadsByBatchOnce(batchId)
                    .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
                else -> productDao.getPendingOrFailedImageDownloadsOnce()
            }

            if (targets.isEmpty()) {
                trace?.succeed("لا توجد صور فاشلة لإعادة المحاولة")
                return@withContext RetryImageDownloadsResult(0, 0, 0, 0, emptyList())
            }

            trace?.stage("إعادة تنزيل ${targets.size} صورة")
            val updated = processImageDownloadQueue(targets, onProgress)
            val okCount = updated.count { it.status == ImageDownloadStatus.SUCCESS.name }
            val failCount = updated.count { it.status == ImageDownloadStatus.FAILED.name }
            if (failCount > 0) {
                trace?.warn("نجح $okCount • استمر فشل $failCount")
            } else {
                trace?.succeed("اكتملت إعادة التحميل ($okCount من ${targets.size})")
            }
            RetryImageDownloadsResult(
                totalAttempted = targets.size,
                succeededCount = okCount,
                failedCount = failCount,
                skippedCount = updated.count { it.status == ImageDownloadStatus.SKIPPED.name },
                updatedRecords = updated,
            )
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء إعادة تحميل الصور")
            throw c
        } catch (t: Throwable) {
            val rec = errorMonitor?.recordError(t, ScreenNames.EXCEL_IMPORT, DiagnosticModules.IMAGES, "إعادة تحميل صور المنتجات", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(t.message ?: "فشل إعادة تحميل الصور", linkedErrorId = rec?.errorId.orEmpty())
            throw t
        }
    }

    private suspend fun processImageDownloadQueue(
        tasks: List<ProductImageDownloadEntity>,
        onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
        downloaderOverride: RemoteImageDownloader? = null,
    ): List<ProductImageDownloadEntity> = coroutineScope {
        val productDao = db.productDao()
        val downloader = downloaderOverride ?: remoteDownloader
        val globalSemaphore = Semaphore(MAX_CONCURRENT_IMAGE_DOWNLOADS)
        val hostSemaphores = ConcurrentHashMap<String, Semaphore>()
        val urlMutex = Mutex()
        val inBatchUrlBytes = mutableMapOf<String, CompletableDeferred<RemoteImageBytesResult>>()
        val completedCount = AtomicInteger(0)
        val total = tasks.size
        val results = mutableListOf<ProductImageDownloadEntity>()

        for (batch in tasks.chunked(IMAGE_DOWNLOAD_BATCH_SIZE)) {
            val batchResults = batch.map { task ->
                async(Dispatchers.IO) {
                    globalSemaphore.withPermit {
                        val trimmedUrl = task.sourceUrl.trim()
                        val validation = RemoteImageUrlValidator.validateSyntax(trimmedUrl)
                        val lookupUrl = if (validation.isValid) validation.normalizedUrl else trimmedUrl
                        val hostKey = try {
                            URI(lookupUrl).host?.lowercase().orEmpty()
                        } catch (_: Exception) {
                            ""
                        }
                        val hostGate = if (hostKey.isNotEmpty()) {
                            hostSemaphores.getOrPut(hostKey) { Semaphore(MAX_CONCURRENT_PER_HOST) }
                        } else {
                            null
                        }

                        suspend fun runTask(): ProductImageDownloadEntity {
                            val existingReusable = (productDao.findImageBySourceUrl(lookupUrl)
                                ?: productDao.findImageBySourceUrl(trimmedUrl))?.takeIf { img ->
                                ImageService.resolveProductImageStateless(img, preferThumbnail = true) is ImageResolution.Available
                            }

                            return if (existingReusable != null) {
                                val copied = mediaStorage.copyStoredFilesForProduct(
                                    StoredImageFiles(
                                        activePath = ImageService.cleanPath(existingReusable.filePath),
                                        originalPath = ImageService.cleanPath(existingReusable.originalFilePath),
                                        thumbnailPath = ImageService.cleanPath(existingReusable.thumbnailPath),
                                    ),
                                )
                                if (copied != null) {
                                    applyDownloadedImageToProduct(
                                        task = task,
                                        storedFiles = copied,
                                        normalizedUrl = lookupUrl,
                                        contentHash = existingReusable.contentHash,
                                        fileSizeBytes = existingReusable.fileSizeBytes,
                                        detectedFormat = File(copied.originalPath).extension.ifBlank { "png" },
                                        finalUrl = lookupUrl,
                                        httpStatusCode = 200,
                                        diagnosticLog = "Reused cached URL image",
                                    )
                                } else {
                                    downloadAndApplyTask(task, trimmedUrl, lookupUrl, urlMutex, inBatchUrlBytes, downloader)
                                }
                            } else {
                                downloadAndApplyTask(task, trimmedUrl, lookupUrl, urlMutex, inBatchUrlBytes, downloader)
                            }
                        }

                        val outcome = if (hostGate != null) {
                            hostGate.withPermit { runTask() }
                        } else {
                            runTask()
                        }

                        val done = completedCount.incrementAndGet()
                        onProgress(done, total)
                        outcome
                    }
                }
            }.awaitAll()
            results.addAll(batchResults)
        }
        results
    }

    private suspend fun downloadAndApplyTask(
        task: ProductImageDownloadEntity,
        trimmedUrl: String,
        lookupUrl: String,
        urlMutex: Mutex,
        inBatchUrlBytes: MutableMap<String, CompletableDeferred<RemoteImageBytesResult>>,
        downloader: RemoteImageDownloader,
    ): ProductImageDownloadEntity {
        var isOwner = false
        val deferred = urlMutex.withLock {
            val existing = inBatchUrlBytes[lookupUrl]
            if (existing != null) {
                existing
            } else {
                isOwner = true
                CompletableDeferred<RemoteImageBytesResult>().also {
                    inBatchUrlBytes[lookupUrl] = it
                }
            }
        }

        val bytesResult = if (isOwner) {
            try {
                downloader.downloadAndVerifyBytes(trimmedUrl).also { deferred.complete(it) }
            } catch (t: Throwable) {
                val fail = RemoteImageBytesResult.Failure(
                    normalizedUrl = lookupUrl,
                    reason = t.message ?: "خطأ غير متوقع أثناء التنزيل",
                    kind = RemoteImageFailureKind.NETWORK_ERROR,
                    diagnosticLog = t.javaClass.simpleName,
                )
                deferred.complete(fail)
                fail
            }
        } else {
            deferred.await()
        }

        return when (bytesResult) {
            is RemoteImageBytesResult.Failure -> {
                val now = System.currentTimeMillis()
                val failedEntity = task.copy(
                    status = ImageDownloadStatus.FAILED.name,
                    failureReason = bytesResult.reason,
                    failureCategory = bytesResult.kind.arabicLabel,
                    httpStatusCode = bytesResult.httpStatusCode,
                    finalUrl = bytesResult.finalUrl,
                    diagnosticLog = bytesResult.diagnosticLog,
                    attemptCount = task.attemptCount + 1,
                    updatedAt = now,
                )
                db.productDao().updateImageDownload(failedEntity)
                failedEntity
            }
            is RemoteImageBytesResult.Success -> {
                val existingByHash = db.productDao().findImageByContentHash(bytesResult.contentHash)?.takeIf { img ->
                    ImageService.resolveProductImageStateless(img, preferThumbnail = true) is ImageResolution.Available
                }
                val filesForThisProduct = if (existingByHash != null) {
                    mediaStorage.copyStoredFilesForProduct(
                        StoredImageFiles(
                            activePath = ImageService.cleanPath(existingByHash.filePath),
                            originalPath = ImageService.cleanPath(existingByHash.originalFilePath),
                            thumbnailPath = ImageService.cleanPath(existingByHash.thumbnailPath),
                        ),
                    )
                } else {
                    mediaStorage.saveDownloadedImageBytes(bytesResult.bytes, bytesResult.detectedExtension)
                } ?: mediaStorage.saveDownloadedImageBytes(bytesResult.bytes, bytesResult.detectedExtension)

                val verifiedOnDisk = filesForThisProduct != null &&
                    File(filesForThisProduct.activePath).let { it.exists() && it.length() > 0L } &&
                    File(filesForThisProduct.thumbnailPath).let { it.exists() && it.length() > 0L }

                if (filesForThisProduct == null || !verifiedOnDisk) {
                    filesForThisProduct?.let { deleteStoredTriplet(it) }
                    val now = System.currentTimeMillis()
                    val failedEntity = task.copy(
                        status = ImageDownloadStatus.FAILED.name,
                        failureReason = "تعذر حفظ الصورة والتحقق من صلاحيتها داخل تخزين التطبيق",
                        failureCategory = RemoteImageFailureKind.STORAGE_ERROR.arabicLabel,
                        httpStatusCode = bytesResult.httpStatusCode,
                        finalUrl = bytesResult.finalUrl,
                        detectedFormat = bytesResult.detectedExtension,
                        diagnosticLog = bytesResult.diagnosticLog,
                        attemptCount = task.attemptCount + 1,
                        updatedAt = now,
                    )
                    db.productDao().updateImageDownload(failedEntity)
                    failedEntity
                } else {
                    applyDownloadedImageToProduct(
                        task = task,
                        storedFiles = filesForThisProduct,
                        normalizedUrl = bytesResult.normalizedUrl,
                        contentHash = bytesResult.contentHash,
                        fileSizeBytes = bytesResult.bytes.size.toLong(),
                        detectedFormat = bytesResult.detectedExtension,
                        finalUrl = bytesResult.finalUrl,
                        httpStatusCode = bytesResult.httpStatusCode,
                        diagnosticLog = bytesResult.diagnosticLog,
                    )
                }
            }
        }
    }

    private suspend fun applyDownloadedImageToProduct(
        task: ProductImageDownloadEntity,
        storedFiles: StoredImageFiles,
        normalizedUrl: String,
        contentHash: String,
        fileSizeBytes: Long,
        detectedFormat: String = "",
        finalUrl: String = normalizedUrl,
        httpStatusCode: Int = 200,
        diagnosticLog: String = "",
        forceApplyOverExistingPolicy: Boolean = false,
    ): ProductImageDownloadEntity {
        val productDao = db.productDao()
        val inventoryDao = db.inventoryDao()
        val now = System.currentTimeMillis()
        val effectivePolicy = ExcelImageConflictPolicy.entries.firstOrNull { it.name == task.imagePolicy }
            ?: ExcelImageConflictPolicy.KEEP_EXISTING

        return mutexForProduct(task.productId).withLock {
            db.withTransaction {
                val details = productDao.getProductWithDetails(task.productId)
                if (details == null) {
                    deleteStoredTriplet(storedFiles)
                    val failed = task.copy(
                        status = ImageDownloadStatus.FAILED.name,
                        failureReason = "لم يعد المنتج المرتبط موجوداً في قاعدة البيانات",
                        failureCategory = RemoteImageFailureKind.STORAGE_ERROR.arabicLabel,
                        attemptCount = task.attemptCount + 1,
                        updatedAt = now,
                    )
                    productDao.updateImageDownload(failed)
                    return@withTransaction failed
                }

                val existingImages = details.images.sortedBy { it.sortOrder }
                val hasValidExisting = existingImages.any { im ->
                    ImageService.resolveProductImageStateless(im, preferThumbnail = true) is ImageResolution.Available
                }
                val batchAlreadyApplied = task.batchId.isNotBlank() &&
                    productDao.getImageDownloadsByBatchOnce(task.batchId).any {
                        it.productId == task.productId &&
                            it.id != task.id &&
                            it.status == ImageDownloadStatus.SUCCESS.name
                    }
                val policy = if (batchAlreadyApplied && effectivePolicy == ExcelImageConflictPolicy.REPLACE_PRIMARY) {
                    ExcelImageConflictPolicy.ADD_AS_ADDITIONAL
                } else {
                    effectivePolicy
                }

            if (hasValidExisting && policy == ExcelImageConflictPolicy.KEEP_EXISTING && !forceApplyOverExistingPolicy) {
                deleteStoredTriplet(storedFiles)
                val skippedRec = task.copy(
                    status = ImageDownloadStatus.SKIPPED.name,
                    failureReason = "تم الإبقاء على الصورة الحالية للمنتج حسب السياسة المختارة",
                    failureCategory = "",
                    httpStatusCode = httpStatusCode,
                    finalUrl = finalUrl,
                    detectedFormat = detectedFormat,
                    diagnosticLog = diagnosticLog,
                    attemptCount = task.attemptCount + 1,
                    updatedAt = now,
                )
                productDao.updateImageDownload(skippedRec)
                return@withTransaction skippedRec
            }

            val makePrimary = !hasValidExisting || policy == ExcelImageConflictPolicy.REPLACE_PRIMARY
            val savedImageId: Long = if (hasValidExisting && policy == ExcelImageConflictPolicy.REPLACE_PRIMARY) {
                val targetPrimary = existingImages.firstOrNull { it.isPrimary } ?: existingImages.first()
                mediaStorage.deleteFileIfInternal(targetPrimary.filePath)
                mediaStorage.deleteFileIfInternal(targetPrimary.originalFilePath)
                mediaStorage.deleteFileIfInternal(targetPrimary.thumbnailPath)
                productDao.updateImage(
                    targetPrimary.copy(
                        filePath = storedFiles.activePath,
                        originalFilePath = storedFiles.originalPath,
                        thumbnailPath = storedFiles.thumbnailPath,
                        isPrimary = true,
                        sourceUrl = normalizedUrl,
                        matchedBarcode = task.barcode,
                        downloadedAt = now,
                        downloadStatus = ImageDownloadStatus.SUCCESS.name,
                        failureReason = "",
                        contentHash = contentHash,
                        fileSizeBytes = fileSizeBytes,
                    ),
                )
                productDao.setPrimaryImage(task.productId, targetPrimary.id)
                targetPrimary.id
            } else {
                val insertedId = productDao.insertImage(
                    ProductImageEntity(
                        productId = task.productId,
                        filePath = storedFiles.activePath,
                        originalFilePath = storedFiles.originalPath,
                        thumbnailPath = storedFiles.thumbnailPath,
                        isPrimary = makePrimary,
                        sortOrder = (existingImages.maxOfOrNull { it.sortOrder } ?: -1) + 1,
                        sourceUrl = normalizedUrl,
                        matchedBarcode = task.barcode,
                        downloadedAt = now,
                        downloadStatus = ImageDownloadStatus.SUCCESS.name,
                        failureReason = "",
                        contentHash = contentHash,
                        fileSizeBytes = fileSizeBytes,
                    ),
                )
                if (makePrimary) {
                    productDao.setPrimaryImage(task.productId, insertedId)
                }
                insertedId
            }

            productDao.updateProduct(details.product.copy(updatedAt = now))

            // Keep inventory count item snapshot paths synchronized if blank/missing or primary replaced
            if (makePrimary) {
                val invItems = inventoryDao.getCountItemsForProductOnce(task.productId)
                invItems.forEach { countItem ->
                    val cleanSnap = ImageService.cleanPath(countItem.productImagePath)
                    val currentMissing = cleanSnap.isBlank() || !File(cleanSnap).exists()
                    if (currentMissing || policy == ExcelImageConflictPolicy.REPLACE_PRIMARY) {
                        inventoryDao.updateCountItem(countItem.copy(productImagePath = storedFiles.activePath))
                    }
                }
            }

                val successEntity = task.copy(
                    status = ImageDownloadStatus.SUCCESS.name,
                    failureReason = "",
                    failureCategory = "",
                    httpStatusCode = httpStatusCode,
                    finalUrl = finalUrl,
                    detectedFormat = detectedFormat,
                    diagnosticLog = diagnosticLog,
                    localImageId = savedImageId,
                    localFilePath = storedFiles.activePath,
                    originalFilePath = storedFiles.originalPath,
                    thumbnailPath = storedFiles.thumbnailPath,
                    contentHash = contentHash,
                    fileSizeBytes = fileSizeBytes,
                    downloadedAt = now,
                    attemptCount = task.attemptCount + 1,
                    updatedAt = now,
                )
                productDao.updateImageDownload(successEntity)
                successEntity
            }
        }
    }

    /**
     * Fallback 1: Manual photo pick or local file fulfillment linked directly to ProductID without duplicating products.
     */
    suspend fun fulfillDownloadFromLocalBytes(
        downloadId: Long,
        bytes: ByteArray,
        sourceLabel: String = "manual_upload",
    ): Result<ProductImageDownloadEntity> = withContext(Dispatchers.IO) {
        val task = db.productDao().getImageDownloadsByIdsOnce(listOf(downloadId)).firstOrNull()
            ?: return@withContext Result.failure(IllegalArgumentException("سجل التحميل غير موجود"))

        if (bytes.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("ملف الصورة المختار فارغ"))
        }
        val detectedExt = RemoteImageDownloader.detectRasterImageFormat(bytes)
            ?: return@withContext Result.failure(IllegalArgumentException("صيغة الملف غير مدعومة (المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF)"))
        val stored = mediaStorage.saveDownloadedImageBytes(bytes, detectedExt)
            ?: return@withContext Result.failure(IllegalStateException("تعذر فتح ملف الصورة وحفظه داخل التخزين"))

        val hash = RemoteImageDownloader.sha256Hex(bytes)
        val updated = applyDownloadedImageToProduct(
            task = task,
            storedFiles = stored,
            normalizedUrl = task.sourceUrl.ifBlank { sourceLabel },
            contentHash = hash,
            fileSizeBytes = bytes.size.toLong(),
            detectedFormat = detectedExt,
            finalUrl = sourceLabel,
            httpStatusCode = 0,
            diagnosticLog = "Fulfilled from $sourceLabel (${detectedExt.uppercase()})",
            forceApplyOverExistingPolicy = true,
        )
        Result.success(updated)
    }

    suspend fun fulfillFailedDownloadManually(
        downloadId: Long,
        imageUri: Uri,
    ): Result<ProductImageDownloadEntity> = withContext(Dispatchers.IO) {
        val bytes = try {
            context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
        } catch (_: Exception) {
            null
        } ?: return@withContext Result.failure(IllegalStateException("تعذر قراءة الصورة المختارة"))
        fulfillDownloadFromLocalBytes(downloadId, bytes, sourceLabel = "manual_picker")
    }

    /**
     * Multi-image manual selection fallback: resolves [downloadId] with the first valid photo
     * and attaches all subsequent selected photos to the exact same ProductID without overwriting primary.
     */
    suspend fun fulfillFailedDownloadManuallyMultiple(
        downloadId: Long,
        imageUris: List<Uri>,
    ): Result<Pair<ProductImageDownloadEntity, Int>> = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("لم يتم اختيار أي صور"))
        }
        val firstRes = fulfillFailedDownloadManually(downloadId, imageUris.first())
        val resolvedTask = firstRes.getOrElse { return@withContext Result.failure(it) }
        var extraCount = 0
        for (extraUri in imageUris.drop(1)) {
            val bytes = runCatching { context.contentResolver.openInputStream(extraUri)?.use { it.readBytes() } }.getOrNull()
                ?: continue
            if (attachAdditionalImageBytesToProduct(resolvedTask.productId, bytes, resolvedTask.barcode, "manual_picker")) {
                extraCount++
            }
        }
        Result.success(resolvedTask to extraCount)
    }

    private suspend fun attachAdditionalImageBytesToProduct(
        productId: Long,
        bytes: ByteArray,
        matchedBarcode: String,
        sourceUrl: String,
    ): Boolean {
        if (bytes.isEmpty()) return false
        val detectedExt = RemoteImageDownloader.detectRasterImageFormat(bytes) ?: return false
        val stored = mediaStorage.saveDownloadedImageBytes(bytes, detectedExt) ?: return false
        val hash = RemoteImageDownloader.sha256Hex(bytes)
        val now = System.currentTimeMillis()
        val productDao = db.productDao()
        return mutexForProduct(productId).withLock {
            db.withTransaction {
                val details = productDao.getProductWithDetails(productId)
                if (details == null) {
                    deleteStoredTriplet(stored)
                    return@withTransaction false
                }
                val existingImages = details.images
                if (existingImages.any { it.contentHash.isNotBlank() && it.contentHash == hash }) {
                    deleteStoredTriplet(stored)
                    return@withTransaction true
                }
                val nextSort = (existingImages.maxOfOrNull { it.sortOrder } ?: -1) + 1
                productDao.insertImage(
                    ProductImageEntity(
                        productId = productId,
                        filePath = stored.activePath,
                        originalFilePath = stored.originalPath,
                        thumbnailPath = stored.thumbnailPath,
                        isPrimary = existingImages.isEmpty(),
                        sortOrder = nextSort,
                        sourceUrl = sourceUrl,
                        matchedBarcode = matchedBarcode,
                        downloadedAt = now,
                        downloadStatus = ImageDownloadStatus.SUCCESS.name,
                        contentHash = hash,
                        fileSizeBytes = bytes.size.toLong(),
                    ),
                )
                productDao.updateProduct(details.product.copy(updatedAt = now))
                true
            }
        }
    }

    /**
     * Fallback 2: Strict GTIN/barcode batch matching from a user-selected local folder (SAF OpenDocumentTree).
     * Never guesses matches by product name alone (to prevent wrong links on similar names).
     * Supports multiple images per GTIN (e.g. `6281234567890.webp`, `6281234567890_1.jpg`, `6281234567890-2.png`).
     */
    suspend fun matchAndImportFailedFromFolder(
        folderTreeUri: Uri,
        downloadIds: List<Long>? = null,
        batchId: String? = null,
        customCandidatesProvider: (suspend (Uri) -> List<LocalFolderImageCandidate>)? = null,
    ): FolderImageImportResult = withContext(Dispatchers.IO) {
        val productDao = db.productDao()
        val failedTargets = when {
            !downloadIds.isNullOrEmpty() -> productDao.getImageDownloadsByIdsOnce(downloadIds)
                .filter { it.status == ImageDownloadStatus.FAILED.name }
            !batchId.isNullOrBlank() -> productDao.getImageDownloadsByBatchOnce(batchId)
                .filter { it.status == ImageDownloadStatus.FAILED.name }
            else -> productDao.getPendingOrFailedImageDownloadsOnce()
                .filter { it.status == ImageDownloadStatus.FAILED.name }
        }
        val candidates = if (customCandidatesProvider != null) {
            customCandidatesProvider(folderTreeUri)
        } else {
            enumerateSafFolderImageCandidates(folderTreeUri)
        }.sortedBy { it.fileName.lowercase(Locale.ROOT) }
        if (candidates.isEmpty()) {
            return@withContext FolderImageImportResult(0, 0, 0, 0, emptyList())
        }

        val allProducts = productDao.getAllProductsWithDetailsOnce()
        val productsMap = allProducts.associateBy { it.product.id }
        val updatedRecords = mutableListOf<ProductImageDownloadEntity>()
        val errors = mutableListOf<String>()
        val matchedCandidateNames = mutableSetOf<String>()
        var matched = 0
        var succeeded = 0
        var failed = 0
        var extraLinked = 0

        val tasksByProduct = failedTargets.groupBy { it.productId }
        for ((productId, productTasks) in tasksByProduct) {
            val details = productsMap[productId]
            val firstTask = productTasks.first()
            val strictIdentifiers = buildStrictIdentifiersForProduct(
                details = details,
                extraBarcode = firstTask.barcode,
                extraUrls = productTasks.map { it.sourceUrl },
            )
            if (strictIdentifiers.isEmpty()) continue

            val matchedFiles = candidates.filter { cand ->
                matchesStrictIdentifier(cand.fileName, strictIdentifiers)
            }
            if (matchedFiles.isEmpty()) continue

            matched++
            var candIdx = 0
            // 1. Fulfill each failed download task for this product with corresponding matched files
            for (task in productTasks) {
                val cand = matchedFiles.getOrNull(candIdx) ?: matchedFiles.firstOrNull() ?: break
                matchedCandidateNames.add(cand.fileName)
                candIdx++
                val bytes = cand.openBytes()
                if (bytes == null) {
                    failed++
                    errors.add("${task.productName}: تعذر قراءة الملف ${cand.fileName}")
                } else {
                    val res = fulfillDownloadFromLocalBytes(task.id, bytes, sourceLabel = "local_gtin:${cand.fileName}")
                    res.onSuccess { rec ->
                        updatedRecords.add(rec)
                        if (rec.status == ImageDownloadStatus.SUCCESS.name) succeeded++ else failed++
                    }.onFailure { err ->
                        failed++
                        errors.add("${task.productName} (${cand.fileName}): ${err.message}")
                    }
                }
            }
            // 2. Attach any additional local GTIN images (e.g. _2, _3) directly to this ProductID
            for (extraCand in matchedFiles.drop(candIdx)) {
                matchedCandidateNames.add(extraCand.fileName)
                val bytes = extraCand.openBytes() ?: continue
                if (attachAdditionalImageBytesToProduct(productId, bytes, firstTask.barcode, "local_gtin:${extraCand.fileName}")) {
                    extraLinked++
                }
            }
        }

        // Also match products that currently have NO images even without a failed download record (GTIN-only)
        val productsAlreadyHandled = tasksByProduct.keys.toMutableSet()
        for (prod in allProducts) {
            if (prod.product.id in productsAlreadyHandled || prod.images.isNotEmpty()) continue
            val strictIds = buildStrictIdentifiersForProduct(prod)
            if (strictIds.isEmpty()) continue
            val prodMatches = candidates.filter { cand ->
                cand.fileName !in matchedCandidateNames && matchesStrictIdentifier(cand.fileName, strictIds)
            }
            if (prodMatches.isEmpty()) continue
            productsAlreadyHandled.add(prod.product.id)
            matched++
            val primaryGtin = prod.primaryBarcode?.barcodeValue.orEmpty()
            prodMatches.forEach { cand ->
                matchedCandidateNames.add(cand.fileName)
                val bytes = cand.openBytes()
                if (bytes == null) {
                    failed++
                    errors.add("${prod.product.name}: تعذر قراءة الملف ${cand.fileName}")
                } else if (attachAdditionalImageBytesToProduct(prod.product.id, bytes, primaryGtin, "local_gtin:${cand.fileName}")) {
                    succeeded++
                } else {
                    failed++
                    errors.add("${prod.product.name} (${cand.fileName}): صيغة صورة غير صالحة أو تالفة")
                }
            }
        }

        val unmatchedFiles = candidates.map { it.fileName }.filterNot { it in matchedCandidateNames }
        FolderImageImportResult(
            scannedFilesCount = candidates.size,
            matchedCount = matched,
            succeededCount = succeeded + extraLinked,
            failedCount = failed,
            updatedRecords = updatedRecords,
            errors = errors,
            extraLinkedCount = extraLinked,
            unmatchedFiles = unmatchedFiles,
        )
    }

    private fun buildStrictIdentifiersForProduct(
        details: com.example.data.local.entity.ProductWithDetails?,
        extraBarcode: String = "",
        extraUrls: List<String> = emptyList(),
    ): List<String> {
        return buildList {
            if (extraBarcode.isNotBlank()) add(extraBarcode.trim())
            details?.barcodes?.forEach { b ->
                if (b.barcodeValue.isNotBlank()) add(b.barcodeValue.trim())
            }
            details?.product?.internalCode?.trim()?.takeIf {
                it.isNotBlank() && !it.startsWith("IMP-", ignoreCase = true)
            }?.let { add(it) }
            extraUrls.forEach { u ->
                val urlStem = runCatching {
                    URI(u.trim()).path.substringAfterLast('/').substringBeforeLast('.')
                }.getOrNull().orEmpty()
                if (urlStem.length >= 6 && !urlStem.equals("image", true) && !urlStem.equals("product", true)) {
                    add(urlStem)
                }
            }
        }.map { it.lowercase(Locale.ROOT) }.distinct()
    }

    private fun matchesStrictIdentifier(fileName: String, identifiers: List<String>): Boolean {
        val rawStem = fileName.substringBeforeLast('.').trim().lowercase(Locale.ROOT)
        if (rawStem.isEmpty()) return false
        return identifiers.any { id ->
            if (id.length < 3) return@any false
            rawStem == id ||
                rawStem.startsWith("${id}_") ||
                rawStem.startsWith("$id-") ||
                rawStem.startsWith("$id.") ||
                rawStem.startsWith("$id ") ||
                rawStem.startsWith("$id(") ||
                rawStem.split('_', '-', '.', ' ', '(', ')').any { token -> token == id }
        }
    }

    private fun enumerateSafFolderImageCandidates(treeUri: Uri): List<LocalFolderImageCandidate> {
        val list = mutableListOf<LocalFolderImageCandidate>()
        try {
            val resolver = context.contentResolver
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri),
            )
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
            )
            resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (cursor.moveToNext()) {
                    val docId = if (idCol >= 0) cursor.getString(idCol) else continue
                    val name = if (nameCol >= 0) cursor.getString(nameCol).orEmpty() else ""
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol).orEmpty() else ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                    val ext = name.substringAfterLast('.', "").lowercase()
                    val looksLikeImage = mime.startsWith("image/") ||
                        ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif")
                    if (!looksLikeImage || name.isBlank()) continue
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                    list.add(
                        LocalFolderImageCandidate(
                            fileName = name,
                            openBytes = {
                                try {
                                    resolver.openInputStream(docUri)?.use { it.readBytes() }
                                } catch (_: Exception) {
                                    null
                                }
                            },
                        ),
                    )
                }
            }
        } catch (_: Exception) {
        }
        return list
    }

    private fun normalizeLookupStem(value: String): String =
        value.trim().lowercase().replace(Regex("[\\s_\\-]+"), "")

    /**
     * Fallback 3: Update a failed download record's URL to a new alternate URL and retry downloading it immediately.
     */
    suspend fun updateAndRetryFailedDownloadUrl(
        downloadId: Long,
        newUrl: String,
    ): Result<ProductImageDownloadEntity> = withContext(Dispatchers.IO) {
        val trimmed = newUrl.trim()
        val validation = RemoteImageUrlValidator.validateSyntax(trimmed)
        if (!validation.isValid) {
            return@withContext Result.failure(IllegalArgumentException(validation.errorReason ?: "الرابط البديل غير صالح"))
        }
        val existing = db.productDao().getImageDownloadsByIdsOnce(listOf(downloadId)).firstOrNull()
            ?: return@withContext Result.failure(IllegalArgumentException("سجل التحميل غير موجود"))

        val refreshed = existing.copy(
            sourceUrl = validation.normalizedUrl,
            status = ImageDownloadStatus.PENDING.name,
            failureReason = "",
            failureCategory = "",
            httpStatusCode = 0,
            updatedAt = System.currentTimeMillis(),
        )
        db.productDao().updateImageDownload(refreshed)
        val retryRes = retryFailedImageDownloads(downloadIds = listOf(downloadId))
        val updated = retryRes.updatedRecords.firstOrNull()
            ?: db.productDao().getImageDownloadsByIdsOnce(listOf(downloadId)).firstOrNull()
            ?: refreshed
        Result.success(updated)
    }

    /**
     * Fallback 4: Fetch images for failed records via an official, authorized HTTPS source API
     * (never bypassing access controls; requires valid HTTPS endpoint + optional user-provided API credential
     * strictly locked to the official API host).
     */
    suspend fun retryFailedUsingAuthorizedApi(
        config: OfficialApiImageConfig,
        downloadIds: List<Long>? = null,
        batchId: String? = null,
        transportOverride: RemoteImageTransport? = null,
    ): RetryImageDownloadsResult = withContext(Dispatchers.IO) {
        val rawEndpoint = config.endpointOrTemplate.trim()
        val endpointForValidation = rawEndpoint
            .replace("{barcode}", "0000")
            .replace("{sku}", "0000")
        val syntax = RemoteImageUrlValidator.validateSyntax(endpointForValidation)
        require(syntax.isValid) { syntax.errorReason ?: "عنوان واجهة الـ API غير صالح" }
        require(syntax.normalizedUrl.startsWith("https://", ignoreCase = true)) {
            "يجب أن يستخدم API الرسمي اتصالاً مشفراً HTTPS لحماية بيانات التفويض"
        }
        val apiHost = URI(syntax.normalizedUrl).host?.lowercase().orEmpty()
        require(apiHost.isNotBlank()) { "عنوان مضيف API غير صالح" }

        val productDao = db.productDao()
        val targets = when {
            !downloadIds.isNullOrEmpty() -> productDao.getImageDownloadsByIdsOnce(downloadIds)
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
            !batchId.isNullOrBlank() -> productDao.getImageDownloadsByBatchOnce(batchId)
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
            else -> productDao.getPendingOrFailedImageDownloadsOnce()
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
        }
        if (targets.isEmpty()) {
            return@withContext RetryImageDownloadsResult(0, 0, 0, 0, emptyList())
        }

        val apiHeader = config.authHeaderValue.trim().takeIf { it.isNotEmpty() }?.let { token ->
            AuthorizedApiHeader(
                allowedHost = apiHost,
                headerName = config.authHeaderName.trim().ifBlank { "Authorization" },
                headerValue = token,
            )
        }
        val effectiveTransport = transportOverride ?: HttpUrlRemoteImageTransport(
            authorizedApiHeader = apiHeader,
            acceptHeader = "application/json,image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8",
        )
        val authorizedDownloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = effectiveTransport,
        )

        val productsMap = productDao.getAllProductsWithDetailsOnce().associateBy { it.product.id }
        val isPerItemTemplate = rawEndpoint.contains("{barcode}") || rawEndpoint.contains("{sku}")
        val updatedTasks = mutableListOf<ProductImageDownloadEntity>()

        if (!isPerItemTemplate) {
            // Catalog JSON endpoint mode: fetch JSON map of barcode/sku -> image_url once via authorized transport
            val resp = effectiveTransport.fetch(
                syntax.normalizedUrl,
                RemoteImageDownloader.DEFAULT_CONNECT_TIMEOUT_MS,
                RemoteImageDownloader.DEFAULT_READ_TIMEOUT_MS,
                RemoteImageDownloader.DEFAULT_MAX_FILE_BYTES,
            )
            if (resp.statusCode !in 200..299) {
                throw IllegalStateException("استجابة الـ API الرسمي غير ناجحة (HTTP ${resp.statusCode})")
            }
            val urlMap = parseOfficialApiCatalogJson(resp.bytes.toString(Charsets.UTF_8))
            for (t in targets) {
                val p = productsMap[t.productId]
                val lookupKeys = buildList {
                    if (t.barcode.isNotBlank()) add(t.barcode.trim())
                    p?.barcodes?.forEach { b -> add(b.barcodeValue.trim()) }
                    p?.product?.internalCode?.takeIf { it.isNotBlank() }?.let { add(it.trim()) }
                }.distinct()
                val mappedUrl = lookupKeys.firstNotNullOfOrNull { k -> urlMap[k] }
                if (!mappedUrl.isNullOrBlank()) {
                    val prepared = t.copy(
                        sourceUrl = mappedUrl,
                        status = ImageDownloadStatus.PENDING.name,
                        failureReason = "",
                        failureCategory = "",
                        updatedAt = System.currentTimeMillis(),
                    )
                    productDao.updateImageDownload(prepared)
                    updatedTasks.add(prepared)
                }
            }
        } else {
            for (t in targets) {
                val p = productsMap[t.productId]
                val barcodeVal = t.barcode.ifBlank { p?.primaryBarcode?.barcodeValue.orEmpty() }
                val skuVal = p?.product?.internalCode?.ifBlank { barcodeVal } ?: barcodeVal
                val encodedBarcode = URLEncoder.encode(barcodeVal, "UTF-8")
                val encodedSku = URLEncoder.encode(skuVal, "UTF-8")
                val itemUrl = rawEndpoint
                    .replace("{barcode}", encodedBarcode)
                    .replace("{sku}", encodedSku)
                val prepared = t.copy(
                    sourceUrl = itemUrl,
                    status = ImageDownloadStatus.PENDING.name,
                    failureReason = "",
                    failureCategory = "",
                    updatedAt = System.currentTimeMillis(),
                )
                productDao.updateImageDownload(prepared)
                updatedTasks.add(prepared)
            }
        }

        if (updatedTasks.isEmpty()) {
            return@withContext RetryImageDownloadsResult(targets.size, 0, targets.size, 0, emptyList())
        }

        val finished = processImageDownloadQueue(updatedTasks, downloaderOverride = authorizedDownloader)
        RetryImageDownloadsResult(
            totalAttempted = updatedTasks.size,
            succeededCount = finished.count { it.status == ImageDownloadStatus.SUCCESS.name },
            failedCount = finished.count { it.status == ImageDownloadStatus.FAILED.name },
            skippedCount = finished.count { it.status == ImageDownloadStatus.SKIPPED.name },
            updatedRecords = finished,
        )
    }

    private fun parseOfficialApiCatalogJson(jsonText: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) return result

        fun extractFromObject(obj: JSONObject) {
            val url = listOf("image_url", "imageUrl", "url", "image", "photo")
                .firstNotNullOfOrNull { k -> obj.optString(k).trim().takeIf { it.isNotEmpty() } }
                ?: return
            val keys = listOfNotNull(
                obj.optString("barcode").trim().takeIf { it.isNotEmpty() },
                obj.optString("sku").trim().takeIf { it.isNotEmpty() },
                obj.optString("internalCode").trim().takeIf { it.isNotEmpty() },
                obj.optString("code").trim().takeIf { it.isNotEmpty() },
            )
            keys.forEach { result[it] = url }
        }

        try {
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { extractFromObject(it) }
                }
            } else if (trimmed.startsWith("{")) {
                val root = JSONObject(trimmed)
                val nestedArray = root.optJSONArray("items")
                    ?: root.optJSONArray("products")
                    ?: root.optJSONArray("data")
                if (nestedArray != null) {
                    for (i in 0 until nestedArray.length()) {
                        nestedArray.optJSONObject(i)?.let { extractFromObject(it) }
                    }
                } else {
                    val keys = root.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        when (val v = root.opt(k)) {
                            is String -> if (v.startsWith("http", ignoreCase = true)) result[k] = v
                            is JSONObject -> {
                                val u = listOf("image_url", "imageUrl", "url", "image")
                                    .firstNotNullOfOrNull { f -> v.optString(f).trim().takeIf { it.isNotEmpty() } }
                                if (u != null) result[k] = u
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    /**
     * Fallback 5: Server-side batch image fetch via user's companion HTTPS Backend Service (`POST /api/images/fetch-batch`).
     * Downloads happen on the server instead of Android client, and returned bytes are locally re-verified before saving.
     */
    suspend fun retryFailedViaBackendService(
        config: BackendImageSyncService.BackendServerConfig,
        downloadIds: List<Long>? = null,
        batchId: String? = null,
        backendServiceOverride: BackendImageSyncService? = null,
    ): RetryImageDownloadsResult = withContext(Dispatchers.IO) {
        val productDao = db.productDao()
        val targets = when {
            !downloadIds.isNullOrEmpty() -> productDao.getImageDownloadsByIdsOnce(downloadIds)
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
            !batchId.isNullOrBlank() -> productDao.getImageDownloadsByBatchOnce(batchId)
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
            else -> productDao.getPendingOrFailedImageDownloadsOnce()
                .filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
        }
        if (targets.isEmpty()) {
            return@withContext RetryImageDownloadsResult(0, 0, 0, 0, emptyList())
        }

        val service = backendServiceOverride ?: backendSyncService
        val updatedRecords = mutableListOf<ProductImageDownloadEntity>()
        val targetMap = targets.associateBy { it.id }

        for (chunk in targets.chunked(25)) {
            val reqItems = chunk.map {
                BackendImageSyncService.BackendBatchFetchItem(
                    downloadId = it.id,
                    url = it.sourceUrl.trim(),
                    gtin = it.barcode,
                    productName = it.productName,
                )
            }
            val batchResp = service.fetchImagesViaBackend(config, reqItems).getOrThrow()
            for (itemRes in batchResp) {
                val task = targetMap[itemRes.downloadId] ?: continue
                val bytes = itemRes.bytes
                if (itemRes.ok && bytes != null && itemRes.detectedFormat.isNotBlank()) {
                    val stored = mediaStorage.saveDownloadedImageBytes(bytes, itemRes.detectedFormat)
                    if (stored != null && File(stored.activePath).exists() && File(stored.thumbnailPath).exists()) {
                        val applied = applyDownloadedImageToProduct(
                            task = task,
                            storedFiles = stored,
                            normalizedUrl = task.sourceUrl.trim(),
                            contentHash = RemoteImageDownloader.sha256Hex(bytes),
                            fileSizeBytes = bytes.size.toLong(),
                            detectedFormat = itemRes.detectedFormat,
                            finalUrl = itemRes.finalUrl.ifBlank { task.sourceUrl },
                            httpStatusCode = itemRes.statusCode.takeIf { it > 0 } ?: 200,
                            diagnosticLog = "Fetched via Backend Service (${itemRes.detectedFormat.uppercase()})",
                            forceApplyOverExistingPolicy = true,
                        )
                        updatedRecords.add(applied)
                        continue
                    }
                }
                val now = System.currentTimeMillis()
                val failedKind = itemRes.failureKind ?: RemoteImageFailureKind.NETWORK_ERROR
                val failedRec = task.copy(
                    status = ImageDownloadStatus.FAILED.name,
                    failureReason = itemRes.failureReason.ifBlank { failedKind.arabicLabel },
                    failureCategory = failedKind.arabicLabel,
                    httpStatusCode = itemRes.statusCode,
                    finalUrl = itemRes.finalUrl.ifBlank { task.sourceUrl },
                    diagnosticLog = "Backend fetch failed (HTTP ${itemRes.statusCode})",
                    attemptCount = task.attemptCount + 1,
                    updatedAt = now,
                )
                productDao.updateImageDownload(failedRec)
                updatedRecords.add(failedRec)
            }
        }

        RetryImageDownloadsResult(
            totalAttempted = targets.size,
            succeededCount = updatedRecords.count { it.status == ImageDownloadStatus.SUCCESS.name },
            failedCount = updatedRecords.count { it.status == ImageDownloadStatus.FAILED.name },
            skippedCount = updatedRecords.count { it.status == ImageDownloadStatus.SKIPPED.name },
            updatedRecords = updatedRecords,
        )
    }

    /**
     * Fallback 6: Sync product images directly from Salla Merchant API via the Backend Service OAuth 2.0 session.
     * Matches Salla products strictly by GTIN/barcode/SKU (never by name alone) and saves multiple gallery images per product.
     */
    suspend fun syncSallaCatalogViaBackend(
        config: BackendImageSyncService.BackendServerConfig,
        batchId: String? = null,
        createMissingProducts: Boolean = false,
        backendServiceOverride: BackendImageSyncService? = null,
    ): SallaCatalogSyncReport = withContext(Dispatchers.IO) {
        val service = backendServiceOverride ?: backendSyncService
        val productDao = db.productDao()
        val sallaProducts = service.fetchSallaCatalogProducts(config, page = 1, perPage = 100, downloadImages = true)
            .getOrThrow()

        val allLocal = productDao.getAllProductsWithDetailsOnce().toMutableList()
        val barcodeToProd = allLocal.flatMap { p ->
            p.barcodes.map { b -> b.barcodeValue.trim().lowercase(Locale.ROOT) to p }
        }.toMap(mutableMapOf())
        val skuToProd = allLocal.filter { it.product.internalCode.isNotBlank() }
            .associateBy { it.product.internalCode.trim().lowercase(Locale.ROOT) }
            .toMutableMap()

        val pendingOrFailed = if (!batchId.isNullOrBlank()) {
            productDao.getImageDownloadsByBatchOnce(batchId)
        } else {
            productDao.getPendingOrFailedImageDownloadsOnce()
        }.filter { it.status == ImageDownloadStatus.FAILED.name || it.status == ImageDownloadStatus.PENDING.name }
            .groupBy { it.productId }

        var matchedCount = 0
        var createdCount = 0
        var linkedImagesCount = 0
        var failedImagesCount = 0
        val errors = mutableListOf<String>()

        for (sp in sallaProducts) {
            val lookupKeys = listOf(sp.gtin, sp.barcode, sp.sku)
                .map { it.trim().lowercase(Locale.ROOT) }
                .filter { it.isNotEmpty() }
            var target = lookupKeys.firstNotNullOfOrNull { barcodeToProd[it] ?: skuToProd[it] }

            if (target == null && createMissingProducts && sp.name.isNotBlank()) {
                val now = System.currentTimeMillis()
                val newId = productDao.insertProduct(
                    ProductEntity(
                        internalCode = sp.sku.ifBlank { "SALLA-${sp.sallaProductId}" },
                        name = sp.name,
                        createdAt = now,
                        updatedAt = now,
                    ),
                )
                val primaryBc = sp.gtin.ifBlank { sp.barcode }
                if (primaryBc.isNotBlank()) {
                    val savedDefault = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                        db.settingsDao().getSettingsOnce()?.defaultBarcodeType,
                    ) ?: BarcodeFormatType.CODE_128
                    val inferredFmt = inferBarcodeFormat(primaryBc, preferredDefault = savedDefault)
                    productDao.insertBarcode(
                        ProductBarcodeEntity(
                            productId = newId,
                            barcodeValue = primaryBc,
                            barcodeType = inferredFmt.name,
                            label = "GTIN",
                            isPrimary = true,
                            updatedAt = now,
                        ),
                    )
                }
                target = productDao.getProductWithDetails(newId)
                if (target != null) {
                    createdCount++
                    allLocal.add(target)
                    if (primaryBc.isNotBlank()) barcodeToProd[primaryBc.lowercase(Locale.ROOT)] = target
                    if (target.product.internalCode.isNotBlank()) {
                        skuToProd[target.product.internalCode.lowercase(Locale.ROOT)] = target
                    }
                }
            }

            if (target == null) continue
            matchedCount++

            val targetTasks = pendingOrFailed[target.product.id].orEmpty()
            var taskIdx = 0
            val mediaItems = sp.downloadedImages
            mediaItems.forEach { media ->
                val bytes = media.bytes
                if (media.ok && bytes != null && media.detectedFormat.isNotBlank()) {
                    val linkedViaTask = targetTasks.getOrNull(taskIdx)
                    if (linkedViaTask != null) {
                        val stored = mediaStorage.saveDownloadedImageBytes(bytes, media.detectedFormat)
                        if (stored != null) {
                            applyDownloadedImageToProduct(
                                task = linkedViaTask,
                                storedFiles = stored,
                                normalizedUrl = media.url,
                                contentHash = RemoteImageDownloader.sha256Hex(bytes),
                                fileSizeBytes = bytes.size.toLong(),
                                detectedFormat = media.detectedFormat,
                                finalUrl = media.url,
                                httpStatusCode = media.statusCode.takeIf { it > 0 } ?: 200,
                                diagnosticLog = "Synced via Salla Merchant API",
                                forceApplyOverExistingPolicy = true,
                            )
                            linkedImagesCount++
                        } else {
                            failedImagesCount++
                        }
                        taskIdx++
                    } else if (attachAdditionalImageBytesToProduct(
                            productId = target.product.id,
                            bytes = bytes,
                            matchedBarcode = sp.gtin.ifBlank { sp.barcode },
                            sourceUrl = media.url,
                        )
                    ) {
                        linkedImagesCount++
                    } else {
                        failedImagesCount++
                    }
                } else {
                    failedImagesCount++
                    errors.add("${sp.name}: ${media.failureReason.ifBlank { "تعذر تنزيل الصورة" }}")
                }
            }
        }

        SallaCatalogSyncReport(
            fetchedProductsCount = sallaProducts.size,
            matchedProductsCount = matchedCount,
            createdProductsCount = createdCount,
            linkedImagesCount = linkedImagesCount,
            failedImagesCount = failedImagesCount,
            errors = errors,
        )
    }

    private fun deleteStoredTriplet(stored: StoredImageFiles) {
        mediaStorage.deleteFileIfInternal(stored.activePath)
        mediaStorage.deleteFileIfInternal(stored.originalPath)
        mediaStorage.deleteFileIfInternal(stored.thumbnailPath)
    }

    /**
     * Executes atomic transactional import directly (delegates through buildPreImportReviewDraft + commitReviewedImport).
     */
    suspend fun executeImport(
        sheet: ParsedSheetData,
        mappings: Map<Int, ProductImportField>,
        hasHeaderRow: Boolean,
        policy: ImportDuplicatePolicy,
        defaultCurrency: String = "ر.س",
        onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
    ): ExcelImportFinalReport = withContext(Dispatchers.IO) {
        val draft = buildPreImportReviewDraft(sheet, mappings, hasHeaderRow, policy, defaultCurrency)
        commitReviewedImport(draft, onProgress)
    }

    companion object {
        private const val MAX_CONCURRENT_IMAGE_DOWNLOADS = 3
        private const val MAX_CONCURRENT_PER_HOST = 2
        private const val IMAGE_DOWNLOAD_BATCH_SIZE = 20
        private val SCIENTIFIC_BARCODE_REGEX = Regex("""^\d+(?:\.\d+)?[Ee][+-]?\d+$""")

        /**
         * Parses one or more URLs from a spreadsheet cell (e.g. newline/semicolon/pipe/whitespace-separated URLs,
         * or comma-separated `url1,https://url2` without breaking Cloudflare resize parameters like `,quality=80`).
         */
        fun splitCellImageUrls(raw: String): List<String> {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) return emptyList()
            val roughTokens = trimmed
                .split('\n', '\r', ';', '|')
                .flatMap { it.trim().split(Regex("\\s+")) }
                .flatMap { token ->
                    if (token.contains(",http://", ignoreCase = true) || token.contains(",https://", ignoreCase = true)) {
                        token.split(Regex(",(?=https?://)", RegexOption.IGNORE_CASE))
                    } else {
                        listOf(token)
                    }
                }
                .map { it.trim().trimEnd(',') }
                .filter { it.isNotEmpty() }
            if (roughTokens.isEmpty()) return emptyList()
            val hasHttp = roughTokens.any { it.startsWith("http://", true) || it.startsWith("https://", true) }
            return if (hasHttp) roughTokens.distinct() else listOf(trimmed)
        }
    }

    private fun inferBarcodeFormat(
        value: String,
        explicitFormatRaw: String = "",
        preferredDefault: BarcodeFormatType = BarcodeFormatType.CODE_128,
    ): BarcodeFormatType {
        val explicitParsed = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(explicitFormatRaw)
        if (explicitParsed != null && com.example.domain.barcode.BarcodeEngine.isCompatible(value, explicitParsed)) {
            return explicitParsed
        }
        return com.example.domain.barcode.BarcodeEngine.resolveCompatibleDefaultFormat(
            value = value,
            preferredDefault = preferredDefault,
        )
    }

    // ==================== XLSX Streaming OOXML Parser ====================

    private fun parseXlsx(bytes: ByteArray): List<ParsedSheetData> {
        val entries = mutableMapOf<String, ByteArray>()
        val maxEntryBytes = 24 * 1024 * 1024
        val maxTotalBytes = 96 * 1024 * 1024
        var totalDecoded = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val out = ByteArrayOutputStream()
                    val buf = ByteArray(16 * 1024)
                    var entryLen = 0
                    while (true) {
                        val read = zis.read(buf)
                        if (read <= 0) break
                        entryLen += read
                        totalDecoded += read
                        if (entryLen > maxEntryBytes || totalDecoded > maxTotalBytes) {
                            throw IllegalStateException("حجم بيانات المصنف XLSX يتجاوز الحد الآمن للذاكرة (${entry.name})")
                        }
                        out.write(buf, 0, read)
                    }
                    entries[entry.name.trimStart('/')] = out.toByteArray()
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val workbookSheets = entries["xl/workbook.xml"]?.let { parseWorkbookSheetList(it, entries["xl/_rels/workbook.xml.rels"]) }
            ?: listOf("Sheet1" to "xl/worksheets/sheet1.xml")

        return workbookSheets.mapNotNull { (sheetName, sheetPath) ->
            val sheetBytes = entries[sheetPath] ?: return@mapNotNull null
            val sheetFileName = sheetPath.substringAfterLast('/')
            val sheetDir = sheetPath.substringBeforeLast('/', "")
            val sheetRelsPath = if (sheetDir.isEmpty()) "_rels/$sheetFileName.rels" else "$sheetDir/_rels/$sheetFileName.rels"
            val sheetRels = parseRelationships(entries[sheetRelsPath])
            val rows = parseWorksheetXml(sheetBytes, sharedStrings, sheetRels)
            val headers = rows.firstOrNull()?.mapIndexed { idx, v -> v.ifBlank { "عمود ${idx + 1}" } }.orEmpty()
            val images = extractXlsxSheetImages(sheetPath, entries)
            ParsedSheetData(
                sheetName = sheetName,
                headers = headers,
                rows = rows,
                extractedImages = images,
            )
        }
    }

    private fun parseSharedStrings(xmlBytes: ByteArray): List<String> {
        val list = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
        var inSi = false
        var inT = false
        val current = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "si" -> {
                            inSi = true
                            current.clear()
                        }
                        "t" -> if (inSi) inT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inSi && inT) current.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "t" -> inT = false
                        "si" -> {
                            list.add(current.toString())
                            inSi = false
                        }
                    }
                }
            }
            event = parser.next()
        }
        return list
    }

    private fun parseWorkbookSheetList(
        workbookBytes: ByteArray,
        relsBytes: ByteArray?,
    ): List<Pair<String, String>> {
        val relMap = parseRelationships(relsBytes)
        val result = mutableListOf<Pair<String, String>>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(workbookBytes), "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "sheet") {
                val name = parser.getAttributeValue(null, "name") ?: "Sheet"
                val rId = parser.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id")
                    ?: parser.getAttributeValue(null, "r:id")
                val target = rId?.let { relMap[it] }?.let { normalizeXlPath("xl/", it) }
                    ?: "xl/worksheets/sheet${result.size + 1}.xml"
                result.add(name to target)
            }
            event = parser.next()
        }
        return result
    }

    private fun parseRelationships(relsBytes: ByteArray?): Map<String, String> {
        if (relsBytes == null) return emptyMap()
        val map = mutableMapOf<String, String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(relsBytes), "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "Relationship") {
                val id = parser.getAttributeValue(null, "Id")
                val target = parser.getAttributeValue(null, "Target")
                if (id != null && target != null) {
                    map[id] = target
                }
            }
            event = parser.next()
        }
        return map
    }

    private fun parseWorksheetXml(
        sheetBytes: ByteArray,
        sharedStrings: List<String>,
        sheetRels: Map<String, String> = emptyMap(),
    ): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(sheetBytes), "UTF-8")

        var currentRow = mutableMapOf<Int, String>()
        var currentRowIndex = 0
        var currentColIdx = 0
        var cellType = ""
        var inV = false
        var inF = false
        var inIs = false
        var inT = false
        val valueBuilder = StringBuilder()
        val formulaBuilder = StringBuilder()
        var maxCols = 0
        val cellHyperlinks = mutableListOf<Triple<Int, Int, String>>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> {
                            currentRow = mutableMapOf()
                            currentRowIndex = parser.getAttributeValue(null, "r")?.toIntOrNull()?.minus(1) ?: rows.size
                        }
                        "c" -> {
                            val ref = parser.getAttributeValue(null, "r").orEmpty()
                            currentColIdx = if (ref.isNotEmpty()) columnIndexFromRef(ref) else currentRow.size
                            cellType = parser.getAttributeValue(null, "t").orEmpty()
                            valueBuilder.clear()
                            formulaBuilder.clear()
                        }
                        "v" -> inV = true
                        "f" -> inF = true
                        "is" -> inIs = true
                        "t" -> if (inIs) inT = true
                        "hyperlink" -> {
                            val ref = parser.getAttributeValue(null, "ref").orEmpty()
                            val rId = parser.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id")
                                ?: parser.getAttributeValue(null, "r:id")
                            val target = rId?.let { sheetRels[it] }.orEmpty()
                            if (ref.isNotEmpty() && target.startsWith("http", ignoreCase = true)) {
                                val (rIdx, cIdx) = cellCoordsFromRef(ref)
                                if (rIdx >= 0 && cIdx >= 0) {
                                    cellHyperlinks.add(Triple(rIdx, cIdx, target))
                                }
                            }
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inV || (inIs && inT)) {
                        valueBuilder.append(parser.text)
                    } else if (inF) {
                        formulaBuilder.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> inV = false
                        "f" -> inF = false
                        "t" -> inT = false
                        "is" -> inIs = false
                        "c" -> {
                            val raw = valueBuilder.toString()
                            val cachedVal = when (cellType) {
                                "s" -> raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty()
                                "inlineStr", "str", "e" -> raw
                                "b" -> if (raw == "1") "TRUE" else "FALSE"
                                else -> normalizeNumericTextPreservingIntegrity(raw)
                            }
                            val formulaUrl = extractHyperlinkFormulaUrl(formulaBuilder.toString())
                            val resolved = when {
                                cachedVal.startsWith("http://", true) || cachedVal.startsWith("https://", true) -> cachedVal
                                formulaUrl != null -> formulaUrl
                                else -> cachedVal
                            }
                            if (resolved.isNotEmpty()) {
                                currentRow[currentColIdx] = resolved
                                if (currentColIdx + 1 > maxCols) maxCols = currentColIdx + 1
                            }
                        }
                        "row" -> {
                            while (rows.size < currentRowIndex) {
                                rows.add(mutableListOf())
                            }
                            val rowMax = (currentRow.keys.maxOrNull() ?: -1) + 1
                            if (rowMax > 0) {
                                val list = MutableList(maxOf(maxCols, rowMax)) { col -> currentRow[col].orEmpty() }
                                rows.add(list)
                            } else {
                                rows.add(mutableListOf())
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }

        // Apply explicit worksheet <hyperlink> targets when cell text wasn't already an HTTP(S) URL
        cellHyperlinks.forEach { (rIdx, cIdx, url) ->
            if (rIdx in rows.indices) {
                val targetRow = rows[rIdx]
                while (targetRow.size <= cIdx) targetRow.add("")
                if (cIdx + 1 > maxCols) maxCols = cIdx + 1
                val existingVal = targetRow[cIdx].trim()
                if (!existingVal.startsWith("http://", true) && !existingVal.startsWith("https://", true)) {
                    targetRow[cIdx] = url
                }
            }
        }

        return rows.map { r ->
            if (r.size >= maxCols) r else r + List(maxCols - r.size) { "" }
        }
    }

    private fun extractHyperlinkFormulaUrl(formula: String): String? {
        if (formula.isBlank()) return null
        val match = Regex("""HYPERLINK\s*\(\s*"([^"]+)"\s*(?:,|;|\))""", RegexOption.IGNORE_CASE).find(formula)
            ?: return null
        val url = match.groupValues.getOrNull(1)?.trim().orEmpty()
        return url.takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) }
    }

    private fun cellCoordsFromRef(ref: String): Pair<Int, Int> {
        val col = columnIndexFromRef(ref)
        val digits = ref.dropWhile { it.isLetter() }
        val row = (digits.toIntOrNull()?.minus(1)) ?: -1
        return row to col
    }

    private fun normalizeBarcodeCellValue(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        if (SCIENTIFIC_BARCODE_REGEX.matches(trimmed)) {
            return runCatching {
                val bd = BigDecimal(trimmed).stripTrailingZeros()
                if (bd.scale() <= 0) bd.toPlainString() else trimmed
            }.getOrDefault(trimmed)
        }
        return trimmed
    }

    private fun normalizeNumericTextPreservingIntegrity(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        // Convert plain integer-valued floating representations like "12345.0" cleanly without losing digits
        return try {
            if (trimmed.contains('.') && !trimmed.contains('E', true)) {
                val bd = BigDecimal(trimmed).stripTrailingZeros()
                if (bd.scale() <= 0) bd.toPlainString() else bd.toPlainString()
            } else if (trimmed.contains('E', true)) {
                BigDecimal(trimmed).stripTrailingZeros().toPlainString()
            } else {
                trimmed
            }
        } catch (_: Exception) {
            trimmed
        }
    }

    private fun extractXlsxSheetImages(
        sheetPath: String,
        entries: Map<String, ByteArray>,
    ): List<ExtractedExcelImage> {
        val sheetFileName = sheetPath.substringAfterLast('/')
        val sheetDir = sheetPath.substringBeforeLast('/', "")
        val sheetRelsPath = if (sheetDir.isEmpty()) "_rels/$sheetFileName.rels" else "$sheetDir/_rels/$sheetFileName.rels"
        val sheetRels = parseRelationships(entries[sheetRelsPath])
        val drawingTargets = sheetRels.values.filter { it.contains("drawing", ignoreCase = true) }
        if (drawingTargets.isEmpty()) return emptyList()

        val images = mutableListOf<ExtractedExcelImage>()
        drawingTargets.forEach { target ->
            val drawingPath = normalizeXlPath("$sheetDir/", target)
            val drawingBytes = entries[drawingPath] ?: return@forEach
            val drawingName = drawingPath.substringAfterLast('/')
            val drawingDir = drawingPath.substringBeforeLast('/', "")
            val drawingRelsPath = "$drawingDir/_rels/$drawingName.rels"
            val drawingRels = parseRelationships(entries[drawingRelsPath])

            val anchors = parseDrawingAnchors(drawingBytes)
            anchors.forEachIndexed { idx, anchor ->
                val mediaTarget = drawingRels[anchor.embedRId] ?: return@forEachIndexed
                val mediaPath = normalizeXlPath("$drawingDir/", mediaTarget)
                val imgBytes = entries[mediaPath] ?: return@forEachIndexed
                images.add(
                    ExtractedExcelImage(
                        id = "${drawingName}_${idx}_${anchor.embedRId}",
                        fileName = mediaPath.substringAfterLast('/'),
                        bytes = imgBytes,
                        anchoredRowZeroBased = anchor.row,
                        anchoredColZeroBased = anchor.col,
                    ),
                )
            }
        }
        return images
    }

    private data class DrawingAnchor(val row: Int?, val col: Int?, val embedRId: String)

    private fun parseDrawingAnchors(drawingBytes: ByteArray): List<DrawingAnchor> {
        val list = mutableListOf<DrawingAnchor>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(drawingBytes), "UTF-8")

        var inAnchor = false
        var inFrom = false
        var inCol = false
        var inRow = false
        var anchorRow: Int? = null
        var anchorCol: Int? = null
        var embedId: String? = null
        val textBuf = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val localName = parser.name.substringAfter(':')
                    when (localName) {
                        "twoCellAnchor", "oneCellAnchor" -> {
                            inAnchor = true
                            anchorRow = null
                            anchorCol = null
                            embedId = null
                        }
                        "from" -> if (inAnchor) inFrom = true
                        "col" -> if (inFrom) {
                            inCol = true
                            textBuf.clear()
                        }
                        "row" -> if (inFrom) {
                            inRow = true
                            textBuf.clear()
                        }
                        "blip" -> if (inAnchor) {
                            embedId = parser.getAttributeValue(
                                "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
                                "embed",
                            ) ?: parser.getAttributeValue(null, "r:embed")
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inCol || inRow) textBuf.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    val localName = parser.name.substringAfter(':')
                    when (localName) {
                        "col" -> {
                            if (inCol) {
                                anchorCol = textBuf.toString().trim().toIntOrNull()
                                inCol = false
                            }
                        }
                        "row" -> {
                            if (inRow) {
                                anchorRow = textBuf.toString().trim().toIntOrNull()
                                inRow = false
                            }
                        }
                        "from" -> inFrom = false
                        "twoCellAnchor", "oneCellAnchor" -> {
                            val validEmbed = embedId
                            if (inAnchor && validEmbed != null) {
                                list.add(DrawingAnchor(anchorRow, anchorCol, validEmbed))
                            }
                            inAnchor = false
                        }
                    }
                }
            }
            event = parser.next()
        }
        return list
    }

    private fun columnIndexFromRef(ref: String): Int {
        var col = 0
        for (ch in ref) {
            if (ch.isLetter()) {
                col = col * 26 + (ch.uppercaseChar() - 'A' + 1)
            } else {
                break
            }
        }
        return (col - 1).coerceAtLeast(0)
    }

    private fun normalizeXlPath(baseDir: String, target: String): String {
        val raw = if (target.startsWith("/")) target.trimStart('/') else "$baseDir$target"
        val parts = mutableListOf<String>()
        raw.split('/').forEach { part ->
            when (part) {
                "", "." -> Unit
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
                else -> parts.add(part)
            }
        }
        return parts.joinToString("/")
    }

    // ==================== XLS (Apache POI HSSF) Parser ====================

    private fun parseXls(bytes: ByteArray): List<ParsedSheetData> {
        HSSFWorkbook(ByteArrayInputStream(bytes)).use { workbook ->
            val formatter = DataFormatter(Locale.US)
            val sheets = mutableListOf<ParsedSheetData>()
            for (sIdx in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(sIdx)
                val rowList = mutableListOf<List<String>>()
                var maxCols = 0
                for (rIdx in 0..sheet.lastRowNum) {
                    val row = sheet.getRow(rIdx)
                    if (row == null) {
                        rowList.add(emptyList())
                        continue
                    }
                    val lastCol = row.lastCellNum.toInt().coerceAtLeast(0)
                    if (lastCol > maxCols) maxCols = lastCol
                    val vals = (0 until lastCol).map { cIdx ->
                        val cell = row.getCell(cIdx)
                        if (cell == null) {
                            ""
                        } else {
                            val formatted = if (cell.cellTypeEnum == CellType.NUMERIC) {
                                val rawFormatted = formatter.formatCellValue(cell).trim()
                                if (rawFormatted.contains('E', true) || rawFormatted.endsWith(".0")) {
                                    runCatching { BigDecimal.valueOf(cell.numericCellValue).stripTrailingZeros().toPlainString() }
                                        .getOrDefault(rawFormatted)
                                } else {
                                    rawFormatted
                                }
                            } else {
                                formatter.formatCellValue(cell).trim()
                            }
                            val linkAddr = runCatching { cell.hyperlink?.address?.trim() }.getOrNull().orEmpty()
                            if (!formatted.startsWith("http://", true) &&
                                !formatted.startsWith("https://", true) &&
                                (linkAddr.startsWith("http://", true) || linkAddr.startsWith("https://", true))
                            ) {
                                linkAddr
                            } else {
                                formatted
                            }
                        }
                    }
                    rowList.add(vals)
                }
                val padded = rowList.map { r -> if (r.size >= maxCols) r else r + List(maxCols - r.size) { "" } }
                val headers = padded.firstOrNull()?.mapIndexed { idx, v -> v.ifBlank { "عمود ${idx + 1}" } }.orEmpty()

                val extractedImages = mutableListOf<ExtractedExcelImage>()
                val patriarch = sheet.drawingPatriarch
                if (patriarch != null) {
                    patriarch.children.forEachIndexed { idx, shape ->
                        if (shape is HSSFPicture) {
                            val anchor = shape.anchor as? HSSFClientAnchor
                            val picData = shape.pictureData
                            extractedImages.add(
                                ExtractedExcelImage(
                                    id = "xls_${sIdx}_$idx",
                                    fileName = "xls_img_$idx.${picData.suggestFileExtension()}",
                                    bytes = picData.data,
                                    anchoredRowZeroBased = anchor?.row1,
                                    anchoredColZeroBased = anchor?.col1?.toInt(),
                                ),
                            )
                        }
                    }
                }
                sheets.add(
                    ParsedSheetData(
                        sheetName = sheet.sheetName,
                        headers = headers,
                        rows = padded,
                        extractedImages = extractedImages,
                    ),
                )
            }
            return sheets
        }
    }

    // ==================== CSV RFC-4180 Parser ====================

    private fun parseCsv(bytes: ByteArray): ParsedSheetData {
        var text = bytes.toString(Charsets.UTF_8)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val rows = parseCsvRows(text)
        val maxCols = rows.maxOfOrNull { it.size } ?: 0
        val padded = rows.map { r -> if (r.size >= maxCols) r else r + List(maxCols - r.size) { "" } }
        val headers = padded.firstOrNull()?.mapIndexed { idx, v -> v.ifBlank { "عمود ${idx + 1}" } }.orEmpty()
        return ParsedSheetData(
            sheetName = "CSV",
            headers = headers,
            rows = padded,
            extractedImages = emptyList(),
        )
    }

    private fun parseCsvRows(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var currentRow = mutableListOf<String>()
        val cell = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        cell.append('"')
                        i += 2
                        continue
                    } else {
                        inQuotes = false
                    }
                } else {
                    cell.append(ch)
                }
            } else {
                when (ch) {
                    '"' -> inQuotes = true
                    ',' -> {
                        currentRow.add(cell.toString().trim())
                        cell.clear()
                    }
                    '\r' -> Unit
                    '\n' -> {
                        currentRow.add(cell.toString().trim())
                        cell.clear()
                        if (currentRow.any { it.isNotEmpty() }) rows.add(currentRow)
                        currentRow = mutableListOf()
                    }
                    else -> cell.append(ch)
                }
            }
            i++
        }
        if (cell.isNotEmpty() || currentRow.isNotEmpty()) {
            currentRow.add(cell.toString().trim())
            if (currentRow.any { it.isNotEmpty() }) rows.add(currentRow)
        }
        return rows
    }

    private fun queryDisplayName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (nameIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameIdx) ?: "import.xlsx"
            }
        }
        return uri.lastPathSegment ?: "import.xlsx"
    }
}
