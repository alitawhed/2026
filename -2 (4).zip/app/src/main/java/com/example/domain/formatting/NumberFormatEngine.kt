package com.example.domain.formatting

import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnType
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.math.BigDecimal
import java.math.RoundingMode

enum class AppNumericSection(val arabicLabel: String) {
    INVENTORY("كشف الجرد"),
    REPORT("التقارير"),
    PRODUCTS("المنتجات"),
    LABELS("الملصقات"),
}

@Serializable
data class NumberFormatSpec(
    val decimalPlaces: Int = 0,
    val autoDecimals: Boolean = false,
    val stripTrailingZeros: Boolean = false,
    val useGrouping: Boolean = true,
) {
    fun normalized(): NumberFormatSpec = copy(
        decimalPlaces = decimalPlaces.coerceIn(0, 6),
    )

    fun isZeroDecimalsFixed(): Boolean = !autoDecimals && decimalPlaces == 0
}

@Serializable
data class ProductsNumericConfig(
    val quantityFormat: NumberFormatSpec = NumberFormatSpec(
        decimalPlaces = 0,
        autoDecimals = false,
        stripTrailingZeros = false,
    ),
    val priceFormat: NumberFormatSpec = NumberFormatSpec(
        decimalPlaces = 2,
        autoDecimals = false,
        stripTrailingZeros = false,
    ),
    val conversionFactorFormat: NumberFormatSpec = NumberFormatSpec(
        decimalPlaces = 2,
        autoDecimals = true,
        stripTrailingZeros = true,
    ),
)

object NumberFormatEngine {
    const val MIN_DECIMALS = 0
    const val MAX_DECIMALS = 6

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun isNumericColumnType(type: ColumnType): Boolean = type in setOf(
        ColumnType.QUANTITY,
        ColumnType.PRICE,
        ColumnType.CURRENCY,
        ColumnType.PERCENTAGE,
        ColumnType.NUMBER,
    )

    fun ColumnConfigModel.toNumberFormatSpec(useGrouping: Boolean = true): NumberFormatSpec =
        NumberFormatSpec(
            decimalPlaces = decimalPlaces.coerceIn(MIN_DECIMALS, MAX_DECIMALS),
            autoDecimals = autoDecimals,
            stripTrailingZeros = stripTrailingZeros,
            useGrouping = useGrouping,
        )

    fun ColumnConfigModel.withNumberFormatSpec(spec: NumberFormatSpec): ColumnConfigModel {
        val norm = spec.normalized()
        return copy(
            decimalPlaces = norm.decimalPlaces,
            autoDecimals = norm.autoDecimals,
            stripTrailingZeros = norm.stripTrailingZeros,
            numberFormat = when {
                norm.autoDecimals -> "AUTO"
                norm.stripTrailingZeros -> "TRIM_ZEROS"
                norm.decimalPlaces == 0 -> "INTEGER"
                else -> "DECIMAL"
            },
        )
    }

    fun defaultSpecForColumn(
        section: AppNumericSection,
        columnKey: String,
        columnType: ColumnType,
    ): NumberFormatSpec {
        if (columnKey == "conversion_factor") {
            return NumberFormatSpec(
                decimalPlaces = 2,
                autoDecimals = true,
                stripTrailingZeros = true,
            )
        }
        return when (columnType) {
            ColumnType.QUANTITY -> NumberFormatSpec(
                decimalPlaces = 0,
                autoDecimals = false,
                stripTrailingZeros = false,
            )
            ColumnType.PRICE, ColumnType.CURRENCY -> NumberFormatSpec(
                decimalPlaces = 2,
                autoDecimals = false,
                stripTrailingZeros = false,
            )
            ColumnType.PERCENTAGE -> NumberFormatSpec(
                decimalPlaces = 1,
                autoDecimals = false,
                stripTrailingZeros = true,
            )
            ColumnType.NUMBER -> when (section) {
                AppNumericSection.INVENTORY -> NumberFormatSpec(
                    decimalPlaces = 0,
                    autoDecimals = false,
                    stripTrailingZeros = false,
                )
                else -> NumberFormatSpec(
                    decimalPlaces = 2,
                    autoDecimals = true,
                    stripTrailingZeros = true,
                )
            }
            else -> NumberFormatSpec(
                decimalPlaces = 0,
                autoDecimals = false,
                stripTrailingZeros = false,
            )
        }
    }

    fun resolveInventoryColumnSpec(
        columns: List<ColumnConfigModel>,
        columnKey: String,
    ): NumberFormatSpec {
        val match = columns.firstOrNull { it.columnKey == columnKey }
            ?: if (columnKey == "quantity") columns.firstOrNull { it.columnType == ColumnType.QUANTITY } else null
        return match?.toNumberFormatSpec() ?: defaultSpecForColumn(
            AppNumericSection.INVENTORY,
            columnKey,
            if (columnKey == "conversion_factor") ColumnType.NUMBER else ColumnType.QUANTITY,
        )
    }

    fun resolveReportQuantitySpec(columns: List<ColumnConfigModel>): NumberFormatSpec {
        val match = columns.firstOrNull { it.columnKey == "qty" }
            ?: columns.firstOrNull { it.columnType == ColumnType.QUANTITY }
        return match?.toNumberFormatSpec() ?: defaultSpecForColumn(
            AppNumericSection.REPORT,
            "qty",
            ColumnType.QUANTITY,
        )
    }

    fun resolveReportPriceSpec(columns: List<ColumnConfigModel>): NumberFormatSpec {
        val match = columns.firstOrNull { it.columnKey == "price" }
            ?: columns.firstOrNull { it.columnType == ColumnType.PRICE }
            ?: columns.firstOrNull { it.columnType == ColumnType.CURRENCY }
        return match?.toNumberFormatSpec() ?: defaultSpecForColumn(
            AppNumericSection.REPORT,
            "price",
            ColumnType.PRICE,
        )
    }

    fun resolveReportTotalSpec(columns: List<ColumnConfigModel>): NumberFormatSpec {
        val match = columns.firstOrNull { it.columnKey == "total" }
            ?: columns.lastOrNull { it.columnType == ColumnType.CURRENCY }
            ?: columns.firstOrNull { it.columnType == ColumnType.PRICE }
        return match?.toNumberFormatSpec() ?: defaultSpecForColumn(
            AppNumericSection.REPORT,
            "total",
            ColumnType.CURRENCY,
        )
    }

    fun resolveReportPercentageSpec(columns: List<ColumnConfigModel>): NumberFormatSpec {
        val match = columns.firstOrNull { it.columnType == ColumnType.PERCENTAGE }
        return match?.toNumberFormatSpec() ?: defaultSpecForColumn(
            AppNumericSection.REPORT,
            "discount",
            ColumnType.PERCENTAGE,
        )
    }

    fun formatDouble(value: Double, spec: NumberFormatSpec): String {
        if (!value.isFinite()) return "0"
        val clean = if (value == 0.0 || value == -0.0) 0.0 else value
        val clampedDecimals = spec.decimalPlaces.coerceIn(MIN_DECIMALS, MAX_DECIMALS)

        val rawBd = BigDecimal.valueOf(clean)
        val scaledBd = if (spec.autoDecimals) {
            rawBd.stripTrailingZeros()
        } else {
            val rounded = rawBd.setScale(clampedDecimals, RoundingMode.HALF_UP)
            if (spec.stripTrailingZeros) rounded.stripTrailingZeros() else rounded
        }

        val normalizedBd = if (scaledBd.compareTo(BigDecimal.ZERO) == 0) {
            if (spec.autoDecimals || spec.stripTrailingZeros) {
                BigDecimal.ZERO
            } else {
                BigDecimal.ZERO.setScale(clampedDecimals)
            }
        } else {
            scaledBd
        }

        val plain = normalizedBd.toPlainString()
        val dotIndex = plain.indexOf('.')
        val rawIntPart = if (dotIndex >= 0) plain.substring(0, dotIndex) else plain
        val fracPart = if (dotIndex >= 0) plain.substring(dotIndex + 1) else ""

        val intFormatted = if (spec.useGrouping) insertThousandsGrouping(rawIntPart) else rawIntPart
        return if (fracPart.isEmpty()) intFormatted else "$intFormatted.$fracPart"
    }

    fun formatDouble(
        value: Double,
        column: ColumnConfigModel,
        useGrouping: Boolean = true,
    ): String = formatDouble(value, column.toNumberFormatSpec(useGrouping))

    fun formatCurrencyAmount(
        value: Double,
        currency: String,
        spec: NumberFormatSpec,
    ): String {
        val formatted = formatDouble(value, spec)
        return if (currency.isBlank()) formatted else "$formatted $currency"
    }

    /**
     * Lossless string for text-field initial values so editing an entry preserves exact precision.
     */
    fun formatEditableNumber(value: Double): String {
        if (!value.isFinite()) return "0"
        val clean = if (value == 0.0 || value == -0.0) 0.0 else value
        val bd = BigDecimal.valueOf(clean).stripTrailingZeros()
        return if (bd.compareTo(BigDecimal.ZERO) == 0) "0" else bd.toPlainString()
    }

    fun excelNumFmtCode(spec: NumberFormatSpec): String {
        val clamped = spec.decimalPlaces.coerceIn(MIN_DECIMALS, MAX_DECIMALS)
        val base = if (spec.useGrouping) "#,##0" else "0"
        return when {
            spec.autoDecimals -> "$base.##########"
            clamped == 0 -> base
            spec.stripTrailingZeros -> "$base.${"#".repeat(clamped)}"
            else -> "$base.${"0".repeat(clamped)}"
        }
    }

    fun arabicSummaryLabel(spec: NumberFormatSpec): String {
        val base = if (spec.autoDecimals) {
            "تلقائي حسب القيمة الأصلية"
        } else {
            when (spec.decimalPlaces.coerceIn(MIN_DECIMALS, MAX_DECIMALS)) {
                0 -> "0 منازل عشرية"
                1 -> "منزلة عشرية واحدة"
                2 -> "منزلتان عشريتان"
                3 -> "3 منازل عشرية"
                4 -> "4 منازل عشرية"
                5 -> "5 منازل عشرية"
                6 -> "6 منازل عشرية"
                else -> "${spec.decimalPlaces} منازل عشرية"
            }
        }
        return if (!spec.autoDecimals && spec.stripTrailingZeros) {
            "$base • بدون أصفار زائدة"
        } else {
            base
        }
    }

    fun shortBadgeLabel(spec: NumberFormatSpec): String {
        val base = if (spec.autoDecimals) {
            "تلقائي"
        } else {
            when (spec.decimalPlaces.coerceIn(MIN_DECIMALS, MAX_DECIMALS)) {
                0 -> "0 منازل"
                1 -> "منزلة 1"
                2 -> "منزلتان"
                else -> "${spec.decimalPlaces} منازل"
            }
        }
        return if (!spec.autoDecimals && spec.stripTrailingZeros) "$base (مرن)" else base
    }

    fun encodeProductsConfig(config: ProductsNumericConfig): String =
        json.encodeToString(
            config.copy(
                quantityFormat = config.quantityFormat.normalized(),
                priceFormat = config.priceFormat.normalized(),
                conversionFactorFormat = config.conversionFactorFormat.normalized(),
            ),
        )

    fun decodeProductsConfig(raw: String): ProductsNumericConfig {
        if (raw.isBlank()) return ProductsNumericConfig()
        return try {
            val decoded = json.decodeFromString<ProductsNumericConfig>(raw)
            decoded.copy(
                quantityFormat = decoded.quantityFormat.normalized(),
                priceFormat = decoded.priceFormat.normalized(),
                conversionFactorFormat = decoded.conversionFactorFormat.normalized(),
            )
        } catch (_: Exception) {
            ProductsNumericConfig()
        }
    }

    private fun insertThousandsGrouping(intPart: String): String {
        val negative = intPart.startsWith('-')
        val digits = if (negative) intPart.substring(1) else intPart
        if (digits.length <= 3) return intPart
        val sb = StringBuilder(digits.length + digits.length / 3 + 1)
        var count = 0
        for (i in digits.length - 1 downTo 0) {
            sb.append(digits[i])
            count++
            if (count % 3 == 0 && i > 0) {
                sb.append(',')
            }
        }
        if (negative) sb.append('-')
        return sb.reverse().toString()
    }
}
