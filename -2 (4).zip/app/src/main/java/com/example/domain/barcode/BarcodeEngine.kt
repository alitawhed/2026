package com.example.domain.barcode

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.CellAlignment
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.MultiFormatReader
import com.google.zxing.MultiFormatWriter
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.BitMatrix
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

data class BarcodeValidationResult(
    val isValid: Boolean,
    val normalizedValue: String,
    val errorMessage: String? = null,
)

data class DecodedBarcodeResult(
    val text: String,
    val format: BarcodeFormatType,
)

object BarcodeEngine {

    val PRIMARY_SUPPORTED_FORMATS: List<BarcodeFormatType> = listOf(
        BarcodeFormatType.CODE_128,
        BarcodeFormatType.CODE_39,
        BarcodeFormatType.EAN_13,
        BarcodeFormatType.EAN_8,
        BarcodeFormatType.UPC_A,
        BarcodeFormatType.UPC_E,
        BarcodeFormatType.QR_CODE,
    )

    fun parseFormatOrNull(raw: String?): BarcodeFormatType? {
        val clean = raw?.trim().orEmpty()
        if (clean.isEmpty()) return null
        BarcodeFormatType.entries.firstOrNull {
            it.name.equals(clean, ignoreCase = true) ||
                it.arabicLabel.equals(clean, ignoreCase = true)
        }?.let { return it }
        return when (clean.uppercase().replace("-", "").replace("_", "").replace(" ", "")) {
            "CODE128", "C128" -> BarcodeFormatType.CODE_128
            "CODE39", "C39" -> BarcodeFormatType.CODE_39
            "EAN13" -> BarcodeFormatType.EAN_13
            "EAN8" -> BarcodeFormatType.EAN_8
            "UPCA" -> BarcodeFormatType.UPC_A
            "UPCE" -> BarcodeFormatType.UPC_E
            "QR", "QRCODE" -> BarcodeFormatType.QR_CODE
            "ITF", "ITF14" -> BarcodeFormatType.ITF
            "CODABAR" -> BarcodeFormatType.CODABAR
            "DATAMATRIX" -> BarcodeFormatType.DATA_MATRIX
            "PDF417" -> BarcodeFormatType.PDF_417
            "AZTEC" -> BarcodeFormatType.AZTEC
            else -> null
        }
    }

    fun formatRequirementsArabic(format: BarcodeFormatType): String = when (format) {
        BarcodeFormatType.CODE_128 -> "يدعم الأرقام والأحرف الإنجليزية والرموز بأي طول تقريباً"
        BarcodeFormatType.CODE_39 -> "يدعم الأرقام والأحرف الإنجليزية الكبيرة و(-. \$/+%)"
        BarcodeFormatType.EAN_13 -> "يتطلب 12 أو 13 رقماً مع رقم تحقق GS1 صحيح"
        BarcodeFormatType.EAN_8 -> "يتطلب 7 أو 8 أرقام مع رقم تحقق GS1 صحيح"
        BarcodeFormatType.UPC_A -> "يتطلب 11 أو 12 رقماً مع رقم تحقق GS1 صحيح"
        BarcodeFormatType.UPC_E -> "يتطلب 7 أو 8 أرقام بصيغة UPC-E القياسية (يبدأ بـ 0 أو 1)"
        BarcodeFormatType.QR_CODE -> "يدعم جميع النصوص والأرقام والروابط والأحرف العربية"
        BarcodeFormatType.ITF -> "يتطلب عدداً زوجياً من الأرقام"
        else -> format.arabicLabel
    }

    fun isCompatible(value: String, format: BarcodeFormatType): Boolean =
        validate(value, format).isValid

    /**
     * Resolves a compatible format WITHOUT EVER mutating [value].
     * Uses [preferredDefault] if [value] can be validly encoded in it; otherwise preserves strict GS1
     * formats when check digits are genuinely valid, or safely falls back to CODE_128 / QR_CODE.
     */
    fun resolveCompatibleDefaultFormat(
        value: String,
        preferredDefault: BarcodeFormatType = BarcodeFormatType.CODE_128,
    ): BarcodeFormatType {
        val raw = value.trim()
        if (raw.isEmpty()) return preferredDefault
        if (isCompatible(raw, preferredDefault)) return preferredDefault
        if (raw.all { it.isDigit() }) {
            when (raw.length) {
                13 -> if (verifyGs1CheckDigit(raw) && isCompatible(raw, BarcodeFormatType.EAN_13)) {
                    return BarcodeFormatType.EAN_13
                }
                12 -> if (verifyGs1CheckDigit(raw) && isCompatible(raw, BarcodeFormatType.UPC_A)) {
                    return BarcodeFormatType.UPC_A
                }
                8 -> {
                    if (verifyGs1CheckDigit(raw) && isCompatible(raw, BarcodeFormatType.EAN_8)) {
                        return BarcodeFormatType.EAN_8
                    }
                    if (isCompatible(raw, BarcodeFormatType.UPC_E)) {
                        return BarcodeFormatType.UPC_E
                    }
                }
            }
        }
        return if (isCompatible(raw, BarcodeFormatType.CODE_128)) {
            BarcodeFormatType.CODE_128
        } else {
            BarcodeFormatType.QR_CODE
        }
    }

    fun toZxingFormat(format: BarcodeFormatType): BarcodeFormat = when (format) {
        BarcodeFormatType.EAN_13 -> BarcodeFormat.EAN_13
        BarcodeFormatType.EAN_8 -> BarcodeFormat.EAN_8
        BarcodeFormatType.UPC_A -> BarcodeFormat.UPC_A
        BarcodeFormatType.UPC_E -> BarcodeFormat.UPC_E
        BarcodeFormatType.CODE_128 -> BarcodeFormat.CODE_128
        BarcodeFormatType.CODE_39 -> BarcodeFormat.CODE_39
        BarcodeFormatType.ITF -> BarcodeFormat.ITF
        BarcodeFormatType.CODABAR -> BarcodeFormat.CODABAR
        BarcodeFormatType.QR_CODE -> BarcodeFormat.QR_CODE
        BarcodeFormatType.DATA_MATRIX -> BarcodeFormat.DATA_MATRIX
        BarcodeFormatType.PDF_417 -> BarcodeFormat.PDF_417
        BarcodeFormatType.AZTEC -> BarcodeFormat.AZTEC
    }

    fun fromZxingFormat(format: BarcodeFormat): BarcodeFormatType = when (format) {
        BarcodeFormat.EAN_13 -> BarcodeFormatType.EAN_13
        BarcodeFormat.EAN_8 -> BarcodeFormatType.EAN_8
        BarcodeFormat.UPC_A -> BarcodeFormatType.UPC_A
        BarcodeFormat.UPC_E -> BarcodeFormatType.UPC_E
        BarcodeFormat.CODE_128 -> BarcodeFormatType.CODE_128
        BarcodeFormat.CODE_39 -> BarcodeFormatType.CODE_39
        BarcodeFormat.ITF -> BarcodeFormatType.ITF
        BarcodeFormat.CODABAR -> BarcodeFormatType.CODABAR
        BarcodeFormat.QR_CODE -> BarcodeFormatType.QR_CODE
        BarcodeFormat.DATA_MATRIX -> BarcodeFormatType.DATA_MATRIX
        BarcodeFormat.PDF_417 -> BarcodeFormatType.PDF_417
        BarcodeFormat.AZTEC -> BarcodeFormatType.AZTEC
        else -> BarcodeFormatType.CODE_128
    }

    /**
     * Validates a barcode strictly without mutating leading zeros or guessing values.
     * Guarantees that when [BarcodeValidationResult.isValid] is true, ZXing encoding will succeed.
     */
    fun validate(value: String, format: BarcodeFormatType): BarcodeValidationResult {
        val raw = value.trim()
        if (raw.isEmpty()) {
            return BarcodeValidationResult(false, raw, "قيمة الباركود فارغة")
        }
        val syntaxFailure: String? = when (format) {
            BarcodeFormatType.EAN_13 -> when {
                !raw.all { it.isDigit() } || (raw.length != 12 && raw.length != 13) ->
                    "صيغة EAN-13 تتطلب 12 أو 13 رقماً فقط بدون أحرف"
                raw.length == 13 && !verifyGs1CheckDigit(raw) ->
                    "رقم التحقق (Check Digit) لـ EAN-13 غير صحيح"
                else -> null
            }
            BarcodeFormatType.EAN_8 -> when {
                !raw.all { it.isDigit() } || (raw.length != 7 && raw.length != 8) ->
                    "صيغة EAN-8 تتطلب 7 أو 8 أرقام فقط بدون أحرف"
                raw.length == 8 && !verifyGs1CheckDigit(raw) ->
                    "رقم التحقق (Check Digit) لـ EAN-8 غير صحيح"
                else -> null
            }
            BarcodeFormatType.UPC_A -> when {
                !raw.all { it.isDigit() } || (raw.length != 11 && raw.length != 12) ->
                    "صيغة UPC-A تتطلب 11 أو 12 رقماً فقط بدون أحرف"
                raw.length == 12 && !verifyGs1CheckDigit(raw) ->
                    "رقم التحقق (Check Digit) لـ UPC-A غير صحيح"
                else -> null
            }
            BarcodeFormatType.UPC_E -> when {
                !raw.all { it.isDigit() } || (raw.length != 7 && raw.length != 8) ->
                    "صيغة UPC-E تتطلب 7 أو 8 أرقام فقط"
                raw.first() != '0' && raw.first() != '1' ->
                    "صيغة UPC-E تتطلب أن يبدأ الرقم بالصفر (0) أو الواحد (1)"
                else -> null
            }
            BarcodeFormatType.ITF -> {
                if (!raw.all { it.isDigit() } || raw.length % 2 != 0 || raw.length < 2) {
                    "ITF يتطلب عدداً زوجياً من الأرقام"
                } else {
                    null
                }
            }
            BarcodeFormatType.CODE_39 -> {
                val allowed = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. \$/+%"
                if (!raw.all { it in allowed }) {
                    "Code 39 يدعم الأحرف الإنجليزية الكبيرة والأرقام والرموز (-. \$/+%) فقط"
                } else {
                    null
                }
            }
            BarcodeFormatType.CODE_128 -> {
                if (raw.length > 80) {
                    "طول النص يتجاوز الحد العملي للباركود أحادي البعد Code 128"
                } else {
                    null
                }
            }
            else -> null
        }
        if (syntaxFailure != null) {
            return BarcodeValidationResult(false, raw, syntaxFailure)
        }
        return try {
            encodeBitMatrix(raw, format, quietZoneModules = 2)
            BarcodeValidationResult(true, raw)
        } catch (e: Exception) {
            BarcodeValidationResult(false, raw, "تعذر ترميز القيمة بصيغة ${format.arabicLabel}: ${e.message ?: "قيمة غير متوافقة"}")
        }
    }

    private fun verifyGs1CheckDigit(digits: String): Boolean {
        if (digits.length < 2 || !digits.all { it.isDigit() }) return false
        val body = digits.dropLast(1)
        val expected = digits.last().digitToInt()
        var sum = 0
        val reversed = body.reversed()
        for (i in reversed.indices) {
            val d = reversed[i].digitToInt()
            sum += if (i % 2 == 0) d * 3 else d
        }
        val computed = (10 - (sum % 10)) % 10
        return computed == expected
    }

    /**
     * Produces the exact native-module BitMatrix (width = modules + quiet zone, height = 1 for 1D or square for 2D).
     * Never distorts or guesses the barcode value.
     */
    fun encodeBitMatrix(
        value: String,
        format: BarcodeFormatType,
        quietZoneModules: Int = 8,
    ): BitMatrix {
        val effectiveMargin = if (format.is2D) {
            quietZoneModules.coerceAtLeast(2)
        } else {
            // ZXing OneDimensionalCodeWriter divides MARGIN across left+right sides; UPC-E needs >=6 modules per side.
            if (quietZoneModules <= 2) quietZoneModules.coerceAtLeast(2) else quietZoneModules.coerceAtLeast(16)
        }
        val hints = mutableMapOf<EncodeHintType, Any>(
            EncodeHintType.MARGIN to effectiveMargin,
            EncodeHintType.CHARACTER_SET to "UTF-8",
        )
        if (format == BarcodeFormatType.QR_CODE) {
            hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.M
        }
        val size = if (format.is2D) 1 else 0
        return MultiFormatWriter().encode(
            value,
            toZxingFormat(format),
            size,
            size,
            hints,
        )
    }

    /**
     * Draws a crisp, vector-exact barcode directly onto any Android Canvas (including PDF Canvas).
     * Guarantees pure black-on-white contrast, preserves quiet zones, and prevents clipping.
     */
    fun drawVectorOnCanvas(
        canvas: Canvas,
        value: String,
        format: BarcodeFormatType,
        bounds: RectF,
        showText: Boolean = true,
        textSizePt: Float = 8f,
        quietZoneModules: Int = 18,
        alignment: CellAlignment = CellAlignment.CENTER,
        typeface: Typeface? = null,
    ): Boolean {
        if (value.isBlank() || bounds.width() <= 4f || bounds.height() <= 4f) return false
        return try {
            val matrix = encodeBitMatrix(value, format, quietZoneModules)
            val bgPaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(bounds, bgPaint)

            val barPaint = Paint().apply {
                color = Color.BLACK
                style = Paint.Style.FILL
                isAntiAlias = false
            }

            val textAreaHeight = if (showText && !format.is2D) (textSizePt + 3f).coerceAtMost(bounds.height() * 0.35f) else 0f
            val availableBarHeight = (bounds.height() - textAreaHeight - 2f).coerceAtLeast(6f)

            if (format.is2D) {
                val side = minOf(bounds.width(), availableBarHeight)
                val moduleSize = side / matrix.width.toFloat()
                val drawnWidth = moduleSize * matrix.width
                val drawnHeight = moduleSize * matrix.height
                val offsetX = when (alignment) {
                    CellAlignment.START -> bounds.left
                    CellAlignment.CENTER -> bounds.left + (bounds.width() - drawnWidth) / 2f
                    CellAlignment.END -> bounds.right - drawnWidth
                }
                val offsetY = bounds.top + (bounds.height() - drawnHeight) / 2f
                for (y in 0 until matrix.height) {
                    for (x in 0 until matrix.width) {
                        if (matrix[x, y]) {
                            canvas.drawRect(
                                offsetX + x * moduleSize,
                                offsetY + y * moduleSize,
                                offsetX + (x + 1) * moduleSize,
                                offsetY + (y + 1) * moduleSize,
                                barPaint,
                            )
                        }
                    }
                }
            } else {
                // 1D Barcode: snap to integer modules on raster surfaces (>= 2px/module) to avoid subpixel bar distortion
                val rawModuleWidth = bounds.width() / matrix.width.toFloat()
                if (rawModuleWidth < 0.35f) return false // Cell too narrow to guarantee scannability
                val moduleWidth = if (rawModuleWidth >= 2f) kotlin.math.floor(rawModuleWidth) else rawModuleWidth
                val totalDrawnWidth = moduleWidth * matrix.width
                val startX = bounds.left + (bounds.width() - totalDrawnWidth) / 2f
                val barTop = bounds.top + 1f
                val barBottom = barTop + availableBarHeight
                val ySample = matrix.height / 2
                var runStart = -1
                for (x in 0 until matrix.width) {
                    val isBlack = matrix[x, ySample]
                    if (isBlack && runStart == -1) {
                        runStart = x
                    } else if (!isBlack && runStart != -1) {
                        canvas.drawRect(
                            startX + runStart * moduleWidth,
                            barTop,
                            startX + x * moduleWidth,
                            barBottom,
                            barPaint,
                        )
                        runStart = -1
                    }
                }
                if (runStart != -1) {
                    canvas.drawRect(
                        startX + runStart * moduleWidth,
                        barTop,
                        startX + matrix.width * moduleWidth,
                        barBottom,
                        barPaint,
                    )
                }

                if (showText) {
                    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.BLACK
                        textSize = textSizePt.coerceIn(5.5f, 14f)
                        textAlign = Paint.Align.CENTER
                        this.typeface = typeface ?: Typeface.MONOSPACE
                    }
                    val textY = barBottom + textAreaHeight - 1.5f
                    canvas.drawText(value, bounds.centerX(), textY, textPaint)
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Generates a high-DPI raster Bitmap (e.g., 300 DPI or 600 DPI) suitable for label export and preview.
     */
    fun generateHighResBitmap(
        value: String,
        format: BarcodeFormatType,
        widthPx: Int = 900,
        heightPx: Int = 340,
        showText: Boolean = true,
        quietZoneModules: Int = 14,
    ): Bitmap? {
        if (value.isBlank()) return null
        return try {
            val reqW = widthPx.coerceIn(120, 4096)
            val reqH = heightPx.coerceIn(80, 4096)
            val matrix = encodeBitMatrix(value, format, quietZoneModules.coerceAtLeast(4))

            val actualW: Int
            val actualH: Int
            if (format.is2D) {
                val side = minOf(reqW, reqH)
                val modSize = (side / matrix.width).coerceAtLeast(2)
                actualW = maxOf(reqW, modSize * matrix.width).coerceAtMost(4096)
                actualH = maxOf(reqH, modSize * matrix.height).coerceAtMost(4096)
            } else {
                val modW = (reqW / matrix.width).coerceAtLeast(2)
                actualW = maxOf(reqW, modW * matrix.width).coerceAtMost(4096)
                actualH = reqH
            }

            val pixels = IntArray(actualW * actualH) { Color.WHITE }

            val textAreaH = if (showText && !format.is2D) (actualH * 0.20f).toInt().coerceIn(22, 64) else 0
            val barH = (actualH - textAreaH - 8).coerceAtLeast(24)

            if (format.is2D) {
                val side = minOf(actualW, actualH)
                val modSize = (side / matrix.width).coerceAtLeast(1)
                val drawnW = modSize * matrix.width
                val drawnH = modSize * matrix.height
                val offsetX = ((actualW - drawnW) / 2).coerceAtLeast(0)
                val offsetY = ((actualH - drawnH) / 2).coerceAtLeast(0)
                for (my in 0 until matrix.height) {
                    for (mx in 0 until matrix.width) {
                        if (matrix[mx, my]) {
                            val x0 = offsetX + mx * modSize
                            val y0 = offsetY + my * modSize
                            val x1 = (x0 + modSize).coerceAtMost(actualW)
                            val y1 = (y0 + modSize).coerceAtMost(actualH)
                            for (py in y0 until y1) {
                                val rowOff = py * actualW
                                for (px in x0 until x1) pixels[rowOff + px] = Color.BLACK
                            }
                        }
                    }
                }
            } else {
                val modW = (actualW / matrix.width).coerceAtLeast(1)
                val drawnW = modW * matrix.width
                val startX = ((actualW - drawnW) / 2).coerceAtLeast(0)
                val topY = 4
                val bottomY = (topY + barH).coerceAtMost(actualH)
                val ySample = matrix.height / 2
                for (mx in 0 until matrix.width) {
                    if (matrix[mx, ySample]) {
                        val x0 = startX + mx * modW
                        val x1 = (x0 + modW).coerceAtMost(actualW)
                        for (py in topY until bottomY) {
                            val rowOff = py * actualW
                            for (px in x0 until x1) pixels[rowOff + px] = Color.BLACK
                        }
                    }
                }
            }

            val bitmap = Bitmap.createBitmap(actualW, actualH, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, actualW, 0, 0, actualW, actualH)

            if (showText && !format.is2D && textAreaH > 0) {
                val canvas = Canvas(bitmap)
                val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.BLACK
                    textSize = (textAreaH * 0.68f).coerceIn(14f, 40f)
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.MONOSPACE
                }
                canvas.drawText(value, actualW / 2f, (actualH - 6).toFloat(), textPaint)
            }
            bitmap
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Generates a true scalable SVG vector document for the barcode.
     */
    fun generateSvg(
        value: String,
        format: BarcodeFormatType,
        widthMm: Float = 50f,
        heightMm: Float = 22f,
        showText: Boolean = true,
        quietZoneModules: Int = 8,
    ): String {
        val matrix = encodeBitMatrix(value, format, quietZoneModules)
        val viewW = matrix.width * 2
        val barH = if (format.is2D) matrix.height * 2 else 64
        val textH = if (showText && !format.is2D) 14 else 0
        val viewH = barH + textH
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8"?>""")
        sb.append("\n")
        sb.append("""<svg xmlns="http://www.w3.org/2000/svg" width="${widthMm}mm" height="${heightMm}mm" viewBox="0 0 $viewW $viewH" shape-rendering="crispEdges">""")
        sb.append("""<rect width="100%" height="100%" fill="#FFFFFF"/>""")
        if (format.is2D) {
            for (y in 0 until matrix.height) {
                for (x in 0 until matrix.width) {
                    if (matrix[x, y]) {
                        sb.append("""<rect x="${x * 2}" y="${y * 2}" width="2" height="2" fill="#000000"/>""")
                    }
                }
            }
        } else {
            val ySample = matrix.height / 2
            var runStart = -1
            for (x in 0 until matrix.width) {
                if (matrix[x, ySample] && runStart == -1) {
                    runStart = x
                } else if (!matrix[x, ySample] && runStart != -1) {
                    val runLen = (x - runStart) * 2
                    sb.append("""<rect x="${runStart * 2}" y="2" width="$runLen" height="${barH - 4}" fill="#000000"/>""")
                    runStart = -1
                }
            }
            if (runStart != -1) {
                val runLen = (matrix.width - runStart) * 2
                sb.append("""<rect x="${runStart * 2}" y="2" width="$runLen" height="${barH - 4}" fill="#000000"/>""")
            }
            if (showText) {
                val escaped = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                sb.append("""<text x="${viewW / 2}" y="${viewH - 2}" font-family="monospace" font-size="11" text-anchor="middle" fill="#000000">$escaped</text>""")
            }
        }
        sb.append("</svg>")
        return sb.toString()
    }

    /**
     * Independent decoder to verify generated barcodes and decode cropped bitmaps.
     */
    fun decodeBitmap(
        bitmap: Bitmap,
        expectedFormat: BarcodeFormatType? = null,
    ): DecodedBarcodeResult? {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source: LuminanceSource = RGBLuminanceSource(width, height, pixels)
        return decodeLuminanceSource(source, expectedFormat)
    }

    fun decodeYuvFrame(
        yuvBytes: ByteArray,
        dataWidth: Int,
        dataHeight: Int,
        expectedFormat: BarcodeFormatType? = null,
    ): DecodedBarcodeResult? {
        if (dataWidth <= 0 || dataHeight <= 0 || yuvBytes.size < dataWidth * dataHeight) return null
        val source = PlanarYUVLuminanceSource(
            yuvBytes,
            dataWidth,
            dataHeight,
            0,
            0,
            dataWidth,
            dataHeight,
            false,
        )
        return decodeLuminanceSource(source, expectedFormat)
    }

    /**
     * Compacts a CameraX Y-plane buffer when rowStride includes alignment padding
     * (rowStride > width), preventing bar-spacing distortion and crop failures on devices.
     */
    fun compactYPlane(
        yuvBytes: ByteArray,
        width: Int,
        height: Int,
        rowStride: Int,
    ): ByteArray {
        if (width <= 0 || height <= 0) return ByteArray(0)
        val expectedCompact = width * height
        if (rowStride <= width) {
            return if (yuvBytes.size == expectedCompact) yuvBytes else yuvBytes.copyOf(expectedCompact.coerceAtMost(yuvBytes.size))
        }
        val compact = ByteArray(expectedCompact)
        var srcOffset = 0
        var dstOffset = 0
        for (row in 0 until height) {
            if (srcOffset + width <= yuvBytes.size) {
                System.arraycopy(yuvBytes, srcOffset, compact, dstOffset, width)
            } else {
                val available = (yuvBytes.size - srcOffset).coerceAtLeast(0)
                if (available > 0) {
                    System.arraycopy(yuvBytes, srcOffset, compact, dstOffset, available)
                }
            }
            srcOffset += rowStride
            dstOffset += width
        }
        return compact
    }

    /**
     * Rotates a compact Y luminance buffer clockwise by 0, 90, 180, or 270 degrees.
     * Returns (rotatedBytes, newWidth, newHeight).
     */
    fun rotateYPlane(
        compactY: ByteArray,
        width: Int,
        height: Int,
        rotationDegrees: Int,
    ): Triple<ByteArray, Int, Int> {
        val norm = ((rotationDegrees % 360) + 360) % 360
        if (norm == 0 || compactY.size < width * height) {
            return Triple(compactY, width, height)
        }
        val out = ByteArray(width * height)
        when (norm) {
            90 -> {
                for (y in 0 until height) {
                    for (x in 0 until width) {
                        out[x * height + (height - 1 - y)] = compactY[y * width + x]
                    }
                }
                return Triple(out, height, width)
            }
            180 -> {
                val total = width * height
                for (i in 0 until total) {
                    out[total - 1 - i] = compactY[i]
                }
                return Triple(out, width, height)
            }
            270 -> {
                for (y in 0 until height) {
                    for (x in 0 until width) {
                        out[(width - 1 - x) * height + y] = compactY[y * width + x]
                    }
                }
                return Triple(out, height, width)
            }
            else -> return Triple(compactY, width, height)
        }
    }

    /**
     * Robust YUV frame decoder handling rowStride padding, multiple orientations (starting with
     * sensor rotationDegrees then perpendicular angles), inverted light-on-dark codes, and format filtering.
     * Preserves exact raw text including leading zeros.
     */
    fun decodeYuvFrameWithRotation(
        yuvBytes: ByteArray,
        width: Int,
        height: Int,
        rowStride: Int = width,
        rotationDegrees: Int = 0,
        allowedFormats: Set<BarcodeFormatType>? = null,
        tryInverted: Boolean = true,
    ): DecodedBarcodeResult? {
        if (width <= 0 || height <= 0 || yuvBytes.isEmpty()) return null
        val compact = compactYPlane(yuvBytes, width, height, rowStride)
        if (compact.size < width * height) return null

        val baseRot = ((rotationDegrees % 360) + 360) % 360
        val angles = listOf(
            baseRot,
            (baseRot + 90) % 360,
            (baseRot + 270) % 360,
            (baseRot + 180) % 360,
        ).distinct()

        for (angle in angles) {
            val (rotBytes, rotW, rotH) = rotateYPlane(compact, width, height, angle)
            val source = PlanarYUVLuminanceSource(
                rotBytes,
                rotW,
                rotH,
                0,
                0,
                rotW,
                rotH,
                false,
            )
            decodeLuminanceSource(source, allowedFormats = allowedFormats)?.let { return it }
            if (tryInverted) {
                decodeLuminanceSource(source.invert(), allowedFormats = allowedFormats)?.let { return it }
            }
        }
        return null
    }

    private fun decodeLuminanceSource(
        source: LuminanceSource,
        expectedFormat: BarcodeFormatType? = null,
        allowedFormats: Set<BarcodeFormatType>? = null,
    ): DecodedBarcodeResult? {
        val formats = when {
            expectedFormat != null -> listOf(toZxingFormat(expectedFormat))
            !allowedFormats.isNullOrEmpty() -> allowedFormats.map { toZxingFormat(it) }
            else -> listOf(
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.ITF,
                BarcodeFormat.CODABAR,
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.PDF_417,
                BarcodeFormat.AZTEC,
            )
        }
        val reader = MultiFormatReader().apply {
            setHints(
                mapOf(
                    DecodeHintType.TRY_HARDER to true,
                    DecodeHintType.CHARACTER_SET to "UTF-8",
                    DecodeHintType.POSSIBLE_FORMATS to formats,
                ),
            )
        }
        return try {
            val result = try {
                reader.decodeWithState(BinaryBitmap(HybridBinarizer(source)))
            } catch (_: Exception) {
                reader.reset()
                reader.decodeWithState(BinaryBitmap(GlobalHistogramBinarizer(source)))
            }
            DecodedBarcodeResult(
                text = result.text,
                format = fromZxingFormat(result.barcodeFormat),
            )
        } catch (_: Exception) {
            null
        } finally {
            reader.reset()
        }
    }
}
