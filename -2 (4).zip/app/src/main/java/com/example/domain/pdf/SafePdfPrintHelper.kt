package com.example.domain.pdf

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

sealed class PrintDispatchResult {
    data class Started(val jobName: String, val pageCount: Int) : PrintDispatchResult()
    data class Error(val message: String, val cause: Throwable? = null) : PrintDispatchResult()
}

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

class SafePdfPrintAdapter(
    private val pdfFile: File,
    private val knownPageCount: Int,
) : PrintDocumentAdapter() {

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback?,
        extras: Bundle?,
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
        }
        if (!pdfFile.exists() || pdfFile.length() <= 0L) {
            callback?.onLayoutFailed("ملف PDF غير موجود أو فارغ")
            return
        }
        val builder = PrintDocumentInfo.Builder(pdfFile.name)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
        if (knownPageCount > 0) {
            builder.setPageCount(knownPageCount)
        } else {
            builder.setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
        }
        callback?.onLayoutFinished(builder.build(), true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback?,
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback?.onWriteCancelled()
            return
        }
        val fd = destination?.fileDescriptor
        if (fd == null) {
            callback?.onWriteFailed("تعذر فتح مخرج الطباعة")
            return
        }
        if (!pdfFile.exists() || pdfFile.length() <= 0L) {
            callback?.onWriteFailed("ملف PDF غير موجود أو فارغ")
            return
        }
        try {
            writePdfStream(fd, cancellationSignal)
            if (cancellationSignal?.isCanceled == true) {
                callback?.onWriteCancelled()
            } else {
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            }
        } catch (t: Throwable) {
            callback?.onWriteFailed(t.message ?: "فشل كتابة ملف PDF للطباعة")
        }
    }

    internal fun writePdfStream(
        fd: java.io.FileDescriptor,
        cancellationSignal: CancellationSignal? = null,
    ) {
        val buffer = ByteArray(16 * 1024)
        FileInputStream(pdfFile).use { input ->
            FileOutputStream(fd).use { output ->
                while (true) {
                    if (cancellationSignal?.isCanceled == true) {
                        return
                    }
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                }
                output.flush()
            }
        }
    }
}

object SafePdfPrintHelper {

    fun countPdfPagesSafe(pdfFile: File): Int {
        if (!pdfFile.exists() || pdfFile.length() <= 0L) return 0
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            renderer.pageCount
        } catch (_: Throwable) {
            0
        } finally {
            try {
                renderer?.close()
            } catch (_: Throwable) {
            }
            try {
                pfd?.close()
            } catch (_: Throwable) {
            }
        }
    }

    fun printPdfWithActivity(
        context: Context,
        pdfFile: File,
        jobName: String,
        isLandscape: Boolean = false,
    ): PrintDispatchResult {
        if (!pdfFile.exists() || pdfFile.length() <= 0L) {
            return PrintDispatchResult.Error("ملف PDF غير جاهز أو فارغ، يرجى إعادة إنشائه أولاً")
        }
        val activity = context.findActivity()
            ?: return PrintDispatchResult.Error("يتطلب نظام الطباعة سياق شاشة نشطة (Activity)؛ تعذر بدء الطباعة من سياق التطبيق")
        if (activity.isFinishing || activity.isDestroyed) {
            return PrintDispatchResult.Error("الشاشة غير نشطة حالياً للطباعة")
        }
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            ?: return PrintDispatchResult.Error("خدمة الطباعة غير متوفرة على هذا الجهاز")

        val safeJobName = jobName.trim().ifBlank { pdfFile.nameWithoutExtension }.take(80)
        val pageCount = countPdfPagesSafe(pdfFile)
        val mediaSize = if (isLandscape) {
            PrintAttributes.MediaSize.ISO_A4.asLandscape()
        } else {
            PrintAttributes.MediaSize.ISO_A4
        }
        val attributes = PrintAttributes.Builder()
            .setMediaSize(mediaSize)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()

        return try {
            printManager.print(
                safeJobName,
                SafePdfPrintAdapter(pdfFile, pageCount),
                attributes,
            )
            PrintDispatchResult.Started(safeJobName, pageCount)
        } catch (t: Throwable) {
            PrintDispatchResult.Error("تعذر فتح واجهة الطباعة: ${t.localizedMessage ?: "خطأ غير متوقع"}", t)
        }
    }
}
