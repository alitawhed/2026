package com.example.domain.model

import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.ProductWithDetails
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
enum class InventoryBarcodeSourceMode(val arabicLabel: String) {
    SCANNED_BARCODE("الباركود الممسوح فعلياً"),
    PRIMARY_BARCODE("الباركود الأساسي للمنتج");

    companion object {
        fun fromString(value: String?): InventoryBarcodeSourceMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: SCANNED_BARCODE
    }
}

@Serializable
data class InventorySheetConfig(
    val columns: List<ColumnConfigModel> = InventoryColumnDefaults.defaultColumns(),
    val distributionMode: ColumnDistributionMode = ColumnDistributionMode.AUTO_FIT,
    val paperSize: PaperSizeType = PaperSizeType.A4,
    val customWidthMm: Float = 210f,
    val customHeightMm: Float = 297f,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val marginTopMm: Float = 10f,
    val marginBottomMm: Float = 10f,
    val marginStartMm: Float = 8f,
    val marginEndMm: Float = 8f,
    val splitHorizontalGroups: Boolean = false,
    val repeatTableHeader: Boolean = true,
    val showPageNumbers: Boolean = true,
    val showProductImages: Boolean = true,
    val showSessionNotes: Boolean = true,
    val showTotalsFooter: Boolean = true,
    val barcodeSourceMode: InventoryBarcodeSourceMode = InventoryBarcodeSourceMode.SCANNED_BARCODE,
    val renderBarcodeGraphic: Boolean = true,
    val showBarcodeTextBelow: Boolean = true,
    val barcodeFormatOverride: String = "AUTO",
    val barcodeHeightPt: Float = 28f,
    val quietZoneModules: Int = 10,
    val schemaRevision: Int = 1,
) {
    fun toPageSpec(): PageSpec = PageSpec(
        paperSize = paperSize,
        customWidthMm = customWidthMm,
        customHeightMm = customHeightMm,
        orientation = orientation,
        marginTopMm = marginTopMm,
        marginBottomMm = marginBottomMm,
        marginStartMm = marginStartMm,
        marginEndMm = marginEndMm,
    )
}

object InventoryColumnDefaults {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun defaultColumns(): List<ColumnConfigModel> = listOf(
        ColumnConfigModel(
            columnKey = "serial",
            title = "الرقم التسلسلي",
            columnType = ColumnType.SERIAL,
            visible = true,
            sortOrder = 0,
            manualWidthPt = 34f,
            presetWidth = ColumnWidthPreset.NARROW,
            minWidthPt = 24f,
            maxWidthPt = 72f,
            cellHeightPt = 44f,
            fontSizeSp = 9.5f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "image",
            title = "صورة المنتج",
            columnType = ColumnType.IMAGE,
            visible = true,
            sortOrder = 1,
            manualWidthPt = 48f,
            presetWidth = ColumnWidthPreset.NARROW,
            minWidthPt = 38f,
            maxWidthPt = 120f,
            cellHeightPt = 44f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "internal_code",
            title = "رقم المنتج",
            columnType = ColumnType.TEXT,
            visible = true,
            sortOrder = 2,
            manualWidthPt = 64f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 44f,
            maxWidthPt = 160f,
            cellHeightPt = 44f,
            fontSizeSp = 9f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "name",
            title = "اسم المنتج",
            columnType = ColumnType.TEXT,
            visible = true,
            sortOrder = 3,
            manualWidthPt = 132f,
            presetWidth = ColumnWidthPreset.WIDE,
            minWidthPt = 78f,
            maxWidthPt = 320f,
            cellHeightPt = 44f,
            fontSizeSp = 9.5f,
            alignment = CellAlignment.START,
        ),
        ColumnConfigModel(
            columnKey = "barcode",
            title = "الباركود",
            columnType = ColumnType.BARCODE,
            visible = true,
            sortOrder = 4,
            manualWidthPt = 108f,
            presetWidth = ColumnWidthPreset.WIDE,
            minWidthPt = 76f,
            maxWidthPt = 240f,
            cellHeightPt = 46f,
            fontSizeSp = 8.5f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "quantity",
            title = "الكمية",
            columnType = ColumnType.QUANTITY,
            visible = true,
            sortOrder = 5,
            manualWidthPt = 54f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 38f,
            maxWidthPt = 140f,
            cellHeightPt = 44f,
            fontSizeSp = 10f,
            alignment = CellAlignment.CENTER,
            numberFormat = "INTEGER",
            decimalPlaces = 0,
            autoDecimals = false,
            stripTrailingZeros = false,
        ),
        ColumnConfigModel(
            columnKey = "unit",
            title = "الوحدة",
            columnType = ColumnType.TEXT,
            visible = true,
            sortOrder = 6,
            manualWidthPt = 52f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 38f,
            maxWidthPt = 130f,
            cellHeightPt = 44f,
            fontSizeSp = 9f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "notes",
            title = "الملاحظات",
            columnType = ColumnType.NOTES,
            visible = true,
            sortOrder = 7,
            manualWidthPt = 78f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 50f,
            maxWidthPt = 260f,
            cellHeightPt = 44f,
            fontSizeSp = 9f,
            alignment = CellAlignment.START,
        ),
    )

    fun optionalExtraColumns(): List<ColumnConfigModel> = listOf(
        ColumnConfigModel(
            columnKey = "category",
            title = "التصنيف",
            columnType = ColumnType.TEXT,
            visible = true,
            manualWidthPt = 68f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 44f,
            maxWidthPt = 160f,
            cellHeightPt = 44f,
            fontSizeSp = 9f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "conversion_factor",
            title = "معامل التحويل",
            columnType = ColumnType.NUMBER,
            visible = true,
            manualWidthPt = 58f,
            presetWidth = ColumnWidthPreset.NARROW,
            minWidthPt = 40f,
            maxWidthPt = 120f,
            cellHeightPt = 44f,
            fontSizeSp = 9f,
            alignment = CellAlignment.CENTER,
            numberFormat = "AUTO",
            decimalPlaces = 2,
            autoDecimals = true,
            stripTrailingZeros = true,
        ),
        ColumnConfigModel(
            columnKey = "base_qty",
            title = "الكمية بالأساس",
            columnType = ColumnType.QUANTITY,
            visible = true,
            manualWidthPt = 66f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 44f,
            maxWidthPt = 140f,
            cellHeightPt = 44f,
            fontSizeSp = 9.5f,
            alignment = CellAlignment.CENTER,
            numberFormat = "INTEGER",
            decimalPlaces = 0,
            autoDecimals = false,
            stripTrailingZeros = false,
        ),
        ColumnConfigModel(
            columnKey = "barcode_text",
            title = "نص الباركود",
            columnType = ColumnType.TEXT,
            visible = true,
            manualWidthPt = 92f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 56f,
            maxWidthPt = 200f,
            cellHeightPt = 44f,
            fontSizeSp = 8.5f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "barcode_type",
            title = "نوع الباركود",
            columnType = ColumnType.TEXT,
            visible = true,
            manualWidthPt = 64f,
            presetWidth = ColumnWidthPreset.NARROW,
            minWidthPt = 44f,
            maxWidthPt = 140f,
            cellHeightPt = 44f,
            fontSizeSp = 8.5f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "qr_code",
            title = "QR Code",
            columnType = ColumnType.QR_CODE,
            visible = true,
            manualWidthPt = 52f,
            presetWidth = ColumnWidthPreset.NARROW,
            minWidthPt = 44f,
            maxWidthPt = 140f,
            cellHeightPt = 46f,
            alignment = CellAlignment.CENTER,
        ),
        ColumnConfigModel(
            columnKey = "scanned_at",
            title = "وقت المسح",
            columnType = ColumnType.DATE,
            visible = true,
            manualWidthPt = 68f,
            presetWidth = ColumnWidthPreset.MEDIUM,
            minWidthPt = 48f,
            maxWidthPt = 150f,
            cellHeightPt = 44f,
            fontSizeSp = 8.5f,
            alignment = CellAlignment.CENTER,
        ),
    )

    fun defaultColumnForKey(key: String): ColumnConfigModel? {
        return (defaultColumns() + optionalExtraColumns()).firstOrNull { it.columnKey == key }
    }

    fun encode(config: InventorySheetConfig): String =
        json.encodeToString(config.copy(schemaRevision = 2))

    fun decode(raw: String): InventorySheetConfig {
        if (raw.isBlank()) return InventorySheetConfig(schemaRevision = 2)
        return try {
            val decoded = json.decodeFromString<InventorySheetConfig>(raw)
            val baseCols = if (decoded.columns.isEmpty()) defaultColumns() else decoded.columns
            val migratedCols = if (decoded.schemaRevision < 2) {
                baseCols.map { col ->
                    when {
                        (col.columnKey == "quantity" || col.columnKey == "base_qty") &&
                            col.decimalPlaces == 2 && !col.autoDecimals && !col.stripTrailingZeros ->
                            col.copy(decimalPlaces = 0, numberFormat = "INTEGER")
                        col.columnKey == "conversion_factor" &&
                            col.decimalPlaces == 2 && !col.autoDecimals && !col.stripTrailingZeros ->
                            col.copy(autoDecimals = true, stripTrailingZeros = true, numberFormat = "AUTO")
                        else -> col
                    }
                }
            } else {
                baseCols
            }
            decoded.copy(
                schemaRevision = 2,
                columns = migratedCols
                    .sortedBy { it.sortOrder }
                    .mapIndexed { idx, col -> col.copy(sortOrder = idx) },
            )
        } catch (_: Exception) {
            InventorySheetConfig(schemaRevision = 2)
        }
    }

    fun sheetNumberForSession(sessionId: Long): String {
        val padded = sessionId.coerceAtLeast(1L).toString().padStart(4, '0')
        return "INV-$padded"
    }

    fun resolveBarcodeValue(
        item: InventoryCountItemEntity,
        product: ProductWithDetails?,
        mode: InventoryBarcodeSourceMode,
    ): String {
        return when (mode) {
            InventoryBarcodeSourceMode.SCANNED_BARCODE -> item.scannedBarcode
            InventoryBarcodeSourceMode.PRIMARY_BARCODE -> {
                product?.primaryBarcode?.barcodeValue?.takeIf { it.isNotBlank() } ?: item.scannedBarcode
            }
        }
    }

    fun resolveBarcodeFormat(
        item: InventoryCountItemEntity,
        product: ProductWithDetails?,
        config: InventorySheetConfig,
        defaultFormat: BarcodeFormatType = BarcodeFormatType.CODE_128,
    ): BarcodeFormatType {
        if (!config.barcodeFormatOverride.equals("AUTO", ignoreCase = true) &&
            config.barcodeFormatOverride.isNotBlank()
        ) {
            return com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(config.barcodeFormatOverride)
                ?: defaultFormat
        }
        val rawType = when (config.barcodeSourceMode) {
            InventoryBarcodeSourceMode.SCANNED_BARCODE -> item.barcodeType
            InventoryBarcodeSourceMode.PRIMARY_BARCODE -> {
                product?.primaryBarcode?.barcodeType?.takeIf { it.isNotBlank() } ?: item.barcodeType
            }
        }
        return com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(rawType) ?: defaultFormat
    }
}
