package com.example.domain.billing

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClient.BillingResponseCode
import com.android.billingclient.api.BillingClient.ProductType
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.acknowledgePurchase
import com.android.billingclient.api.queryProductDetails
import com.android.billingclient.api.queryPurchasesAsync
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

class PlayBillingManager(
    private val context: Context,
    private val configStore: BillingConfigStore,
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val activeUidProvider: () -> String? = { null },
) : BillingGateway, PurchasesUpdatedListener {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val refreshMutex = Mutex()

    private val liveProductDetails = ConcurrentHashMap<String, ProductDetails>()

    private val _connectionState = MutableStateFlow(BillingConnectionState.IDLE)
    override val connectionState: StateFlow<BillingConnectionState> = _connectionState.asStateFlow()

    private val _availableOffers = MutableStateFlow<List<SubscriptionOfferUiModel>>(emptyList())
    override val availableOffers: StateFlow<List<SubscriptionOfferUiModel>> = _availableOffers.asStateFlow()

    private val _entitlementState = MutableStateFlow(configStore.loadCachedEntitlement())
    override val entitlementState: StateFlow<SubscriptionEntitlementState> = _entitlementState.asStateFlow()

    override val billingConfiguration: StateFlow<PlayBillingConfiguration> = configStore.configuration

    private val _lastStatusMessage = MutableStateFlow<String?>(null)
    override val lastStatusMessage: StateFlow<String?> = _lastStatusMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    override val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    @Volatile
    private var pendingPurchaseAuthUid: String? = null

    @Volatile
    private var pendingPurchaseTrialHint: Boolean = false

    private val billingClient: BillingClient by lazy {
        BillingClient.newBuilder(appContext)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .enablePrepaidPlans()
                    .build(),
            )
            .enableAutoServiceReconnection()
            .build()
    }

    override fun consumeStatusMessage() {
        _lastStatusMessage.value = null
    }

    override fun connectAndRefresh(onComplete: (() -> Unit)?) {
        scope.launch {
            refreshProductsAndPurchases()
            onComplete?.invoke()
        }
    }

    private suspend fun ensureConnected(): BillingResult = withContext(Dispatchers.Main) {
        if (billingClient.isReady) {
            _connectionState.value = BillingConnectionState.CONNECTED
            return@withContext BillingResult.newBuilder()
                .setResponseCode(BillingResponseCode.OK)
                .build()
        }

        _connectionState.value = BillingConnectionState.CONNECTING
        val deferred = CompletableDeferred<BillingResult>()

        try {
            billingClient.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(billingResult: BillingResult) {
                    if (!deferred.isCompleted) {
                        deferred.complete(billingResult)
                    }
                    _connectionState.value = when (billingResult.responseCode) {
                        BillingResponseCode.OK -> BillingConnectionState.CONNECTED
                        BillingResponseCode.BILLING_UNAVAILABLE,
                        BillingResponseCode.FEATURE_NOT_SUPPORTED,
                        -> BillingConnectionState.UNAVAILABLE
                        else -> BillingConnectionState.ERROR
                    }
                }

                override fun onBillingServiceDisconnected() {
                    // enableAutoServiceReconnection handles reconnects automatically; track state only
                    if (_connectionState.value == BillingConnectionState.CONNECTED) {
                        _connectionState.value = BillingConnectionState.IDLE
                    }
                }
            })
        } catch (t: Throwable) {
            errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.SUBSCRIPTION,
                moduleName = DiagnosticModules.BILLING,
                operationName = "بدء الاتصال بـ Google Play Billing",
            )
            _connectionState.value = BillingConnectionState.UNAVAILABLE
            return@withContext BillingResult.newBuilder()
                .setResponseCode(BillingResponseCode.BILLING_UNAVAILABLE)
                .setDebugMessage(t.message.orEmpty())
                .build()
        }

        val awaited = withTimeoutOrNull(8_000L) { deferred.await() }
        if (awaited == null) {
            _connectionState.value = BillingConnectionState.ERROR
            return@withContext BillingResult.newBuilder()
                .setResponseCode(BillingResponseCode.SERVICE_TIMEOUT)
                .setDebugMessage("Connection timeout")
                .build()
        }
        awaited
    }

    override suspend fun refreshProductsAndPurchases(): BillingActionResult = refreshMutex.withLock {
        _isBusy.value = true
        try {
            val conn = ensureConnected()
            if (conn.responseCode != BillingResponseCode.OK) {
                val cached = configStore.loadCachedEntitlement()
                if (cached.isProEntitled) {
                    _entitlementState.value = cached.copy(isOfflineFallback = true)
                }
                val msg = BillingErrorMapper.toArabicMessage(conn)
                return@withLock BillingActionResult.Failure(
                    arabicMessage = msg,
                    responseCode = conn.responseCode,
                )
            }

            val config = configStore.currentConfiguration()
            var productQueryError: BillingActionResult.Failure? = null

            if (config.isConfigured) {
                val prodList = config.allConfiguredProductIds().map { pid ->
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(pid)
                        .setProductType(ProductType.SUBS)
                        .build()
                }
                val params = QueryProductDetailsParams.newBuilder()
                    .setProductList(prodList)
                    .build()
                val detailsResult = withContext(Dispatchers.IO) {
                    billingClient.queryProductDetails(params)
                }
                if (detailsResult.billingResult.responseCode == BillingResponseCode.OK) {
                    val fetched = detailsResult.productDetailsList.orEmpty()
                    liveProductDetails.clear()
                    fetched.forEach { pd -> liveProductDetails[pd.productId] = pd }
                    _availableOffers.value = mapProductDetailsToOffers(fetched, config)
                } else {
                    _availableOffers.value = emptyList()
                    productQueryError = BillingActionResult.Failure(
                        arabicMessage = BillingErrorMapper.toArabicMessage(detailsResult.billingResult),
                        responseCode = detailsResult.billingResult.responseCode,
                    )
                }
            } else {
                liveProductDetails.clear()
                _availableOffers.value = emptyList()
            }

            val purchaseRes = syncPurchasesFromPlayInternal(isExplicitRestore = false)
            if (purchaseRes is BillingActionResult.Failure) {
                return@withLock purchaseRes
            }
            if (productQueryError != null) {
                return@withLock productQueryError
            }
            purchaseRes
        } catch (t: Throwable) {
            errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.SUBSCRIPTION,
                moduleName = DiagnosticModules.BILLING,
                operationName = "تحديث الاشتراكات من Google Play",
            )
            BillingActionResult.Failure("تعذر تحديث حالة الاشتراك: ${t.message}")
        } finally {
            _isBusy.value = false
        }
    }

    override suspend fun restorePurchases(): BillingActionResult = refreshMutex.withLock {
        _isBusy.value = true
        try {
            val conn = ensureConnected()
            if (conn.responseCode != BillingResponseCode.OK) {
                val msg = BillingErrorMapper.toArabicMessage(conn)
                _lastStatusMessage.value = msg
                return@withLock BillingActionResult.Failure(msg, conn.responseCode)
            }
            val result = syncPurchasesFromPlayInternal(isExplicitRestore = true)
            when (result) {
                is BillingActionResult.Success -> _lastStatusMessage.value = result.message
                is BillingActionResult.Pending -> _lastStatusMessage.value = result.message
                is BillingActionResult.Failure -> _lastStatusMessage.value = result.arabicMessage
                is BillingActionResult.Cancelled -> Unit
            }
            result
        } finally {
            _isBusy.value = false
        }
    }

    private suspend fun syncPurchasesFromPlayInternal(isExplicitRestore: Boolean): BillingActionResult {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(ProductType.SUBS)
            .build()
        val purchasesResult = withContext(Dispatchers.IO) {
            billingClient.queryPurchasesAsync(params)
        }
        val billingResult = purchasesResult.billingResult
        if (billingResult.responseCode != BillingResponseCode.OK) {
            val cached = configStore.loadCachedEntitlement()
            if (cached.isProEntitled) {
                _entitlementState.value = cached.copy(isOfflineFallback = true)
            }
            return BillingActionResult.Failure(
                arabicMessage = BillingErrorMapper.toArabicMessage(billingResult),
                responseCode = billingResult.responseCode,
            )
        }

        return processPurchasesList(
            purchases = purchasesResult.purchasesList,
            isExplicitRestore = isExplicitRestore,
        )
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        scope.launch {
            when (billingResult.responseCode) {
                BillingResponseCode.OK -> {
                    val result = processPurchasesList(
                        purchases = purchases.orEmpty(),
                        isExplicitRestore = false,
                    )
                    when (result) {
                        is BillingActionResult.Success -> _lastStatusMessage.value = result.message
                        is BillingActionResult.Pending -> _lastStatusMessage.value = result.message
                        is BillingActionResult.Failure -> _lastStatusMessage.value = result.arabicMessage
                        is BillingActionResult.Cancelled -> Unit
                    }
                }
                BillingResponseCode.USER_CANCELED -> {
                    _lastStatusMessage.value = BillingErrorMapper.toArabicMessage(billingResult)
                }
                else -> {
                    val msg = BillingErrorMapper.toArabicMessage(billingResult)
                    _lastStatusMessage.value = msg
                    errorMonitor?.recordCustomError(
                        screenName = ScreenNames.SUBSCRIPTION,
                        moduleName = DiagnosticModules.BILLING,
                        operationName = "onPurchasesUpdated",
                        errorType = "PlayBillingResponse(${billingResult.responseCode})",
                        message = "Code=${billingResult.responseCode}, sub=${billingResult.onPurchasesUpdatedSubResponseCode}: $msg",
                    )
                }
            }
        }
    }

    private suspend fun processPurchasesList(
        purchases: List<Purchase>,
        isExplicitRestore: Boolean,
    ): BillingActionResult {
        val now = System.currentTimeMillis()
        val config = configStore.currentConfiguration()
        val configuredIds = config.allConfiguredProductIds().toSet()

        val relevantPurchases = if (configuredIds.isEmpty()) {
            purchases
        } else {
            purchases.filter { p -> p.products.any { it in configuredIds } }
        }

        val purchased = relevantPurchases.firstOrNull {
            it.purchaseState == Purchase.PurchaseState.PURCHASED &&
                (it.packageName.isBlank() || it.packageName == appContext.packageName) &&
                it.purchaseToken.isNotBlank()
        }

        if (purchased != null) {
            var acknowledged = purchased.isAcknowledged
            if (!acknowledged) {
                val ackParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchased.purchaseToken)
                    .build()
                val ackResult = withContext(Dispatchers.IO) {
                    billingClient.acknowledgePurchase(ackParams)
                }
                if (ackResult.responseCode != BillingResponseCode.OK) {
                    val err = "تم الدفع لكن تعذر تأكيد الاستلام مع Google Play حالياً: ${BillingErrorMapper.toArabicMessage(ackResult)}"
                    return BillingActionResult.Failure(err, ackResult.responseCode)
                }
                acknowledged = true
            }

            val productId = purchased.products.firstOrNull()
            val offerContext = _availableOffers.value.firstOrNull { it.productId == productId }
            val resolvedPlan = resolvePlanType(productId, offerContext?.basePlanId, config, offerContext?.planType)
            val resolvedStatus = when {
                !purchased.isAutoRenewing -> SubscriptionStatus.CANCELLED_GRACE
                pendingPurchaseTrialHint && (now - purchased.purchaseTime) < 7 * 24 * 60 * 60 * 1000L ->
                    SubscriptionStatus.TRIAL
                offerContext?.hasFreeTrial == true &&
                    _entitlementState.value.status == SubscriptionStatus.TRIAL &&
                    _entitlementState.value.purchaseToken == purchased.purchaseToken ->
                    SubscriptionStatus.TRIAL
                else -> SubscriptionStatus.ACTIVE
            }

            val updated = SubscriptionEntitlementState(
                status = resolvedStatus,
                planType = resolvedPlan,
                activeProductId = productId,
                activeBasePlanId = offerContext?.basePlanId,
                purchaseToken = purchased.purchaseToken,
                orderId = purchased.orderId,
                isAutoRenewing = purchased.isAutoRenewing,
                purchaseTimeMs = purchased.purchaseTime,
                isAcknowledged = acknowledged,
                linkedAuthUid = activeUidProvider() ?: pendingPurchaseAuthUid,
                verificationMode = VerificationMode.CLIENT_PLAY_BILLING,
                isOfflineFallback = false,
                lastCheckedMs = now,
            )
            pendingPurchaseTrialHint = false
            _entitlementState.value = updated
            configStore.saveCachedEntitlement(updated)

            return BillingActionResult.Success(
                if (isExplicitRestore) "تمت استعادة الاشتراك النشط بنجاح."
                else "تم تفعيل الاشتراك الاحترافي بنجاح.",
            )
        }

        val pending = relevantPurchases.firstOrNull { it.purchaseState == Purchase.PurchaseState.PENDING }
        if (pending != null) {
            val pendingState = SubscriptionEntitlementState(
                status = SubscriptionStatus.PENDING,
                planType = SubscriptionPlanType.FREE,
                activeProductId = pending.products.firstOrNull(),
                purchaseToken = pending.purchaseToken,
                orderId = pending.orderId,
                isAutoRenewing = pending.isAutoRenewing,
                purchaseTimeMs = pending.purchaseTime,
                isAcknowledged = false,
                linkedAuthUid = activeUidProvider(),
                verificationMode = VerificationMode.CLIENT_PLAY_BILLING,
                isOfflineFallback = false,
                lastCheckedMs = now,
            )
            _entitlementState.value = pendingState
            configStore.saveCachedEntitlement(pendingState)
            return BillingActionResult.Pending("عملية الدفع قيد الانتظار لدى Google Play. سيتم تفعيل المزايا فور اكتمال السداد.")
        }

        // No active or pending purchase returned by Google Play
        val previous = configStore.loadCachedEntitlement()
        val expiredOrFreeStatus = if (previous.purchaseToken != null) {
            SubscriptionStatus.ON_HOLD_EXPIRED
        } else {
            SubscriptionStatus.FREE
        }
        val resetState = SubscriptionEntitlementState(
            status = expiredOrFreeStatus,
            planType = SubscriptionPlanType.FREE,
            activeProductId = previous.activeProductId,
            activeBasePlanId = previous.activeBasePlanId,
            purchaseToken = null,
            orderId = null,
            isAutoRenewing = false,
            purchaseTimeMs = previous.purchaseTimeMs,
            isAcknowledged = false,
            linkedAuthUid = activeUidProvider(),
            verificationMode = VerificationMode.CLIENT_PLAY_BILLING,
            isOfflineFallback = false,
            lastCheckedMs = now,
        )
        _entitlementState.value = resetState
        configStore.saveCachedEntitlement(resetState)

        return if (isExplicitRestore) {
            BillingActionResult.Failure("لم يتم العثور على اشتراكات نشطة في حساب Google Play الحالي.", isRecoverable = true)
        } else {
            BillingActionResult.Success("تم تحديث حالة الاشتراك من Google Play.")
        }
    }

    override suspend fun launchSubscriptionPurchase(
        activity: Activity,
        offer: SubscriptionOfferUiModel,
        obfuscatedAccountUid: String?,
    ): BillingActionResult {
        val conn = ensureConnected()
        if (conn.responseCode != BillingResponseCode.OK) {
            return BillingActionResult.Failure(BillingErrorMapper.toArabicMessage(conn), conn.responseCode)
        }

        val productDetails = liveProductDetails[offer.productId]
            ?: run {
                refreshProductsAndPurchases()
                liveProductDetails[offer.productId]
            }
            ?: return BillingActionResult.Failure(
                "تعذر تحميل تفاصيل الباقة من Google Play؛ تحقق من معرف المنتج والاتصال.",
            )

        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(productDetails)
            .setOfferToken(offer.offerToken)
            .build()

        val flowBuilder = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))

        if (!obfuscatedAccountUid.isNullOrBlank()) {
            flowBuilder.setObfuscatedAccountId(hashUidForPlay(obfuscatedAccountUid))
        }

        pendingPurchaseAuthUid = obfuscatedAccountUid
        pendingPurchaseTrialHint = offer.hasFreeTrial

        val launchResult = withContext(Dispatchers.Main) {
            billingClient.launchBillingFlow(activity, flowBuilder.build())
        }
        return if (launchResult.responseCode == BillingResponseCode.OK) {
            BillingActionResult.Success("تم فتح نافذة الدفع عبر Google Play.")
        } else if (launchResult.responseCode == BillingResponseCode.USER_CANCELED) {
            BillingActionResult.Cancelled(BillingErrorMapper.toArabicMessage(launchResult))
        } else {
            BillingActionResult.Failure(
                BillingErrorMapper.toArabicMessage(launchResult),
                launchResult.responseCode,
            )
        }
    }

    override suspend fun updateBillingConfiguration(config: PlayBillingConfiguration) {
        configStore.saveConfiguration(config)
        refreshProductsAndPurchases()
    }

    override fun openPlaySubscriptionsCenter(context: Context) {
        val activeProductId = _entitlementState.value.activeProductId
            ?: configStore.currentConfiguration().allConfiguredProductIds().firstOrNull()
        val url = if (!activeProductId.isNullOrBlank()) {
            "https://play.google.com/store/account/subscriptions?sku=${Uri.encode(activeProductId)}&package=${Uri.encode(context.packageName)}"
        } else {
            "https://play.google.com/store/account/subscriptions"
        }
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            _lastStatusMessage.value = "تعذر فتح مركز اشتراكات Google Play على هذا الجهاز."
        }
    }

    override fun release() {
        runCatching {
            if (billingClient.isReady) {
                billingClient.endConnection()
            }
        }
    }

    companion object {
        fun mapProductDetailsToOffers(
            detailsList: List<ProductDetails>,
            config: PlayBillingConfiguration,
        ): List<SubscriptionOfferUiModel> {
            val out = mutableListOf<SubscriptionOfferUiModel>()
            for (pd in detailsList) {
                val offers = pd.subscriptionOfferDetails.orEmpty()
                if (offers.isEmpty()) continue

                // Group by basePlanId so if user is eligible for a free-trial offer we prefer it cleanly
                val byBasePlan = offers.groupBy { it.basePlanId }
                for ((basePlanId, basePlanOffers) in byBasePlan) {
                    val preferredOffer = selectBestOfferForBasePlan(basePlanOffers, config.trialOfferId)
                    val phases = preferredOffer.pricingPhases.pricingPhaseList
                    if (phases.isEmpty()) continue

                    val trialPhase = phases.firstOrNull { it.priceAmountMicros == 0L }
                    val recurringPhase = phases.lastOrNull { it.priceAmountMicros > 0L } ?: phases.last()
                    val billingIso = recurringPhase.billingPeriod
                    val planType = resolvePlanType(pd.productId, basePlanId, config, null)
                    val trialDays = trialPhase?.let { BillingPeriodParser.parseDays(it.billingPeriod) } ?: 0
                    val trialLabel = if (trialPhase != null && trialDays > 0) {
                        "تجربة مجانية لمدة $trialDays أيام"
                    } else if (trialPhase != null) {
                        "تجربة مجانية متاحة"
                    } else null

                    out += SubscriptionOfferUiModel(
                        productId = pd.productId,
                        basePlanId = basePlanId,
                        offerId = preferredOffer.offerId,
                        offerToken = preferredOffer.offerToken,
                        planType = planType,
                        title = pd.title.ifBlank { planType.arabicTitle },
                        description = pd.description,
                        formattedPrice = recurringPhase.formattedPrice,
                        priceCurrencyCode = recurringPhase.priceCurrencyCode,
                        billingPeriodIso = billingIso,
                        billingPeriodArabic = BillingPeriodParser.toArabicPeriodLabel(billingIso),
                        hasFreeTrial = trialPhase != null,
                        freeTrialDays = trialDays,
                        freeTrialLabel = trialLabel,
                    )
                }
            }
            return out.sortedBy {
                when (it.planType) {
                    SubscriptionPlanType.PRO_MONTHLY -> 0
                    SubscriptionPlanType.PRO_YEARLY -> 1
                    SubscriptionPlanType.FREE -> 2
                }
            }
        }

        private fun selectBestOfferForBasePlan(
            offers: List<ProductDetails.SubscriptionOfferDetails>,
            preferredOfferId: String,
        ): ProductDetails.SubscriptionOfferDetails {
            if (preferredOfferId.isNotBlank()) {
                offers.firstOrNull { it.offerId == preferredOfferId }?.let { return it }
            }
            offers.firstOrNull { offer ->
                offer.pricingPhases.pricingPhaseList.any { it.priceAmountMicros == 0L }
            }?.let { return it }
            return offers.firstOrNull { it.offerId == null } ?: offers.first()
        }

        fun resolvePlanType(
            productId: String?,
            basePlanId: String?,
            config: PlayBillingConfiguration,
            fallback: SubscriptionPlanType?,
        ): SubscriptionPlanType {
            if (fallback != null && fallback != SubscriptionPlanType.FREE) return fallback
            val pid = productId?.trim().orEmpty()
            val bp = basePlanId?.trim().orEmpty()
            if (pid.isNotEmpty() && pid.equals(config.yearlyProductId, ignoreCase = true)) {
                return SubscriptionPlanType.PRO_YEARLY
            }
            if (pid.isNotEmpty() && pid.equals(config.monthlyProductId, ignoreCase = true)) {
                return SubscriptionPlanType.PRO_MONTHLY
            }
            if (bp.isNotEmpty() && bp.equals(config.yearlyBasePlanId, ignoreCase = true)) {
                return SubscriptionPlanType.PRO_YEARLY
            }
            if (bp.isNotEmpty() && bp.equals(config.monthlyBasePlanId, ignoreCase = true)) {
                return SubscriptionPlanType.PRO_MONTHLY
            }
            if (bp.contains("year", ignoreCase = true) || bp.contains("annual", ignoreCase = true) ||
                pid.contains("year", ignoreCase = true) || pid.contains("annual", ignoreCase = true)
            ) {
                return SubscriptionPlanType.PRO_YEARLY
            }
            return SubscriptionPlanType.PRO_MONTHLY
        }

        private fun hashUidForPlay(uid: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(uid.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }.take(64)
        }
    }
}
