package com.example.domain.barcode

import android.view.View
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.ScreenNames
import com.google.mlkit.vision.barcode.BarcodeScanner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Manages a long-lived daemon executor for CameraX ImageAnalysis and ML Kit Task listeners
 * so leaving or rapidly toggling screens (e.g., Inventory <-> BarcodeScanner) NEVER terminates
 * an executor while asynchronous GMS Tasks are still completing on another thread.
 */
class CameraAnalysisExecutorManager(
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val threadCounter = AtomicInteger(0)

    @Volatile
    private var sharedExecutor: ExecutorService = newManagedExecutor()

    val executor: ExecutorService
        get() {
            val current = sharedExecutor
            if (!current.isShutdown && !current.isTerminated) {
                return current
            }
            synchronized(this) {
                val rechecked = sharedExecutor
                if (rechecked.isShutdown || rechecked.isTerminated) {
                    sharedExecutor = newManagedExecutor()
                }
                return sharedExecutor
            }
        }

    fun newSession(scanner: BarcodeScanner? = null): ScannerSessionHandle =
        ScannerSessionHandle(scanner = scanner, errorMonitor = errorMonitor)

    fun postUiIfActive(
        session: ScannerSessionHandle,
        view: View,
        screenName: String = ScreenNames.BARCODE_SCANNER,
        block: () -> Unit,
    ) {
        if (session.isDisposed) return
        val posted = view.post {
            if (!session.isDisposed) {
                try {
                    block()
                } catch (t: Throwable) {
                    errorMonitor?.recordError(
                        throwable = t,
                        screenName = screenName,
                        moduleName = DiagnosticModules.BARCODE_CAMERA,
                        operationName = "معالجة نتيجة مسح الباركود على الواجهة",
                        wasHandled = true,
                        severity = LogSeverity.ERROR,
                    )
                }
            }
        }
        if (!posted && !session.isDisposed) {
            errorMonitor?.recordCustomError(
                screenName = screenName,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = "إرسال نتيجة مسح الباركود",
                errorType = "ViewDetachedBeforeResult",
                message = "تعذر إرسال النتيجة لأن واجهة الماسح انفصلت عن الشاشة قبل اكتمال الإطار.",
                wasHandled = true,
                severity = LogSeverity.WARNING,
            )
        }
    }

    fun dispatchSafe(
        targetExecutor: ExecutorService = executor,
        session: ScannerSessionHandle? = null,
        screenName: String = ScreenNames.BARCODE_SCANNER,
        operationName: String = "تشغيل مهمة تحليل الباركود",
        task: () -> Unit,
    ): Boolean {
        if (session?.isDisposed == true) return false
        return try {
            targetExecutor.execute {
                if (session?.isDisposed == true) return@execute
                try {
                    task()
                } catch (t: Throwable) {
                    errorMonitor?.recordError(
                        throwable = t,
                        screenName = screenName,
                        moduleName = DiagnosticModules.BARCODE_CAMERA,
                        operationName = operationName,
                        wasHandled = true,
                        severity = LogSeverity.ERROR,
                    )
                }
            }
            true
        } catch (rejected: RejectedExecutionException) {
            errorMonitor?.recordError(
                throwable = rejected,
                screenName = screenName,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = operationName,
                wasHandled = true,
                severity = LogSeverity.ERROR,
            )
            false
        }
    }

    private fun newManagedExecutor(): ExecutorService {
        val factory = ThreadFactory { runnable ->
            Thread(runnable, "camera-barcode-worker-${threadCounter.incrementAndGet()}").apply {
                isDaemon = true
            }
        }
        return Executors.newSingleThreadExecutor(factory)
    }
}

/**
 * Coordinates async ML Kit / CameraX callback gating and defers BarcodeScanner.close()
 * until all in-flight asynchronous callbacks finish safely.
 */
class ScannerSessionHandle(
    private val scanner: BarcodeScanner? = null,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val disposedFlag = AtomicBoolean(false)
    private val scannerClosedFlag = AtomicBoolean(false)
    private val inFlightCallbacks = AtomicInteger(0)

    val isDisposed: Boolean
        get() = disposedFlag.get()

    val inFlightCount: Int
        get() = inFlightCallbacks.get()

    val isScannerClosed: Boolean
        get() = scannerClosedFlag.get()

    fun beginAsyncWork(): Boolean {
        if (disposedFlag.get()) return false
        inFlightCallbacks.incrementAndGet()
        if (disposedFlag.get()) {
            endAsyncWork()
            return false
        }
        return true
    }

    fun endAsyncWork() {
        val remaining = inFlightCallbacks.decrementAndGet().coerceAtLeast(0)
        if (remaining == 0 && disposedFlag.get()) {
            closeScannerIfReady()
        }
    }

    fun disposeAndCloseWhenIdle() {
        disposedFlag.set(true)
        if (inFlightCallbacks.get() <= 0) {
            closeScannerIfReady()
        }
    }

    private fun closeScannerIfReady() {
        if (scannerClosedFlag.compareAndSet(false, true)) {
            runCatching {
                scanner?.close()
            }.onFailure { err ->
                errorMonitor?.recordError(
                    throwable = err,
                    screenName = ScreenNames.BARCODE_SCANNER,
                    moduleName = DiagnosticModules.BARCODE_CAMERA,
                    operationName = "إغلاق ماسح الباركود بعد اكتمال الإطارات",
                    wasHandled = true,
                    severity = LogSeverity.WARNING,
                )
            }
        }
    }
}
