package com.example.domain.diagnostics

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

/**
 * Crash-safe, SQLite-independent persistent storage for diagnostics, pending crashes,
 * and rotating operation logs.
 *
 * Uses strict file size limits and log rotation so diagnostic logs never consume unbounded storage
 * and never throw exceptions back to callers.
 */
class DiagnosticsFileStore(
    private val baseFilesDir: File,
) {
    private val lock = Any()
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val diagnosticsDir: File
        get() = File(baseFilesDir, "diagnostics").apply { mkdirs() }

    private val errorsFile: File get() = File(diagnosticsDir, "errors_log.jsonl")
    private val errorsPrevFile: File get() = File(diagnosticsDir, "errors_log.prev.jsonl")
    private val opsFile: File get() = File(diagnosticsDir, "ops_log.jsonl")
    private val opsPrevFile: File get() = File(diagnosticsDir, "ops_log.prev.jsonl")
    private val pendingCrashFile: File get() = File(diagnosticsDir, "pending_crash.json")
    private val lastRestoreFile: File get() = File(diagnosticsDir, "last_restore_diagnostics.json")
    private val pendingRestoreVerifyFile: File get() = File(diagnosticsDir, "pending_restore_verify.json")

    companion object {
        const val MAX_ERROR_LOG_BYTES = 512L * 1024L
        const val MAX_OPS_LOG_BYTES = 512L * 1024L
        const val MAX_IN_MEMORY_ERRORS = 400
        const val MAX_IN_MEMORY_OPS = 500
    }

    fun writeAllErrors(errors: List<ErrorEventRecord>) {
        synchronized(lock) {
            runCatching {
                val capped = errors.sortedByDescending { it.lastSeenAt }.take(MAX_IN_MEMORY_ERRORS)
                if (errorsFile.exists() && errorsFile.length() > MAX_ERROR_LOG_BYTES) {
                    errorsFile.copyTo(errorsPrevFile, overwrite = true)
                }
                val sb = StringBuilder()
                capped.forEach { record ->
                    sb.append(json.encodeToString(record)).append('\n')
                }
                atomicWriteString(errorsFile, sb.toString())
            }
        }
    }

    fun appendErrorSynchronous(record: ErrorEventRecord) {
        synchronized(lock) {
            runCatching {
                if (errorsFile.exists() && errorsFile.length() > MAX_ERROR_LOG_BYTES) {
                    errorsFile.copyTo(errorsPrevFile, overwrite = true)
                    errorsFile.writeText("")
                }
                val line = json.encodeToString(record) + "\n"
                FileOutputStream(errorsFile, true).use { fos ->
                    fos.write(line.toByteArray(Charsets.UTF_8))
                    fos.flush()
                    runCatching { fos.fd.sync() }
                }
            }
        }
    }

    fun readAllErrors(): List<ErrorEventRecord> {
        synchronized(lock) {
            return runCatching {
                val files = listOfNotNull(
                    errorsPrevFile.takeIf { it.exists() },
                    errorsFile.takeIf { it.exists() },
                )
                val map = linkedMapOf<String, ErrorEventRecord>()
                files.forEach { file ->
                    file.forEachLine(Charsets.UTF_8) { line ->
                        if (line.isNotBlank()) {
                            runCatching { json.decodeFromString<ErrorEventRecord>(line) }.getOrNull()?.let { rec ->
                                map[rec.errorId] = rec
                            }
                        }
                    }
                }
                map.values.sortedByDescending { it.lastSeenAt }.take(MAX_IN_MEMORY_ERRORS)
            }.getOrDefault(emptyList())
        }
    }

    fun writeAllOperations(ops: List<OperationLogRecord>, syncToDisk: Boolean = false) {
        synchronized(lock) {
            runCatching {
                val capped = ops.sortedByDescending { it.startTime }.take(MAX_IN_MEMORY_OPS)
                if (opsFile.exists() && opsFile.length() > MAX_OPS_LOG_BYTES) {
                    opsFile.copyTo(opsPrevFile, overwrite = true)
                }
                val sb = StringBuilder()
                capped.forEach { rec ->
                    sb.append(json.encodeToString(rec)).append('\n')
                }
                atomicWriteString(opsFile, sb.toString(), sync = syncToDisk)
            }
        }
    }

    fun readAllOperations(): List<OperationLogRecord> {
        synchronized(lock) {
            return runCatching {
                val files = listOfNotNull(
                    opsPrevFile.takeIf { it.exists() },
                    opsFile.takeIf { it.exists() },
                )
                val map = linkedMapOf<String, OperationLogRecord>()
                files.forEach { file ->
                    file.forEachLine(Charsets.UTF_8) { line ->
                        if (line.isNotBlank()) {
                            runCatching { json.decodeFromString<OperationLogRecord>(line) }.getOrNull()?.let { rec ->
                                map[rec.operationId] = rec
                            }
                        }
                    }
                }
                map.values.sortedByDescending { it.startTime }.take(MAX_IN_MEMORY_OPS)
            }.getOrDefault(emptyList())
        }
    }

    fun writePendingCrashSynchronous(crash: ErrorEventRecord) {
        synchronized(lock) {
            runCatching {
                atomicWriteString(pendingCrashFile, json.encodeToString(crash), sync = true)
            }
        }
    }

    fun consumePendingCrash(): ErrorEventRecord? {
        synchronized(lock) {
            return runCatching {
                if (!pendingCrashFile.exists()) return null
                val content = pendingCrashFile.readText(Charsets.UTF_8)
                pendingCrashFile.delete()
                if (content.isBlank()) null else json.decodeFromString<ErrorEventRecord>(content)
            }.getOrNull()
        }
    }

    fun peekPendingCrash(): ErrorEventRecord? {
        synchronized(lock) {
            return runCatching {
                if (!pendingCrashFile.exists()) return null
                val content = pendingCrashFile.readText(Charsets.UTF_8)
                if (content.isBlank()) null else json.decodeFromString<ErrorEventRecord>(content)
            }.getOrNull()
        }
    }

    fun saveLastRestoreDiagnostics(report: RestoreDiagnosticsReport) {
        synchronized(lock) {
            runCatching {
                atomicWriteString(lastRestoreFile, json.encodeToString(report))
            }
        }
    }

    fun readLastRestoreDiagnostics(): RestoreDiagnosticsReport? {
        synchronized(lock) {
            return runCatching {
                if (!lastRestoreFile.exists()) return null
                val text = lastRestoreFile.readText(Charsets.UTF_8)
                if (text.isBlank()) null else json.decodeFromString<RestoreDiagnosticsReport>(text)
            }.getOrNull()
        }
    }

    fun savePendingRestoreVerification(pending: PendingRestoreVerification) {
        synchronized(lock) {
            runCatching {
                atomicWriteString(pendingRestoreVerifyFile, json.encodeToString(pending), sync = true)
            }
        }
    }

    fun consumePendingRestoreVerification(): PendingRestoreVerification? {
        synchronized(lock) {
            return runCatching {
                if (!pendingRestoreVerifyFile.exists()) return null
                val content = pendingRestoreVerifyFile.readText(Charsets.UTF_8)
                pendingRestoreVerifyFile.delete()
                if (content.isBlank()) null else json.decodeFromString<PendingRestoreVerification>(content)
            }.getOrNull()
        }
    }

    fun totalDiagnosticStorageBytes(): Long {
        synchronized(lock) {
            return runCatching {
                diagnosticsDir.listFiles()?.sumOf { if (it.isFile) it.length() else 0L } ?: 0L
            }.getOrDefault(0L)
        }
    }

    fun clearAllLogs() {
        synchronized(lock) {
            runCatching {
                errorsFile.delete()
                errorsPrevFile.delete()
                opsFile.delete()
                opsPrevFile.delete()
                pendingCrashFile.delete()
            }
        }
    }

    private fun atomicWriteString(target: File, text: String, sync: Boolean = false) {
        diagnosticsDir.mkdirs()
        val tmp = File(diagnosticsDir, "${target.name}.tmp")
        FileOutputStream(tmp).use { fos ->
            fos.write(text.toByteArray(Charsets.UTF_8))
            fos.flush()
            if (sync) {
                runCatching { fos.fd.sync() }
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) {
            target.writeText(text, Charsets.UTF_8)
            tmp.delete()
        }
    }
}
