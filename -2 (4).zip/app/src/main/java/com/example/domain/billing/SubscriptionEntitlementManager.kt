package com.example.domain.billing

import com.example.domain.auth.AuthGateway
import kotlinx.coroutines.flow.StateFlow

class SubscriptionEntitlementManager(
    private val billingGateway: BillingGateway,
    private val authGateway: AuthGateway,
) {
    val entitlementState: StateFlow<SubscriptionEntitlementState> = billingGateway.entitlementState
    val billingConfiguration: StateFlow<PlayBillingConfiguration> = billingGateway.billingConfiguration

    fun isProActive(): Boolean = entitlementState.value.isProEntitled

    /**
     * Core invariant: Free features and access to all historical user data, reports, logs,
     * and ZIP backup/restore NEVER lock or expire even after a subscription ends or without login.
     */
    @Suppress("UNUSED_PARAMETER")
    fun canAccessFreeFeature(feature: FreeFeature): Boolean = true

    fun hasProAccess(feature: ProFeature): Boolean {
        return entitlementState.value.isProEntitled
    }

    fun checkProFeatureAccess(feature: ProFeature): FeatureAccessDecision {
        val state = entitlementState.value
        return if (state.isProEntitled) {
            FeatureAccessDecision.Allowed
        } else {
            FeatureAccessDecision.RequiresProUpgrade(
                feature = feature,
                currentStatus = state.status,
                isBillingConfigured = billingConfiguration.value.isConfigured,
            )
        }
    }

    fun currentObfuscatedUid(): String? = authGateway.currentUser()?.uid
}
