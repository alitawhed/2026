package com.example.domain.billing

import android.app.Activity
import android.content.Context
import kotlinx.coroutines.flow.StateFlow

interface BillingGateway {
    val connectionState: StateFlow<BillingConnectionState>
    val availableOffers: StateFlow<List<SubscriptionOfferUiModel>>
    val entitlementState: StateFlow<SubscriptionEntitlementState>
    val billingConfiguration: StateFlow<PlayBillingConfiguration>
    val lastStatusMessage: StateFlow<String?>
    val isBusy: StateFlow<Boolean>

    fun connectAndRefresh(onComplete: (() -> Unit)? = null)
    suspend fun refreshProductsAndPurchases(): BillingActionResult
    suspend fun launchSubscriptionPurchase(
        activity: Activity,
        offer: SubscriptionOfferUiModel,
        obfuscatedAccountUid: String? = null,
    ): BillingActionResult

    suspend fun restorePurchases(): BillingActionResult
    suspend fun updateBillingConfiguration(config: PlayBillingConfiguration)
    fun consumeStatusMessage()
    fun openPlaySubscriptionsCenter(context: Context)
    fun release()
}
