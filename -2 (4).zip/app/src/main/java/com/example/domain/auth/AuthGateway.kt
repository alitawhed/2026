package com.example.domain.auth

import kotlinx.coroutines.flow.StateFlow

interface AuthGateway {
    val authStateFlow: StateFlow<AuthUserProfile?>

    fun currentUser(): AuthUserProfile?

    fun configurationStatus(): AuthConfigurationStatus

    suspend fun signInWithGoogleIdToken(idToken: String): AuthActionResult

    suspend fun signInWithEmail(email: String, password: String): AuthActionResult

    suspend fun registerWithEmail(
        email: String,
        password: String,
        displayName: String,
    ): AuthActionResult

    suspend fun sendEmailVerification(): AuthActionResult

    suspend fun reloadCurrentUser(): AuthActionResult

    suspend fun sendPasswordResetEmail(email: String): AuthActionResult

    suspend fun updatePassword(
        currentPassword: String?,
        newPassword: String,
    ): AuthActionResult

    suspend fun linkGoogleIdToken(idToken: String): AuthActionResult

    suspend fun linkEmailPassword(email: String, password: String): AuthActionResult

    suspend fun unlinkProvider(providerType: AuthProviderType): AuthActionResult

    suspend fun reauthenticateWithGoogleIdToken(idToken: String): AuthActionResult

    suspend fun reauthenticateWithEmailPassword(email: String, password: String): AuthActionResult

    suspend fun signOut(): AuthActionResult

    suspend fun deleteCurrentAccount(): AuthActionResult
}
