package com.example.domain.backup

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.room.withTransaction
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.InventorySessionEntity
import com.example.data.local.entity.PdfDocumentEntity
import com.example.data.local.entity.PdfPageEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ReportColumnEntity
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemBarcodeEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportItemImageEntity
import com.example.data.local.entity.ReportTemplateEntity
import com.example.data.local.entity.StockAdjustmentLogEntity
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.OperationStageRecord
import com.example.domain.diagnostics.PendingRestoreVerification
import com.example.domain.diagnostics.RestoreDiagnosticsReport
import com.example.domain.diagnostics.RestoreVerificationCheck
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class BackupFileEntry(
    val relativePath: String,
    val sizeBytes: Long = 0L,
    val sha256: String = "",
)

@Serializable
data class BackupManifest(
    val formatVersion: Int = 6,
    val appName: String = "مدير التقارير",
    val createdAt: Long = System.currentTimeMillis(),
    val appVersion: String = BuildConfig.VERSION_NAME,
    val appVersionCode: Int = BuildConfig.VERSION_CODE,
    val databaseSchemaVersion: Int = 11,
    val backupDateIso: String = "",
    val deviceSdkInt: Int = Build.VERSION.SDK_INT,
    val productCount: Int = 0,
    val barcodeCount: Int = 0,
    val imageCount: Int = 0,
    val reportCount: Int = 0,
    val templateCount: Int = 0,
    val pdfDocumentCount: Int = 0,
    val inventorySessionCount: Int = 0,
    val inventoryItemCount: Int = 0,
    val expectedAssetPaths: List<String> = emptyList(),
    val filesManifest: List<BackupFileEntry> = emptyList(),
)

@Serializable
data class BackupDatabasePayload(
    val settings: AppSettingsEntity? = null,
    val categories: List<CategoryEntity> = emptyList(),
    val products: List<ProductEntity> = emptyList(),
    val productBarcodes: List<ProductBarcodeEntity> = emptyList(),
    val productImages: List<ProductImageEntity> = emptyList(),
    val productImageDownloads: List<ProductImageDownloadEntity> = emptyList(),
    val templates: List<ReportTemplateEntity> = emptyList(),
    val reports: List<ReportEntity> = emptyList(),
    val reportItems: List<ReportItemEntity> = emptyList(),
    val reportItemBarcodes: List<ReportItemBarcodeEntity> = emptyList(),
    val reportItemImages: List<ReportItemImageEntity> = emptyList(),
    val reportColumns: List<ReportColumnEntity> = emptyList(),
    val pdfDocuments: List<PdfDocumentEntity> = emptyList(),
    val pdfPages: List<PdfPageEntity> = emptyList(),
    val inventorySessions: List<InventorySessionEntity> = emptyList(),
    val inventoryCountItems: List<InventoryCountItemEntity> = emptyList(),
    val stockAdjustmentLogs: List<StockAdjustmentLogEntity> = emptyList(),
)

data class BackupInspectionResult(
    val isValid: Boolean,
    val manifest: BackupManifest?,
    val missingFiles: List<String>,
    val corruptedFiles: List<String> = emptyList(),
    val errorMessage: String? = null,
    val rawZipBytes: ByteArray = ByteArray(0),
    val stagedZipFilePath: String = "",
    val sourceDisplayName: String = "restored_backup.zip",
    val warnings: List<String> = emptyList(),
)

class BackupRestoreEngine(
    private val context: Context,
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    companion object {
        const val CURRENT_BACKUP_FORMAT_VERSION = 6
        const val CURRENT_DB_SCHEMA_VERSION = 11
        private const val IO_BUFFER_SIZE = 16 * 1024
        private const val MAX_JSON_ENTRY_BYTES = 64L * 1024L * 1024L
    }

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
        coerceInputValues = true
    }

    suspend fun createBackupZip(customName: String = ""): Result<File> = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.BACKUP_RESTORE,
            moduleName = DiagnosticModules.BACKUP_RESTORE,
            operationName = "إنشاء نسخة احتياطية شاملة (ZIP)",
            initialStage = "جمع بيانات SQLite",
        )
        try {
            val settings = db.settingsDao().getSettingsOnce() ?: AppSettingsEntity()
            val categories = db.categoryDao().getAllCategoriesOnce()
            val products = db.productDao().getAllProductsOnce()
            val barcodes = db.productDao().getAllBarcodesOnce()
            val images = db.productDao().getAllImagesOnce()
            val imageDownloads = db.productDao().getAllImageDownloadsOnce()
            val templates = db.templateDao().getAllTemplatesOnce()
            val reportsWithDetails = db.reportDao().getAllReportsWithDetailsOnce()
            val pdfDocsWithPages = db.pdfDocumentDao().getAllDocumentsOnce()
            val inventorySessions = db.inventoryDao().getAllSessionsOnce()
            val inventoryCountItems = db.inventoryDao().getAllCountItemsOnce()
            val stockAdjustmentLogs = db.inventoryDao().getAllAdjustmentLogsOnce()

            val reports = reportsWithDetails.map { it.report }
            val reportItems = reportsWithDetails.flatMap { it.items.map { item -> item.item } }
            val reportItemBarcodes = reportsWithDetails.flatMap { it.items.flatMap { item -> item.barcodes } }
            val reportItemImages = reportsWithDetails.flatMap { it.items.flatMap { item -> item.images } }
            val reportColumns = reportsWithDetails.flatMap { it.columns }
            val pdfDocs = pdfDocsWithPages.map { it.document }
            val pdfPages = pdfDocsWithPages.flatMap { it.pages }

            trace?.stage("فحص وتجهيز مسارات الصور والملفات")
            val filesToArchive = linkedMapOf<String, File>() // zipEntryPath -> physicalFile
            val physicalToZipKey = mutableMapOf<String, String>()

            fun registerFile(rawPath: String, zipPrefix: String): String {
                val cleaned = cleanFilePath(rawPath)
                if (cleaned.isBlank()) return ""
                val f = File(cleaned)
                if (!f.exists() || !f.isFile || f.length() <= 0L) return ""
                val canonical = runCatching { f.canonicalPath }.getOrDefault(f.absolutePath)
                physicalToZipKey[canonical]?.let { existingKey ->
                    if (existingKey.startsWith("$zipPrefix/")) return existingKey
                }
                val safeName = sanitizeFileName(f.name)
                var candidateKey = "$zipPrefix/$safeName"
                var collisionCounter = 1
                while (filesToArchive.containsKey(candidateKey)) {
                    val existingCanonical = runCatching { filesToArchive[candidateKey]?.canonicalPath }.getOrNull()
                    if (existingCanonical == canonical) return candidateKey
                    val dot = safeName.lastIndexOf('.')
                    val numberedName = if (dot > 0) {
                        "${safeName.substring(0, dot)}_$collisionCounter${safeName.substring(dot)}"
                    } else {
                        "${safeName}_$collisionCounter"
                    }
                    candidateKey = "$zipPrefix/$numberedName"
                    collisionCounter++
                }
                filesToArchive[candidateKey] = f
                physicalToZipKey[canonical] = candidateKey
                return candidateKey
            }

            val remappedSettings = settings.copy(
                companyLogoPath = registerFile(settings.companyLogoPath, "assets/branding"),
            )
            val remappedImages = images.map { img ->
                img.copy(
                    filePath = registerFile(img.filePath, "assets/products"),
                    originalFilePath = registerFile(img.originalFilePath, "assets/originals"),
                    thumbnailPath = registerFile(img.thumbnailPath, "assets/thumbnails"),
                )
            }
            val remappedReports = reports.map { r ->
                r.copy(
                    companyLogoPath = registerFile(r.companyLogoPath, "assets/branding"),
                    signaturePath = registerFile(r.signaturePath, "assets/branding"),
                    stampPath = registerFile(r.stampPath, "assets/branding"),
                    lastPdfPath = registerFile(r.lastPdfPath, "assets/pdfs"),
                )
            }
            val remappedItems = reportItems.map { item ->
                item.copy(
                    imageSnapshotPath = registerFile(item.imageSnapshotPath, "assets/reports/${item.reportId}"),
                )
            }
            val reportIdByItemId = reportItems.associate { it.id to it.reportId }
            val remappedReportItemImages = reportItemImages.map { img ->
                val parentReportId = reportIdByItemId[img.reportItemId] ?: img.reportId
                img.copy(filePath = registerFile(img.filePath, "assets/reports/$parentReportId"))
            }
            val remappedPdfDocs = pdfDocs.map { doc ->
                doc.copy(
                    workingFilePath = registerFile(doc.workingFilePath, "assets/pdfs"),
                    originalFilePath = registerFile(doc.originalFilePath, "assets/pdfs"),
                )
            }
            val remappedPdfPages = pdfPages.map { page ->
                page.copy(
                    sourcePdfPath = registerFile(page.sourcePdfPath, "assets/pdfs"),
                    thumbnailPath = registerFile(page.thumbnailPath, "assets/thumbnails"),
                )
            }
            val remappedInventoryItems = inventoryCountItems.map { item ->
                item.copy(
                    productImagePath = registerFile(item.productImagePath, "assets/thumbnails"),
                )
            }
            val remappedImageDownloads = imageDownloads.map { dl ->
                dl.copy(
                    localFilePath = registerFile(dl.localFilePath, "assets/products"),
                    originalFilePath = registerFile(dl.originalFilePath, "assets/originals"),
                    thumbnailPath = registerFile(dl.thumbnailPath, "assets/thumbnails"),
                )
            }

            val payload = BackupDatabasePayload(
                settings = remappedSettings,
                categories = categories,
                products = products,
                productBarcodes = barcodes,
                productImages = remappedImages,
                productImageDownloads = remappedImageDownloads,
                templates = templates,
                reports = remappedReports,
                reportItems = remappedItems,
                reportItemBarcodes = reportItemBarcodes,
                reportItemImages = remappedReportItemImages,
                reportColumns = reportColumns,
                pdfDocuments = remappedPdfDocs,
                pdfPages = remappedPdfPages,
                inventorySessions = inventorySessions,
                inventoryCountItems = remappedInventoryItems,
                stockAdjustmentLogs = stockAdjustmentLogs,
            )

            trace?.stage("حساب بصمات التحقق SHA-256 للملفات")
            val filesManifest = filesToArchive.entries.sortedBy { it.key }.map { (zipKey, physicalFile) ->
                BackupFileEntry(
                    relativePath = zipKey,
                    sizeBytes = physicalFile.length(),
                    sha256 = computeSha256(physicalFile),
                )
            }

            val now = System.currentTimeMillis()
            val isoDate = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date(now))
            val manifest = BackupManifest(
                formatVersion = CURRENT_BACKUP_FORMAT_VERSION,
                appName = settings.appName,
                createdAt = now,
                appVersion = BuildConfig.VERSION_NAME,
                appVersionCode = BuildConfig.VERSION_CODE,
                databaseSchemaVersion = CURRENT_DB_SCHEMA_VERSION,
                backupDateIso = isoDate,
                deviceSdkInt = Build.VERSION.SDK_INT,
                productCount = products.size,
                barcodeCount = barcodes.size,
                imageCount = filesToArchive.size,
                reportCount = reports.size,
                templateCount = templates.size,
                pdfDocumentCount = pdfDocs.size,
                inventorySessionCount = inventorySessions.size,
                inventoryItemCount = inventoryCountItems.size,
                expectedAssetPaths = filesToArchive.keys.sorted(),
                filesManifest = filesManifest,
            )

            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(now))
            val cleanName = customName.trim().ifBlank { "backup_report_manager_$stamp" }
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val outFile = File(mediaStorage.backupsDir, if (cleanName.endsWith(".zip", true)) cleanName else "$cleanName.zip")

            trace?.stage("ضغط الأرشيف ZIP على القرص", "${filesToArchive.size} ملف")
            val buf = ByteArray(IO_BUFFER_SIZE)
            FileOutputStream(outFile).use { fos ->
                ZipOutputStream(fos).use { zos ->
                    zos.putNextEntry(ZipEntry("manifest.json"))
                    zos.write(json.encodeToString(manifest).toByteArray(Charsets.UTF_8))
                    zos.closeEntry()

                    zos.putNextEntry(ZipEntry("database_export.json"))
                    zos.write(json.encodeToString(payload).toByteArray(Charsets.UTF_8))
                    zos.closeEntry()

                    filesToArchive.forEach { (zipKey, physicalFile) ->
                        zos.putNextEntry(ZipEntry(zipKey))
                        physicalFile.inputStream().use { input ->
                            while (true) {
                                val read = input.read(buf)
                                if (read <= 0) break
                                zos.write(buf, 0, read)
                            }
                        }
                        zos.closeEntry()
                    }
                }
            }

            db.backupDao().insertHistory(
                BackupHistoryEntity(
                    fileName = outFile.name,
                    filePath = outFile.absolutePath,
                    productCount = products.size,
                    barcodeCount = barcodes.size,
                    imageCount = filesToArchive.size,
                    reportCount = reports.size,
                    templateCount = templates.size,
                    sizeBytes = outFile.length(),
                    operationType = "BACKUP",
                    status = "SUCCESS",
                ),
            )
            trace?.succeed("تم إنشاء ${outFile.name} بحجم ${outFile.length()} بايت")
            Result.success(outFile)
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.BACKUP_RESTORE,
                moduleName = DiagnosticModules.BACKUP_RESTORE,
                operationName = "إنشاء نسخة احتياطية ZIP",
                linkedOperationId = trace?.operationId.orEmpty(),
                severity = LogSeverity.ERROR,
            )
            trace?.fail(t.message ?: "فشل إنشاء النسخة", err?.errorId.orEmpty())
            Result.failure(if (t is Exception) t else RuntimeException(t.message ?: "خطأ في النظام أثناء النسخ الاحتياطي", t))
        }
    }

    /**
     * Streams the selected backup URI to a temporary staging file on disk (never loading the entire
     * archive or images into RAM), avoiding OutOfMemoryError when transferring large ZIP backups
     * across devices.
     */
    suspend fun inspectBackupUri(uri: Uri): BackupInspectionResult = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.BACKUP_RESTORE,
            moduleName = DiagnosticModules.BACKUP_RESTORE,
            operationName = "فحص ملف النسخة الاحتياطية قبل الاستعادة",
            initialStage = "قراءة مصدر الملف (URI)",
        )
        val displayName = resolveUriDisplayName(uri)
        val stagingRoot = createStagingDir("inspect")
        val stagedZip = File(stagingRoot, "source_backup.zip")
        try {
            val copiedBytes = context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(stagedZip).use { out ->
                    copyStreamBuffered(input, out)
                }
            } ?: run {
                stagingRoot.deleteRecursively()
                trace?.fail("تعذر فتح مجرى القراءة للملف المختار")
                return@withContext BackupInspectionResult(
                    isValid = false,
                    manifest = null,
                    missingFiles = emptyList(),
                    errorMessage = "تعذر قراءة ملف النسخة الاحتياطية من الموقع المختار (تحقق من صلاحية الوصول للملف).",
                    sourceDisplayName = displayName,
                )
            }

            if (copiedBytes <= 0L || !stagedZip.exists()) {
                stagingRoot.deleteRecursively()
                trace?.fail("الملف المختار فارغ")
                return@withContext BackupInspectionResult(
                    isValid = false,
                    manifest = null,
                    missingFiles = emptyList(),
                    errorMessage = "ملف النسخة الاحتياطية المختار فارغ أو غير مكتمل.",
                    sourceDisplayName = displayName,
                )
            }

            trace?.stage("فحص محتويات ZIP وبصمة SHA-256", "الحجم: $copiedBytes بايت")
            val result = inspectZipFileInternal(
                zipFile = stagedZip,
                stagedZipPath = stagedZip.absolutePath,
                displayName = displayName,
                operationId = trace?.operationId.orEmpty(),
            )
            if (result.isValid) {
                trace?.succeed("ملف صالح (${result.manifest?.productCount ?: 0} منتج)")
            } else {
                stagingRoot.deleteRecursively()
                trace?.fail(result.errorMessage ?: "فشل التحقق من النسخة")
            }
            result
        } catch (t: Throwable) {
            stagingRoot.deleteRecursively()
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.BACKUP_RESTORE,
                moduleName = DiagnosticModules.BACKUP_RESTORE,
                operationName = "فحص ملف النسخة الاحتياطية",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر فحص الملف", err?.errorId.orEmpty())
            BackupInspectionResult(
                isValid = false,
                manifest = null,
                missingFiles = emptyList(),
                errorMessage = "خطأ أثناء قراءة النسخة الاحتياطية: ${t.message ?: t::class.java.simpleName}",
                sourceDisplayName = displayName,
            )
        }
    }

    fun inspectBackupBytes(bytes: ByteArray): BackupInspectionResult {
        val stagingRoot = createStagingDir("inspect_bytes")
        val stagedZip = File(stagingRoot, "source_backup.zip")
        return try {
            stagedZip.writeBytes(bytes)
            val result = inspectZipFileInternal(
                zipFile = stagedZip,
                stagedZipPath = stagedZip.absolutePath,
                displayName = "backup_bytes.zip",
                operationId = "",
            )
            if (!result.isValid) {
                stagingRoot.deleteRecursively()
            }
            result.copy(rawZipBytes = bytes)
        } catch (t: Throwable) {
            stagingRoot.deleteRecursively()
            errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.BACKUP_RESTORE,
                moduleName = DiagnosticModules.BACKUP_RESTORE,
                operationName = "فحص بايتات النسخة الاحتياطية",
            )
            BackupInspectionResult(
                isValid = false,
                manifest = null,
                missingFiles = emptyList(),
                errorMessage = "خطأ في التحقق من النسخة الاحتياطية: ${t.message}",
                rawZipBytes = bytes,
            )
        }
    }

    fun cleanupStagedInspection(inspection: BackupInspectionResult?) {
        if (inspection == null) return
        if (inspection.stagedZipFilePath.isNotBlank()) {
            runCatching {
                File(inspection.stagedZipFilePath).parentFile?.takeIf {
                    it.absolutePath.startsWith(File(context.cacheDir, "restore_staging").absolutePath)
                }?.deleteRecursively()
            }
        }
    }

    private fun inspectZipFileInternal(
        zipFile: File,
        stagedZipPath: String,
        displayName: String,
        operationId: String,
    ): BackupInspectionResult {
        val entryStats = linkedMapOf<String, BackupFileEntry>()
        var manifestJson: String? = null
        var dbJson: String? = null

        // First scan entry names to detect any accidental top-level wrapper folder (e.g. from OS re-zipping)
        val rawNames = mutableListOf<String>()
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    rawNames.add(normalizeZipEntryPath(entry.name))
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val wrapperPrefix = detectWrapperPrefix(rawNames)

        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val norm = stripWrapperPrefix(normalizeZipEntryPath(entry.name), wrapperPrefix)
                    if (norm.isNotBlank() && !isUnsafeZipPath(norm)) {
                        when (norm) {
                            "manifest.json" -> {
                                manifestJson = readBoundedUtf8(zis, MAX_JSON_ENTRY_BYTES)
                            }
                            "database_export.json" -> {
                                dbJson = readBoundedUtf8(zis, MAX_JSON_ENTRY_BYTES)
                            }
                            else -> {
                                val (size, sha) = measureStreamSizeAndSha256(zis)
                                entryStats[norm] = BackupFileEntry(
                                    relativePath = norm,
                                    sizeBytes = size,
                                    sha256 = sha,
                                )
                            }
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val checks = mutableListOf<RestoreVerificationCheck>()
        if (manifestJson == null || dbJson == null) {
            checks.add(RestoreVerificationCheck("وجود manifest.json و database_export.json", false, "ملف مفقود داخل الأرشيف"))
            saveInspectDiagnostics(operationId, zipFile.length(), entryStats.size, null, listOf("manifest.json أو database_export.json"), emptyList(), checks, "فحص الملفات الأساسية", "ملف النسخة الاحتياطية غير مكتمل أو تالف")
            return BackupInspectionResult(
                isValid = false,
                manifest = null,
                missingFiles = listOf("manifest.json أو database_export.json"),
                errorMessage = "ملف النسخة الاحتياطية غير مكتمل أو تالف (manifest.json أو database_export.json غير موجود)",
                sourceDisplayName = displayName,
            )
        }
        checks.add(RestoreVerificationCheck("وجود manifest.json و database_export.json", true))

        val manifest = json.decodeFromString<BackupManifest>(manifestJson!!)
        val payload = json.decodeFromString<BackupDatabasePayload>(dbJson!!)

        val compatibilityError = checkCompatibility(manifest)
        if (compatibilityError != null) {
            checks.add(RestoreVerificationCheck("توافق إصدار النسخة والمخطط", false, compatibilityError))
            saveInspectDiagnostics(operationId, zipFile.length(), entryStats.size, manifest, emptyList(), emptyList(), checks, "فحص التوافق", compatibilityError)
            return BackupInspectionResult(
                isValid = false,
                manifest = manifest,
                missingFiles = emptyList(),
                errorMessage = compatibilityError,
                sourceDisplayName = displayName,
            )
        }
        checks.add(RestoreVerificationCheck("توافق إصدار النسخة (${manifest.formatVersion}) ومخطط القاعدة (${manifest.databaseSchemaVersion})", true))

        val missing = mutableListOf<String>()
        val corrupted = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        manifest.expectedAssetPaths.forEach { rawExpected ->
            val expected = normalizeZipEntryPath(rawExpected)
            if (expected !in entryStats) {
                missing.add(expected)
            }
        }
        manifest.filesManifest.forEach { expectedEntry ->
            val norm = normalizeZipEntryPath(expectedEntry.relativePath)
            val actual = entryStats[norm]
            if (actual == null) {
                if (norm !in missing) missing.add(norm)
            } else if (expectedEntry.sha256.isNotBlank() && actual.sha256 != expectedEntry.sha256) {
                corrupted.add(norm)
            } else if (actual.sizeBytes <= 0L) {
                corrupted.add(norm)
            }
        }

        if (missing.isNotEmpty()) {
            warnings.add("يوجد ${missing.size} ملف أصل مفقود داخل الأرشيف؛ سيتم استعادة البيانات المتاحة وتخطي المفقود بأمان.")
        }
        if (corrupted.isNotEmpty()) {
            warnings.add("يوجد ${corrupted.size} ملف تالف أو مختلف البصمة؛ سيتم تخطي التالف حفاظاً على استقرار التطبيق.")
        }

        checks.add(RestoreVerificationCheck("سلامة فك JSON (${payload.products.size} منتج، ${payload.reports.size} تقرير)", true))
        checks.add(RestoreVerificationCheck("التحقق من ملفات الأصول (${entryStats.size} ملف)", corrupted.isEmpty(), if (corrupted.isEmpty()) "سليم" else "${corrupted.size} ملف تالف"))

        saveInspectDiagnostics(
            operationId = operationId,
            zipSizeBytes = zipFile.length(),
            assetCount = entryStats.size,
            manifest = manifest,
            missing = missing,
            corrupted = corrupted,
            checks = checks,
            failureStage = "",
            failureReason = "",
        )

        return BackupInspectionResult(
            isValid = true,
            manifest = manifest,
            missingFiles = missing,
            corruptedFiles = corrupted,
            stagedZipFilePath = stagedZipPath,
            sourceDisplayName = displayName,
            warnings = warnings,
        )
    }

    suspend fun restoreFromStagedZip(
        stagedZipPath: String,
        fileNameLabel: String = "restored_backup.zip",
    ): Result<BackupManifest> = withContext(Dispatchers.IO) {
        val file = File(stagedZipPath)
        if (!file.exists() || !file.isFile) {
            return@withContext Result.failure(IllegalStateException("ملف النسخة المرحلي لم يعد متاحاً؛ يرجى اختيار الملف مجدداً."))
        }
        try {
            restoreFromZipFileInternal(file, fileNameLabel, deleteSourceZipAfter = true)
        } finally {
            file.parentFile?.takeIf {
                it.absolutePath.startsWith(File(context.cacheDir, "restore_staging").absolutePath)
            }?.deleteRecursively()
        }
    }

    suspend fun restoreFromUri(uri: Uri, fileNameLabel: String? = null): Result<BackupManifest> = withContext(Dispatchers.IO) {
        val label = fileNameLabel ?: resolveUriDisplayName(uri)
        val stagingRoot = createStagingDir("uri_restore")
        val stagedZip = File(stagingRoot, "source_backup.zip")
        try {
            val copied = context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(stagedZip).use { output ->
                    copyStreamBuffered(input, output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("تعذر فتح ملف النسخة الاحتياطية"))
            if (copied <= 0L) {
                return@withContext Result.failure(IllegalStateException("ملف النسخة الاحتياطية فارغ"))
            }
            restoreFromZipFileInternal(stagedZip, label, deleteSourceZipAfter = true)
        } catch (t: Throwable) {
            Result.failure(if (t is Exception) t else RuntimeException(t.message ?: "تعذر استعادة الملف", t))
        } finally {
            stagingRoot.deleteRecursively()
        }
    }

    suspend fun restoreFromBackupBytes(zipBytes: ByteArray, fileNameLabel: String = "restore.zip"): Result<BackupManifest> =
        withContext(Dispatchers.IO) {
            val stagingRoot = createStagingDir("bytes_restore")
            val stagedZip = File(stagingRoot, "source_backup.zip")
            try {
                stagedZip.writeBytes(zipBytes)
                restoreFromZipFileInternal(stagedZip, fileNameLabel, deleteSourceZipAfter = true)
            } finally {
                stagingRoot.deleteRecursively()
            }
        }

    /**
     * Cross-device safe streaming restore pipeline:
     * 1. Streams ZIP entries into an isolated staging directory (never holding images in RAM).
     * 2. Validates manifest compatibility, JSON payloads, and SHA-256 integrity BEFORE touching DB.
     * 3. Sanitizes & de-duplicates foreign keys / unique indices BEFORE deleting target DB.
     * 4. Stages and validates media asset files into target directories while tracking rollback list.
     * 5. Executes atomic Room transaction; on ANY error, rolls back newly written files & preserves
     *    target device's original SQLite data 100% intact.
     */
    private suspend fun restoreFromZipFileInternal(
        zipFile: File,
        fileNameLabel: String,
        deleteSourceZipAfter: Boolean,
    ): Result<BackupManifest> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.BACKUP_RESTORE,
            moduleName = DiagnosticModules.BACKUP_RESTORE,
            operationName = "استعادة نسخة احتياطية ($fileNameLabel)",
            initialStage = "1. اختيار الملف",
        )
        val extractRoot = createStagingDir("extract")
        val newlyCommittedMediaFiles = mutableListOf<File>()
        val checks = mutableListOf<RestoreVerificationCheck>()
        var currentStage = "1. اختيار الملف"
        var parsedManifest: BackupManifest? = null
        val corruptedAssets = mutableListOf<String>()
        val missingAssets = mutableListOf<String>()

        try {
            // Stage 2: Open ZIP file & scan entries
            currentStage = "2. فتح ملف ZIP"
            trace?.stage(currentStage, "${fileNameLabel} (${zipFile.length()} بايت)")
            val rawNames = mutableListOf<String>()
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) rawNames.add(normalizeZipEntryPath(entry.name))
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            val wrapperPrefix = detectWrapperPrefix(rawNames)

            // Stage 3: Verify archive integrity structure
            currentStage = "3. التحقق من سلامة الأرشيف"
            trace?.stage(currentStage, "عدد المداخل المكتشفة: ${rawNames.size}")
            if (rawNames.isEmpty()) {
                throw IllegalStateException("ملف ZIP فارغ أو لا يحتوي على بيانات قابلة للقراءة")
            }

            // Stage 6 prep / stream extract assets & read JSON payloads safely
            currentStage = "6. فك الضغط"
            val stagedAssetFiles = linkedMapOf<String, BackupFileEntry>() // normalizedZipKey -> size/sha
            val stagedAssetFileMap = linkedMapOf<String, File>() // normalizedZipKey -> File on disk
            var manifestJson: String? = null
            var dbJson: String? = null

            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val norm = stripWrapperPrefix(normalizeZipEntryPath(entry.name), wrapperPrefix)
                        if (norm.isNotBlank() && !isUnsafeZipPath(norm)) {
                            when (norm) {
                                "manifest.json" -> manifestJson = readBoundedUtf8(zis, MAX_JSON_ENTRY_BYTES)
                                "database_export.json" -> dbJson = readBoundedUtf8(zis, MAX_JSON_ENTRY_BYTES)
                                else -> {
                                    val destStaged = safeResolveInside(extractRoot, norm)
                                    if (destStaged != null) {
                                        destStaged.parentFile?.mkdirs()
                                        val (size, sha) = streamEntryToFileWithSha256(zis, destStaged)
                                        stagedAssetFileMap[norm] = destStaged
                                        stagedAssetFiles[norm] = BackupFileEntry(norm, size, sha)
                                    }
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            // Stage 4: Read Manifest if present (fallback cleanly if legacy ZIP omitted manifest)
            currentStage = "4. قراءة Manifest إن وجد"
            val hasExplicitManifest = manifestJson != null
            val manifest = if (manifestJson != null) {
                json.decodeFromString<BackupManifest>(manifestJson!!)
            } else {
                BackupManifest(
                    formatVersion = 1,
                    appName = "مدير التقارير",
                    createdAt = System.currentTimeMillis(),
                    appVersion = "legacy",
                    appVersionCode = 1,
                    databaseSchemaVersion = CURRENT_DB_SCHEMA_VERSION,
                )
            }
            parsedManifest = manifest
            trace?.stage(
                currentStage,
                if (hasExplicitManifest) "Manifest v${manifest.formatVersion}" else "نسخة بدون Manifest - تفعيل الوضع التوافقي",
            )

            // Stage 5: Check app version & DB schema compatibility
            currentStage = "5. التحقق من إصدار التطبيق ومخطط قاعدة البيانات"
            val compatErr = checkCompatibility(manifest)
            if (compatErr != null) {
                throw IllegalStateException(compatErr)
            }
            trace?.stage(
                currentStage,
                "App=${manifest.appVersion}, Schema v${manifest.databaseSchemaVersion} -> v$CURRENT_DB_SCHEMA_VERSION",
            )

            // Record Stage 6 completion explicitly
            currentStage = "6. فك الضغط"
            trace?.stage(currentStage, "تم فك ${stagedAssetFileMap.size} ملف أصل بأسلوب البث الآمن")
            checks.add(RestoreVerificationCheck("فك ضغط الأرشيف دون استهلاك الذاكرة", true, "${stagedAssetFileMap.size} ملف"))

            // Stage 7: Verify database JSON & sanitize relational constraints BEFORE wiping target DB
            currentStage = "7. التحقق من قاعدة البيانات"
            val rawPayload = json.decodeFromString<BackupDatabasePayload>(
                dbJson ?: throw IllegalStateException("ملف database_export.json مفقود داخل النسخة الاحتياطية"),
            )
            checks.add(RestoreVerificationCheck("قراءة بيانات SQLite المصدر (${rawPayload.products.size} منتج)", true))

            val checksumByPath = manifest.filesManifest.associateBy { normalizeZipEntryPath(it.relativePath) }
            val usableAssetFiles = linkedMapOf<String, File>()
            val basenameFallbackMap = linkedMapOf<String, File>()
            stagedAssetFileMap.forEach { (normKey, stagedFile) ->
                val expected = checksumByPath[normKey]
                val checksumMismatch = expected != null &&
                    expected.sha256.isNotBlank() &&
                    stagedAssetFiles[normKey]?.sha256 != expected.sha256
                if (!stagedFile.exists() || stagedFile.length() <= 0L || checksumMismatch) {
                    corruptedAssets.add(normKey)
                } else {
                    usableAssetFiles[normKey] = stagedFile
                    val baseName = stagedFile.name
                    if (!basenameFallbackMap.containsKey(baseName)) {
                        basenameFallbackMap[baseName] = stagedFile
                    }
                }
            }
            manifest.expectedAssetPaths.forEach { exp ->
                val normExp = normalizeZipEntryPath(exp)
                if (!usableAssetFiles.containsKey(normExp) && !corruptedAssets.contains(normExp)) {
                    missingAssets.add(normExp)
                }
            }
            checks.add(
                RestoreVerificationCheck(
                    "فحص سلامة الملفات",
                    corruptedAssets.isEmpty(),
                    "متاح: ${usableAssetFiles.size} • مفقود: ${missingAssets.size} • تالف: ${corruptedAssets.size}",
                ),
            )

            val cleanPayload = sanitizePayloadForCrossDeviceRestore(rawPayload)
            checks.add(
                RestoreVerificationCheck(
                    "التحقق من القيود والمفاتيح الأجنبية",
                    true,
                    "منتجات: ${cleanPayload.products.size}, باركودات: ${cleanPayload.productBarcodes.size}, تقارير: ${cleanPayload.reports.size}",
                ),
            )
            trace?.stage(currentStage, "سليم (${cleanPayload.products.size} منتج، ${cleanPayload.reports.size} تقرير)")

            // Stage 9: Rebuild file paths across devices cleanly
            currentStage = "9. إعادة بناء مسارات الملفات"
            trace?.stage(currentStage, "تحويل مسارات الهاتف المصدر إلى مسارات تخزين الهاتف الحالي")
            val remappedLocalPaths = mutableMapOf<String, String>()

            fun findStagedFile(rawZipKey: String): File? {
                val norm = normalizeZipEntryPath(rawZipKey)
                if (norm.isBlank()) return null
                usableAssetFiles[norm]?.let { return it }
                usableAssetFiles.entries.firstOrNull { it.key.equals(norm, ignoreCase = true) }?.value?.let { return it }
                val fileNameOnly = norm.substringAfterLast('/')
                if (fileNameOnly.isNotBlank()) {
                    basenameFallbackMap[fileNameOnly]?.let { return it }
                }
                return null
            }

            // Stage 10: Restore images & attachments into local app storage
            currentStage = "10. استعادة الصور والمرفقات"
            trace?.stage(currentStage)

            fun restoreAsset(rawZipKey: String, targetDir: File, prefixHint: String = ""): String {
                if (rawZipKey.isBlank()) return ""
                val normKey = normalizeZipEntryPath(rawZipKey)
                val cacheKey = "${targetDir.absolutePath}::$normKey"
                remappedLocalPaths[cacheKey]?.let { return it }

                val stagedSource = findStagedFile(normKey) ?: return ""
                targetDir.mkdirs()
                val rawName = sanitizeFileName(stagedSource.name)
                val uniquePrefix = if (prefixHint.isNotBlank()) "${prefixHint}_" else ""
                var destFile = File(targetDir, "$uniquePrefix$rawName")
                if (destFile.exists() && destFile.length() != stagedSource.length()) {
                    val dot = rawName.lastIndexOf('.')
                    val altName = if (dot > 0) {
                        "${rawName.substring(0, dot)}_${UUID.randomUUID().toString().take(6)}${rawName.substring(dot)}"
                    } else {
                        "${rawName}_${UUID.randomUUID().toString().take(6)}"
                    }
                    destFile = File(targetDir, "$uniquePrefix$altName")
                }
                stagedSource.inputStream().use { input ->
                    FileOutputStream(destFile).use { output ->
                        copyStreamBuffered(input, output)
                    }
                }
                if (!destFile.exists() || destFile.length() <= 0L) {
                    destFile.delete()
                    return ""
                }
                newlyCommittedMediaFiles.add(destFile)
                remappedLocalPaths[cacheKey] = destFile.absolutePath
                return destFile.absolutePath
            }

            val immutableDefaults = AppSettingsEntity()
            val preparedSettings = (cleanPayload.settings ?: immutableDefaults).let { s ->
                s.copy(
                    id = 1,
                    developerName = immutableDefaults.developerName,
                    developerPhone = immutableDefaults.developerPhone,
                    companyLogoPath = restoreAsset(s.companyLogoPath, mediaStorage.brandingDir),
                )
            }

            val preparedImages = cleanPayload.productImages.mapNotNull { img ->
                var activePath = restoreAsset(img.filePath, mediaStorage.productImagesDir)
                val origPath = restoreAsset(img.originalFilePath, mediaStorage.originalsDir)
                if (activePath.isBlank() && origPath.isNotBlank()) {
                    activePath = restoreAsset(img.originalFilePath, mediaStorage.productImagesDir)
                }
                if (activePath.isBlank() || !isDecodableOrValidAsset(File(activePath))) {
                    null
                } else {
                    var thumbPath = restoreAsset(img.thumbnailPath, mediaStorage.thumbnailsDir)
                    if (thumbPath.isBlank()) {
                        thumbPath = mediaStorage.generateThumbnail(activePath)
                        if (thumbPath.isNotBlank()) newlyCommittedMediaFiles.add(File(thumbPath))
                    }
                    img.copy(
                        filePath = activePath,
                        originalFilePath = origPath,
                        thumbnailPath = thumbPath,
                    )
                }
            }

            val preparedDownloads = cleanPayload.productImageDownloads.map { dl ->
                dl.copy(
                    localFilePath = restoreAsset(dl.localFilePath, mediaStorage.productImagesDir),
                    originalFilePath = restoreAsset(dl.originalFilePath, mediaStorage.originalsDir),
                    thumbnailPath = restoreAsset(dl.thumbnailPath, mediaStorage.thumbnailsDir),
                )
            }

            val preparedReports = cleanPayload.reports.map { r ->
                r.copy(
                    companyLogoPath = restoreAsset(r.companyLogoPath, mediaStorage.brandingDir),
                    signaturePath = restoreAsset(r.signaturePath, mediaStorage.brandingDir),
                    stampPath = restoreAsset(r.stampPath, mediaStorage.brandingDir),
                    lastPdfPath = restoreAsset(r.lastPdfPath, mediaStorage.exportsDir),
                )
            }

            val preparedReportItems = cleanPayload.reportItems.map { item ->
                val reportSnapDir = File(mediaStorage.reportSnapshotsDir, "report_${item.reportId}")
                item.copy(imageSnapshotPath = restoreAsset(item.imageSnapshotPath, reportSnapDir))
            }

            val reportIdByItemId = preparedReportItems.associate { it.id to it.reportId }
            val preparedReportItemImages = cleanPayload.reportItemImages.mapNotNull { img ->
                val rid = reportIdByItemId[img.reportItemId] ?: img.reportId
                val dir = File(mediaStorage.reportSnapshotsDir, "report_$rid")
                val newPath = restoreAsset(img.filePath, dir)
                if (newPath.isBlank()) null else img.copy(filePath = newPath)
            }

            val preparedPdfDocs = cleanPayload.pdfDocuments.map { doc ->
                doc.copy(
                    workingFilePath = restoreAsset(doc.workingFilePath, mediaStorage.pdfWorkspaceDir),
                    originalFilePath = restoreAsset(doc.originalFilePath, mediaStorage.pdfWorkspaceDir),
                )
            }

            val preparedPdfPages = cleanPayload.pdfPages.map { p ->
                p.copy(
                    sourcePdfPath = restoreAsset(p.sourcePdfPath, mediaStorage.pdfWorkspaceDir),
                    thumbnailPath = restoreAsset(p.thumbnailPath, mediaStorage.thumbnailsDir),
                )
            }

            val preparedInventoryItems = cleanPayload.inventoryCountItems.map { item ->
                var restoredThumb = restoreAsset(item.productImagePath, mediaStorage.thumbnailsDir)
                if (restoredThumb.isBlank() && item.productId != null) {
                    val fallbackProductImg = preparedImages.firstOrNull { it.productId == item.productId && it.isPrimary }
                        ?: preparedImages.firstOrNull { it.productId == item.productId }
                    restoredThumb = fallbackProductImg?.thumbnailPath?.ifBlank { fallbackProductImg.filePath }.orEmpty()
                }
                item.copy(productImagePath = restoredThumb)
            }

            checks.add(
                RestoreVerificationCheck(
                    "تجهيز والتحقق من الصور المستعادة",
                    true,
                    "صور منتجات صالحة: ${preparedImages.size}, صور تقارير: ${preparedReportItemImages.size}",
                ),
            )

            // Stage 8: Restore database in atomic SQLite transaction (preserving target DB on error)
            currentStage = "8. استعادة قاعدة البيانات"
            trace?.stage(currentStage)

            db.withTransaction {
                db.inventoryDao().deleteAllSessions()
                db.pdfDocumentDao().deleteAllDocuments()
                db.reportDao().deleteAllReports()
                db.productDao().deleteAllProducts()
                db.categoryDao().deleteAllCategories()
                db.templateDao().deleteAllTemplates()

                db.settingsDao().saveSettings(preparedSettings)
                if (cleanPayload.categories.isNotEmpty()) {
                    db.categoryDao().insertCategories(cleanPayload.categories)
                }
                val templatesToInsert = cleanPayload.templates.ifEmpty { TemplateDefaults.buildBuiltInTemplates() }
                db.templateDao().insertTemplates(templatesToInsert)

                if (cleanPayload.products.isNotEmpty()) {
                    db.productDao().insertProducts(cleanPayload.products)
                }
                if (cleanPayload.productBarcodes.isNotEmpty()) {
                    db.productDao().insertBarcodes(cleanPayload.productBarcodes)
                }
                if (preparedImages.isNotEmpty()) {
                    db.productDao().insertImages(preparedImages)
                }
                if (preparedDownloads.isNotEmpty()) {
                    db.productDao().insertImageDownloads(preparedDownloads)
                }
                if (preparedReports.isNotEmpty()) {
                    preparedReports.forEach { db.reportDao().insertReport(it) }
                }
                if (cleanPayload.reportColumns.isNotEmpty()) {
                    db.reportDao().insertColumns(cleanPayload.reportColumns)
                }
                if (preparedReportItems.isNotEmpty()) {
                    db.reportDao().insertReportItems(preparedReportItems)
                }
                if (cleanPayload.reportItemBarcodes.isNotEmpty()) {
                    db.reportDao().insertReportItemBarcodes(cleanPayload.reportItemBarcodes)
                }
                if (preparedReportItemImages.isNotEmpty()) {
                    db.reportDao().insertReportItemImages(preparedReportItemImages)
                }
                if (preparedPdfDocs.isNotEmpty()) {
                    preparedPdfDocs.forEach { db.pdfDocumentDao().insertDocument(it) }
                }
                if (preparedPdfPages.isNotEmpty()) {
                    db.pdfDocumentDao().insertPages(preparedPdfPages)
                }
                if (cleanPayload.inventorySessions.isNotEmpty()) {
                    db.inventoryDao().insertSessions(cleanPayload.inventorySessions)
                }
                if (preparedInventoryItems.isNotEmpty()) {
                    db.inventoryDao().insertCountItems(preparedInventoryItems)
                }
                if (cleanPayload.stockAdjustmentLogs.isNotEmpty()) {
                    db.inventoryDao().insertAdjustmentLogs(cleanPayload.stockAdjustmentLogs)
                }
            }

            // Stage 11: Verify image-to-product links & actual physical files
            currentStage = "11. التحقق من ربط الصور بالمنتجات"
            val restoredImageEntities = db.productDao().getAllImagesOnce()
            val validProductIds = db.productDao().getAllProductsOnce().map { it.id }.toSet()
            val linkedImagesOk = restoredImageEntities.all { img ->
                img.productId in validProductIds && img.filePath.isNotBlank() && File(img.filePath).exists()
            }
            val existingImageFiles = restoredImageEntities.count { it.filePath.isNotBlank() && File(it.filePath).exists() }
            trace?.stage(
                currentStage,
                "صور مربوطة وموجودة فعلياً: $existingImageFiles/${restoredImageEntities.size}",
            )
            checks.add(
                RestoreVerificationCheck(
                    "ربط الصور بالمنتجات والتحقق الفيزيائي",
                    linkedImagesOk,
                    "$existingImageFiles/${restoredImageEntities.size}",
                ),
            )

            // Stage 12: Verify product, barcode & report counts
            currentStage = "12. التحقق من عدد المنتجات والسجلات"
            val actualProducts = db.productDao().getAllProductsOnce().size
            val actualBarcodes = db.productDao().getAllBarcodesOnce().size
            val actualImages = restoredImageEntities.size
            val actualReports = db.reportDao().getAllReportsWithDetailsOnce().size
            val countsMatch = actualProducts == cleanPayload.products.size &&
                actualBarcodes == cleanPayload.productBarcodes.size &&
                actualReports == cleanPayload.reports.size

            trace?.stage(
                currentStage,
                "منتجات=$actualProducts/${cleanPayload.products.size}، باركودات=$actualBarcodes، تقارير=$actualReports",
            )
            checks.add(
                RestoreVerificationCheck(
                    "مطابقة عدد المنتجات والسجلات بعد الاستعادة",
                    countsMatch,
                    "منتجات=$actualProducts, باركودات=$actualBarcodes, صور=$actualImages (ملفات موجودة=$existingImageFiles), تقارير=$actualReports",
                ),
            )

            // Stage 13: Commit restore & persist Stage 14 post-restart verification marker
            currentStage = "13. اعتماد الاستعادة"
            trace?.stage(
                currentStage,
                "تم اعتماد الاستعادة وحفظ مؤشر التحقق بعد إعادة الفتح (المرحلة 14)",
            )

            db.backupDao().insertHistory(
                BackupHistoryEntity(
                    fileName = fileNameLabel,
                    filePath = "",
                    productCount = actualProducts,
                    barcodeCount = actualBarcodes,
                    imageCount = actualImages,
                    reportCount = actualReports,
                    templateCount = cleanPayload.templates.size,
                    sizeBytes = zipFile.length(),
                    operationType = "RESTORE",
                    status = "SUCCESS",
                ),
            )

            val opId = trace?.operationId.orEmpty()
            if (opId.isNotBlank()) {
                errorMonitor?.fileStore?.savePendingRestoreVerification(
                    PendingRestoreVerification(
                        operationId = opId,
                        expectedProducts = actualProducts,
                        expectedImages = existingImageFiles,
                        expectedReports = actualReports,
                    ),
                )
            }

            errorMonitor?.saveRestoreDiagnostics(
                RestoreDiagnosticsReport(
                    timestamp = System.currentTimeMillis(),
                    operationId = opId,
                    phase = "RESTORE",
                    outcome = "SUCCESS",
                    sourceFormatVersion = manifest.formatVersion,
                    sourceSchemaVersion = manifest.databaseSchemaVersion,
                    targetSchemaVersion = CURRENT_DB_SCHEMA_VERSION,
                    sourceAppVersion = manifest.appVersion,
                    targetAppVersion = BuildConfig.VERSION_NAME,
                    zipSizeBytes = zipFile.length(),
                    assetFilesInZip = stagedAssetFileMap.size,
                    missingFiles = missingAssets,
                    corruptedFiles = corruptedAssets,
                    stageTimeline = trace?.snapshotStages().orEmpty(),
                    verificationChecks = checks,
                    targetDataPreservedOnFailure = true,
                ),
            )

            trace?.succeed("استعادة مكتملة: $actualProducts منتج، $actualImages صورة، $actualReports تقرير")
            if (deleteSourceZipAfter) {
                runCatching { zipFile.delete() }
            }
            return Result.success(manifest)
        } catch (t: Throwable) {
            newlyCommittedMediaFiles.forEach { f -> runCatching { f.delete() } }

            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.BACKUP_RESTORE,
                moduleName = DiagnosticModules.BACKUP_RESTORE,
                operationName = "استعادة نسخة احتياطية ($currentStage)",
                linkedOperationId = trace?.operationId.orEmpty(),
                failedStage = currentStage,
                severity = LogSeverity.CRITICAL,
                extraMeta = mapOf(
                    "stage" to currentStage,
                    "zipSize" to (if (zipFile.exists()) zipFile.length().toString() else "0"),
                ),
            )
            trace?.fail(t.message ?: "فشلت الاستعادة عند: $currentStage", err?.errorId.orEmpty(), LogSeverity.CRITICAL)

            errorMonitor?.saveRestoreDiagnostics(
                RestoreDiagnosticsReport(
                    timestamp = System.currentTimeMillis(),
                    operationId = trace?.operationId.orEmpty(),
                    phase = "RESTORE",
                    outcome = "FAILED",
                    sourceFormatVersion = parsedManifest?.formatVersion ?: 0,
                    sourceSchemaVersion = parsedManifest?.databaseSchemaVersion ?: 0,
                    targetSchemaVersion = CURRENT_DB_SCHEMA_VERSION,
                    sourceAppVersion = parsedManifest?.appVersion.orEmpty(),
                    targetAppVersion = BuildConfig.VERSION_NAME,
                    zipSizeBytes = if (zipFile.exists()) zipFile.length() else 0L,
                    assetFilesInZip = 0,
                    missingFiles = missingAssets,
                    corruptedFiles = corruptedAssets,
                    stageTimeline = trace?.snapshotStages().orEmpty(),
                    verificationChecks = checks + RestoreVerificationCheck(currentStage, false, t.message ?: t::class.java.simpleName),
                    targetDataPreservedOnFailure = true,
                    failureStage = currentStage,
                    failureReason = t.message ?: t::class.java.simpleName,
                ),
            )
            return Result.failure(if (t is Exception) t else RuntimeException(t.message ?: "تعذر الاستعادة", t))
        } finally {
            extractRoot.deleteRecursively()
        }
    }

    /**
     * Stage 14 of cross-device ZIP restore: executed on subsequent app launch to verify
     * that restored SQLite data and restored image files survived process restart intact.
     */
    suspend fun verifyPendingRestoreAfterAppRestart() = withContext(Dispatchers.IO) {
        val monitor = errorMonitor ?: return@withContext
        val pending = monitor.fileStore.consumePendingRestoreVerification() ?: return@withContext
        try {
            val actualProducts = db.productDao().getAllProductsOnce().size
            val actualImages = db.productDao().getAllImagesOnce()
            val existingImages = actualImages.count { it.filePath.isNotBlank() && File(it.filePath).exists() }
            val actualReports = db.reportDao().getAllReportsWithDetailsOnce().size
            val passed = actualProducts >= pending.expectedProducts &&
                existingImages >= pending.expectedImages &&
                actualReports >= pending.expectedReports
            val detail = "بعد إعادة فتح التطبيق: منتجات=$actualProducts/${pending.expectedProducts}، صور موجودة=$existingImages/${pending.expectedImages}، تقارير=$actualReports/${pending.expectedReports}"

            var errId = ""
            if (!passed) {
                val err = monitor.recordCustomError(
                    screenName = ScreenNames.BACKUP_RESTORE,
                    moduleName = DiagnosticModules.BACKUP_RESTORE,
                    operationName = "التحقق من استقرار البيانات المستعادة بعد إعادة الفتح",
                    errorType = "PostRestoreRestartMismatch",
                    message = detail,
                    wasHandled = true,
                    severity = LogSeverity.CRITICAL,
                    linkedOperationId = pending.operationId,
                    failedStage = "14. إعادة فتح التطبيق والبيانات",
                )
                errId = err.errorId
            }

            monitor.operationLogger.appendPostRestartVerificationStage(
                operationId = pending.operationId,
                stageName = "14. إعادة فتح التطبيق والبيانات",
                passed = passed,
                detail = detail,
                linkedErrorId = errId,
            )

            val prevReport = monitor.lastRestoreDiagnostics.value ?: monitor.fileStore.readLastRestoreDiagnostics()
            if (prevReport != null && prevReport.operationId == pending.operationId) {
                val updatedStages = monitor.operationLogger.getOperationStages(pending.operationId)
                    .ifEmpty {
                        prevReport.stageTimeline + OperationStageRecord(
                            stageName = "14. إعادة فتح التطبيق والبيانات",
                            timestamp = System.currentTimeMillis(),
                            status = if (passed) "DONE" else "FAILED",
                            detail = detail,
                        )
                    }
                monitor.saveRestoreDiagnostics(
                    prevReport.copy(
                        outcome = if (passed) "SUCCESS" else "FAILED",
                        stageTimeline = updatedStages,
                        verificationChecks = prevReport.verificationChecks + RestoreVerificationCheck(
                            checkName = "14. إعادة فتح التطبيق والبيانات",
                            passed = passed,
                            detail = detail,
                        ),
                        failureStage = if (passed) prevReport.failureStage else "14. إعادة فتح التطبيق والبيانات",
                        failureReason = if (passed) prevReport.failureReason else detail,
                    ),
                )
            }
        } catch (t: Throwable) {
            val err = monitor.recordError(
                throwable = t,
                screenName = ScreenNames.BACKUP_RESTORE,
                moduleName = DiagnosticModules.BACKUP_RESTORE,
                operationName = "التحقق بعد إعادة فتح التطبيق",
                linkedOperationId = pending.operationId,
                failedStage = "14. إعادة فتح التطبيق والبيانات",
                severity = LogSeverity.CRITICAL,
            )
            monitor.operationLogger.appendPostRestartVerificationStage(
                operationId = pending.operationId,
                stageName = "14. إعادة فتح التطبيق والبيانات",
                passed = false,
                detail = t.message ?: t::class.java.simpleName,
                linkedErrorId = err.errorId,
            )
        }
    }

    private fun sanitizePayloadForCrossDeviceRestore(raw: BackupDatabasePayload): BackupDatabasePayload {
        val validCategories = raw.categories.distinctBy { it.id }.ifEmpty { emptyList() }
        val categoryIds = validCategories.map { it.id }.toSet()

        val cleanProducts = raw.products
            .distinctBy { it.id }
            .map { p ->
                val resolvedCatId = p.categoryId?.takeIf { it in categoryIds }
                p.copy(
                    internalCode = p.internalCode.trim().ifBlank { "PRD-${p.id}" },
                    categoryId = resolvedCatId,
                )
            }
        val productIds = cleanProducts.map { it.id }.toSet()

        // ProductBarcodes has UNIQUE index on barcodeValue AND ForeignKey on productId -> deduplicate & filter!
        val seenBarcodeValues = HashSet<String>()
        val cleanBarcodes = raw.productBarcodes
            .distinctBy { it.id }
            .filter { b ->
                val valTrim = b.barcodeValue.trim()
                b.productId in productIds && valTrim.isNotEmpty() && seenBarcodeValues.add(valTrim)
            }
            .map { it.copy(barcodeValue = it.barcodeValue.trim()) }

        val cleanImages = raw.productImages
            .distinctBy { it.id }
            .filter { it.productId in productIds }

        val cleanDownloads = raw.productImageDownloads
            .distinctBy { it.id }
            .filter { it.productId in productIds }

        val cleanTemplates = raw.templates.distinctBy { it.id }
        val templateIds = cleanTemplates.map { it.id }.toSet()

        val cleanReports = raw.reports
            .distinctBy { it.id }
            .map { r ->
                r.copy(templateId = r.templateId?.takeIf { it in templateIds })
            }
        val reportIds = cleanReports.map { it.id }.toSet()

        val cleanColumns = raw.reportColumns
            .distinctBy { it.id }
            .filter { it.reportId in reportIds }

        val cleanReportItems = raw.reportItems
            .distinctBy { it.id }
            .filter { it.reportId in reportIds }
        val reportItemIds = cleanReportItems.map { it.id }.toSet()

        val cleanReportItemBarcodes = raw.reportItemBarcodes
            .distinctBy { it.id }
            .filter { it.reportItemId in reportItemIds }

        val cleanReportItemImages = raw.reportItemImages
            .distinctBy { it.id }
            .filter { it.reportItemId in reportItemIds }

        val cleanPdfDocs = raw.pdfDocuments.distinctBy { it.id }
        val pdfDocIds = cleanPdfDocs.map { it.id }.toSet()

        val cleanPdfPages = raw.pdfPages
            .distinctBy { it.id }
            .filter { it.documentId in pdfDocIds }

        val cleanSessions = raw.inventorySessions.distinctBy { it.id }
        val sessionIds = cleanSessions.map { it.id }.toSet()

        val cleanInvItems = raw.inventoryCountItems
            .distinctBy { it.id }
            .filter { it.sessionId in sessionIds }
            .map { item -> item.copy(productId = item.productId?.takeIf { it in productIds }) }

        val cleanAdjLogs = raw.stockAdjustmentLogs
            .distinctBy { it.id }
            .filter { it.sessionId in sessionIds }

        return BackupDatabasePayload(
            settings = raw.settings,
            categories = validCategories,
            products = cleanProducts,
            productBarcodes = cleanBarcodes,
            productImages = cleanImages,
            productImageDownloads = cleanDownloads,
            templates = cleanTemplates,
            reports = cleanReports,
            reportItems = cleanReportItems,
            reportItemBarcodes = cleanReportItemBarcodes,
            reportItemImages = cleanReportItemImages,
            reportColumns = cleanColumns,
            pdfDocuments = cleanPdfDocs,
            pdfPages = cleanPdfPages,
            inventorySessions = cleanSessions,
            inventoryCountItems = cleanInvItems,
            stockAdjustmentLogs = cleanAdjLogs,
        )
    }

    private fun checkCompatibility(manifest: BackupManifest): String? {
        if (manifest.formatVersion > CURRENT_BACKUP_FORMAT_VERSION) {
            return "هذه النسخة الاحتياطية أُنشئت بإصدار أحدث من التطبيق (تنسيق v${manifest.formatVersion})؛ يرجى تحديث التطبيق على هذا الهاتف قبل الاستعادة."
        }
        if (manifest.databaseSchemaVersion > CURRENT_DB_SCHEMA_VERSION) {
            return "مخطط قاعدة البيانات في النسخة (${manifest.databaseSchemaVersion}) أحدث من المخطط الحالي ($CURRENT_DB_SCHEMA_VERSION)؛ يرجى تحديث التطبيق أولاً."
        }
        return null
    }

    private fun saveInspectDiagnostics(
        operationId: String,
        zipSizeBytes: Long,
        assetCount: Int,
        manifest: BackupManifest?,
        missing: List<String>,
        corrupted: List<String>,
        checks: List<RestoreVerificationCheck>,
        failureStage: String,
        failureReason: String,
    ) {
        errorMonitor?.saveRestoreDiagnostics(
            RestoreDiagnosticsReport(
                timestamp = System.currentTimeMillis(),
                operationId = operationId,
                phase = "INSPECT",
                outcome = if (failureReason.isBlank()) "VALID" else "INVALID",
                sourceFormatVersion = manifest?.formatVersion ?: 0,
                sourceSchemaVersion = manifest?.databaseSchemaVersion ?: 0,
                targetSchemaVersion = CURRENT_DB_SCHEMA_VERSION,
                sourceAppVersion = manifest?.appVersion.orEmpty(),
                targetAppVersion = BuildConfig.VERSION_NAME,
                zipSizeBytes = zipSizeBytes,
                assetFilesInZip = assetCount,
                missingFiles = missing,
                corruptedFiles = corrupted,
                stageTimeline = emptyList(),
                verificationChecks = checks,
                targetDataPreservedOnFailure = true,
                failureStage = failureStage,
                failureReason = failureReason,
            ),
        )
    }

    private fun createStagingDir(tag: String): File {
        val base = File(context.cacheDir, "restore_staging").apply { mkdirs() }
        return File(base, "${tag}_${UUID.randomUUID().toString().take(8)}").apply { mkdirs() }
    }

    private fun resolveUriDisplayName(uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: "restored_backup.zip"
    }

    private fun cleanFilePath(raw: String): String {
        if (raw.isBlank()) return ""
        var clean = raw.trim()
        if (clean.startsWith("file://", ignoreCase = true)) {
            clean = clean.removePrefix("file://")
        }
        val queryIdx = clean.indexOf('?')
        if (queryIdx > 0 && clean.substring(queryIdx).startsWith("?t=")) {
            clean = clean.substring(0, queryIdx)
        }
        return clean
    }

    private fun normalizeZipEntryPath(raw: String): String {
        return raw.replace('\\', '/').trimStart('/').removePrefix("./").trim()
    }

    private fun detectWrapperPrefix(entryNames: List<String>): String {
        if (entryNames.any { it == "manifest.json" || it == "database_export.json" }) return ""
        val candidate = entryNames.firstOrNull { it.endsWith("/manifest.json") } ?: return ""
        return candidate.removeSuffix("manifest.json")
    }

    private fun stripWrapperPrefix(path: String, wrapperPrefix: String): String {
        if (wrapperPrefix.isBlank()) return path
        return if (path.startsWith(wrapperPrefix)) path.removePrefix(wrapperPrefix) else path
    }

    private fun isUnsafeZipPath(path: String): Boolean {
        val parts = path.split('/')
        return parts.any { it == ".." || it.contains('\u0000') }
    }

    private fun safeResolveInside(root: File, relativePath: String): File? {
        return try {
            val rootCanonical = root.canonicalPath
            val target = File(root, relativePath)
            val targetCanonical = target.canonicalPath
            if (targetCanonical == rootCanonical || targetCanonical.startsWith("$rootCanonical${File.separator}")) {
                target
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|\u0000]"), "_").ifBlank { "asset_${UUID.randomUUID().toString().take(6)}" }
    }

    private fun readBoundedUtf8(input: InputStream, maxBytes: Long): String {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(IO_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            total += read
            if (total > maxBytes) {
                throw IllegalStateException("تجاوز حجم ملف JSON الحد الآمن ($maxBytes بايت)")
            }
            out.write(buf, 0, read)
        }
        return out.toString(Charsets.UTF_8.name())
    }

    private fun copyStreamBuffered(input: InputStream, output: FileOutputStream): Long {
        val buf = ByteArray(IO_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            output.write(buf, 0, read)
            total += read
        }
        output.flush()
        return total
    }

    private fun streamEntryToFileWithSha256(input: InputStream, destFile: File): Pair<Long, String> {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(IO_BUFFER_SIZE)
        var total = 0L
        FileOutputStream(destFile).use { fos ->
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                fos.write(buf, 0, read)
                md.update(buf, 0, read)
                total += read
            }
            fos.flush()
        }
        val sha = md.digest().joinToString("") { "%02x".format(it) }
        return total to sha
    }

    private fun measureStreamSizeAndSha256(input: InputStream): Pair<Long, String> {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(IO_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            md.update(buf, 0, read)
            total += read
        }
        val sha = md.digest().joinToString("") { "%02x".format(it) }
        return total to sha
    }

    private fun computeSha256(file: File): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(IO_BUFFER_SIZE)
            FileInputStream(file).use { fis ->
                while (true) {
                    val read = fis.read(buf)
                    if (read <= 0) break
                    md.update(buf, 0, read)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            ""
        }
    }

    private fun isDecodableOrValidAsset(file: File): Boolean {
        if (!file.exists() || !file.isFile || file.length() <= 0L) return false
        val ext = file.extension.lowercase()
        if (ext == "pdf") {
            return runCatching {
                FileInputStream(file).use { fis ->
                    val hdr = ByteArray(4)
                    fis.read(hdr) >= 4 && String(hdr, Charsets.US_ASCII) == "%PDF"
                }
            }.getOrDefault(false)
        }
        if (ext in setOf("png", "jpg", "jpeg", "webp", "gif", "bmp", "avif")) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, opts)
            return if (opts.outWidth > 0 && opts.outHeight > 0) true else file.length() > 16L
        }
        return true
    }
}
