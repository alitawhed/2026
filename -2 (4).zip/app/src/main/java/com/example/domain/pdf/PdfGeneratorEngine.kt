package com.example.domain.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.LruCache
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.local.TemplateDefaults
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportWithDetails
import com.example.data.storage.ImageService
import com.example.data.storage.MediaStorageManager
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.toNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.layout.ColumnLayoutEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.BarcodeStyleConfig
import com.example.domain.model.CellAlignment
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ComputedColumnWidth
import com.example.domain.model.ColumnType
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.MM_TO_PT
import com.example.domain.model.PageOrientation
import com.example.domain.model.PageSpec
import com.example.domain.model.PaperSizeType
import com.example.domain.model.ReportHeaderFooterConfig
import kotlinx.coroutines.CancellationException
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

data class PdfGenerationResult(
    val file: File,
    val pageCount: Int,
    val warnings: List<String>,
)

class PdfCancelledException : Exception("تم إلغاء إنشاء ملف PDF بواسطة المستخدم")

class PdfGeneratorEngine(
    private val context: Context,
    private val mediaStorage: MediaStorageManager,
    private val sessionFactory: PdfSessionFactory = AndroidPdfSessionFactory(),
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    internal var drawnCellTextObserver: ((String) -> Unit)? = null

    private fun createBoundedBitmapCache(maxSizeKb: Int = 16 * 1024): LruCache<String, Bitmap> {
        return object : LruCache<String, Bitmap>(maxSizeKb) {
            override fun sizeOf(key: String, value: Bitmap): Int {
                return (value.allocationByteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    fun generateReportPdf(
        reportDetails: ReportWithDetails,
        settings: AppSettingsEntity,
        outputFileName: String? = null,
        onProgress: (currentPage: Int, totalPages: Int) -> Unit = { _, _ -> },
        isCancelled: () -> Boolean = { false },
    ): PdfGenerationResult {
        val report = reportDetails.report
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PDF_PREVIEW,
            moduleName = DiagnosticModules.PDF,
            operationName = "توليد ملف PDF للتقرير (${report.reportNumber})",
            initialStage = "تهيئة تخطيط التقرير",
        )
        val pageSpec = PageSpec(
            paperSize = PaperSizeType.fromString(report.paperSize),
            customWidthMm = report.customWidthMm,
            customHeightMm = report.customHeightMm,
            orientation = PageOrientation.fromString(report.orientation),
            marginTopMm = report.marginTopMm,
            marginBottomMm = report.marginBottomMm,
            marginStartMm = report.marginStartMm,
            marginEndMm = report.marginEndMm,
        )
        val distributionMode = ColumnDistributionMode.fromString(report.columnDistributionMode)
        val columns = reportDetails.sortedColumns.map { it.toDomainModel() }
        val layoutResult = ColumnLayoutEngine.calculateLayout(
            pageSpec = pageSpec,
            allColumns = columns,
            distributionMode = distributionMode,
            splitHorizontalGroups = report.splitHorizontalGroups,
        )
        trace?.stage("تحليل وتوزيع الأعمدة", "مجموعات=${layoutResult.columnGroups.size}")

        val headerFooter = TemplateDefaults.decodeHeaderFooter(report.headerFooterConfigJson)
        val barcodeStyle = TemplateDefaults.decodeBarcodeStyle(report.barcodeStyleConfigJson)
        val arabicTypeface = loadArabicTypeface(settings.fontFamilyKey)
        val warnings = mutableListOf<String>()

        if (layoutResult.hasOverflow && !report.splitHorizontalGroups) {
            warnings.add("مجموع عروض الأعمدة يتجاوز العرض الفعلي للصفحة بمقدار ${layoutResult.overflowAmountPt.toInt()} نقطة")
        }

        val pageW = ceil(pageSpec.pageWidthPt).toInt().coerceAtLeast(160)
        val pageH = ceil(pageSpec.pageHeightPt).toInt().coerceAtLeast(200)
        val leftX = pageSpec.marginStartPt
        val rightX = pageSpec.pageWidthPt - pageSpec.marginEndPt
        val topY = pageSpec.marginTopPt
        val bottomLimitY = pageSpec.pageHeightPt - pageSpec.marginBottomPt - (if (headerFooter.showPageNumbers) 18f else 4f)

        val items = reportDetails.sortedItems
        val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(report.reportDate))
        val groups = if (layoutResult.columnGroups.isEmpty()) listOf(emptyList()) else layoutResult.columnGroups

        // Pre-calculate pages in two passes or buffer page drawings?
        // Using PdfDocument directly: to display accurate "صفحة X من Y", we compute pagination plan first!
        val pdfDocument = sessionFactory.create()
        val bitmapCache = createBoundedBitmapCache()

        try {
            data class PageSlice(
                val groupCols: List<ComputedColumnWidth>,
                val isFirstPageOfGroup: Boolean,
                val itemRange: IntRange,
                val includeSummaryFooter: Boolean,
            )

            val slices = mutableListOf<PageSlice>()
            val headerBlockHeight = measureHeaderHeight(reportDetails, headerFooter)
            val tableHeaderHeight = 28f
            val footerBlockHeight = measureFooterHeight(reportDetails, headerFooter)
            val hasVisibleFooter = footerBlockHeight > 12f

            for (groupCols in groups) {
                if (isCancelled()) throw PdfCancelledException()
                if (items.isEmpty()) {
                    slices.add(PageSlice(groupCols, true, IntRange.EMPTY, hasVisibleFooter))
                    continue
                }
                var idx = 0
                var firstPage = true
                while (idx < items.size) {
                    if (isCancelled()) throw PdfCancelledException()
                    var cursorY = topY + (if (firstPage) headerBlockHeight + 8f else 0f) + tableHeaderHeight
                    val startIdx = idx
                    while (idx < items.size) {
                        val rowH = measureRowHeight(
                            row = items[idx],
                            groupCols = groupCols,
                            typeface = arabicTypeface,
                            dateStr = dateStr,
                            currency = report.currency,
                        )
                        if (cursorY + rowH > bottomLimitY && idx > startIdx) {
                            break
                        }
                        cursorY += rowH
                        idx++
                    }
                    val isLastItemSlice = idx >= items.size
                    val fitsFooterOnSamePage = isLastItemSlice && (!hasVisibleFooter || (cursorY + footerBlockHeight + 8f <= bottomLimitY))
                    slices.add(
                        PageSlice(
                            groupCols = groupCols,
                            isFirstPageOfGroup = firstPage,
                            itemRange = startIdx until idx,
                            includeSummaryFooter = fitsFooterOnSamePage && hasVisibleFooter,
                        ),
                    )
                    if (isLastItemSlice && hasVisibleFooter && !fitsFooterOnSamePage) {
                        slices.add(
                            PageSlice(
                                groupCols = groupCols,
                                isFirstPageOfGroup = false,
                                itemRange = IntRange.EMPTY,
                                includeSummaryFooter = true,
                            ),
                        )
                    }
                    firstPage = false
                }
            }

            val totalPages = slices.size.coerceAtLeast(1)
            trace?.stage("رسم صفحات التقرير", "عدد الصفحات=$totalPages")
            slices.forEachIndexed { pageIndex, slice ->
                if (isCancelled()) throw PdfCancelledException()
                onProgress(pageIndex + 1, totalPages)
                val canvas = pdfDocument.beginPage(pageW, pageH, pageIndex + 1)
                canvas.drawColor(Color.WHITE)

                var y = topY
                if (slice.isFirstPageOfGroup) {
                    y += drawReportHeader(
                        canvas = canvas,
                        reportDetails = reportDetails,
                        config = headerFooter,
                        typeface = arabicTypeface,
                        leftX = leftX,
                        rightX = rightX,
                        topY = y,
                        dateStr = dateStr,
                        bitmapCache = bitmapCache,
                    )
                    y += 8f
                }

                // Draw table header & rows if we have items or empty state
                if (slice.groupCols.isNotEmpty() && (!slice.itemRange.isEmpty() || items.isEmpty())) {
                    if (slice.isFirstPageOfGroup || headerFooter.repeatTableHeader) {
                        y += drawTableHeader(
                            canvas = canvas,
                            cols = slice.groupCols,
                            rightX = rightX,
                            topY = y,
                            height = tableHeaderHeight,
                            typeface = arabicTypeface,
                        )
                    }
                    if (items.isEmpty() && slice.isFirstPageOfGroup) {
                        val emptyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.GRAY
                            textSize = 11f
                            typeface = arabicTypeface
                            textAlign = Paint.Align.CENTER
                        }
                        canvas.drawText("لا توجد منتجات مضافة في هذا التقرير", (leftX + rightX) / 2f, y + 26f, emptyPaint)
                        y += 40f
                    } else {
                        for (itemIdx in slice.itemRange) {
                            val row = items[itemIdx]
                            val rowH = measureRowHeight(row, slice.groupCols, arabicTypeface, dateStr, report.currency)
                            drawTableRow(
                                canvas = canvas,
                                rowIndex = itemIdx,
                                row = row,
                                cols = slice.groupCols,
                                rightX = rightX,
                                topY = y,
                                rowHeight = rowH,
                                typeface = arabicTypeface,
                                dateStr = dateStr,
                                currency = report.currency,
                                stripeHex = headerFooter.tableStripeHex,
                                barcodeStyle = barcodeStyle,
                                bitmapCache = bitmapCache,
                                warnings = warnings,
                            )
                            y += rowH
                        }
                    }
                }

                if (slice.includeSummaryFooter) {
                    y += 10f
                    drawReportSummaryFooter(
                        canvas = canvas,
                        reportDetails = reportDetails,
                        config = headerFooter,
                        typeface = arabicTypeface,
                        leftX = leftX,
                        rightX = rightX,
                        topY = y,
                        bitmapCache = bitmapCache,
                    )
                }

                if (headerFooter.showPageNumbers) {
                    drawPageNumberFooter(
                        canvas = canvas,
                        pageNumber = pageIndex + 1,
                        totalPages = totalPages,
                        rightFooterLabel = report.companyName.ifBlank { settings.companyName },
                        typeface = arabicTypeface,
                        leftX = leftX,
                        rightX = rightX,
                        bottomY = pageSpec.pageHeightPt - pageSpec.marginBottomPt,
                    )
                }

                pdfDocument.endPage()
            }

            if (isCancelled()) throw PdfCancelledException()
            trace?.stage("حفظ ملف PDF على التخزين", "صفحات=$totalPages")
            val cleanName = (outputFileName ?: "${settings.exportFilePrefix}_${report.reportNumber}")
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .trim()
                .ifBlank { "report_${report.id}" }
            val outFile = File(mediaStorage.exportsDir, if (cleanName.endsWith(".pdf", true)) cleanName else "$cleanName.pdf")
            FileOutputStream(outFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            trace?.succeed("تم إنشاء ${outFile.name} ($totalPages صفحة)")
            return PdfGenerationResult(outFile, totalPages, warnings.distinct())
        } catch (c: PdfCancelledException) {
            trace?.cancel(c.message ?: "تم إلغاء إنشاء ملف PDF")
            throw c
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء إنشاء ملف PDF بعد مغادرة الواجهة")
            throw c
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.PDF_PREVIEW,
                moduleName = DiagnosticModules.PDF,
                operationName = "توليد ملف PDF للتقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر إنشاء ملف PDF", linkedErrorId = err?.errorId.orEmpty())
            throw t
        } finally {
            pdfDocument.close()
            val cached = bitmapCache.snapshot().values.toList()
            bitmapCache.evictAll()
            cached.forEach { bmp ->
                if (!bmp.isRecycled) bmp.recycle()
            }
        }
    }

    fun generateInventoryReportPdf(
        sessionDetails: InventorySessionWithDetails,
        allProducts: List<ProductWithDetails>,
        settings: AppSettingsEntity,
        inventoryConfig: InventorySheetConfig = InventoryColumnDefaults.decode(settings.inventoryConfigJson),
        outputFileName: String? = null,
        onProgress: (currentPage: Int, totalPages: Int) -> Unit = { _, _ -> },
        isCancelled: () -> Boolean = { false },
    ): PdfGenerationResult {
        val sheetNumber = InventoryColumnDefaults.sheetNumberForSession(sessionDetails.session.id)
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.PDF,
            operationName = "توليد كشف الجرد PDF ($sheetNumber)",
            initialStage = "تهيئة تخطيط كشف الجرد",
        )
        val pageSpec = inventoryConfig.toPageSpec()
        val layoutResult = ColumnLayoutEngine.calculateLayout(
            pageSpec = pageSpec,
            allColumns = inventoryConfig.columns,
            distributionMode = inventoryConfig.distributionMode,
            splitHorizontalGroups = inventoryConfig.splitHorizontalGroups,
        )
        trace?.stage("تحليل أعمدة كشف الجرد", "مجموعات=${layoutResult.columnGroups.size}")
        val typeface = loadArabicTypeface(settings.fontFamilyKey)
        val warnings = mutableListOf<String>()
        if (layoutResult.hasOverflow && !inventoryConfig.splitHorizontalGroups) {
            warnings.add("مجموع عروض الأعمدة يتجاوز العرض الفعلي للصفحة بمقدار ${layoutResult.overflowAmountPt.toInt()} نقطة")
        }

        val pageW = ceil(pageSpec.pageWidthPt).toInt().coerceAtLeast(160)
        val pageH = ceil(pageSpec.pageHeightPt).toInt().coerceAtLeast(200)
        val leftX = pageSpec.marginStartPt
        val rightX = pageSpec.pageWidthPt - pageSpec.marginEndPt
        val topY = pageSpec.marginTopPt
        val bottomLimitY = pageSpec.pageHeightPt - pageSpec.marginBottomPt - (if (inventoryConfig.showPageNumbers) 18f else 6f)

        val dateFmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        val timeFmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        val productMap = allProducts.associateBy { it.product.id }
        val items = sessionDetails.sortedItems
        val distinctProductsCount = items.map { it.productId ?: it.scannedBarcode }.distinct().size
        val totalCountedUnits = items.sumOf { it.countedQty }
        val groups = if (layoutResult.columnGroups.isEmpty()) listOf(emptyList()) else layoutResult.columnGroups

        val pdfDocument = sessionFactory.create()
        val bitmapCache = createBoundedBitmapCache()

        try {
            data class InvPageSlice(
                val groupCols: List<ComputedColumnWidth>,
                val isFirstPageOfGroup: Boolean,
                val itemRange: IntRange,
                val includeSummaryFooter: Boolean,
            )

            val headerBlockHeight = 82f
            val tableHeaderHeight = 26f
            val hasNotesFooter = inventoryConfig.showSessionNotes && sessionDetails.session.notes.isNotBlank()
            val footerBlockHeight = (if (inventoryConfig.showTotalsFooter) 38f else 0f) + (if (hasNotesFooter) 24f else 0f)
            val hasVisibleFooter = footerBlockHeight > 4f

            fun measureInvRowHeight(
                rowIndex: Int,
                item: com.example.data.local.entity.InventoryCountItemEntity,
                groupCols: List<ComputedColumnWidth>,
            ): Float {
                val product = item.productId?.let { productMap[it] }
                var maxH = groupCols.maxOfOrNull { colW ->
                    val col = colW.column
                    when (col.columnType) {
                        ColumnType.BARCODE -> if (inventoryConfig.renderBarcodeGraphic) {
                            maxOf(col.cellHeightPt, inventoryConfig.barcodeHeightPt + (if (inventoryConfig.showBarcodeTextBelow) 14f else 6f))
                        } else {
                            col.cellHeightPt.coerceAtMost(34f)
                        }
                        ColumnType.QR_CODE -> maxOf(col.cellHeightPt, 46f)
                        ColumnType.IMAGE -> if (inventoryConfig.showProductImages) maxOf(col.cellHeightPt, 42f) else 30f
                        else -> col.cellHeightPt
                    }
                } ?: 36f

                for (computed in groupCols) {
                    val col = computed.column
                    val shouldMeasureText = col.columnType in setOf(
                        ColumnType.TEXT,
                        ColumnType.NOTES,
                        ColumnType.CUSTOM_FIELD,
                        ColumnType.LINK,
                        ColumnType.DROPDOWN,
                    ) || (col.columnType == ColumnType.BARCODE && !inventoryConfig.renderBarcodeGraphic)
                    if (shouldMeasureText && col.wrapText) {
                        val txt = resolveInventoryCellText(rowIndex, item, product, col, inventoryConfig, timeFmt)
                        if (txt.isNotEmpty()) {
                            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                                textSize = col.fontSizeSp.coerceIn(6.5f, 15f)
                                this.typeface = typeface
                            }
                            val availW = (computed.widthPt - col.paddingHorizontalPt * 2f).toInt().coerceAtLeast(16)
                            val sl = StaticLayout.Builder.obtain(txt, 0, txt.length, tp, availW)
                                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                                .setTextDirection(TextDirectionHeuristics.RTL)
                                .build()
                            val neededH = sl.height + col.paddingVerticalPt * 2f + 4f
                            if (neededH > maxH) maxH = neededH
                        }
                    }
                }
                return maxH.coerceIn(24f, 190f)
            }

            val slices = mutableListOf<InvPageSlice>()
            for (groupCols in groups) {
                if (isCancelled()) throw PdfCancelledException()
                if (items.isEmpty()) {
                    slices.add(InvPageSlice(groupCols, true, IntRange.EMPTY, hasVisibleFooter))
                    continue
                }
                var idx = 0
                var firstPage = true
                while (idx < items.size) {
                    if (isCancelled()) throw PdfCancelledException()
                    var cursorY = topY + (if (firstPage) headerBlockHeight + 6f else 0f) +
                        (if (firstPage || inventoryConfig.repeatTableHeader) tableHeaderHeight else 0f)
                    val startIdx = idx
                    while (idx < items.size) {
                        val rowH = measureInvRowHeight(idx, items[idx], groupCols)
                        if (cursorY + rowH > bottomLimitY && idx > startIdx) {
                            break
                        }
                        cursorY += rowH
                        idx++
                    }
                    val isLastSlice = idx >= items.size
                    val fitsFooterOnSamePage = isLastSlice && (!hasVisibleFooter || (cursorY + footerBlockHeight + 8f <= bottomLimitY))
                    slices.add(
                        InvPageSlice(
                            groupCols = groupCols,
                            isFirstPageOfGroup = firstPage,
                            itemRange = startIdx until idx,
                            includeSummaryFooter = fitsFooterOnSamePage && hasVisibleFooter,
                        ),
                    )
                    if (isLastSlice && hasVisibleFooter && !fitsFooterOnSamePage) {
                        slices.add(
                            InvPageSlice(
                                groupCols = groupCols,
                                isFirstPageOfGroup = false,
                                itemRange = IntRange.EMPTY,
                                includeSummaryFooter = true,
                            ),
                        )
                    }
                    firstPage = false
                }
            }

            val totalPages = slices.size.coerceAtLeast(1)
            val accentColor = parseColorSafe(settings.accentColorHex, Color.rgb(15, 23, 42))
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 12.5f
                this.typeface = Typeface.create(typeface, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(15, 23, 42)
                textSize = 8.5f
                this.typeface = typeface
                textAlign = Paint.Align.RIGHT
            }
            val leftMetaPaint = TextPaint(metaPaint).apply { textAlign = Paint.Align.LEFT }

            slices.forEachIndexed { pageIdx, slice ->
                if (isCancelled()) throw PdfCancelledException()
                onProgress(pageIdx + 1, totalPages)
                val canvas = pdfDocument.beginPage(pageW, pageH, pageIdx + 1)
                canvas.drawColor(Color.WHITE)
                var y = topY

                if (slice.isFirstPageOfGroup) {
                    val bannerRect = RectF(leftX, y, rightX, y + 26f)
                    canvas.drawRoundRect(bannerRect, 4f, 4f, Paint().apply { color = accentColor })
                    canvas.drawText(
                        "كشف كميات الجرد — ${sessionDetails.session.title}",
                        (leftX + rightX) / 2f,
                        y + 17f,
                        titlePaint,
                    )
                    y += 31f

                    val summaryRect = RectF(leftX, y, rightX, y + 44f)
                    canvas.drawRoundRect(summaryRect, 4f, 4f, Paint().apply { color = Color.rgb(248, 250, 252) })
                    canvas.drawRoundRect(summaryRect, 4f, 4f, Paint().apply { color = Color.rgb(203, 213, 225); style = Paint.Style.STROKE; strokeWidth = 0.8f })
                    canvas.drawText(
                        "رقم الكشف: $sheetNumber   |   المنشأة: ${settings.companyName.ifBlank { settings.appName }}",
                        rightX - 10f,
                        y + 16f,
                        metaPaint,
                    )
                    val invQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(inventoryConfig.columns, "quantity")
                    canvas.drawText(
                        "المنتجات المختلفة: $distinctProductsCount   |   عدد البنود: ${items.size}   |   إجمالي الكميات: ${NumberFormatEngine.formatDouble(totalCountedUnits, invQtySpec)}",
                        rightX - 10f,
                        y + 34f,
                        metaPaint,
                    )
                    canvas.drawText(
                        "التاريخ: ${dateFmt.format(Date(sessionDetails.session.sessionDate))}",
                        leftX + 10f,
                        y + 16f,
                        leftMetaPaint,
                    )
                    y += 51f
                }

                if (slice.groupCols.isNotEmpty() && (!slice.itemRange.isEmpty() || items.isEmpty())) {
                    if (slice.isFirstPageOfGroup || inventoryConfig.repeatTableHeader) {
                        y += drawTableHeader(
                            canvas = canvas,
                            cols = slice.groupCols,
                            rightX = rightX,
                            topY = y,
                            height = tableHeaderHeight,
                            typeface = typeface,
                        )
                    }

                    if (items.isEmpty() && slice.isFirstPageOfGroup) {
                        val emptyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.GRAY
                            textSize = 10.5f
                            this.typeface = typeface
                            textAlign = Paint.Align.CENTER
                        }
                        canvas.drawText("لا توجد بنود مسجلة في كشف الجرد", (leftX + rightX) / 2f, y + 24f, emptyPaint)
                        y += 38f
                    } else {
                        for (itemIdx in slice.itemRange) {
                            val item = items[itemIdx]
                            val product = item.productId?.let { productMap[it] }
                            val rowH = measureInvRowHeight(itemIdx, item, slice.groupCols)
                            var cursorRight = rightX
                            val isEven = itemIdx % 2 == 1

                            for (computed in slice.groupCols) {
                                val col = computed.column
                                val colLeft = cursorRight - computed.widthPt
                                val cellRect = RectF(colLeft, y, cursorRight, y + rowH)
                                val defaultBg = if (isEven) Color.rgb(248, 250, 252) else Color.WHITE
                                val cellBg = if (col.cellBgColorHex.equals("#FFFFFF", true)) defaultBg else parseColorSafe(col.cellBgColorHex, defaultBg)
                                canvas.drawRect(cellRect, Paint().apply { color = cellBg; style = Paint.Style.FILL })
                                if (col.borderWidthPt > 0f) {
                                    canvas.drawRect(
                                        cellRect,
                                        Paint().apply {
                                            color = Color.rgb(203, 213, 225)
                                            style = Paint.Style.STROKE
                                            strokeWidth = col.borderWidthPt
                                        },
                                    )
                                }

                                val innerRect = RectF(
                                    cellRect.left + col.paddingHorizontalPt,
                                    cellRect.top + col.paddingVerticalPt,
                                    cellRect.right - col.paddingHorizontalPt,
                                    cellRect.bottom - col.paddingVerticalPt,
                                )

                                when {
                                    col.columnType == ColumnType.IMAGE -> {
                                        if (inventoryConfig.showProductImages) {
                                            val imgPath = listOfNotNull(
                                                item.productImagePath,
                                                product?.primaryImage?.filePath,
                                                product?.primaryImage?.originalFilePath,
                                                product?.primaryImage?.thumbnailPath,
                                            ).map { ImageService.cleanPath(it) }
                                                .firstOrNull { it.isNotBlank() && File(it).exists() }
                                                .orEmpty()
                                            val bmp = getCachedBitmap(imgPath, bitmapCache, maxDim = 260)
                                            if (bmp != null) {
                                                drawBitmapFitInside(canvas, bmp, innerRect)
                                            }
                                        }
                                    }
                                    col.columnType == ColumnType.BARCODE && inventoryConfig.renderBarcodeGraphic -> {
                                        val code = InventoryColumnDefaults.resolveBarcodeValue(
                                            item,
                                            product,
                                            inventoryConfig.barcodeSourceMode,
                                        )
                                        val defaultInvFmt = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(settings.defaultBarcodeType)
                                            ?: BarcodeFormatType.CODE_128
                                        val fmt = InventoryColumnDefaults.resolveBarcodeFormat(item, product, inventoryConfig, defaultInvFmt)
                                        if (code.isNotBlank()) {
                                            val ok = BarcodeEngine.drawVectorOnCanvas(
                                                canvas = canvas,
                                                value = code,
                                                format = fmt,
                                                bounds = innerRect,
                                                showText = inventoryConfig.showBarcodeTextBelow,
                                                textSizePt = 7.5f,
                                                quietZoneModules = inventoryConfig.quietZoneModules,
                                                alignment = col.alignment,
                                                typeface = Typeface.MONOSPACE,
                                            )
                                            if (!ok) {
                                                warnings.add("مساحة خلية الباركود للصنف (${item.productName}) ضيقة للرسم")
                                                val fallbackTp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                                                    color = Color.rgb(15, 23, 42)
                                                    textSize = 7.5f
                                                    this.typeface = Typeface.MONOSPACE
                                                }
                                                drawAlignedWrappedText(canvas, code, innerRect, fallbackTp, CellAlignment.CENTER, 2f, 2f, false)
                                            }
                                        }
                                    }
                                    col.columnType == ColumnType.QR_CODE -> {
                                        val code = InventoryColumnDefaults.resolveBarcodeValue(
                                            item,
                                            product,
                                            inventoryConfig.barcodeSourceMode,
                                        ).ifBlank { item.productInternalCode.ifBlank { item.productName } }
                                        if (code.isNotBlank()) {
                                            BarcodeEngine.drawVectorOnCanvas(
                                                canvas = canvas,
                                                value = code,
                                                format = BarcodeFormatType.QR_CODE,
                                                bounds = innerRect,
                                                showText = false,
                                                quietZoneModules = 2,
                                                alignment = col.alignment,
                                            )
                                        }
                                    }
                                    else -> {
                                        val txt = resolveInventoryCellText(itemIdx, item, product, col, inventoryConfig, timeFmt)
                                        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                                            color = parseColorSafe(col.textColorHex, Color.rgb(15, 23, 42))
                                            textSize = col.fontSizeSp.coerceIn(6.5f, 15f)
                                            this.typeface = if (col.columnType == ColumnType.BARCODE || col.columnKey == "barcode_text") Typeface.MONOSPACE else typeface
                                        }
                                        drawAlignedWrappedText(
                                            canvas = canvas,
                                            text = txt,
                                            bounds = cellRect,
                                            paint = tp,
                                            alignment = col.alignment,
                                            padH = col.paddingHorizontalPt,
                                            padV = col.paddingVerticalPt,
                                            wrapText = col.wrapText,
                                        )
                                    }
                                }
                                cursorRight = colLeft
                            }
                            y += rowH
                        }
                    }
                }

                if (slice.includeSummaryFooter) {
                    y += 8f
                    if (inventoryConfig.showTotalsFooter) {
                        val boxRect = RectF(leftX, y, rightX, y + 32f)
                        canvas.drawRoundRect(boxRect, 4f, 4f, Paint().apply { color = Color.rgb(241, 245, 249) })
                        canvas.drawRoundRect(boxRect, 4f, 4f, Paint().apply { color = Color.rgb(148, 163, 184); style = Paint.Style.STROKE; strokeWidth = 0.7f })
                        val footerTp = TextPaint(metaPaint).apply {
                            this.typeface = Typeface.create(typeface, Typeface.BOLD)
                        }
                        val invQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(inventoryConfig.columns, "quantity")
                        canvas.drawText(
                            "إجمالي عدد المنتجات المختلفة: $distinctProductsCount   |   عدد البنود بالكشف: ${items.size}   |   مجموع الكميات الفعلية: ${NumberFormatEngine.formatDouble(totalCountedUnits, invQtySpec)}",
                            rightX - 10f,
                            y + 20f,
                            footerTp,
                        )
                        y += 38f
                    }
                    if (hasNotesFooter) {
                        canvas.drawText(
                            "ملاحظات الكشف: ${sessionDetails.session.notes}",
                            rightX - 4f,
                            y + 12f,
                            metaPaint,
                        )
                    }
                }

                if (inventoryConfig.showPageNumbers) {
                    drawPageNumberFooter(
                        canvas = canvas,
                        pageNumber = pageIdx + 1,
                        totalPages = totalPages,
                        rightFooterLabel = settings.companyName,
                        typeface = typeface,
                        leftX = leftX,
                        rightX = rightX,
                        bottomY = pageSpec.pageHeightPt - pageSpec.marginBottomPt,
                    )
                }
                pdfDocument.endPage()
            }

            if (isCancelled()) throw PdfCancelledException()
            trace?.stage("حفظ ملف PDF لكشف الجرد", "صفحات=$totalPages")
            val clean = (outputFileName ?: "inventory_sheet_${sessionDetails.session.id}")
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .ifBlank { "inventory_sheet_${sessionDetails.session.id}" }
            val outFile = File(mediaStorage.exportsDir, if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
            FileOutputStream(outFile).use { fos -> pdfDocument.writeTo(fos) }
            trace?.succeed("تم إنشاء ${outFile.name} ($totalPages صفحة)")
            return PdfGenerationResult(outFile, totalPages, warnings.distinct())
        } catch (c: PdfCancelledException) {
            trace?.cancel(c.message ?: "تم إلغاء إنشاء ملف PDF لكشف الجرد")
            throw c
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء إنشاء PDF لكشف الجرد")
            throw c
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(
                throwable = t,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.PDF,
                operationName = "توليد ملف PDF لكشف الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(t.message ?: "تعذر إنشاء PDF لكشف الجرد", linkedErrorId = err?.errorId.orEmpty())
            throw t
        } finally {
            pdfDocument.close()
            val cached = bitmapCache.snapshot().values.toList()
            bitmapCache.evictAll()
            cached.forEach { bmp ->
                if (!bmp.isRecycled) bmp.recycle()
            }
        }
    }

    internal fun resolveInventoryCellText(
        rowIndex: Int,
        item: com.example.data.local.entity.InventoryCountItemEntity,
        product: ProductWithDetails?,
        col: com.example.domain.model.ColumnConfigModel,
        config: InventorySheetConfig,
        timeFmt: SimpleDateFormat,
    ): String {
        val baseKey = col.columnKey.substringBefore("_copy_")
        return when (baseKey) {
            "serial" -> (rowIndex + 1).toString()
            "internal_code" -> product?.product?.internalCode?.ifBlank { item.productInternalCode }
                ?: item.productInternalCode
            "name" -> item.productName
            "barcode", "barcode_text" -> InventoryColumnDefaults.resolveBarcodeValue(
                item = item,
                product = product,
                mode = config.barcodeSourceMode,
            )
            "barcode_type" -> InventoryColumnDefaults.resolveBarcodeFormat(
                item,
                product,
                config,
                BarcodeFormatType.fromString(
                    config.barcodeFormatOverride.takeUnless { it.equals("AUTO", true) || it.isBlank() }
                        ?: item.barcodeType.ifBlank { product?.primaryBarcode?.barcodeType },
                ),
            ).arabicLabel
            "quantity" -> NumberFormatEngine.formatDouble(item.countedQty, col)
            "base_qty" -> NumberFormatEngine.formatDouble(item.baseUnitEquivalentQty, col)
            "unit" -> item.unitType
            "conversion_factor" -> NumberFormatEngine.formatDouble(item.conversionFactor, col)
            "category" -> product?.product?.categoryName.orEmpty()
            "scanned_at" -> timeFmt.format(Date(item.scannedAt))
            "notes" -> item.notes
            else -> when (col.columnType) {
                ColumnType.SERIAL -> (rowIndex + 1).toString()
                ColumnType.QUANTITY, ColumnType.NUMBER -> NumberFormatEngine.formatDouble(item.countedQty, col)
                ColumnType.PRICE -> NumberFormatEngine.formatDouble(product?.product?.basePrice ?: 0.0, col)
                ColumnType.CURRENCY -> NumberFormatEngine.formatCurrencyAmount(
                    product?.product?.basePrice ?: 0.0,
                    product?.product?.currency ?: "",
                    col.toNumberFormatSpec(),
                )
                ColumnType.PERCENTAGE -> "${NumberFormatEngine.formatDouble(0.0, col)}%"
                ColumnType.NOTES -> item.notes
                ColumnType.DATE -> timeFmt.format(Date(item.scannedAt))
                ColumnType.BARCODE -> InventoryColumnDefaults.resolveBarcodeValue(item, product, config.barcodeSourceMode)
                ColumnType.CUSTOM_FIELD -> {
                    if (col.customFieldKey.isNotBlank() && product != null) {
                        try {
                            val map = kotlinx.serialization.json.Json.decodeFromString<Map<String, String>>(product.product.customFieldsJson)
                            map[col.customFieldKey].orEmpty()
                        } catch (_: Exception) {
                            ""
                        }
                    } else ""
                }
                else -> ""
            }
        }
    }

    private fun measureHeaderHeight(
        reportDetails: ReportWithDetails,
        config: ReportHeaderFooterConfig,
    ): Float {
        var h = 36f // Title bar
        if (config.showCompanyInfo || config.showLogo) h += 38f
        if (config.showClientInfo || config.showReportMeta) h += 42f
        return h
    }

    private fun measureFooterHeight(
        reportDetails: ReportWithDetails,
        config: ReportHeaderFooterConfig,
    ): Float {
        var h = 10f
        if (config.showTotals) h += 64f
        if (config.showNotes && reportDetails.report.notes.isNotBlank()) h += 28f
        if (config.showTerms && reportDetails.report.termsAndConditions.isNotBlank()) h += 28f
        if (config.showResponsible || config.showSignature || config.showStamp) h += 52f
        return h
    }

    private fun drawReportHeader(
        canvas: Canvas,
        reportDetails: ReportWithDetails,
        config: ReportHeaderFooterConfig,
        typeface: Typeface?,
        leftX: Float,
        rightX: Float,
        topY: Float,
        dateStr: String,
        bitmapCache: LruCache<String, Bitmap>,
    ): Float {
        val report = reportDetails.report
        val width = rightX - leftX
        val accentColor = parseColorSafe(config.headerAccentHex, Color.rgb(15, 23, 42))

        var y = topY

        // Top Company + Logo Row
        if (config.showCompanyInfo || config.showLogo) {
            val rowTop = y
            var textRightEdge = rightX
            if (config.showLogo && report.companyLogoPath.isNotBlank()) {
                val logoBmp = getCachedBitmap(report.companyLogoPath, bitmapCache, maxDim = 450)
                if (logoBmp != null) {
                    val logoSize = 36f
                    val logoRect = RectF(rightX - logoSize, rowTop, rightX, rowTop + logoSize)
                    drawBitmapFitInside(canvas, logoBmp, logoRect)
                    textRightEdge -= (logoSize + 8f)
                }
            }
            if (config.showCompanyInfo) {
                val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accentColor
                    textSize = 13f
                    this.typeface = Typeface.create(typeface, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                canvas.drawText(report.companyName.ifBlank { "مدير التقارير" }, textRightEdge, rowTop + 14f, titlePaint)
                val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.DKGRAY
                    textSize = 8.5f
                    this.typeface = typeface
                    textAlign = Paint.Align.RIGHT
                }
                val infoLine = listOf(report.companyAddress, report.companyPhone).filter { it.isNotBlank() }.joinToString("  •  ")
                if (infoLine.isNotBlank()) {
                    canvas.drawText(infoLine, textRightEdge, rowTop + 28f, subPaint)
                }
            }
            y += 40f
        }

        // Report Title Banner
        val bannerPaint = Paint().apply {
            color = accentColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(leftX, y, rightX, y + 26f), 4f, 4f, bannerPaint)
        val bannerTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(report.title, leftX + width / 2f, y + 17f, bannerTextPaint)
        y += 32f

        // Client & Report Meta box
        if (config.showClientInfo || config.showReportMeta) {
            val boxRect = RectF(leftX, y, rightX, y + 38f)
            val fillPaint = Paint().apply { color = Color.rgb(248, 250, 252); style = Paint.Style.FILL }
            val strokePaint = Paint().apply { color = Color.rgb(203, 213, 225); style = Paint.Style.STROKE; strokeWidth = 0.75f }
            canvas.drawRoundRect(boxRect, 4f, 4f, fillPaint)
            canvas.drawRoundRect(boxRect, 4f, 4f, strokePaint)

            val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(15, 23, 42)
                textSize = 8.5f
                this.typeface = typeface
                textAlign = Paint.Align.RIGHT
            }
            if (config.showReportMeta) {
                canvas.drawText("رقم التقرير: ${report.reportNumber}", rightX - 8f, y + 14f, metaPaint)
                canvas.drawText("التاريخ: $dateStr   |   العملة: ${report.currency}", rightX - 8f, y + 29f, metaPaint)
            }
            if (config.showClientInfo) {
                val leftMetaPaint = TextPaint(metaPaint).apply { textAlign = Paint.Align.LEFT }
                val clientLine1 = if (report.clientName.isNotBlank()) "العميل: ${report.clientName}" else ""
                val clientLine2 = listOf(report.clientPhone, report.clientAddress).filter { it.isNotBlank() }.joinToString(" - ")
                if (clientLine1.isNotBlank()) canvas.drawText(clientLine1, leftX + 8f, y + 14f, leftMetaPaint)
                if (clientLine2.isNotBlank()) canvas.drawText(clientLine2, leftX + 8f, y + 29f, leftMetaPaint)
            }
            y += 42f
        }

        return y - topY
    }

    private fun drawTableHeader(
        canvas: Canvas,
        cols: List<ComputedColumnWidth>,
        rightX: Float,
        topY: Float,
        height: Float,
        typeface: Typeface?,
    ): Float {
        // RTL: First column starts at rightX and advances leftward
        var cursorRight = rightX
        for (computed in cols) {
            val col = computed.column
            val colLeft = cursorRight - computed.widthPt
            val rect = RectF(colLeft, topY, cursorRight, topY + height)

            val bgPaint = Paint().apply {
                color = parseColorSafe(col.headerBgColorHex, Color.rgb(15, 23, 42))
                style = Paint.Style.FILL
            }
            canvas.drawRect(rect, bgPaint)

            val borderPaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 0.6f
            }
            canvas.drawRect(rect, borderPaint)

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = parseColorSafe(col.headerTextColorHex, Color.WHITE)
                textSize = (col.fontSizeSp).coerceIn(7f, 13f)
                this.typeface = Typeface.create(typeface, Typeface.BOLD)
            }
            drawAlignedWrappedText(
                canvas = canvas,
                text = col.title,
                bounds = rect,
                paint = tp,
                alignment = CellAlignment.CENTER,
                padH = 3f,
                padV = 3f,
                wrapText = true,
            )
            cursorRight = colLeft
        }
        return height
    }

    private fun measureRowHeight(
        row: com.example.data.local.entity.ReportItemWithBarcodes,
        groupCols: List<ComputedColumnWidth>,
        typeface: Typeface?,
        dateStr: String,
        currency: String,
    ): Float {
        var maxH = groupCols.maxOfOrNull { it.column.cellHeightPt } ?: 38f
        for (computed in groupCols) {
            val col = computed.column
            if (col.columnType in setOf(ColumnType.TEXT, ColumnType.NOTES, ColumnType.CUSTOM_FIELD, ColumnType.LINK, ColumnType.DROPDOWN)) {
                val txt = resolveCellText(row, col, dateStr, currency)
                if (txt.isNotEmpty() && col.wrapText) {
                    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                        textSize = col.fontSizeSp.coerceIn(6.5f, 16f)
                        this.typeface = typeface
                    }
                    val availW = (computed.widthPt - col.paddingHorizontalPt * 2f).toInt().coerceAtLeast(16)
                    val sl = StaticLayout.Builder.obtain(txt, 0, txt.length, tp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .build()
                    val neededH = sl.height + col.paddingVerticalPt * 2f + 4f
                    if (neededH > maxH) maxH = neededH
                }
            }
        }
        return maxH.coerceIn(22f, 220f)
    }

    private fun drawTableRow(
        canvas: Canvas,
        rowIndex: Int,
        row: com.example.data.local.entity.ReportItemWithBarcodes,
        cols: List<ComputedColumnWidth>,
        rightX: Float,
        topY: Float,
        rowHeight: Float,
        typeface: Typeface?,
        dateStr: String,
        currency: String,
        stripeHex: String,
        barcodeStyle: BarcodeStyleConfig,
        bitmapCache: LruCache<String, Bitmap>,
        warnings: MutableList<String>,
    ) {
        var cursorRight = rightX
        val isEven = rowIndex % 2 == 1
        for (computed in cols) {
            val col = computed.column
            val colLeft = cursorRight - computed.widthPt
            val cellRect = RectF(colLeft, topY, cursorRight, topY + rowHeight)

            val defaultBg = if (isEven) parseColorSafe(stripeHex, Color.rgb(248, 250, 252)) else Color.WHITE
            val cellBg = if (col.cellBgColorHex.equals("#FFFFFF", true)) defaultBg else parseColorSafe(col.cellBgColorHex, defaultBg)
            canvas.drawRect(cellRect, Paint().apply { color = cellBg; style = Paint.Style.FILL })

            if (col.borderWidthPt > 0f) {
                canvas.drawRect(
                    cellRect,
                    Paint().apply {
                        color = Color.rgb(203, 213, 225)
                        style = Paint.Style.STROKE
                        strokeWidth = col.borderWidthPt
                    },
                )
            }

            val innerRect = RectF(
                cellRect.left + col.paddingHorizontalPt,
                cellRect.top + col.paddingVerticalPt,
                cellRect.right - col.paddingHorizontalPt,
                cellRect.bottom - col.paddingVerticalPt,
            )

            when (col.columnType) {
                ColumnType.IMAGE -> {
                    val imgPath = (listOf(row.item.imageSnapshotPath) + row.images.sortedBy { it.sortOrder }.map { it.filePath })
                        .map { ImageService.cleanPath(it) }
                        .firstOrNull { it.isNotBlank() && File(it).exists() }
                    val bmp = imgPath?.let { getCachedBitmap(it, bitmapCache, maxDim = 320) }
                    if (bmp != null) {
                        drawBitmapFitInside(canvas, bmp, innerRect)
                    }
                }
                ColumnType.MULTI_IMAGE -> {
                    val paths = row.images.sortedBy { it.sortOrder }.map { ImageService.cleanPath(it.filePath) }
                        .filter { it.isNotBlank() && File(it).exists() }
                        .ifEmpty {
                            listOfNotNull(ImageService.cleanPath(row.item.imageSnapshotPath).takeIf { it.isNotBlank() && File(it).exists() })
                        }
                    val visiblePaths = paths.take(4)
                    if (visiblePaths.isNotEmpty()) {
                        val gap = 2f
                        val count = visiblePaths.size
                        val slotW = ((innerRect.width() - gap * (count - 1)) / count.toFloat()).coerceAtLeast(8f)
                        visiblePaths.forEachIndexed { idx, p ->
                            val bmp = getCachedBitmap(p, bitmapCache, maxDim = 260)
                            if (bmp != null) {
                                val slotLeft = innerRect.left + idx * (slotW + gap)
                                drawBitmapFitInside(canvas, bmp, RectF(slotLeft, innerRect.top, slotLeft + slotW, innerRect.bottom))
                            }
                        }
                    }
                }
                ColumnType.BARCODE -> {
                    val code = row.item.primaryBarcodeSnapshot
                    val fmt = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(row.item.primaryBarcodeTypeSnapshot)
                        ?: BarcodeFormatType.fromString(row.item.primaryBarcodeTypeSnapshot)
                    if (code.isNotBlank()) {
                        val ok = BarcodeEngine.drawVectorOnCanvas(
                            canvas = canvas,
                            value = code,
                            format = fmt,
                            bounds = innerRect,
                            showText = barcodeStyle.showText,
                            textSizePt = barcodeStyle.textSizePt,
                            quietZoneModules = barcodeStyle.quietZoneModules,
                            alignment = col.alignment,
                            typeface = Typeface.MONOSPACE,
                        )
                        if (!ok) {
                            warnings.add("مساحة خلية الباركود للمنتج (${row.item.productNameSnapshot}) ضيقة")
                            val fallbackTp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = Color.RED
                                textSize = 7.5f
                                this.typeface = typeface
                            }
                            drawAlignedWrappedText(canvas, code, innerRect, fallbackTp, CellAlignment.CENTER, 2f, 2f, false)
                        }
                    }
                }
                ColumnType.QR_CODE -> {
                    val code = row.item.primaryBarcodeSnapshot.ifBlank { row.item.productNameSnapshot }
                    if (code.isNotBlank()) {
                        BarcodeEngine.drawVectorOnCanvas(
                            canvas = canvas,
                            value = code,
                            format = BarcodeFormatType.QR_CODE,
                            bounds = innerRect,
                            showText = false,
                            quietZoneModules = 2,
                            alignment = col.alignment,
                        )
                    }
                }
                else -> {
                    val text = resolveCellText(row, col, dateStr, currency)
                    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = parseColorSafe(col.textColorHex, Color.rgb(15, 23, 42))
                        textSize = col.fontSizeSp.coerceIn(6.5f, 16f)
                        this.typeface = typeface
                    }
                    drawAlignedWrappedText(
                        canvas = canvas,
                        text = text,
                        bounds = cellRect,
                        paint = tp,
                        alignment = col.alignment,
                        padH = col.paddingHorizontalPt,
                        padV = col.paddingVerticalPt,
                        wrapText = col.wrapText,
                    )
                }
            }

            cursorRight = colLeft
        }
    }

    private fun drawReportSummaryFooter(
        canvas: Canvas,
        reportDetails: ReportWithDetails,
        config: ReportHeaderFooterConfig,
        typeface: Typeface?,
        leftX: Float,
        rightX: Float,
        topY: Float,
        bitmapCache: LruCache<String, Bitmap>,
    ) {
        val report = reportDetails.report
        val items = reportDetails.sortedItems
        var y = topY

        if (config.showTotals) {
            val totalQty = items.sumOf { it.item.quantity }
            val subtotal = items.sumOf { it.item.unitPrice * it.item.quantity }
            val netTotal = items.sumOf { it.item.lineTotal }
            val totalDiscount = (subtotal - netTotal).coerceAtLeast(0.0)

            val boxRect = RectF(leftX, y, rightX, y + 54f)
            canvas.drawRoundRect(boxRect, 4f, 4f, Paint().apply { color = Color.rgb(241, 245, 249); style = Paint.Style.FILL })
            canvas.drawRoundRect(boxRect, 4f, 4f, Paint().apply { color = Color.rgb(148, 163, 184); style = Paint.Style.STROKE; strokeWidth = 0.75f })

            val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(15, 23, 42)
                textSize = 9f
                this.typeface = typeface
                textAlign = Paint.Align.RIGHT
            }
            val boldPaint = TextPaint(labelPaint).apply {
                textSize = 10.5f
                this.typeface = Typeface.create(typeface, Typeface.BOLD)
            }
            val leftBoldPaint = TextPaint(boldPaint).apply { textAlign = Paint.Align.LEFT }

            val domainCols = reportDetails.sortedColumns.map { it.toDomainModel() }
            val qtySpec = NumberFormatEngine.resolveReportQuantitySpec(domainCols)
            val financialSpec = NumberFormatEngine.resolveReportTotalSpec(domainCols)

            canvas.drawText("عدد المنتجات: ${items.size}    |    إجمالي الكميات: ${NumberFormatEngine.formatDouble(totalQty, qtySpec)}", rightX - 10f, y + 18f, labelPaint)
            canvas.drawText("المجموع قبل الخصم: ${NumberFormatEngine.formatDouble(subtotal, financialSpec)} ${report.currency}    |    إجمالي الخصومات: ${NumberFormatEngine.formatDouble(totalDiscount, financialSpec)} ${report.currency}", rightX - 10f, y + 36f, labelPaint)
            canvas.drawText("الإجمالي النهائي: ${NumberFormatEngine.formatDouble(netTotal, financialSpec)} ${report.currency}", leftX + 10f, y + 34f, leftBoldPaint)
            y += 62f
        }

        val notePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 8.5f
            this.typeface = typeface
            textAlign = Paint.Align.RIGHT
        }
        if (config.showNotes && report.notes.isNotBlank()) {
            canvas.drawText("ملاحظات: ${report.notes}", rightX, y + 12f, notePaint)
            y += 22f
        }
        if (config.showTerms && report.termsAndConditions.isNotBlank()) {
            canvas.drawText("الشروط والأحكام: ${report.termsAndConditions}", rightX, y + 12f, notePaint)
            y += 22f
        }

        if (config.showResponsible || config.showSignature || config.showStamp) {
            y += 6f
            if (config.showResponsible && report.responsiblePerson.isNotBlank()) {
                canvas.drawText("المسؤول: ${report.responsiblePerson}", rightX, y + 14f, notePaint)
            }
            if (config.showSignature) {
                val sigBmp = getCachedBitmap(report.signaturePath, bitmapCache, maxDim = 450)
                if (sigBmp != null) {
                    drawBitmapFitInside(canvas, sigBmp, RectF(leftX + 90f, y, leftX + 165f, y + 34f))
                } else {
                    canvas.drawText("التوقيع: ......................", (leftX + rightX) / 2f, y + 14f, notePaint)
                }
            }
            if (config.showStamp) {
                val stampBmp = getCachedBitmap(report.stampPath, bitmapCache, maxDim = 450)
                if (stampBmp != null) {
                    drawBitmapFitInside(canvas, stampBmp, RectF(leftX, y, leftX + 60f, y + 38f))
                } else {
                    val leftPaint = TextPaint(notePaint).apply { textAlign = Paint.Align.LEFT }
                    canvas.drawText("الختم الرسمي", leftX, y + 14f, leftPaint)
                }
            }
        }
    }

    private fun drawPageNumberFooter(
        canvas: Canvas,
        pageNumber: Int,
        totalPages: Int,
        rightFooterLabel: String,
        typeface: Typeface?,
        leftX: Float,
        rightX: Float,
        bottomY: Float,
    ) {
        val lineY = bottomY - 12f
        canvas.drawLine(leftX, lineY, rightX, lineY, Paint().apply { color = Color.LTGRAY; strokeWidth = 0.5f })
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GRAY
            textSize = 7.5f
            this.typeface = typeface
            textAlign = Paint.Align.LEFT
        }
        canvas.drawText("صفحة $pageNumber من $totalPages", leftX, bottomY, tp)
        if (rightFooterLabel.isNotBlank()) {
            val rightTp = TextPaint(tp).apply { textAlign = Paint.Align.RIGHT }
            canvas.drawText(rightFooterLabel, rightX, bottomY, rightTp)
        }
    }

    internal fun resolveCellText(
        row: com.example.data.local.entity.ReportItemWithBarcodes,
        col: ColumnConfigModel,
        dateStr: String,
        currency: String,
    ): String {
        val item = row.item
        val key = col.columnKey
        val spec = col.toNumberFormatSpec()
        return when (col.columnType) {
            ColumnType.SERIAL -> item.serialNumber.toString()
            ColumnType.PRICE -> NumberFormatEngine.formatDouble(item.unitPrice, spec)
            ColumnType.CURRENCY -> {
                val value = if (key == "price") item.unitPrice else item.lineTotal
                NumberFormatEngine.formatCurrencyAmount(value, currency, spec)
            }
            ColumnType.QUANTITY -> NumberFormatEngine.formatDouble(item.quantity, spec)
            ColumnType.NUMBER -> {
                val numValue = when (key) {
                    "subtotal" -> item.unitPrice * item.quantity
                    "discount_amount" -> (item.unitPrice * item.quantity - item.lineTotal).coerceAtLeast(0.0)
                    else -> col.customFieldKey.toDoubleOrNull() ?: item.quantity
                }
                NumberFormatEngine.formatDouble(numValue, spec)
            }
            ColumnType.PERCENTAGE -> "${NumberFormatEngine.formatDouble(item.discountPercent, spec)}%"
            ColumnType.DATE -> dateStr
            ColumnType.NOTES -> item.notes
            else -> when (key) {
                "name" -> item.productNameSnapshot
                "barcode_text" -> item.primaryBarcodeSnapshot
                "barcode_type" -> item.primaryBarcodeTypeSnapshot
                "category" -> item.categorySnapshot
                "origin" -> item.originCountrySnapshot
                "manufacturer" -> item.manufacturerSnapshot
                "internal_code" -> item.sourceProductId?.toString().orEmpty()
                else -> item.productNameSnapshot
            }
        }
    }

    private fun drawAlignedWrappedText(
        canvas: Canvas,
        text: String,
        bounds: RectF,
        paint: TextPaint,
        alignment: CellAlignment,
        padH: Float,
        padV: Float,
        wrapText: Boolean,
    ) {
        if (text.isBlank()) return
        drawnCellTextObserver?.invoke(text)
        val availW = (bounds.width() - padH * 2f).toInt().coerceAtLeast(10)
        val layoutAlign = when (alignment) {
            CellAlignment.START -> Layout.Alignment.ALIGN_NORMAL
            CellAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            CellAlignment.END -> Layout.Alignment.ALIGN_OPPOSITE
        }
        val sl = StaticLayout.Builder.obtain(text, 0, text.length, paint, availW)
            .setAlignment(layoutAlign)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setMaxLines(if (wrapText) 6 else 1)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()

        canvas.save()
        canvas.clipRect(bounds)
        val contentH = sl.height.toFloat()
        val dy = bounds.top + ((bounds.height() - contentH) / 2f).coerceAtLeast(padV)
        canvas.translate(bounds.left + padH, dy)
        sl.draw(canvas)
        canvas.restore()
    }

    private fun drawBitmapFitInside(canvas: Canvas, bitmap: Bitmap, target: RectF) {
        if (bitmap.width <= 0 || bitmap.height <= 0 || target.width() <= 1f || target.height() <= 1f) return
        val scale = minOf(target.width() / bitmap.width.toFloat(), target.height() / bitmap.height.toFloat())
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        val left = target.left + (target.width() - drawW) / 2f
        val top = target.top + (target.height() - drawH) / 2f
        val dest = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bitmap, Rect(0, 0, bitmap.width, bitmap.height), dest, Paint(Paint.FILTER_BITMAP_FLAG))
    }

    private fun getCachedBitmap(
        path: String,
        cache: LruCache<String, Bitmap>,
        maxDim: Int = 320,
    ): Bitmap? {
        val cleanPath = ImageService.cleanPath(path)
        if (cleanPath.isBlank()) return null
        val key = "$cleanPath#$maxDim"
        val existing = cache.get(key)
        if (existing != null && !existing.isRecycled) return existing
        val decoded = mediaStorage.decodeSampledBitmap(cleanPath, maxDim) ?: return null
        cache.put(key, decoded)
        return decoded
    }

    private fun loadArabicTypeface(fontKey: String): Typeface? {
        val resId = if (fontKey == "IBM_PLEX") R.font.ibm_plex_sans_arabic else R.font.cairo
        return try {
            ResourcesCompat.getFont(context, resId)
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.PDF_PREVIEW, DiagnosticModules.PDF, "تحميل الخط العربي لملف PDF")
            Typeface.DEFAULT
        }
    }

    private fun parseColorSafe(hex: String, fallback: Int): Int = try {
        Color.parseColor(hex)
    } catch (_: Exception) {
        fallback
    }
}
