package com.example.domain.auth

import android.content.Context
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.ScreenNames
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Production Firebase Authentication gateway.
 *
 * Gracefully checks whether `google-services.json` and FirebaseApp have been configured yet
 * without crashing on launch if `google-services.json` is pending manual placement.
 * Uses Firebase Authentication ONLY (no Firestore, no Realtime DB, no Functions, no custom backend).
 */
class FirebaseAuthGateway(
    private val context: Context,
    private val errorMonitor: GlobalErrorMonitor? = null,
) : AuthGateway {

    private val _authStateFlow = MutableStateFlow<AuthUserProfile?>(null)
    override val authStateFlow: StateFlow<AuthUserProfile?> = _authStateFlow.asStateFlow()

    private val authLock = Any()

    @Volatile
    private var attachedAuth: FirebaseAuth? = null

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        _authStateFlow.value = firebaseAuth.currentUser?.toAuthProfile()
    }

    init {
        tryAttachFirebaseAuth()
    }

    override fun currentUser(): AuthUserProfile? {
        val auth = tryAttachFirebaseAuth() ?: return null
        return auth.currentUser?.toAuthProfile()
    }

    override fun configurationStatus(): AuthConfigurationStatus {
        val appIdRes = context.resources.getIdentifier("google_app_id", "string", context.packageName)
        val googleAppId = if (appIdRes != 0) runCatching { context.getString(appIdRes) }.getOrDefault("") else ""
        val isGoogleServicesConfigured = googleAppId.isNotBlank() && !googleAppId.contains("placeholder", ignoreCase = true)

        val webClientRes = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        val webClientId = if (webClientRes != 0) runCatching { context.getString(webClientRes) }.getOrDefault("") else ""
        val hasWebClientId = webClientId.isNotBlank()

        val auth = tryAttachFirebaseAuth()
        val isInitialized = auth != null

        val statusMessage = when {
            !isGoogleServicesConfigured ->
                "لم يتم ربط ملف إعدادات Firebase (google-services.json) بعد. يمكنك تصفح الشاشة والاحتفاظ ببياناتك المحلية، وسيتفعل تسجيل الدخول فور إضافة الملف."
            !isInitialized ->
                "تعذر تهيئة FirebaseApp رغم وجود الإعدادات؛ تحقق من تطابق Package Name (${context.packageName}) داخل google-services.json."
            !hasWebClientId ->
                "Firebase مهيأ للبريد الإلكتروني، لكن default_web_client_id غير متوفر؛ تحقق من تفعيل Google Sign-In وإضافة بصمات SHA-1 وSHA-256 في Firebase Console."
            else ->
                "Firebase Authentication مهيأ وجاهز للاتصال."
        }

        return AuthConfigurationStatus(
            isGoogleServicesConfigured = isGoogleServicesConfigured,
            isFirebaseInitialized = isInitialized,
            googleWebClientIdPresent = hasWebClientId,
            statusMessage = statusMessage,
        )
    }

    fun getGoogleWebClientIdOrNull(): String? {
        val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        if (resId == 0) return null
        return runCatching { context.getString(resId) }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    private fun tryAttachFirebaseAuth(): FirebaseAuth? {
        attachedAuth?.let { return it }
        return synchronized(authLock) {
            attachedAuth?.let { return@synchronized it }
            val app = runCatching {
                FirebaseApp.getApps(context).firstOrNull() ?: FirebaseApp.initializeApp(context)
            }.getOrNull() ?: return@synchronized null

            runCatching {
                FirebaseAuth.getInstance(app).also { auth ->
                    auth.addAuthStateListener(authStateListener)
                    _authStateFlow.value = auth.currentUser?.toAuthProfile()
                    attachedAuth = auth
                }
            }.getOrNull()
        }
    }

    private fun requireConfiguredAuthOrFailure(): Pair<FirebaseAuth?, AuthActionResult.Failure?> {
        val auth = tryAttachFirebaseAuth()
        if (auth == null) {
            return null to AuthActionResult.Failure(
                errorCode = "FIREBASE_NOT_CONFIGURED",
                userMessageArabic = "إعدادات Firebase غير مكتملة بعد. يرجى وضع ملف google-services.json الصحيح للمشروع في app/ لتفعيل المصادقة.",
            )
        }
        return auth to null
    }

    private fun ensureOnlineOrFailure(): AuthActionResult.Failure? {
        if (!AuthErrorMapper.isNetworkAvailable(context)) {
            return AuthActionResult.Failure(
                errorCode = "NO_INTERNET",
                userMessageArabic = "لا يوجد اتصال بالإنترنت حالياً. يرجى التحقق من الشبكة والمحاولة مرة أخرى.",
                isNetworkError = true,
            )
        }
        return null
    }

    override suspend fun signInWithGoogleIdToken(idToken: String): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        if (idToken.isBlank()) {
            return@withContext AuthActionResult.Failure(
                errorCode = "EMPTY_ID_TOKEN",
                userMessageArabic = "لم يتم استلام رمز تعريف صالح من حساب Google.",
            )
        }

        try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val result = auth.signInWithCredential(credential).await()
            val profile = result.user?.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(
                user = profile,
                message = "تم تسجيل الدخول بحساب Google بنجاح",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("تسجيل الدخول بحساب Google", t)
            AuthErrorMapper.mapException(
                throwable = t,
                operationLabel = "تسجيل الدخول بحساب Google",
                pendingGoogleIdToken = idToken,
            )
        }
    }

    override suspend fun signInWithEmail(email: String, password: String): AuthActionResult = withContext(Dispatchers.IO) {
        val cleanEmail = AuthInputValidator.normalizeEmail(email)
        AuthInputValidator.validateSignInInputs(cleanEmail, password)?.let { errMsg ->
            return@withContext AuthActionResult.Failure("INVALID_INPUT", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        try {
            val res = auth.signInWithEmailAndPassword(cleanEmail, password).await()
            val user = res.user ?: return@withContext AuthActionResult.Failure(
                errorCode = "NULL_USER",
                userMessageArabic = "تعذر قراءة بيانات الحساب بعد تسجيل الدخول.",
            )
            runCatching { user.reload().await() }
            val profile = user.toAuthProfile()
            _authStateFlow.value = profile
            if (!profile.isAccountVerified) {
                AuthActionResult.RequiresEmailVerification(
                    user = profile,
                    message = "تم تسجيل الدخول لكن البريد الإلكتروني غير موثق بعد. يرجى تأكيد رابط التفعيل المرسل إلى بريدك أو إعادة إرساله.",
                )
            } else {
                AuthActionResult.Success(profile, "تم تسجيل الدخول بالبريد الإلكتروني بنجاح")
            }
        } catch (t: Throwable) {
            recordAuthDiagnostic("تسجيل الدخول بالبريد الإلكتروني", t)
            AuthErrorMapper.mapException(t, "تسجيل الدخول بالبريد الإلكتروني")
        }
    }

    override suspend fun registerWithEmail(
        email: String,
        password: String,
        displayName: String,
    ): AuthActionResult = withContext(Dispatchers.IO) {
        val cleanEmail = AuthInputValidator.normalizeEmail(email)
        val cleanName = displayName.trim()
        AuthInputValidator.validateRegistrationInputs(cleanName, cleanEmail, password, password)?.let { errMsg ->
            return@withContext AuthActionResult.Failure("INVALID_INPUT", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        try {
            val res = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val user = res.user ?: return@withContext AuthActionResult.Failure(
                errorCode = "NULL_USER",
                userMessageArabic = "تعذر إنشاء الحساب؛ لم يتم إرجاع بيانات المستخدم.",
            )
            if (cleanName.isNotBlank()) {
                runCatching {
                    user.updateProfile(
                        UserProfileChangeRequest.Builder()
                            .setDisplayName(cleanName)
                            .build(),
                    ).await()
                }
            }
            var verificationSent = false
            runCatching {
                user.sendEmailVerification().await()
                verificationSent = true
            }
            runCatching { user.reload().await() }
            val profile = user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.RequiresEmailVerification(
                user = profile,
                message = if (verificationSent) {
                    "تم إنشاء الحساب وإرسال رسالة التحقق إلى $cleanEmail. يرجى تأكيد بريدك الإلكتروني ثم الضغط على «تحديث حالة التحقق»."
                } else {
                    "تم إنشاء الحساب، لكن تعذر إرسال رسالة التحقق تلقائياً. يمكنك إعادة الإرسال من الزر أدناه."
                },
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("إنشاء حساب بالبريد الإلكتروني", t)
            AuthErrorMapper.mapException(t, "إنشاء حساب جديد")
        }
    }

    override suspend fun sendEmailVerification(): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة مستخدم نشطة لإرسال رسالة التحقق.",
        )

        try {
            user.sendEmailVerification().await()
            val profile = user.toAuthProfile()
            AuthActionResult.Success(
                user = profile,
                message = "تم إرسال رسالة التحقق إلى ${profile.email}. يرجى مراجعة البريد الوارد أو البريد غير الهام.",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("إرسال رسالة التحقق", t)
            AuthErrorMapper.mapException(t, "إرسال رسالة التحقق")
        }
    }

    override suspend fun reloadCurrentUser(): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة نشطة حالياً.",
        )

        try {
            user.reload().await()
            val refreshed = auth.currentUser?.toAuthProfile()
            _authStateFlow.value = refreshed
            if (refreshed != null && !refreshed.isAccountVerified) {
                AuthActionResult.RequiresEmailVerification(
                    user = refreshed,
                    message = "لم يتم تأكيد البريد الإلكتروني بعد. تأكد من فتح رابط التحقق المرسل لبريدك.",
                )
            } else {
                AuthActionResult.Success(
                    user = refreshed,
                    message = "تم التحقق من البريد الإلكتروني وتحديث بيانات الحساب بنجاح.",
                )
            }
        } catch (t: Throwable) {
            recordAuthDiagnostic("تحديث حالة المستخدم", t)
            AuthErrorMapper.mapException(t, "تحديث حالة الحساب")
        }
    }

    override suspend fun sendPasswordResetEmail(email: String): AuthActionResult = withContext(Dispatchers.IO) {
        val cleanEmail = AuthInputValidator.normalizeEmail(email)
        AuthInputValidator.validateEmail(cleanEmail)?.let { errMsg ->
            return@withContext AuthActionResult.Failure("INVALID_EMAIL", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        try {
            auth.sendPasswordResetEmail(cleanEmail).await()
            AuthActionResult.Success(
                user = auth.currentUser?.toAuthProfile(),
                message = "إذا كان البريد $cleanEmail مسجلاً، فسيصله رابط إعادة تعيين كلمة المرور خلال لحظات.",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("إرسال رابط إعادة تعيين كلمة المرور", t)
            AuthErrorMapper.mapException(t, "إعادة تعيين كلمة المرور")
        }
    }

    override suspend fun updatePassword(
        currentPassword: String?,
        newPassword: String,
    ): AuthActionResult = withContext(Dispatchers.IO) {
        AuthInputValidator.validatePasswordPolicy(newPassword).errorMessage?.let { errMsg ->
            return@withContext AuthActionResult.Failure("WEAK_PASSWORD", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "يرجى تسجيل الدخول أولاً لتغيير كلمة المرور.",
        )

        try {
            val email = user.email.orEmpty()
            if (!currentPassword.isNullOrEmpty() && email.isNotBlank()) {
                val cred = EmailAuthProvider.getCredential(email, currentPassword)
                user.reauthenticate(cred).await()
            }
            user.updatePassword(newPassword).await()
            val profile = user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(profile, "تم تحديث كلمة المرور بنجاح.")
        } catch (t: Throwable) {
            recordAuthDiagnostic("تغيير كلمة المرور", t)
            AuthErrorMapper.mapException(t, "تغيير كلمة المرور")
        }
    }

    override suspend fun linkGoogleIdToken(idToken: String): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "يجب تسجيل الدخول بالحساب الحالي أولاً لربطه بحساب Google.",
        )
        if (idToken.isBlank()) {
            return@withContext AuthActionResult.Failure("EMPTY_ID_TOKEN", "رمز تعريف Google غير صالح.")
        }

        try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val res = user.linkWithCredential(credential).await()
            val profile = res.user?.toAuthProfile() ?: user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(
                user = profile,
                message = "تم ربط حساب Google بحسابك الحالي بنجاح (مع بقاء معرف الحساب ثابتاً وجميع بياناتك كما هي).",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("ربط حساب Google بالحساب الحالي", t)
            AuthErrorMapper.mapException(t, "ربط حساب Google", pendingGoogleIdToken = idToken)
        }
    }

    override suspend fun linkEmailPassword(email: String, password: String): AuthActionResult = withContext(Dispatchers.IO) {
        val cleanEmail = AuthInputValidator.normalizeEmail(email)
        AuthInputValidator.validateEmail(cleanEmail)?.let { errMsg ->
            return@withContext AuthActionResult.Failure("INVALID_EMAIL", errMsg)
        }
        AuthInputValidator.validatePasswordPolicy(password).errorMessage?.let { errMsg ->
            return@withContext AuthActionResult.Failure("WEAK_PASSWORD", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "يجب تسجيل الدخول أولاً لربط البريد الإلكتروني وكلمة المرور بحسابك.",
        )

        try {
            val credential = EmailAuthProvider.getCredential(cleanEmail, password)
            val res = user.linkWithCredential(credential).await()
            val profile = res.user?.toAuthProfile() ?: user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(
                user = profile,
                message = "تم ربط البريد الإلكتروني وكلمة المرور بحسابك بنجاح.",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("ربط البريد وكلمة المرور بالحساب الحالي", t)
            AuthErrorMapper.mapException(t, "ربط البريد وكلمة المرور")
        }
    }

    override suspend fun unlinkProvider(providerType: AuthProviderType): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة نشطة.",
        )
        val currentProviders = user.providerData.mapNotNull { AuthProviderType.fromProviderId(it.providerId) }.toSet()
        if (currentProviders.size <= 1) {
            return@withContext AuthActionResult.Failure(
                errorCode = "LAST_PROVIDER",
                userMessageArabic = "لا يمكن فك ربط وسيلة الدخول الوحيدة المرتبطة بالحساب.",
            )
        }

        try {
            val res = user.unlink(providerType.firebaseProviderId).await()
            val profile = res.user?.toAuthProfile() ?: user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(profile, "تم فك ربط ${providerType.arabicLabel} بنجاح.")
        } catch (t: Throwable) {
            recordAuthDiagnostic("فك ربط وسيلة دخول", t)
            AuthErrorMapper.mapException(t, "فك ربط ${providerType.arabicLabel}")
        }
    }

    override suspend fun reauthenticateWithGoogleIdToken(idToken: String): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة نشطة لإعادة المصادقة.",
        )

        try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            user.reauthenticate(credential).await()
            val profile = user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(profile, "تم التحقق من هويتك عبر Google بنجاح.")
        } catch (t: Throwable) {
            recordAuthDiagnostic("إعادة المصادقة عبر Google", t)
            AuthErrorMapper.mapException(t, "إعادة المصادقة عبر Google")
        }
    }

    override suspend fun reauthenticateWithEmailPassword(
        email: String,
        password: String,
    ): AuthActionResult = withContext(Dispatchers.IO) {
        val cleanEmail = AuthInputValidator.normalizeEmail(email)
        AuthInputValidator.validateSignInInputs(cleanEmail, password)?.let { errMsg ->
            return@withContext AuthActionResult.Failure("INVALID_INPUT", errMsg)
        }
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة نشطة لإعادة المصادقة.",
        )

        try {
            val credential = EmailAuthProvider.getCredential(cleanEmail, password)
            user.reauthenticate(credential).await()
            val profile = user.toAuthProfile()
            _authStateFlow.value = profile
            AuthActionResult.Success(profile, "تم التحقق من كلمة المرور بنجاح.")
        } catch (t: Throwable) {
            recordAuthDiagnostic("إعادة المصادقة بالبريد الإلكتروني", t)
            AuthErrorMapper.mapException(t, "إعادة المصادقة بالبريد الإلكتروني")
        }
    }

    override suspend fun signOut(): AuthActionResult = withContext(Dispatchers.IO) {
        val auth = tryAttachFirebaseAuth()
        runCatching { auth?.signOut() }
        _authStateFlow.value = null
        AuthActionResult.Success(
            user = null,
            message = "تم تسجيل الخروج بأمان. جميع بياناتك المحلية محفوظة على الجهاز.",
        )
    }

    override suspend fun deleteCurrentAccount(): AuthActionResult = withContext(Dispatchers.IO) {
        val (auth, notReady) = requireConfiguredAuthOrFailure()
        if (auth == null) return@withContext notReady!!
        ensureOnlineOrFailure()?.let { return@withContext it }

        val user = auth.currentUser ?: return@withContext AuthActionResult.Failure(
            errorCode = "NO_ACTIVE_SESSION",
            userMessageArabic = "لا توجد جلسة حساب نشطة لحذفها.",
        )

        try {
            user.delete().await()
            _authStateFlow.value = null
            AuthActionResult.Success(
                user = null,
                message = "تم حذف حساب Firebase Authentication نهائياً.",
            )
        } catch (t: Throwable) {
            recordAuthDiagnostic("حذف حساب Firebase", t)
            AuthErrorMapper.mapException(t, "حذف الحساب")
        }
    }

    private fun recordAuthDiagnostic(operation: String, throwable: Throwable) {
        errorMonitor?.recordError(
            throwable = throwable,
            screenName = ScreenNames.AUTH,
            moduleName = DiagnosticModules.AUTH,
            operationName = operation,
            wasHandled = true,
            severity = LogSeverity.WARNING,
        )
    }

    private fun FirebaseUser.toAuthProfile(): AuthUserProfile {
        val providerSet = providerData
            .mapNotNull { AuthProviderType.fromProviderId(it.providerId) }
            .toSet()
        return AuthUserProfile(
            uid = uid,
            email = email.orEmpty(),
            displayName = displayName.orEmpty(),
            photoUrl = photoUrl?.toString().orEmpty(),
            isEmailVerified = isEmailVerified,
            providers = providerSet,
            creationTimestamp = metadata?.creationTimestamp ?: 0L,
            lastSignInTimestamp = metadata?.lastSignInTimestamp ?: 0L,
        )
    }
}
