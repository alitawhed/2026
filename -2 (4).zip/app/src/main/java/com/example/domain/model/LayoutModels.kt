package com.example.domain.model

import kotlinx.serialization.Serializable

const val MM_TO_PT = 72f / 25.4f

@Serializable
data class PageSpec(
    val paperSize: PaperSizeType = PaperSizeType.A4,
    val customWidthMm: Float = 210f,
    val customHeightMm: Float = 297f,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val marginTopMm: Float = 12f,
    val marginBottomMm: Float = 12f,
    val marginStartMm: Float = 10f,
    val marginEndMm: Float = 10f,
) {
    val rawWidthMm: Float
        get() = if (paperSize == PaperSizeType.CUSTOM) customWidthMm.coerceIn(60f, 1000f) else paperSize.widthMm

    val rawHeightMm: Float
        get() = if (paperSize == PaperSizeType.CUSTOM) customHeightMm.coerceIn(60f, 1400f) else paperSize.heightMm

    val orientedWidthMm: Float
        get() = if (orientation == PageOrientation.LANDSCAPE) maxOf(rawWidthMm, rawHeightMm) else minOf(rawWidthMm, rawHeightMm)

    val orientedHeightMm: Float
        get() = if (orientation == PageOrientation.LANDSCAPE) minOf(rawWidthMm, rawHeightMm) else maxOf(rawWidthMm, rawHeightMm)

    val pageWidthPt: Float get() = orientedWidthMm * MM_TO_PT
    val pageHeightPt: Float get() = orientedHeightMm * MM_TO_PT
    val marginTopPt: Float get() = marginTopMm.coerceAtLeast(2f) * MM_TO_PT
    val marginBottomPt: Float get() = marginBottomMm.coerceAtLeast(2f) * MM_TO_PT
    val marginStartPt: Float get() = marginStartMm.coerceAtLeast(2f) * MM_TO_PT
    val marginEndPt: Float get() = marginEndMm.coerceAtLeast(2f) * MM_TO_PT

    val usableWidthPt: Float
        get() = (pageWidthPt - marginStartPt - marginEndPt).coerceAtLeast(100f)

    val usableHeightPt: Float
        get() = (pageHeightPt - marginTopPt - marginBottomPt).coerceAtLeast(120f)
}

@Serializable
data class ColumnConfigModel(
    val id: Long = 0L,
    val columnKey: String,
    val title: String,
    val columnType: ColumnType,
    val visible: Boolean = true,
    val sortOrder: Int = 0,
    val widthMode: ColumnDistributionMode = ColumnDistributionMode.AUTO_FIT,
    val manualWidthPt: Float = 80f,
    val presetWidth: ColumnWidthPreset = ColumnWidthPreset.MEDIUM,
    val minWidthPt: Float = 36f,
    val maxWidthPt: Float = 320f,
    val cellHeightPt: Float = 42f,
    val fontSizeSp: Float = 10f,
    val textColorHex: String = "#0F172A",
    val cellBgColorHex: String = "#FFFFFF",
    val headerBgColorHex: String = "#0F172A",
    val headerTextColorHex: String = "#FFFFFF",
    val alignment: CellAlignment = CellAlignment.CENTER,
    val wrapText: Boolean = true,
    val borderWidthPt: Float = 0.75f,
    val paddingHorizontalPt: Float = 5f,
    val paddingVerticalPt: Float = 4f,
    val numberFormat: String = "DECIMAL",
    val decimalPlaces: Int = 2,
    val autoDecimals: Boolean = false,
    val stripTrailingZeros: Boolean = false,
    val dropdownOptions: List<String> = emptyList(),
    val customFieldKey: String = "",
    val pinned: Boolean = false,
)

data class ComputedColumnWidth(
    val column: ColumnConfigModel,
    val widthPt: Float,
    val horizontalGroupIndex: Int = 0,
)

enum class OverflowSuggestionType {
    SWITCH_LANDSCAPE,
    REDUCE_MARGINS,
    LARGER_PAPER_A3,
    MANUAL_WIDTHS,
    SPLIT_HORIZONTAL_GROUPS,
}

data class OverflowSuggestion(
    val type: OverflowSuggestionType,
    val title: String,
    val description: String,
)

data class ColumnLayoutResult(
    val usableWidthPt: Float,
    val totalAllocatedWidthPt: Float,
    val computedColumns: List<ComputedColumnWidth>,
    val hasOverflow: Boolean,
    val overflowAmountPt: Float,
    val suggestions: List<OverflowSuggestion>,
    val columnGroups: List<List<ComputedColumnWidth>>,
)

@Serializable
data class BarcodeStyleConfig(
    val format: BarcodeFormatType = BarcodeFormatType.CODE_128,
    val widthPt: Float = 96f,
    val heightPt: Float = 32f,
    val showText: Boolean = true,
    val textSizePt: Float = 8f,
    val quietZoneModules: Int = 8,
    val alignment: CellAlignment = CellAlignment.CENTER,
    val dpi: Int = 300,
)

@Serializable
data class ReportHeaderFooterConfig(
    val showLogo: Boolean = true,
    val showCompanyInfo: Boolean = true,
    val showClientInfo: Boolean = true,
    val showReportMeta: Boolean = true,
    val showTotals: Boolean = true,
    val showNotes: Boolean = true,
    val showTerms: Boolean = false,
    val showResponsible: Boolean = true,
    val showSignature: Boolean = true,
    val showStamp: Boolean = false,
    val repeatTableHeader: Boolean = true,
    val showPageNumbers: Boolean = true,
    val headerAccentHex: String = "#0F172A",
    val tableStripeHex: String = "#F8FAFC",
)
