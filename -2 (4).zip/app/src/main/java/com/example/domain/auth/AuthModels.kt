package com.example.domain.auth

enum class AuthProviderType(val firebaseProviderId: String, val arabicLabel: String) {
    GOOGLE("google.com", "حساب Google"),
    EMAIL_PASSWORD("password", "البريد الإلكتروني وكلمة المرور");

    companion object {
        fun fromProviderId(id: String): AuthProviderType? =
            entries.firstOrNull { it.firebaseProviderId.equals(id, ignoreCase = true) }
    }
}

data class AuthUserProfile(
    val uid: String,
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val isEmailVerified: Boolean = false,
    val providers: Set<AuthProviderType> = emptySet(),
    val creationTimestamp: Long = 0L,
    val lastSignInTimestamp: Long = 0L,
) {
    val hasGoogleProvider: Boolean
        get() = AuthProviderType.GOOGLE in providers

    val hasEmailPasswordProvider: Boolean
        get() = AuthProviderType.EMAIL_PASSWORD in providers

    /**
     * A user is considered verified for email/password accounts only after Firebase confirms
     * isEmailVerified == true (or when authenticated via a trusted OAuth provider like Google).
     */
    val isAccountVerified: Boolean
        get() = isEmailVerified || hasGoogleProvider

    val effectiveDisplayLabel: String
        get() = displayName.ifBlank { email.substringBefore('@').ifBlank { uid.take(8) } }
}

data class AuthConfigurationStatus(
    val isGoogleServicesConfigured: Boolean,
    val isFirebaseInitialized: Boolean,
    val googleWebClientIdPresent: Boolean,
    val statusMessage: String,
) {
    val isReadyForGoogleSignIn: Boolean
        get() = isGoogleServicesConfigured && isFirebaseInitialized && googleWebClientIdPresent

    val isReadyForEmailAuth: Boolean
        get() = isGoogleServicesConfigured && isFirebaseInitialized
}

sealed interface AuthActionResult {
    data class Success(
        val user: AuthUserProfile?,
        val message: String = "",
    ) : AuthActionResult

    data class RequiresEmailVerification(
        val user: AuthUserProfile,
        val message: String,
    ) : AuthActionResult

    data class AccountCollision(
        val email: String,
        val existingProviderHint: String,
        val message: String,
        val pendingGoogleIdToken: String? = null,
    ) : AuthActionResult

    data class RequiresRecentLogin(
        val operationLabel: String,
        val message: String,
    ) : AuthActionResult

    data object Cancelled : AuthActionResult

    data class Failure(
        val errorCode: String,
        val userMessageArabic: String,
        val technicalReason: String = "",
        val isNetworkError: Boolean = false,
    ) : AuthActionResult
}

data class PasswordValidationResult(
    val isValid: Boolean,
    val hasMinLength: Boolean,
    val hasLetter: Boolean,
    val hasDigit: Boolean,
    val hasNoSpaces: Boolean,
    val errorMessage: String? = null,
)

object AuthInputValidator {
    const val MIN_PASSWORD_LENGTH = 8
    private val EMAIL_REGEX = Regex(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$",
    )

    fun normalizeEmail(raw: String): String = raw.trim().lowercase()

    fun validateEmail(raw: String): String? {
        val normalized = normalizeEmail(raw)
        if (normalized.isEmpty()) return "يرجى إدخال البريد الإلكتروني"
        if (normalized.length > 254 || !EMAIL_REGEX.matches(normalized)) {
            return "صيغة البريد الإلكتروني غير صحيحة"
        }
        return null
    }

    fun validatePasswordPolicy(password: String): PasswordValidationResult {
        val hasMinLength = password.length >= MIN_PASSWORD_LENGTH
        val hasLetter = password.any { it.isLetter() }
        val hasDigit = password.any { it.isDigit() }
        val hasNoSpaces = password.none { it.isWhitespace() }

        val error = when {
            password.isEmpty() -> "يرجى إدخال كلمة المرور"
            !hasNoSpaces -> "يجب ألا تحتوي كلمة المرور على مسافات"
            !hasMinLength -> "يجب أن تتكون كلمة المرور من $MIN_PASSWORD_LENGTH أحرف على الأقل"
            !hasLetter -> "يجب أن تحتوي كلمة المرور على حرف واحد على الأقل"
            !hasDigit -> "يجب أن تحتوي كلمة المرور على رقم واحد على الأقل"
            else -> null
        }

        return PasswordValidationResult(
            isValid = error == null,
            hasMinLength = hasMinLength,
            hasLetter = hasLetter,
            hasDigit = hasDigit,
            hasNoSpaces = hasNoSpaces,
            errorMessage = error,
        )
    }

    fun validateSignInInputs(email: String, password: String): String? {
        validateEmail(email)?.let { return it }
        if (password.isEmpty()) return "يرجى إدخال كلمة المرور"
        return null
    }

    fun validateRegistrationInputs(
        displayName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ): String? {
        if (displayName.trim().length < 2) {
            return "يرجى إدخال الاسم الكامل (حرفان على الأقل)"
        }
        validateEmail(email)?.let { return it }
        validatePasswordPolicy(password).errorMessage?.let { return it }
        if (password != confirmPassword) {
            return "كلمتا المرور غير متطابقتين"
        }
        return null
    }
}
