package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "AppSettings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val appName: String = "مدير التقارير",
    val developerName: String = "المهندس علي توحيد",
    val developerPhone: String = "+966573928022",
    val companyName: String = "مؤسسة الأعمال التجارية",
    val companyAddress: String = "المملكة العربية السعودية",
    val companyPhone: String = "",
    val companyLogoPath: String = "",
    val headerDefaultText: String = "تقرير تجاري معتمد",
    val fontFamilyKey: String = "CAIRO",
    val accentColorHex: String = "#0D9488",
    val defaultCurrency: String = "ر.س",
    val defaultPaperSize: String = "A4",
    val defaultOrientation: String = "PORTRAIT",
    val defaultMarginMm: Float = 10f,
    val defaultBarcodeType: String = "CODE_128",
    val barcodeWidthPt: Float = 100f,
    val barcodeHeightPt: Float = 34f,
    val barcodeFontSizePt: Float = 8f,
    val barcodeQuietZoneModules: Int = 8,
    val barcodeDpi: Int = 300,
    val cameraFlashDefault: Boolean = false,
    val cameraContinuousScan: Boolean = true,
    val scanBeepEnabled: Boolean = true,
    val scanVibrateEnabled: Boolean = true,
    val autoSaveEnabled: Boolean = true,
    val themeMode: String = "SYSTEM",
    val exportFilePrefix: String = "تقرير",
    val productPickerViewMode: String = "LIST",
    val scannerEnabledFormats: String = "",
    val inventoryConfigJson: String = "",
    val productsNumericConfigJson: String = "",
    val backendServiceUrl: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
)
