package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ErrorLogs",
    indices = [
        Index(value = ["fingerprint"]),
        Index(value = ["severity"]),
        Index(value = ["lastSeenAt"]),
        Index(value = ["isReviewed"]),
    ],
)
data class ErrorLogEntity(
    @PrimaryKey val errorId: String,
    val timestamp: Long,
    val screenName: String,
    val moduleName: String,
    val operationName: String,
    val errorType: String,
    val originalMessage: String,
    val stackTrace: String,
    val sourceFile: String,
    val lineNumber: Int,
    val functionName: String,
    val appStateSummary: String,
    val wasHandled: Boolean,
    val severity: String,
    val fingerprint: String,
    val occurrenceCount: Int,
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    val isReviewed: Boolean,
    val linkedOperationId: String,
    val failedStage: String = "",
    val deviceSummary: String = "",
    val appVersionSummary: String = "",
    val isCrash: Boolean,
)
