package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.AppSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SettingsDao {
    @Query("SELECT * FROM AppSettings WHERE id = 1 LIMIT 1")
    fun observeSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM AppSettings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsOnce(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettingsEntity)

    @Query("UPDATE AppSettings SET inventoryConfigJson = :json, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateInventoryConfigJson(json: String, updatedAt: Long)

    @Query("UPDATE AppSettings SET productsNumericConfigJson = :json, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateProductsNumericConfigJson(json: String, updatedAt: Long)

    @Query("UPDATE AppSettings SET defaultBarcodeType = :defaultBarcodeType, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateDefaultBarcodeType(defaultBarcodeType: String, updatedAt: Long)
}
