package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "PDFPages",
    foreignKeys = [
        ForeignKey(
            entity = PdfDocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["documentId"])],
)
data class PdfPageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val documentId: Long,
    val sourcePdfPath: String = "",
    val sourcePageIndex: Int = 0,
    val sortOrder: Int = 0,
    val rotationDegrees: Int = 0,
    val cropLeftFraction: Float = 0f,
    val cropTopFraction: Float = 0f,
    val cropRightFraction: Float = 1f,
    val cropBottomFraction: Float = 1f,
    val isBlankPage: Boolean = false,
    val blankWidthPt: Float = 595f,
    val blankHeightPt: Float = 842f,
    val extractedText: String = "",
    val thumbnailPath: String = "",
)
