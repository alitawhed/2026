package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.PdfDocumentEntity
import com.example.data.local.entity.PdfDocumentWithPages
import com.example.data.local.entity.PdfPageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PdfDocumentDao {
    @Transaction
    @Query("SELECT * FROM PDFDocuments ORDER BY updatedAt DESC")
    fun observeAllDocuments(): Flow<List<PdfDocumentWithPages>>

    @Transaction
    @Query("SELECT * FROM PDFDocuments WHERE id = :id")
    fun observeDocument(id: Long): Flow<PdfDocumentWithPages?>

    @Transaction
    @Query("SELECT * FROM PDFDocuments WHERE id = :id")
    suspend fun getDocumentOnce(id: Long): PdfDocumentWithPages?

    @Transaction
    @Query("SELECT * FROM PDFDocuments ORDER BY updatedAt DESC")
    suspend fun getAllDocumentsOnce(): List<PdfDocumentWithPages>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: PdfDocumentEntity): Long

    @Update
    suspend fun updateDocument(doc: PdfDocumentEntity)

    @Query("DELETE FROM PDFDocuments WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<PdfPageEntity>): List<Long>

    @Query("DELETE FROM PDFPages WHERE documentId = :documentId")
    suspend fun deletePagesForDocument(documentId: Long)

    @Query("DELETE FROM PDFDocuments")
    suspend fun deleteAllDocuments()
}
