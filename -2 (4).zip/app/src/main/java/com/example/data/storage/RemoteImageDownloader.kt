package com.example.data.storage

import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL
import java.net.UnknownHostException
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.net.ssl.SSLException

data class RemoteHttpResponse(
    val statusCode: Int,
    val contentType: String?,
    val contentLength: Long,
    val bytes: ByteArray,
    val finalUrl: String,
    val retryAfterSeconds: Long? = null,
    val authChallenge: String? = null,
    val redirectCount: Int = 0,
)

/**
 * Credentials scope for official authorized source APIs ONLY.
 * Strictly enforced to HTTPS on [allowedHost] and never forwarded on cross-host redirects.
 */
data class AuthorizedApiHeader(
    val allowedHost: String,
    val headerName: String,
    val headerValue: String,
)

fun interface RemoteImageTransport {
    suspend fun fetch(
        url: String,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        maxBytes: Long,
    ): RemoteHttpResponse
}

enum class RemoteImageFailureKind(val arabicLabel: String) {
    INVALID_URL("رابط غير صالح"),
    BLOCKED_NETWORK("رابط محظور لأسباب أمنية"),
    TIMEOUT("انتهاء مهلة الاتصال"),
    NETWORK_ERROR("خطأ في الاتصال بالشبكة"),
    HTTP_FORBIDDEN("HTTP 403: رفض الوصول"),
    HTTP_UNAUTHORIZED("رابط يحتاج إلى صلاحيات أو جلسة دخول"),
    HTTP_NOT_FOUND("HTTP 404: الصورة غير موجودة"),
    HTTP_RATE_LIMITED("HTTP 429: تجاوز حد الطلبات"),
    HTTP_SERVER_ERROR("HTTP 5xx: خطأ من الخادم"),
    HTTP_ERROR("خطأ استجابة من الخادم"),
    FILE_TOO_LARGE("حجم الصورة يتجاوز الحد المسموح"),
    UNSUPPORTED_FORMAT("صيغة صورة أو ملف غير مدعومة"),
    CORRUPT_OR_NOT_IMAGE("ملف تالف أو ليس صورة حقيقية"),
    STORAGE_ERROR("تعذر حفظ الصورة في التخزين"),
}

sealed interface RemoteImageDownloadResult {
    data class Success(
        val storedFiles: StoredImageFiles,
        val normalizedUrl: String,
        val detectedExtension: String,
        val contentHash: String,
        val fileSizeBytes: Long,
        val width: Int,
        val height: Int,
        val finalUrl: String = normalizedUrl,
        val httpStatusCode: Int = 200,
        val diagnosticLog: String = "",
    ) : RemoteImageDownloadResult

    data class Failure(
        val normalizedUrl: String,
        val reason: String,
        val kind: RemoteImageFailureKind,
        val httpStatusCode: Int = 0,
        val finalUrl: String = normalizedUrl,
        val diagnosticLog: String = "",
    ) : RemoteImageDownloadResult
}

sealed interface RemoteImageBytesResult {
    data class Success(
        val bytes: ByteArray,
        val normalizedUrl: String,
        val detectedExtension: String,
        val contentHash: String,
        val width: Int,
        val height: Int,
        val finalUrl: String = normalizedUrl,
        val httpStatusCode: Int = 200,
        val diagnosticLog: String = "",
    ) : RemoteImageBytesResult

    data class Failure(
        val normalizedUrl: String,
        val reason: String,
        val kind: RemoteImageFailureKind,
        val httpStatusCode: Int = 0,
        val finalUrl: String = normalizedUrl,
        val diagnosticLog: String = "",
    ) : RemoteImageBytesResult
}

data class ValidatedUrlResult(
    val isValid: Boolean,
    val normalizedUrl: String,
    val errorReason: String? = null,
    val failureKind: RemoteImageFailureKind? = null,
)

class HttpUrlRemoteImageTransport(
    private val hostAddressResolver: (String) -> Array<InetAddress> = { host ->
        InetAddress.getAllByName(host)
    },
    private val authorizedApiHeader: AuthorizedApiHeader? = null,
    private val acceptHeader: String = DEFAULT_IMAGE_ACCEPT_HEADER,
) : RemoteImageTransport {

    override suspend fun fetch(
        url: String,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        maxBytes: Long,
    ): RemoteHttpResponse = withContext(Dispatchers.IO) {
        var currentUrl = url
        var redirects = 0
        while (true) {
            val uri = URI(currentUrl)
            val scheme = uri.scheme?.lowercase() ?: ""
            if (scheme != "http" && scheme != "https") {
                throw SecurityUrlException("يُسمح فقط بروابط HTTP أو HTTPS")
            }
            val host = uri.host ?: throw SecurityUrlException("رابط الصورة لا يحتوي على اسم نطاق صالح")
            RemoteImageUrlValidator.verifyHostSafe(host, hostAddressResolver)

            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                requestMethod = "GET"
                connectTimeout = connectTimeoutMs
                readTimeout = readTimeoutMs
                setRequestProperty("Accept", acceptHeader)
                setRequestProperty("Accept-Language", "ar,en-US;q=0.9,en;q=0.8")
                setRequestProperty("User-Agent", DEFAULT_BROWSER_USER_AGENT)
                // Only attach authorized API header on matching HTTPS host; never send credentials over HTTP or third-party hosts
                val apiAuth = authorizedApiHeader
                if (apiAuth != null &&
                    scheme == "https" &&
                    host.equals(apiAuth.allowedHost, ignoreCase = true) &&
                    apiAuth.headerName.isNotBlank() &&
                    apiAuth.headerValue.isNotBlank()
                ) {
                    setRequestProperty(apiAuth.headerName.trim(), apiAuth.headerValue)
                }
            }

            try {
                conn.connect()
                val code = conn.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    redirects++
                    if (redirects > MAX_REDIRECTS) {
                        throw IOException("تم تجاوز الحد الأقصى لعمليات إعادة التوجيه ($MAX_REDIRECTS)")
                    }
                    val rawLocation = conn.getHeaderField("Location")?.trim()
                        ?: throw IOException("إعادة توجيه بدون عنوان وجهة")
                    val encodedLocation = RemoteImageUrlValidator.encodeSpacesAndUnsafeChars(rawLocation)
                    val resolved = uri.resolve(encodedLocation)
                    val targetScheme = resolved.scheme?.lowercase().orEmpty()
                    if (targetScheme !in setOf("http", "https")) {
                        throw SecurityUrlException("إعادة التوجيه تستخدم بروتوكولاً غير مدعوم")
                    }
                    if (scheme == "https" && targetScheme == "http") {
                        throw SecurityUrlException("تم رفض التحويل من اتصال آمن HTTPS إلى HTTP غير مشفر")
                    }
                    if (!resolved.rawUserInfo.isNullOrEmpty()) {
                        throw SecurityUrlException("إعادة التوجيه تحتوي على بيانات مصادقة غير مسموحة")
                    }
                    currentUrl = resolved.toString()
                    continue
                }

                val contentType = conn.contentType
                val retryAfter = conn.getHeaderField("Retry-After")?.trim()?.toLongOrNull()
                val authChallenge = conn.getHeaderField("WWW-Authenticate")?.trim()
                val contentLength = conn.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
                if (contentLength > maxBytes) {
                    throw PayloadTooLargeException(contentLength, maxBytes)
                }

                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val bytes = if (stream != null) {
                    if (code in 200..299) {
                        readBoundedBytes(stream, maxBytes)
                    } else {
                        // Read at most 8KB of error body safely for diagnostics (never execute or store)
                        readBoundedBytesUpTo(stream, 8 * 1024L)
                    }
                } else {
                    ByteArray(0)
                }

                return@withContext RemoteHttpResponse(
                    statusCode = code,
                    contentType = contentType,
                    contentLength = if (contentLength >= 0) contentLength else bytes.size.toLong(),
                    bytes = bytes,
                    finalUrl = currentUrl,
                    retryAfterSeconds = retryAfter,
                    authChallenge = authChallenge,
                    redirectCount = redirects,
                )
            } finally {
                conn.disconnect()
            }
        }
        @Suppress("UNREACHABLE_CODE")
        throw IOException("فشل الاتصال")
    }

    private fun readBoundedBytes(stream: java.io.InputStream, maxBytes: Long): ByteArray {
        stream.use { input ->
            val buffer = ByteArray(16 * 1024)
            val out = ByteArrayOutputStream()
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > maxBytes) {
                    throw PayloadTooLargeException(total, maxBytes)
                }
                out.write(buffer, 0, read)
            }
            return out.toByteArray()
        }
    }

    private fun readBoundedBytesUpTo(stream: java.io.InputStream, capBytes: Long): ByteArray {
        return try {
            stream.use { input ->
                val buffer = ByteArray(2048)
                val out = ByteArrayOutputStream()
                var total = 0L
                while (total < capBytes) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    val toWrite = minOf(read.toLong(), capBytes - total).toInt()
                    out.write(buffer, 0, toWrite)
                    total += toWrite
                }
                out.toByteArray()
            }
        } catch (_: Exception) {
            ByteArray(0)
        }
    }

    companion object {
        private const val MAX_REDIRECTS = 5
        const val DEFAULT_BROWSER_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        const val DEFAULT_IMAGE_ACCEPT_HEADER =
            "image/avif,image/webp,image/apng,image/png,image/jpeg,image/gif,image/bmp,image/*;q=0.8,*/*;q=0.5"
    }
}

class SecurityUrlException(message: String) : IOException(message)
class PayloadTooLargeException(val actualBytes: Long, val limitBytes: Long) :
    IOException("حجم الصورة يتجاوز الحد الأقصى المسموح (${limitBytes / (1024 * 1024)} ميجابايت)")

object RemoteImageUrlValidator {

    private val BLOCKED_HOSTNAMES = setOf(
        "localhost",
        "localhost.localdomain",
        "ip6-localhost",
        "ip6-loopback",
        "metadata.google.internal",
        "metadata",
    )

    internal fun encodeSpacesAndUnsafeChars(url: String): String {
        val unescaped = url.trim().replace("&amp;", "&")
        return unescaped.replace(" ", "%20")
    }

    fun validateSyntax(rawUrl: String): ValidatedUrlResult {
        val cleaned = encodeSpacesAndUnsafeChars(rawUrl)
        if (cleaned.isEmpty()) {
            return ValidatedUrlResult(false, "", "رابط الصورة فارغ", RemoteImageFailureKind.INVALID_URL)
        }
        val lower = cleaned.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            return ValidatedUrlResult(
                false,
                cleaned,
                "صيغة الرابط غير صالحة — يجب أن يبدأ بـ https:// أو http://",
                RemoteImageFailureKind.INVALID_URL,
            )
        }
        val parsed = try {
            URI(cleaned)
        } catch (_: Exception) {
            return ValidatedUrlResult(false, cleaned, "رابط الصورة يحتوي على صيغة غير صالحة", RemoteImageFailureKind.INVALID_URL)
        }
        if (!parsed.rawUserInfo.isNullOrEmpty()) {
            return ValidatedUrlResult(
                false,
                cleaned,
                "رابط الصورة يحتوي على بيانات مصادقة مضمنة غير مسموح بها",
                RemoteImageFailureKind.INVALID_URL,
            )
        }
        val host = parsed.host?.trim()?.lowercase().orEmpty()
        if (host.isEmpty()) {
            return ValidatedUrlResult(false, cleaned, "رابط الصورة لا يحتوي على عنوان موقع صالح", RemoteImageFailureKind.INVALID_URL)
        }
        if (host in BLOCKED_HOSTNAMES || host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".localhost")) {
            return ValidatedUrlResult(
                false,
                cleaned,
                "تم حظر الرابط لأنه يشير إلى عنوان شبكة محلي أو داخلي",
                RemoteImageFailureKind.BLOCKED_NETWORK,
            )
        }
        if (isLiteralPrivateIp(host)) {
            return ValidatedUrlResult(
                false,
                cleaned,
                "تم حظر الرابط لأنه يشير إلى عنوان IP خاص أو محلي",
                RemoteImageFailureKind.BLOCKED_NETWORK,
            )
        }
        return ValidatedUrlResult(true, parsed.toString())
    }

    fun verifyHostSafe(
        host: String,
        resolver: (String) -> Array<InetAddress> = { InetAddress.getAllByName(it) },
    ) {
        val cleanHost = host.trim().lowercase().removePrefix("[").removeSuffix("]")
        if (cleanHost in BLOCKED_HOSTNAMES ||
            cleanHost.endsWith(".local") ||
            cleanHost.endsWith(".internal") ||
            cleanHost.endsWith(".localhost")
        ) {
            throw SecurityUrlException("تم حظر الرابط لأنه يشير إلى عنوان شبكة محلي أو داخلي")
        }
        val addresses = try {
            resolver(cleanHost)
        } catch (e: UnknownHostException) {
            throw e
        }
        if (addresses.isEmpty()) {
            throw UnknownHostException(cleanHost)
        }
        for (addr in addresses) {
            if (isDisallowedAddress(addr)) {
                throw SecurityUrlException("تم رفض الاتصال بعنوان شبكة محلي أو خاص غير آمن")
            }
        }
    }

    private fun isLiteralPrivateIp(rawHost: String): Boolean {
        val host = rawHost.removePrefix("[").removeSuffix("]")
        val isDottedIpv4 = Regex("""^\d{1,3}(\.\d{1,3}){3}$""").matches(host)
        val isIpv6Literal = host.contains(':')
        if (isDottedIpv4 || isIpv6Literal) {
            return try {
                val addr = InetAddress.getByName(host)
                isDisallowedAddress(addr)
            } catch (_: Exception) {
                false
            }
        }
        val isNumericOrObfuscatedIpv4 = Regex("""^(0x[0-9a-f]+|\d+)$""").matches(host) ||
            Regex("""^(0x[0-9a-f]+|0\d+|\d+)(\.(0x[0-9a-f]+|0\d+|\d+)){1,2}$""").matches(host) ||
            (host.split('.').size == 4 && host.split('.').all { seg -> seg.startsWith("0x", true) || (seg.length > 1 && seg.startsWith("0")) })
        return isNumericOrObfuscatedIpv4
    }

    fun isDisallowedAddress(addr: InetAddress): Boolean {
        if (addr.isAnyLocalAddress ||
            addr.isLoopbackAddress ||
            addr.isLinkLocalAddress ||
            addr.isSiteLocalAddress ||
            addr.isMulticastAddress
        ) {
            return true
        }
        val bytes = addr.address
        return when (addr) {
            is Inet4Address -> isDisallowedIpv4(bytes)
            is Inet6Address -> isDisallowedIpv6(bytes)
            else -> true
        }
    }

    private fun isDisallowedIpv4(b: ByteArray): Boolean {
        if (b.size != 4) return true
        val o0 = b[0].toInt() and 0xFF
        val o1 = b[1].toInt() and 0xFF
        return when {
            o0 == 0 -> true
            o0 == 10 -> true
            o0 == 127 -> true
            o0 == 169 && o1 == 254 -> true
            o0 == 172 && o1 in 16..31 -> true
            o0 == 192 && o1 == 168 -> true
            o0 == 100 && o1 in 64..127 -> true
            o0 >= 224 -> true
            else -> false
        }
    }

    private fun isDisallowedIpv6(b: ByteArray): Boolean {
        if (b.size != 16) return true
        val allZeroExceptLast = (0..14).all { b[it].toInt() == 0 }
        if (allZeroExceptLast && (b[15].toInt() == 0 || b[15].toInt() == 1)) return true
        val first = b[0].toInt() and 0xFF
        val second = b[1].toInt() and 0xFF
        if ((first and 0xFE) == 0xFC) return true
        if (first == 0xFE && (second and 0xC0) == 0x80) return true
        if (first == 0xFF) return true
        val isV4Mapped = (0..9).all { b[it].toInt() == 0 } &&
            (b[10].toInt() and 0xFF) == 0xFF &&
            (b[11].toInt() and 0xFF) == 0xFF
        if (isV4Mapped) {
            return isDisallowedIpv4(byteArrayOf(b[12], b[13], b[14], b[15]))
        }
        return false
    }
}

class RemoteImageDownloader(
    private val mediaStorage: MediaStorageManager,
    private val transport: RemoteImageTransport = HttpUrlRemoteImageTransport(),
    private val maxFileBytes: Long = DEFAULT_MAX_FILE_BYTES,
    private val connectTimeoutMs: Int = DEFAULT_CONNECT_TIMEOUT_MS,
    private val readTimeoutMs: Int = DEFAULT_READ_TIMEOUT_MS,
    private val maxTransientRetries: Int = DEFAULT_MAX_TRANSIENT_RETRIES,
    private val retryDelayProvider: suspend (Long) -> Unit = { ms -> delay(ms) },
) {

    suspend fun downloadAndVerifyBytes(rawUrl: String): RemoteImageBytesResult = withContext(Dispatchers.IO) {
        val validation = RemoteImageUrlValidator.validateSyntax(rawUrl)
        if (!validation.isValid) {
            return@withContext RemoteImageBytesResult.Failure(
                normalizedUrl = validation.normalizedUrl,
                reason = validation.errorReason ?: "رابط الصورة غير صالح",
                kind = validation.failureKind ?: RemoteImageFailureKind.INVALID_URL,
                diagnosticLog = "Syntax validation failed: ${validation.errorReason}",
            )
        }
        val normalized = validation.normalizedUrl
        val logs = mutableListOf<String>()

        var lastFailure: RemoteImageBytesResult.Failure? = null
        val totalAttempts = (maxTransientRetries.coerceIn(0, 4)) + 1

        for (attempt in 1..totalAttempts) {
            val stepOutcome = attemptSingleFetchAndValidate(normalized, logs)
            when (stepOutcome) {
                is AttemptOutcome.Succeeded -> {
                    return@withContext stepOutcome.result.copy(
                        diagnosticLog = logs.joinToString(" | "),
                    )
                }
                is AttemptOutcome.Failed -> {
                    lastFailure = stepOutcome.failure
                    if (!stepOutcome.isTransient || attempt >= totalAttempts) {
                        return@withContext stepOutcome.failure.copy(
                            diagnosticLog = logs.joinToString(" | "),
                        )
                    }
                    val waitMs = stepOutcome.suggestedDelayMs.coerceIn(0L, MAX_BACKOFF_MS)
                    if (waitMs > 0L) {
                        logs.add("إعادة المحاولة #$attempt بعد ${waitMs}ms")
                        retryDelayProvider(waitMs)
                    } else {
                        logs.add("إعادة المحاولة #$attempt")
                    }
                }
            }
        }

        lastFailure ?: RemoteImageBytesResult.Failure(
            normalizedUrl = normalized,
            reason = "تعذر تنزيل الصورة",
            kind = RemoteImageFailureKind.NETWORK_ERROR,
            diagnosticLog = logs.joinToString(" | "),
        )
    }

    private sealed interface AttemptOutcome {
        data class Succeeded(val result: RemoteImageBytesResult.Success) : AttemptOutcome
        data class Failed(
            val failure: RemoteImageBytesResult.Failure,
            val isTransient: Boolean,
            val suggestedDelayMs: Long = 0L,
        ) : AttemptOutcome
    }

    private suspend fun attemptSingleFetchAndValidate(
        normalized: String,
        logs: MutableList<String>,
    ): AttemptOutcome {
        val response = try {
            transport.fetch(normalized, connectTimeoutMs, readTimeoutMs, maxFileBytes)
        } catch (e: SecurityUrlException) {
            val msg = e.message ?: "الرابط محظور لأسباب أمنية"
            logs.add("SecurityBlock: $msg")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(normalized, msg, RemoteImageFailureKind.BLOCKED_NETWORK),
                isTransient = false,
            )
        } catch (e: PayloadTooLargeException) {
            val msg = "حجم ملف الصورة يتجاوز الحد المسموح (${maxFileBytes / (1024 * 1024)} ميجابايت)"
            logs.add("TooLarge: ${e.actualBytes} bytes > ${e.limitBytes}")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(normalized, msg, RemoteImageFailureKind.FILE_TOO_LARGE),
                isTransient = false,
            )
        } catch (_: SocketTimeoutException) {
            logs.add("Timeout (${readTimeoutMs}ms)")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalized,
                    "انتهت مهلة الاتصال بالخادم أثناء تنزيل الصورة",
                    RemoteImageFailureKind.TIMEOUT,
                ),
                isTransient = true,
                suggestedDelayMs = 600L,
            )
        } catch (_: UnknownHostException) {
            logs.add("UnknownHost")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalized,
                    "تعذر العثور على الخادم (تحقق من الرابط واتصال الإنترنت)",
                    RemoteImageFailureKind.NETWORK_ERROR,
                ),
                isTransient = false,
            )
        } catch (e: SSLException) {
            logs.add("SSLException: ${e.javaClass.simpleName}")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalized,
                    "فشل التحقق من شهادة الأمان SSL للرابط",
                    RemoteImageFailureKind.NETWORK_ERROR,
                ),
                isTransient = false,
            )
        } catch (e: IOException) {
            val msg = e.message?.takeIf { it.isNotBlank() } ?: "فشل الاتصال بالخادم"
            logs.add("IOException: $msg")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(normalized, msg, RemoteImageFailureKind.NETWORK_ERROR),
                isTransient = true,
                suggestedDelayMs = 600L,
            )
        } catch (e: Exception) {
            val msg = e.message?.takeIf { it.isNotBlank() } ?: "فشل غير متوقع أثناء الاتصال"
            logs.add("Exception: ${e.javaClass.simpleName}: $msg")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(normalized, msg, RemoteImageFailureKind.NETWORK_ERROR),
                isTransient = false,
            )
        }

        val finalValidation = RemoteImageUrlValidator.validateSyntax(response.finalUrl)
        if (!finalValidation.isValid) {
            val reason = finalValidation.errorReason ?: "وجهة إعادة التوجيه غير مسموحة"
            logs.add("FinalUrlBlocked: ${response.finalUrl}")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = reason,
                    kind = finalValidation.failureKind ?: RemoteImageFailureKind.BLOCKED_NETWORK,
                    httpStatusCode = response.statusCode,
                    finalUrl = response.finalUrl,
                ),
                isTransient = false,
            )
        }

        val initialScheme = try { URI(normalized).scheme?.lowercase() } catch (_: Exception) { null }
        val finalScheme = try { URI(finalValidation.normalizedUrl).scheme?.lowercase() } catch (_: Exception) { null }
        if (initialScheme == "https" && finalScheme == "http") {
            logs.add("HTTPS->HTTP downgrade blocked (${response.finalUrl})")
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = "تم رفض التحويل من اتصال آمن HTTPS إلى HTTP غير مشفر",
                    kind = RemoteImageFailureKind.BLOCKED_NETWORK,
                    httpStatusCode = response.statusCode,
                    finalUrl = response.finalUrl,
                ),
                isTransient = false,
            )
        }

        val finalHost = try { URI(finalValidation.normalizedUrl).host.orEmpty() } catch (_: Exception) { "" }
        logs.add("HTTP ${response.statusCode} CT=${response.contentType ?: "none"} bytes=${response.bytes.size} redir=${response.redirectCount}")

        when (response.statusCode) {
            403 -> {
                val hint = if (response.authChallenge != null) " (يتطلب توثيقاً)" else ""
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "رفض الخادم الوصول إلى الصورة (HTTP 403 Forbidden)$hint — قد يمنع الموقع التنزيل التلقائي؛ استخدم الرفع اليدوي أو المجلد المحلي أو API رسمي.",
                        kind = RemoteImageFailureKind.HTTP_FORBIDDEN,
                        httpStatusCode = 403,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = false,
                )
            }
            401, 407 -> {
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "الرابط يتطلب صلاحيات أو جلسة تسجيل دخول مصرح بها (HTTP ${response.statusCode})",
                        kind = RemoteImageFailureKind.HTTP_UNAUTHORIZED,
                        httpStatusCode = response.statusCode,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = false,
                )
            }
            404, 410 -> {
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "الصورة غير موجودة أو انتهت صلاحية الرابط على الخادم (HTTP ${response.statusCode})",
                        kind = RemoteImageFailureKind.HTTP_NOT_FOUND,
                        httpStatusCode = response.statusCode,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = false,
                )
            }
            429 -> {
                val backoffMs = ((response.retryAfterSeconds ?: 2L).coerceIn(1L, 5L)) * 1000L
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "تجاوز حد الطلبات المسموح على الخادم ($finalHost) — (HTTP 429)",
                        kind = RemoteImageFailureKind.HTTP_RATE_LIMITED,
                        httpStatusCode = 429,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = true,
                    suggestedDelayMs = backoffMs,
                )
            }
            in 500..599 -> {
                val backoffMs = ((response.retryAfterSeconds ?: 1L).coerceIn(1L, 4L)) * 800L
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "خطأ مؤقت من الخادم المستضيف للصورة (HTTP ${response.statusCode})",
                        kind = RemoteImageFailureKind.HTTP_SERVER_ERROR,
                        httpStatusCode = response.statusCode,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = true,
                    suggestedDelayMs = backoffMs,
                )
            }
            !in 200..299 -> {
                return AttemptOutcome.Failed(
                    RemoteImageBytesResult.Failure(
                        normalizedUrl = normalized,
                        reason = "فشل تنزيل الصورة من الخادم (HTTP ${response.statusCode})",
                        kind = RemoteImageFailureKind.HTTP_ERROR,
                        httpStatusCode = response.statusCode,
                        finalUrl = finalValidation.normalizedUrl,
                    ),
                    isTransient = false,
                )
            }
        }

        if (response.bytes.isEmpty()) {
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = "الرابط أعاد ملفاً فارغاً بدون بيانات صورة",
                    kind = RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }
        if (response.bytes.size.toLong() > maxFileBytes) {
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = "حجم ملف الصورة يتجاوز الحد المسموح (${maxFileBytes / (1024 * 1024)} ميجابايت)",
                    kind = RemoteImageFailureKind.FILE_TOO_LARGE,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        val mime = response.contentType?.substringBefore(';')?.trim()?.lowercase().orEmpty()
        // Inspect real magic bytes regardless of URL extension!
        val nonImageKind = detectNonImagePayload(response.bytes, mime, finalValidation.normalizedUrl)
        if (nonImageKind != null) {
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = nonImageKind.second,
                    kind = nonImageKind.first,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        if (mime.isNotBlank() && isRejectedContentType(mime)) {
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = "النوع المُرجَع من الخادم غير مدعوم كصورة ($mime)",
                    kind = RemoteImageFailureKind.UNSUPPORTED_FORMAT,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        val ext = detectRasterImageFormat(response.bytes)
        if (ext == null) {
            val isUnsupportedImageMime = mime.startsWith("image/") && mime !in setOf(
                "image/jpeg", "image/jpg", "image/png", "image/webp",
                "image/gif", "image/bmp", "image/x-ms-bmp", "image/avif",
            )
            val kind = if (isUnsupportedImageMime) {
                RemoteImageFailureKind.UNSUPPORTED_FORMAT
            } else {
                RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE
            }
            val reason = if (isUnsupportedImageMime) {
                "صيغة الصورة غير مدعومة ($mime) — المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF"
            } else {
                "الملف تالف أو ليس صورة حقيقية قابلة للفتح (المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF)"
            }
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = reason,
                    kind = kind,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        val decodedDims = verifyImageDecodableBounds(response.bytes, ext)
        if (decodedDims == null) {
            val isAvifPre31 = ext == "avif" && Build.VERSION.SDK_INT < Build.VERSION_CODES.S
            val kind = if (isAvifPre31) RemoteImageFailureKind.UNSUPPORTED_FORMAT else RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE
            val reason = if (isAvifPre31) {
                "صيغة AVIF تتطلب أندرويد 12 أو أحدث لفك ترميزها على الجهاز"
            } else {
                "ملف الصورة تالف أو مبتور ولا يمكن فتحه (الصيغة المكتشفة: ${ext.uppercase()})"
            }
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = reason,
                    kind = kind,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        val (width, height) = decodedDims
        val pixelCount = width.toLong() * height.toLong()
        if (width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION || pixelCount > MAX_IMAGE_PIXELS) {
            return AttemptOutcome.Failed(
                RemoteImageBytesResult.Failure(
                    normalizedUrl = normalized,
                    reason = "أبعاد الصورة ($width×$height) كبيرة جداً ولا يمكن معالجتها بأمان",
                    kind = RemoteImageFailureKind.FILE_TOO_LARGE,
                    httpStatusCode = response.statusCode,
                    finalUrl = finalValidation.normalizedUrl,
                ),
                isTransient = false,
            )
        }

        val hash = sha256Hex(response.bytes)
        logs.add("Verified=${ext.uppercase()} ${width}x${height}")
        return AttemptOutcome.Succeeded(
            RemoteImageBytesResult.Success(
                bytes = response.bytes,
                normalizedUrl = normalized,
                detectedExtension = ext,
                contentHash = hash,
                width = width,
                height = height,
                finalUrl = finalValidation.normalizedUrl,
                httpStatusCode = response.statusCode,
            ),
        )
    }

    private fun verifyImageDecodableBounds(bytes: ByteArray, ext: String): Pair<Int, Int>? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (_: Exception) {
            opts.outWidth = -1
        }
        if (opts.outWidth > 0 && opts.outHeight > 0) {
            // Also verify actual pixel decode succeeds (catches truncated/corrupt payloads whose header alone parses)
            val fullDecoded = try {
                var sample = 1
                while (opts.outWidth / sample > 2048 || opts.outHeight / sample > 2048) sample *= 2
                BitmapFactory.decodeByteArray(
                    bytes,
                    0,
                    bytes.size,
                    BitmapFactory.Options().apply { inSampleSize = sample },
                )
            } catch (_: Exception) {
                null
            }
            if (fullDecoded != null) {
                if (!fullDecoded.isRecycled) fullDecoded.recycle()
                return opts.outWidth to opts.outHeight
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && ext in setOf("avif", "webp", "gif", "png", "jpg", "bmp")) {
            return try {
                var w = 0
                var h = 0
                val src = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
                val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    w = info.size.width
                    h = info.size.height
                }
                if (!bmp.isRecycled) bmp.recycle()
                if (w > 0 && h > 0) w to h else null
            } catch (_: Exception) {
                null
            }
        }
        return null
    }

    private fun detectNonImagePayload(
        bytes: ByteArray,
        mime: String,
        finalUrl: String,
    ): Pair<RemoteImageFailureKind, String>? {
        val headText = try {
            bytes.copyOfRange(0, minOf(bytes.size, 1024))
                .toString(Charsets.UTF_8)
                .trimStart('\uFEFF', ' ', '\t', '\r', '\n')
                .lowercase()
        } catch (_: Exception) {
            ""
        }

        if (bytes.size >= 4 && bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() &&
            bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte()
        ) {
            return RemoteImageFailureKind.UNSUPPORTED_FORMAT to "الرابط يشير إلى ملف PDF وليس ملف صورة"
        }
        if (bytes.size >= 2 && bytes[0] == 0x4D.toByte() && bytes[1] == 0x5A.toByte()) {
            return RemoteImageFailureKind.UNSUPPORTED_FORMAT to "تم رفض الملف لأن محتواه تنفيذي وليس صورة صالحة"
        }
        if (bytes.size >= 4 && bytes[0] == 0x7F.toByte() && bytes[1] == 'E'.code.toByte() &&
            bytes[2] == 'L'.code.toByte() && bytes[3] == 'F'.code.toByte()
        ) {
            return RemoteImageFailureKind.UNSUPPORTED_FORMAT to "تم رفض الملف لأن محتواه تنفيذي وليس صورة صالحة"
        }
        if (mime.contains("svg") || headText.startsWith("<svg") || (headText.startsWith("<?xml") && headText.contains("<svg"))) {
            return RemoteImageFailureKind.UNSUPPORTED_FORMAT to "صيغة SVG غير مدعومة كصورة نقطية (المدعوم: JPG/PNG/WEBP/GIF/BMP/AVIF)"
        }
        val lowerFinal = finalUrl.lowercase()
        val isHtml = mime == "text/html" || mime == "application/xhtml+xml" ||
            headText.startsWith("<!doctype html") || headText.startsWith("<html")
        if (isHtml) {
            val isLoginRedirect = lowerFinal.contains("/login") ||
                lowerFinal.contains("/signin") ||
                lowerFinal.contains("/auth") ||
                lowerFinal.contains("/sso") ||
                headText.contains("type=\"password\"") ||
                headText.contains("name=\"password\"") ||
                headText.contains("تسجيل الدخول")
            return if (isLoginRedirect) {
                RemoteImageFailureKind.HTTP_UNAUTHORIZED to "الرابط يتطلب تسجيل دخول أو صلاحيات وصول (حوّل إلى صفحة تسجيل دخول)"
            } else {
                RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE to "الرابط أعاد صفحة ويب HTML بدلاً من صورة حقيقية"
            }
        }
        return null
    }

    suspend fun downloadAndSave(rawUrl: String): RemoteImageDownloadResult = withContext(Dispatchers.IO) {
        when (val res = downloadAndVerifyBytes(rawUrl)) {
            is RemoteImageBytesResult.Failure -> {
                RemoteImageDownloadResult.Failure(
                    normalizedUrl = res.normalizedUrl,
                    reason = res.reason,
                    kind = res.kind,
                    httpStatusCode = res.httpStatusCode,
                    finalUrl = res.finalUrl,
                    diagnosticLog = res.diagnosticLog,
                )
            }
            is RemoteImageBytesResult.Success -> {
                val stored = mediaStorage.saveDownloadedImageBytes(res.bytes, res.detectedExtension)
                val storedVerified = stored != null &&
                    File(stored.activePath).let { it.exists() && it.length() > 0L } &&
                    File(stored.thumbnailPath).let { it.exists() && it.length() > 0L }
                if (!storedVerified || stored == null) {
                    RemoteImageDownloadResult.Failure(
                        normalizedUrl = res.normalizedUrl,
                        reason = "تم تنزيل الصورة لكن تعذر التحقق من حفظها وفتحها داخل تخزين التطبيق",
                        kind = RemoteImageFailureKind.STORAGE_ERROR,
                        httpStatusCode = res.httpStatusCode,
                        finalUrl = res.finalUrl,
                        diagnosticLog = res.diagnosticLog,
                    )
                } else {
                    RemoteImageDownloadResult.Success(
                        storedFiles = stored,
                        normalizedUrl = res.normalizedUrl,
                        detectedExtension = res.detectedExtension,
                        contentHash = res.contentHash,
                        fileSizeBytes = res.bytes.size.toLong(),
                        width = res.width,
                        height = res.height,
                        finalUrl = res.finalUrl,
                        httpStatusCode = res.httpStatusCode,
                        diagnosticLog = res.diagnosticLog,
                    )
                }
            }
        }
    }

    companion object {
        const val DEFAULT_MAX_FILE_BYTES: Long = 20L * 1024L * 1024L
        const val DEFAULT_CONNECT_TIMEOUT_MS: Int = 12_000
        const val DEFAULT_READ_TIMEOUT_MS: Int = 22_000
        const val DEFAULT_MAX_TRANSIENT_RETRIES: Int = 2
        private const val MAX_BACKOFF_MS: Long = 5_000L
        private const val MAX_IMAGE_DIMENSION = 20_000
        private const val MAX_IMAGE_PIXELS = 100_000_000L

        fun sha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun detectRasterImageFormat(bytes: ByteArray): String? {
            if (bytes.size < 4) return null
            // PNG: 89 50 4E 47 0D 0A 1A 0A
            if (bytes.size >= 8 &&
                bytes[0] == 0x89.toByte() &&
                bytes[1] == 0x50.toByte() &&
                bytes[2] == 0x4E.toByte() &&
                bytes[3] == 0x47.toByte() &&
                bytes[4] == 0x0D.toByte() &&
                bytes[5] == 0x0A.toByte() &&
                bytes[6] == 0x1A.toByte() &&
                bytes[7] == 0x0A.toByte()
            ) {
                return "png"
            }
            // JPEG: FF D8 FF
            if (bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
                return "jpg"
            }
            // GIF87a / GIF89a
            if (bytes.size >= 6 &&
                bytes[0] == 'G'.code.toByte() &&
                bytes[1] == 'I'.code.toByte() &&
                bytes[2] == 'F'.code.toByte() &&
                bytes[3] == '8'.code.toByte() &&
                (bytes[4] == '7'.code.toByte() || bytes[4] == '9'.code.toByte()) &&
                bytes[5] == 'a'.code.toByte()
            ) {
                return "gif"
            }
            // WEBP: RIFF....WEBP
            if (bytes.size >= 12 &&
                bytes[0] == 'R'.code.toByte() &&
                bytes[1] == 'I'.code.toByte() &&
                bytes[2] == 'F'.code.toByte() &&
                bytes[3] == 'F'.code.toByte() &&
                bytes[8] == 'W'.code.toByte() &&
                bytes[9] == 'E'.code.toByte() &&
                bytes[10] == 'B'.code.toByte() &&
                bytes[11] == 'P'.code.toByte()
            ) {
                return "webp"
            }
            // BMP: 42 4D
            if (bytes[0] == 'B'.code.toByte() && bytes[1] == 'M'.code.toByte()) {
                return "bmp"
            }
            // AVIF: ISO BMFF ftyp box with major/compatible brand 'avif' or 'avis'
            if (bytes.size >= 12 &&
                bytes[4] == 'f'.code.toByte() &&
                bytes[5] == 't'.code.toByte() &&
                bytes[6] == 'y'.code.toByte() &&
                bytes[7] == 'p'.code.toByte()
            ) {
                val boxSize = ByteBuffer.wrap(bytes, 0, 4).int.let { sz ->
                    if (sz in 12..bytes.size) sz else minOf(bytes.size, 64)
                }
                val ftypSlice = try {
                    String(bytes, 8, (boxSize - 8).coerceAtMost(96), Charsets.US_ASCII).lowercase()
                } catch (_: Exception) {
                    ""
                }
                if (ftypSlice.contains("avif") || ftypSlice.contains("avis")) {
                    return "avif"
                }
            }
            return null
        }

        private fun isRejectedContentType(mime: String): Boolean {
            if (mime.startsWith("image/")) {
                return mime.contains("svg") || mime.contains("xml")
            }
            if (mime == "application/octet-stream" || mime == "binary/octet-stream") {
                return false
            }
            return true
        }
    }
}
