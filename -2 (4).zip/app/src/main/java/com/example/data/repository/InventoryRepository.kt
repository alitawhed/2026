package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.InventorySessionEntity
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.ProductWithDetails
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.InventoryItemStatus
import com.example.domain.model.InventorySessionStatus
import com.example.domain.model.SaveStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

enum class DuplicateCountAction {
    ADD_TO_EXISTING,
    REPLACE_EXISTING,
}

sealed class InventoryScanLookupResult {
    data class MatchedRegistered(
        val product: ProductWithDetails,
        val barcodeValue: String,
        val barcodeType: String,
        val unitType: String,
        val conversionFactor: Double,
        val isAlternativeBarcode: Boolean,
        val existingItemInSession: InventoryCountItemEntity? = null,
        val otherUnitsInSession: List<String> = emptyList(),
    ) : InventoryScanLookupResult()

    data class UnregisteredBarcode(
        val barcodeValue: String,
        val barcodeType: String,
        val existingUnregisteredItem: InventoryCountItemEntity? = null,
    ) : InventoryScanLookupResult()
}

class InventoryUnitConflictException(
    val existingUnit: String,
    val existingFactor: Double,
    val newUnit: String,
    val newFactor: Double,
) : Exception(
    "تعارض في وحدة العد لنفس الباركود: المسجل سابقاً ($existingUnit × $existingFactor) يختلف عن الحالي ($newUnit × $newFactor). استبدل السطر أو راجع الوحدة أولاً.",
)

/**
 * Pure Count-Sheet Inventory Repository ("كشف كميات فقط").
 * Strictly NEVER modifies Products.defaultQuantity or performs accounting/reconciliation entries.
 */
class InventoryRepository(
    private val db: AppDatabase,
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val barcodeService: com.example.domain.barcode.BarcodeService? = null,
) {
    private val inventoryDao = db.inventoryDao()
    private val productDao = db.productDao()
    private val settingsDao = db.settingsDao()

    private val _saveStatus = MutableStateFlow(SaveStatus.IDLE)
    val saveStatus: StateFlow<SaveStatus> = _saveStatus.asStateFlow()

    val allSessions: Flow<List<InventorySessionWithDetails>> =
        inventoryDao.observeAllSessionsWithDetails()

    fun observeSession(sessionId: Long): Flow<InventorySessionWithDetails?> =
        inventoryDao.observeSessionWithDetails(sessionId)

    suspend fun getSessionOnce(sessionId: Long): InventorySessionWithDetails? =
        inventoryDao.getSessionWithDetails(sessionId)

    suspend fun createSession(
        title: String,
        notes: String = "",
        sessionDate: Long = System.currentTimeMillis(),
    ): Result<Long> {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) {
            return Result.failure(IllegalArgumentException("يرجى إدخال اسم كشف الجرد"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "إنشاء جلسة جرد",
            initialStage = "تهيئة بيانات جلسة الجرد",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val now = System.currentTimeMillis()
            trace?.stage("حفظ جلسة الجرد في قاعدة البيانات", cleanTitle)
            val id = inventoryDao.insertSession(
                InventorySessionEntity(
                    title = cleanTitle,
                    sessionDate = sessionDate,
                    status = InventorySessionStatus.OPEN.name,
                    notes = notes.trim(),
                    createdAt = now,
                    updatedAt = now,
                ),
            )
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم إنشاء كشف الجرد #$id")
            Result.success(id)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "إنشاء جلسة جرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر إنشاء الجلسة", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun updateSessionDetails(
        sessionId: Long,
        title: String,
        notes: String,
    ): Result<Unit> {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) {
            return Result.failure(IllegalArgumentException("يرجى إدخال اسم كشف الجرد"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "تعديل تفاصيل جلسة الجرد",
            initialStage = "قراءة بيانات الجلسة الحالية",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val session = inventoryDao.getSessionWithDetails(sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                trace?.stage("تحديث سجل الجلسة في قاعدة البيانات")
                inventoryDao.updateSession(
                    session.copy(
                        title = cleanTitle,
                        notes = notes.trim(),
                        updatedAt = System.currentTimeMillis(),
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم تحديث بيانات الجلسة #$sessionId")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "تعديل تفاصيل جلسة الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر التحديث", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun closeSession(sessionId: Long): Result<Unit> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "إغلاق جلسة الجرد",
            initialStage = "التحقق من الجلسة #$sessionId",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val session = inventoryDao.getSessionWithDetails(sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                val now = System.currentTimeMillis()
                trace?.stage("اعتماد الإغلاق في قاعدة البيانات")
                inventoryDao.updateSession(
                    session.copy(
                        status = InventorySessionStatus.CLOSED.name,
                        closedAt = now,
                        updatedAt = now,
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم إغلاق الجلسة #$sessionId")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "إغلاق جلسة الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر إغلاق الجلسة", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun reopenSession(sessionId: Long): Result<Unit> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "إعادة فتح جلسة الجرد",
            initialStage = "قراءة حالة الجلسة #$sessionId",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val session = inventoryDao.getSessionWithDetails(sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                val now = System.currentTimeMillis()
                trace?.stage("فتح الجلسة للتعديل")
                inventoryDao.updateSession(
                    session.copy(
                        status = InventorySessionStatus.OPEN.name,
                        closedAt = null,
                        updatedAt = now,
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تمت إعادة فتح الجلسة #$sessionId")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "إعادة فتح جلسة الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر إعادة فتح الجلسة", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun deleteSession(sessionId: Long): Result<Unit> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "حذف جلسة الجرد",
            initialStage = "حذف سجل الجلسة #$sessionId",
        )
        return try {
            inventoryDao.deleteSessionById(sessionId)
            trace?.succeed("تم حذف الجلسة #$sessionId")
            Result.success(Unit)
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "حذف جلسة الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر الحذف", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun lookupBarcodeForSession(
        sessionId: Long,
        rawBarcode: String,
        fallbackBarcodeType: String? = null,
    ): InventoryScanLookupResult? {
        val code = rawBarcode.trim()
        if (code.isEmpty()) return null
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "مطابقة الباركود في الجرد",
            initialStage = "البحث عن الباركود في قاعدة المنتجات",
        )
        return try {
            val savedDefaultFormat = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                settingsDao.getSettingsOnce()?.defaultBarcodeType,
            ) ?: com.example.domain.model.BarcodeFormatType.CODE_128
            val resolvedFallbackType = fallbackBarcodeType?.takeIf { it.isNotBlank() }
                ?: com.example.domain.barcode.BarcodeEngine
                    .resolveCompatibleDefaultFormat(code, savedDefaultFormat)
                    .name

            val matchedBarcode = productDao.findBarcodeExact(code)
            val existingItem = inventoryDao.findItemBySessionAndBarcode(sessionId, code)
            if (matchedBarcode != null) {
                val product = productDao.getProductWithDetails(matchedBarcode.productId)
                if (product != null) {
                    val currentUnit = matchedBarcode.unitType.ifBlank { "حبة" }
                    val resolvedMatchedType = matchedBarcode.barcodeType.ifBlank { resolvedFallbackType }
                    val sessionItems = inventoryDao.getSessionWithDetails(sessionId)?.items.orEmpty()
                    val otherUnits = sessionItems
                        .filter {
                            it.productId == product.product.id &&
                                it.scannedBarcode != matchedBarcode.barcodeValue &&
                                it.unitType != currentUnit
                        }
                        .map { "${it.unitType} (${it.scannedBarcode})" }
                        .distinct()

                    trace?.succeed("تمت مطابقة المنتج: ${product.product.name}")
                    return InventoryScanLookupResult.MatchedRegistered(
                        product = product,
                        barcodeValue = matchedBarcode.barcodeValue,
                        barcodeType = resolvedMatchedType,
                        unitType = currentUnit,
                        conversionFactor = matchedBarcode.conversionFactor.takeIf { it > 0.0 } ?: 1.0,
                        isAlternativeBarcode = !matchedBarcode.isPrimary,
                        existingItemInSession = existingItem,
                        otherUnitsInSession = otherUnits,
                    )
                }
            }
            trace?.succeed("باركود غير مسجل ($code)")
            InventoryScanLookupResult.UnregisteredBarcode(
                barcodeValue = code,
                barcodeType = resolvedFallbackType,
                existingUnregisteredItem = existingItem,
            )
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.BARCODE_CAMERA,
                operationName = "مطابقة الباركود في الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل البحث عن الباركود", err?.errorId.orEmpty())
            throw e
        }
    }

    /**
     * Records a scanned registered item in the count sheet.
     * Strictly NEVER mutates Products.defaultQuantity.
     */
    suspend fun recordCountedItem(
        sessionId: Long,
        product: ProductWithDetails,
        scannedBarcode: String,
        barcodeType: String,
        unitType: String,
        conversionFactor: Double,
        quantity: Double,
        notes: String = "",
        duplicateAction: DuplicateCountAction = DuplicateCountAction.ADD_TO_EXISTING,
    ): Result<Long> {
        if (quantity < 0.0 || quantity.isNaN() || quantity.isInfinite()) {
            return Result.failure(IllegalArgumentException("الكمية المدخلة غير صالحة"))
        }
        if (conversionFactor <= 0.0) {
            return Result.failure(IllegalArgumentException("معامل التحويل يجب أن يكون أكبر من صفر"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "تسجيل عد منتج في الجرد",
            initialStage = "التحقق من حالة جلسة الجرد",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val savedId = db.withTransaction {
                val session = inventoryDao.getSessionWithDetails(sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                if (session.status != InventorySessionStatus.OPEN.name) {
                    throw IllegalStateException("الكشف مغلق ولا يقبل التعديل حالياً")
                }

                val now = System.currentTimeMillis()
                val cleanBarcode = scannedBarcode.trim()
                val existing = inventoryDao.findItemBySessionAndBarcode(sessionId, cleanBarcode)
                val resolvedUnit = unitType.trim().ifBlank { "حبة" }
                val primaryImage = (com.example.data.storage.ImageService.resolveProductImageStateless(
                    product.primaryImage,
                    preferThumbnail = true,
                ) as? com.example.data.storage.ImageResolution.Available)?.file?.absolutePath
                    ?: com.example.data.storage.ImageService.cleanPath(
                        product.primaryImage?.thumbnailPath?.takeIf { it.isNotBlank() }
                            ?: product.primaryImage?.filePath,
                    )

                val savedDefault = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                    settingsDao.getSettingsOnce()?.defaultBarcodeType,
                ) ?: com.example.domain.model.BarcodeFormatType.CODE_128
                val cleanBarcodeType = barcodeType.trim().ifBlank {
                    com.example.domain.barcode.BarcodeEngine
                        .resolveCompatibleDefaultFormat(cleanBarcode, savedDefault)
                        .name
                }
                trace?.stage("حفظ كمية العد في قاعدة البيانات", "${product.product.name} ($quantity)")
                val itemId = if (existing == null) {
                    val baseEquivalent = quantity * conversionFactor
                    inventoryDao.insertCountItem(
                        InventoryCountItemEntity(
                            sessionId = sessionId,
                            productId = product.product.id,
                            productInternalCode = product.product.internalCode,
                            productName = product.product.name,
                            productImagePath = primaryImage,
                            scannedBarcode = cleanBarcode,
                            barcodeType = cleanBarcodeType,
                            unitType = resolvedUnit,
                            conversionFactor = conversionFactor,
                            countedQty = quantity,
                            baseUnitEquivalentQty = baseEquivalent,
                            previousSystemQty = 0.0,
                            lastIncrementQty = quantity,
                            scanCount = 1,
                            notes = notes.trim(),
                            status = InventoryItemStatus.COUNTED.name,
                            scannedAt = now,
                            updatedAt = now,
                        ),
                    )
                } else {
                    if (duplicateAction == DuplicateCountAction.ADD_TO_EXISTING &&
                        (existing.unitType != resolvedUnit || abs(existing.conversionFactor - conversionFactor) > 0.0001)
                    ) {
                        throw InventoryUnitConflictException(
                            existingUnit = existing.unitType,
                            existingFactor = existing.conversionFactor,
                            newUnit = resolvedUnit,
                            newFactor = conversionFactor,
                        )
                    }
                    val finalQty = when (duplicateAction) {
                        DuplicateCountAction.ADD_TO_EXISTING -> existing.countedQty + quantity
                        DuplicateCountAction.REPLACE_EXISTING -> quantity
                    }
                    val baseEquivalent = finalQty * conversionFactor
                    inventoryDao.updateCountItem(
                        existing.copy(
                            productId = product.product.id,
                            productInternalCode = product.product.internalCode,
                            productName = product.product.name,
                            productImagePath = primaryImage,
                            barcodeType = cleanBarcodeType,
                            unitType = resolvedUnit,
                            conversionFactor = conversionFactor,
                            countedQty = finalQty,
                            baseUnitEquivalentQty = baseEquivalent,
                            lastIncrementQty = quantity,
                            scanCount = existing.scanCount + 1,
                            notes = notes.trim().ifBlank { existing.notes },
                            status = InventoryItemStatus.COUNTED.name,
                            updatedAt = now,
                        ),
                    )
                    existing.id
                }

                inventoryDao.updateSession(session.copy(updatedAt = now))
                Triple(itemId, cleanBarcode, cleanBarcodeType)
            }.let { (itemId, cleanBc, cleanBcType) ->
                com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(cleanBcType)?.let { fmt ->
                    barcodeService?.prewarmProductBarcodeImage(product.product.id, cleanBc, fmt)
                }
                itemId
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم حفظ البند #$savedId (الكمية: $quantity)")
            Result.success(savedId)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            if (e is InventoryUnitConflictException) {
                trace?.warn(e.message ?: "تعارض وحدة العد")
            } else {
                val err = errorMonitor?.recordError(
                    throwable = e,
                    screenName = ScreenNames.INVENTORY,
                    moduleName = DiagnosticModules.INVENTORY,
                    operationName = "تسجيل عد منتج في الجرد",
                    linkedOperationId = trace?.operationId.orEmpty(),
                )
                trace?.fail(e.message ?: "تعذر تسجيل الكمية", err?.errorId.orEmpty())
            }
            Result.failure(e)
        }
    }

    suspend fun recordUnregisteredBarcode(
        sessionId: Long,
        scannedBarcode: String,
        barcodeType: String,
        quantity: Double,
        notes: String = "",
        duplicateAction: DuplicateCountAction = DuplicateCountAction.ADD_TO_EXISTING,
    ): Result<Long> {
        if (quantity < 0.0 || quantity.isNaN() || quantity.isInfinite()) {
            return Result.failure(IllegalArgumentException("الكمية غير صالحة"))
        }
        val cleanBarcode = scannedBarcode.trim()
        if (cleanBarcode.isEmpty()) {
            return Result.failure(IllegalArgumentException("الباركود فارغ"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "تسجيل باركود غير مسجل في الجرد",
            initialStage = "التحقق من الجلسة وإدراج الباركود",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val itemId = db.withTransaction {
                val session = inventoryDao.getSessionWithDetails(sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                if (session.status != InventorySessionStatus.OPEN.name) {
                    throw IllegalStateException("الكشف مغلق ولا يقبل التعديل حالياً")
                }
                val now = System.currentTimeMillis()
                val existing = inventoryDao.findItemBySessionAndBarcode(sessionId, cleanBarcode)
                val id = if (existing == null) {
                    inventoryDao.insertCountItem(
                        InventoryCountItemEntity(
                            sessionId = sessionId,
                            productId = null,
                            productInternalCode = "",
                            productName = "باركود غير مسجل ($cleanBarcode)",
                            productImagePath = "",
                            scannedBarcode = cleanBarcode,
                            barcodeType = barcodeType,
                            unitType = "حبة",
                            conversionFactor = 1.0,
                            countedQty = quantity,
                            baseUnitEquivalentQty = quantity,
                            previousSystemQty = 0.0,
                            lastIncrementQty = quantity,
                            scanCount = 1,
                            notes = notes.trim(),
                            status = InventoryItemStatus.UNREGISTERED.name,
                            scannedAt = now,
                            updatedAt = now,
                        ),
                    )
                } else {
                    val newQty = if (duplicateAction == DuplicateCountAction.ADD_TO_EXISTING) {
                        existing.countedQty + quantity
                    } else {
                        quantity
                    }
                    inventoryDao.updateCountItem(
                        existing.copy(
                            countedQty = newQty,
                            baseUnitEquivalentQty = newQty * existing.conversionFactor,
                            lastIncrementQty = quantity,
                            scanCount = existing.scanCount + 1,
                            notes = notes.trim().ifBlank { existing.notes },
                            updatedAt = now,
                        ),
                    )
                    existing.id
                }
                inventoryDao.updateSession(session.copy(updatedAt = now))
                id
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم حفظ باركود غير مسجل #$itemId")
            Result.success(itemId)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "تسجيل باركود غير مسجل في الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر حفظ الباركود غير المسجل", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun updateCountItemQuantity(
        itemId: Long,
        newQuantity: Double,
        notes: String? = null,
    ): Result<Unit> {
        if (newQuantity < 0.0 || newQuantity.isNaN() || newQuantity.isInfinite()) {
            return Result.failure(IllegalArgumentException("الكمية غير صالحة"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "تعديل كمية بند الجرد",
            initialStage = "التحقق من السطر #$itemId",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val item = inventoryDao.getCountItemById(itemId)
                    ?: throw IllegalArgumentException("سطر الجرد غير موجود")
                val session = inventoryDao.getSessionWithDetails(item.sessionId)?.session
                    ?: throw IllegalArgumentException("جلسة الجرد غير موجودة")
                if (session.status != InventorySessionStatus.OPEN.name) {
                    throw IllegalStateException("الكشف مغلق ولا يمكن تعديل الكميات")
                }
                val now = System.currentTimeMillis()
                trace?.stage("تحديث الكمية في قاعدة البيانات", "الكمية=$newQuantity")
                inventoryDao.updateCountItem(
                    item.copy(
                        countedQty = newQuantity,
                        baseUnitEquivalentQty = newQuantity * item.conversionFactor,
                        lastIncrementQty = newQuantity,
                        notes = notes ?: item.notes,
                        updatedAt = now,
                    ),
                )
                inventoryDao.updateSession(session.copy(updatedAt = now))
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم تعديل كمية البند #$itemId")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "تعديل كمية بند الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر تعديل الكمية", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }

    suspend fun deleteCountItem(itemId: Long): Result<Unit> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.INVENTORY,
            operationName = "حذف بند من الجرد",
            initialStage = "حذف السطر #$itemId",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val item = inventoryDao.getCountItemById(itemId) ?: return@withTransaction
                val session = inventoryDao.getSessionWithDetails(item.sessionId)?.session
                    ?: throw IllegalArgumentException("الجلسة غير موجودة")
                if (session.status != InventorySessionStatus.OPEN.name) {
                    throw IllegalStateException("الكشف مغلق ولا يمكن حذف بنوده")
                }
                inventoryDao.deleteCountItemById(itemId)
                inventoryDao.updateSession(session.copy(updatedAt = System.currentTimeMillis()))
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم حذف البند #$itemId")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.INVENTORY,
                operationName = "حذف بند من الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر الحذف", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }
}
