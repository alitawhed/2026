package com.example.data.storage

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

fun interface BackendHttpTransport {
    suspend fun execute(
        method: String,
        url: String,
        headers: Map<String, String>,
        bodyJson: String?,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        maxBytes: Long,
    ): RemoteHttpResponse
}

class HttpUrlBackendTransport : BackendHttpTransport {
    override suspend fun execute(
        method: String,
        url: String,
        headers: Map<String, String>,
        bodyJson: String?,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        maxBytes: Long,
    ): RemoteHttpResponse = withContext(Dispatchers.IO) {
        val uri = URI(url)
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme != "https") {
            throw SecurityUrlException("يتطلب الاتصال بالخادم الخلفي بروتوكول HTTPS مشفر لحماية بيانات المتجر")
        }
        val host = uri.host?.trim().orEmpty()
        if (host.isBlank()) {
            throw SecurityUrlException("عنوان الخادم الخلفي غير صالح")
        }
        RemoteImageUrlValidator.verifyHostSafe(host)

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            requestMethod = method
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) ->
                if (k.isNotBlank() && v.isNotBlank()) {
                    setRequestProperty(k, v)
                }
            }
            if (bodyJson != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                OutputStreamWriter(outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(bodyJson)
                    writer.flush()
                }
            }
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = if (stream != null) {
                stream.use { input ->
                    val buffer = ByteArray(16 * 1024)
                    val out = ByteArrayOutputStream()
                    var total = 0L
                    while (true) {
                        val r = input.read(buffer)
                        if (r < 0) break
                        total += r
                        if (total > maxBytes) {
                            throw PayloadTooLargeException(total, maxBytes)
                        }
                        out.write(buffer, 0, r)
                    }
                    out.toByteArray()
                }
            } else {
                ByteArray(0)
            }
            RemoteHttpResponse(
                statusCode = code,
                contentType = conn.contentType,
                contentLength = bytes.size.toLong(),
                bytes = bytes,
                finalUrl = url,
            )
        } finally {
            conn.disconnect()
        }
    }
}

class BackendImageSyncService(
    private val transport: BackendHttpTransport = HttpUrlBackendTransport(),
) {

    data class BackendServerConfig(
        val backendBaseUrl: String,
        val backendAccessToken: String = "",
    )

    data class BackendBatchFetchItem(
        val downloadId: Long,
        val url: String,
        val gtin: String,
        val productName: String,
    )

    data class BackendImageFetchResult(
        val downloadId: Long,
        val url: String,
        val ok: Boolean,
        val statusCode: Int,
        val finalUrl: String,
        val failureKind: RemoteImageFailureKind?,
        val failureReason: String,
        val detectedFormat: String,
        val bytes: ByteArray?,
    )

    data class SallaBackendStatus(
        val configured: Boolean,
        val connected: Boolean,
        val scopes: List<String>,
        val redirectUriConfigured: Boolean,
        val expiresAt: Long,
    )

    data class BackendDownloadedMedia(
        val url: String,
        val ok: Boolean,
        val statusCode: Int,
        val failureKind: RemoteImageFailureKind?,
        val failureReason: String,
        val detectedFormat: String,
        val bytes: ByteArray?,
    )

    data class SallaCatalogProductImages(
        val sallaProductId: Long,
        val name: String,
        val sku: String,
        val gtin: String,
        val barcode: String,
        val imageUrls: List<String>,
        val downloadedImages: List<BackendDownloadedMedia>,
    )

    private fun validateBackendBaseUrl(rawUrl: String): Result<String> {
        val trimmed = rawUrl.trim().trimEnd('/')
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("يرجى إدخال عنوان الخادم الخلفي المرافق (HTTPS)"))
        }
        val syntax = RemoteImageUrlValidator.validateSyntax(trimmed)
        if (!syntax.isValid) {
            return Result.failure(IllegalArgumentException(syntax.errorReason ?: "عنوان الخادم الخلفي غير صالح"))
        }
        if (!syntax.normalizedUrl.startsWith("https://", ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("يجب أن يبدأ رابط الخادم الخلفي بـ https:// لحماية البيانات"))
        }
        return Result.success(syntax.normalizedUrl.trimEnd('/'))
    }

    private fun authHeaders(config: BackendServerConfig): Map<String, String> {
        val tok = config.backendAccessToken.trim()
        return if (tok.isNotEmpty()) mapOf("Authorization" to "Bearer $tok") else emptyMap()
    }

    suspend fun fetchImagesViaBackend(
        config: BackendServerConfig,
        items: List<BackendBatchFetchItem>,
    ): Result<List<BackendImageFetchResult>> = withContext(Dispatchers.IO) {
        if (items.isEmpty()) return@withContext Result.success(emptyList())
        val baseUrl = validateBackendBaseUrl(config.backendBaseUrl).getOrElse { return@withContext Result.failure(it) }

        val reqArr = JSONArray()
        items.forEach { item ->
            reqArr.put(
                JSONObject().apply {
                    put("id", item.downloadId)
                    put("url", item.url)
                    put("gtin", item.gtin)
                    put("barcode", item.gtin)
                    put("productName", item.productName)
                },
            )
        }
        val reqBody = JSONObject().put("images", reqArr).toString()

        val resp = try {
            transport.execute(
                method = "POST",
                url = "$baseUrl/api/images/fetch-batch",
                headers = authHeaders(config),
                bodyJson = reqBody,
                connectTimeoutMs = 15_000,
                readTimeoutMs = 45_000,
                maxBytes = 40L * 1024L * 1024L,
            )
        } catch (e: Exception) {
            return@withContext Result.failure(IllegalStateException("تعذر الاتصال بخدمة الخادم: ${e.message}"))
        }

        val respText = resp.bytes.toString(Charsets.UTF_8)
        if (resp.statusCode !in 200..299) {
            val serverMsg = runCatching { JSONObject(respText).optString("error") }.getOrNull().orEmpty()
            return@withContext Result.failure(
                IllegalStateException(
                    serverMsg.ifBlank { "رفض الخادم الخلفي الطلب (HTTP ${resp.statusCode})" },
                ),
            )
        }

        return@withContext runCatching {
            val root = JSONObject(respText)
            val resultsArr = root.optJSONArray("results") ?: JSONArray()
            val out = mutableListOf<BackendImageFetchResult>()
            for (i in 0 until resultsArr.length()) {
                val obj = resultsArr.optJSONObject(i) ?: continue
                val id = obj.optLong("id", -1L)
                val url = obj.optString("url")
                val ok = obj.optBoolean("ok", false)
                val code = obj.optInt("statusCode", 0)
                val finalUrl = obj.optString("finalUrl", url)
                val kind = parseFailureKind(obj.optString("failureKind"), code)
                val reason = obj.optString("failureReason", "")
                val b64 = obj.optString("base64Data", "")

                if (ok && b64.isNotBlank()) {
                    val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                    val verifiedExt = RemoteImageDownloader.detectRasterImageFormat(rawBytes)
                    if (verifiedExt != null) {
                        out.add(
                            BackendImageFetchResult(
                                downloadId = id,
                                url = url,
                                ok = true,
                                statusCode = code,
                                finalUrl = finalUrl,
                                failureKind = null,
                                failureReason = "",
                                detectedFormat = verifiedExt,
                                bytes = rawBytes,
                            ),
                        )
                    } else {
                        out.add(
                            BackendImageFetchResult(
                                downloadId = id,
                                url = url,
                                ok = false,
                                statusCode = code,
                                finalUrl = finalUrl,
                                failureKind = RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE,
                                failureReason = "فشل التحقق المحلي من صلاحية الصورة المستلمة من الخادم",
                                detectedFormat = "",
                                bytes = null,
                            ),
                        )
                    }
                } else {
                    out.add(
                        BackendImageFetchResult(
                            downloadId = id,
                            url = url,
                            ok = false,
                            statusCode = code,
                            finalUrl = finalUrl,
                            failureKind = kind,
                            failureReason = reason.ifBlank { kind.arabicLabel },
                            detectedFormat = "",
                            bytes = null,
                        ),
                    )
                }
            }
            out
        }
    }

    suspend fun getSallaConfigStatus(config: BackendServerConfig): Result<SallaBackendStatus> = withContext(Dispatchers.IO) {
        val baseUrl = validateBackendBaseUrl(config.backendBaseUrl).getOrElse { return@withContext Result.failure(it) }
        val resp = try {
            transport.execute(
                method = "GET",
                url = "$baseUrl/api/salla/config-status",
                headers = authHeaders(config),
                bodyJson = null,
                connectTimeoutMs = 12_000,
                readTimeoutMs = 20_000,
                maxBytes = 1024L * 1024L,
            )
        } catch (e: Exception) {
            return@withContext Result.failure(IllegalStateException("تعذر الاتصال بالخادم الخلفي: ${e.message}"))
        }
        val text = resp.bytes.toString(Charsets.UTF_8)
        if (resp.statusCode !in 200..299) {
            val err = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
            return@withContext Result.failure(IllegalStateException(err.ifBlank { "HTTP ${resp.statusCode}" }))
        }
        runCatching {
            val json = JSONObject(text)
            val scopesArr = json.optJSONArray("scopes") ?: JSONArray()
            val scopes = (0 until scopesArr.length()).mapNotNull { scopesArr.optString(it).takeIf { s -> s.isNotBlank() } }
            SallaBackendStatus(
                configured = json.optBoolean("configured", false),
                connected = json.optBoolean("connected", false),
                scopes = scopes,
                redirectUriConfigured = json.optBoolean("redirectUriConfigured", false),
                expiresAt = json.optLong("expiresAt", 0L),
            )
        }
    }

    suspend fun getSallaAuthorizeUrl(config: BackendServerConfig): Result<String> = withContext(Dispatchers.IO) {
        val baseUrl = validateBackendBaseUrl(config.backendBaseUrl).getOrElse { return@withContext Result.failure(it) }
        val resp = try {
            transport.execute(
                method = "GET",
                url = "$baseUrl/api/salla/auth/url",
                headers = authHeaders(config),
                bodyJson = null,
                connectTimeoutMs = 12_000,
                readTimeoutMs = 20_000,
                maxBytes = 1024L * 1024L,
            )
        } catch (e: Exception) {
            return@withContext Result.failure(IllegalStateException("تعذر طلب رابط تفويض سلة: ${e.message}"))
        }
        val text = resp.bytes.toString(Charsets.UTF_8)
        if (resp.statusCode !in 200..299) {
            val err = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
            return@withContext Result.failure(IllegalStateException(err.ifBlank { "تعذر الحصول على رابط تفويض سلة (HTTP ${resp.statusCode})" }))
        }
        runCatching {
            val url = JSONObject(text).optString("authorizeUrl", "").trim()
            require(url.startsWith("https://", ignoreCase = true)) { "رابط تفويض سلة غير صالح" }
            url
        }
    }

    suspend fun fetchSallaCatalogProducts(
        config: BackendServerConfig,
        page: Int = 1,
        perPage: Int = 50,
        downloadImages: Boolean = true,
    ): Result<List<SallaCatalogProductImages>> = withContext(Dispatchers.IO) {
        val baseUrl = validateBackendBaseUrl(config.backendBaseUrl).getOrElse { return@withContext Result.failure(it) }
        val resp = try {
            transport.execute(
                method = "GET",
                url = "$baseUrl/api/salla/products?page=$page&perPage=$perPage&downloadImages=$downloadImages",
                headers = authHeaders(config),
                bodyJson = null,
                connectTimeoutMs = 15_000,
                readTimeoutMs = 60_000,
                maxBytes = 40L * 1024L * 1024L,
            )
        } catch (e: Exception) {
            return@withContext Result.failure(IllegalStateException("تعذر جلب منتجات سلة عبر الخادم: ${e.message}"))
        }
        val text = resp.bytes.toString(Charsets.UTF_8)
        if (resp.statusCode !in 200..299) {
            val err = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
            return@withContext Result.failure(IllegalStateException(err.ifBlank { "فشل جلب منتجات سلة (HTTP ${resp.statusCode})" }))
        }

        runCatching {
            val root = JSONObject(text)
            val prodsArr = root.optJSONArray("products") ?: JSONArray()
            val list = mutableListOf<SallaCatalogProductImages>()
            for (i in 0 until prodsArr.length()) {
                val obj = prodsArr.optJSONObject(i) ?: continue
                val imgUrlsArr = obj.optJSONArray("imageUrls") ?: JSONArray()
                val urls = (0 until imgUrlsArr.length()).mapNotNull { imgUrlsArr.optString(it).takeIf { s -> s.isNotBlank() } }
                val dlArr = obj.optJSONArray("downloadedImages") ?: JSONArray()
                val dlMedia = mutableListOf<BackendDownloadedMedia>()
                for (j in 0 until dlArr.length()) {
                    val m = dlArr.optJSONObject(j) ?: continue
                    val ok = m.optBoolean("ok", false)
                    val code = m.optInt("statusCode", 0)
                    val b64 = m.optString("base64Data", "")
                    val raw = if (ok && b64.isNotBlank()) Base64.decode(b64, Base64.DEFAULT) else null
                    val ext = raw?.let { RemoteImageDownloader.detectRasterImageFormat(it) }
                    dlMedia.add(
                        BackendDownloadedMedia(
                            url = m.optString("url"),
                            ok = ok && ext != null,
                            statusCode = code,
                            failureKind = if (ok && ext != null) null else parseFailureKind(m.optString("failureKind"), code),
                            failureReason = m.optString("failureReason"),
                            detectedFormat = ext.orEmpty(),
                            bytes = if (ext != null) raw else null,
                        ),
                    )
                }
                list.add(
                    SallaCatalogProductImages(
                        sallaProductId = obj.optLong("sallaProductId", 0L),
                        name = obj.optString("name"),
                        sku = obj.optString("sku"),
                        gtin = obj.optString("gtin"),
                        barcode = obj.optString("barcode"),
                        imageUrls = urls,
                        downloadedImages = dlMedia,
                    ),
                )
            }
            list
        }
    }

    private fun parseFailureKind(rawKind: String, statusCode: Int): RemoteImageFailureKind {
        RemoteImageFailureKind.entries.firstOrNull { it.name == rawKind }?.let { return it }
        return when (statusCode) {
            403 -> RemoteImageFailureKind.HTTP_FORBIDDEN
            401, 407 -> RemoteImageFailureKind.HTTP_UNAUTHORIZED
            404, 410 -> RemoteImageFailureKind.HTTP_NOT_FOUND
            429 -> RemoteImageFailureKind.HTTP_RATE_LIMITED
            in 500..599 -> RemoteImageFailureKind.HTTP_SERVER_ERROR
            else -> RemoteImageFailureKind.NETWORK_ERROR
        }
    }
}
