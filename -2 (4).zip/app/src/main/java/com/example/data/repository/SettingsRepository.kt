package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class SettingsRepository(
    private val db: AppDatabase,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val settingsDao = db.settingsDao()
    private val settingsMutex = Mutex()

    val settingsFlow: Flow<AppSettingsEntity> = settingsDao.observeSettings().map {
        it ?: AppSettingsEntity()
    }

    val inventoryConfigFlow: Flow<InventorySheetConfig> = settingsFlow
        .map { InventoryColumnDefaults.decode(it.inventoryConfigJson) }
        .distinctUntilChanged()

    val productsNumericConfigFlow: Flow<ProductsNumericConfig> = settingsFlow
        .map { NumberFormatEngine.decodeProductsConfig(it.productsNumericConfigJson) }
        .distinctUntilChanged()

    suspend fun getSettingsOnce(): AppSettingsEntity {
        return try {
            settingsDao.getSettingsOnce() ?: settingsMutex.withLock {
                withContext(NonCancellable) {
                    db.withTransaction {
                        settingsDao.getSettingsOnce() ?: AppSettingsEntity().also {
                            settingsDao.saveSettings(it)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.SETTINGS, DiagnosticModules.SETTINGS, "قراءة الإعدادات العامة")
            AppSettingsEntity()
        }
    }

    suspend fun saveSettings(settings: AppSettingsEntity) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.SETTINGS,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "حفظ الإعدادات العامة",
            initialStage = "كتابة الإعدادات في SQLite",
        )
        try {
            val immutableDefaults = AppSettingsEntity()
            settingsMutex.withLock {
                withContext(NonCancellable) {
                    db.withTransaction {
                        val existing = settingsDao.getSettingsOnce()
                        settingsDao.saveSettings(
                            settings.copy(
                                id = 1,
                                developerName = immutableDefaults.developerName,
                                developerPhone = immutableDefaults.developerPhone,
                                inventoryConfigJson = existing?.inventoryConfigJson?.ifBlank { settings.inventoryConfigJson }
                                    ?: settings.inventoryConfigJson,
                                productsNumericConfigJson = existing?.productsNumericConfigJson?.ifBlank { settings.productsNumericConfigJson }
                                    ?: settings.productsNumericConfigJson,
                                updatedAt = System.currentTimeMillis(),
                            ),
                        )
                    }
                }
            }
            trace?.succeed()
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.SETTINGS,
                moduleName = DiagnosticModules.SETTINGS,
                operationName = "حفظ الإعدادات العامة",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حفظ الإعدادات", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun getInventoryConfigOnce(): InventorySheetConfig {
        return InventoryColumnDefaults.decode(getSettingsOnce().inventoryConfigJson)
    }

    suspend fun saveInventoryConfig(config: InventorySheetConfig) {
        updateInventoryConfig { config }
    }

    suspend fun updateInventoryConfig(
        transform: (InventorySheetConfig) -> InventorySheetConfig,
    ): InventorySheetConfig {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.INVENTORY,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "حفظ إعدادات أعمدة الجرد",
            initialStage = "قراءة وتحديث تكوين الأعمدة بشكل ذري",
        )
        try {
            val saved = settingsMutex.withLock {
                withContext(NonCancellable) {
                    db.withTransaction {
                        val current = settingsDao.getSettingsOnce()
                        val decoded = InventoryColumnDefaults.decode(current?.inventoryConfigJson.orEmpty())
                        val transformed = transform(decoded).let { cfg ->
                            val normalizedCols = cfg.columns
                                .sortedBy { it.sortOrder }
                                .mapIndexed { idx, col -> col.copy(sortOrder = idx) }
                            cfg.copy(columns = normalizedCols, schemaRevision = 2)
                        }
                        val encoded = InventoryColumnDefaults.encode(transformed)
                        val now = System.currentTimeMillis()
                        if (current == null) {
                            settingsDao.saveSettings(
                                AppSettingsEntity(
                                    inventoryConfigJson = encoded,
                                    updatedAt = now,
                                ),
                            )
                        } else {
                            settingsDao.updateInventoryConfigJson(
                                json = encoded,
                                updatedAt = now,
                            )
                        }
                        transformed
                    }
                }
            }
            trace?.succeed("تم حفظ ${saved.columns.size} عمود")
            return saved
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.INVENTORY,
                moduleName = DiagnosticModules.SETTINGS,
                operationName = "حفظ إعدادات أعمدة الجرد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حفظ تكوين الأعمدة", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun getProductsNumericConfigOnce(): ProductsNumericConfig {
        return NumberFormatEngine.decodeProductsConfig(getSettingsOnce().productsNumericConfigJson)
    }

    suspend fun saveProductsNumericConfig(config: ProductsNumericConfig) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.SETTINGS,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "حفظ إعدادات المنازل العشرية للمنتجات",
            initialStage = "حفظ تنسيق الأرقام",
        )
        try {
            val encoded = NumberFormatEngine.encodeProductsConfig(config)
            settingsMutex.withLock {
                withContext(NonCancellable) {
                    db.withTransaction {
                        val current = settingsDao.getSettingsOnce()
                        val now = System.currentTimeMillis()
                        if (current == null) {
                            settingsDao.saveSettings(
                                AppSettingsEntity(
                                    productsNumericConfigJson = encoded,
                                    updatedAt = now,
                                ),
                            )
                        } else {
                            settingsDao.updateProductsNumericConfigJson(
                                json = encoded,
                                updatedAt = now,
                            )
                        }
                    }
                }
            }
            trace?.succeed()
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.SETTINGS,
                moduleName = DiagnosticModules.SETTINGS,
                operationName = "حفظ إعدادات تنسيق الأرقام",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حفظ إعدادات الأرقام", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun resetProductsNumericConfig() {
        saveProductsNumericConfig(ProductsNumericConfig())
    }

    suspend fun getDefaultBarcodeType(): com.example.domain.model.BarcodeFormatType {
        val raw = getSettingsOnce().defaultBarcodeType
        return com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(raw)
            ?: com.example.domain.model.BarcodeFormatType.CODE_128
    }

    suspend fun updateDefaultBarcodeType(format: com.example.domain.model.BarcodeFormatType) {
        settingsMutex.withLock {
            withContext(NonCancellable) {
                db.withTransaction {
                    val current = settingsDao.getSettingsOnce()
                    val now = System.currentTimeMillis()
                    if (current == null) {
                        settingsDao.saveSettings(
                            AppSettingsEntity(
                                defaultBarcodeType = format.name,
                                updatedAt = now,
                            ),
                        )
                    } else {
                        settingsDao.updateDefaultBarcodeType(
                            defaultBarcodeType = format.name,
                            updatedAt = now,
                        )
                    }
                }
            }
        }
    }
}
