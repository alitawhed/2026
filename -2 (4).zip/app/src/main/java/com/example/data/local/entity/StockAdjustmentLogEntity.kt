package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "StockAdjustmentLogs",
    foreignKeys = [
        ForeignKey(
            entity = InventorySessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["productId"]),
    ],
)
data class StockAdjustmentLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: Long,
    val productId: Long,
    val productInternalCode: String = "",
    val productName: String,
    val previousQty: Double,
    val newQty: Double,
    val differenceQty: Double,
    val reason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)
