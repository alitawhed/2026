package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.BackupHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BackupDao {
    @Query("SELECT * FROM BackupHistory ORDER BY createdAt DESC")
    fun observeBackupHistory(): Flow<List<BackupHistoryEntity>>

    @Query("SELECT * FROM BackupHistory ORDER BY createdAt DESC LIMIT 1")
    fun observeLatestBackup(): Flow<BackupHistoryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: BackupHistoryEntity): Long

    @Query("DELETE FROM BackupHistory WHERE id = :id")
    suspend fun deleteById(id: Long)
}
