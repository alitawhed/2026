package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ReportTemplateEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TemplateDao {
    @Query("SELECT * FROM ReportTemplates ORDER BY isDefault DESC, isBuiltIn DESC, id ASC")
    fun observeAllTemplates(): Flow<List<ReportTemplateEntity>>

    @Query("SELECT * FROM ReportTemplates ORDER BY isDefault DESC, id ASC")
    suspend fun getAllTemplatesOnce(): List<ReportTemplateEntity>

    @Query("SELECT * FROM ReportTemplates WHERE id = :templateId")
    suspend fun getTemplateById(templateId: Long): ReportTemplateEntity?

    @Query("SELECT * FROM ReportTemplates WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultTemplate(): ReportTemplateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: ReportTemplateEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(templates: List<ReportTemplateEntity>): List<Long>

    @Update
    suspend fun updateTemplate(template: ReportTemplateEntity)

    @Delete
    suspend fun deleteTemplate(template: ReportTemplateEntity)

    @Query("UPDATE ReportTemplates SET isDefault = CASE WHEN id = :templateId THEN 1 ELSE 0 END")
    suspend fun setDefaultTemplate(templateId: Long)

    @Query("DELETE FROM ReportTemplates")
    suspend fun deleteAllTemplates()
}
