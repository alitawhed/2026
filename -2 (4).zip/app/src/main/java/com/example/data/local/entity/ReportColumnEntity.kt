package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "ReportColumns",
    foreignKeys = [
        ForeignKey(
            entity = ReportEntity::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["reportId"])],
)
data class ReportColumnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val reportId: Long,
    val columnKey: String,
    val title: String,
    val columnType: String = "TEXT",
    val visible: Boolean = true,
    val sortOrder: Int = 0,
    val widthMode: String = "AUTO_FIT",
    val manualWidthPt: Float = 80f,
    val presetWidth: String = "MEDIUM",
    val minWidthPt: Float = 36f,
    val maxWidthPt: Float = 320f,
    val cellHeightPt: Float = 42f,
    val fontSizeSp: Float = 10f,
    val textColorHex: String = "#0F172A",
    val cellBgColorHex: String = "#FFFFFF",
    val headerBgColorHex: String = "#0F172A",
    val headerTextColorHex: String = "#FFFFFF",
    val alignment: String = "CENTER",
    val wrapText: Boolean = true,
    val borderWidthPt: Float = 0.75f,
    val paddingHorizontalPt: Float = 5f,
    val paddingVerticalPt: Float = 4f,
    val numberFormat: String = "DECIMAL",
    val decimalPlaces: Int = 2,
    val autoDecimals: Boolean = false,
    val stripTrailingZeros: Boolean = false,
    val dropdownOptionsJson: String = "[]",
    val customFieldKey: String = "",
)
