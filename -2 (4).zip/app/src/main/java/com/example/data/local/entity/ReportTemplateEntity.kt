package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "ReportTemplates")
data class ReportTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val templateKind: String = "OFFICIAL_COMMERCIAL",
    val description: String = "",
    val isDefault: Boolean = false,
    val isBuiltIn: Boolean = false,
    val paperSize: String = "A4",
    val customWidthMm: Float = 210f,
    val customHeightMm: Float = 297f,
    val orientation: String = "PORTRAIT",
    val marginTopMm: Float = 12f,
    val marginBottomMm: Float = 12f,
    val marginStartMm: Float = 10f,
    val marginEndMm: Float = 10f,
    val distributionMode: String = "AUTO_FIT",
    val headerFooterConfigJson: String = "{}",
    val barcodeStyleConfigJson: String = "{}",
    val columnsConfigJson: String = "[]",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
