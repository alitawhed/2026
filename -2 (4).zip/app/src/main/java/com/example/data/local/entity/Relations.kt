package com.example.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation

data class ProductWithDetails(
    @Embedded val product: ProductEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "productId",
    )
    val barcodes: List<ProductBarcodeEntity> = emptyList(),
    @Relation(
        parentColumn = "id",
        entityColumn = "productId",
    )
    val images: List<ProductImageEntity> = emptyList(),
) {
    val primaryBarcode: ProductBarcodeEntity?
        get() = barcodes.firstOrNull { it.isPrimary } ?: barcodes.firstOrNull()

    val primaryImage: ProductImageEntity?
        get() = images.sortedBy { it.sortOrder }.firstOrNull { it.isPrimary }
            ?: images.minByOrNull { it.sortOrder }
}

data class ReportItemWithBarcodes(
    @Embedded val item: ReportItemEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "reportItemId",
    )
    val barcodes: List<ReportItemBarcodeEntity> = emptyList(),
    @Relation(
        parentColumn = "id",
        entityColumn = "reportItemId",
    )
    val images: List<ReportItemImageEntity> = emptyList(),
)

data class ReportWithDetails(
    @Embedded val report: ReportEntity,
    @Relation(
        entity = ReportItemEntity::class,
        parentColumn = "id",
        entityColumn = "reportId",
    )
    val items: List<ReportItemWithBarcodes> = emptyList(),
    @Relation(
        parentColumn = "id",
        entityColumn = "reportId",
    )
    val columns: List<ReportColumnEntity> = emptyList(),
) {
    val sortedItems: List<ReportItemWithBarcodes>
        get() = items.sortedBy { it.item.sortOrder }

    val sortedColumns: List<ReportColumnEntity>
        get() = columns.sortedBy { it.sortOrder }
}

data class PdfDocumentWithPages(
    @Embedded val document: PdfDocumentEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "documentId",
    )
    val pages: List<PdfPageEntity> = emptyList(),
) {
    val sortedPages: List<PdfPageEntity>
        get() = pages.sortedBy { it.sortOrder }
}

data class InventorySessionWithDetails(
    @Embedded val session: InventorySessionEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "sessionId",
    )
    val items: List<InventoryCountItemEntity> = emptyList(),
    @Relation(
        parentColumn = "id",
        entityColumn = "sessionId",
    )
    val adjustmentLogs: List<StockAdjustmentLogEntity> = emptyList(),
) {
    val sortedItems: List<InventoryCountItemEntity>
        get() = items.sortedWith(compareBy<InventoryCountItemEntity> { it.scannedAt }.thenBy { it.id })

    val sortedLogs: List<StockAdjustmentLogEntity>
        get() = adjustmentLogs.sortedByDescending { it.createdAt }
}

data class DashboardStats(
    val totalProducts: Int = 0,
    val totalBarcodes: Int = 0,
    val totalReports: Int = 0,
    val savedReports: Int = 0,
    val productsWithoutImages: Int = 0,
    val productsWithMultipleBarcodes: Int = 0,
    val totalImages: Int = 0,
    val multiImageProducts: Int = 0,
    val todaysReports: Int = 0,
    val archivedReports: Int = 0,
    val lastBackupTimestamp: Long? = null,
    val lastBackupStatus: String = "",
    val usedStorageBytes: Long = 0L,
)
