package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BackupDao
import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.DiagnosticsDao
import com.example.data.local.dao.InventoryDao
import com.example.data.local.dao.PdfDocumentDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.ReportDao
import com.example.data.local.dao.SettingsDao
import com.example.data.local.dao.TemplateDao
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ErrorLogEntity
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.InventorySessionEntity
import com.example.data.local.entity.OperationLogEntity
import com.example.data.local.entity.PdfDocumentEntity
import com.example.data.local.entity.PdfPageEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ReportColumnEntity
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemBarcodeEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportItemImageEntity
import com.example.data.local.entity.ReportTemplateEntity
import com.example.data.local.entity.StockAdjustmentLogEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        ProductBarcodeEntity::class,
        ProductImageEntity::class,
        ProductImageDownloadEntity::class,
        CategoryEntity::class,
        ReportEntity::class,
        ReportItemEntity::class,
        ReportItemBarcodeEntity::class,
        ReportItemImageEntity::class,
        ReportTemplateEntity::class,
        ReportColumnEntity::class,
        AppSettingsEntity::class,
        BackupHistoryEntity::class,
        PdfDocumentEntity::class,
        PdfPageEntity::class,
        InventorySessionEntity::class,
        InventoryCountItemEntity::class,
        StockAdjustmentLogEntity::class,
        ErrorLogEntity::class,
        OperationLogEntity::class,
    ],
    version = 11,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun categoryDao(): CategoryDao
    abstract fun reportDao(): ReportDao
    abstract fun templateDao(): TemplateDao
    abstract fun settingsDao(): SettingsDao
    abstract fun backupDao(): BackupDao
    abstract fun pdfDocumentDao(): PdfDocumentDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun diagnosticsDao(): DiagnosticsDao

    companion object {
        const val LEGACY_DATABASE_NAME = "report_manager_db"

        @Volatile
        private var INSTANCE: AppDatabase? = null
        private val workspaceInstances = mutableMapOf<String, AppDatabase>()
        private val dbScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN originalFilePath TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN thumbnailPath TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE Reports ADD COLUMN versionNumber INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE Reports ADD COLUMN parentReportId INTEGER")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS ReportItemImages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        reportItemId INTEGER NOT NULL,
                        filePath TEXT NOT NULL,
                        isPrimary INTEGER NOT NULL,
                        sortOrder INTEGER NOT NULL,
                        FOREIGN KEY(reportItemId) REFERENCES ReportItems(id) ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ReportItemImages_reportItemId ON ReportItemImages(reportItemId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS PDFDocuments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        title TEXT NOT NULL,
                        fileName TEXT NOT NULL,
                        workingFilePath TEXT NOT NULL,
                        originalFilePath TEXT NOT NULL,
                        pageCount INTEGER NOT NULL,
                        fileSizeBytes INTEGER NOT NULL,
                        sourceReportId INTEGER,
                        annotationsJson TEXT NOT NULL,
                        isEditedCopy INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_PDFDocuments_updatedAt ON PDFDocuments(updatedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_PDFDocuments_sourceReportId ON PDFDocuments(sourceReportId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS PDFPages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        documentId INTEGER NOT NULL,
                        sourcePdfPath TEXT NOT NULL,
                        sourcePageIndex INTEGER NOT NULL,
                        sortOrder INTEGER NOT NULL,
                        rotationDegrees INTEGER NOT NULL,
                        cropLeftFraction REAL NOT NULL,
                        cropTopFraction REAL NOT NULL,
                        cropRightFraction REAL NOT NULL,
                        cropBottomFraction REAL NOT NULL,
                        isBlankPage INTEGER NOT NULL,
                        blankWidthPt REAL NOT NULL,
                        blankHeightPt REAL NOT NULL,
                        extractedText TEXT NOT NULL,
                        thumbnailPath TEXT NOT NULL,
                        FOREIGN KEY(documentId) REFERENCES PDFDocuments(id) ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_PDFPages_documentId ON PDFPages(documentId)")
            }
        }

        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ReportItemImages ADD COLUMN reportId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE ReportItemImages ADD COLUMN sourceProductId INTEGER")
                db.execSQL("ALTER TABLE ReportItemImages ADD COLUMN sourceImageId INTEGER")
                db.execSQL("ALTER TABLE ReportItemImages ADD COLUMN imageSourceType TEXT NOT NULL DEFAULT 'PRODUCT_PRIMARY'")
                db.execSQL("ALTER TABLE ReportItemImages ADD COLUMN addedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE ReportItemImages SET reportId = COALESCE((SELECT reportId FROM ReportItems WHERE ReportItems.id = ReportItemImages.reportItemId), 0)")
                db.execSQL("ALTER TABLE Reports ADD COLUMN rowSortMode TEXT NOT NULL DEFAULT 'MANUAL'")
                db.execSQL("ALTER TABLE AppSettings ADD COLUMN productPickerViewMode TEXT NOT NULL DEFAULT 'LIST'")
                db.execSQL("ALTER TABLE AppSettings ADD COLUMN scannerEnabledFormats TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_3_4: Migration = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ProductBarcodes ADD COLUMN description TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductBarcodes ADD COLUMN unitType TEXT NOT NULL DEFAULT 'حبة'")
                db.execSQL("ALTER TABLE ProductBarcodes ADD COLUMN conversionFactor REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE ProductBarcodes ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE ProductBarcodes SET unitType = CASE WHEN TRIM(label) IN ('حبة','علبة','كرتون','عبوة كبيرة','عبوة صغيرة') THEN TRIM(label) ELSE 'حبة' END, updatedAt = createdAt")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS InventorySessions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        title TEXT NOT NULL,
                        sessionDate INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        notes TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        closedAt INTEGER,
                        reconciledAt INTEGER
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS InventoryCountItems (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        sessionId INTEGER NOT NULL,
                        productId INTEGER,
                        productInternalCode TEXT NOT NULL,
                        productName TEXT NOT NULL,
                        productImagePath TEXT NOT NULL,
                        scannedBarcode TEXT NOT NULL,
                        barcodeType TEXT NOT NULL,
                        unitType TEXT NOT NULL,
                        conversionFactor REAL NOT NULL,
                        countedQty REAL NOT NULL,
                        baseUnitEquivalentQty REAL NOT NULL,
                        previousSystemQty REAL NOT NULL,
                        lastIncrementQty REAL NOT NULL,
                        scanCount INTEGER NOT NULL,
                        notes TEXT NOT NULL,
                        status TEXT NOT NULL,
                        scannedAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        FOREIGN KEY(sessionId) REFERENCES InventorySessions(id) ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_InventoryCountItems_sessionId ON InventoryCountItems(sessionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_InventoryCountItems_productId ON InventoryCountItems(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_InventoryCountItems_scannedBarcode ON InventoryCountItems(scannedBarcode)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS StockAdjustmentLogs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        sessionId INTEGER NOT NULL,
                        productId INTEGER NOT NULL,
                        productInternalCode TEXT NOT NULL,
                        productName TEXT NOT NULL,
                        previousQty REAL NOT NULL,
                        newQty REAL NOT NULL,
                        differenceQty REAL NOT NULL,
                        reason TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        FOREIGN KEY(sessionId) REFERENCES InventorySessions(id) ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_StockAdjustmentLogs_sessionId ON StockAdjustmentLogs(sessionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_StockAdjustmentLogs_productId ON StockAdjustmentLogs(productId)")
            }
        }

        val MIGRATION_4_5: Migration = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE AppSettings ADD COLUMN inventoryConfigJson TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_5_6: Migration = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ReportColumns ADD COLUMN autoDecimals INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE ReportColumns ADD COLUMN stripTrailingZeros INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE AppSettings ADD COLUMN productsNumericConfigJson TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_6_7: Migration = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN sourceUrl TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN matchedBarcode TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN downloadedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN downloadStatus TEXT NOT NULL DEFAULT 'LOCAL'")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN failureReason TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN contentHash TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImages ADD COLUMN fileSizeBytes INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS ProductImageDownloads (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        batchId TEXT NOT NULL,
                        productId INTEGER NOT NULL,
                        barcode TEXT NOT NULL,
                        productName TEXT NOT NULL,
                        sourceUrl TEXT NOT NULL,
                        localImageId INTEGER,
                        localFilePath TEXT NOT NULL,
                        originalFilePath TEXT NOT NULL,
                        thumbnailPath TEXT NOT NULL,
                        status TEXT NOT NULL,
                        failureReason TEXT NOT NULL,
                        imagePolicy TEXT NOT NULL,
                        excelRowNumber INTEGER NOT NULL,
                        attemptCount INTEGER NOT NULL,
                        contentHash TEXT NOT NULL,
                        fileSizeBytes INTEGER NOT NULL,
                        downloadedAt INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        FOREIGN KEY(productId) REFERENCES Products(id) ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ProductImageDownloads_productId ON ProductImageDownloads(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ProductImageDownloads_status ON ProductImageDownloads(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ProductImageDownloads_batchId ON ProductImageDownloads(batchId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ProductImageDownloads_barcode ON ProductImageDownloads(barcode)")
            }
        }

        val MIGRATION_7_8: Migration = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ProductImageDownloads ADD COLUMN failureCategory TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImageDownloads ADD COLUMN httpStatusCode INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE ProductImageDownloads ADD COLUMN finalUrl TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImageDownloads ADD COLUMN detectedFormat TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ProductImageDownloads ADD COLUMN diagnosticLog TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_8_9: Migration = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE AppSettings ADD COLUMN backendServiceUrl TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_9_10: Migration = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS ErrorLogs (
                        errorId TEXT PRIMARY KEY NOT NULL,
                        timestamp INTEGER NOT NULL,
                        screenName TEXT NOT NULL,
                        moduleName TEXT NOT NULL,
                        operationName TEXT NOT NULL,
                        errorType TEXT NOT NULL,
                        originalMessage TEXT NOT NULL,
                        stackTrace TEXT NOT NULL,
                        sourceFile TEXT NOT NULL,
                        lineNumber INTEGER NOT NULL,
                        functionName TEXT NOT NULL,
                        appStateSummary TEXT NOT NULL,
                        wasHandled INTEGER NOT NULL,
                        severity TEXT NOT NULL,
                        fingerprint TEXT NOT NULL,
                        occurrenceCount INTEGER NOT NULL,
                        firstSeenAt INTEGER NOT NULL,
                        lastSeenAt INTEGER NOT NULL,
                        isReviewed INTEGER NOT NULL,
                        linkedOperationId TEXT NOT NULL,
                        isCrash INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ErrorLogs_fingerprint ON ErrorLogs(fingerprint)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ErrorLogs_severity ON ErrorLogs(severity)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ErrorLogs_lastSeenAt ON ErrorLogs(lastSeenAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ErrorLogs_isReviewed ON ErrorLogs(isReviewed)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS OperationLogs (
                        operationId TEXT PRIMARY KEY NOT NULL,
                        startTime INTEGER NOT NULL,
                        endTime INTEGER NOT NULL,
                        screenName TEXT NOT NULL,
                        moduleName TEXT NOT NULL,
                        operationName TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        outcome TEXT NOT NULL,
                        failureReason TEXT NOT NULL,
                        linkedErrorId TEXT NOT NULL,
                        stagesJson TEXT NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_OperationLogs_startTime ON OperationLogs(startTime)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_OperationLogs_outcome ON OperationLogs(outcome)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_OperationLogs_moduleName ON OperationLogs(moduleName)")
            }
        }

        val MIGRATION_10_11: Migration = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE ErrorLogs ADD COLUMN failedStage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ErrorLogs ADD COLUMN deviceSummary TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ErrorLogs ADD COLUMN appVersionSummary TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE OperationLogs ADD COLUMN currentStage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE OperationLogs ADD COLUMN lastSuccessfulStage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE OperationLogs ADD COLUMN interruptedAbnormally INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext, LEGACY_DATABASE_NAME).also { INSTANCE = it }
            }
        }

        fun getInstanceForDatabaseName(context: Context, dbName: String): AppDatabase {
            if (dbName == LEGACY_DATABASE_NAME) return getInstance(context)
            return synchronized(this) {
                workspaceInstances[dbName] ?: buildDatabase(context.applicationContext, dbName).also {
                    workspaceInstances[dbName] = it
                }
            }
        }

        private fun buildDatabase(context: Context, dbName: String): AppDatabase {
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                dbName,
            )
                .addMigrations(
                    MIGRATION_1_2,
                    MIGRATION_2_3,
                    MIGRATION_3_4,
                    MIGRATION_4_5,
                    MIGRATION_5_6,
                    MIGRATION_6_7,
                    MIGRATION_7_8,
                    MIGRATION_8_9,
                    MIGRATION_9_10,
                    MIGRATION_10_11,
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        dbScope.launch {
                            seedInitialDefaults(getInstanceForDatabaseName(context, dbName))
                        }
                    }
                })
                .fallbackToDestructiveMigration(dropAllTables = false)
                .build()
        }

        suspend fun ensureSeeded(database: AppDatabase) {
            seedInitialDefaults(database)
        }

        private suspend fun seedInitialDefaults(database: AppDatabase) {
            val settingsDao = database.settingsDao()
            if (settingsDao.getSettingsOnce() == null) {
                settingsDao.saveSettings(AppSettingsEntity())
            }
            val templateDao = database.templateDao()
            if (templateDao.getAllTemplatesOnce().isEmpty()) {
                templateDao.insertTemplates(TemplateDefaults.buildBuiltInTemplates())
            }
        }
    }
}
