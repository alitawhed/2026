package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "BackupHistory")
data class BackupHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val fileName: String,
    val filePath: String,
    val productCount: Int = 0,
    val barcodeCount: Int = 0,
    val imageCount: Int = 0,
    val reportCount: Int = 0,
    val templateCount: Int = 0,
    val sizeBytes: Long = 0L,
    val operationType: String = "BACKUP",
    val status: String = "SUCCESS",
    val createdAt: Long = System.currentTimeMillis(),
)
