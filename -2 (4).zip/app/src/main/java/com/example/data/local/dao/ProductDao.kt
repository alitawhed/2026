package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageDownloadEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {

    @Transaction
    @Query("SELECT * FROM Products ORDER BY updatedAt DESC")
    fun observeAllProductsWithDetails(): Flow<List<ProductWithDetails>>

    @Transaction
    @Query("SELECT * FROM Products ORDER BY updatedAt DESC LIMIT :limit")
    fun observeRecentProducts(limit: Int = 5): Flow<List<ProductWithDetails>>

    @Transaction
    @Query("SELECT * FROM Products WHERE id = :productId")
    fun observeProductWithDetails(productId: Long): Flow<ProductWithDetails?>

    @Transaction
    @Query("SELECT * FROM Products WHERE id = :productId")
    suspend fun getProductWithDetails(productId: Long): ProductWithDetails?

    @Transaction
    @Query("SELECT * FROM Products")
    suspend fun getAllProductsWithDetailsOnce(): List<ProductWithDetails>

    @Query("SELECT * FROM Products")
    suspend fun getAllProductsOnce(): List<ProductEntity>

    @Query("SELECT * FROM ProductBarcodes")
    suspend fun getAllBarcodesOnce(): List<ProductBarcodeEntity>

    @Query("SELECT * FROM ProductImages")
    suspend fun getAllImagesOnce(): List<ProductImageEntity>

    @Query("SELECT * FROM ProductBarcodes WHERE barcodeValue = :barcodeValue LIMIT 1")
    suspend fun findBarcodeExact(barcodeValue: String): ProductBarcodeEntity?

    @Query("SELECT * FROM ProductBarcodes WHERE id = :barcodeId LIMIT 1")
    suspend fun getBarcodeById(barcodeId: Long): ProductBarcodeEntity?

    @Transaction
    @Query(
        """
        SELECT DISTINCT p.* FROM Products p
        LEFT JOIN ProductBarcodes b ON p.id = b.productId
        WHERE p.name LIKE '%' || :query || '%'
           OR p.internalCode LIKE '%' || :query || '%'
           OR p.description LIKE '%' || :query || '%'
           OR p.categoryName LIKE '%' || :query || '%'
           OR b.barcodeValue LIKE '%' || :query || '%'
           OR b.label LIKE '%' || :query || '%'
           OR b.description LIKE '%' || :query || '%'
        ORDER BY p.updatedAt DESC
        """
    )
    fun searchProducts(query: String): Flow<List<ProductWithDetails>>

    @Query("SELECT COUNT(*) FROM Products")
    fun observeProductCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM ProductBarcodes")
    fun observeBarcodeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM Products WHERE id NOT IN (SELECT DISTINCT productId FROM ProductImages)")
    fun observeProductsWithoutImagesCount(): Flow<Int>

    @Query(
        """
        SELECT COUNT(*) FROM (
            SELECT productId FROM ProductBarcodes GROUP BY productId HAVING COUNT(*) > 1
        )
        """
    )
    fun observeMultiBarcodeProductsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM ProductImages")
    fun observeImageCount(): Flow<Int>

    @Query(
        """
        SELECT COUNT(*) FROM (
            SELECT productId FROM ProductImages GROUP BY productId HAVING COUNT(*) > 1
        )
        """
    )
    fun observeMultiImageProductsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>): List<Long>

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("DELETE FROM Products WHERE id IN (:ids)")
    suspend fun deleteProductsByIds(ids: List<Long>)

    @Query("UPDATE Products SET categoryId = :categoryId, categoryName = :categoryName, updatedAt = :updatedAt WHERE id IN (:ids)")
    suspend fun updateCategoryForProducts(ids: List<Long>, categoryId: Long?, categoryName: String, updatedAt: Long)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBarcode(barcode: ProductBarcodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBarcodes(barcodes: List<ProductBarcodeEntity>): List<Long>

    @Update
    suspend fun updateBarcode(barcode: ProductBarcodeEntity)

    @Query("DELETE FROM ProductBarcodes WHERE id = :barcodeId")
    suspend fun deleteBarcodeById(barcodeId: Long)

    @Query("UPDATE ProductBarcodes SET isPrimary = CASE WHEN id = :primaryId THEN 1 ELSE 0 END WHERE productId = :productId")
    suspend fun setPrimaryBarcode(productId: Long, primaryId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImage(image: ProductImageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImages(images: List<ProductImageEntity>): List<Long>

    @Update
    suspend fun updateImage(image: ProductImageEntity)

    @Update
    suspend fun updateImages(images: List<ProductImageEntity>)

    @Query("SELECT * FROM ProductImages WHERE id = :imageId LIMIT 1")
    suspend fun getImageById(imageId: Long): ProductImageEntity?

    @Query("SELECT * FROM ProductImages WHERE contentHash = :hash AND contentHash != '' LIMIT 1")
    suspend fun findImageByContentHash(hash: String): ProductImageEntity?

    @Query("SELECT * FROM ProductImages WHERE sourceUrl = :url AND sourceUrl != '' LIMIT 1")
    suspend fun findImageBySourceUrl(url: String): ProductImageEntity?

    @Query("DELETE FROM ProductImages WHERE id = :imageId")
    suspend fun deleteImageById(imageId: Long)

    @Query("UPDATE ProductImages SET isPrimary = CASE WHEN id = :primaryId THEN 1 ELSE 0 END WHERE productId = :productId")
    suspend fun setPrimaryImage(productId: Long, primaryId: Long)

    @Query("SELECT * FROM ProductImageDownloads ORDER BY updatedAt DESC")
    fun observeAllImageDownloads(): Flow<List<ProductImageDownloadEntity>>

    @Query("SELECT * FROM ProductImageDownloads WHERE status IN ('FAILED', 'PENDING') ORDER BY updatedAt DESC")
    fun observePendingOrFailedImageDownloads(): Flow<List<ProductImageDownloadEntity>>

    @Query("SELECT * FROM ProductImageDownloads WHERE status IN ('FAILED', 'PENDING') ORDER BY id ASC")
    suspend fun getPendingOrFailedImageDownloadsOnce(): List<ProductImageDownloadEntity>

    @Query("SELECT * FROM ProductImageDownloads WHERE batchId = :batchId ORDER BY excelRowNumber ASC, id ASC")
    suspend fun getImageDownloadsByBatchOnce(batchId: String): List<ProductImageDownloadEntity>

    @Query("SELECT * FROM ProductImageDownloads WHERE id IN (:ids) ORDER BY id ASC")
    suspend fun getImageDownloadsByIdsOnce(ids: List<Long>): List<ProductImageDownloadEntity>

    @Query("SELECT * FROM ProductImageDownloads WHERE productId = :productId ORDER BY updatedAt DESC")
    suspend fun getImageDownloadsForProductOnce(productId: Long): List<ProductImageDownloadEntity>

    @Query("SELECT * FROM ProductImageDownloads")
    suspend fun getAllImageDownloadsOnce(): List<ProductImageDownloadEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImageDownload(item: ProductImageDownloadEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImageDownloads(items: List<ProductImageDownloadEntity>): List<Long>

    @Update
    suspend fun updateImageDownload(item: ProductImageDownloadEntity)

    @Query("DELETE FROM ProductImageDownloads WHERE id = :id")
    suspend fun deleteImageDownloadById(id: Long)

    @Query("DELETE FROM ProductImageDownloads WHERE status = 'SUCCESS'")
    suspend fun clearCompletedImageDownloads()

    @Query("DELETE FROM Products")
    suspend fun deleteAllProducts()
}
