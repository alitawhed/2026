package com.example.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.UUID
import kotlin.math.abs

data class StoredImageFiles(
    val activePath: String,
    val originalPath: String,
    val thumbnailPath: String,
)

data class ImageEditParameters(
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropRight: Float = 1f,
    val cropBottom: Float = 1f,
    val rotateDegrees: Int = 0,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val brightness: Float = 0f,      // -100f .. +100f
    val contrast: Float = 1f,        // 0.4f .. 2.2f
    val saturation: Float = 1f,      // 0f .. 2.2f
    val temperatureWarmth: Float = 0f, // -40f .. +40f (blue <-> warm amber balance)
    val removeLightBackground: Boolean = false,
    val backgroundThreshold: Int = 238,
    val targetMaxWidth: Int = 0,     // 0 = keep current width
    val targetMaxHeight: Int = 0,    // 0 = keep current height
    val exportAsPng: Boolean = true,
    val jpegQuality: Int = 92,
)

class MediaStorageManager(
    private val context: Context,
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val baseStorageDir: File = context.filesDir,
) {

    val productImagesDir: File
        get() = File(baseStorageDir, "product_images").apply { mkdirs() }

    val originalsDir: File
        get() = File(baseStorageDir, "product_originals").apply { mkdirs() }

    val thumbnailsDir: File
        get() = File(baseStorageDir, "product_thumbnails").apply { mkdirs() }

    val reportSnapshotsDir: File
        get() = File(baseStorageDir, "report_snapshots").apply { mkdirs() }

    val brandingDir: File
        get() = File(baseStorageDir, "branding").apply { mkdirs() }

    val exportsDir: File
        get() = File(baseStorageDir, "exports").apply { mkdirs() }

    val pdfWorkspaceDir: File
        get() = File(baseStorageDir, "pdf_workspace").apply { mkdirs() }

    val editedPdfsDir: File
        get() = File(baseStorageDir, "edited_pdfs").apply { mkdirs() }

    val backupsDir: File
        get() = File(baseStorageDir, "backups").apply { mkdirs() }

    val barcodeCacheDir: File
        get() = File(baseStorageDir, "barcode_cache").apply { mkdirs() }

    fun saveProductImageWithOriginal(uri: Uri): StoredImageFiles? {
        return try {
            val rawBytes = readBoundedBytesFromUri(uri, maxBytes = 25L * 1024L * 1024L)
            if (rawBytes != null && rawBytes.isNotEmpty()) {
                val detectedExt = RemoteImageDownloader.detectRasterImageFormat(rawBytes)
                if (detectedExt != null) {
                    val savedFromBytes = saveDownloadedImageBytes(rawBytes, detectedExt)
                    if (savedFromBytes != null) return savedFromBytes
                }
            }
            val bitmap = decodeAndOrientBitmap(uri) ?: return null
            saveBitmapTriplet(bitmap)
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.STORAGE, "حفظ صورة منتج من URI")
            null
        }
    }

    fun saveProductImageBytesWithOriginal(bytes: ByteArray): StoredImageFiles? {
        val detected = RemoteImageDownloader.detectRasterImageFormat(bytes) ?: "png"
        return saveDownloadedImageBytes(bytes, extensionHint = detected)
    }

    /**
     * Stores image bytes preserving exact untouched original file bytes in originalsDir,
     * converting display copies cleanly to PNG/JPEG when format needs normalization across app views
     * (e.g. GIF/BMP/AVIF/rotated/oversized), and verifies saved files exist & decode cleanly.
     */
    fun saveDownloadedImageBytes(bytes: ByteArray, extensionHint: String = "png"): StoredImageFiles? {
        var uid = ""
        var activeFile: File? = null
        var originalFile: File? = null
        var thumbFile: File? = null
        return try {
            val detectedReal = RemoteImageDownloader.detectRasterImageFormat(bytes)
            val safeExt = (detectedReal ?: extensionHint).lowercase().let {
                when (it) {
                    "jpeg" -> "jpg"
                    "png", "jpg", "webp", "gif", "bmp", "avif" -> it
                    else -> "png"
                }
            }

            var usedFallbackDecoder = false
            var inSample = 1
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val decoded: Bitmap = (if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                while (bounds.outWidth / inSample > 2400 || bounds.outHeight / inSample > 2400) {
                    inSample *= 2
                }
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = inSample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                    ?: if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        usedFallbackDecoder = true
                        decodeWithImageDecoder(bytes, maxDim = 2400)
                    } else null
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                usedFallbackDecoder = true
                decodeWithImageDecoder(bytes, maxDim = 2400)
            } else {
                null
            }) ?: return null

            val orientation = try {
                bytes.inputStream().use { exifStream ->
                    ExifInterface(exifStream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL,
                    )
                }
            } catch (_: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

            val finalBitmap = if (degrees != 0f) {
                val matrix = Matrix().apply { postRotate(degrees) }
                val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
                rotated
            } else {
                decoded
            }

            uid = UUID.randomUUID().toString()
            originalFile = File(originalsDir, "orig_$uid.$safeExt").also { f ->
                FileOutputStream(f).use { it.write(bytes) }
            }

            val keepDirectRawActive = inSample == 1 &&
                degrees == 0f &&
                !usedFallbackDecoder &&
                safeExt in setOf("png", "jpg", "webp") &&
                bounds.outWidth > 0 && bounds.outHeight > 0

            activeFile = if (keepDirectRawActive) {
                File(productImagesDir, "prod_$uid.$safeExt").also { f ->
                    FileOutputStream(f).use { it.write(bytes) }
                }
            } else {
                // Convert display copy to universal PNG while untouched original stays in originalsDir
                File(saveBitmapToFile(finalBitmap, productImagesDir, "prod_$uid.png"))
            }

            val thumb = scaleDownIfHuge(finalBitmap, 320, recycleSource = false)
            val thumbPath = saveBitmapToFile(thumb, thumbnailsDir, "thumb_$uid.png")
            thumbFile = File(thumbPath)
            if (thumb !== finalBitmap && !thumb.isRecycled) thumb.recycle()
            if (!finalBitmap.isRecycled) finalBitmap.recycle()

            val activeOk = activeFile.exists() && activeFile.length() > 0L && isReadableImageFile(activeFile)
            val thumbOk = thumbFile.exists() && thumbFile.length() > 0L && isReadableImageFile(thumbFile)
            val origOk = originalFile.exists() && originalFile.length() > 0L
            if (!activeOk || !thumbOk || !origOk) {
                activeFile.delete()
                originalFile.delete()
                thumbFile.delete()
                return null
            }

            StoredImageFiles(
                activePath = activeFile.absolutePath,
                originalPath = originalFile.absolutePath,
                thumbnailPath = thumbPath,
            )
        } catch (t: Throwable) {
            activeFile?.delete()
            originalFile?.delete()
            thumbFile?.delete()
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.STORAGE, "حفظ بايتات صورة المنتج")
            null
        }
    }

    fun copyStoredFilesForProduct(source: StoredImageFiles): StoredImageFiles? {
        return try {
            val uid = UUID.randomUUID().toString()
            val activeSrc = File(source.activePath)
            if (!activeSrc.exists()) return null
            val activeExt = activeSrc.extension.ifBlank { "png" }
            val activeDest = File(productImagesDir, "prod_$uid.$activeExt")
            activeSrc.copyTo(activeDest, overwrite = true)

            val origDestPath = File(source.originalPath).takeIf { it.exists() }?.let { origSrc ->
                val origExt = origSrc.extension.ifBlank { activeExt }
                val dest = File(originalsDir, "orig_$uid.$origExt")
                origSrc.copyTo(dest, overwrite = true)
                dest.absolutePath
            } ?: ensureOriginalBackup(activeDest.absolutePath, "")

            val thumbDestPath = File(source.thumbnailPath).takeIf { it.exists() }?.let { thumbSrc ->
                val dest = File(thumbnailsDir, "thumb_$uid.${thumbSrc.extension.ifBlank { "png" }}")
                thumbSrc.copyTo(dest, overwrite = true)
                dest.absolutePath
            } ?: generateThumbnail(activeDest.absolutePath)

            StoredImageFiles(
                activePath = activeDest.absolutePath,
                originalPath = origDestPath,
                thumbnailPath = thumbDestPath,
            )
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.STORAGE, "نسخ ملفات صورة المنتج")
            null
        }
    }

    fun saveProductImageFromUri(uri: Uri): String? =
        saveProductImageWithOriginal(uri)?.activePath

    fun saveProductImageFromBytes(bytes: ByteArray, extensionHint: String = "png"): String? =
        saveDownloadedImageBytes(bytes, extensionHint)?.activePath

    fun saveBrandingImageFromUri(uri: Uri, prefix: String): String? {
        return try {
            val bitmap = decodeAndOrientBitmap(uri) ?: return null
            saveBitmapToFile(bitmap, brandingDir, "${prefix}_${UUID.randomUUID()}.png")
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.SETTINGS, DiagnosticModules.STORAGE, "حفظ شعار العلامة التجارية")
            null
        }
    }

    fun saveBitmapAsProductImage(bitmap: Bitmap): String? {
        return try {
            saveBitmapToFile(bitmap, productImagesDir, "prod_${UUID.randomUUID()}.png")
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.STORAGE, "حفظ Bitmap كصورة منتج")
            null
        }
    }

    fun saveBitmapTriplet(bitmap: Bitmap): StoredImageFiles {
        val uid = UUID.randomUUID().toString()
        val originalPath = saveBitmapToFile(bitmap, originalsDir, "orig_$uid.png")
        val activePath = saveBitmapToFile(bitmap, productImagesDir, "prod_$uid.png")
        val thumb = scaleDownIfHuge(bitmap, 320, recycleSource = false)
        val thumbPath = saveBitmapToFile(thumb, thumbnailsDir, "thumb_$uid.png")
        if (thumb !== bitmap && !thumb.isRecycled) thumb.recycle()
        return StoredImageFiles(
            activePath = activePath,
            originalPath = originalPath,
            thumbnailPath = thumbPath,
        )
    }

    /**
     * Generates a fresh thumbnail for any stored image path.
     */
    fun generateThumbnail(sourcePath: String): String {
        if (sourcePath.isBlank()) return ""
        return try {
            val sampled = decodeSampledBitmap(sourcePath, 320) ?: return ""
            val path = saveBitmapToFile(sampled, thumbnailsDir, "thumb_${UUID.randomUUID()}.png")
            if (!sampled.isRecycled) sampled.recycle()
            path
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "توليد صورة مصغرة")
            ""
        }
    }

    /**
     * Ensures a legacy image without originalFilePath gets an untouched copy backed up in originalsDir first.
     */
    fun ensureOriginalBackup(activePath: String, existingOriginalPath: String): String {
        if (existingOriginalPath.isNotBlank() && File(existingOriginalPath).exists()) {
            return existingOriginalPath
        }
        val activeFile = File(activePath)
        if (!activeFile.exists()) return ""
        val backupFile = File(originalsDir, "orig_${UUID.randomUUID()}.${activeFile.extension.ifBlank { "png" }}")
        return try {
            activeFile.copyTo(backupFile, overwrite = true)
            backupFile.absolutePath
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Applies full non-destructive image edits against [sourceImagePath] (never mutating [sourceImagePath] if it's the original).
     * Returns newly generated StoredImageFiles (or updates activePath when [saveAsNewCopy] is false while keeping originalPath intact).
     */
    fun applyImageEdits(
        sourceImagePath: String,
        existingOriginalPath: String,
        activeFilePath: String,
        params: ImageEditParameters,
        saveAsNewCopy: Boolean = false,
    ): StoredImageFiles? {
        val originalPath = ensureOriginalBackup(activeFilePath, existingOriginalPath)
        val decodeFrom = if (File(sourceImagePath).exists()) sourceImagePath else activeFilePath
        val raw = decodeSampledBitmap(decodeFrom, 2048) ?: return null
        return try {
            val processed = renderEditedBitmap(raw, params)
            val ext = if (params.exportAsPng) "png" else "jpg"
            val format = if (params.exportAsPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
            val quality = if (params.exportAsPng) 100 else params.jpegQuality.coerceIn(50, 100)

            val outActivePath = if (saveAsNewCopy) {
                File(productImagesDir, "prod_${UUID.randomUUID()}.$ext").absolutePath
            } else {
                File(productImagesDir, "prod_${UUID.randomUUID()}.$ext").absolutePath
            }

            FileOutputStream(outActivePath).use { out ->
                processed.compress(format, quality, out)
            }

            val finalOriginalPath = if (saveAsNewCopy) {
                File(originalsDir, "orig_${UUID.randomUUID()}.$ext").also { origCopy ->
                    File(outActivePath).copyTo(origCopy, overwrite = true)
                }.absolutePath
            } else {
                originalPath
            }

            val thumbBmp = scaleDownIfHuge(processed, 320, recycleSource = false)
            val thumbPath = saveBitmapToFile(thumbBmp, thumbnailsDir, "thumb_${UUID.randomUUID()}.png")
            if (thumbBmp !== processed && !thumbBmp.isRecycled) thumbBmp.recycle()
            if (!processed.isRecycled) processed.recycle()

            if (!saveAsNewCopy && activeFilePath != finalOriginalPath) {
                deleteFileIfInternal(activeFilePath)
            }

            StoredImageFiles(
                activePath = outActivePath,
                originalPath = finalOriginalPath,
                thumbnailPath = thumbPath,
            )
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGE_EDITOR, DiagnosticModules.IMAGES, "تطبيق تعديلات الصورة")
            null
        } finally {
            if (!raw.isRecycled) raw.recycle()
        }
    }

    /**
     * Renders an edited bitmap preview in memory without writing files (used by interactive Image Editor screen).
     */
    fun renderEditedBitmap(source: Bitmap, params: ImageEditParameters): Bitmap {
        var current = source

        // 1. Crop
        val l = (params.cropLeft.coerceIn(0f, 0.92f) * current.width).toInt()
        val t = (params.cropTop.coerceIn(0f, 0.92f) * current.height).toInt()
        val r = (params.cropRight.coerceIn(params.cropLeft + 0.05f, 1f) * current.width).toInt()
        val b = (params.cropBottom.coerceIn(params.cropTop + 0.05f, 1f) * current.height).toInt()
        val cropW = (r - l).coerceIn(8, (current.width - l).coerceAtLeast(1))
        val cropH = (b - t).coerceIn(8, (current.height - t).coerceAtLeast(1))
        if (l > 0 || t > 0 || cropW < current.width || cropH < current.height) {
            current = Bitmap.createBitmap(current, l, t, cropW, cropH)
        }

        // 2. Rotate & Flip
        val rotMod = ((params.rotateDegrees % 360) + 360) % 360
        if (rotMod != 0 || params.flipHorizontal || params.flipVertical) {
            val matrix = Matrix()
            if (rotMod != 0) matrix.postRotate(rotMod.toFloat())
            matrix.postScale(
                if (params.flipHorizontal) -1f else 1f,
                if (params.flipVertical) -1f else 1f,
            )
            val transformed = Bitmap.createBitmap(current, 0, 0, current.width, current.height, matrix, true)
            if (current !== source && !current.isRecycled) current.recycle()
            current = transformed
        }

        // 3. Resize if requested
        if (params.targetMaxWidth > 0 || params.targetMaxHeight > 0) {
            val reqW = if (params.targetMaxWidth > 0) params.targetMaxWidth else current.width
            val reqH = if (params.targetMaxHeight > 0) params.targetMaxHeight else current.height
            val scale = minOf(
                reqW.toFloat() / current.width.toFloat(),
                reqH.toFloat() / current.height.toFloat(),
            ).coerceIn(0.05f, 2f)
            val targetW = (current.width * scale).toInt().coerceAtLeast(8)
            val targetH = (current.height * scale).toInt().coerceAtLeast(8)
            if (targetW != current.width || targetH != current.height) {
                val resized = Bitmap.createScaledBitmap(current, targetW, targetH, true)
                if (current !== source && !current.isRecycled) current.recycle()
                current = resized
            }
        }

        // 4. Brightness, Contrast, Saturation & Warmth ColorMatrix
        val needsColorAdjust =
            abs(params.brightness) > 0.5f ||
                abs(params.contrast - 1f) > 0.02f ||
                abs(params.saturation - 1f) > 0.02f ||
                abs(params.temperatureWarmth) > 0.5f

        if (needsColorAdjust) {
            val outBmp = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(outBmp)
            val cm = ColorMatrix()

            val satMatrix = ColorMatrix().apply { setSaturation(params.saturation.coerceIn(0f, 2.5f)) }
            cm.postConcat(satMatrix)

            val c = params.contrast.coerceIn(0.4f, 2.2f)
            val tOffset = 128f * (1f - c) + params.brightness.coerceIn(-120f, 120f)
            val warm = params.temperatureWarmth.coerceIn(-45f, 45f)
            val bcMatrix = ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, tOffset + warm,
                    0f, c, 0f, 0f, tOffset,
                    0f, 0f, c, 0f, tOffset - warm,
                    0f, 0f, 0f, 1f, 0f,
                ),
            )
            cm.postConcat(bcMatrix)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                colorFilter = ColorMatrixColorFilter(cm)
            }
            canvas.drawBitmap(current, 0f, 0f, paint)
            if (current !== source && !current.isRecycled) current.recycle()
            current = outBmp
        }

        // 5. Optional Studio White/Light Background Cleanup (transparent background)
        if (params.removeLightBackground) {
            val thresh = params.backgroundThreshold.coerceIn(180, 254)
            val w = current.width
            val h = current.height
            val pixels = IntArray(w * h)
            current.getPixels(pixels, 0, w, 0, 0, w, h)
            for (i in pixels.indices) {
                val px = pixels[i]
                val a = Color.alpha(px)
                if (a == 0) continue
                val rC = Color.red(px)
                val gC = Color.green(px)
                val bC = Color.blue(px)
                val minCh = minOf(rC, gC, bC)
                val spread = maxOf(rC, gC, bC) - minCh
                if (minCh >= thresh && spread <= 24) {
                    pixels[i] = Color.TRANSPARENT
                }
            }
            val cleaned = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            cleaned.setPixels(pixels, 0, w, 0, 0, w, h)
            if (current !== source && !current.isRecycled) current.recycle()
            current = cleaned
        }

        if (current === source) {
            current = source.copy(Bitmap.Config.ARGB_8888, false)
        }
        return current
    }

    /**
     * Restores the untouched original copy back into activePath without deleting the original backup.
     */
    fun restoreFromOriginal(originalPath: String, currentActivePath: String): StoredImageFiles? {
        val orig = File(originalPath)
        if (!orig.exists()) return null
        return try {
            val destActive = File(productImagesDir, "prod_${UUID.randomUUID()}.${orig.extension.ifBlank { "png" }}")
            orig.copyTo(destActive, overwrite = true)
            if (currentActivePath != originalPath) {
                deleteFileIfInternal(currentActivePath)
            }
            val thumb = generateThumbnail(destActive.absolutePath)
            StoredImageFiles(
                activePath = destActive.absolutePath,
                originalPath = originalPath,
                thumbnailPath = thumb,
            )
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGE_EDITOR, DiagnosticModules.STORAGE, "استعادة الصورة الأصلية")
            null
        }
    }

    fun copyUriToPdfWorkspace(uri: Uri, preferredName: String = "document.pdf"): File? {
        return try {
            val clean = preferredName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "doc.pdf" }
            val out = File(pdfWorkspaceDir, "${UUID.randomUUID().toString().take(6)}_$clean")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(out).use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            out
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.PDF_EDITOR, DiagnosticModules.STORAGE, "نسخ PDF إلى مساحة العمل")
            null
        }
    }

    fun copyPdfToWorkspace(sourceFile: File): File? {
        if (!sourceFile.exists()) return null
        return try {
            val out = File(pdfWorkspaceDir, "${UUID.randomUUID().toString().take(6)}_${sourceFile.name}")
            sourceFile.copyTo(out, overwrite = true)
            out
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.PDF_EDITOR, DiagnosticModules.STORAGE, "نسخ ملف PDF داخلي")
            null
        }
    }

    fun calculateUsedStorageBytes(): Long {
        val isLegacyRoot = baseStorageDir.absolutePath == context.filesDir.absolutePath
        fun walk(dir: File): Long {
            if (!dir.exists()) return 0L
            if (isLegacyRoot && dir.isDirectory && dir.parentFile?.absolutePath == baseStorageDir.absolutePath && dir.name == "workspaces") {
                return 0L
            }
            if (dir.isFile) return dir.length()
            return dir.listFiles()?.sumOf { walk(it) } ?: 0L
        }
        return walk(baseStorageDir)
    }

    fun copyToReportSnapshot(sourcePath: String, reportId: Long): String {
        if (sourcePath.isBlank()) return ""
        val src = File(sourcePath)
        if (!src.exists() || !src.isFile) return ""
        val reportDir = File(reportSnapshotsDir, "report_$reportId").apply { mkdirs() }
        val ext = src.extension.ifBlank { "png" }
        val dest = File(reportDir, "snap_${UUID.randomUUID()}.$ext")
        return try {
            src.copyTo(dest, overwrite = true)
            dest.absolutePath
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.REPORT_EDITOR, DiagnosticModules.STORAGE, "نسخ لقطة صورة التقرير")
            ""
        }
    }

    /**
     * Imports an external Uri directly into the isolated report snapshot folder
     * without touching the product image catalog or originals.
     */
    fun saveUriToReportSnapshot(uri: Uri, reportId: Long): String? {
        return try {
            val bitmap = decodeAndOrientBitmap(uri) ?: return null
            val reportDir = File(reportSnapshotsDir, "report_$reportId").apply { mkdirs() }
            val path = saveBitmapToFile(bitmap, reportDir, "rpt_up_${UUID.randomUUID()}.png")
            if (!bitmap.isRecycled) bitmap.recycle()
            path
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.REPORT_EDITOR, DiagnosticModules.STORAGE, "استيراد صورة لقطة للتقرير")
            null
        }
    }

    /**
     * Applies image edits (crop, rotate, flip, brightness, contrast, saturation) solely to a new
     * file inside [reportSnapshotsDir]/report_<reportId> without touching [sourcePath] or product files.
     */
    fun applyEditsToReportSnapshot(
        sourcePath: String,
        reportId: Long,
        params: ImageEditParameters,
    ): String? {
        if (sourcePath.isBlank()) return null
        val srcFile = File(sourcePath)
        if (!srcFile.exists() || !srcFile.isFile) return null
        val raw = decodeSampledBitmap(srcFile.absolutePath, 2048) ?: return null
        return try {
            val processed = renderEditedBitmap(raw, params)
            val reportDir = File(reportSnapshotsDir, "report_$reportId").apply { mkdirs() }
            val ext = if (params.exportAsPng) "png" else "jpg"
            val format = if (params.exportAsPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
            val quality = if (params.exportAsPng) 100 else params.jpegQuality.coerceIn(50, 100)
            val outFile = File(reportDir, "rpt_edit_${UUID.randomUUID()}.$ext")
            FileOutputStream(outFile).use { out ->
                processed.compress(format, quality, out)
            }
            if (!processed.isRecycled) processed.recycle()
            outFile.absolutePath
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.REPORT_EDITOR, DiagnosticModules.IMAGES, "تعديل صورة التقرير")
            null
        } finally {
            if (!raw.isRecycled) raw.recycle()
        }
    }

    fun rotateImageFile(filePath: String, degrees: Float = 90f): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false
        return try {
            val original = decodeSampledBitmap(file.absolutePath, 2048) ?: return false
            val matrix = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
            FileOutputStream(file).use { out ->
                rotated.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            if (rotated != original) rotated.recycle()
            original.recycle()
            true
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "تدوير ملف الصورة")
            false
        }
    }

    fun cropImageFile(
        filePath: String,
        leftFraction: Float,
        topFraction: Float,
        rightFraction: Float,
        bottomFraction: Float,
    ): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false
        return try {
            val original = decodeSampledBitmap(file.absolutePath, 2048) ?: return false
            val l = (leftFraction.coerceIn(0f, 0.9f) * original.width).toInt()
            val t = (topFraction.coerceIn(0f, 0.9f) * original.height).toInt()
            val r = (rightFraction.coerceIn(leftFraction + 0.1f, 1f) * original.width).toInt()
            val b = (bottomFraction.coerceIn(topFraction + 0.1f, 1f) * original.height).toInt()
            val w = (r - l).coerceAtLeast(16)
            val h = (b - t).coerceAtLeast(16)
            val cropped = Bitmap.createBitmap(original, l, t, w.coerceAtMost(original.width - l), h.coerceAtMost(original.height - t))
            FileOutputStream(file).use { out ->
                cropped.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            if (cropped != original) cropped.recycle()
            original.recycle()
            true
        } catch (t: Throwable) {
            errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "قص ملف الصورة")
            false
        }
    }

    fun deleteFileIfInternal(path: String) {
        if (path.isBlank()) return
        try {
            val file = File(path)
            if (file.exists() && file.absolutePath.startsWith(baseStorageDir.absolutePath)) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun deleteReportSnapshots(reportId: Long) {
        try {
            val dir = File(reportSnapshotsDir, "report_$reportId")
            if (dir.exists()) dir.deleteRecursively()
        } catch (_: Exception) {
        }
    }

    fun decodeSampledBitmap(path: String, maxDimension: Int = 1200): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists()) return null
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        if (opts.outWidth > 0 && opts.outHeight > 0) {
            var inSample = 1
            while (opts.outWidth / inSample > maxDimension || opts.outHeight / inSample > maxDimension) {
                inSample *= 2
            }
            val decoded = BitmapFactory.decodeFile(
                file.absolutePath,
                BitmapFactory.Options().apply { inSampleSize = inSample },
            )
            if (decoded != null) return decoded
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return try {
                val src = ImageDecoder.createSource(file)
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val w = info.size.width
                    val h = info.size.height
                    val maxSide = maxOf(w, h)
                    if (maxSide > maxDimension && maxSide > 0) {
                        val ratio = maxDimension.toFloat() / maxSide.toFloat()
                        decoder.setTargetSize(
                            (w * ratio).toInt().coerceAtLeast(1),
                            (h * ratio).toInt().coerceAtLeast(1),
                        )
                    }
                }
            } catch (_: Exception) {
                null
            }
        }
        return null
    }

    private fun readBoundedBytesFromUri(uri: Uri, maxBytes: Long): ByteArray? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val read = input.read(buf)
                    if (read < 0) break
                    total += read
                    if (total > maxBytes) return null
                    out.write(buf, 0, read)
                }
                out.toByteArray()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun decodeWithImageDecoder(bytes: ByteArray, maxDim: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
        return try {
            val src = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val maxSide = maxOf(w, h)
                if (maxSide > maxDim && maxSide > 0) {
                    val ratio = maxDim.toFloat() / maxSide.toFloat()
                    decoder.setTargetSize(
                        (w * ratio).toInt().coerceAtLeast(1),
                        (h * ratio).toInt().coerceAtLeast(1),
                    )
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isReadableImageFile(file: File): Boolean {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        if (opts.outWidth > 0 && opts.outHeight > 0) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return try {
                var valid = false
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { _, info, _ ->
                    valid = info.size.width > 0 && info.size.height > 0
                }
                valid
            } catch (_: Exception) {
                false
            }
        }
        return false
    }

    private fun decodeAndOrientBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, bounds)
        }
        var sample = 1
        if (bounds.outWidth > 0 && bounds.outHeight > 0) {
            while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) {
                sample *= 2
            }
        }
        val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null

        val orientation = try {
            context.contentResolver.openInputStream(uri)?.use { exifStream ->
                ExifInterface(exifStream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return scaleDownIfHuge(rawBitmap, 2048, recycleSource = true)

        val matrix = Matrix().apply { postRotate(degrees) }
        val rotated = Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
        if (rotated != rawBitmap) rawBitmap.recycle()
        return scaleDownIfHuge(rotated, 2048, recycleSource = true)
    }

    private fun scaleDownIfHuge(bitmap: Bitmap, maxDim: Int, recycleSource: Boolean): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / maxSide.toFloat()
        val targetW = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetH = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        if (recycleSource && scaled != bitmap) bitmap.recycle()
        return scaled
    }

    private fun saveBitmapToFile(bitmap: Bitmap, dir: File, fileName: String): String {
        val outFile = File(dir, fileName)
        FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return outFile.absolutePath
    }
}
