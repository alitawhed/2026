package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ErrorLogEntity
import com.example.data.local.entity.OperationLogEntity

@Dao
interface DiagnosticsDao {
    @Query("SELECT * FROM ErrorLogs ORDER BY lastSeenAt DESC LIMIT :limit")
    suspend fun getRecentErrorsOnce(limit: Int = 400): List<ErrorLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertError(error: ErrorLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertErrors(errors: List<ErrorLogEntity>)

    @Query("UPDATE ErrorLogs SET isReviewed = :reviewed WHERE errorId = :errorId")
    suspend fun setErrorReviewed(errorId: String, reviewed: Boolean)

    @Query("UPDATE ErrorLogs SET isReviewed = 1")
    suspend fun markAllErrorsReviewed()

    @Query("DELETE FROM ErrorLogs")
    suspend fun clearAllErrors()

    @Query("SELECT * FROM OperationLogs ORDER BY startTime DESC LIMIT :limit")
    suspend fun getRecentOperationsOnce(limit: Int = 500): List<OperationLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOperation(operation: OperationLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOperations(operations: List<OperationLogEntity>)

    @Query("DELETE FROM OperationLogs")
    suspend fun clearAllOperations()
}
