package com.example.data.storage

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import androidx.room.withTransaction
import coil.request.ImageRequest
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductImageEntity
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface ImageResolution {
    data class Available(
        val file: File,
        val cacheKey: String,
        val width: Int,
        val height: Int,
        val usedFallback: Boolean = false,
    ) : ImageResolution

    data class Missing(val rawPath: String) : ImageResolution
    data class Corrupted(val file: File, val reason: String) : ImageResolution
    data object Empty : ImageResolution
}

data class ProductImageAuditIssue(
    val productId: Long,
    val productName: String,
    val internalCode: String,
    val imageId: Long,
    val recordedPath: String,
    val issueType: String,
    val isRepairable: Boolean,
)

data class ImageDiagnosticReport(
    val totalProducts: Int = 0,
    val productsWithImages: Int = 0,
    val totalImageRecords: Int = 0,
    val loadableCount: Int = 0,
    val missingFilesCount: Int = 0,
    val corruptedCount: Int = 0,
    val missingThumbnailCount: Int = 0,
    val repairableCount: Int = 0,
    val issues: List<ProductImageAuditIssue> = emptyList(),
)

data class ImageRepairResult(
    val backupFilePath: String?,
    val repairedCount: Int,
    val thumbnailsRebuiltCount: Int,
    val unrecoverableCount: Int,
    val reportAfter: ImageDiagnosticReport,
)

class ImageService(
    private val context: Context,
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {

    fun cleanPath(rawPath: String?): String = ImageService.cleanPath(rawPath)

    fun resolveProductImage(
        image: ProductImageEntity?,
        preferThumbnail: Boolean,
        refreshTag: Int = 0,
    ): ImageResolution = ImageService.resolveProductImageStateless(image, preferThumbnail, refreshTag)

    fun resolveRawPath(
        path: String?,
        refreshTag: Int = 0,
    ): ImageResolution = ImageService.resolveRawPathStateless(path, refreshTag)

    fun resolveInventoryImage(
        snapshotPath: String?,
        product: com.example.data.local.entity.ProductWithDetails?,
        preferThumbnail: Boolean = true,
        refreshTag: Int = 0,
    ): ImageResolution = ImageService.resolveInventoryItemImageStateless(snapshotPath, product, preferThumbnail, refreshTag)

    fun buildCoilRequest(
        resolution: ImageResolution.Available,
        crossfade: Boolean = true,
    ): ImageRequest {
        return ImageRequest.Builder(context)
            .data(resolution.file)
            .memoryCacheKey(resolution.cacheKey)
            .diskCacheKey(resolution.cacheKey)
            .crossfade(crossfade)
            .build()
    }

    companion object {
        fun cleanPath(rawPath: String?): String {
            if (rawPath.isNullOrBlank()) return ""
            var clean = rawPath.trim()
            if (clean.startsWith("file://", ignoreCase = true)) {
                clean = clean.removePrefix("file://")
            }
            val queryIdx = clean.indexOf('?')
            if (queryIdx > 0) {
                val candidateWithoutQuery = clean.substring(0, queryIdx)
                if (!File(clean).exists() && File(candidateWithoutQuery).exists()) {
                    clean = candidateWithoutQuery
                } else if (clean.substring(queryIdx).startsWith("?t=")) {
                    clean = candidateWithoutQuery
                }
            }
            return clean
        }

        fun resolveProductImageStateless(
            image: ProductImageEntity?,
            preferThumbnail: Boolean = true,
            refreshTag: Int = 0,
        ): ImageResolution {
            if (image == null) return ImageResolution.Empty
            val candidates = if (preferThumbnail) {
                listOf(image.thumbnailPath, image.filePath, image.originalFilePath)
            } else {
                listOf(image.filePath, image.originalFilePath, image.thumbnailPath)
            }
            return resolveFromCandidates(candidates, refreshTag)
        }

        fun resolveRawPathStateless(
            path: String?,
            refreshTag: Int = 0,
        ): ImageResolution {
            if (path.isNullOrBlank()) return ImageResolution.Empty
            return resolveFromCandidates(listOf(path), refreshTag)
        }

        fun resolveInventoryItemImageStateless(
            snapshotPath: String?,
            product: com.example.data.local.entity.ProductWithDetails?,
            preferThumbnail: Boolean = true,
            refreshTag: Int = 0,
        ): ImageResolution {
            val primary = product?.primaryImage
            val candidates = buildList {
                if (!snapshotPath.isNullOrBlank()) add(snapshotPath)
                if (primary != null) {
                    if (preferThumbnail) {
                        add(primary.thumbnailPath)
                        add(primary.filePath)
                        add(primary.originalFilePath)
                    } else {
                        add(primary.filePath)
                        add(primary.originalFilePath)
                        add(primary.thumbnailPath)
                    }
                }
            }
            return resolveFromCandidates(candidates, refreshTag)
        }

        fun resolveFromCandidates(
            rawCandidates: List<String>,
            refreshTag: Int = 0,
        ): ImageResolution {
            val cleaned = rawCandidates.map { cleanPath(it) }.filter { it.isNotBlank() }.distinct()
            if (cleaned.isEmpty()) return ImageResolution.Empty

            var lastMissing: String? = null
            var lastCorrupted: File? = null

            cleaned.forEachIndexed { idx, path ->
                val file = File(path)
                if (!file.exists() || !file.isFile || file.length() <= 0L) {
                    if (lastMissing == null) lastMissing = path
                } else {
                    val bounds = readImageBounds(file)
                    if (bounds != null) {
                        val key = "${file.absolutePath}:${file.length()}:${file.lastModified()}:$refreshTag"
                        return ImageResolution.Available(
                            file = file,
                            cacheKey = key,
                            width = bounds.first,
                            height = bounds.second,
                            usedFallback = idx > 0,
                        )
                    } else {
                        if (lastCorrupted == null) lastCorrupted = file
                    }
                }
            }

            lastCorrupted?.let {
                return ImageResolution.Corrupted(it, "الملف موجود لكنه تالف أو بصيغة غير مدعومة")
            }
            return ImageResolution.Missing(lastMissing.orEmpty())
        }

        private fun readImageBounds(file: File): Pair<Int, Int>? {
            try {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, opts)
                if (opts.outWidth > 0 && opts.outHeight > 0) {
                    return opts.outWidth to opts.outHeight
                }
            } catch (_: Exception) {
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    var dims: Pair<Int, Int>? = null
                    val src = ImageDecoder.createSource(file)
                    val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        if (info.size.width > 0 && info.size.height > 0) {
                            dims = info.size.width to info.size.height
                        }
                    }
                    if (!bmp.isRecycled) bmp.recycle()
                    if (dims != null) return dims
                } catch (_: Exception) {
                }
            }
            return null
        }
    }

    suspend fun auditAllProductImages(): ImageDiagnosticReport = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.IMAGES,
            moduleName = DiagnosticModules.IMAGES,
            operationName = "فحص سلامة صور المنتجات",
            initialStage = "قراءة سجلات المنتجات والصور",
        )
        try {
            val products = db.productDao().getAllProductsWithDetailsOnce()
            var withImages = 0
            var totalRecords = 0
            var loadable = 0
            var missing = 0
            var corrupted = 0
            var missingThumbs = 0
            var repairable = 0
            val issues = mutableListOf<ProductImageAuditIssue>()

            for (p in products) {
                if (p.images.isNotEmpty()) withImages++
                for (img in p.images) {
                    totalRecords++
                    val cleanActive = cleanPath(img.filePath)
                    val cleanOrig = cleanPath(img.originalFilePath)

                    val activeRes = resolveFromCandidates(listOf(img.filePath), 0)
                    val origRes = resolveFromCandidates(listOf(img.originalFilePath), 0)
                    val thumbRes = resolveFromCandidates(listOf(img.thumbnailPath), 0)

                    val anyValid = activeRes is ImageResolution.Available ||
                        origRes is ImageResolution.Available ||
                        thumbRes is ImageResolution.Available

                    if (thumbRes !is ImageResolution.Available && anyValid) {
                        missingThumbs++
                    }

                    when {
                        activeRes is ImageResolution.Available && cleanActive == img.filePath -> {
                            loadable++
                        }
                        activeRes is ImageResolution.Available && cleanActive != img.filePath -> {
                            // Needs path normalization (e.g. had ?t= or file://)
                            loadable++
                            repairable++
                            issues.add(
                                ProductImageAuditIssue(
                                    productId = p.product.id,
                                    productName = p.product.name,
                                    internalCode = p.product.internalCode,
                                    imageId = img.id,
                                    recordedPath = img.filePath,
                                    issueType = "مسار يحتوي على لاحقة أو صيغة غير قياسية",
                                    isRepairable = true,
                                ),
                            )
                        }
                        origRes is ImageResolution.Available || thumbRes is ImageResolution.Available -> {
                            missing++
                            repairable++
                            issues.add(
                                ProductImageAuditIssue(
                                    productId = p.product.id,
                                    productName = p.product.name,
                                    internalCode = p.product.internalCode,
                                    imageId = img.id,
                                    recordedPath = img.filePath,
                                    issueType = "ملف العرض مفقود لكن توجد نسخة أصلية/مصغرة قابلة للاستعادة",
                                    isRepairable = true,
                                ),
                            )
                        }
                        activeRes is ImageResolution.Corrupted -> {
                            corrupted++
                            issues.add(
                                ProductImageAuditIssue(
                                    productId = p.product.id,
                                    productName = p.product.name,
                                    internalCode = p.product.internalCode,
                                    imageId = img.id,
                                    recordedPath = img.filePath,
                                    issueType = "ملف الصورة تالف ولا يمكن فك ترميزه",
                                    isRepairable = false,
                                ),
                            )
                        }
                        else -> {
                            missing++
                            issues.add(
                                ProductImageAuditIssue(
                                    productId = p.product.id,
                                    productName = p.product.name,
                                    internalCode = p.product.internalCode,
                                    imageId = img.id,
                                    recordedPath = img.filePath,
                                    issueType = "الملف غير موجود على وحدة التخزين (${cleanOrig.ifBlank { cleanActive }})",
                                    isRepairable = false,
                                ),
                            )
                        }
                    }
                }
            }

            val report = ImageDiagnosticReport(
                totalProducts = products.size,
                productsWithImages = withImages,
                totalImageRecords = totalRecords,
                loadableCount = loadable,
                missingFilesCount = missing,
                corruptedCount = corrupted,
                missingThumbnailCount = missingThumbs,
                repairableCount = repairable,
                issues = issues,
            )
            trace?.succeed("سليمة=$loadable | مفقودة=$missing | تالفة=$corrupted | قابلة للإصلاح=$repairable")
            report
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء فحص الصور")
            throw c
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "فحص سلامة صور المنتجات", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(t.message ?: "تعذر فحص الصور", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }

    suspend fun repairBrokenImageReferences(
        backupEngine: BackupRestoreEngine? = null,
        createBackupFirst: Boolean = true,
    ): ImageRepairResult = withContext(Dispatchers.IO) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.IMAGES,
            moduleName = DiagnosticModules.IMAGES,
            operationName = "إصلاح مراجع ومصغرات الصور",
            initialStage = "الفحص الأولي للصور",
        )
        try {
            val before = auditAllProductImages()
            val backupPath = if (createBackupFirst && backupEngine != null &&
                (before.repairableCount > 0 || before.missingThumbnailCount > 0)
            ) {
                trace?.stage("إنشاء نسخة احتياطية وقائية قبل الإصلاح")
                backupEngine.createBackupZip("pre_image_repair_${System.currentTimeMillis()}").getOrNull()?.absolutePath
            } else null

            trace?.stage("معالجة المراجع والملفات", "صور=${before.totalImageRecords}")
            var repaired = 0
            var thumbsRebuilt = 0
            var unrecoverable = 0

            val allImages = db.productDao().getAllImagesOnce()
            val toUpdate = mutableListOf<ProductImageEntity>()

            for (img in allImages) {
                val cleanActive = cleanPath(img.filePath)
                val cleanOrig = cleanPath(img.originalFilePath)
                val cleanThumb = cleanPath(img.thumbnailPath)

                val activeValid = resolveFromCandidates(listOf(cleanActive), 0) is ImageResolution.Available
                val origValid = resolveFromCandidates(listOf(cleanOrig), 0) is ImageResolution.Available
                val thumbValid = resolveFromCandidates(listOf(cleanThumb), 0) is ImageResolution.Available

                var newActive = cleanActive
                var newOrig = cleanOrig
                var newThumb = cleanThumb
                var changed = (cleanActive != img.filePath || cleanOrig != img.originalFilePath || cleanThumb != img.thumbnailPath)

                if (!activeValid) {
                    val recoverySource = when {
                        origValid -> File(cleanOrig)
                        thumbValid -> File(cleanThumb)
                        else -> null
                    }
                    if (recoverySource != null) {
                        val dest = File(
                            mediaStorage.productImagesDir,
                            "prod_recovered_${UUID.randomUUID()}.${recoverySource.extension.ifBlank { "png" }}",
                        )
                        try {
                            recoverySource.copyTo(dest, overwrite = true)
                            newActive = dest.absolutePath
                            changed = true
                            repaired++
                        } catch (e: Exception) {
                            unrecoverable++
                            errorMonitor?.recordError(
                                e,
                                ScreenNames.IMAGES,
                                DiagnosticModules.IMAGES,
                                "إصلاح مسار صورة منتج",
                                linkedOperationId = trace?.operationId.orEmpty(),
                            )
                        }
                    } else {
                        unrecoverable++
                    }
                } else if (changed) {
                    repaired++
                }

                val activeNowValid = resolveFromCandidates(listOf(newActive), 0) is ImageResolution.Available
                if (activeNowValid) {
                    if (newOrig.isBlank() || resolveFromCandidates(listOf(newOrig), 0) !is ImageResolution.Available) {
                        val backedUp = mediaStorage.ensureOriginalBackup(newActive, "")
                        if (backedUp.isNotBlank()) {
                            newOrig = backedUp
                            changed = true
                        }
                    }
                    if (!thumbValid || newThumb.isBlank()) {
                        val generatedThumb = mediaStorage.generateThumbnail(newActive)
                        if (generatedThumb.isNotBlank()) {
                            newThumb = generatedThumb
                            changed = true
                            thumbsRebuilt++
                        }
                    }
                }

                if (changed) {
                    toUpdate.add(
                        img.copy(
                            filePath = newActive,
                            originalFilePath = newOrig,
                            thumbnailPath = newThumb,
                        ),
                    )
                }
            }

            if (toUpdate.isNotEmpty()) {
                trace?.stage("تحديث مراجع الصور في قاعدة البيانات", "تحديثات=${toUpdate.size}")
                db.withTransaction {
                    db.productDao().updateImages(toUpdate)
                }
            }

            val after = auditAllProductImages()
            trace?.succeed("أُصلح=$repaired | مصغرات=$thumbsRebuilt | غير قابل للاستعادة=$unrecoverable")
            ImageRepairResult(
                backupFilePath = backupPath,
                repairedCount = repaired,
                thumbnailsRebuiltCount = thumbsRebuilt,
                unrecoverableCount = unrecoverable,
                reportAfter = after,
            )
        } catch (c: CancellationException) {
            trace?.cancel("تم إلغاء إصلاح مراجع الصور")
            throw c
        } catch (t: Throwable) {
            val err = errorMonitor?.recordError(t, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "إصلاح مراجع ومصغرات الصور", linkedOperationId = trace?.operationId.orEmpty())
            trace?.fail(t.message ?: "تعذر إصلاح الصور", linkedErrorId = err?.errorId.orEmpty())
            throw t
        }
    }
}
