package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "Products",
    indices = [
        Index(value = ["internalCode"]),
        Index(value = ["name"]),
        Index(value = ["categoryName"]),
        Index(value = ["originCountry"]),
    ],
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val internalCode: String = "",
    val name: String,
    val description: String = "",
    val categoryId: Long? = null,
    val categoryName: String = "",
    val basePrice: Double = 0.0,
    val currency: String = "ر.س",
    val originCountry: String = "",
    val manufacturer: String = "",
    val defaultQuantity: Double = 1.0,
    val notes: String = "",
    val customFieldsJson: String = "{}",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
