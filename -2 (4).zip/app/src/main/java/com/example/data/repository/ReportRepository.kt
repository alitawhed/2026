package com.example.data.repository

import android.net.Uri
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.TemplateDefaults.toEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.local.entity.ReportColumnEntity
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemBarcodeEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportItemImageEntity
import com.example.data.local.entity.ReportTemplateEntity
import com.example.data.local.entity.ReportWithDetails
import com.example.data.storage.ImageEditParameters
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.DuplicateProductBehavior
import com.example.domain.model.ReportImageSourceType
import com.example.domain.model.ReportRowSortMode
import com.example.domain.model.SaveStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

sealed class AddProductToReportResult {
    data class Added(val itemId: Long) : AddProductToReportResult()
    data class IncrementedExisting(val itemId: Long, val newQty: Double) : AddProductToReportResult()
    data object PreventedDuplicate : AddProductToReportResult()
}

data class ReportProductPickRequest(
    val product: ProductWithDetails,
    val selectedBarcodeOverride: String? = null,
    val selectedImageId: Long? = null,
    val selectedImagePathOverride: String? = null,
)

data class BatchAddToReportResult(
    val addedCount: Int,
    val incrementedCount: Int,
    val skippedCount: Int,
)

class ReportRepository(
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val barcodeService: com.example.domain.barcode.BarcodeService? = null,
) {
    private val reportDao = db.reportDao()
    private val productDao = db.productDao()
    private val templateDao = db.templateDao()
    private val settingsDao = db.settingsDao()

    private val _saveStatus = MutableStateFlow(SaveStatus.IDLE)
    val saveStatus: StateFlow<SaveStatus> = _saveStatus.asStateFlow()

    val allReports: Flow<List<ReportWithDetails>> = reportDao.observeAllReportsWithDetails()
    val archivedReports: Flow<List<ReportWithDetails>> = reportDao.observeArchivedReports()
    val recentReports: Flow<List<ReportWithDetails>> = reportDao.observeRecentReports(5)
    val totalReportCount: Flow<Int> = reportDao.observeTotalReportCount()
    val savedReportCount: Flow<Int> = reportDao.observeSavedReportCount()
    val archivedReportCount: Flow<Int> = reportDao.observeArchivedReportCount()

    fun observeTodaysReportCount(): Flow<Int> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return reportDao.observeTodaysReportCount(cal.timeInMillis)
    }

    fun observeReport(reportId: Long): Flow<ReportWithDetails?> =
        reportDao.observeReportWithDetails(reportId)

    suspend fun getReportOnce(reportId: Long): ReportWithDetails? =
        reportDao.getReportWithDetails(reportId)

    /**
     * Always creates an EMPTY report (0 items). Products are only added explicitly by the user.
     */
    suspend fun createEmptyReport(templateId: Long? = null, customTitle: String = ""): Long {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "إنشاء تقرير جديد",
            initialStage = "تحميل الإعدادات والقالب",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val id = db.withTransaction {
                val settings = settingsDao.getSettingsOnce()
                val template = templateId?.let { templateDao.getTemplateById(it) }
                    ?: templateDao.getDefaultTemplate()
                    ?: TemplateDefaults.buildBuiltInTemplates().first()

                val dateTag = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                val count = reportDao.getAllReportsWithDetailsOnce().size + 1
                val reportNum = "RPT-$dateTag-${count.toString().padStart(3, '0')}"

                val report = ReportEntity(
                    reportNumber = reportNum,
                    title = customTitle.ifBlank { "${template.name} - $reportNum" },
                    reportDate = System.currentTimeMillis(),
                    currency = settings?.defaultCurrency ?: "ر.س",
                    companyName = settings?.companyName ?: "",
                    companyAddress = settings?.companyAddress ?: "",
                    companyPhone = settings?.companyPhone ?: "",
                    companyLogoPath = settings?.companyLogoPath ?: "",
                    headerTitle = settings?.headerDefaultText ?: template.name,
                    responsiblePerson = "",
                    templateId = template.id,
                    paperSize = template.paperSize,
                    customWidthMm = template.customWidthMm,
                    customHeightMm = template.customHeightMm,
                    orientation = template.orientation,
                    marginTopMm = template.marginTopMm,
                    marginBottomMm = template.marginBottomMm,
                    marginStartMm = template.marginStartMm,
                    marginEndMm = template.marginEndMm,
                    columnDistributionMode = template.distributionMode,
                    headerFooterConfigJson = template.headerFooterConfigJson,
                    barcodeStyleConfigJson = template.barcodeStyleConfigJson,
                    rowSortMode = ReportRowSortMode.MANUAL.name,
                    isArchived = false,
                    isSaved = true,
                )
                trace?.stage("إدراج التقرير والأعمدة في قاعدة البيانات")
                val newReportId = reportDao.insertReport(report)
                val templateColumns = TemplateDefaults.decodeColumns(template.columnsConfigJson)
                val columnEntities = templateColumns.mapIndexed { idx, col ->
                    col.copy(id = 0L, sortOrder = idx).toEntity(newReportId)
                }
                if (columnEntities.isNotEmpty()) {
                    reportDao.insertColumns(columnEntities)
                }
                newReportId
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم إنشاء التقرير #$id")
            id
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.REPORT_EDITOR,
                DiagnosticModules.REPORTS,
                "إنشاء تقرير جديد",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر إنشاء التقرير", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun applyTemplateToReport(reportId: Long, template: ReportTemplateEntity) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "تطبيق قالب على التقرير",
            initialStage = "نسخ خصائص القالب والأعمدة",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                val existing = reportDao.getReportWithDetails(reportId)?.report ?: return@withTransaction
                reportDao.updateReport(
                    existing.copy(
                        templateId = template.id,
                        paperSize = template.paperSize,
                        customWidthMm = template.customWidthMm,
                        customHeightMm = template.customHeightMm,
                        orientation = template.orientation,
                        marginTopMm = template.marginTopMm,
                        marginBottomMm = template.marginBottomMm,
                        marginStartMm = template.marginStartMm,
                        marginEndMm = template.marginEndMm,
                        columnDistributionMode = template.distributionMode,
                        headerFooterConfigJson = template.headerFooterConfigJson,
                        barcodeStyleConfigJson = template.barcodeStyleConfigJson,
                        updatedAt = System.currentTimeMillis(),
                    ),
                )
                reportDao.deleteColumnsForReport(reportId)
                val cols = TemplateDefaults.decodeColumns(template.columnsConfigJson)
                    .mapIndexed { idx, col -> col.copy(id = 0L, sortOrder = idx).toEntity(reportId) }
                if (cols.isNotEmpty()) reportDao.insertColumns(cols)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed(template.name)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.REPORT_EDITOR,
                DiagnosticModules.REPORTS,
                "تطبيق قالب على التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر تطبيق القالب", err?.errorId.orEmpty())
        }
    }

    suspend fun updateReport(report: ReportEntity) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            reportDao.updateReport(report.copy(updatedAt = System.currentTimeMillis(), isSaved = true))
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "تحديث بيانات التقرير")
        }
    }

    /**
     * Adds a product to a report as a deep immutable snapshot (copies chosen/primary image into report snapshot dir
     * and clones all barcodes into ReportItemBarcodes). Never mutates the source ProductEntity or ProductImages.
     */
    suspend fun addProductToReport(
        reportId: Long,
        product: ProductWithDetails,
        selectedBarcodeOverride: String? = null,
        selectedImageId: Long? = null,
        selectedImagePathOverride: String? = null,
    ): AddProductToReportResult {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "إضافة منتج إلى التقرير",
            initialStage = "نسخ اللقطة المستقلة للصنف",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val result = db.withTransaction {
                insertProductIntoReportLocked(
                    reportId = reportId,
                    request = ReportProductPickRequest(
                        product = product,
                        selectedBarcodeOverride = selectedBarcodeOverride,
                        selectedImageId = selectedImageId,
                        selectedImagePathOverride = selectedImagePathOverride,
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed(product.product.name)
            result
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.REPORT_EDITOR,
                DiagnosticModules.REPORTS,
                "إضافة منتج إلى التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر إضافة المنتج للتقرير", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun addProductsBatchToReport(
        reportId: Long,
        requests: List<ReportProductPickRequest>,
    ): BatchAddToReportResult {
        if (requests.isEmpty()) return BatchAddToReportResult(0, 0, 0)
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_PICKER,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "إضافة مجموعة منتجات للتقرير",
            initialStage = "إدراج ${requests.size} أصناف داخل التقرير",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val summary = db.withTransaction {
                var added = 0
                var incremented = 0
                var skipped = 0
                requests.forEach { req ->
                    when (insertProductIntoReportLocked(reportId, req)) {
                        is AddProductToReportResult.Added -> added++
                        is AddProductToReportResult.IncrementedExisting -> incremented++
                        AddProductToReportResult.PreventedDuplicate -> skipped++
                    }
                }
                BatchAddToReportResult(added, incremented, skipped)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("أضيف ${summary.addedCount}، زيد ${summary.incrementedCount}")
            summary
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.REPORT_PICKER,
                DiagnosticModules.REPORTS,
                "إضافة مجموعة منتجات للتقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر الإضافة الجماعية للتقرير", err?.errorId.orEmpty())
            throw e
        }
    }

    private suspend fun insertProductIntoReportLocked(
        reportId: Long,
        request: ReportProductPickRequest,
    ): AddProductToReportResult {
        val product = request.product
        val reportDetails = reportDao.getReportWithDetails(reportId)
            ?: throw IllegalStateException("التقرير غير موجود")
        val behavior = DuplicateProductBehavior.fromString(reportDetails.report.duplicateBehavior)
        val existingMatch = reportDetails.items.firstOrNull {
            it.item.sourceProductId == product.product.id
        }

        if (existingMatch != null) {
            when (behavior) {
                DuplicateProductBehavior.PREVENT -> return AddProductToReportResult.PreventedDuplicate
                DuplicateProductBehavior.INCREMENT_QTY -> {
                    val newQty = existingMatch.item.quantity + product.product.defaultQuantity.coerceAtLeast(1.0)
                    val updatedItem = recalcLineTotal(existingMatch.item.copy(quantity = newQty))
                    reportDao.updateReportItem(updatedItem)
                    reportDao.updateReport(reportDetails.report.copy(updatedAt = System.currentTimeMillis()))
                    return AddProductToReportResult.IncrementedExisting(updatedItem.id, newQty)
                }
                DuplicateProductBehavior.NEW_ROW -> Unit
            }
        }

        val chosenImageEntity: ProductImageEntity? = when {
            request.selectedImageId != null -> product.images.firstOrNull { it.id == request.selectedImageId }
            !request.selectedImagePathOverride.isNullOrBlank() -> product.images.firstOrNull {
                it.filePath == request.selectedImagePathOverride || it.originalFilePath == request.selectedImagePathOverride
            }
            else -> product.primaryImage
        } ?: product.primaryImage

        val resolvedPrimarySourcePath = resolveExistingFilePath(
            request.selectedImagePathOverride,
            chosenImageEntity?.filePath,
            chosenImageEntity?.originalFilePath,
            chosenImageEntity?.thumbnailPath,
        )
        val snapshotImagePath = if (resolvedPrimarySourcePath.isNotBlank()) {
            mediaStorage.copyToReportSnapshot(resolvedPrimarySourcePath, reportId)
        } else ""

        val chosenBarcode = request.selectedBarcodeOverride?.let { valStr ->
            product.barcodes.firstOrNull { it.barcodeValue == valStr }
        } ?: product.primaryBarcode

        val nextSort = (reportDetails.items.maxOfOrNull { it.item.sortOrder } ?: -1) + 1
        val nextSerial = reportDetails.items.size + 1

        val defaultFmt = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
            settingsDao.getSettingsOnce()?.defaultBarcodeType,
        ) ?: com.example.domain.model.BarcodeFormatType.CODE_128
        val chosenBcValue = chosenBarcode?.barcodeValue.orEmpty()
        val resolvedBcType = chosenBarcode?.barcodeType?.takeIf { it.isNotBlank() }
            ?: if (chosenBcValue.isNotBlank()) {
                com.example.domain.barcode.BarcodeEngine
                    .resolveCompatibleDefaultFormat(chosenBcValue, defaultFmt)
                    .name
            } else {
                defaultFmt.name
            }

        val newItem = recalcLineTotal(
            ReportItemEntity(
                reportId = reportId,
                sourceProductId = product.product.id,
                sortOrder = nextSort,
                serialNumber = nextSerial,
                productNameSnapshot = product.product.name,
                descriptionSnapshot = product.product.description,
                categorySnapshot = product.product.categoryName,
                originCountrySnapshot = product.product.originCountry,
                manufacturerSnapshot = product.product.manufacturer,
                primaryBarcodeSnapshot = chosenBcValue,
                primaryBarcodeTypeSnapshot = resolvedBcType,
                imageSnapshotPath = snapshotImagePath,
                unitPrice = product.product.basePrice,
                quantity = product.product.defaultQuantity.coerceAtLeast(1.0),
                discountPercent = 0.0,
                discountAmount = 0.0,
                notes = product.product.notes,
                customFieldsJson = product.product.customFieldsJson,
            ),
        )
        val insertedItemId = reportDao.insertReportItem(newItem)

        if (product.barcodes.isNotEmpty()) {
            reportDao.insertReportItemBarcodes(
                product.barcodes.map { b ->
                    ReportItemBarcodeEntity(
                        reportItemId = insertedItemId,
                        barcodeValue = b.barcodeValue,
                        barcodeType = b.barcodeType,
                        label = b.label,
                        isPrimary = b.barcodeValue == newItem.primaryBarcodeSnapshot,
                    )
                },
            )
        }

        val now = System.currentTimeMillis()
        val orderedProductImages = product.images.sortedWith(
            compareByDescending<ProductImageEntity> {
                chosenImageEntity != null && it.id == chosenImageEntity.id
            }.thenBy { it.sortOrder },
        )

        if (orderedProductImages.isNotEmpty()) {
            val itemImages = orderedProductImages.mapIndexedNotNull { idx, img ->
                val isSelectedPrimary = (chosenImageEntity != null && img.id == chosenImageEntity.id) ||
                    (chosenImageEntity == null && idx == 0)
                val snapPath = if (isSelectedPrimary && snapshotImagePath.isNotBlank()) {
                    snapshotImagePath
                } else {
                    val altPath = resolveExistingFilePath(img.filePath, img.originalFilePath, img.thumbnailPath)
                    if (altPath.isNotBlank()) mediaStorage.copyToReportSnapshot(altPath, reportId) else ""
                }
                if (snapPath.isBlank()) null
                else {
                    val sourceType = when {
                        isSelectedPrimary && request.selectedImageId != null && !img.isPrimary ->
                            ReportImageSourceType.PRODUCT_GALLERY.name
                        isSelectedPrimary -> ReportImageSourceType.PRODUCT_PRIMARY.name
                        else -> ReportImageSourceType.PRODUCT_GALLERY.name
                    }
                    ReportItemImageEntity(
                        reportItemId = insertedItemId,
                        reportId = reportId,
                        sourceProductId = product.product.id,
                        sourceImageId = img.id,
                        filePath = snapPath,
                        imageSourceType = sourceType,
                        isPrimary = isSelectedPrimary,
                        sortOrder = idx,
                        addedAt = now,
                    )
                }
            }
            if (itemImages.isNotEmpty()) {
                reportDao.insertReportItemImages(itemImages)
            }
        } else if (snapshotImagePath.isNotBlank()) {
            reportDao.insertReportItemImages(
                listOf(
                    ReportItemImageEntity(
                        reportItemId = insertedItemId,
                        reportId = reportId,
                        sourceProductId = product.product.id,
                        sourceImageId = chosenImageEntity?.id,
                        filePath = snapshotImagePath,
                        imageSourceType = ReportImageSourceType.PRODUCT_GALLERY.name,
                        isPrimary = true,
                        sortOrder = 0,
                        addedAt = now,
                    ),
                ),
            )
        }

        reportDao.updateReport(reportDetails.report.copy(updatedAt = now))
        return AddProductToReportResult.Added(insertedItemId)
    }

    suspend fun updateReportItem(item: ReportItemEntity) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                // Preserves manual sortOrder and serialNumber strictly!
                reportDao.updateReportItem(recalcLineTotal(item))
                reportDao.getReportWithDetails(item.reportId)?.report?.let {
                    reportDao.updateReport(it.copy(updatedAt = System.currentTimeMillis()))
                }
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "تحديث بند في التقرير")
        }
    }

    suspend fun deleteReportItem(reportId: Long, itemId: Long) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                reportDao.deleteReportItemById(itemId)
                // Re-number serial numbers cleanly; NEVER deletes product or product images!
                val remaining = reportDao.getReportWithDetails(reportId)?.sortedItems.orEmpty()
                if (remaining.isNotEmpty()) {
                    reportDao.updateReportItems(
                        remaining.mapIndexed { idx, row ->
                            row.item.copy(sortOrder = idx, serialNumber = idx + 1)
                        },
                    )
                }
                reportDao.getReportWithDetails(reportId)?.report?.let {
                    reportDao.updateReport(it.copy(updatedAt = System.currentTimeMillis()))
                }
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "حذف بند من التقرير")
        }
    }

    // ==================== Stage 5: Full Report Row Ordering & Batch Manipulation ====================

    /**
     * Atomically applies an explicit row order by [orderedItemIds], renumbering both
     * sortOrder (0..N-1) and serialNumber (1..N) completely independent of sourceProductId.
     * Switches report.rowSortMode to MANUAL so future edits preserve user ordering.
     */
    suspend fun reorderReportRows(reportId: Long, orderedItemIds: List<Long>) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                val details = reportDao.getReportWithDetails(reportId) ?: return@withTransaction
                val byId = details.sortedItems.associateBy { it.item.id }
                val reordered = buildList {
                    orderedItemIds.forEach { id -> byId[id]?.let { add(it.item) } }
                    val seen = orderedItemIds.toHashSet()
                    details.sortedItems.forEach { row ->
                        if (row.item.id !in seen) add(row.item)
                    }
                }
                if (reordered.isNotEmpty()) {
                    reportDao.updateReportItems(
                        reordered.mapIndexed { idx, item ->
                            item.copy(sortOrder = idx, serialNumber = idx + 1)
                        },
                    )
                }
                reportDao.updateReport(
                    details.report.copy(
                        rowSortMode = ReportRowSortMode.MANUAL.name,
                        updatedAt = System.currentTimeMillis(),
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "إعادة ترتيب صفوف التقرير")
        }
    }

    suspend fun moveReportRow(reportId: Long, fromIndex: Int, toIndex: Int) {
        val items = reportDao.getReportWithDetails(reportId)?.sortedItems.orEmpty()
        if (fromIndex !in items.indices || toIndex !in items.indices || fromIndex == toIndex) return
        val ids = items.map { it.item.id }.toMutableList()
        val moved = ids.removeAt(fromIndex)
        ids.add(toIndex, moved)
        reorderReportRows(reportId, ids)
    }

    suspend fun moveReportRowToPosition(reportId: Long, itemId: Long, oneBasedTargetPosition: Int) {
        val items = reportDao.getReportWithDetails(reportId)?.sortedItems.orEmpty()
        if (items.isEmpty()) return
        val fromIdx = items.indexOfFirst { it.item.id == itemId }
        if (fromIdx < 0) return
        val targetIdx = (oneBasedTargetPosition - 1).coerceIn(0, items.lastIndex)
        if (fromIdx == targetIdx) return
        val ids = items.map { it.item.id }.toMutableList()
        val moved = ids.removeAt(fromIdx)
        ids.add(targetIdx, moved)
        reorderReportRows(reportId, ids)
    }

    /**
     * Moves a set of selected rows together to [targetInsertionIndex] in the current sorted list,
     * preserving their exact relative order.
     */
    suspend fun moveReportRowsBatch(
        reportId: Long,
        selectedItemIds: Set<Long>,
        targetInsertionIndex: Int,
    ) {
        if (selectedItemIds.isEmpty()) return
        val items = reportDao.getReportWithDetails(reportId)?.sortedItems.orEmpty()
        if (items.isEmpty()) return
        val selectedOrdered = items.filter { it.item.id in selectedItemIds }.map { it.item.id }
        if (selectedOrdered.isEmpty()) return

        val clampedTarget = targetInsertionIndex.coerceIn(0, items.size)
        val removedBeforeTarget = items.take(clampedTarget).count { it.item.id in selectedItemIds }
        val remaining = items.filterNot { it.item.id in selectedItemIds }.map { it.item.id }.toMutableList()
        val adjustedInsertIdx = (clampedTarget - removedBeforeTarget).coerceIn(0, remaining.size)
        remaining.addAll(adjustedInsertIdx, selectedOrdered)
        reorderReportRows(reportId, remaining)
    }

    suspend fun applyReportRowSortMode(reportId: Long, sortMode: ReportRowSortMode) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                val details = reportDao.getReportWithDetails(reportId) ?: return@withTransaction
                if (sortMode != ReportRowSortMode.MANUAL && details.sortedItems.isNotEmpty()) {
                    val comparator: Comparator<ReportItemEntity> = when (sortMode) {
                        ReportRowSortMode.NAME_ASC -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.BARCODE_ASC -> compareBy<ReportItemEntity> { it.primaryBarcodeSnapshot }
                            .thenBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.PRICE_DESC -> compareByDescending<ReportItemEntity> { it.unitPrice }
                            .thenBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.PRICE_ASC -> compareBy<ReportItemEntity> { it.unitPrice }
                            .thenBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.QTY_DESC -> compareByDescending<ReportItemEntity> { it.quantity }
                            .thenBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.CATEGORY_ASC -> compareBy<ReportItemEntity, String>(String.CASE_INSENSITIVE_ORDER) { it.categorySnapshot }
                            .thenBy(String.CASE_INSENSITIVE_ORDER) { it.productNameSnapshot }
                        ReportRowSortMode.MANUAL -> compareBy { it.sortOrder }
                    }
                    val sorted = details.sortedItems.map { it.item }.sortedWith(comparator)
                    reportDao.updateReportItems(
                        sorted.mapIndexed { idx, item -> item.copy(sortOrder = idx, serialNumber = idx + 1) },
                    )
                }
                reportDao.updateReport(
                    details.report.copy(
                        rowSortMode = sortMode.name,
                        updatedAt = System.currentTimeMillis(),
                    ),
                )
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "فرز صفوف التقرير")
        }
    }

    /**
     * Duplicates a row inside the same report with independent copied snapshot images
     * right after the original row, updating sortOrder and serialNumber atomically.
     */
    suspend fun duplicateReportRow(reportId: Long, itemId: Long): Long? {
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val newId = db.withTransaction {
                val details = reportDao.getReportWithDetails(reportId) ?: return@withTransaction null
                val sorted = details.sortedItems
                val srcIdx = sorted.indexOfFirst { it.item.id == itemId }
                if (srcIdx < 0) return@withTransaction null
                val srcRow = sorted[srcIdx]

                val copiedPrimarySnap = if (srcRow.item.imageSnapshotPath.isNotBlank()) {
                    mediaStorage.copyToReportSnapshot(srcRow.item.imageSnapshotPath, reportId)
                } else ""

                val newItemId = reportDao.insertReportItem(
                    srcRow.item.copy(
                        id = 0L,
                        imageSnapshotPath = copiedPrimarySnap,
                        sortOrder = srcIdx + 1,
                        serialNumber = srcIdx + 2,
                    ),
                )
                if (srcRow.barcodes.isNotEmpty()) {
                    reportDao.insertReportItemBarcodes(
                        srcRow.barcodes.map { b -> b.copy(id = 0L, reportItemId = newItemId) },
                    )
                }
                val now = System.currentTimeMillis()
                if (srcRow.images.isNotEmpty()) {
                    val copiedImgs = srcRow.images.sortedBy { it.sortOrder }.mapIndexedNotNull { imgIdx, img ->
                        val newPath = if (img.isPrimary && copiedPrimarySnap.isNotBlank()) {
                            copiedPrimarySnap
                        } else {
                            mediaStorage.copyToReportSnapshot(img.filePath, reportId)
                        }
                        if (newPath.isBlank()) null
                        else img.copy(
                            id = 0L,
                            reportItemId = newItemId,
                            reportId = reportId,
                            filePath = newPath,
                            sortOrder = imgIdx,
                            addedAt = now,
                        )
                    }
                    if (copiedImgs.isNotEmpty()) {
                        reportDao.insertReportItemImages(copiedImgs)
                    }
                }

                // Re-number all rows cleanly in exact sequence
                val reordered = buildList {
                    sorted.forEachIndexed { idx, row ->
                        add(row.item)
                        if (idx == srcIdx) {
                            add(reportDao.getReportItemById(newItemId)!!)
                        }
                    }
                }
                reportDao.updateReportItems(
                    reordered.mapIndexed { idx, item -> item.copy(sortOrder = idx, serialNumber = idx + 1) },
                )
                reportDao.updateReport(details.report.copy(updatedAt = now))
                newItemId
            }
            _saveStatus.value = SaveStatus.SAVED
            newId
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "تكرار صف في التقرير")
            null
        }
    }

    // ==================== Stage 5: Report-Only Image Replacement, Editing & Restore ====================

    suspend fun setReportItemImageFromPath(
        reportId: Long,
        itemId: Long,
        sourcePath: String,
        sourceType: ReportImageSourceType,
        sourceProductId: Long? = null,
        sourceImageId: Long? = null,
    ): Boolean {
        val snapPath = mediaStorage.copyToReportSnapshot(sourcePath, reportId)
        if (snapPath.isBlank()) return false
        return replacePrimarySnapshotForReportItem(
            reportId = reportId,
            itemId = itemId,
            newSnapshotPath = snapPath,
            sourceType = sourceType,
            sourceProductId = sourceProductId,
            sourceImageId = sourceImageId,
        )
    }

    suspend fun setReportItemImageFromUri(
        reportId: Long,
        itemId: Long,
        uri: Uri,
    ): Boolean {
        val snapPath = mediaStorage.saveUriToReportSnapshot(uri, reportId) ?: return false
        return replacePrimarySnapshotForReportItem(
            reportId = reportId,
            itemId = itemId,
            newSnapshotPath = snapPath,
            sourceType = ReportImageSourceType.REPORT_UPLOAD,
            sourceImageId = null,
        )
    }

    suspend fun applyReportOnlyImageEdits(
        reportId: Long,
        itemId: Long,
        sourcePathOverride: String? = null,
        params: ImageEditParameters,
    ): String? {
        val currentItem = reportDao.getReportItemById(itemId) ?: return null
        val srcPath = sourcePathOverride?.takeIf { it.isNotBlank() && File(it).exists() }
            ?: currentItem.imageSnapshotPath
        val newSnapPath = mediaStorage.applyEditsToReportSnapshot(srcPath, reportId, params) ?: return null
        val ok = replacePrimarySnapshotForReportItem(
            reportId = reportId,
            itemId = itemId,
            newSnapshotPath = newSnapPath,
            sourceType = ReportImageSourceType.REPORT_EDITED,
            sourceProductId = currentItem.sourceProductId,
            sourceImageId = null,
        )
        return if (ok) newSnapPath else null
    }

    suspend fun restoreReportItemOriginalProductImage(reportId: Long, itemId: Long): Boolean {
        val item = reportDao.getReportItemById(itemId) ?: return false
        val srcProductId = item.sourceProductId ?: return false
        val prod = productDao.getProductWithDetails(srcProductId) ?: return false
        val primary = prod.primaryImage ?: prod.images.firstOrNull() ?: return false
        val srcPath = resolveExistingFilePath(primary.filePath, primary.originalFilePath, primary.thumbnailPath)
        if (srcPath.isBlank()) return false
        return setReportItemImageFromPath(
            reportId = reportId,
            itemId = itemId,
            sourcePath = srcPath,
            sourceType = ReportImageSourceType.PRODUCT_PRIMARY,
            sourceProductId = srcProductId,
            sourceImageId = primary.id,
        )
    }

    private suspend fun replacePrimarySnapshotForReportItem(
        reportId: Long,
        itemId: Long,
        newSnapshotPath: String,
        sourceType: ReportImageSourceType,
        sourceProductId: Long? = null,
        sourceImageId: Long? = null,
    ): Boolean {
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val reportDetails = reportDao.getReportWithDetails(reportId) ?: return@withTransaction false
                val item = reportDao.getReportItemById(itemId) ?: return@withTransaction false
                val oldSnapshotPath = item.imageSnapshotPath
                val existingItemImages = reportDao.getReportItemImagesForItem(itemId)
                val now = System.currentTimeMillis()

                reportDao.updateReportItem(item.copy(imageSnapshotPath = newSnapshotPath))

                // Rebuild item's ReportItemImages cleanly with newSnapshotPath as primary (sortOrder = 0)
                val secondaryImgs = existingItemImages
                    .filter { !it.isPrimary && it.filePath != oldSnapshotPath && it.filePath.isNotBlank() }
                    .sortedBy { it.sortOrder }

                reportDao.deleteReportItemImagesForItem(itemId)
                val rebuilt = buildList {
                    add(
                        ReportItemImageEntity(
                            reportItemId = itemId,
                            reportId = reportId,
                            sourceProductId = sourceProductId ?: item.sourceProductId,
                            sourceImageId = sourceImageId,
                            filePath = newSnapshotPath,
                            imageSourceType = sourceType.name,
                            isPrimary = true,
                            sortOrder = 0,
                            addedAt = now,
                        ),
                    )
                    secondaryImgs.forEachIndexed { idx, extra ->
                        add(
                            extra.copy(
                                id = 0L,
                                reportItemId = itemId,
                                reportId = reportId,
                                isPrimary = false,
                                sortOrder = idx + 1,
                            ),
                        )
                    }
                }
                reportDao.insertReportItemImages(rebuilt)
                reportDao.updateReport(reportDetails.report.copy(updatedAt = now))

                // Only delete old snapshot file if it belongs exclusively to this report's snapshots dir
                // and no OTHER row in the report still points to it.
                if (oldSnapshotPath.isNotBlank() &&
                    oldSnapshotPath != newSnapshotPath &&
                    oldSnapshotPath.contains("report_$reportId")
                ) {
                    val stillReferencedElsewhere = reportDetails.items.any { other ->
                        other.item.id != itemId && (
                            other.item.imageSnapshotPath == oldSnapshotPath ||
                                other.images.any { it.filePath == oldSnapshotPath }
                            )
                    }
                    if (!stillReferencedElsewhere) {
                        mediaStorage.deleteFileIfInternal(oldSnapshotPath)
                    }
                }
                true
            }.also { ok ->
                _saveStatus.value = if (ok) SaveStatus.SAVED else SaveStatus.ERROR
            }
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.REPORT_EDITOR, DiagnosticModules.IMAGES, "تحديث أو استعادة صورة في التقرير")
            false
        }
    }

    suspend fun replaceReportColumns(reportId: Long, columns: List<ColumnConfigModel>) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "حفظ أعمدة التقرير",
            initialStage = "حفظ ترتيب وخصائص ${columns.size} عمود",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                reportDao.deleteColumnsForReport(reportId)
                val entities = columns.mapIndexed { idx, col ->
                    col.copy(id = 0L, sortOrder = idx).toEntity(reportId)
                }
                if (entities.isNotEmpty()) {
                    reportDao.insertColumns(entities)
                }
                reportDao.getReportWithDetails(reportId)?.report?.let {
                    reportDao.updateReport(it.copy(updatedAt = System.currentTimeMillis()))
                }
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.REPORT_EDITOR,
                DiagnosticModules.SETTINGS,
                "حفظ أعمدة التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حفظ الأعمدة", err?.errorId.orEmpty())
        }
    }

    suspend fun archiveReport(reportId: Long, archived: Boolean = true) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.ARCHIVE,
            moduleName = DiagnosticModules.REPORTS,
            operationName = if (archived) "أرشفة التقرير" else "إلغاء أرشفة التقرير",
            initialStage = "تحديث حالة التقرير #$reportId",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            reportDao.getReportWithDetails(reportId)?.report?.let {
                reportDao.updateReport(it.copy(isArchived = archived, isSaved = true, updatedAt = System.currentTimeMillis()))
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.ARCHIVE,
                DiagnosticModules.REPORTS,
                "أرشفة التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر الأرشفة", err?.errorId.orEmpty())
        }
    }

    suspend fun cloneReport(sourceReportId: Long, asNewDraft: Boolean = false): Long {
        return duplicateReportInternal(sourceReportId, asNewDraft = asNewDraft, asRevisionVersion = false)
    }

    suspend fun saveAsNewReportVersion(sourceReportId: Long): Long {
        return duplicateReportInternal(sourceReportId, asNewDraft = false, asRevisionVersion = true)
    }

    private suspend fun duplicateReportInternal(
        sourceReportId: Long,
        asNewDraft: Boolean,
        asRevisionVersion: Boolean,
    ): Long {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.ARCHIVE,
            moduleName = DiagnosticModules.REPORTS,
            operationName = if (asRevisionVersion) "حفظ إصدار جديد للتقرير" else "نسخ التقرير",
            initialStage = "قراءة ونسخ بنود وصور التقرير",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val newId = db.withTransaction {
                val src = reportDao.getReportWithDetails(sourceReportId)
                    ?: throw IllegalArgumentException("التقرير غير موجود")
                val dateTag = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                val nextVersion = if (asRevisionVersion) src.report.versionNumber + 1 else 1
                val newNum = if (asRevisionVersion) {
                    val baseNum = src.report.reportNumber.substringBefore("-V")
                    "$baseNum-V$nextVersion"
                } else {
                    "${src.report.reportNumber}-COPY-${dateTag.takeLast(4)}"
                }
                val newTitle = when {
                    asRevisionVersion -> "${src.report.title.substringBefore(" (إصدار")} (إصدار $nextVersion)"
                    asNewDraft -> "تقرير جديد من ${src.report.title}"
                    else -> "${src.report.title} (نسخة)"
                }
                val now = System.currentTimeMillis()
                val newReportId = reportDao.insertReport(
                    src.report.copy(
                        id = 0L,
                        reportNumber = newNum,
                        title = newTitle,
                        reportDate = now,
                        isArchived = asRevisionVersion,
                        isSaved = true,
                        versionNumber = nextVersion,
                        parentReportId = if (asRevisionVersion) (src.report.parentReportId ?: src.report.id) else null,
                        lastPdfPath = "",
                        createdAt = now,
                        updatedAt = now,
                    ),
                )
                val cols = src.sortedColumns.mapIndexed { idx, col ->
                    col.copy(id = 0L, reportId = newReportId, sortOrder = idx)
                }
                if (cols.isNotEmpty()) reportDao.insertColumns(cols)

                src.sortedItems.forEachIndexed { idx, row ->
                    val copiedSnap = if (row.item.imageSnapshotPath.isNotBlank()) {
                        mediaStorage.copyToReportSnapshot(row.item.imageSnapshotPath, newReportId)
                    } else ""
                    val newItemId = reportDao.insertReportItem(
                        row.item.copy(
                            id = 0L,
                            reportId = newReportId,
                            sortOrder = idx,
                            serialNumber = idx + 1,
                            imageSnapshotPath = copiedSnap,
                        ),
                    )
                    if (row.barcodes.isNotEmpty()) {
                        reportDao.insertReportItemBarcodes(
                            row.barcodes.map { b -> b.copy(id = 0L, reportItemId = newItemId) },
                        )
                    }
                    if (row.images.isNotEmpty()) {
                        val copiedImages = row.images.sortedBy { it.sortOrder }.mapIndexedNotNull { imgIdx, img ->
                            val newSnap = if (img.isPrimary && copiedSnap.isNotBlank()) {
                                copiedSnap
                            } else {
                                mediaStorage.copyToReportSnapshot(img.filePath, newReportId)
                            }
                            if (newSnap.isBlank()) null
                            else img.copy(
                                id = 0L,
                                reportItemId = newItemId,
                                reportId = newReportId,
                                filePath = newSnap,
                                sortOrder = imgIdx,
                                addedAt = now,
                            )
                        }
                        if (copiedImages.isNotEmpty()) {
                            reportDao.insertReportItemImages(copiedImages)
                        }
                    }
                }
                newReportId
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("التقرير الجديد #$newId")
            newId
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.ARCHIVE,
                DiagnosticModules.REPORTS,
                "نسخ التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر نسخ التقرير", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun deleteReport(reportId: Long) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.ARCHIVE,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "حذف التقرير",
            initialStage = "حذف التقرير ولقطات صوره #$reportId",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                reportDao.deleteReportById(reportId)
            }
            mediaStorage.deleteReportSnapshots(reportId)
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.ARCHIVE,
                DiagnosticModules.REPORTS,
                "حذف التقرير",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "تعذر حذف التقرير", err?.errorId.orEmpty())
        }
    }

    fun getColumnsDomain(report: ReportWithDetails): List<ColumnConfigModel> =
        report.sortedColumns.map { it.toDomainModel() }

    private fun recalcLineTotal(item: ReportItemEntity): ReportItemEntity {
        val gross = item.unitPrice * item.quantity
        val pctDisc = gross * (item.discountPercent.coerceIn(0.0, 100.0) / 100.0)
        val total = (gross - pctDisc - item.discountAmount).coerceAtLeast(0.0)
        return item.copy(lineTotal = total)
    }

    private fun resolveExistingFilePath(vararg rawCandidates: String?): String {
        for (raw in rawCandidates) {
            if (raw.isNullOrBlank()) continue
            var clean = raw.trim().removePrefix("file://")
            val qIdx = clean.indexOf('?')
            if (qIdx > 0 && clean.substring(qIdx).startsWith("?t=")) {
                clean = clean.substring(0, qIdx)
            }
            val file = File(clean)
            if (file.exists() && file.isFile && file.length() > 0L) {
                return file.absolutePath
            }
        }
        return ""
    }
}
