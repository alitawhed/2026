package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "ReportItemBarcodes",
    foreignKeys = [
        ForeignKey(
            entity = ReportItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["reportItemId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["reportItemId"])],
)
data class ReportItemBarcodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val reportItemId: Long,
    val barcodeValue: String,
    val barcodeType: String = "CODE_128",
    val label: String = "وحدة",
    val isPrimary: Boolean = false,
)
