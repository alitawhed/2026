package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.ReportColumnEntity
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemBarcodeEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.local.entity.ReportItemImageEntity
import com.example.data.local.entity.ReportWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {

    @Transaction
    @Query("SELECT * FROM Reports ORDER BY updatedAt DESC")
    fun observeAllReportsWithDetails(): Flow<List<ReportWithDetails>>

    @Transaction
    @Query("SELECT * FROM Reports WHERE isArchived = 1 ORDER BY updatedAt DESC")
    fun observeArchivedReports(): Flow<List<ReportWithDetails>>

    @Transaction
    @Query("SELECT * FROM Reports ORDER BY updatedAt DESC LIMIT :limit")
    fun observeRecentReports(limit: Int = 5): Flow<List<ReportWithDetails>>

    @Transaction
    @Query("SELECT * FROM Reports WHERE id = :reportId")
    fun observeReportWithDetails(reportId: Long): Flow<ReportWithDetails?>

    @Transaction
    @Query("SELECT * FROM Reports WHERE id = :reportId")
    suspend fun getReportWithDetails(reportId: Long): ReportWithDetails?

    @Transaction
    @Query("SELECT * FROM Reports")
    suspend fun getAllReportsWithDetailsOnce(): List<ReportWithDetails>

    @Query("SELECT COUNT(*) FROM Reports")
    fun observeTotalReportCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM Reports WHERE isSaved = 1")
    fun observeSavedReportCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM Reports WHERE createdAt >= :startOfDayMillis")
    fun observeTodaysReportCount(startOfDayMillis: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM Reports WHERE isArchived = 1")
    fun observeArchivedReportCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity): Long

    @Update
    suspend fun updateReport(report: ReportEntity)

    @Delete
    suspend fun deleteReport(report: ReportEntity)

    @Query("DELETE FROM Reports WHERE id = :reportId")
    suspend fun deleteReportById(reportId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReportItem(item: ReportItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReportItems(items: List<ReportItemEntity>): List<Long>

    @Update
    suspend fun updateReportItem(item: ReportItemEntity)

    @Update
    suspend fun updateReportItems(items: List<ReportItemEntity>)

    @Query("DELETE FROM ReportItems WHERE id = :itemId")
    suspend fun deleteReportItemById(itemId: Long)

    @Query("SELECT * FROM ReportItems WHERE id = :itemId LIMIT 1")
    suspend fun getReportItemById(itemId: Long): ReportItemEntity?

    @Query("SELECT * FROM ReportItemImages WHERE reportItemId = :itemId ORDER BY sortOrder ASC")
    suspend fun getReportItemImagesForItem(itemId: Long): List<ReportItemImageEntity>

    @Query("DELETE FROM ReportItemImages WHERE reportItemId = :itemId")
    suspend fun deleteReportItemImagesForItem(itemId: Long)

    @Query("UPDATE ReportItemImages SET isPrimary = CASE WHEN id = :primaryImageId THEN 1 ELSE 0 END WHERE reportItemId = :itemId")
    suspend fun setPrimaryReportItemImage(itemId: Long, primaryImageId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReportItemBarcodes(barcodes: List<ReportItemBarcodeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReportItemImages(images: List<ReportItemImageEntity>)

    @Query("SELECT * FROM ReportItemImages")
    suspend fun getAllReportItemImagesOnce(): List<ReportItemImageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColumns(columns: List<ReportColumnEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertColumn(column: ReportColumnEntity): Long

    @Update
    suspend fun updateColumn(column: ReportColumnEntity)

    @Update
    suspend fun updateColumns(columns: List<ReportColumnEntity>)

    @Query("DELETE FROM ReportColumns WHERE id = :columnId")
    suspend fun deleteColumnById(columnId: Long)

    @Query("DELETE FROM ReportColumns WHERE reportId = :reportId")
    suspend fun deleteColumnsForReport(reportId: Long)

    @Query("DELETE FROM Reports")
    suspend fun deleteAllReports()
}
