package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "ReportItemImages",
    foreignKeys = [
        ForeignKey(
            entity = ReportItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["reportItemId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["reportItemId"])],
)
data class ReportItemImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val reportItemId: Long,
    val reportId: Long = 0L,
    val sourceProductId: Long? = null,
    val sourceImageId: Long? = null,
    val filePath: String,
    val imageSourceType: String = "PRODUCT_PRIMARY",
    val isPrimary: Boolean = false,
    val sortOrder: Int = 0,
    val addedAt: Long = System.currentTimeMillis(),
)
