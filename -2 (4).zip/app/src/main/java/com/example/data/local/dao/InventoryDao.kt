package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.InventorySessionEntity
import com.example.data.local.entity.InventorySessionWithDetails
import com.example.data.local.entity.StockAdjustmentLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {

    @Transaction
    @Query("SELECT * FROM InventorySessions ORDER BY updatedAt DESC")
    fun observeAllSessionsWithDetails(): Flow<List<InventorySessionWithDetails>>

    @Transaction
    @Query("SELECT * FROM InventorySessions WHERE id = :sessionId")
    fun observeSessionWithDetails(sessionId: Long): Flow<InventorySessionWithDetails?>

    @Transaction
    @Query("SELECT * FROM InventorySessions WHERE id = :sessionId")
    suspend fun getSessionWithDetails(sessionId: Long): InventorySessionWithDetails?

    @Query("SELECT * FROM InventorySessions ORDER BY updatedAt DESC")
    suspend fun getAllSessionsOnce(): List<InventorySessionEntity>

    @Query("SELECT * FROM InventoryCountItems")
    suspend fun getAllCountItemsOnce(): List<InventoryCountItemEntity>

    @Query("SELECT * FROM StockAdjustmentLogs ORDER BY createdAt DESC")
    suspend fun getAllAdjustmentLogsOnce(): List<StockAdjustmentLogEntity>

    @Query("SELECT * FROM StockAdjustmentLogs ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecentAdjustmentLogs(limit: Int = 50): Flow<List<StockAdjustmentLogEntity>>

    @Query("SELECT * FROM InventoryCountItems WHERE sessionId = :sessionId AND scannedBarcode = :barcode LIMIT 1")
    suspend fun findItemBySessionAndBarcode(sessionId: Long, barcode: String): InventoryCountItemEntity?

    @Query("SELECT * FROM InventoryCountItems WHERE sessionId = :sessionId AND productId = :productId LIMIT 1")
    suspend fun findItemBySessionAndProduct(sessionId: Long, productId: Long): InventoryCountItemEntity?

    @Query("SELECT * FROM InventoryCountItems WHERE id = :itemId LIMIT 1")
    suspend fun getCountItemById(itemId: Long): InventoryCountItemEntity?

    @Query("SELECT * FROM InventoryCountItems WHERE productId = :productId")
    suspend fun getCountItemsForProductOnce(productId: Long): List<InventoryCountItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: InventorySessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessions(sessions: List<InventorySessionEntity>): List<Long>

    @Update
    suspend fun updateSession(session: InventorySessionEntity)

    @Query("DELETE FROM InventorySessions WHERE id = :sessionId")
    suspend fun deleteSessionById(sessionId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCountItem(item: InventoryCountItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCountItems(items: List<InventoryCountItemEntity>): List<Long>

    @Update
    suspend fun updateCountItem(item: InventoryCountItemEntity)

    @Query("DELETE FROM InventoryCountItems WHERE id = :itemId")
    suspend fun deleteCountItemById(itemId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdjustmentLog(log: StockAdjustmentLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdjustmentLogs(logs: List<StockAdjustmentLogEntity>): List<Long>

    @Query("DELETE FROM InventorySessions")
    suspend fun deleteAllSessions()
}
