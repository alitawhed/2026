package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "OperationLogs",
    indices = [
        Index(value = ["startTime"]),
        Index(value = ["outcome"]),
        Index(value = ["moduleName"]),
    ],
)
data class OperationLogEntity(
    @PrimaryKey val operationId: String,
    val startTime: Long,
    val endTime: Long,
    val screenName: String,
    val moduleName: String,
    val operationName: String,
    val severity: String,
    val outcome: String,
    val currentStage: String = "",
    val lastSuccessfulStage: String = "",
    val interruptedAbnormally: Boolean = false,
    val failureReason: String,
    val linkedErrorId: String,
    val stagesJson: String,
)
