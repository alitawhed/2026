package com.example.data.local

import com.example.data.local.entity.ReportColumnEntity
import com.example.data.local.entity.ReportTemplateEntity
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.BarcodeStyleConfig
import com.example.domain.model.CellAlignment
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnType
import com.example.domain.model.ColumnWidthPreset
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.domain.model.ReportHeaderFooterConfig
import com.example.domain.model.TemplateKind
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object TemplateDefaults {
    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private fun col(
        key: String,
        title: String,
        type: ColumnType,
        order: Int,
        preset: ColumnWidthPreset = ColumnWidthPreset.MEDIUM,
        minW: Float = 36f,
        maxW: Float = 260f,
        cellHeight: Float = 42f,
        headerBg: String = "#0F172A",
        headerText: String = "#FFFFFF",
        cellBg: String = "#FFFFFF",
        textColor: String = "#0F172A",
        align: CellAlignment = CellAlignment.CENTER,
        fontSize: Float = 9.5f,
        decimalPlaces: Int = when (type) {
            ColumnType.QUANTITY, ColumnType.SERIAL -> 0
            ColumnType.PERCENTAGE -> 1
            else -> 2
        },
        autoDecimals: Boolean = (type == ColumnType.NUMBER),
        stripTrailingZeros: Boolean = (type == ColumnType.PERCENTAGE || type == ColumnType.NUMBER),
    ) = ColumnConfigModel(
        columnKey = key,
        title = title,
        columnType = type,
        visible = true,
        sortOrder = order,
        widthMode = ColumnDistributionMode.AUTO_FIT,
        manualWidthPt = when (preset) {
            ColumnWidthPreset.NARROW -> 45f
            ColumnWidthPreset.MEDIUM -> 78f
            ColumnWidthPreset.WIDE -> 140f
            ColumnWidthPreset.CUSTOM -> 90f
        },
        presetWidth = preset,
        minWidthPt = minW,
        maxWidthPt = maxW,
        cellHeightPt = cellHeight,
        fontSizeSp = fontSize,
        textColorHex = textColor,
        cellBgColorHex = cellBg,
        headerBgColorHex = headerBg,
        headerTextColorHex = headerText,
        alignment = align,
        wrapText = true,
        borderWidthPt = 0.75f,
        paddingHorizontalPt = 4f,
        paddingVerticalPt = 4f,
        numberFormat = when {
            autoDecimals -> "AUTO"
            stripTrailingZeros -> "TRIM_ZEROS"
            decimalPlaces == 0 -> "INTEGER"
            else -> "DECIMAL"
        },
        decimalPlaces = decimalPlaces,
        autoDecimals = autoDecimals,
        stripTrailingZeros = stripTrailingZeros,
    )

    fun buildBuiltInTemplates(): List<ReportTemplateEntity> = listOf(
        // 1. تقرير تجاري رسمي
        ReportTemplateEntity(
            name = TemplateKind.OFFICIAL_COMMERCIAL.arabicLabel,
            templateKind = TemplateKind.OFFICIAL_COMMERCIAL.name,
            description = TemplateKind.OFFICIAL_COMMERCIAL.description,
            isDefault = true,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            marginTopMm = 12f,
            marginBottomMm = 12f,
            marginStartMm = 10f,
            marginEndMm = 10f,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(
                    showLogo = true,
                    showCompanyInfo = true,
                    showClientInfo = true,
                    showReportMeta = true,
                    showTotals = true,
                    showNotes = true,
                    showTerms = true,
                    showResponsible = true,
                    showSignature = true,
                    showStamp = true,
                    headerAccentHex = "#0F172A",
                    tableStripeHex = "#F8FAFC",
                ),
            ),
            barcodeStyleConfigJson = json.encodeToString(
                BarcodeStyleConfig(format = BarcodeFormatType.CODE_128, widthPt = 92f, heightPt = 28f),
            ),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 42f),
                    col("image", "الصورة", ColumnType.IMAGE, 1, ColumnWidthPreset.NARROW, minW = 44f, maxW = 68f, cellHeight = 46f),
                    col("name", "اسم المنتج", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 90f, align = CellAlignment.START),
                    col("barcode", "الباركود", ColumnType.BARCODE, 3, ColumnWidthPreset.WIDE, minW = 86f, maxW = 140f),
                    col("qty", "الكمية", ColumnType.QUANTITY, 4, ColumnWidthPreset.NARROW, minW = 40f, maxW = 68f, decimalPlaces = 0),
                    col("price", "السعر", ColumnType.PRICE, 5, ColumnWidthPreset.MEDIUM, minW = 48f, maxW = 82f),
                    col("total", "الإجمالي", ColumnType.CURRENCY, 6, ColumnWidthPreset.MEDIUM, minW = 54f, maxW = 92f),
                ),
            ),
        ),
        // 2. قائمة أسعار
        ReportTemplateEntity(
            name = TemplateKind.PRICE_LIST.arabicLabel,
            templateKind = TemplateKind.PRICE_LIST.name,
            description = TemplateKind.PRICE_LIST.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            marginTopMm = 10f,
            marginBottomMm = 10f,
            marginStartMm = 10f,
            marginEndMm = 10f,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(
                    showLogo = true,
                    showCompanyInfo = true,
                    showClientInfo = false,
                    showTotals = false,
                    showNotes = true,
                    showTerms = true,
                    showResponsible = true,
                    showSignature = false,
                    headerAccentHex = "#0D9488",
                    tableStripeHex = "#F0FDFA",
                ),
            ),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 24f, maxW = 38f, cellHeight = 30f, headerBg = "#0D9488"),
                    col("internal_code", "الرمز", ColumnType.TEXT, 1, ColumnWidthPreset.NARROW, minW = 48f, maxW = 72f, cellHeight = 30f, headerBg = "#0D9488"),
                    col("name", "اسم الصنف", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 110f, cellHeight = 30f, headerBg = "#0D9488", align = CellAlignment.START),
                    col("category", "التصنيف", ColumnType.TEXT, 3, ColumnWidthPreset.MEDIUM, minW = 56f, maxW = 96f, cellHeight = 30f, headerBg = "#0D9488"),
                    col("barcode_text", "رقم الباركود", ColumnType.TEXT, 4, ColumnWidthPreset.MEDIUM, minW = 76f, maxW = 120f, cellHeight = 30f, headerBg = "#0D9488"),
                    col("price", "السعر", ColumnType.CURRENCY, 5, ColumnWidthPreset.MEDIUM, minW = 56f, maxW = 86f, cellHeight = 30f, headerBg = "#0D9488"),
                ),
            ),
        ),
        // 3. كتالوج منتجات
        ReportTemplateEntity(
            name = TemplateKind.PRODUCT_CATALOG.arabicLabel,
            templateKind = TemplateKind.PRODUCT_CATALOG.name,
            description = TemplateKind.PRODUCT_CATALOG.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.LANDSCAPE.name,
            marginTopMm = 10f,
            marginBottomMm = 10f,
            marginStartMm = 10f,
            marginEndMm = 10f,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(
                    showLogo = true,
                    showCompanyInfo = true,
                    showClientInfo = true,
                    showTotals = false,
                    showNotes = true,
                    showSignature = false,
                    headerAccentHex = "#1E293B",
                    tableStripeHex = "#F8FAFC",
                ),
            ),
            barcodeStyleConfigJson = json.encodeToString(
                BarcodeStyleConfig(format = BarcodeFormatType.QR_CODE, widthPt = 52f, heightPt = 52f, showText = false),
            ),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 36f, cellHeight = 68f, headerBg = "#1E293B"),
                    col("image", "صورة المنتج", ColumnType.IMAGE, 1, ColumnWidthPreset.MEDIUM, minW = 68f, maxW = 96f, cellHeight = 68f, headerBg = "#1E293B"),
                    col("name", "المنتج والوصف", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 140f, cellHeight = 68f, headerBg = "#1E293B", align = CellAlignment.START),
                    col("manufacturer", "المصنع", ColumnType.TEXT, 3, ColumnWidthPreset.MEDIUM, minW = 66f, maxW = 110f, cellHeight = 68f, headerBg = "#1E293B"),
                    col("origin", "المنشأ", ColumnType.TEXT, 4, ColumnWidthPreset.NARROW, minW = 54f, maxW = 84f, cellHeight = 68f, headerBg = "#1E293B"),
                    col("price", "السعر", ColumnType.CURRENCY, 5, ColumnWidthPreset.MEDIUM, minW = 60f, maxW = 90f, cellHeight = 68f, headerBg = "#1E293B"),
                    col("qr", "رمز QR", ColumnType.QR_CODE, 6, ColumnWidthPreset.MEDIUM, minW = 60f, maxW = 84f, cellHeight = 68f, headerBg = "#1E293B"),
                ),
            ),
        ),
        // 4. تقرير جرد
        ReportTemplateEntity(
            name = TemplateKind.INVENTORY.arabicLabel,
            templateKind = TemplateKind.INVENTORY.name,
            description = TemplateKind.INVENTORY.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(
                    showTotals = true,
                    showTerms = false,
                    showSignature = true,
                    showStamp = true,
                    headerAccentHex = "#B45309",
                    tableStripeHex = "#FFFBEB",
                ),
            ),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 38f, cellHeight = 36f, headerBg = "#B45309"),
                    col("barcode_text", "الباركود", ColumnType.TEXT, 1, ColumnWidthPreset.MEDIUM, minW = 80f, maxW = 115f, cellHeight = 36f, headerBg = "#B45309"),
                    col("name", "اسم الصنف", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 110f, cellHeight = 36f, headerBg = "#B45309", align = CellAlignment.START),
                    col("category", "التصنيف", ColumnType.TEXT, 3, ColumnWidthPreset.MEDIUM, minW = 54f, maxW = 86f, cellHeight = 36f, headerBg = "#B45309"),
                    col("qty", "الكمية الفعلية", ColumnType.QUANTITY, 4, ColumnWidthPreset.NARROW, minW = 48f, maxW = 74f, cellHeight = 36f, headerBg = "#B45309", decimalPlaces = 0),
                    col("notes", "ملاحظات الجرد", ColumnType.NOTES, 5, ColumnWidthPreset.WIDE, minW = 80f, cellHeight = 36f, headerBg = "#B45309", align = CellAlignment.START),
                ),
            ),
        ),
        // 5. تقرير منتجات بالصور
        ReportTemplateEntity(
            name = TemplateKind.PHOTO_REPORT.arabicLabel,
            templateKind = TemplateKind.PHOTO_REPORT.name,
            description = TemplateKind.PHOTO_REPORT.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(headerAccentHex = "#0369A1", tableStripeHex = "#F0F9FF"),
            ),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 38f, cellHeight = 64f, headerBg = "#0369A1"),
                    col("image", "الصورة الرئيسية", ColumnType.IMAGE, 1, ColumnWidthPreset.WIDE, minW = 74f, maxW = 108f, cellHeight = 64f, headerBg = "#0369A1"),
                    col("name", "اسم المنتج", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 120f, cellHeight = 64f, headerBg = "#0369A1", align = CellAlignment.START),
                    col("price", "السعر", ColumnType.CURRENCY, 3, ColumnWidthPreset.MEDIUM, minW = 56f, maxW = 86f, cellHeight = 64f, headerBg = "#0369A1"),
                    col("qty", "الكمية", ColumnType.QUANTITY, 4, ColumnWidthPreset.NARROW, minW = 44f, maxW = 68f, cellHeight = 64f, headerBg = "#0369A1", decimalPlaces = 0),
                    col("total", "الإجمالي", ColumnType.CURRENCY, 5, ColumnWidthPreset.MEDIUM, minW = 60f, maxW = 92f, cellHeight = 64f, headerBg = "#0369A1"),
                ),
            ),
        ),
        // 6. تقرير باركودات
        ReportTemplateEntity(
            name = TemplateKind.BARCODE_REPORT.arabicLabel,
            templateKind = TemplateKind.BARCODE_REPORT.name,
            description = TemplateKind.BARCODE_REPORT.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(showTotals = false, headerAccentHex = "#111827", tableStripeHex = "#F9FAFB"),
            ),
            barcodeStyleConfigJson = json.encodeToString(
                BarcodeStyleConfig(format = BarcodeFormatType.CODE_128, widthPt = 136f, heightPt = 38f, showText = true),
            ),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 38f, cellHeight = 52f, headerBg = "#111827"),
                    col("name", "اسم المنتج", ColumnType.TEXT, 1, ColumnWidthPreset.WIDE, minW = 110f, cellHeight = 52f, headerBg = "#111827", align = CellAlignment.START),
                    col("barcode_type", "نوع الباركود", ColumnType.TEXT, 2, ColumnWidthPreset.NARROW, minW = 52f, maxW = 78f, cellHeight = 52f, headerBg = "#111827"),
                    col("barcode", "الباركود (قابل للمسح)", ColumnType.BARCODE, 3, ColumnWidthPreset.WIDE, minW = 130f, maxW = 210f, cellHeight = 52f, headerBg = "#111827"),
                    col("price", "السعر", ColumnType.CURRENCY, 4, ColumnWidthPreset.MEDIUM, minW = 54f, maxW = 84f, cellHeight = 52f, headerBg = "#111827"),
                ),
            ),
        ),
        // 7. تقرير كميات
        ReportTemplateEntity(
            name = TemplateKind.QUANTITY_REPORT.arabicLabel,
            templateKind = TemplateKind.QUANTITY_REPORT.name,
            description = TemplateKind.QUANTITY_REPORT.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(headerAccentHex = "#15803D", tableStripeHex = "#F0FDF4"),
            ),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 26f, maxW = 38f, cellHeight = 34f, headerBg = "#15803D"),
                    col("name", "المنتج", ColumnType.TEXT, 1, ColumnWidthPreset.WIDE, minW = 130f, cellHeight = 34f, headerBg = "#15803D", align = CellAlignment.START),
                    col("barcode_text", "الباركود", ColumnType.TEXT, 2, ColumnWidthPreset.MEDIUM, minW = 76f, maxW = 115f, cellHeight = 34f, headerBg = "#15803D"),
                    col("qty", "الكمية المطلوبة", ColumnType.QUANTITY, 3, ColumnWidthPreset.MEDIUM, minW = 56f, maxW = 86f, cellHeight = 34f, headerBg = "#15803D", decimalPlaces = 0),
                    col("notes", "ملاحظات", ColumnType.NOTES, 4, ColumnWidthPreset.WIDE, minW = 80f, cellHeight = 34f, headerBg = "#15803D", align = CellAlignment.START),
                ),
            ),
        ),
        // 8. تقرير مختصر
        ReportTemplateEntity(
            name = TemplateKind.SUMMARY_REPORT.arabicLabel,
            templateKind = TemplateKind.SUMMARY_REPORT.name,
            description = TemplateKind.SUMMARY_REPORT.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A5.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(showClientInfo = true, showTerms = false, showStamp = false, headerAccentHex = "#334155"),
            ),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 24f, maxW = 34f, cellHeight = 28f, headerBg = "#334155", fontSize = 8.5f),
                    col("name", "المنتج", ColumnType.TEXT, 1, ColumnWidthPreset.WIDE, minW = 100f, cellHeight = 28f, headerBg = "#334155", align = CellAlignment.START, fontSize = 8.5f),
                    col("qty", "الكمية", ColumnType.QUANTITY, 2, ColumnWidthPreset.NARROW, minW = 36f, maxW = 56f, cellHeight = 28f, headerBg = "#334155", fontSize = 8.5f, decimalPlaces = 0),
                    col("total", "الإجمالي", ColumnType.CURRENCY, 3, ColumnWidthPreset.MEDIUM, minW = 52f, maxW = 80f, cellHeight = 28f, headerBg = "#334155", fontSize = 8.5f),
                ),
            ),
        ),
        // 9. تقرير تفصيلي
        ReportTemplateEntity(
            name = TemplateKind.DETAILED_REPORT.arabicLabel,
            templateKind = TemplateKind.DETAILED_REPORT.name,
            description = TemplateKind.DETAILED_REPORT.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.LANDSCAPE.name,
            marginTopMm = 10f,
            marginBottomMm = 10f,
            marginStartMm = 8f,
            marginEndMm = 8f,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(
                ReportHeaderFooterConfig(showTerms = true, showStamp = true, showSignature = true, headerAccentHex = "#0F172A"),
            ),
            barcodeStyleConfigJson = json.encodeToString(
                BarcodeStyleConfig(widthPt = 94f, heightPt = 26f),
            ),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 24f, maxW = 36f, cellHeight = 42f),
                    col("image", "الصورة", ColumnType.IMAGE, 1, ColumnWidthPreset.NARROW, minW = 42f, maxW = 60f, cellHeight = 42f),
                    col("name", "اسم المنتج", ColumnType.TEXT, 2, ColumnWidthPreset.WIDE, minW = 100f, cellHeight = 42f, align = CellAlignment.START),
                    col("barcode", "الباركود", ColumnType.BARCODE, 3, ColumnWidthPreset.MEDIUM, minW = 88f, maxW = 126f, cellHeight = 42f),
                    col("origin", "المنشأ", ColumnType.TEXT, 4, ColumnWidthPreset.NARROW, minW = 48f, maxW = 72f, cellHeight = 42f),
                    col("price", "السعر", ColumnType.PRICE, 5, ColumnWidthPreset.NARROW, minW = 46f, maxW = 68f, cellHeight = 42f),
                    col("qty", "الكمية", ColumnType.QUANTITY, 6, ColumnWidthPreset.NARROW, minW = 40f, maxW = 60f, cellHeight = 42f, decimalPlaces = 0),
                    col("discount", "الخصم", ColumnType.PERCENTAGE, 7, ColumnWidthPreset.NARROW, minW = 40f, maxW = 60f, cellHeight = 42f),
                    col("total", "الإجمالي", ColumnType.CURRENCY, 8, ColumnWidthPreset.MEDIUM, minW = 54f, maxW = 84f, cellHeight = 42f),
                    col("notes", "ملاحظات", ColumnType.NOTES, 9, ColumnWidthPreset.MEDIUM, minW = 64f, cellHeight = 42f, align = CellAlignment.START),
                ),
            ),
        ),
        // 10. قالب فارغ قابل للتصميم
        ReportTemplateEntity(
            name = TemplateKind.BLANK_CUSTOM.arabicLabel,
            templateKind = TemplateKind.BLANK_CUSTOM.name,
            description = TemplateKind.BLANK_CUSTOM.description,
            isBuiltIn = true,
            paperSize = PaperSizeType.A4.name,
            orientation = PageOrientation.PORTRAIT.name,
            distributionMode = ColumnDistributionMode.AUTO_FIT.name,
            headerFooterConfigJson = json.encodeToString(ReportHeaderFooterConfig(headerAccentHex = "#475569")),
            barcodeStyleConfigJson = json.encodeToString(BarcodeStyleConfig()),
            columnsConfigJson = json.encodeToString(
                listOf(
                    col("serial", "م", ColumnType.SERIAL, 0, ColumnWidthPreset.NARROW, minW = 28f, maxW = 42f, headerBg = "#475569"),
                    col("name", "البيان / المنتج", ColumnType.TEXT, 1, ColumnWidthPreset.WIDE, minW = 140f, headerBg = "#475569", align = CellAlignment.START),
                    col("qty", "الكمية", ColumnType.QUANTITY, 2, ColumnWidthPreset.NARROW, minW = 50f, maxW = 80f, headerBg = "#475569", decimalPlaces = 0),
                    col("total", "القيمة", ColumnType.CURRENCY, 3, ColumnWidthPreset.MEDIUM, minW = 65f, maxW = 100f, headerBg = "#475569"),
                ),
            ),
        ),
    )

    fun decodeColumns(columnsJson: String): List<ColumnConfigModel> =
        try {
            json.decodeFromString<List<ColumnConfigModel>>(columnsJson)
        } catch (_: Exception) {
            emptyList()
        }

    fun decodeHeaderFooter(configJson: String): ReportHeaderFooterConfig =
        try {
            if (configJson.isBlank() || configJson == "{}") ReportHeaderFooterConfig()
            else json.decodeFromString<ReportHeaderFooterConfig>(configJson)
        } catch (_: Exception) {
            ReportHeaderFooterConfig()
        }

    fun decodeBarcodeStyle(configJson: String): BarcodeStyleConfig =
        try {
            if (configJson.isBlank() || configJson == "{}") BarcodeStyleConfig()
            else json.decodeFromString<BarcodeStyleConfig>(configJson)
        } catch (_: Exception) {
            BarcodeStyleConfig()
        }

    fun ColumnConfigModel.toEntity(reportId: Long): ReportColumnEntity = ReportColumnEntity(
        id = id,
        reportId = reportId,
        columnKey = columnKey,
        title = title,
        columnType = columnType.name,
        visible = visible,
        sortOrder = sortOrder,
        widthMode = widthMode.name,
        manualWidthPt = manualWidthPt,
        presetWidth = presetWidth.name,
        minWidthPt = minWidthPt,
        maxWidthPt = maxWidthPt,
        cellHeightPt = cellHeightPt,
        fontSizeSp = fontSizeSp,
        textColorHex = textColorHex,
        cellBgColorHex = cellBgColorHex,
        headerBgColorHex = headerBgColorHex,
        headerTextColorHex = headerTextColorHex,
        alignment = alignment.name,
        wrapText = wrapText,
        borderWidthPt = borderWidthPt,
        paddingHorizontalPt = paddingHorizontalPt,
        paddingVerticalPt = paddingVerticalPt,
        numberFormat = numberFormat,
        decimalPlaces = decimalPlaces,
        autoDecimals = autoDecimals,
        stripTrailingZeros = stripTrailingZeros,
        dropdownOptionsJson = json.encodeToString(dropdownOptions),
        customFieldKey = customFieldKey,
    )

    fun ReportColumnEntity.toDomainModel(): ColumnConfigModel = ColumnConfigModel(
        id = id,
        columnKey = columnKey,
        title = title,
        columnType = ColumnType.fromString(columnType),
        visible = visible,
        sortOrder = sortOrder,
        widthMode = ColumnDistributionMode.fromString(widthMode),
        manualWidthPt = manualWidthPt,
        presetWidth = ColumnWidthPreset.fromString(presetWidth),
        minWidthPt = minWidthPt,
        maxWidthPt = maxWidthPt,
        cellHeightPt = cellHeightPt,
        fontSizeSp = fontSizeSp,
        textColorHex = textColorHex,
        cellBgColorHex = cellBgColorHex,
        headerBgColorHex = headerBgColorHex,
        headerTextColorHex = headerTextColorHex,
        alignment = CellAlignment.fromString(alignment),
        wrapText = wrapText,
        borderWidthPt = borderWidthPt,
        paddingHorizontalPt = paddingHorizontalPt,
        paddingVerticalPt = paddingVerticalPt,
        numberFormat = numberFormat,
        decimalPlaces = decimalPlaces,
        autoDecimals = autoDecimals,
        stripTrailingZeros = stripTrailingZeros,
        dropdownOptions = try {
            json.decodeFromString<List<String>>(dropdownOptionsJson)
        } catch (_: Exception) {
            emptyList()
        },
        customFieldKey = customFieldKey,
    )
}
