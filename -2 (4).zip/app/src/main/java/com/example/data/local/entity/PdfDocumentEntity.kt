package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "PDFDocuments",
    indices = [
        Index(value = ["updatedAt"]),
        Index(value = ["sourceReportId"]),
    ],
)
data class PdfDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val fileName: String,
    val workingFilePath: String,
    val originalFilePath: String,
    val pageCount: Int = 0,
    val fileSizeBytes: Long = 0L,
    val sourceReportId: Long? = null,
    val annotationsJson: String = "[]",
    val isEditedCopy: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
