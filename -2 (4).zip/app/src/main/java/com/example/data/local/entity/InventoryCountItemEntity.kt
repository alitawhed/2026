package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "InventoryCountItems",
    foreignKeys = [
        ForeignKey(
            entity = InventorySessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["productId"]),
        Index(value = ["scannedBarcode"]),
    ],
)
data class InventoryCountItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: Long,
    val productId: Long? = null,
    val productInternalCode: String = "",
    val productName: String,
    val productImagePath: String = "",
    val scannedBarcode: String,
    val barcodeType: String = "CODE_128",
    val unitType: String = "حبة",
    val conversionFactor: Double = 1.0,
    val countedQty: Double = 0.0,
    val baseUnitEquivalentQty: Double = 0.0,
    val previousSystemQty: Double = 0.0,
    val lastIncrementQty: Double = 0.0,
    val scanCount: Int = 1,
    val notes: String = "",
    val status: String = "COUNTED",
    val scannedAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
