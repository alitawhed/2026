package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class ImageDownloadStatus(val arabicLabel: String) {
    PENDING("بانتظار التحميل"),
    DOWNLOADING("جارٍ التحميل"),
    SUCCESS("تم التنزيل والحفظ"),
    FAILED("فشل التنزيل"),
    SKIPPED("تم التخطي"),
}

enum class ExcelImageConflictPolicy(val arabicLabel: String) {
    KEEP_EXISTING("الإبقاء على الصورة القديمة"),
    REPLACE_PRIMARY("استبدال الصورة الحالية"),
    ADD_AS_ADDITIONAL("إضافة كصورة إضافية"),
}

@Serializable
@Entity(
    tableName = "ProductImageDownloads",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["productId"]),
        Index(value = ["status"]),
        Index(value = ["batchId"]),
        Index(value = ["barcode"]),
    ],
)
data class ProductImageDownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val batchId: String = "",
    val productId: Long,
    val barcode: String = "",
    val productName: String = "",
    val sourceUrl: String,
    val localImageId: Long? = null,
    val localFilePath: String = "",
    val originalFilePath: String = "",
    val thumbnailPath: String = "",
    val status: String = ImageDownloadStatus.PENDING.name,
    val failureReason: String = "",
    val failureCategory: String = "",
    val httpStatusCode: Int = 0,
    val finalUrl: String = "",
    val detectedFormat: String = "",
    val diagnosticLog: String = "",
    val imagePolicy: String = ExcelImageConflictPolicy.KEEP_EXISTING.name,
    val excelRowNumber: Int = 0,
    val attemptCount: Int = 0,
    val contentHash: String = "",
    val fileSizeBytes: Long = 0L,
    val downloadedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
