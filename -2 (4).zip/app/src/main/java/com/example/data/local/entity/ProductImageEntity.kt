package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "ProductImages",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["productId"])],
)
data class ProductImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val productId: Long,
    val filePath: String,
    val originalFilePath: String = "",
    val thumbnailPath: String = "",
    val isPrimary: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val sourceUrl: String = "",
    val matchedBarcode: String = "",
    val downloadedAt: Long = 0L,
    val downloadStatus: String = "LOCAL",
    val failureReason: String = "",
    val contentHash: String = "",
    val fileSizeBytes: Long = 0L,
)
