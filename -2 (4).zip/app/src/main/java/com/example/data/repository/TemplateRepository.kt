package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.entity.ReportTemplateEntity
import com.example.data.local.entity.ReportWithDetails
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString

class TemplateRepository(
    private val db: AppDatabase,
    private val errorMonitor: GlobalErrorMonitor? = null,
) {
    private val templateDao = db.templateDao()

    val allTemplates: Flow<List<ReportTemplateEntity>> = templateDao.observeAllTemplates()

    suspend fun ensureBuiltInsSeeded() {
        try {
            if (templateDao.getAllTemplatesOnce().isEmpty()) {
                val trace = errorMonitor?.operationLogger?.startOperation(
                    screenName = ScreenNames.TEMPLATES,
                    moduleName = DiagnosticModules.SQLITE,
                    operationName = "تهيئة القوالب الافتراضية",
                    initialStage = "فحص جدول القوالب",
                )
                templateDao.insertTemplates(TemplateDefaults.buildBuiltInTemplates())
                trace?.succeed("تم إدراج القوالب المدمجة")
            }
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.TEMPLATES, DiagnosticModules.SQLITE, "تهيئة القوالب الافتراضية")
            throw e
        }
    }

    suspend fun saveTemplate(template: ReportTemplateEntity): Long {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.TEMPLATES,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "حفظ قالب (${template.name})",
            initialStage = "تحديث قاعدة البيانات",
        )
        return try {
            val id = templateDao.insertTemplate(
                template.copy(updatedAt = System.currentTimeMillis()),
            )
            trace?.succeed("ID=$id")
            id
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "حفظ قالب",
                linkedOperationId = trace?.operationId.orEmpty(),
                failedStage = "تحديث قاعدة البيانات",
            )
            trace?.fail(e.message ?: "فشل حفظ القالب", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun saveReportAsNewTemplate(reportDetails: ReportWithDetails, templateName: String, description: String): Long {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.TEMPLATES,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "حفظ التقرير كقالب جديد",
            initialStage = "ترميز أعمدة القالب",
        )
        return try {
            val cols = reportDetails.sortedColumns.map { it.toDomainModel().copy(id = 0L) }
            val template = ReportTemplateEntity(
                name = templateName.trim().ifBlank { "قالب مخصص" },
                templateKind = "CUSTOM",
                description = description.ifBlank { "قالب محفوظ من تقرير ${reportDetails.report.title}" },
                isDefault = false,
                isBuiltIn = false,
                paperSize = reportDetails.report.paperSize,
                customWidthMm = reportDetails.report.customWidthMm,
                customHeightMm = reportDetails.report.customHeightMm,
                orientation = reportDetails.report.orientation,
                marginTopMm = reportDetails.report.marginTopMm,
                marginBottomMm = reportDetails.report.marginBottomMm,
                marginStartMm = reportDetails.report.marginStartMm,
                marginEndMm = reportDetails.report.marginEndMm,
                distributionMode = reportDetails.report.columnDistributionMode,
                headerFooterConfigJson = reportDetails.report.headerFooterConfigJson,
                barcodeStyleConfigJson = reportDetails.report.barcodeStyleConfigJson,
                columnsConfigJson = TemplateDefaults.json.encodeToString(cols),
            )
            trace?.stage("إدراج القالب في SQLite")
            val id = templateDao.insertTemplate(template)
            trace?.succeed("ID=$id")
            id
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "حفظ التقرير كقالب",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حفظ القالب", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun duplicateTemplate(template: ReportTemplateEntity): Long {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.TEMPLATES,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "نسخ قالب (${template.name})",
            initialStage = "إدراج نسخة القالب",
        )
        return try {
            val id = templateDao.insertTemplate(
                template.copy(
                    id = 0L,
                    name = "${template.name} (نسخة)",
                    isDefault = false,
                    isBuiltIn = false,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                ),
            )
            trace?.succeed("ID=$id")
            id
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "نسخ قالب",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل نسخ القالب", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun deleteTemplate(template: ReportTemplateEntity) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.TEMPLATES,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "حذف قالب (${template.name})",
            initialStage = "تنفيذ حذف القالب وضبط الافتراضي",
        )
        try {
            db.withTransaction {
                templateDao.deleteTemplate(template)
                val remaining = templateDao.getAllTemplatesOnce()
                if (remaining.isNotEmpty() && remaining.none { it.isDefault }) {
                    templateDao.setDefaultTemplate(remaining.first().id)
                }
            }
            trace?.succeed()
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "حذف قالب",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حذف القالب", err?.errorId.orEmpty())
            throw e
        }
    }

    suspend fun setDefaultTemplate(templateId: Long) {
        try {
            templateDao.setDefaultTemplate(templateId)
            errorMonitor?.operationLogger?.logQuickEvent(
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "تعيين القالب الافتراضي (#$templateId)",
            )
        } catch (e: Exception) {
            errorMonitor?.recordError(e, ScreenNames.TEMPLATES, DiagnosticModules.REPORTS, "تعيين القالب الافتراضي")
            throw e
        }
    }

    fun exportTemplateJson(template: ReportTemplateEntity): String =
        TemplateDefaults.json.encodeToString(template.copy(id = 0L, isBuiltIn = false, isDefault = false))

    suspend fun importTemplateJson(rawJson: String): Result<Long> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.TEMPLATES,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "استيراد قالب JSON",
            initialStage = "تحليل JSON القالب",
        )
        return try {
            val parsed = TemplateDefaults.json.decodeFromString<ReportTemplateEntity>(rawJson)
            trace?.stage("حفظ القالب في قاعدة البيانات")
            val id = templateDao.insertTemplate(
                parsed.copy(
                    id = 0L,
                    isBuiltIn = false,
                    isDefault = false,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                ),
            )
            trace?.succeed("ID=$id")
            Result.success(id)
        } catch (e: Exception) {
            val err = errorMonitor?.recordError(
                throwable = e,
                screenName = ScreenNames.TEMPLATES,
                moduleName = DiagnosticModules.REPORTS,
                operationName = "استيراد قالب JSON",
                linkedOperationId = trace?.operationId.orEmpty(),
                failedStage = "تحليل JSON القالب",
            )
            trace?.fail(e.message ?: "تعذر استيراد القالب", err?.errorId.orEmpty())
            Result.failure(e)
        }
    }
}
