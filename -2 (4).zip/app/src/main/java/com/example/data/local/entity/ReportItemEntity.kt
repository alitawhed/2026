package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "ReportItems",
    foreignKeys = [
        ForeignKey(
            entity = ReportEntity::class,
            parentColumns = ["id"],
            childColumns = ["reportId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["reportId"])],
)
data class ReportItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val reportId: Long,
    val sourceProductId: Long? = null,
    val sortOrder: Int = 0,
    val serialNumber: Int = 1,
    val productNameSnapshot: String,
    val descriptionSnapshot: String = "",
    val categorySnapshot: String = "",
    val originCountrySnapshot: String = "",
    val manufacturerSnapshot: String = "",
    val primaryBarcodeSnapshot: String = "",
    val primaryBarcodeTypeSnapshot: String = "CODE_128",
    val imageSnapshotPath: String = "",
    val unitPrice: Double = 0.0,
    val quantity: Double = 1.0,
    val discountPercent: Double = 0.0,
    val discountAmount: Double = 0.0,
    val lineTotal: Double = 0.0,
    val notes: String = "",
    val customFieldsJson: String = "{}",
)
