package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "Reports",
    indices = [
        Index(value = ["reportNumber"]),
        Index(value = ["clientName"]),
        Index(value = ["isArchived"]),
        Index(value = ["updatedAt"]),
    ],
)
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val reportNumber: String,
    val title: String,
    val reportDate: Long = System.currentTimeMillis(),
    val clientName: String = "",
    val clientPhone: String = "",
    val clientContact: String = "",
    val clientAddress: String = "",
    val currency: String = "ر.س",
    val notes: String = "",
    val companyName: String = "",
    val companyAddress: String = "",
    val companyPhone: String = "",
    val companyLogoPath: String = "",
    val headerTitle: String = "",
    val termsAndConditions: String = "",
    val responsiblePerson: String = "",
    val signaturePath: String = "",
    val stampPath: String = "",
    val customFieldsJson: String = "{}",
    val templateId: Long? = null,
    val paperSize: String = "A4",
    val customWidthMm: Float = 210f,
    val customHeightMm: Float = 297f,
    val orientation: String = "PORTRAIT",
    val marginTopMm: Float = 12f,
    val marginBottomMm: Float = 12f,
    val marginStartMm: Float = 10f,
    val marginEndMm: Float = 10f,
    val duplicateBehavior: String = "INCREMENT_QTY",
    val columnDistributionMode: String = "AUTO_FIT",
    val headerFooterConfigJson: String = "{}",
    val barcodeStyleConfigJson: String = "{}",
    val splitHorizontalGroups: Boolean = false,
    val rowSortMode: String = "MANUAL",
    val isArchived: Boolean = false,
    val isSaved: Boolean = true,
    val versionNumber: Int = 1,
    val parentReportId: Long? = null,
    val lastPdfPath: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
