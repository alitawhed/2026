package com.example.data.repository

import android.net.Uri
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.DashboardStats
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.storage.MediaStorageManager
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.SaveStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import java.util.UUID

class DuplicateBarcodeException(
    val barcodeValue: String,
    val conflictingProductId: Long,
    val conflictingProductName: String,
) : Exception("الباركود ($barcodeValue) مستخدم مسبقاً في المنتج: $conflictingProductName")

data class BarcodeProductMatch(
    val product: ProductWithDetails,
    val matchedBarcode: ProductBarcodeEntity,
)

class ProductRepository(
    private val db: AppDatabase,
    private val mediaStorage: MediaStorageManager,
    private val errorMonitor: GlobalErrorMonitor? = null,
    private val barcodeService: com.example.domain.barcode.BarcodeService? = null,
) {
    private val productDao = db.productDao()
    private val categoryDao = db.categoryDao()
    private val settingsDao = db.settingsDao()
    private val inventoryDao = db.inventoryDao()

    private val _saveStatus = MutableStateFlow(SaveStatus.IDLE)
    val saveStatus: StateFlow<SaveStatus> = _saveStatus.asStateFlow()

    val allProducts: Flow<List<ProductWithDetails>> = productDao.observeAllProductsWithDetails()
    val recentProducts: Flow<List<ProductWithDetails>> = productDao.observeRecentProducts(5)
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.observeAllCategories()

    fun observeProduct(productId: Long): Flow<ProductWithDetails?> =
        productDao.observeProductWithDetails(productId)

    fun observeDashboardProductMetrics(): Flow<DashboardStats> = combine(
        productDao.observeProductCount(),
        productDao.observeBarcodeCount(),
        productDao.observeProductsWithoutImagesCount(),
        productDao.observeMultiBarcodeProductsCount(),
        productDao.observeImageCount(),
        productDao.observeMultiImageProductsCount(),
    ) { arr ->
        val products = arr[0] as Int
        val barcodes = arr[1] as Int
        val noImages = arr[2] as Int
        val multiBarcode = arr[3] as Int
        val totalImages = arr[4] as Int
        val multiImages = arr[5] as Int
        DashboardStats(
            totalProducts = products,
            totalBarcodes = barcodes,
            productsWithoutImages = noImages,
            productsWithMultipleBarcodes = multiBarcode,
            totalImages = totalImages,
            multiImageProducts = multiImages,
        )
    }

    suspend fun findProductByExactBarcode(barcodeValue: String): ProductWithDetails? {
        val trimmed = barcodeValue.trim()
        if (trimmed.isEmpty()) return null
        val barcode = productDao.findBarcodeExact(trimmed) ?: return null
        return productDao.getProductWithDetails(barcode.productId)
    }

    suspend fun findProductAndBarcodeExact(barcodeValue: String): BarcodeProductMatch? {
        val trimmed = barcodeValue.trim()
        if (trimmed.isEmpty()) return null
        val barcode = productDao.findBarcodeExact(trimmed) ?: return null
        val product = productDao.getProductWithDetails(barcode.productId) ?: return null
        return BarcodeProductMatch(product = product, matchedBarcode = barcode)
    }

    suspend fun getProductWithDetailsOnce(productId: Long): ProductWithDetails? {
        if (productId <= 0L) return null
        return productDao.getProductWithDetails(productId)
    }

    fun filterProductsUnified(
        products: List<ProductWithDetails>,
        query: String,
    ): List<ProductWithDetails> {
        val q = query.trim()
        if (q.isEmpty()) return products
        return products.filter { item ->
            item.product.name.contains(q, ignoreCase = true) ||
                item.product.internalCode.contains(q, ignoreCase = true) ||
                item.product.description.contains(q, ignoreCase = true) ||
                item.product.categoryName.contains(q, ignoreCase = true) ||
                item.product.customFieldsJson.contains(q, ignoreCase = true) ||
                item.barcodes.any { b ->
                    b.barcodeValue.contains(q, ignoreCase = true) ||
                        b.label.contains(q, ignoreCase = true) ||
                        b.description.contains(q, ignoreCase = true) ||
                        b.unitType.contains(q, ignoreCase = true)
                }
        }
    }

    suspend fun checkBarcodeConflict(barcodeValue: String, excludeProductId: Long = 0L): ProductWithDetails? {
        val trimmed = barcodeValue.trim()
        if (trimmed.isEmpty()) return null
        val existing = productDao.findBarcodeExact(trimmed) ?: return null
        if (existing.productId == excludeProductId) return null
        return productDao.getProductWithDetails(existing.productId)
    }

    suspend fun createOrUpdateProduct(
        product: ProductEntity,
        barcodes: List<ProductBarcodeEntity>,
        images: List<ProductImageEntity>,
    ): Result<Long> {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCT_EDITOR,
            moduleName = DiagnosticModules.PRODUCTS,
            operationName = if (product.id == 0L) "إضافة منتج جديد" else "تعديل بيانات منتج",
            initialStage = "التحقق من التصنيف والباركودات",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val savedId = db.withTransaction {
                val now = System.currentTimeMillis()
                val categoryName = product.categoryName.trim()
                val resolvedCategoryId = if (categoryName.isNotBlank()) {
                    val existingCat = categoryDao.findByName(categoryName)
                    existingCat?.id ?: categoryDao.insertCategory(CategoryEntity(name = categoryName))
                } else {
                    product.categoryId
                }

                val internalCode = product.internalCode.trim().ifBlank {
                    "PRD-${UUID.randomUUID().toString().take(6).uppercase()}"
                }

                val entityToSave = product.copy(
                    internalCode = internalCode,
                    categoryId = resolvedCategoryId,
                    categoryName = categoryName,
                    updatedAt = now,
                    createdAt = if (product.id == 0L) now else product.createdAt,
                )

                trace?.stage("حفظ سجل المنتج الأساسي")
                val productId = if (product.id == 0L) {
                    productDao.insertProduct(entityToSave)
                } else {
                    productDao.updateProduct(entityToSave)
                    product.id
                }

                // Validate barcode uniqueness globally before applying changes
                val cleanBarcodes = barcodes
                    .map { it.copy(barcodeValue = it.barcodeValue.trim()) }
                    .filter { it.barcodeValue.isNotEmpty() }

                val seenInList = HashSet<String>()
                for (b in cleanBarcodes) {
                    if (!seenInList.add(b.barcodeValue)) {
                        throw DuplicateBarcodeException(b.barcodeValue, productId, entityToSave.name)
                    }
                    val conflict = productDao.findBarcodeExact(b.barcodeValue)
                    if (conflict != null && conflict.productId != productId) {
                        val conflictProduct = productDao.getProductWithDetails(conflict.productId)
                        throw DuplicateBarcodeException(
                            b.barcodeValue,
                            conflict.productId,
                            conflictProduct?.product?.name ?: "#${conflict.productId}",
                        )
                    }
                }

                // Sync barcodes cleanly
                trace?.stage("حفظ ومزامنة الباركودات (${cleanBarcodes.size})")
                val defaultFormat = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                    settingsDao.getSettingsOnce()?.defaultBarcodeType,
                ) ?: BarcodeFormatType.CODE_128
                val existingBarcodes = productDao.getProductWithDetails(productId)?.barcodes.orEmpty()
                val keptIds = cleanBarcodes.mapNotNull { if (it.id > 0L) it.id else null }.toSet()
                existingBarcodes.filter { it.id !in keptIds }.forEach {
                    productDao.deleteBarcodeById(it.id)
                }

                val normalizedBarcodes = ensureSinglePrimaryBarcode(cleanBarcodes).map { b ->
                    val resolvedType = if (b.barcodeType.isBlank()) {
                        com.example.domain.barcode.BarcodeEngine
                            .resolveCompatibleDefaultFormat(b.barcodeValue, defaultFormat)
                            .name
                    } else {
                        b.barcodeType
                    }
                    b.copy(barcodeType = resolvedType)
                }
                normalizedBarcodes.forEach { b ->
                    val toSave = b.copy(productId = productId)
                    if (toSave.id == 0L) {
                        productDao.insertBarcode(toSave)
                    } else {
                        productDao.updateBarcode(toSave)
                    }
                }

                // Sync inventory snapshot barcodeType for existing items matching updated product barcodes
                val invItems = inventoryDao.getCountItemsForProductOnce(productId)
                if (invItems.isNotEmpty() && normalizedBarcodes.isNotEmpty()) {
                    val byValue = normalizedBarcodes.associateBy { it.barcodeValue }
                    invItems.forEach { inv ->
                        val matched = byValue[inv.scannedBarcode]
                        if (matched != null && inv.barcodeType != matched.barcodeType) {
                            inventoryDao.updateCountItem(inv.copy(barcodeType = matched.barcodeType, updatedAt = now))
                        }
                    }
                }

                // Sync images
                trace?.stage("حفظ وربط الصور (${images.size})")
                val existingImages = productDao.getProductWithDetails(productId)?.images.orEmpty()
                val keptImgIds = images.mapNotNull { if (it.id > 0L) it.id else null }.toSet()
                existingImages.filter { it.id !in keptImgIds }.forEach { removed ->
                    productDao.deleteImageById(removed.id)
                    mediaStorage.deleteFileIfInternal(removed.filePath)
                    mediaStorage.deleteFileIfInternal(removed.originalFilePath)
                    mediaStorage.deleteFileIfInternal(removed.thumbnailPath)
                }
                val normalizedImages = ensureSinglePrimaryImage(images)
                normalizedImages.forEachIndexed { idx, img ->
                    val orig = img.originalFilePath.ifBlank {
                        mediaStorage.ensureOriginalBackup(img.filePath, "")
                    }
                    val thumb = img.thumbnailPath.ifBlank {
                        mediaStorage.generateThumbnail(img.filePath)
                    }
                    val prepared = img.copy(
                        productId = productId,
                        originalFilePath = orig,
                        thumbnailPath = thumb,
                        sortOrder = idx,
                    )
                    if (prepared.id == 0L) {
                        productDao.insertImage(prepared)
                    } else {
                        productDao.updateImage(prepared)
                    }
                }
                syncInventorySnapshotImageLocked(productId)

                productId
            }
            productDao.getProductWithDetails(savedId)?.barcodes?.forEach { savedBc ->
                barcodeService?.bumpVersionAndInvalidate(savedId, savedBc.barcodeValue)
                val fmt = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(savedBc.barcodeType)
                if (fmt != null) {
                    barcodeService?.prewarmProductBarcodeImage(savedId, savedBc.barcodeValue, fmt)
                }
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم حفظ المنتج #$savedId")
            Result.success(savedId)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            if (e is DuplicateBarcodeException) {
                trace?.warn(e.message ?: "باركود مكرر")
            } else {
                val err = errorMonitor?.recordError(
                    throwable = e,
                    screenName = ScreenNames.PRODUCT_EDITOR,
                    moduleName = DiagnosticModules.PRODUCTS,
                    operationName = "حفظ أو تعديل منتج",
                    linkedOperationId = trace?.operationId.orEmpty(),
                )
                trace?.fail(e.message ?: "فشل حفظ المنتج", err?.errorId.orEmpty())
            }
            Result.failure(e)
        }
    }

    suspend fun addBarcodeToProduct(
        productId: Long,
        barcodeValue: String,
        format: BarcodeFormatType? = null,
        label: String,
        makePrimary: Boolean,
        description: String = "",
        unitType: String = "حبة",
        conversionFactor: Double = 1.0,
    ): Result<Long> {
        val trimmed = barcodeValue.trim()
        if (trimmed.isEmpty()) return Result.failure(IllegalArgumentException("قيمة الباركود مطلوبة"))
        if (conversionFactor <= 0.0) {
            return Result.failure(IllegalArgumentException("معامل التحويل يجب أن يكون أكبر من صفر"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCT_DETAIL,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "إضافة باركود للمنتج",
            initialStage = "فحص التفرد وإدراج الباركود",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val savedDefault = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                settingsDao.getSettingsOnce()?.defaultBarcodeType,
            ) ?: BarcodeFormatType.CODE_128
            val resolvedFormat = format
                ?: com.example.domain.barcode.BarcodeEngine.resolveCompatibleDefaultFormat(trimmed, savedDefault)
            val id = db.withTransaction {
                val now = System.currentTimeMillis()
                val conflict = productDao.findBarcodeExact(trimmed)
                if (conflict != null) {
                    val conflictProduct = productDao.getProductWithDetails(conflict.productId)
                    throw DuplicateBarcodeException(
                        trimmed,
                        conflict.productId,
                        conflictProduct?.product?.name ?: "#${conflict.productId}",
                    )
                }
                val existing = productDao.getProductWithDetails(productId)?.barcodes.orEmpty()
                val shouldBePrimary = makePrimary || existing.none { it.isPrimary }
                val resolvedUnit = unitType.trim().ifBlank { "حبة" }
                val resolvedLabel = label.trim().ifBlank { resolvedUnit }
                val insertedId = productDao.insertBarcode(
                    ProductBarcodeEntity(
                        productId = productId,
                        barcodeValue = trimmed,
                        barcodeType = resolvedFormat.name,
                        label = resolvedLabel,
                        description = description.trim(),
                        unitType = resolvedUnit,
                        conversionFactor = conversionFactor,
                        isPrimary = shouldBePrimary,
                        createdAt = now,
                        updatedAt = now,
                    ),
                )
                if (shouldBePrimary) {
                    productDao.setPrimaryBarcode(productId, insertedId)
                }
                val prod = productDao.getProductWithDetails(productId)?.product
                if (prod != null) {
                    productDao.updateProduct(prod.copy(updatedAt = now))
                }
                insertedId
            }
            barcodeService?.bumpVersionAndInvalidate(productId, trimmed)
            barcodeService?.prewarmProductBarcodeImage(productId, trimmed, resolvedFormat)
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تمت إضافة الباركود #$id")
            Result.success(id)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            if (e is DuplicateBarcodeException) {
                trace?.warn(e.message ?: "باركود مكرر")
            } else {
                val err = errorMonitor?.recordError(
                    throwable = e,
                    screenName = ScreenNames.PRODUCT_DETAIL,
                    moduleName = DiagnosticModules.BARCODE_CAMERA,
                    operationName = "إضافة باركود للمنتج",
                    linkedOperationId = trace?.operationId.orEmpty(),
                )
                trace?.fail(e.message ?: "فشل إضافة الباركود", err?.errorId.orEmpty())
            }
            Result.failure(e)
        }
    }

    suspend fun updateBarcode(barcode: ProductBarcodeEntity): Result<Unit> {
        val trimmed = barcode.barcodeValue.trim()
        if (trimmed.isEmpty()) return Result.failure(IllegalArgumentException("قيمة الباركود مطلوبة"))
        if (barcode.conversionFactor <= 0.0) {
            return Result.failure(IllegalArgumentException("معامل التحويل يجب أن يكون أكبر من صفر"))
        }
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCT_DETAIL,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "تعديل باركود المنتج",
            initialStage = "التحقق من التفرد والتحديث",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            val savedDefault = com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(
                settingsDao.getSettingsOnce()?.defaultBarcodeType,
            ) ?: BarcodeFormatType.CODE_128
            val resolvedType = if (barcode.barcodeType.isBlank()) {
                com.example.domain.barcode.BarcodeEngine
                    .resolveCompatibleDefaultFormat(trimmed, savedDefault)
                    .name
            } else {
                barcode.barcodeType
            }
            db.withTransaction {
                val now = System.currentTimeMillis()
                val conflict = productDao.findBarcodeExact(trimmed)
                if (conflict != null && conflict.id != barcode.id) {
                    val conflictProduct = productDao.getProductWithDetails(conflict.productId)
                    throw DuplicateBarcodeException(
                        trimmed,
                        conflict.productId,
                        conflictProduct?.product?.name ?: "#${conflict.productId}",
                    )
                }
                val resolvedUnit = barcode.unitType.trim().ifBlank { "حبة" }
                val resolvedLabel = barcode.label.trim().ifBlank { resolvedUnit }
                productDao.updateBarcode(
                    barcode.copy(
                        barcodeValue = trimmed,
                        barcodeType = resolvedType,
                        label = resolvedLabel,
                        description = barcode.description.trim(),
                        unitType = resolvedUnit,
                        updatedAt = now,
                    ),
                )
                if (barcode.isPrimary) {
                    productDao.setPrimaryBarcode(barcode.productId, barcode.id)
                }
                productDao.getProductWithDetails(barcode.productId)?.product?.let {
                    productDao.updateProduct(it.copy(updatedAt = now))
                }
                inventoryDao.getCountItemsForProductOnce(barcode.productId)
                    .filter { it.scannedBarcode == trimmed }
                    .forEach { inv ->
                        if (inv.barcodeType != resolvedType) {
                            inventoryDao.updateCountItem(inv.copy(barcodeType = resolvedType, updatedAt = now))
                        }
                    }
            }
            barcodeService?.bumpVersionAndInvalidate(barcode.productId, trimmed)
            com.example.domain.barcode.BarcodeEngine.parseFormatOrNull(resolvedType)?.let { fmt ->
                barcodeService?.prewarmProductBarcodeImage(barcode.productId, trimmed, fmt)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم تعديل الباركود #$trimmed")
            Result.success(Unit)
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            if (e is DuplicateBarcodeException) {
                trace?.warn(e.message ?: "باركود مكرر")
            } else {
                val err = errorMonitor?.recordError(
                    throwable = e,
                    screenName = ScreenNames.PRODUCT_DETAIL,
                    moduleName = DiagnosticModules.BARCODE_CAMERA,
                    operationName = "تعديل باركود المنتج",
                    linkedOperationId = trace?.operationId.orEmpty(),
                )
                trace?.fail(e.message ?: "تعذر تعديل الباركود", err?.errorId.orEmpty())
            }
            Result.failure(e)
        }
    }

    suspend fun setPrimaryBarcode(productId: Long, barcodeId: Long) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCT_DETAIL,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "تعيين الباركود الأساسي",
            initialStage = "تحديث قاعدة البيانات",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                productDao.setPrimaryBarcode(productId, barcodeId)
                productDao.getProductWithDetails(productId)?.product?.let {
                    productDao.updateProduct(it.copy(updatedAt = System.currentTimeMillis()))
                }
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCT_DETAIL,
                DiagnosticModules.BARCODE_CAMERA,
                "تعيين الباركود الأساسي",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل تعيين الباركود الأساسي", err?.errorId.orEmpty())
        }
    }

    suspend fun deleteBarcode(productId: Long, barcodeId: Long) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCT_DETAIL,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "حذف باركود المنتج",
            initialStage = "حذف السجل",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                productDao.deleteBarcodeById(barcodeId)
                val remaining = productDao.getProductWithDetails(productId)?.barcodes.orEmpty()
                if (remaining.isNotEmpty() && remaining.none { it.isPrimary }) {
                    productDao.setPrimaryBarcode(productId, remaining.first().id)
                }
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCT_DETAIL,
                DiagnosticModules.BARCODE_CAMERA,
                "حذف باركود المنتج",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل الحذف", err?.errorId.orEmpty())
        }
    }

    suspend fun addProductImageFromUri(productId: Long, uri: Uri, makePrimary: Boolean = false): String? {
        val stored = mediaStorage.saveProductImageWithOriginal(uri) ?: return null
        return addStoredImageTripletToProduct(productId, stored.activePath, stored.originalPath, stored.thumbnailPath, makePrimary)
    }

    suspend fun addProductImagesFromUris(productId: Long, uris: List<Uri>): Int {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.IMAGES,
            moduleName = DiagnosticModules.IMAGES,
            operationName = "إضافة مجموعة صور للمنتج",
            initialStage = "معالجة وحفظ ${uris.size} صور",
        )
        var added = 0
        uris.forEachIndexed { _, uri ->
            val stored = mediaStorage.saveProductImageWithOriginal(uri)
            if (stored != null) {
                val res = addStoredImageTripletToProduct(
                    productId = productId,
                    storedPath = stored.activePath,
                    originalPath = stored.originalPath,
                    thumbnailPath = stored.thumbnailPath,
                    makePrimary = false,
                )
                if (res != null) added++
            }
        }
        trace?.succeed("أُضيفت $added من ${uris.size} صور")
        return added
    }

    suspend fun addStoredImageToProduct(productId: Long, storedPath: String, makePrimary: Boolean = false): String? {
        val originalPath = mediaStorage.ensureOriginalBackup(storedPath, "")
        val thumbPath = mediaStorage.generateThumbnail(storedPath)
        return addStoredImageTripletToProduct(productId, storedPath, originalPath, thumbPath, makePrimary)
    }

    suspend fun addStoredImageTripletToProduct(
        productId: Long,
        storedPath: String,
        originalPath: String,
        thumbnailPath: String,
        makePrimary: Boolean = false,
    ): String? {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.IMAGES,
            moduleName = DiagnosticModules.IMAGES,
            operationName = "ربط صورة بالمنتج",
            initialStage = "تسجيل مسارات الصورة في قاعدة البيانات",
        )
        _saveStatus.value = SaveStatus.SAVING
        return try {
            db.withTransaction {
                val existing = productDao.getProductWithDetails(productId)?.images.orEmpty()
                val shouldBePrimary = makePrimary || existing.isEmpty()
                val insertedId = productDao.insertImage(
                    ProductImageEntity(
                        productId = productId,
                        filePath = storedPath,
                        originalFilePath = originalPath,
                        thumbnailPath = thumbnailPath,
                        isPrimary = shouldBePrimary,
                        sortOrder = existing.size,
                    ),
                )
                if (shouldBePrimary) {
                    productDao.setPrimaryImage(productId, insertedId)
                }
                syncInventorySnapshotImageLocked(productId, forceUpdate = shouldBePrimary)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم ربط الصورة بالمنتج #$productId")
            storedPath
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.IMAGES,
                DiagnosticModules.IMAGES,
                "ربط صورة بالمنتج",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل ربط الصورة", err?.errorId.orEmpty())
            null
        }
    }

    suspend fun getImageById(imageId: Long): ProductImageEntity? =
        productDao.getImageById(imageId)

    suspend fun updateImagePathsNonDestructive(
        imageId: Long,
        newActivePath: String,
        originalPath: String,
        newThumbnailPath: String,
    ) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                val current = productDao.getImageById(imageId) ?: return@withTransaction
                if (current.thumbnailPath != newThumbnailPath) {
                    mediaStorage.deleteFileIfInternal(current.thumbnailPath)
                }
                productDao.updateImage(
                    current.copy(
                        filePath = newActivePath,
                        originalFilePath = originalPath.ifBlank { current.originalFilePath },
                        thumbnailPath = newThumbnailPath,
                    ),
                )
                if (current.isPrimary) {
                    syncInventorySnapshotImageLocked(current.productId, forceUpdate = true)
                }
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.IMAGE_EDITOR, DiagnosticModules.IMAGES, "تحديث مسارات الصورة المعدلة")
        }
    }

    suspend fun replaceImageFromUri(imageId: Long, uri: Uri): Boolean {
        val current = productDao.getImageById(imageId) ?: return false
        val stored = mediaStorage.saveProductImageWithOriginal(uri) ?: return false
        db.withTransaction {
            mediaStorage.deleteFileIfInternal(current.filePath)
            mediaStorage.deleteFileIfInternal(current.originalFilePath)
            mediaStorage.deleteFileIfInternal(current.thumbnailPath)
            productDao.updateImage(
                current.copy(
                    filePath = stored.activePath,
                    originalFilePath = stored.originalPath,
                    thumbnailPath = stored.thumbnailPath,
                ),
            )
            if (current.isPrimary) {
                syncInventorySnapshotImageLocked(current.productId, forceUpdate = true)
            }
        }
        return true
    }

    suspend fun rotateProductImageById(imageId: Long, degrees: Int = 90): Boolean {
        val current = productDao.getImageById(imageId) ?: return false
        val origBackup = mediaStorage.ensureOriginalBackup(current.filePath, current.originalFilePath)
        val ok = mediaStorage.rotateImageFile(current.filePath, degrees.toFloat())
        if (!ok) return false
        mediaStorage.deleteFileIfInternal(current.thumbnailPath)
        val newThumb = mediaStorage.generateThumbnail(current.filePath)
        db.withTransaction {
            productDao.updateImage(
                current.copy(
                    originalFilePath = origBackup.ifBlank { current.originalFilePath },
                    thumbnailPath = newThumb,
                ),
            )
            if (current.isPrimary) {
                syncInventorySnapshotImageLocked(current.productId, forceUpdate = true)
            }
        }
        return true
    }

    suspend fun cropProductImageById(
        imageId: Long,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
    ): Boolean {
        val current = productDao.getImageById(imageId) ?: return false
        val origBackup = mediaStorage.ensureOriginalBackup(current.filePath, current.originalFilePath)
        val ok = mediaStorage.cropImageFile(current.filePath, left, top, right, bottom)
        if (!ok) return false
        mediaStorage.deleteFileIfInternal(current.thumbnailPath)
        val newThumb = mediaStorage.generateThumbnail(current.filePath)
        db.withTransaction {
            productDao.updateImage(
                current.copy(
                    originalFilePath = origBackup.ifBlank { current.originalFilePath },
                    thumbnailPath = newThumb,
                ),
            )
            if (current.isPrimary) {
                syncInventorySnapshotImageLocked(current.productId, forceUpdate = true)
            }
        }
        return true
    }

    suspend fun setPrimaryImage(productId: Long, imageId: Long) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                productDao.setPrimaryImage(productId, imageId)
                syncInventorySnapshotImageLocked(productId, forceUpdate = true)
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "تعيين الصورة الأساسية")
        }
    }

    suspend fun reorderImages(productId: Long, orderedImages: List<ProductImageEntity>) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            productDao.updateImages(
                orderedImages.mapIndexed { idx, img -> img.copy(productId = productId, sortOrder = idx) },
            )
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "إعادة ترتيب صور المنتج")
        }
    }

    suspend fun deleteProductImage(productId: Long, image: ProductImageEntity) {
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                productDao.deleteImageById(image.id)
                mediaStorage.deleteFileIfInternal(image.filePath)
                mediaStorage.deleteFileIfInternal(image.originalFilePath)
                mediaStorage.deleteFileIfInternal(image.thumbnailPath)
                val remaining = productDao.getProductWithDetails(productId)?.images.orEmpty()
                if (remaining.isNotEmpty() && remaining.none { it.isPrimary }) {
                    productDao.setPrimaryImage(productId, remaining.first().id)
                }
                syncInventorySnapshotImageLocked(productId, forceUpdate = true)
            }
            _saveStatus.value = SaveStatus.SAVED
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            errorMonitor?.recordError(e, ScreenNames.IMAGES, DiagnosticModules.IMAGES, "حذف صورة المنتج")
        }
    }

    suspend fun duplicateProduct(sourceId: Long): Result<Long> {
        val src = productDao.getProductWithDetails(sourceId)
            ?: return Result.failure(IllegalArgumentException("المنتج غير موجود"))
        // Copy images to fresh files; do NOT copy barcodes because barcodes must be globally unique!
        val copiedImages = src.images.mapIndexedNotNull { idx, img ->
            val srcFile = java.io.File(img.filePath)
            if (srcFile.exists()) {
                val newPath = mediaStorage.saveProductImageFromBytes(srcFile.readBytes())
                newPath?.let {
                    ProductImageEntity(productId = 0L, filePath = it, isPrimary = img.isPrimary, sortOrder = idx)
                }
            } else null
        }
        val copyEntity = src.product.copy(
            id = 0L,
            internalCode = "",
            name = "${src.product.name} (نسخة)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
        )
        return createOrUpdateProduct(copyEntity, emptyList(), copiedImages)
    }

    suspend fun deleteProduct(productId: Long) {
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.PRODUCTS,
            operationName = "حذف منتج",
            initialStage = "حذف السجل والصور المرتبطة #$productId",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            val details = productDao.getProductWithDetails(productId)
            db.withTransaction {
                details?.let {
                    productDao.deleteProduct(it.product)
                }
            }
            details?.images?.forEach {
                mediaStorage.deleteFileIfInternal(it.filePath)
                mediaStorage.deleteFileIfInternal(it.originalFilePath)
                mediaStorage.deleteFileIfInternal(it.thumbnailPath)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCTS,
                DiagnosticModules.PRODUCTS,
                "حذف منتج",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل حذف المنتج", err?.errorId.orEmpty())
        }
    }

    suspend fun deleteProductsBulk(ids: List<Long>) {
        if (ids.isEmpty()) return
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.PRODUCTS,
            operationName = "حذف مجموعة منتجات",
            initialStage = "حذف ${ids.size} منتج",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            val all = ids.mapNotNull { productDao.getProductWithDetails(it) }
            db.withTransaction {
                productDao.deleteProductsByIds(ids)
            }
            all.flatMap { it.images }.forEach {
                mediaStorage.deleteFileIfInternal(it.filePath)
                mediaStorage.deleteFileIfInternal(it.originalFilePath)
                mediaStorage.deleteFileIfInternal(it.thumbnailPath)
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed("تم حذف ${ids.size} منتج")
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCTS,
                DiagnosticModules.PRODUCTS,
                "حذف مجموعة منتجات",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل الحذف الجماعي", err?.errorId.orEmpty())
        }
    }

    suspend fun updateCategoryBulk(ids: List<Long>, categoryName: String) {
        if (ids.isEmpty()) return
        val trace = errorMonitor?.operationLogger?.startOperation(
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.PRODUCTS,
            operationName = "تحديث تصنيف مجموعة منتجات",
            initialStage = "تحديث التصنيف إلى ($categoryName)",
        )
        _saveStatus.value = SaveStatus.SAVING
        try {
            db.withTransaction {
                val trimmed = categoryName.trim()
                val catId = if (trimmed.isNotEmpty()) {
                    categoryDao.findByName(trimmed)?.id ?: categoryDao.insertCategory(CategoryEntity(name = trimmed))
                } else null
                productDao.updateCategoryForProducts(ids, catId, trimmed, System.currentTimeMillis())
            }
            _saveStatus.value = SaveStatus.SAVED
            trace?.succeed()
        } catch (e: Exception) {
            _saveStatus.value = SaveStatus.ERROR
            val err = errorMonitor?.recordError(
                e,
                ScreenNames.PRODUCTS,
                DiagnosticModules.PRODUCTS,
                "تحديث تصنيف مجموعة منتجات",
                linkedOperationId = trace?.operationId.orEmpty(),
            )
            trace?.fail(e.message ?: "فشل تحديث التصنيف", err?.errorId.orEmpty())
        }
    }

    suspend fun ensureCategory(name: String): Long? {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return null
        return categoryDao.findByName(trimmed)?.id ?: categoryDao.insertCategory(CategoryEntity(name = trimmed))
    }

    private suspend fun syncInventorySnapshotImageLocked(
        productId: Long,
        forceUpdate: Boolean = false,
    ) {
        val inventoryDao = db.inventoryDao()
        val countItems = inventoryDao.getCountItemsForProductOnce(productId)
        if (countItems.isEmpty()) return
        val primaryImg = productDao.getProductWithDetails(productId)?.primaryImage
        val bestPath = primaryImg?.let { img ->
            listOf(img.filePath, img.thumbnailPath, img.originalFilePath)
                .map { com.example.data.storage.ImageService.cleanPath(it) }
                .firstOrNull { p -> p.isNotBlank() && java.io.File(p).exists() }
                .orEmpty()
        }.orEmpty()
        countItems.forEach { countItem ->
            val cleanExisting = com.example.data.storage.ImageService.cleanPath(countItem.productImagePath)
            val currentMissing = cleanExisting.isBlank() || !java.io.File(cleanExisting).exists()
            if (forceUpdate || currentMissing) {
                if (countItem.productImagePath != bestPath) {
                    inventoryDao.updateCountItem(countItem.copy(productImagePath = bestPath))
                }
            }
        }
    }

    private fun ensureSinglePrimaryBarcode(list: List<ProductBarcodeEntity>): List<ProductBarcodeEntity> {
        if (list.isEmpty()) return emptyList()
        val firstPrimaryIdx = list.indexOfFirst { it.isPrimary }.let { if (it >= 0) it else 0 }
        return list.mapIndexed { idx, item -> item.copy(isPrimary = idx == firstPrimaryIdx) }
    }

    private fun ensureSinglePrimaryImage(list: List<ProductImageEntity>): List<ProductImageEntity> {
        if (list.isEmpty()) return emptyList()
        val firstPrimaryIdx = list.indexOfFirst { it.isPrimary }.let { if (it >= 0) it else 0 }
        return list.mapIndexed { idx, item -> item.copy(isPrimary = idx == firstPrimaryIdx) }
    }
}
