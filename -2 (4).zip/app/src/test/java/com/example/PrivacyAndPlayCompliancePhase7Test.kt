package com.example

import android.content.Context
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductEntity
import com.example.di.SharedAppServices
import com.example.domain.billing.BillingConfigStore
import com.example.domain.billing.BillingGateway
import com.example.domain.billing.FreeFeature
import com.example.domain.billing.PlayBillingConfiguration
import com.example.domain.billing.SubscriptionEntitlementState
import com.example.domain.billing.SubscriptionPlanType
import com.example.domain.billing.SubscriptionStatus
import com.example.domain.model.DeveloperIdentity
import com.example.ui.screens.PrivacyAndDeletionScreen
import com.example.ui.theme.ReportManagerTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class Phase7FakeBillingGateway(context: Context) : BillingGateway {
    private val store = BillingConfigStore(context)
    private val _conn = MutableStateFlow(com.example.domain.billing.BillingConnectionState.IDLE)
    override val connectionState = _conn.asStateFlow()
    private val _offers = MutableStateFlow<List<com.example.domain.billing.SubscriptionOfferUiModel>>(emptyList())
    override val availableOffers = _offers.asStateFlow()
    val mutableEntitlement = MutableStateFlow(SubscriptionEntitlementState())
    override val entitlementState: StateFlow<SubscriptionEntitlementState> = mutableEntitlement.asStateFlow()
    override val billingConfiguration: StateFlow<PlayBillingConfiguration> = store.configuration
    private val _msg = MutableStateFlow<String?>(null)
    override val lastStatusMessage = _msg.asStateFlow()
    private val _busy = MutableStateFlow(false)
    override val isBusy = _busy.asStateFlow()
    var playSubscriptionsCenterOpened = false

    override fun connectAndRefresh(onComplete: (() -> Unit)?) {
        onComplete?.invoke()
    }

    override suspend fun refreshProductsAndPurchases() =
        com.example.domain.billing.BillingActionResult.Success("OK")

    override suspend fun launchSubscriptionPurchase(
        activity: android.app.Activity,
        offer: com.example.domain.billing.SubscriptionOfferUiModel,
        obfuscatedAccountUid: String?,
    ) = com.example.domain.billing.BillingActionResult.Cancelled("Cancelled")

    override suspend fun restorePurchases() =
        com.example.domain.billing.BillingActionResult.Failure("None")

    override suspend fun updateBillingConfiguration(config: PlayBillingConfiguration) {
        store.saveConfiguration(config)
    }

    override fun consumeStatusMessage() {
        _msg.value = null
    }

    override fun openPlaySubscriptionsCenter(context: Context) {
        playSubscriptionsCenterOpened = true
    }

    override fun release() = Unit
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PrivacyAndPlayCompliancePhase7Test {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun `privacy screen renders deletion distinction, manual url notice, developer email, and navigation actions`() {
        val fakeBilling = Phase7FakeBillingGateway(context)
        var accountMgmtOpened = false

        composeRule.setContent {
            ReportManagerTheme {
                PrivacyAndDeletionScreen(
                    billingGateway = fakeBilling,
                    onBack = {},
                    onOpenAccountManagement = { accountMgmtOpened = true },
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("privacy_data_scope_card").assertIsDisplayed()
        composeRule.onNodeWithTag("privacy_screen_list").performScrollToNode(hasTestTag("privacy_workspace_card"))
        composeRule.onNodeWithTag("privacy_workspace_card").assertIsDisplayed()
        composeRule.onNodeWithTag("privacy_screen_list").performScrollToNode(hasTestTag("privacy_deletion_policy_card"))
        composeRule.onNodeWithTag("privacy_deletion_policy_card").assertIsDisplayed()
        composeRule.onNodeWithTag("privacy_screen_list").performScrollToNode(hasTestTag("privacy_manual_setup_urls_card"))
        composeRule.onNodeWithTag("privacy_manual_setup_urls_card").assertIsDisplayed()

        composeRule.onNodeWithTag("privacy_screen_list").performScrollToNode(hasTestTag("privacy_actions_card"))
        composeRule.onNodeWithTag("privacy_actions_card").assertIsDisplayed()
        composeRule.onNodeWithText("بريد الخصوصية والدعم: ${DeveloperIdentity.DEVELOPER_EMAIL}").assertIsDisplayed()

        composeRule.onNodeWithTag("privacy_open_account_mgmt_btn").performClick()
        assertTrue(accountMgmtOpened)

        composeRule.onNodeWithTag("privacy_open_play_subscriptions_btn").performClick()
        assertTrue(fakeBilling.playSubscriptionsCenterOpened)
    }

    @Test
    fun `historical products, reports, and v6 backup restore remain fully accessible after subscription expiration`() = runBlocking {
        val fakeBilling = Phase7FakeBillingGateway(context)
        val shared = SharedAppServices(context, billingGatewayOverride = fakeBilling)
        val container = shared.workspaceManager.currentContainer()
        AppDatabase.ensureSeeded(container.database)

        // Start as active Pro, create product + report + backup
        fakeBilling.mutableEntitlement.value = SubscriptionEntitlementState(
            status = SubscriptionStatus.ACTIVE,
            planType = SubscriptionPlanType.PRO_MONTHLY,
            isAcknowledged = true,
        )
        assertTrue(shared.entitlementManager.isProActive())

        val prodId = container.productRepository.createOrUpdateProduct(
            ProductEntity(name = "منتج ما قبل الانتهاء", internalCode = "EXP-KEEP-1"),
            emptyList(),
            emptyList(),
        ).getOrThrow()
        val prodDetails = container.productRepository.getProductWithDetailsOnce(prodId)!!
        val reportId = container.reportRepository.createEmptyReport(customTitle = "تقرير محفوظ")
        container.reportRepository.addProductToReport(reportId, prodDetails)
        val backupFile = container.backupRestoreEngine.createBackupZip().getOrThrow()

        // Subscription expires -> ON_HOLD_EXPIRED
        fakeBilling.mutableEntitlement.value = SubscriptionEntitlementState(
            status = SubscriptionStatus.ON_HOLD_EXPIRED,
            planType = SubscriptionPlanType.FREE,
            isAcknowledged = false,
        )
        assertFalse(shared.entitlementManager.isProActive())

        // Historical data, report reading, free features, and BackupRestoreEngine v6 remain 100% accessible!
        assertTrue(shared.entitlementManager.canAccessFreeFeature(FreeFeature.READ_LEGACY_DATA))
        assertTrue(shared.entitlementManager.canAccessFreeFeature(FreeFeature.BACKUP_AND_RESTORE))
        assertEquals(1, container.productRepository.allProducts.first().count { it.product.internalCode == "EXP-KEEP-1" })
        val reportAfterExpiry = container.reportRepository.getReportOnce(reportId)!!
        assertEquals("تقرير محفوظ", reportAfterExpiry.report.title)
        assertEquals(1, reportAfterExpiry.items.size)

        val inspection = container.backupRestoreEngine.inspectBackupUri(Uri.fromFile(backupFile))
        assertTrue(inspection.isValid)
        val restored = container.backupRestoreEngine.restoreFromStagedZip(inspection.stagedZipFilePath, backupFile.name)
        assertTrue(restored.isSuccess)
    }
}
