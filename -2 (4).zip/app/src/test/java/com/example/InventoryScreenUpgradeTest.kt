package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.di.AppContainer
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.model.InventorySheetConfig
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ProductEditorScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.DuplicatePromptStep
import com.example.ui.viewmodel.InventoryViewModel
import com.example.ui.viewmodel.ProductsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w412dp-h915dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class InventoryScreenUpgradeTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var container: AppContainer

    private class CapturingPdfSession(
        val capturedText: MutableList<String>,
    ) : PdfSession {
        var pageCount = 0
            private set

        override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
            pageCount++
            return object : Canvas() {
                override fun drawText(text: String, x: Float, y: Float, paint: Paint) {
                    capturedText.add(text)
                }

                override fun drawText(text: String, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    capturedText.add(text.substring(start, end))
                }

                override fun drawText(text: CharSequence, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    capturedText.add(text.subSequence(start, end).toString())
                }
            }
        }

        override fun endPage() = Unit

        override fun writeTo(outputStream: OutputStream) {
            val minimalPdf = "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count $pageCount/Kids[]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
            outputStream.write(minimalPdf.toByteArray(Charsets.US_ASCII))
        }

        override fun close() = Unit
    }

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        container = AppContainer(context)
        runBlocking {
            AppDatabase.ensureSeeded(container.database)
            container.database.inventoryDao().getAllSessionsOnce().forEach {
                container.inventoryRepository.deleteSession(it.id)
            }
            container.database.productDao().getAllProductsOnce().forEach {
                container.productRepository.deleteProduct(it.id)
            }
            container.settingsRepository.saveInventoryConfig(InventorySheetConfig())
        }
    }

    @After
    fun tearDown() {
        container.barcodeService.closeForTest()
    }

    private fun waitWithLooper(
        timeoutMs: Long = 8000L,
        vm: InventoryViewModel? = null,
        label: String = "condition",
        condition: () -> Boolean,
    ) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            composeRule.waitForIdle()
            if (condition()) return
            Thread.sleep(25)
        }
        Shadows.shadowOf(Looper.getMainLooper()).idle()
        composeRule.waitForIdle()
        if (!condition()) {
            val st = vm?.uiState?.value
            val diag = if (st != null) {
                " [session=${st.activeSession?.session?.id}, items=${st.activeSession?.items?.size}, " +
                    "pending=${st.pendingScanLookup != null}, qty='${st.qtyInput}', " +
                    "dup=${st.duplicatePrompt?.step}, submitting=${st.isSubmittingCount}, " +
                    "status='${st.statusMessage}', err=${st.isError}]"
            } else ""
            throw AssertionError("Timed out after ${timeoutMs}ms waiting for $label$diag")
        }
    }

    private fun seedDummyImageFile(name: String): String {
        val f = File(container.mediaStorage.productImagesDir, name)
        val bmp = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            bmp.recycle()
            f.writeBytes(out.toByteArray())
        }
        return f.absolutePath
    }

    private suspend fun seedSampleCatalog(): Triple<Long, Long, Long> {
        val img1 = seedDummyImageFile("coffee_test.png")
        val p1 = container.productRepository.createOrUpdateProduct(
            ProductEntity(
                internalCode = "ITM-101",
                name = "قهوة عربية فاخرة",
                categoryName = "مشروبات ساخنة",
                basePrice = 42.5,
                defaultQuantity = 25.0,
                customFieldsJson = Json.encodeToString(mapOf("GTIN" to "06281000011223")),
            ),
            listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "6281111222233",
                    label = "علبة",
                    unitType = "علبة",
                    conversionFactor = 1.0,
                    isPrimary = true,
                ),
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "CARTON-628",
                    label = "كرتون 12",
                    unitType = "كرتون",
                    conversionFactor = 12.0,
                    isPrimary = false,
                ),
            ),
            listOf(
                ProductImageEntity(
                    productId = 0L,
                    filePath = img1,
                    originalFilePath = img1,
                    thumbnailPath = img1,
                    isPrimary = true,
                    sortOrder = 0,
                ),
            ),
        ).getOrThrow()

        val p2 = container.productRepository.createOrUpdateProduct(
            ProductEntity(
                internalCode = "ITM-202",
                name = "زيت زيتون بكر ممتاز",
                categoryName = "زيوت",
                basePrice = 58.0,
                defaultQuantity = 15.0,
            ),
            listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "009988776655",
                    label = "عبوة",
                    unitType = "عبوة",
                    conversionFactor = 1.0,
                    isPrimary = true,
                ),
            ),
            emptyList(),
        ).getOrThrow()

        val sid = container.inventoryRepository.createSession("جرد المستودع الشامل", "اختبار الترقية").getOrThrow()
        return Triple(p1, p2, sid)
    }

    @Test
    fun `search by name barcode and GTIN finds right products and adds existing item cleanly`() {
        val (p1, p2, sid) = runBlocking { seedSampleCatalog() }
        runBlocking {
            val all = container.productRepository.allProducts.first { it.size >= 2 }
            assertEquals(1, container.productRepository.filterProductsUnified(all, "قهوة عربية").size)
            assertEquals(1, container.productRepository.filterProductsUnified(all, "CARTON-628").size)
            assertEquals(1, container.productRepository.filterProductsUnified(all, "06281000011223").size)
        }

        val vm = InventoryViewModel(container)
        vm.selectSession(sid)

        composeRule.setContent {
            ReportManagerTheme {
                InventoryScreen(
                    viewModel = vm,
                    onBack = {},
                    onLaunchBarcodeCamera = {},
                    onOpenProductDetail = {},
                    onCreateNewProductWithBarcode = { _, _ -> },
                )
            }
        }
        waitWithLooper(vm = vm, label = "initial session & search button") {
            vm.uiState.value.activeSession?.session?.id == sid &&
                composeRule.onAllNodesWithTag("inventory_search_product_btn").fetchSemanticsNodes().isNotEmpty()
        }

        // Open product search dialog via "البحث عن منتج"
        composeRule.onNodeWithTag("inventory_search_product_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_search_product_btn").performClick()
        waitWithLooper(vm = vm, label = "picker search input") {
            composeRule.onAllNodesWithTag("inv_picker_search_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("inv_picker_search_input").performTextInput("009988776655")
        waitWithLooper(vm = vm, label = "picker product p2") {
            composeRule.onAllNodesWithTag("inv_picker_select_btn_$p2").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithTag("inv_picker_item_$p2").assertIsDisplayed()
        composeRule.onNodeWithTag("inv_picker_select_btn_$p2").performClick()
        waitWithLooper(vm = vm, label = "inventory qty input") {
            composeRule.onAllNodesWithTag("inventory_qty_input").fetchSemanticsNodes().isNotEmpty()
        }

        // Quantity input card should open without duplicate prompt
        composeRule.onNodeWithTag("inventory_qty_input").assertIsDisplayed()
        composeRule.onNodeWithTag("inventory_qty_input").performTextInput("7")
        composeRule.onNodeWithTag("inventory_submit_count_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_submit_count_btn").performClick()

        waitWithLooper(vm = vm, label = "p2 recorded with qty 7.0") {
            vm.uiState.value.activeSession?.items?.any { it.productId == p2 && it.countedQty == 7.0 } == true
        }

        runBlocking {
            // Verify main catalog stock untouched
            assertEquals(15.0, container.database.productDao().getProductWithDetails(p2)!!.product.defaultQuantity, 0.001)
            assertEquals(25.0, container.database.productDao().getProductWithDetails(p1)!!.product.defaultQuantity, 0.001)
        }
    }

    @Test
    fun `search miss lets user add new product in flow return without losing session items and add to count sheet`() {
        val (p1, _, sid) = runBlocking {
            val triple = seedSampleCatalog()
            val p1Details = container.productRepository.getProductWithDetailsOnce(triple.first)!!
            container.inventoryRepository.recordCountedItem(
                sessionId = triple.third,
                product = p1Details,
                scannedBarcode = "6281111222233",
                barcodeType = "EAN_13",
                unitType = "علبة",
                conversionFactor = 1.0,
                quantity = 4.0,
            ).getOrThrow()
            triple
        }

        val vm = InventoryViewModel(container)
        val productsVm = ProductsViewModel(container)
        vm.selectSession(sid)

        var showEditor = false
        var editorPrefillName = ""
        var returnedCreatedProductId: Long? = null

        composeRule.setContent {
            ReportManagerTheme {
                var editorOpen by remember { mutableStateOf(false) }
                var prefillNameState by remember { mutableStateOf("") }
                var createdIdState by remember { mutableStateOf<Long?>(null) }

                if (editorOpen) {
                    ProductEditorScreen(
                        productId = 0L,
                        prefillBarcode = "",
                        prefillBarcodeFormat = "",
                        viewModel = productsVm,
                        prefillName = prefillNameState,
                        onBack = { editorOpen = false },
                        onSaved = { savedId ->
                            createdIdState = savedId
                            returnedCreatedProductId = savedId
                            editorOpen = false
                        },
                        onJumpToConflictProduct = {},
                    )
                } else {
                    InventoryScreen(
                        viewModel = vm,
                        createdProductId = createdIdState,
                        onConsumeCreatedProductId = { createdIdState = null },
                        onBack = {},
                        onLaunchBarcodeCamera = {},
                        onOpenProductDetail = {},
                        onCreateNewProductWithBarcode = { _, _ -> },
                        onCreateNewProductFromSearch = { q ->
                            prefillNameState = q.trim()
                            editorPrefillName = q.trim()
                            showEditor = true
                            editorOpen = true
                        },
                    )
                }
            }
        }
        waitWithLooper(vm = vm, label = "session loaded with 1 item") {
            vm.uiState.value.activeSession?.items?.size == 1 &&
                composeRule.onAllNodesWithTag("inventory_search_product_btn").fetchSemanticsNodes().isNotEmpty()
        }

        // Open search and query non-existent product -> click "إضافة منتج جديد"
        composeRule.onNodeWithTag("inventory_search_product_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_search_product_btn").performClick()
        waitWithLooper(vm = vm, label = "picker search input (search miss)") {
            composeRule.onAllNodesWithTag("inv_picker_search_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("inv_picker_search_input").performTextInput("شاي أخضر عضوي")
        waitWithLooper(vm = vm, label = "empty create button") {
            composeRule.onAllNodesWithTag("inv_picker_empty_create_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("inv_picker_empty_create_btn").performClick()
        waitWithLooper(vm = vm, label = "product editor opened") {
            showEditor && composeRule.onAllNodesWithTag("save_product_btn").fetchSemanticsNodes().isNotEmpty()
        }

        assertEquals("شاي أخضر عضوي", editorPrefillName)

        // Save the prefilled new product in ProductEditorScreen -> returns to InventoryScreen automatically
        composeRule.onNodeWithTag("save_product_btn").performClick()
        waitWithLooper(vm = vm, label = "returned from editor to qty input") {
            returnedCreatedProductId != null &&
                composeRule.onAllNodesWithTag("inventory_qty_input").fetchSemanticsNodes().isNotEmpty()
        }

        // Enter quantity and confirm adding to sheet
        composeRule.onNodeWithTag("inventory_qty_input").performTextInput("12")
        composeRule.onNodeWithTag("inventory_submit_count_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_submit_count_btn").performClick()

        waitWithLooper(vm = vm, label = "session updated to 2 items") {
            vm.uiState.value.activeSession?.items?.size == 2
        }

        runBlocking {
            val items = container.inventoryRepository.getSessionOnce(sid)!!.items
            assertTrue(items.any { it.productId == p1 && it.countedQty == 4.0 })
            assertTrue(items.any { it.productId == returnedCreatedProductId && it.countedQty == 12.0 && it.productName == "شاي أخضر عضوي" })
            val createdProd = container.productRepository.getProductWithDetailsOnce(returnedCreatedProductId!!)
            assertNotNull(createdProd)
            assertEquals("شاي أخضر عضوي", createdProd!!.product.name)
        }
    }

    @Test
    fun `first scan does not alert duplicate while second scan alerts immediately with Add Replace and Cancel plus decimal and conflict handling`() {
        val (p1, _, sid) = runBlocking { seedSampleCatalog() }
        val vm = InventoryViewModel(container)
        vm.selectSession(sid)

        composeRule.setContent {
            ReportManagerTheme {
                InventoryScreen(
                    viewModel = vm,
                    onBack = {},
                    onLaunchBarcodeCamera = {},
                    onOpenProductDetail = {},
                    onCreateNewProductWithBarcode = { _, _ -> },
                )
            }
        }
        waitWithLooper(vm = vm, label = "active session sid") { vm.uiState.value.activeSession?.session?.id == sid }

        // 1. First scan of "6281111222233": NO duplicate dialog, qty input opens
        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "first scan pending lookup") {
            vm.uiState.value.pendingScanLookup != null &&
                composeRule.onAllNodesWithTag("inventory_qty_input").fetchSemanticsNodes().isNotEmpty()
        }
        assertNull(vm.uiState.value.duplicatePrompt)

        composeRule.onNodeWithTag("inventory_qty_input").performTextInput("10")
        composeRule.onNodeWithTag("inventory_submit_count_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_submit_count_btn").performClick()
        waitWithLooper(vm = vm, label = "first item saved with qty 10") {
            vm.uiState.value.activeSession?.items?.firstOrNull()?.countedQty == 10.0
        }

        // 2. Second scan of SAME barcode -> IMMEDIATE duplicate alert BEFORE entering qty!
        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "duplicate prompt dialog") {
            composeRule.onAllNodesWithTag("dup_prompt_title").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_title").assertIsDisplayed()
        composeRule.onNodeWithText("هذا المنتج مسجل مسبقاً في كشف الجرد").assertIsDisplayed()
        assertEquals(DuplicatePromptStep.CHOOSE, vm.uiState.value.duplicatePrompt!!.step)

        // Cancel leaves qty untouched (10.0)
        composeRule.onNodeWithTag("dup_prompt_cancel_btn").performClick()
        waitWithLooper(vm = vm, label = "duplicate prompt dismissed") { vm.uiState.value.duplicatePrompt == null }
        runBlocking {
            assertEquals(10.0, container.inventoryRepository.getSessionOnce(sid)!!.items.first().countedQty, 0.001)
        }

        // 3. Re-scan and select ADD_QUANTITY -> 10 + 5 = 15 (also tests live preview & double-tap protection)
        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "dup prompt choose add") {
            composeRule.onAllNodesWithTag("dup_prompt_choose_add_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_choose_add_btn").performClick()
        waitWithLooper(vm = vm, label = "dup prompt qty input (add)") {
            composeRule.onAllNodesWithTag("dup_prompt_qty_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_qty_input").performTextInput("5")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("dup_prompt_final_qty_preview").assertIsDisplayed()

        // Rapid double invocation of confirmDuplicatePrompt should only add once (10 + 5 = 15, NOT 20)
        composeRule.runOnUiThread {
            vm.confirmDuplicatePrompt()
            vm.confirmDuplicatePrompt()
        }
        waitWithLooper(vm = vm, label = "dup add confirmed 15.0") {
            vm.uiState.value.duplicatePrompt == null &&
                vm.uiState.value.activeSession?.items?.firstOrNull()?.countedQty == 15.0
        }
        runBlocking {
            assertEquals(15.0, container.inventoryRepository.getSessionOnce(sid)!!.items.first().countedQty, 0.001)
        }

        // 4. Re-scan and test decimal addition with Arabic digits: 15 -> replace with 2.5, then add ١٫٢٥ -> 3.75
        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "dup prompt choose replace") {
            composeRule.onAllNodesWithTag("dup_prompt_choose_replace_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_choose_replace_btn").performClick()
        waitWithLooper(vm = vm, label = "dup prompt qty input (replace)") {
            composeRule.onAllNodesWithTag("dup_prompt_qty_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_qty_input").performTextInput("2.5")
        composeRule.onNodeWithTag("dup_prompt_confirm_btn").performClick()
        waitWithLooper(vm = vm, label = "dup replace confirmed 2.5") {
            vm.uiState.value.duplicatePrompt == null &&
                vm.uiState.value.activeSession?.items?.firstOrNull()?.countedQty == 2.5
        }

        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "dup prompt choose add arabic decimal") {
            composeRule.onAllNodesWithTag("dup_prompt_choose_add_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_choose_add_btn").performClick()
        waitWithLooper(vm = vm, label = "dup prompt qty input (arabic decimal)") {
            composeRule.onAllNodesWithTag("dup_prompt_qty_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_qty_input").performTextInput("١٫٢٥")
        composeRule.onNodeWithTag("dup_prompt_confirm_btn").performClick()
        waitWithLooper(vm = vm, label = "dup add confirmed 3.75") {
            vm.uiState.value.duplicatePrompt == null &&
                vm.uiState.value.activeSession?.items?.firstOrNull()?.countedQty == 3.75
        }
        runBlocking {
            assertEquals(3.75, container.inventoryRepository.getSessionOnce(sid)!!.items.first().countedQty, 0.001)

            // 5. Simulate unit/conversion factor change on existing catalog barcode -> ADD button MUST be disabled!
            val existingProd = container.productRepository.getProductWithDetailsOnce(p1)!!
            container.productRepository.createOrUpdateProduct(
                existingProd.product,
                existingProd.barcodes.map {
                    if (it.barcodeValue == "6281111222233") it.copy(unitType = "كرتون", conversionFactor = 6.0) else it
                },
                existingProd.images,
            ).getOrThrow()
        }

        composeRule.runOnUiThread { vm.lookupBarcode("6281111222233") }
        waitWithLooper(vm = vm, label = "dup prompt unit conflict") {
            composeRule.onAllNodesWithTag("dup_prompt_choose_add_btn").fetchSemanticsNodes().isNotEmpty()
        }
        assertNotNull(vm.uiState.value.duplicatePrompt!!.unitConflictMessage)
        composeRule.onNodeWithTag("dup_prompt_choose_add_btn").assertIsNotEnabled()
        // Replace is still allowed when unit changed
        composeRule.onNodeWithTag("dup_prompt_choose_replace_btn").performClick()
        waitWithLooper(vm = vm, label = "dup prompt qty input (unit conflict replace)") {
            composeRule.onAllNodesWithTag("dup_prompt_qty_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dup_prompt_qty_input").performTextInput("5")
        composeRule.onNodeWithTag("dup_prompt_confirm_btn").performClick()
        waitWithLooper(vm = vm, label = "dup replace after conflict confirmed 5.0") {
            vm.uiState.value.duplicatePrompt == null &&
                vm.uiState.value.activeSession?.items?.firstOrNull()?.countedQty == 5.0
        }
        runBlocking {
            assertEquals("كرتون", container.inventoryRepository.getSessionOnce(sid)!!.items.first().unitType)
        }
    }

    @Test
    fun `column rename width reorder hide decimals undo redo persist immediately across live table PDF Excel and restarts while keeping reports isolated`() {
        val (p1, sid, reportId, initialReportCols) = runBlocking {
            val (p1, _, sid) = seedSampleCatalog()
            val p1Details = container.productRepository.getProductWithDetailsOnce(p1)!!
            container.inventoryRepository.recordCountedItem(
                sessionId = sid,
                product = p1Details,
                scannedBarcode = "6281111222233",
                barcodeType = "EAN_13",
                unitType = "علبة",
                conversionFactor = 1.0,
                quantity = 3.75,
            ).getOrThrow()

            val reportId = container.reportRepository.createEmptyReport(customTitle = "تقرير عزل الأعمدة")
            val initialCols = container.reportRepository.getReportOnce(reportId)!!.columns.map { it.columnKey to it.title }
            Quad(p1, sid, reportId, initialCols)
        }

        val vm = InventoryViewModel(container)
        vm.selectSession(sid)

        composeRule.setContent {
            ReportManagerTheme {
                InventoryScreen(
                    viewModel = vm,
                    onBack = {},
                    onLaunchBarcodeCamera = {},
                    onOpenProductDetail = {},
                    onCreateNewProductWithBarcode = { _, _ -> },
                )
            }
        }
        waitWithLooper(vm = vm, label = "column test initial item") { vm.uiState.value.activeSession?.items?.size == 1 }

        // Open Columns panel -> scroll to "name" column and edit title + width + height
        composeRule.onNodeWithTag("inventory_columns_panel_btn").performClick()
        waitWithLooper(vm = vm, label = "columns lazy list") {
            composeRule.onAllNodesWithTag("inv_columns_lazy_list").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("inv_columns_lazy_list").performScrollToNode(hasTestTag("inv_col_edit_name"))
        composeRule.onNodeWithTag("inv_col_edit_name").performClick()
        waitWithLooper(vm = vm, label = "edit column title dialog") {
            composeRule.onAllNodesWithTag("inv_edit_col_title_input").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithTag("inv_edit_col_title_input").performTextClearance()
        composeRule.onNodeWithTag("inv_edit_col_title_input").performTextInput("اسم الصنف المعتمد")
        composeRule.onNodeWithTag("inv_edit_col_width_input").performTextClearance()
        composeRule.onNodeWithTag("inv_edit_col_width_input").performTextInput("175")
        composeRule.onNodeWithTag("inv_edit_col_height_input").performTextClearance()
        composeRule.onNodeWithTag("inv_edit_col_height_input").performTextInput("54")
        composeRule.onNodeWithTag("inv_edit_col_save_btn").performClick()

        waitWithLooper(vm = vm, label = "name column atomic update") {
            val col = vm.uiState.value.inventoryConfig.columns.firstOrNull { it.columnKey == "name" }
            col?.title == "اسم الصنف المعتمد" && col.manualWidthPt == 175f && col.cellHeightPt == 54f
        }

        // Update quantity decimals to 2 fixed, toggle visibility of 'notes' off, & move 'quantity' before 'barcode'
        composeRule.runOnUiThread {
            vm.updateColumnNumberFormat("quantity", NumberFormatSpec(decimalPlaces = 2, autoDecimals = false, stripTrailingZeros = false))
        }
        composeRule.onNodeWithTag("inv_columns_lazy_list").performScrollToNode(hasTestTag("inv_col_vis_notes"))
        composeRule.onNodeWithTag("inv_col_vis_notes").performClick()
        val colsSnapshot = vm.uiState.value.inventoryConfig.columns.sortedBy { it.sortOrder }
        val qtyIdx = colsSnapshot.indexOfFirst { it.columnKey == "quantity" }
        val barcodeIdx = colsSnapshot.indexOfFirst { it.columnKey == "barcode" }
        assertTrue(qtyIdx > barcodeIdx)
        composeRule.runOnUiThread { vm.moveColumn(qtyIdx, barcodeIdx) }

        waitWithLooper(vm = vm, label = "quantity moved before barcode & notes hidden") {
            val cols = vm.uiState.value.inventoryConfig.columns.sortedBy { it.sortOrder }
            val qIdx = cols.indexOfFirst { it.columnKey == "quantity" }
            val bIdx = cols.indexOfFirst { it.columnKey == "barcode" }
            val notesVisible = cols.first { it.columnKey == "notes" }.visible
            qIdx < bIdx && !notesVisible
        }

        // Undo & Redo test
        composeRule.onNodeWithTag("inv_columns_undo_btn").performClick()
        waitWithLooper(vm = vm, label = "undo move") {
            val cols = vm.uiState.value.inventoryConfig.columns.sortedBy { it.sortOrder }
            cols.indexOfFirst { it.columnKey == "quantity" } > cols.indexOfFirst { it.columnKey == "barcode" }
        }
        composeRule.onNodeWithTag("inv_columns_redo_btn").performClick()
        waitWithLooper(vm = vm, label = "redo move") {
            val cols = vm.uiState.value.inventoryConfig.columns.sortedBy { it.sortOrder }
            cols.indexOfFirst { it.columnKey == "quantity" } < cols.indexOfFirst { it.columnKey == "barcode" }
        }

        // Dismiss modal bottom sheet and verify live table header reflects "اسم الصنف المعتمد" immediately
        composeRule.onNodeWithContentDescription("إغلاق").performClick()
        waitWithLooper(vm = vm, label = "live table header renamed") {
            composeRule.onAllNodesWithText("اسم الصنف المعتمد").fetchSemanticsNodes().isNotEmpty()
        }

        // Wait until serialized DB write completes
        waitWithLooper(vm = vm, label = "persisted inventory config in DB") {
            runBlocking {
                val cfg = container.settingsRepository.getInventoryConfigOnce()
                val col = cfg.columns.firstOrNull { it.columnKey == "name" }
                val cols = cfg.columns.sortedBy { it.sortOrder }
                col?.title == "اسم الصنف المعتمد" &&
                    col.manualWidthPt == 175f &&
                    col.cellHeightPt == 54f &&
                    !cols.first { it.columnKey == "notes" }.visible &&
                    cols.indexOfFirst { it.columnKey == "quantity" } < cols.indexOfFirst { it.columnKey == "barcode" }
            }
        }

        // Simulate restart via fresh InventoryViewModel (collected asynchronously while waitWithLooper pumps main looper)
        val freshVm = InventoryViewModel(container)
        var freshTitle: String? = null
        val freshCollectJob = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default).launch {
            freshVm.uiState.collect { st ->
                freshTitle = st.inventoryConfig.columns.firstOrNull { it.columnKey == "name" }?.title
            }
        }
        try {
            waitWithLooper(vm = freshVm, label = "freshVm loads renamed column after restart") {
                freshTitle == "اسم الصنف المعتمد"
            }
            assertEquals("اسم الصنف المعتمد", freshTitle)
        } finally {
            freshCollectJob.cancel()
        }

        runBlocking {
            val persistedConfig = container.settingsRepository.getInventoryConfigOnce()
            val persistedNameCol = persistedConfig.columns.first { it.columnKey == "name" }
            assertEquals("اسم الصنف المعتمد", persistedNameCol.title)
            assertEquals(175f, persistedNameCol.manualWidthPt, 0.1f)
            assertEquals(54f, persistedNameCol.cellHeightPt, 0.1f)
            assertFalse(persistedConfig.columns.first { it.columnKey == "notes" }.visible)

            // Verify Excel export uses exact renamed title, visible columns, reordered sequence, and decimals
            val sessionDetails = container.inventoryRepository.getSessionOnce(sid)!!
            val allProducts = container.productRepository.allProducts.first()
            val xlsx = container.excelExportEngine.exportInventoryReportToXlsx(
                sessionDetails = sessionDetails,
                allProducts = allProducts,
                fileName = "inv_upgrade_verify.xlsx",
                inventoryConfig = persistedConfig,
            )
            val parsed = container.excelImportEngine.parseBytes(xlsx.readBytes(), xlsx.name).getOrThrow().sheets.first()
            assertTrue(parsed.headers.contains("اسم الصنف المعتمد"))
            assertFalse(parsed.headers.contains("ملاحظات"))
            assertTrue(parsed.headers.indexOf("الكمية") < parsed.headers.indexOf("الباركود"))
            val dataRow = parsed.rows.drop(1).first { row -> row.any { it.contains("قهوة عربية فاخرة") } }
            assertEquals("3.75", dataRow[parsed.headers.indexOf("الكمية")])

            // Verify PDF export renders exact renamed column header cleanly
            val capturedPdfTexts = mutableListOf<String>()
            val pdfEngine = PdfGeneratorEngine(
                context = context,
                mediaStorage = container.mediaStorage,
                sessionFactory = PdfSessionFactory { CapturingPdfSession(capturedPdfTexts) },
            ).apply {
                drawnCellTextObserver = { txt -> capturedPdfTexts.add(txt) }
            }
            val pdfOut = pdfEngine.generateInventoryReportPdf(
                sessionDetails = sessionDetails,
                allProducts = allProducts,
                settings = container.settingsRepository.getSettingsOnce(),
                inventoryConfig = persistedConfig,
                outputFileName = "inv_upgrade_verify.pdf",
            )
            assertTrue(pdfOut.file.exists() && pdfOut.pageCount >= 1)
            assertTrue(capturedPdfTexts.any { it.contains("اسم الصنف المعتمد") })
            assertTrue(capturedPdfTexts.any { it.contains("3.75") })

            // Verify ReportColumns isolation (Reports untouched) & StockAdjustmentLogs empty & Products stock unchanged
            val reportColsAfter = container.reportRepository.getReportOnce(reportId)!!.columns.map { it.columnKey to it.title }
            assertEquals(initialReportCols, reportColsAfter)
            assertEquals(0, container.database.inventoryDao().getAllAdjustmentLogsOnce().size)
            assertEquals(25.0, container.database.productDao().getProductWithDetails(p1)!!.product.defaultQuantity, 0.001)
        }
    }

    @Test
    fun `hardware scanner newline triggers alt barcode lookup and direct table header edit preserves AUTO_FIT plus isolation from general settings saves`() {
        val (p1, _, sid) = runBlocking { seedSampleCatalog() }
        val vm = InventoryViewModel(container)
        vm.selectSession(sid)

        composeRule.setContent {
            ReportManagerTheme {
                InventoryScreen(
                    viewModel = vm,
                    onBack = {},
                    onLaunchBarcodeCamera = {},
                    onOpenProductDetail = {},
                    onCreateNewProductWithBarcode = { _, _ -> },
                )
            }
        }
        waitWithLooper(vm = vm, label = "active session sid") {
            vm.uiState.value.activeSession?.session?.id == sid &&
                composeRule.onAllNodesWithTag("inv_table_header_name").fetchSemanticsNodes().isNotEmpty()
        }

        // 1. Hardware scanner wedge input with trailing newline triggers lookup automatically
        composeRule.runOnUiThread { vm.onBarcodeInputChange("CARTON-628\r\n") }
        waitWithLooper(vm = vm, label = "alt barcode pending lookup") {
            val lookup = vm.uiState.value.pendingScanLookup as? com.example.data.repository.InventoryScanLookupResult.MatchedRegistered
            lookup?.barcodeValue == "CARTON-628" && lookup.isAlternativeBarcode && lookup.unitType == "كرتون"
        }

        // Submit qty = 2 for alt barcode carton
        composeRule.onNodeWithTag("inventory_qty_input").performTextInput("2")
        composeRule.onNodeWithTag("inventory_submit_count_btn").performScrollTo()
        composeRule.onNodeWithTag("inventory_submit_count_btn").performClick()
        waitWithLooper(vm = vm, label = "carton recorded qty 2") {
            vm.uiState.value.activeSession?.items?.any {
                it.productId == p1 && it.scannedBarcode == "CARTON-628" && it.countedQty == 2.0 && it.baseUnitEquivalentQty == 24.0
            } == true
        }

        // 2. Tap column header directly in Live Table -> open "تعديل اسم وخصائص هذا العمود" -> rename & verify AUTO_FIT stays intact
        composeRule.onNodeWithTag("inv_table_header_name").performClick()
        waitWithLooper(vm = vm, label = "header edit button visible") {
            composeRule.onAllNodesWithTag("inv_header_edit_col_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("inv_header_edit_col_btn").performClick()
        waitWithLooper(vm = vm, label = "direct header edit dialog open") {
            composeRule.onAllNodesWithTag("inv_edit_col_title_input").fetchSemanticsNodes().isNotEmpty()
        }

        // Blank title guard rejects empty title and keeps dialog open
        composeRule.onNodeWithTag("inv_edit_col_title_input").performTextClearance()
        composeRule.onNodeWithTag("inv_edit_col_save_btn").performClick()
        composeRule.waitForIdle()
        assertTrue(composeRule.onAllNodesWithTag("inv_edit_col_title_input").fetchSemanticsNodes().isNotEmpty())

        // Enter renamed title without altering width -> mode must stay AUTO_FIT
        composeRule.onNodeWithTag("inv_edit_col_title_input").performTextInput("اسم الصنف المحدث")
        composeRule.onNodeWithTag("inv_edit_col_save_btn").performClick()

        waitWithLooper(vm = vm, label = "direct header rename reflected in live table & DB") {
            composeRule.onAllNodesWithText("اسم الصنف المحدث").fetchSemanticsNodes().isNotEmpty() &&
                runBlocking {
                    val cfg = container.settingsRepository.getInventoryConfigOnce()
                    cfg.columns.firstOrNull { it.columnKey == "name" }?.title == "اسم الصنف المحدث"
                }
        }

        runBlocking {
            val cfgBefore = container.settingsRepository.getInventoryConfigOnce()
            assertEquals(com.example.domain.model.ColumnDistributionMode.AUTO_FIT, cfgBefore.distributionMode)

            // 3. Stale general settings save & default barcode update MUST NOT overwrite inventoryConfigJson
            val staleSnapshot = com.example.data.local.entity.AppSettingsEntity(companyName = "شركة اختبار")
            container.settingsRepository.saveSettings(staleSnapshot)
            container.barcodeService.updateDefaultBarcodeFormat(com.example.domain.model.BarcodeFormatType.QR_CODE).getOrThrow()

            val cfgAfter = container.settingsRepository.getInventoryConfigOnce()
            assertEquals("اسم الصنف المحدث", cfgAfter.columns.first { it.columnKey == "name" }.title)
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
