package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.InventoryRepository
import com.example.data.repository.InventoryScanLookupResult
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.repository.SettingsRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.barcode.BarcodeService
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ProductImportField
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BarcodeSystemOverhaulTest {

    private lateinit var context: Context
    private lateinit var dbFile: File
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var barcodeService: BarcodeService
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var productRepo: ProductRepository
    private lateinit var inventoryRepo: InventoryRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var excelImport: ExcelImportEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        dbFile = File(context.cacheDir, "barcode_overhaul_test_${System.nanoTime()}.db")
        mediaStorage = MediaStorageManager(context)
        mediaStorage.barcodeCacheDir.listFiles()?.forEach { it.delete() }
        openFreshDbAndServices()
        runBlocking {
            AppDatabase.ensureSeeded(db)
            assertEquals(BarcodeFormatType.CODE_128, barcodeService.getDefaultBarcodeType())
        }
    }

    @After
    fun tearDown() {
        barcodeService.closeForTest()
        db.close()
        mediaStorage.barcodeCacheDir.listFiles()?.forEach { it.delete() }
        dbFile.delete()
    }

    private fun openFreshDbAndServices() {
        db = Room.databaseBuilder(context, AppDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        barcodeService = BarcodeService(db, mediaStorage)
        settingsRepo = SettingsRepository(db)
        productRepo = ProductRepository(db, mediaStorage, barcodeService = barcodeService)
        inventoryRepo = InventoryRepository(db, barcodeService = barcodeService)
        reportRepo = ReportRepository(db, mediaStorage, barcodeService = barcodeService)
        excelImport = ExcelImportEngine(context, db, mediaStorage, barcodeService = barcodeService)
    }

    @Test
    fun `1 - default barcode type persists across DB close and reopen for all 7 supported formats`() = runBlocking {
        // Initial recommended default is CODE_128
        assertEquals(BarcodeFormatType.CODE_128, barcodeService.getDefaultBarcodeType())
        assertEquals(BarcodeFormatType.CODE_128, barcodeService.defaultBarcodeTypeFlow.value)

        for (fmt in BarcodeEngine.PRIMARY_SUPPORTED_FORMATS) {
            settingsRepo.updateDefaultBarcodeType(fmt)
            assertEquals(fmt, barcodeService.getDefaultBarcodeType())

            // Reopen database from disk to verify durable Room persistence
            barcodeService.closeForTest()
            db.close()
            openFreshDbAndServices()

            assertEquals(
                "Persisted default should remain ${fmt.name} after restart",
                fmt,
                barcodeService.getDefaultBarcodeType(),
            )
            assertEquals(fmt, settingsRepo.getDefaultBarcodeType())
        }
    }

    @Test
    fun `2 - new products and unspecified barcodes automatically adopt saved default barcode type`() = runBlocking {
        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.QR_CODE)

        val pid1 = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "INT-10", name = "منتج بدون صيغة مسبقة"),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "009911-QR",
                    barcodeType = "", // blank -> must resolve from saved default (QR_CODE)
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()

        val saved1 = db.productDao().getProductWithDetails(pid1)!!
        assertEquals(BarcodeFormatType.QR_CODE.name, saved1.primaryBarcode?.barcodeType)
        assertEquals("009911-QR", saved1.primaryBarcode?.barcodeValue)

        // Switching default to CODE_39 immediately affects subsequent unspecified barcodes
        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.CODE_39)
        productRepo.addBarcodeToProduct(
            productId = pid1,
            barcodeValue = "C39-100",
            format = null,
            label = "كرتون",
            makePrimary = false,
            unitType = "كرتون",
            conversionFactor = 12.0,
        ).getOrThrow()

        val savedAfter = db.productDao().getProductWithDetails(pid1)!!
        val addedBc = savedAfter.barcodes.first { it.barcodeValue == "C39-100" }
        assertEquals(BarcodeFormatType.CODE_39.name, addedBc.barcodeType)
    }

    @Test
    fun `3 - excel import uses saved default barcode type ignores No and honors explicit barcodeType`() = runBlocking {
        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.CODE_39)

        val csv = """
            No.,ID,اسم المنتج,الباركود,نوع الباركود
            1,PRD-100,شاي اخضر,TEA-001,
            2,PRD-101,عسل طبيعي,0012345678905,EAN_13
            3,PRD-102,قهوة عربية,عربي-123,QR_CODE
        """.trimIndent().toByteArray(Charsets.UTF_8)

        val parsed = excelImport.parseBytes(csv, "products.csv").getOrThrow()
        val sheet = parsed.sheets.first()
        val mapping = mutableMapOf(
            0 to ProductImportField.IGNORE,
            1 to ProductImportField.INTERNAL_CODE,
            2 to ProductImportField.NAME,
            3 to ProductImportField.PRIMARY_BARCODE,
            4 to ProductImportField.BARCODE_TYPE,
        )
        assertTrue(ProductImportField.BARCODE_TYPE in excelImport.suggestMappings(sheet.headers).values)

        val report = excelImport.executeImport(
            sheet = sheet,
            mappings = mapping,
            hasHeaderRow = true,
            policy = ImportDuplicatePolicy.SKIP,
        )
        assertEquals(3, report.insertedCount)

        val p1 = productRepo.findProductByExactBarcode("TEA-001")!!
        val p2 = productRepo.findProductByExactBarcode("0012345678905")!!
        val p3 = productRepo.findProductByExactBarcode("عربي-123")!!

        // Row 1 had blank barcode type -> picked saved default (CODE_39)
        assertEquals(BarcodeFormatType.CODE_39.name, p1.primaryBarcode?.barcodeType)
        // Row 2 kept explicit EAN_13 and preserved leading zeros
        assertEquals(BarcodeFormatType.EAN_13.name, p2.primaryBarcode?.barcodeType)
        assertEquals("0012345678905", p2.primaryBarcode?.barcodeValue)
        // Row 3 honored explicit QR_CODE
        assertEquals(BarcodeFormatType.QR_CODE.name, p3.primaryBarcode?.barcodeType)
        // Ignored No. and kept ID untouched
        assertEquals("PRD-100", p1.product.internalCode)
    }

    @Test
    fun `4 - all 7 supported formats encode and decode accurately without right edge clipping`() {
        val cases = listOf(
            BarcodeFormatType.CODE_128 to "00123456789-LONG-INTERNAL-ITEM",
            BarcodeFormatType.CODE_39 to "ITEM-0099",
            BarcodeFormatType.EAN_13 to "0012345678905",
            BarcodeFormatType.EAN_8 to "00123457",
            BarcodeFormatType.UPC_A to "012345678905",
            BarcodeFormatType.UPC_E to "01234565",
            BarcodeFormatType.QR_CODE to "00123-منتج-QR",
        )
        for ((format, value) in cases) {
            val validation = BarcodeEngine.validate(value, format)
            assertTrue("Validation failed for $format ($value): ${validation.errorMessage}", validation.isValid)

            val w = if (format.is2D) 440 else 800
            val h = if (format.is2D) 440 else 260
            val bmp = BarcodeEngine.generateHighResBitmap(
                value = value,
                format = format,
                widthPx = w,
                heightPx = h,
                showText = false,
                quietZoneModules = 10,
            )
            assertNotNull("Expected non-null crisp bitmap for $format", bmp)
            val decoded = BarcodeEngine.decodeBitmap(bmp!!, expectedFormat = format)
            assertNotNull("Decode failed for $format ($value)", decoded)
            assertEquals("Decoded text must preserve exact digits/zeros", value, decoded!!.text)
            assertEquals(format, decoded.format)

            // Verify left and right quiet zones remain pure white (no right-edge clipping)
            val midY = bmp.height / 2
            val rightCornerPixel = bmp.getPixel(bmp.width - 1, midY)
            val leftCornerPixel = bmp.getPixel(0, midY)
            assertEquals("Right edge must stay inside white quiet zone for $format", android.graphics.Color.WHITE, rightCornerPixel)
            assertEquals("Left edge must stay inside white quiet zone for $format", android.graphics.Color.WHITE, leftCornerPixel)
            bmp.recycle()
        }
    }

    @Test
    fun `5 - incompatible format conversion is rejected cleanly preserving original number and internalCode`() = runBlocking {
        val gtin = "0012345678905"
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "KEEP-ID-42", name = "زيت زيتون أصلي"),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = gtin,
                    barcodeType = BarcodeFormatType.EAN_13.name,
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()

        val details = db.productDao().getProductWithDetails(pid)!!
        val bcId = details.primaryBarcode!!.id

        // Trying to convert 13-digit EAN_13 into EAN_8 must fail safely
        val failRes = barcodeService.changeFormatForProductBarcode(
            productId = pid,
            barcodeId = bcId,
            targetFormat = BarcodeFormatType.EAN_8,
        )
        assertFalse(failRes.success)

        // Original number, format, and internalCode must be 100% preserved
        val after = db.productDao().getProductWithDetails(pid)!!
        assertEquals("KEEP-ID-42", after.product.internalCode)
        assertEquals(pid, after.product.id)
        assertEquals(gtin, after.primaryBarcode?.barcodeValue)
        assertEquals(BarcodeFormatType.EAN_13.name, after.primaryBarcode?.barcodeType)
    }

    @Test
    fun `6 - alternative internal barcode generator creates new internal barcode in saved default leaving GTIN untouched`() = runBlocking {
        val originalGtin = "6281006530126"
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "PROD-90", name = "حليب طازج"),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = originalGtin,
                    barcodeType = BarcodeFormatType.EAN_13.name,
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()

        // Set default barcode type to CODE_39
        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.CODE_39)

        val alt = barcodeService.generateAndAttachAlternativeInternalBarcode(
            productId = pid,
            unitType = "كرتون",
            conversionFactor = 6.0,
        ).getOrThrow()

        val updated = db.productDao().getProductWithDetails(pid)!!
        assertEquals(2, updated.barcodes.size)
        val primary = updated.primaryBarcode!!
        assertEquals(originalGtin, primary.barcodeValue)
        assertEquals(BarcodeFormatType.EAN_13.name, primary.barcodeType)
        assertTrue(primary.isPrimary)

        assertEquals(BarcodeFormatType.CODE_39.name, alt.barcodeType)
        assertFalse(alt.isPrimary)
        assertTrue(BarcodeEngine.isCompatible(alt.barcodeValue, BarcodeFormatType.CODE_39))
    }

    @Test
    fun `7 - scoped barcode format changes apply cleanly across products bulk inventory and reports`() = runBlocking {
        // Two products: p1 has alphanumeric (incompatible with EAN_13), p2 has valid EAN_13
        val p1 = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "A1", name = "صنف نصي"),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "BOX-001", barcodeType = BarcodeFormatType.CODE_128.name, isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()
        val p2 = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "A2", name = "صنف رقمي"),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "0012345678905", barcodeType = BarcodeFormatType.CODE_128.name, isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()

        // Bulk convert selected products to EAN_13 -> p2 updates, p1 is safely skipped with value untouched
        val bulkProdRes = barcodeService.changeFormatBulkProducts(listOf(p1, p2), BarcodeFormatType.EAN_13)
        assertTrue(bulkProdRes.success)
        assertEquals(1, bulkProdRes.updatedCount)
        assertEquals(1, bulkProdRes.skippedIncompatible.size)
        assertEquals(BarcodeFormatType.CODE_128.name, db.productDao().getProductWithDetails(p1)!!.primaryBarcode?.barcodeType)
        assertEquals(BarcodeFormatType.EAN_13.name, db.productDao().getProductWithDetails(p2)!!.primaryBarcode?.barcodeType)

        // Inventory scope isolation: changing inventory item only does NOT modify product catalog
        val sessionId = inventoryRepo.createSession("جرد نطاق معزول").getOrThrow()
        val prod2 = db.productDao().getProductWithDetails(p2)!!
        val invItemId = inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = prod2,
            scannedBarcode = "0012345678905",
            barcodeType = BarcodeFormatType.EAN_13.name,
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 4.0,
        ).getOrThrow()

        val invOnlyRes = barcodeService.changeFormatForInventoryItem(
            sessionId = sessionId,
            itemId = invItemId,
            targetFormat = BarcodeFormatType.QR_CODE,
            alsoUpdateProductCatalog = false,
        )
        assertTrue(invOnlyRes.success)
        assertEquals(BarcodeFormatType.QR_CODE.name, db.inventoryDao().getCountItemById(invItemId)?.barcodeType)
        // Product catalog stays EAN_13
        assertEquals(BarcodeFormatType.EAN_13.name, db.productDao().getProductWithDetails(p2)!!.primaryBarcode?.barcodeType)

        // Entire session bulk change to CODE_128
        val invSessRes = barcodeService.changeFormatForInventorySession(sessionId, BarcodeFormatType.CODE_128)
        assertTrue(invSessRes.success)
        assertEquals(BarcodeFormatType.CODE_128.name, db.inventoryDao().getCountItemById(invItemId)?.barcodeType)

        // Report item + report scope isolation
        val reportId = reportRepo.createEmptyReport(customTitle = "تقرير تجريبي")
        reportRepo.addProductToReport(reportId, prod2)
        val reportDetails = db.reportDao().getReportWithDetails(reportId)!!
        val repItem = reportDetails.items.first().item
        val repRes = barcodeService.changeFormatForReportItem(
            reportId = reportId,
            itemId = repItem.id,
            targetFormat = BarcodeFormatType.QR_CODE,
            alsoUpdateProductCatalog = false,
        )
        assertTrue(repRes.success)
        val refreshedReport = db.reportDao().getReportWithDetails(reportId)!!
        assertEquals(BarcodeFormatType.QR_CODE.name, refreshedReport.items.first().item.primaryBarcodeTypeSnapshot)
        // Product catalog still untouched (EAN_13)
        assertEquals(BarcodeFormatType.EAN_13.name, db.productDao().getProductWithDetails(p2)!!.primaryBarcode?.barcodeType)
    }

    @Test
    fun `8 - disk and LRU barcode cache isolates products and invalidates cleanly on format switch`() = runBlocking {
        val code = "0012345678905"
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "عصير برتقال"),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = code, barcodeType = BarcodeFormatType.EAN_13.name, isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()
        val bcId = db.productDao().getProductWithDetails(pid)!!.primaryBarcode!!.id

        val bmp1 = barcodeService.getOrGenerateBarcodeBitmap(pid, code, BarcodeFormatType.EAN_13)
        assertNotNull(bmp1)
        val v1 = barcodeService.currentImageVersion(pid, code)
        val filesV1 = mediaStorage.barcodeCacheDir.listFiles()?.toList().orEmpty()
        assertTrue("Expected PNG cache file created", filesV1.any { it.name.contains("_v${v1}_") })

        // Switch format -> bumps version, clears stale v1 disk files, regenerates QR bitmap
        val sw = barcodeService.changeFormatForProductBarcode(pid, bcId, BarcodeFormatType.QR_CODE)
        assertTrue(sw.success)
        val v2 = barcodeService.currentImageVersion(pid, code)
        assertTrue("Image version must increment", v2 > v1)

        val filesAfter = mediaStorage.barcodeCacheDir.listFiles()?.toList().orEmpty()
        assertFalse("Old v1 cache PNG must be removed", filesAfter.any { it.name.contains("_v${v1}_") })
        assertTrue("New v2 cache PNG must be present", filesAfter.any { it.name.contains("_v${v2}_") })

        val bmp2 = barcodeService.getOrGenerateBarcodeBitmap(pid, code, BarcodeFormatType.QR_CODE)
        assertNotNull(bmp2)
        val decoded2 = BarcodeEngine.decodeBitmap(bmp2!!, BarcodeFormatType.QR_CODE)
        assertEquals(code, decoded2?.text)
        assertEquals(BarcodeFormatType.QR_CODE, decoded2?.format)
    }

    @Test
    fun `9 - inventory lookup and rescan sync format keep defaultQuantity unchanged and never block counting`() = runBlocking {
        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.QR_CODE)
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "مياه معدنية", defaultQuantity = 25.0),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "WATER-500ML",
                    barcodeType = BarcodeFormatType.CODE_128.name,
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()
        val prod = db.productDao().getProductWithDetails(pid)!!
        val sessionId = inventoryRepo.createSession("جرد المياه").getOrThrow()

        // Unregistered barcode resolves saved default (QR_CODE)
        val unreg = inventoryRepo.lookupBarcodeForSession(sessionId, "UNREG-XYZ")
        assertTrue(unreg is InventoryScanLookupResult.UnregisteredBarcode)
        assertEquals(BarcodeFormatType.QR_CODE.name, (unreg as InventoryScanLookupResult.UnregisteredBarcode).barcodeType)

        // Registered barcode records cleanly in session without mutating Products.defaultQuantity
        val invId = inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = prod,
            scannedBarcode = "WATER-500ML",
            barcodeType = BarcodeFormatType.CODE_128.name,
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 9.0,
        ).getOrThrow()
        assertEquals(25.0, db.productDao().getProductWithDetails(pid)!!.product.defaultQuantity, 0.0001)

        // Resolving InventoryColumnDefaults with blank item format must fall back to saved default
        val resolvedDefault = InventoryColumnDefaults.resolveBarcodeFormat(
            item = db.inventoryDao().getCountItemById(invId)!!.copy(barcodeType = ""),
            product = null,
            config = InventorySheetConfig(barcodeFormatOverride = "AUTO"),
            defaultFormat = BarcodeFormatType.QR_CODE,
        )
        assertEquals(BarcodeFormatType.QR_CODE, resolvedDefault)

        // Even an unrenderable format returns null bitmap safely instead of throwing
        val badBmp = barcodeService.getOrGenerateBarcodeBitmap(pid, "INVALID-TEXT", BarcodeFormatType.EAN_13)
        assertNull(badBmp)
    }

    @Test
    fun `10 - legacy audit detects issues and chunked repair fixes safely without auto-converting without approval`() = runBlocking {
        // Insert a legacy product directly via DAO with (a) blank barcodeType & (b) invalid check-digit tagged EAN_13
        val pid = db.productDao().insertProduct(ProductEntity(internalCode = "LEG-1", name = "منتج قديم"))
        val blankId = db.productDao().insertBarcode(
            ProductBarcodeEntity(
                productId = pid,
                barcodeValue = "LEGACY-CODE-1",
                barcodeType = "", // unspecified legacy format
                isPrimary = true,
            ),
        )
        val mismatchId = db.productDao().insertBarcode(
            ProductBarcodeEntity(
                productId = pid,
                barcodeValue = "1234567890129", // wrong EAN-13 check digit
                barcodeType = BarcodeFormatType.EAN_13.name,
                isPrimary = false,
            ),
        )

        barcodeService.updateDefaultBarcodeFormat(BarcodeFormatType.CODE_128)
        val audit = barcodeService.auditLegacyBarcodes()
        assertEquals(1, audit.unspecifiedFormatCount)
        assertEquals(1, audit.incompatibleBarcodes.size)

        // Run repair WITHOUT approval to convert incompatible tags -> skips mismatchId, fixes blankId, prewarms PNG
        val safeResult = barcodeService.repairLegacyProductBarcodes(
            convertIncompatibleFormatWithUserApproval = false,
            chunkSize = 25,
        )
        assertEquals(1, safeResult.fixedUnspecifiedFormatsCount)
        assertEquals(0, safeResult.convertedIncompatibleWithApprovalCount)
        assertEquals(1, safeResult.skippedIncompatibleWithoutApprovalCount)
        assertEquals(BarcodeFormatType.CODE_128.name, db.productDao().getBarcodeById(blankId)?.barcodeType)
        assertEquals(BarcodeFormatType.EAN_13.name, db.productDao().getBarcodeById(mismatchId)?.barcodeType)
        assertEquals("1234567890129", db.productDao().getBarcodeById(mismatchId)?.barcodeValue)

        // Run repair WITH explicit user approval -> repairs tag to CODE_128 while keeping exact original digits
        val approvedResult = barcodeService.repairLegacyProductBarcodes(
            convertIncompatibleFormatWithUserApproval = true,
            chunkSize = 25,
        )
        assertEquals(1, approvedResult.convertedIncompatibleWithApprovalCount)
        assertEquals(0, approvedResult.skippedIncompatibleWithoutApprovalCount)
        val repairedMismatch = db.productDao().getBarcodeById(mismatchId)!!
        assertEquals(BarcodeFormatType.CODE_128.name, repairedMismatch.barcodeType)
        assertEquals("1234567890129", repairedMismatch.barcodeValue)
        val cachedCount = barcodeService.currentImageVersion(pid, "LEGACY-CODE-1").let { v ->
            mediaStorage.barcodeCacheDir.listFiles()?.count { it.name.contains("_v${v}_") } ?: 0
        }
        assertNotEquals(0, cachedCount)
    }
}
