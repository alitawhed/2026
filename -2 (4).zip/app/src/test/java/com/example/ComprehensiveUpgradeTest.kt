package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.ImageEditParameters
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ExtractedExcelImage
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ParsedSheetData
import com.example.domain.excel.ProductImportField
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnType
import com.example.domain.pdf.PdfEditorEngine
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfOverlayItem
import com.example.domain.pdf.PdfOverlayType
import com.example.domain.pdf.PdfPageRenderer
import com.example.domain.pdf.PdfRenderOutput
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ComprehensiveUpgradeTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var excelImport: ExcelImportEngine
    private lateinit var backupEngine: BackupRestoreEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        excelImport = ExcelImportEngine(context, db, mediaStorage)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun makeBitmap(width: Int = 80, height: Int = 60, color: Int = Color.BLUE): Bitmap {
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            eraseColor(color)
        }
    }

    private fun makeImageBytes(color: Int, format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG): ByteArray {
        val bmp = makeBitmap(64, 48, color)
        return ByteArrayOutputStream().use {
            bmp.compress(format, 92, it)
            it.toByteArray()
        }.also { bmp.recycle() }
    }

    @Test
    fun `database schema v2 has all 14 tables and MIGRATION_1_2 preserves existing v1 rows`() = runBlocking {
        // Verify 14 user tables exist in Room v2 schema
        val expectedTables = listOf(
            "Products", "ProductBarcodes", "ProductImages", "Categories",
            "ReportTemplates", "Reports", "ReportItems", "ReportItemBarcodes",
            "ReportItemImages", "ReportColumns", "AppSettings", "BackupHistory",
            "PDFDocuments", "PDFPages",
        )
        val sqlite = db.openHelper.readableDatabase
        val present = mutableSetOf<String>()
        sqlite.query("SELECT name FROM sqlite_master WHERE type='table'").use { c ->
            while (c.moveToNext()) present.add(c.getString(0))
        }
        expectedTables.forEach { t ->
            assertTrue("Expected Room v2 table '$t' to exist in $present", present.contains(t))
        }

        // Verify MIGRATION_1_2 preserves v1 ProductImages & Reports rows cleanly via SupportSQLiteOpenHelper
        val legacyFile = File(context.cacheDir, "legacy_v1_${System.nanoTime()}.db")
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(legacyFile.absolutePath)
                .callback(object : SupportSQLiteOpenHelper.Callback(1) {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL("CREATE TABLE ProductImages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productId INTEGER NOT NULL, filePath TEXT NOT NULL, isPrimary INTEGER NOT NULL, sortOrder INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                        db.execSQL("CREATE TABLE ReportItems (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, reportId INTEGER NOT NULL)")
                        db.execSQL("CREATE TABLE Reports (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, reportNumber TEXT NOT NULL, title TEXT NOT NULL, reportDate INTEGER NOT NULL, clientName TEXT NOT NULL, clientPhone TEXT NOT NULL, clientAddress TEXT NOT NULL, currency TEXT NOT NULL, notes TEXT NOT NULL, termsAndConditions TEXT NOT NULL, responsiblePerson TEXT NOT NULL, companyName TEXT NOT NULL, companyAddress TEXT NOT NULL, companyPhone TEXT NOT NULL, companyLogoPath TEXT NOT NULL, headerTitle TEXT NOT NULL, templateId INTEGER, paperSize TEXT NOT NULL, customWidthMm REAL NOT NULL, customHeightMm REAL NOT NULL, orientation TEXT NOT NULL, marginTopMm REAL NOT NULL, marginBottomMm REAL NOT NULL, marginStartMm REAL NOT NULL, marginEndMm REAL NOT NULL, columnDistributionMode TEXT NOT NULL, splitHorizontalGroups INTEGER NOT NULL, duplicateBehavior TEXT NOT NULL, headerFooterConfigJson TEXT NOT NULL, barcodeStyleConfigJson TEXT NOT NULL, lastPdfPath TEXT NOT NULL, isArchived INTEGER NOT NULL, isSaved INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                    }
                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                })
                .build(),
        )
        val raw = helper.writableDatabase
        raw.execSQL("INSERT INTO ProductImages (productId, filePath, isPrimary, sortOrder, createdAt) VALUES (1, '/tmp/p1.png', 1, 0, 100)")
        raw.execSQL("INSERT INTO Reports (reportNumber, title, reportDate, clientName, clientPhone, clientAddress, currency, notes, termsAndConditions, responsiblePerson, companyName, companyAddress, companyPhone, companyLogoPath, headerTitle, templateId, paperSize, customWidthMm, customHeightMm, orientation, marginTopMm, marginBottomMm, marginStartMm, marginEndMm, columnDistributionMode, splitHorizontalGroups, duplicateBehavior, headerFooterConfigJson, barcodeStyleConfigJson, lastPdfPath, isArchived, isSaved, createdAt, updatedAt) VALUES ('RPT-1', 'تقرير قديم', 100, '', '', '', 'ر.س', '', '', '', '', '', '', '', '', NULL, 'A4', 210, 297, 'PORTRAIT', 10, 10, 10, 10, 'AUTO_FIT', 0, 'INCREMENT_QTY', '{}', '{}', '', 0, 1, 100, 100)")

        AppDatabase.MIGRATION_1_2.migrate(raw)

        val migratedTables = mutableSetOf<String>()
        raw.query("SELECT name FROM sqlite_master WHERE type='table'").use { c ->
            while (c.moveToNext()) migratedTables.add(c.getString(0))
        }
        assertTrue(migratedTables.contains("ReportItemImages"))
        assertTrue(migratedTables.contains("PDFDocuments"))
        assertTrue(migratedTables.contains("PDFPages"))
        raw.query("SELECT filePath, originalFilePath FROM ProductImages").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("/tmp/p1.png", c.getString(0))
        }
        raw.query("SELECT title, versionNumber FROM Reports").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("تقرير قديم", c.getString(0))
            assertEquals(1, c.getInt(1))
        }
        helper.close()
        legacyFile.delete()
        Unit
    }

    @Test
    @Config(sdk = [34])
    @GraphicsMode(GraphicsMode.Mode.NATIVE)
    fun `MediaStorageManager non-destructive edits keep original untouched and restore original pixels`() {
        val srcBmp = makeBitmap(100, 80, Color.RED)
        val triplet = mediaStorage.saveBitmapTriplet(srcBmp)
        srcBmp.recycle()

        assertTrue(File(triplet.activePath).exists())
        assertTrue(File(triplet.originalPath).exists())
        assertTrue(File(triplet.thumbnailPath).exists())
        val originalHash = File(triplet.originalPath).readBytes().contentHashCode()

        // Apply rotation + crop + invert/brightness edit non-destructively
        val edited = mediaStorage.applyImageEdits(
            sourceImagePath = triplet.originalPath,
            existingOriginalPath = triplet.originalPath,
            activeFilePath = triplet.activePath,
            params = ImageEditParameters(
                rotateDegrees = 90,
                cropLeft = 0.1f,
                cropTop = 0.1f,
                cropRight = 0.9f,
                cropBottom = 0.9f,
                brightness = -60f,
            ),
            saveAsNewCopy = false,
        )
        assertNotNull(edited)
        assertEquals(triplet.originalPath, edited!!.originalPath)
        assertEquals("Original file bytes must NEVER change during edits", originalHash, File(triplet.originalPath).readBytes().contentHashCode())

        val editedBmp = BitmapFactory.decodeFile(edited.activePath)
        assertNotNull(editedBmp)
        assertNotEquals(Color.RED, editedBmp.getPixel(editedBmp.width / 2, editedBmp.height / 2))
        editedBmp.recycle()

        // Restore original image
        val restored = mediaStorage.restoreFromOriginal(edited.originalPath, edited.activePath)
        assertNotNull(restored)
        val restoredBmp = BitmapFactory.decodeFile(restored!!.activePath)
        assertEquals(100, restoredBmp.width)
        assertEquals(80, restoredBmp.height)
        assertEquals(Color.RED, restoredBmp.getPixel(50, 40))
        restoredBmp.recycle()
    }

    @Test
    fun `excel multi-image extraction sorts per row by column and supports pre-import review reassignment`() = runBlocking {
        val redImg = makeImageBytes(Color.RED)
        val greenImg = makeImageBytes(Color.GREEN)
        val blueImg = makeImageBytes(Color.BLUE)

        val sheet = ParsedSheetData(
            sheetName = "Products",
            headers = listOf("اسم المنتج", "الباركود", "السعر"),
            rows = listOf(
                listOf("اسم المنتج", "الباركود", "السعر"),
                listOf("صنف متعدد الصور", "0011223344", "55.0"),
                listOf("صنف يحتاج صورة", "0055667788", "20.0"),
            ),
            extractedImages = listOf(
                ExtractedExcelImage(id = "img_col4", fileName = "img_col4.png", bytes = greenImg, anchoredRowZeroBased = 1, anchoredColZeroBased = 4),
                ExtractedExcelImage(id = "img_col2", fileName = "img_col2.png", bytes = redImg, anchoredRowZeroBased = 1, anchoredColZeroBased = 2),
                ExtractedExcelImage(id = "unlinked", fileName = "unlinked.png", bytes = blueImg, anchoredRowZeroBased = 99, anchoredColZeroBased = 1),
            ),
        )
        val mapping = mapOf(
            0 to ProductImportField.NAME,
            1 to ProductImportField.PRIMARY_BARCODE,
            2 to ProductImportField.BASE_PRICE,
        )

        val draft = excelImport.buildPreImportReviewDraft(sheet, mapping, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals(2, draft.rows.size)
        // Row 1 should have 2 images sorted ascending by anchoredColZeroBased (col 2 first, col 4 second)
        assertEquals(2, draft.rows[0].images.size)
        assertEquals(2, draft.rows[0].images[0].anchoredColZeroBased)
        assertEquals(4, draft.rows[0].images[1].anchoredColZeroBased)
        assertEquals(1, draft.unlinkedImages.size)

        // Simulate user moving unlinked image into row 2 during pre-import visual review
        val movedImg = draft.unlinkedImages.first()
        val adjusted = draft.copy(
            rows = listOf(
                draft.rows[0],
                draft.rows[1].copy(images = listOf(movedImg), primaryImageId = movedImg.id),
            ),
            unlinkedImages = emptyList(),
        )
        val report = excelImport.commitReviewedImport(adjusted)
        assertEquals(2, report.insertedCount)
        assertEquals(3, report.autoLinkedImagesCount)

        val multiProd = productRepo.findProductByExactBarcode("0011223344")!!
        assertEquals(2, multiProd.images.size)
        assertTrue(multiProd.images.all { it.originalFilePath.isNotBlank() && it.thumbnailPath.isNotBlank() })

        val secondProd = productRepo.findProductByExactBarcode("0055667788")!!
        assertEquals(1, secondProd.images.size)
    }

    @Test
    @Config(sdk = [34])
    @GraphicsMode(GraphicsMode.Mode.NATIVE)
    fun `report MULTI_IMAGE column snapshots all product images renders PDF and versions reports cleanly`() = runBlocking {
        val img1 = mediaStorage.saveBitmapTriplet(makeBitmap(60, 60, Color.CYAN))
        val img2 = mediaStorage.saveBitmapTriplet(makeBitmap(60, 60, Color.MAGENTA))
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج صور متعددة", basePrice = 75.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "MULTI-9001", isPrimary = true)),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = img1.activePath, originalFilePath = img1.originalPath, thumbnailPath = img1.thumbnailPath, isPrimary = true, sortOrder = 0),
                ProductImageEntity(productId = 0L, filePath = img2.activePath, originalFilePath = img2.originalPath, thumbnailPath = img2.thumbnailPath, isPrimary = false, sortOrder = 1),
            ),
        ).getOrThrow()

        val prod = db.productDao().getProductWithDetails(pid)!!
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير صور متعددة")
        val rptBefore = reportRepo.getReportOnce(rid)!!
        val cols = rptBefore.sortedColumns.map {
            ColumnConfigModel(
                id = it.id,
                columnKey = it.columnKey,
                title = it.title,
                columnType = ColumnType.fromString(it.columnType),
                visible = true,
                sortOrder = it.sortOrder,
            )
        } + ColumnConfigModel(
            columnKey = "multi_imgs",
            title = "معرض الصور",
            columnType = ColumnType.MULTI_IMAGE,
            visible = true,
            sortOrder = rptBefore.columns.size,
        )
        reportRepo.replaceReportColumns(rid, cols)
        reportRepo.addProductToReport(rid, prod)

        val details = reportRepo.getReportOnce(rid)!!
        assertEquals(1, details.items.size)
        assertEquals(2, details.items.first().images.size)
        assertTrue(details.items.first().images.all { File(it.filePath).exists() })

        // Render PDF with MULTI_IMAGE column
        val renderedPages = mutableListOf<Bitmap>()
        val factory = PdfSessionFactory {
            object : PdfSession {
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                    val bmp = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                    renderedPages.add(bmp)
                    return Canvas(bmp)
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: OutputStream) {
                    outputStream.write("%PDF-1.4\n".toByteArray())
                }
                override fun close() = Unit
            }
        }
        val pdfRes = PdfGeneratorEngine(context, mediaStorage, factory)
            .generateReportPdf(details, AppSettingsEntity(), "multi_img_test.pdf")
        assertTrue(pdfRes.file.exists())
        assertTrue(renderedPages.isNotEmpty())

        // Create archived report & new version V2
        reportRepo.archiveReport(rid, true)
        val v2Id = reportRepo.saveAsNewReportVersion(rid)
        val v2 = reportRepo.getReportOnce(v2Id)!!
        assertEquals(2, v2.report.versionNumber)
        assertEquals(rid, v2.report.parentReportId)
        assertTrue(v2.report.isArchived)
        assertEquals(2, v2.items.first().images.size)
    }

    @Test
    @Config(sdk = [34])
    @GraphicsMode(GraphicsMode.Mode.NATIVE)
    fun `PdfEditorEngine handles pages merge split crop overlays JPEG extraction and non-destructive export`() = runBlocking {
        val fakeRenderer = object : PdfPageRenderer {
            override fun getPageCount(file: File): Int = if (file.name.contains("two")) 2 else 1
            override fun renderPage(file: File, pageIndex: Int, scaleFactor: Float): PdfRenderOutput {
                val bmp = makeBitmap(120, 160, Color.LTGRAY)
                return PdfRenderOutput(getPageCount(file), 595f, 842f, bmp)
            }
        }
        val exportedPageBitmaps = mutableListOf<Bitmap>()
        val fakeSessionFactory = PdfSessionFactory {
            object : PdfSession {
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                    val bmp = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                    exportedPageBitmaps.add(bmp)
                    return Canvas(bmp)
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: OutputStream) {
                    outputStream.write("%PDF-1.4\n(Hello Report) Tj\n".toByteArray())
                }
                override fun close() = Unit
            }
        }

        val engine = PdfEditorEngine(context, db, mediaStorage, fakeSessionFactory, fakeRenderer)

        // Create synthetic PDF containing an embedded JPEG XObject
        val jpegBytes = makeImageBytes(Color.YELLOW, Bitmap.CompressFormat.JPEG)
        val sourcePdf = File(context.cacheDir, "two_pages_src.pdf")
        val header = "%PDF-1.4\n1 0 obj\n(SampleText) Tj\nstream\n".toByteArray(Charsets.ISO_8859_1)
        val footer = "\nendstream\n%%EOF".toByteArray(Charsets.ISO_8859_1)
        sourcePdf.writeBytes(header + jpegBytes + footer)
        val origBytesBefore = sourcePdf.readBytes()

        val opened = engine.openInternalPdfFile(sourcePdf, "مستند اختباري").getOrThrow()
        assertEquals(2, opened.pages.size)

        var doc = engine.toEditableDocument(opened)
        doc = engine.rotatePage(doc, 0, 90)
        assertEquals(90, doc.pages[0].rotationDegrees)

        doc = engine.cropPageMargins(doc, 0, 0.1f, 0.1f, 0.9f, 0.9f)
        assertEquals(0.1f, doc.pages[0].cropLeft, 0.001f)

        doc = engine.insertBlankPage(doc, afterIndex = 0)
        assertEquals(3, doc.pages.size)
        assertTrue(doc.pages[1].isBlankPage)

        // Merge second PDF
        val secondPdf = File(context.cacheDir, "extra_one.pdf").apply { writeText("%PDF-1.4\n") }
        doc = engine.appendPdfFile(doc, secondPdf).getOrThrow()
        assertEquals(4, doc.pages.size)

        // Reorder and delete page
        doc = engine.movePage(doc, 3, 0)
        assertEquals(extraPdfName(secondPdf), File(doc.pages[0].sourcePdfPath).name)
        doc = engine.deletePage(doc, 0)
        assertEquals(3, doc.pages.size)

        // Add overlays (text, cover box, rectangle, date stamp, page number)
        doc = doc.copy(
            overlays = listOf(
                PdfOverlayItem(pageIndex = 0, type = PdfOverlayType.COVER_BOX, fillColorHex = "#FFFFFF"),
                PdfOverlayItem(pageIndex = 0, type = PdfOverlayType.TEXT, text = "تعديل احترافي", colorHex = "#0F172A"),
                PdfOverlayItem(pageIndex = 0, type = PdfOverlayType.RECTANGLE),
                PdfOverlayItem(pageIndex = 0, type = PdfOverlayType.DATE_STAMP),
                PdfOverlayItem(pageIndex = 0, type = PdfOverlayType.PAGE_NUMBER),
            ),
        )

        val outFile = engine.exportEditedPdf(doc, outputFileName = "final_edited_copy").getOrThrow()
        assertTrue(outFile.exists())
        assertTrue(outFile.parentFile?.name == "edited_pdfs")
        assertTrue(origBytesBefore.contentEquals(sourcePdf.readBytes())) // Original untouched!
        assertEquals(3, exportedPageBitmaps.size)

        // Split pages
        val splitFiles = engine.splitPdfIntoSeparateFiles(doc, "split_unit").getOrThrow()
        assertEquals(3, splitFiles.size)
        assertTrue(splitFiles.all { it.exists() })

        // Extract embedded JPEG XObject from source PDF + plain text literal
        val extractedImgs = engine.extractEmbeddedImagesFromPdf(sourcePdf)
        assertEquals(1, extractedImgs.size)
        assertTrue(extractedImgs.first().exists())
        assertTrue(engine.extractPlainPdfTextLiterals(sourcePdf).contains("SampleText"))

        sourcePdf.delete()
        secondPdf.delete()
        Unit
    }

    private fun extraPdfName(f: File): String = f.name

    @Test
    fun `dashboard metrics and storage calculation reflect live products images reports and backups`() = runBlocking {
        val t1 = mediaStorage.saveBitmapTriplet(makeBitmap(50, 50, Color.GREEN))
        val t2 = mediaStorage.saveBitmapTriplet(makeBitmap(50, 50, Color.BLUE))
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج قياس لوحة التحكم", basePrice = 99.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "KPI-100", isPrimary = true)),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = t1.activePath, originalFilePath = t1.originalPath, thumbnailPath = t1.thumbnailPath, isPrimary = true),
                ProductImageEntity(productId = 0L, filePath = t2.activePath, originalFilePath = t2.originalPath, thumbnailPath = t2.thumbnailPath, isPrimary = false, sortOrder = 1),
            ),
        ).getOrThrow()

        val rid = reportRepo.createEmptyReport(customTitle = "تقرير اليوم")
        reportRepo.addProductToReport(rid, db.productDao().getProductWithDetails(pid)!!)
        reportRepo.archiveReport(rid, true)

        val prodStats = productRepo.observeDashboardProductMetrics().first()
        assertEquals(1, prodStats.totalProducts)
        assertEquals(2, prodStats.totalImages)
        assertEquals(1, prodStats.multiImageProducts)
        assertEquals(0, prodStats.productsWithoutImages)

        assertEquals(1, reportRepo.archivedReportCount.first())
        assertEquals(1, reportRepo.observeTodaysReportCount().first())
        assertTrue(mediaStorage.calculateUsedStorageBytes() > 0L)

        // Also check v2 backup includes ReportItemImages cleanly
        val zip = backupEngine.createBackupZip("v2_stats_check").getOrThrow()
        val inspected = backupEngine.inspectBackupBytes(zip.readBytes())
        assertTrue(inspected.isValid)
        // 2 active + 2 original + 2 thumbnail + 2 report snapshot = 8 packaged image files
        assertEquals(8, inspected.manifest?.imageCount)
        assertEquals(1, inspected.manifest?.reportCount)
    }
}
