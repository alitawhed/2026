package com.example

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.DuplicateCountAction
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupDatabasePayload
import com.example.domain.backup.BackupManifest
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.diagnostics.DiagnosticExportEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.DiagnosticSummaryStats
import com.example.domain.diagnostics.DiagnosticsFileStore
import com.example.domain.diagnostics.ErrorEventRecord
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.MemoryPressureAdvisor
import com.example.domain.diagnostics.OperationLogRecord
import com.example.domain.diagnostics.OperationLogger
import com.example.domain.diagnostics.OperationOutcome
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.barcode.CameraAnalysisExecutorManager
import com.example.domain.pdf.PdfCancelledException
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.google.mlkit.vision.barcode.BarcodeScanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.lang.reflect.Proxy
import java.util.concurrent.CountDownLatch
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DiagnosticsProductionFixesTest {

    private lateinit var baseContext: Context
    private lateinit var rootSandbox: File

    private val testJson = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    @Before
    fun setup() {
        baseContext = ApplicationProvider.getApplicationContext()
        rootSandbox = File(baseContext.cacheDir, "diag_prod_fix_${System.nanoTime()}").apply { mkdirs() }
    }

    @After
    fun tearDown() {
        rootSandbox.deleteRecursively()
    }

    private fun isolatedDeviceContext(tag: String): Context {
        val root = File(rootSandbox, tag).apply { mkdirs() }
        val files = File(root, "files").apply { mkdirs() }
        val cache = File(root, "cache").apply { mkdirs() }
        return object : ContextWrapper(baseContext) {
            override fun getFilesDir(): File = files
            override fun getCacheDir(): File = cache
            override fun getApplicationContext(): Context = this
        }
    }

    private fun makePngBytes(color: Int = Color.BLUE, sizePx: Int = 64): ByteArray {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    private fun fakePdfSessionFactory(): PdfSessionFactory = PdfSessionFactory {
        object : PdfSession {
            private var activeBmp: Bitmap? = null
            override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                activeBmp = Bitmap.createBitmap(widthPt.coerceIn(10, 400), heightPt.coerceIn(10, 400), Bitmap.Config.ARGB_8888)
                return Canvas(activeBmp!!)
            }
            override fun endPage() {
                activeBmp?.recycle()
                activeBmp = null
            }
            override fun writeTo(outputStream: OutputStream) {
                outputStream.write("%PDF-1.4\n%%EOF\n".toByteArray())
            }
            override fun close() {
                activeBmp?.recycle()
                activeBmp = null
            }
        }
    }

    private fun fakeBarcodeScanner(closeCounter: AtomicInteger): BarcodeScanner {
        return Proxy.newProxyInstance(
            BarcodeScanner::class.java.classLoader,
            arrayOf(BarcodeScanner::class.java),
        ) { _, method, _ ->
            if (method.name == "close") {
                closeCounter.incrementAndGet()
            }
            null
        } as BarcodeScanner
    }

    // Test 1: Open, close, reopen Inventory & scanner repeatedly without RejectedExecutionException
    @Test
    fun `test 1 - repeated open close reopen inventory and camera executor produces zero RejectedExecutionException`() = runBlocking {
        val devCtx = isolatedDeviceContext("t1_reopen")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java).allowMainThreadQueries().build()
        AppDatabase.ensureSeeded(db)
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val invRepo = InventoryRepository(db, monitor)
        val execMgr = CameraAnalysisExecutorManager(monitor)

        val rejectedCount = AtomicInteger(0)
        val callbackInvokedAfterDispose = AtomicInteger(0)
        val closeCalls = AtomicInteger(0)

        repeat(8) { cycle ->
            val session = invRepo.createSession("جرد دوري رقم $cycle").getOrThrow()
            val scannerSession = execMgr.newSession(fakeBarcodeScanner(closeCalls))

            val startedWork = scannerSession.beginAsyncWork()
            assertTrue(startedWork)

            val doneLatch = CountDownLatch(1)
            val exec = execMgr.executor
            try {
                exec.execute {
                    try {
                        // Simulate user closing scanner screen right while GMS callback runs
                        if (!scannerSession.isDisposed) {
                            callbackInvokedAfterDispose.incrementAndGet()
                        }
                    } finally {
                        scannerSession.endAsyncWork()
                        doneLatch.countDown()
                    }
                }
            } catch (_: RejectedExecutionException) {
                rejectedCount.incrementAndGet()
            }

            // Rapidly leave screen and dispose session while task might still be finishing
            scannerSession.disposeAndCloseWhenIdle()
            assertTrue(doneLatch.await(3, TimeUnit.SECONDS))
            assertTrue(scannerSession.isDisposed)
            assertTrue(scannerSession.isScannerClosed)

            // Dispatching another task into the long-lived executor on reopen MUST still succeed (never terminated)
            val reopenLatch = CountDownLatch(1)
            val secondSession = execMgr.newSession(fakeBarcodeScanner(closeCalls))
            try {
                execMgr.executor.execute {
                    reopenLatch.countDown()
                }
            } catch (_: RejectedExecutionException) {
                rejectedCount.incrementAndGet()
            }
            assertTrue("Reopened executor must stay alive", reopenLatch.await(3, TimeUnit.SECONDS))
            secondSession.disposeAndCloseWhenIdle()
            invRepo.closeSession(session).getOrThrow()
        }

        assertEquals(0, rejectedCount.get())
        assertFalse(execMgr.executor.isShutdown)
        assertFalse(execMgr.executor.isTerminated)
        assertFalse(
            monitor.errors.value.any { it.errorType.contains("RejectedExecution", ignoreCase = true) },
        )
        db.close()
    }

    // Test 2: Repeated Inventory operations all logged cleanly with OperationLogger
    @Test
    fun `test 2 - repeated inventory operations are recorded in OperationLogger and reflected in summary`() = runBlocking {
        val devCtx = isolatedDeviceContext("t2_inv_ops")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java).allowMainThreadQueries().build()
        AppDatabase.ensureSeeded(db)
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val mediaStorage = MediaStorageManager(devCtx, monitor)
        val prodRepo = ProductRepository(db, mediaStorage, monitor)
        val invRepo = InventoryRepository(db, monitor)

        val pid = prodRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "INV-10", name = "صنف جرد", basePrice = 20.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "6280001112223", isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()
        val prod = db.productDao().getProductWithDetails(pid)!!
        val sid = invRepo.createSession("جلسة جرد تفصيلية").getOrThrow()

        val lookup = invRepo.lookupBarcodeForSession(sid, "6280001112223", "EAN_13")
        assertNotNull(lookup)

        val itemId = invRepo.recordCountedItem(
            sessionId = sid,
            product = prod,
            scannedBarcode = "6280001112223",
            barcodeType = "EAN_13",
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 10.0,
            duplicateAction = DuplicateCountAction.REPLACE_EXISTING,
        ).getOrThrow()

        invRepo.updateCountItemQuantity(itemId, 15.0, "معدل").getOrThrow()
        invRepo.closeSession(sid).getOrThrow()

        val invOps = opLogger.operations.value.filter { it.screenName == ScreenNames.INVENTORY }
        assertTrue("Expected at least 5 inventory screen ops, got ${invOps.size}", invOps.size >= 5)
        assertTrue("Expected at least 4 INVENTORY module ops", invOps.count { it.moduleName == DiagnosticModules.INVENTORY } >= 4)
        assertTrue("Expected barcode lookup op under BARCODE_CAMERA", invOps.any { it.moduleName == DiagnosticModules.BARCODE_CAMERA })
        assertTrue(invOps.all { it.outcome == OperationOutcome.SUCCESS })
        assertTrue(monitor.stats.value.totalOperationsCount >= 5)
        db.close()
    }

    // Test 3: Camera / barcode analyzer lifecycle & deferred scanner close
    @Test
    fun `test 3 - barcode scanner defers close until in-flight frame ends and survives rapid closures`() {
        val devCtx = isolatedDeviceContext("t3_scanner")
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore)
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger)
        val execMgr = CameraAnalysisExecutorManager(monitor)
        val closeCalls = AtomicInteger(0)

        val session = execMgr.newSession(fakeBarcodeScanner(closeCalls))
        assertTrue(session.beginAsyncWork())
        assertEquals(1, session.inFlightCount)

        // Screen disposes while frame is still processing -> scanner MUST NOT close mid-frame
        session.disposeAndCloseWhenIdle()
        assertTrue(session.isDisposed)
        assertFalse("Scanner must defer close until frame finishes", session.isScannerClosed)
        assertEquals(0, closeCalls.get())

        // Once async work finishes -> scanner closes cleanly once
        session.endAsyncWork()
        assertTrue(session.isScannerClosed)
        assertEquals(1, closeCalls.get())
        assertFalse("Subsequent beginAsyncWork must reject cleanly without throwing", session.beginAsyncWork())
    }

    // Test 4: Leaving screen / cancelling operation ends as CANCELLED cleanly with zero crash
    @Test
    fun `test 4 - cancelling running PDF operation and coroutine marks CANCELLED and logs zero errors`() = runBlocking {
        val devCtx = isolatedDeviceContext("t4_cancel")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java).allowMainThreadQueries().build()
        AppDatabase.ensureSeeded(db)
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val media = MediaStorageManager(devCtx, monitor)
        val rptRepo = ReportRepository(db, media, monitor)
        val pdfEngine = PdfGeneratorEngine(devCtx, media, fakePdfSessionFactory(), monitor)

        val rid = rptRepo.createEmptyReport(customTitle = "تقرير للإلغاء")
        val rpt = db.reportDao().getReportWithDetails(rid)!!
        val cancelFlag = AtomicBoolean(true)

        val thrown = runCatching {
            pdfEngine.generateReportPdf(
                reportDetails = rpt,
                settings = AppSettingsEntity(),
                isCancelled = { cancelFlag.get() },
            )
        }.exceptionOrNull()

        assertTrue(thrown is PdfCancelledException)
        val cancelledOp = opLogger.operations.value.firstOrNull { it.moduleName == DiagnosticModules.PDF }
        assertNotNull(cancelledOp)
        assertEquals(OperationOutcome.CANCELLED, cancelledOp!!.outcome)
        assertEquals("PDF cancel must NOT record a crash/error", 0, monitor.errors.value.size)

        // Also test coroutine Job cancellation on an OperationTrace
        val gate = CompletableDeferred<Unit>()
        val trace = opLogger.startOperation(ScreenNames.EXCEL_IMPORT, DiagnosticModules.EXCEL, "عملية ستُلغى")
        val job: Job = launch(Dispatchers.IO) {
            try {
                gate.complete(Unit)
                delay(5_000)
            } catch (c: CancellationException) {
                trace.cancel("إلغاء الكوروتين عند الخروج")
                throw c
            }
        }
        gate.await()
        job.cancel()
        job.join()

        val cancelledExcelOp = opLogger.operations.value.firstOrNull { it.operationId == trace.operationId }
        assertNotNull(cancelledExcelOp)
        assertEquals(OperationOutcome.CANCELLED, cancelledExcelOp!!.outcome)
        assertEquals(0, monitor.errors.value.size)

        db.close()
    }

    // Test 5: Late async callback after screen disposal ignores UI mutation & never throws
    @Test
    fun `test 5 - late async callback after screen disposal does not mutate state or crash`() {
        val devCtx = isolatedDeviceContext("t5_late_callback")
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore)
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger)
        val execMgr = CameraAnalysisExecutorManager(monitor)

        val detachedView = View(devCtx)
        val uiMutated = AtomicBoolean(false)
        val session = execMgr.newSession(fakeBarcodeScanner(AtomicInteger(0)))

        // Dispose first (user left screen), then late callback arrives
        session.disposeAndCloseWhenIdle()
        execMgr.postUiIfActive(session, detachedView, ScreenNames.BARCODE_SCANNER) {
            uiMutated.set(true)
        }
        // Also ensure dispatchSafe refuses cleanly
        val dispatched = execMgr.dispatchSafe(session = session) {
            uiMutated.set(true)
        }

        assertFalse(dispatched)
        assertFalse("Late callback after dispose must NOT mutate UI state", uiMutated.get())
        assertEquals(0, monitor.errors.value.count { it.errorType.contains("RejectedExecution") })
    }

    // Test 6: LowMemory handling separates UI_HIDDEN (20) from true memory pressure and trims caches safely
    @Test
    fun `test 6 - UI_HIDDEN 20 produces zero false LowMemoryWarning while critical pressure logs telemetry and trims temp caches safely`() = runBlocking {
        val devCtx = isolatedDeviceContext("t6_memory")
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore)
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger)

        // Create both disposable cache files and critical user data files
        val urlPreviewFile = File(File(devCtx.cacheDir, "url_previews").apply { mkdirs() }, "preview_1.tmp").apply {
            writeBytes(makePngBytes())
        }
        val userImageFile = File(File(devCtx.filesDir, "product_images").apply { mkdirs() }, "important_prod.png").apply {
            writeBytes(makePngBytes())
        }

        // 6A) TRIM_MEMORY_UI_HIDDEN (20) MUST NOT log LowMemoryWarning
        val uiHiddenEval = MemoryPressureAdvisor.evaluate(devCtx, ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)
        assertFalse("UI_HIDDEN (20) must NEVER log false LowMemoryWarning", uiHiddenEval.shouldLogWarning)
        assertTrue(uiHiddenEval.shouldTrimCaches)

        val app = baseContext as ReportManagerApplication
        val beforeCount = app.container.globalErrorMonitor.errors.value.count { it.errorType == "LowMemoryWarning" }
        app.handleTrimMemoryLevel(ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)
        val afterUiHiddenCount = app.container.globalErrorMonitor.errors.value.count { it.errorType == "LowMemoryWarning" }
        assertEquals("ReportManagerApplication must not log LowMemoryWarning on UI_HIDDEN (20)", beforeCount, afterUiHiddenCount)

        // 6B) Genuine low-memory signal (TRIM_MEMORY_RUNNING_CRITICAL = 15 / TRIM_MEMORY_COMPLETE = 80)
        val criticalEval = MemoryPressureAdvisor.evaluate(devCtx, ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL)
        assertTrue(criticalEval.shouldLogWarning)
        assertTrue(criticalEval.totalRamMb >= 0L)
        assertTrue(criticalEval.heapMaxMb >= 1L)
        val msg = criticalEval.toDiagnosticMessage()
        assertTrue(msg.contains("RAM متاح="))
        assertTrue(msg.contains("Heap="))

        val trimmedCount = MemoryPressureAdvisor.releaseDisposableTempCaches(devCtx, aggressive = true)
        assertTrue(trimmedCount >= 1)
        assertFalse("Disposable url_previews must be cleared", urlPreviewFile.exists())
        assertTrue("User filesDir product images MUST NEVER be touched", userImageFile.exists() && userImageFile.length() > 0L)
    }

    // Test 7: Diagnostic ZIP export contains valid non-empty JSONs, non-zero operations, finished SUCCESS state, and linkedOperationId
    @Test
    fun `test 7 - diagnostic ZIP bundle is non-empty, completes as SUCCESS, and preserves linkedOperationId`() = runBlocking {
        val devCtx = isolatedDeviceContext("t7_export_zip")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java).allowMainThreadQueries().build()
        AppDatabase.ensureSeeded(db)
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val exportEngine = DiagnosticExportEngine(devCtx, monitor)

        val failingTrace = opLogger.startOperation(ScreenNames.REPORT_EDITOR, DiagnosticModules.REPORTS, "عملية فاشلة للاختبار", "المرحلة س")
        failingTrace.stage("المرحلة ص")
        val errRec = monitor.recordError(
            throwable = IllegalStateException("فشل تجريبي عند المرحلة ص"),
            screenName = ScreenNames.REPORT_EDITOR,
            moduleName = DiagnosticModules.REPORTS,
            operationName = "عملية فاشلة للاختبار",
            linkedOperationId = failingTrace.operationId,
            failedStage = "المرحلة ص",
        )
        failingTrace.fail("فشل تجريبي", errRec.errorId)

        val zipFile = exportEngine.exportDiagnosticBundleZip().getOrThrow()
        assertTrue(zipFile.exists() && zipFile.length() > 0L)

        val entries = linkedMapOf<String, String>()
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val text = zis.readBytes().toString(Charsets.UTF_8)
                assertTrue("ZIP entry ${entry.name} must not be empty", text.isNotBlank())
                entries[entry.name] = text
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val summary = testJson.decodeFromString<DiagnosticSummaryStats>(entries.getValue("diagnostic_summary.json"))
        assertTrue("totalOperationsCount must be > 0", summary.totalOperationsCount > 0)

        val exportedOps = testJson.decodeFromString<List<OperationLogRecord>>(entries.getValue("operation_logs.json"))
        assertTrue(exportedOps.none { it.outcome == OperationOutcome.RUNNING || it.outcome == OperationOutcome.STARTED })

        // Verify post-export state of export operation itself is SUCCESS (not RUNNING)
        val liveExportOp = opLogger.operations.value.firstOrNull { it.operationName.contains("حزمة التشخيص") }
        assertNotNull(liveExportOp)
        assertEquals(OperationOutcome.SUCCESS, liveExportOp!!.outcome)

        val exportedErrors = testJson.decodeFromString<List<ErrorEventRecord>>(entries.getValue("error_logs.json"))
        val matched = exportedErrors.firstOrNull { it.errorId == errRec.errorId }
        assertNotNull(matched)
        assertEquals(failingTrace.operationId, matched!!.linkedOperationId)
        assertEquals("المرحلة ص", matched.failedStage)

        db.close()
    }

    // Test 8: Same-phone ZIP backup & restore still works 100%
    @Test
    fun `test 8 - same-phone backup ZIP and restore preserves all products barcodes images and reports`() = runBlocking {
        val devCtx = isolatedDeviceContext("t8_same_phone")
        val dbFile = File(rootSandbox, "same_phone.db")
        val db = Room.databaseBuilder(devCtx, AppDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(db)

        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val media = MediaStorageManager(devCtx, monitor)
        val prodRepo = ProductRepository(db, media, monitor)
        val rptRepo = ReportRepository(db, media, monitor)
        val backup = BackupRestoreEngine(devCtx, db, media, monitor)

        val savedImg = media.saveDownloadedImageBytes(makePngBytes(Color.GREEN, 48), "png")!!
        val pid = prodRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "SAME-1", name = "منتج نفس الهاتف", basePrice = 35.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "6281110009991", isPrimary = true)),
            images = listOf(ProductImageEntity(productId = 0L, filePath = savedImg.activePath, originalFilePath = savedImg.originalPath, thumbnailPath = savedImg.thumbnailPath, isPrimary = true)),
        ).getOrThrow()
        val prod = db.productDao().getProductWithDetails(pid)!!
        val rid = rptRepo.createEmptyReport(customTitle = "تقرير نفس الجهاز")
        rptRepo.addProductToReport(rid, prod)

        val zip = backup.createBackupZip("same_phone_backup").getOrThrow()
        val bytes = zip.readBytes()

        // Wipe data and restore on same device
        db.productDao().deleteProductsByIds(listOf(pid))
        db.reportDao().deleteReportById(rid)
        assertEquals(0, db.productDao().getAllProductsOnce().size)

        val restored = backup.restoreFromBackupBytes(bytes, zip.name)
        assertTrue("Same-phone restore failed: ${restored.exceptionOrNull()?.message}", restored.isSuccess)
        assertEquals(1, db.productDao().getAllProductsOnce().size)
        val restoredProd = prodRepo.findProductByExactBarcode("6281110009991")
        assertNotNull(restoredProd)
        assertTrue(File(restoredProd!!.images.first().filePath).exists())
        assertEquals(1, db.reportDao().getAllReportsWithDetailsOnce().size)

        db.close()
    }

    // Test 9: Cross-device Phone A -> Phone B restore (schema v11 & legacy schema v10) logs all 14 stages & survives restart
    @Test
    fun `test 9 - cross-device restore covers both legacy v10 and v11 backups and logs all 14 stages through restart`() = runBlocking {
        // Part A: Schema v11 backup Phone A -> Phone B
        val phoneACtx = isolatedDeviceContext("t9_phoneA")
        val dbA = Room.inMemoryDatabaseBuilder(phoneACtx, AppDatabase::class.java).allowMainThreadQueries().build()
        AppDatabase.ensureSeeded(dbA)
        val mediaA = MediaStorageManager(phoneACtx)
        val prodRepoA = ProductRepository(dbA, mediaA)
        val rptRepoA = ReportRepository(dbA, mediaA)
        val backupA = BackupRestoreEngine(phoneACtx, dbA, mediaA)

        val imgA = mediaA.saveDownloadedImageBytes(makePngBytes(Color.RED, 60), "png")!!
        val pidA = prodRepoA.createOrUpdateProduct(
            product = ProductEntity(internalCode = "CD-1", name = "منتج نقل هاتف", basePrice = 80.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "6285554443332", isPrimary = true)),
            images = listOf(ProductImageEntity(productId = 0L, filePath = imgA.activePath, originalFilePath = imgA.originalPath, thumbnailPath = imgA.thumbnailPath, isPrimary = true)),
        ).getOrThrow()
        val ridA = rptRepoA.createEmptyReport(customTitle = "تقرير عبر الأجهزة")
        rptRepoA.addProductToReport(ridA, dbA.productDao().getProductWithDetails(pidA)!!)
        val zipA = backupA.createBackupZip("phoneA_v11").getOrThrow()
        val zipABytes = zipA.readBytes()
        dbA.close()
        File(rootSandbox, "t9_phoneA").deleteRecursively()

        val phoneBCtx = isolatedDeviceContext("t9_phoneB")
        val dbFileB = File(rootSandbox, "t9_phoneB.db")
        var dbB = Room.databaseBuilder(phoneBCtx, AppDatabase::class.java, dbFileB.absolutePath)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(dbB)
        val storeB = DiagnosticsFileStore(phoneBCtx.filesDir)
        val opLoggerB = OperationLogger(storeB) { dbB.diagnosticsDao() }
        val monitorB = GlobalErrorMonitor(phoneBCtx, storeB, opLoggerB) { dbB.diagnosticsDao() }
        val mediaB = MediaStorageManager(phoneBCtx, monitorB)
        val backupB = BackupRestoreEngine(phoneBCtx, dbB, mediaB, monitorB)

        val restoreV11 = backupB.restoreFromBackupBytes(zipABytes, "phoneA_v11.zip")
        assertTrue(restoreV11.isSuccess)

        // Simulate Phone B restart & verify Stage 14
        dbB.close()
        dbB = Room.databaseBuilder(phoneBCtx, AppDatabase::class.java, dbFileB.absolutePath)
            .allowMainThreadQueries()
            .build()
        val restartedLoggerB = OperationLogger(storeB) { dbB.diagnosticsDao() }
        val restartedMonitorB = GlobalErrorMonitor(phoneBCtx, storeB, restartedLoggerB) { dbB.diagnosticsDao() }
        val restartedBackupB = BackupRestoreEngine(phoneBCtx, dbB, mediaB, restartedMonitorB)
        restartedBackupB.verifyPendingRestoreAfterAppRestart()

        val op14 = restartedLoggerB.operations.value.firstOrNull { it.moduleName == DiagnosticModules.BACKUP_RESTORE }
        assertNotNull(op14)
        val stageNames = op14!!.stages.map { it.stageName }
        for (stageNum in 1..14) {
            assertTrue("Missing stage $stageNum in $stageNames", stageNames.any { it.startsWith("$stageNum.") })
        }
        assertEquals(OperationOutcome.SUCCESS, op14.outcome)

        // Part B: Legacy schema v10 backup with foreign Phone A paths + wrapped root folder
        val legacyPayload = BackupDatabasePayload(
            settings = AppSettingsEntity(companyName = "شركة إرث v10"),
            products = listOf(ProductEntity(id = 77L, internalCode = "LEG-10", name = "منتج نسخة قديمة v10", basePrice = 42.0)),
            productBarcodes = listOf(ProductBarcodeEntity(id = 78L, productId = 77L, barcodeValue = "0099887766554", isPrimary = true)),
            productImages = listOf(
                ProductImageEntity(
                    id = 79L,
                    productId = 77L,
                    filePath = "/data/user/0/com.old.phone/files/assets/products/legacy_img.png",
                    isPrimary = true,
                ),
            ),
        )
        val legacyManifest = BackupManifest(
            formatVersion = 5,
            databaseSchemaVersion = 10,
            productCount = 1,
            barcodeCount = 1,
            imageCount = 1,
        )
        val legacyZipBytes = ByteArrayOutputStream().also { out ->
            ZipOutputStream(out).use { zos ->
                zos.putNextEntry(ZipEntry("LegacyFolder/manifest.json"))
                zos.write(testJson.encodeToString(legacyManifest).toByteArray())
                zos.closeEntry()
                zos.putNextEntry(ZipEntry("LegacyFolder/database_export.json"))
                zos.write(testJson.encodeToString(legacyPayload).toByteArray())
                zos.closeEntry()
                zos.putNextEntry(ZipEntry("LegacyFolder/assets/products/legacy_img.png"))
                zos.write(makePngBytes(Color.YELLOW, 32))
                zos.closeEntry()
            }
        }.toByteArray()

        val legacyRes = restartedBackupB.restoreFromBackupBytes(legacyZipBytes, "legacy_v10.zip")
        assertTrue("Legacy v10 cross-device restore failed: ${legacyRes.exceptionOrNull()?.message}", legacyRes.isSuccess)
        val legacyProd = ProductRepository(dbB, mediaB, restartedMonitorB).findProductByExactBarcode("0099887766554")
        assertNotNull(legacyProd)
        assertTrue(File(legacyProd!!.images.first().filePath).exists())

        dbB.close()
    }

    // Test 10: Forced termination mid-operation transitions RUNNING -> FAILED, preserves stages, enriches reason & links IDs
    @Test
    fun `test 10 - simulated forced termination mid-operation reconciles RUNNING op to FAILED and enriches crash linkage`() {
        val devCtx = isolatedDeviceContext("t10_kill")
        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val loggerSession1 = OperationLogger(fileStore)
        val trace = loggerSession1.startOperation(
            screenName = ScreenNames.BACKUP_RESTORE,
            moduleName = DiagnosticModules.BACKUP_RESTORE,
            operationName = "استعادة نسخة كبيرة عبر الأجهزة",
            initialStage = "1. فك ضغط الأرشيف",
        )
        trace.stage("2. التحقق من قاعدة البيانات", status = "DONE")
        trace.stage("3. استبدال الصور في التخزين", status = "STARTED")

        // Verify persisted synchronously on disk as RUNNING even without calling succeed/fail
        val onDiskBeforeRestart = fileStore.readAllOperations()
        val runningOnDisk = onDiskBeforeRestart.firstOrNull { it.operationId == trace.operationId }
        assertNotNull(runningOnDisk)
        assertEquals(OperationOutcome.RUNNING, runningOnDisk!!.outcome)

        // Simulate abrupt OS process kill -> fresh OperationLogger & GlobalErrorMonitor started on next launch
        val loggerSession2 = OperationLogger(fileStore)
        val monitorSession2 = GlobalErrorMonitor(devCtx, fileStore, loggerSession2)
        monitorSession2.installGlobalHandlers(null)

        assertTrue(monitorSession2.priorCrashDetected)
        val reconciled = loggerSession2.operations.value.firstOrNull { it.operationId == trace.operationId }
        assertNotNull(reconciled)
        assertEquals(OperationOutcome.FAILED, reconciled!!.outcome)
        assertTrue(reconciled.interruptedAbnormally)
        assertEquals("3. استبدال الصور في التخزين", reconciled.currentStage)
        assertEquals("2. التحقق من قاعدة البيانات", reconciled.lastSuccessfulStage)
        assertTrue(reconciled.linkedErrorId.isNotBlank())

        val linkedErr = monitorSession2.errors.value.firstOrNull { it.errorId == reconciled.linkedErrorId }
        assertNotNull(linkedErr)
        assertEquals(trace.operationId, linkedErr!!.linkedOperationId)
        assertEquals("3. استبدال الصور في التخزين", linkedErr.failedStage)
        assertFalse("Crash message must not be bare 'crash'", linkedErr.originalMessage.trim().equals("crash", ignoreCase = true))
        assertTrue(linkedErr.originalMessage.contains("3. استبدال الصور في التخزين"))
    }
}
