package com.example

import com.example.data.local.TemplateDefaults
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.layout.ColumnLayoutEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.ColumnConfigModel
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.ColumnType
import com.example.domain.model.OverflowSuggestionType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PageSpec
import com.example.domain.model.PaperSizeType
import com.example.domain.model.TemplateKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BarcodeAndLayoutEngineTest {

    @Test
    fun `generated barcodes decode back to exact original strings preserving leading zeros`() {
        val cases = listOf(
            BarcodeFormatType.EAN_13 to "0012345678905",
            BarcodeFormatType.EAN_13 to "6281006530126",
            BarcodeFormatType.EAN_8 to "00123457",
            BarcodeFormatType.UPC_A to "012345678905",
            BarcodeFormatType.CODE_128 to "000998877-AB",
            BarcodeFormatType.CODE_39 to "ITEM-001",
            BarcodeFormatType.ITF to "00112233",
            BarcodeFormatType.QR_CODE to "0012345678905-ARABIC",
        )
        for ((format, value) in cases) {
            val validation = BarcodeEngine.validate(value, format)
            assertTrue("Validation failed for $format / $value: ${validation.errorMessage}", validation.isValid)

            val w = if (format.is2D) 420 else 720
            val h = if (format.is2D) 420 else 240
            val bitmap = BarcodeEngine.generateHighResBitmap(value, format, w, h, showText = false)
            assertNotNull("Bitmap null for $format", bitmap)

            val decoded = BarcodeEngine.decodeBitmap(bitmap!!, expectedFormat = format)
            assertNotNull("Independent decoder failed for $format ($value)", decoded)
            assertEquals("Mismatch on $format", value, decoded!!.text)
            assertEquals(format, decoded.format)

            if (value == "6281006530126") {
                val autoDecoded = BarcodeEngine.decodeBitmap(bitmap)
                assertEquals(value, autoDecoded?.text)
            }

            val svg = BarcodeEngine.generateSvg(value, format)
            assertTrue(svg.contains("<svg"))
            assertTrue(svg.contains("<rect"))
            bitmap.recycle()
        }
    }

    @Test
    fun `column layout engine fills 100 percent usable width across paper sizes and modes`() {
        val officialTemplate = TemplateDefaults.buildBuiltInTemplates()
            .first { it.templateKind == TemplateKind.OFFICIAL_COMMERCIAL.name }
        val cols = TemplateDefaults.decodeColumns(officialTemplate.columnsConfigJson)

        val specs = listOf(
            PageSpec(PaperSizeType.A4, orientation = PageOrientation.PORTRAIT),
            PageSpec(PaperSizeType.A4, orientation = PageOrientation.LANDSCAPE),
            PageSpec(PaperSizeType.A3, orientation = PageOrientation.PORTRAIT),
            PageSpec(PaperSizeType.LETTER, orientation = PageOrientation.LANDSCAPE),
        )
        for (spec in specs) {
            for (mode in listOf(ColumnDistributionMode.AUTO_FIT, ColumnDistributionMode.EQUAL, ColumnDistributionMode.MANUAL)) {
                val res = ColumnLayoutEngine.calculateLayout(spec, cols, mode)
                assertFalse("Unexpected overflow on ${spec.paperSize}/${spec.orientation}/$mode", res.hasOverflow)
                assertEquals(spec.usableWidthPt, res.totalAllocatedWidthPt, 1.5f)
                val barcodeCol = res.computedColumns.firstOrNull { it.column.columnType == ColumnType.BARCODE }
                if (barcodeCol != null) {
                    assertTrue("Barcode column too narrow: ${barcodeCol.widthPt}", barcodeCol.widthPt >= 82f)
                }
            }
        }
    }

    @Test
    fun `column layout detects overflow without auto-deleting columns and offers split horizontal groups`() {
        val manyCols = (1..10).map { i ->
            ColumnConfigModel(
                id = i.toLong(),
                columnKey = "col_$i",
                title = "عمود $i",
                columnType = if (i == 3) ColumnType.BARCODE else ColumnType.TEXT,
                sortOrder = i,
                visible = true,
                minWidthPt = 50f,
            )
        }
        val narrowSpec = PageSpec(PaperSizeType.A5, orientation = PageOrientation.PORTRAIT)

        val overflowRes = ColumnLayoutEngine.calculateLayout(narrowSpec, manyCols, ColumnDistributionMode.AUTO_FIT)
        assertTrue(overflowRes.hasOverflow)
        assertTrue(overflowRes.overflowAmountPt > 0f)
        assertEquals(10, overflowRes.computedColumns.size) // NEVER deletes or hides columns
        assertTrue(overflowRes.suggestions.any { it.type == OverflowSuggestionType.SWITCH_LANDSCAPE })
        assertTrue(overflowRes.suggestions.any { it.type == OverflowSuggestionType.SPLIT_HORIZONTAL_GROUPS })

        val splitRes = ColumnLayoutEngine.calculateLayout(
            narrowSpec,
            manyCols,
            ColumnDistributionMode.AUTO_FIT,
            splitHorizontalGroups = true,
        )
        assertTrue(splitRes.columnGroups.size >= 2)
        splitRes.columnGroups.forEach { group ->
            val sum = group.sumOf { it.widthPt.toDouble() }.toFloat()
            assertEquals(narrowSpec.usableWidthPt, sum, 1.5f)
        }
    }
}
