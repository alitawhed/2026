package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ExcelImageConflictPolicy
import com.example.data.local.entity.ImageDownloadStatus
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.DuplicateCountAction
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.repository.SettingsRepository
import com.example.data.storage.BackendHttpTransport
import com.example.data.storage.BackendImageSyncService
import com.example.data.storage.ImageResolution
import com.example.data.storage.ImageService
import com.example.data.storage.MediaStorageManager
import com.example.data.storage.PayloadTooLargeException
import com.example.data.storage.RemoteHttpResponse
import com.example.data.storage.RemoteImageBytesResult
import com.example.data.storage.RemoteImageDownloader
import com.example.data.storage.RemoteImageFailureKind
import com.example.data.storage.RemoteImageTransport
import com.example.data.storage.RemoteImageUrlValidator
import com.example.data.storage.SecurityUrlException
import com.example.di.AppContainer
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.excel.ExcelImportConflictException
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ExcelNewBarcodePolicy
import com.example.domain.excel.ExcelRowConflictType
import com.example.domain.excel.ExcelUrlImageStatus
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.LocalFolderImageCandidate
import com.example.domain.excel.OfficialApiImageConfig
import com.example.domain.excel.ProductImportField
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.ui.viewmodel.ProductFilterMode
import com.example.ui.viewmodel.ProductsViewModel
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ExcelImageUrlImportTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var context: Context
    private lateinit var dbFile: File
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var inventoryRepo: InventoryRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var excelExport: ExcelExportEngine
    private lateinit var pdfGenerator: PdfGeneratorEngine
    private lateinit var backupEngine: BackupRestoreEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        dbFile = tempFolder.newFile("excel_url_test.db")
        db = openFileDatabase()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        inventoryRepo = InventoryRepository(db)
        reportRepo = ReportRepository(db, mediaStorage)
        settingsRepo = SettingsRepository(db)
        excelExport = ExcelExportEngine(mediaStorage)
        pdfGenerator = PdfGeneratorEngine(context, mediaStorage)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        if (db.isOpen) db.close()
    }

    private fun openFileDatabase(): AppDatabase {
        return Room.databaseBuilder(context, AppDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
    }

    private fun makeTestBitmapBytes(
        width: Int = 120,
        height: Int = 90,
        bgColor: Int = Color.BLUE,
        format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG,
    ): ByteArray {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(bgColor)
        val paint = Paint().apply { color = Color.YELLOW; strokeWidth = 6f }
        canvas.drawLine(0f, 0f, width.toFloat(), height.toFloat(), paint)
        return ByteArrayOutputStream().use { out ->
            bmp.compress(format, 95, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    private fun buildXlsxBytes(
        headers: List<String>,
        rows: List<List<String>>,
        hyperlinkFormulaCell: Pair<Int, Int>? = null, // 1-based (row, col) -> emits =HYPERLINK("url", "صورة")
    ): ByteArray {
        fun colLetter(colZeroBased: Int): String {
            var n = colZeroBased + 1
            val sb = StringBuilder()
            while (n > 0) {
                val rem = (n - 1) % 26
                sb.append(('A'.code + rem).toChar())
                n = (n - 1) / 26
            }
            return sb.reverse().toString()
        }

        fun xmlEsc(s: String): String = s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

        val allRows = listOf(headers) + rows
        val sheetXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8"?>""")
            append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            allRows.forEachIndexed { rIdx, rVals ->
                val rowNum = rIdx + 1
                append("""<row r="$rowNum">""")
                rVals.forEachIndexed { cIdx, v ->
                    val ref = "${colLetter(cIdx)}$rowNum"
                    if (hyperlinkFormulaCell != null &&
                        hyperlinkFormulaCell.first == rowNum &&
                        hyperlinkFormulaCell.second == (cIdx + 1)
                    ) {
                        append("""<c r="$ref" t="str"><f>HYPERLINK("${xmlEsc(v)}", "عرض الصورة")</f><v>عرض الصورة</v></c>""")
                    } else if (v.isNotEmpty()) {
                        append("""<c r="$ref" t="inlineStr"><is><t>${xmlEsc(v)}</t></is></c>""")
                    }
                }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }

        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zos ->
            fun put(name: String, content: String) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            put(
                "[Content_Types].xml",
                """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
            )
            put(
                "_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
            )
            put(
                "xl/workbook.xml",
                """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="المنتجات" sheetId="1" r:id="rId1"/></sheets></workbook>""",
            )
            put(
                "xl/_rels/workbook.xml.rels",
                """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
            )
            put("xl/worksheets/sheet1.xml", sheetXml)
        }
        return out.toByteArray()
    }

    @Test
    fun `full excel url import covers all 7 scenarios retries failed urls persists across restart and shows images everywhere`() = runBlocking {
        // Seed existing Product A with an old stored image + primary & alternative barcodes
        val oldImgStored = mediaStorage.saveProductImageBytesWithOriginal(
            makeTestBitmapBytes(80, 80, Color.DKGRAY, Bitmap.CompressFormat.PNG),
        )!!
        val existingPidA = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "OLD-100", name = "شاي سيلاني قديم", basePrice = 25.0),
            listOf(
                ProductBarcodeEntity(productId = 0L, barcodeValue = "11100011", isPrimary = true),
                ProductBarcodeEntity(productId = 0L, barcodeValue = "11100022", isPrimary = false),
            ),
            listOf(
                ProductImageEntity(
                    productId = 0L,
                    filePath = oldImgStored.activePath,
                    originalFilePath = oldImgStored.originalPath,
                    thumbnailPath = oldImgStored.thumbnailPath,
                    isPrimary = true,
                ),
            ),
        ).getOrThrow()

        // Seed Foreign Product B owning barcode 99988877
        productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "FOR-200", name = "زيت زيتون أصلي", basePrice = 60.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "99988877", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val validPngBytes = makeTestBitmapBytes(200, 150, Color.GREEN, Bitmap.CompressFormat.PNG)
        val validJpegBytes = makeTestBitmapBytes(180, 140, Color.MAGENTA, Bitmap.CompressFormat.JPEG)
        val slowRecoveredBytes = makeTestBitmapBytes(160, 120, Color.CYAN, Bitmap.CompressFormat.PNG)
        val timeoutShouldSucceedNow = AtomicBoolean(false)

        val transport = RemoteImageTransport { url, _, _, maxBytes ->
            when {
                url == "https://cdn.example.com/valid_new.png" -> RemoteHttpResponse(
                    statusCode = 200,
                    contentType = "image/png",
                    contentLength = validPngBytes.size.toLong(),
                    bytes = validPngBytes,
                    finalUrl = url,
                )
                url == "https://cdn.example.com/existing_replace.jpg" -> RemoteHttpResponse(
                    statusCode = 200,
                    contentType = "image/jpeg",
                    contentLength = validJpegBytes.size.toLong(),
                    bytes = validJpegBytes,
                    finalUrl = url,
                )
                url == "https://cdn.example.com/expired_404.png" -> RemoteHttpResponse(
                    statusCode = 404,
                    contentType = "text/html",
                    contentLength = 0L,
                    bytes = ByteArray(0),
                    finalUrl = url,
                )
                url == "https://cdn.example.com/unauth_403.png" -> RemoteHttpResponse(
                    statusCode = 403,
                    contentType = "text/plain",
                    contentLength = 0L,
                    bytes = ByteArray(0),
                    finalUrl = url,
                )
                url == "https://cdn.example.com/fake_exe.png" -> RemoteHttpResponse(
                    statusCode = 200,
                    contentType = "application/x-msdownload",
                    contentLength = 8L,
                    bytes = byteArrayOf(0x4D, 0x5A, 0x90.toByte(), 0x00, 0x03, 0x00, 0x00, 0x00), // MZ header
                    finalUrl = url,
                )
                url == "https://cdn.example.com/oversized.png" -> {
                    throw PayloadTooLargeException(maxBytes + 50_000L, maxBytes)
                }
                url == "https://cdn.example.com/slow_timeout.png" -> {
                    if (!timeoutShouldSucceedNow.get()) {
                        throw SocketTimeoutException("Read timed out")
                    }
                    RemoteHttpResponse(
                        statusCode = 200,
                        contentType = "image/png",
                        contentLength = slowRecoveredBytes.size.toLong(),
                        bytes = slowRecoveredBytes,
                        finalUrl = url,
                    )
                }
                url == "https://cdn.example.com/redirect_local.png" -> RemoteHttpResponse(
                    statusCode = 200,
                    contentType = "image/png",
                    contentLength = validPngBytes.size.toLong(),
                    bytes = validPngBytes,
                    finalUrl = "http://127.0.0.1/secret.png",
                )
                else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
            }
        }

        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = transport,
            maxFileBytes = 256L * 1024L,
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        // Build real XLSX with custom reordered column headers (testing manual mapping & HYPERLINK formula support)
        val customHeaders = listOf("Photo Link", "Custom SKU Code", "Item Title")
        val excelRows = listOf(
            // Row 2: 1. New product with valid image URL (via =HYPERLINK formula!)
            listOf("https://cdn.example.com/valid_new.png", "00102030", "عسل سدر جبلي"),
            // Row 3: 2. Existing product matched by ALTERNATIVE barcode (11100022) with old image + new URL
            listOf("https://cdn.example.com/existing_replace.jpg", "11100022", "اسم مختلف لا يطمس القديم"),
            // Row 4: 3a. Duplicate barcode belonging to foreign product (99988877)
            listOf("https://cdn.example.com/valid_new.png", "99988877", "منتج بباركود أجنبي"),
            // Row 5: 3b. Intra-file duplicate first occurrence
            listOf("", "77766655", "تونة فاخرة أول"),
            // Row 6: 3c. Intra-file duplicate second occurrence
            listOf("", "77766655", "تونة فاخرة مكرر"),
            // Row 7: 4a. Invalid URL syntax (non-HTTP local file path)
            listOf("file:///etc/passwd", "00440011", "منتج برابط محلي غير صالح"),
            // Row 8: 4b. Non-image executable bytes & 404 & redirect to 127.0.0.1 & 403
            listOf("https://cdn.example.com/fake_exe.png", "00440022", "منتج بملف تنفيذي مزيف"),
            listOf("https://cdn.example.com/expired_404.png", "00440033", "منتج برابط منتهي 404"),
            listOf("https://cdn.example.com/unauth_403.png", "00440044", "منتج برابط محمي 403"),
            listOf("https://cdn.example.com/redirect_local.png", "00440055", "منتج بتحويل داخلي محظور"),
            // Row 11: 5. Oversized image
            listOf("https://cdn.example.com/oversized.png", "00550066", "منتج بصورة ضخمة الحجم"),
            // Row 12: 6. Unresponsive / timeout URL (will recover on retry)
            listOf("https://cdn.example.com/slow_timeout.png", "00660077", "منتج برابط بطيء مهلة"),
            // Row 13: 7. Product without image URL
            listOf("", "00770088", "منتج بدون رابط صورة"),
        )
        val xlsxBytes = buildXlsxBytes(
            headers = customHeaders,
            rows = excelRows,
            hyperlinkFormulaCell = 2 to 1, // row 2, col 1 wrapped in =HYPERLINK("...", "عرض الصورة")
        )

        val parsed = excelImport.parseBytes(xlsxBytes, "products_with_urls.xlsx").getOrThrow()
        val sheet = parsed.sheets.single()
        assertEquals("https://cdn.example.com/valid_new.png", sheet.rows[1][0])
        assertEquals("00102030", sheet.rows[1][1])

        // Manual column mapping (since headers are non-standard custom names)
        val manualMapping = mapOf(
            0 to ProductImportField.IMAGE_URL,
            1 to ProductImportField.PRIMARY_BARCODE,
            2 to ProductImportField.NAME,
        )

        val draft = excelImport.buildPreImportReviewDraft(
            sheet = sheet,
            mappings = manualMapping,
            hasHeaderRow = true,
            policy = ImportDuplicatePolicy.SKIP,
        )
        assertEquals(excelRows.size, draft.rows.size)

        // Row idx 1 -> Existing product A matched via alternative barcode
        val existingRow = draft.rows[1]
        assertEquals(existingPidA, existingRow.matchedExistingProductId)
        assertTrue(existingRow.existingProductHasImage)
        assertEquals(ExcelImageConflictPolicy.KEEP_EXISTING, existingRow.imageConflictPolicy)
        assertEquals(oldImgStored.thumbnailPath, existingRow.existingProductImagePath)

        // Blocking conflicts exist (foreign + intra-file dup) -> commit MUST reject before resolution
        assertTrue(draft.computeSummary().unresolvedBlockingCount > 0)
        try {
            excelImport.commitReviewedImport(draft)
            fail("Expected ExcelImportConflictException for unresolved conflicts")
        } catch (_: ExcelImportConflictException) {
            // expected
        }

        // Probe preview for valid URL and invalid URL
        val probeValid = excelImport.probeUrlForReview(draft.rows[0].imageUrl)
        assertEquals(ExcelUrlImageStatus.READY, probeValid.status)
        assertNotNull(probeValid.previewThumbnailPath)
        assertTrue(File(probeValid.previewThumbnailPath!!).exists())

        val probeLocalInvalid = excelImport.probeUrlForReview(draft.rows[5].imageUrl)
        assertEquals(ExcelUrlImageStatus.FAILED, probeLocalInvalid.status)

        // Pass 1: Resolve conflicts & keep old image on Existing Product A (`KEEP_EXISTING`)
        val resolvedKeepOld = draft.copy(
            rows = draft.rows.mapIndexed { i, r ->
                when (i) {
                    1 -> r.copy(imageConflictPolicy = ExcelImageConflictPolicy.KEEP_EXISTING)
                    4 -> r.copy(skipRow = true, newBarcodePolicy = ExcelNewBarcodePolicy.SKIP_PRODUCT) // skip duplicate row
                    else -> r
                }
            },
        )
        assertEquals(0, resolvedKeepOld.computeSummary().unresolvedBlockingCount)

        val report1 = excelImport.commitReviewedImport(resolvedKeepOld)
        // Row 1 skipped (KEEP_EXISTING under SKIP policy), Row 4 skipped (intra-file duplicate),
        // Row 2 matched existing product Foreign Product B (no duplicate created, image added -> updated=1),
        // All other 10 rows inserted!
        assertEquals(10, report1.insertedCount)
        assertEquals(1, report1.updatedCount)
        assertEquals(2, report1.skippedCount)
        assertEquals(0, report1.errorCount)
        assertEquals(2, report1.imageDownloadSuccessCount) // row 0 and row 2 (deduplicated)
        assertEquals(7, report1.imageDownloadFailedCount) // rows 5,6,7,8,9,10,11
        assertEquals(1, report1.imageDownloadSkippedCount) // row 1 KEEP_EXISTING

        // Verify duplicate barcode row 2 matched existing Foreign Product B without creating a duplicate product
        assertEquals(1, db.productDao().getAllProductsOnce().count { it.name == "زيت زيتون أصلي" })
        val foreignMatchedAfter = productRepo.findProductByExactBarcode("99988877")!!
        assertEquals("زيت زيتون أصلي", foreignMatchedAfter.product.name)
        assertEquals(1, foreignMatchedAfter.images.size)

        // Verify Existing Product A kept old image & old name and no duplicate was created
        val existingAfterKeep = db.productDao().getProductWithDetails(existingPidA)!!
        assertEquals("شاي سيلاني قديم", existingAfterKeep.product.name)
        assertEquals(1, existingAfterKeep.images.size)
        assertEquals(oldImgStored.activePath, existingAfterKeep.primaryImage?.filePath)
        assertEquals(1, db.productDao().getAllProductsOnce().count { it.name.contains("شاي") })

        // Now verify Existing Product A supports explicit REPLACE_PRIMARY without creating duplicates
        val draftReplace = resolvedKeepOld.copy(
            rows = listOf(draft.rows[1].copy(imageConflictPolicy = ExcelImageConflictPolicy.REPLACE_PRIMARY)),
        )
        val reportReplace = excelImport.commitReviewedImport(draftReplace)
        assertEquals(1, reportReplace.updatedCount)
        assertEquals(1, reportReplace.imageDownloadSuccessCount)
        val existingAfterReplace = db.productDao().getProductWithDetails(existingPidA)!!
        assertEquals(1, existingAfterReplace.images.size)
        assertNotEquals(oldImgStored.activePath, existingAfterReplace.primaryImage?.filePath)
        assertEquals("https://cdn.example.com/existing_replace.jpg", existingAfterReplace.primaryImage?.sourceUrl)
        assertEquals("11100022", existingAfterReplace.primaryImage?.matchedBarcode)
        assertEquals(ImageDownloadStatus.SUCCESS.name, existingAfterReplace.primaryImage?.downloadStatus)

        // Verify New Product #1 ("00102030") stored original + active + thumbnail + ProductID link
        val newProd1 = productRepo.findProductByExactBarcode("00102030")!!
        assertEquals("عسل سدر جبلي", newProd1.product.name)
        val newProdImg = newProd1.primaryImage!!
        assertEquals(newProd1.product.id, newProdImg.productId)
        assertEquals("https://cdn.example.com/valid_new.png", newProdImg.sourceUrl)
        assertEquals("00102030", newProdImg.matchedBarcode)
        assertTrue(newProdImg.downloadedAt > 0L)
        assertTrue(File(newProdImg.filePath).exists())
        assertTrue(File(newProdImg.originalFilePath).exists())
        assertTrue(File(newProdImg.thumbnailPath).exists())
        // Untouched original file preserves exact downloaded PNG bytes!
        assertTrue(validPngBytes.contentEquals(File(newProdImg.originalFilePath).readBytes()))

        // Verify products whose image URLs failed STILL exist in DB with retained data
        val timeoutProdBeforeRetry = productRepo.findProductByExactBarcode("00660077")!!
        assertEquals("منتج برابط بطيء مهلة", timeoutProdBeforeRetry.product.name)
        assertTrue(timeoutProdBeforeRetry.images.isEmpty())

        val noUrlProd = productRepo.findProductByExactBarcode("00770088")!!
        assertEquals("منتج بدون رابط صورة", noUrlProd.product.name)
        assertTrue(noUrlProd.images.isEmpty())

        // Verify Export Error Report to Excel produces valid readable XLSX with failure reasons
        val errXlsx = excelExport.exportImageImportErrorsToXlsx(
            downloads = report1.imageDownloadRecords,
            importIssues = report1.issues,
            fileName = "url_import_errors_test.xlsx",
        )
        assertTrue(errXlsx.exists() && errXlsx.length() > 0)
        val parsedErrSheet = excelImport.parseBytes(errXlsx.readBytes(), errXlsx.name).getOrThrow().sheets.first()
        assertTrue(parsedErrSheet.rows.size >= 8)

        // Verify Retry Failed Images recovers slow_timeout.png WITHOUT duplicating any products!
        val productCountBeforeRetry = db.productDao().getAllProductsOnce().size
        timeoutShouldSucceedNow.set(true)
        val retryResult = excelImport.retryFailedImageDownloads(batchId = report1.downloadBatchId)
        assertEquals(7, retryResult.totalAttempted)
        assertEquals(1, retryResult.succeededCount)
        assertEquals(6, retryResult.failedCount)
        assertEquals(productCountBeforeRetry, db.productDao().getAllProductsOnce().size)

        val timeoutProdAfterRetry = productRepo.findProductByExactBarcode("00660077")!!
        assertEquals(1, timeoutProdAfterRetry.images.size)
        assertTrue(File(timeoutProdAfterRetry.primaryImage!!.filePath).exists())

        // Simulate App / Database Restart: close DB, re-open file-backed DB
        db.close()
        db = openFileDatabase()
        productRepo = ProductRepository(db, mediaStorage)
        inventoryRepo = InventoryRepository(db)
        reportRepo = ReportRepository(db, mediaStorage)
        settingsRepo = SettingsRepository(db)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)

        // Assert persistence & cross-screen image visibility after restart
        // 1) Products list & 2) Product Detail
        val reopenedProd1 = productRepo.findProductByExactBarcode("00102030")!!
        assertEquals(1, reopenedProd1.images.size)
        val detailResolution = ImageService.resolveProductImageStateless(reopenedProd1.primaryImage, preferThumbnail = false)
        assertTrue("Expected image available in Product Detail", detailResolution is ImageResolution.Available)

        // 3) Inventory Screen
        val invSessionId = inventoryRepo.createSession("جرد تجربة الصور المستوردة").getOrThrow()
        inventoryRepo.recordCountedItem(
            sessionId = invSessionId,
            product = reopenedProd1,
            scannedBarcode = "00102030",
            barcodeType = "CODE_128",
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 3.0,
            duplicateAction = DuplicateCountAction.ADD_TO_EXISTING,
        ).getOrThrow()
        val invDetails = inventoryRepo.getSessionOnce(invSessionId)!!
        val invResolution = ImageService.resolveInventoryItemImageStateless(
            snapshotPath = invDetails.items.single().productImagePath,
            product = reopenedProd1,
            preferThumbnail = true,
        )
        assertTrue("Expected image available in Inventory", invResolution is ImageResolution.Available)

        // 4) Reports & 5) PDF Preview / Printed PDFs
        val reportId = reportRepo.createEmptyReport(customTitle = "تقرير اختبار صور الروابط")
        reportRepo.addProductToReport(reportId, reopenedProd1)
        val reportDetails = reportRepo.getReportOnce(reportId)!!
        val repItem = reportDetails.items.single()
        assertTrue(
            "Expected report image snapshot to exist on disk",
            ImageService.resolveRawPathStateless(repItem.item.imageSnapshotPath) is ImageResolution.Available,
        )

        val renderedPages = mutableListOf<Bitmap>()
        val recordingFactory = PdfSessionFactory {
            object : PdfSession {
                private val pages = mutableListOf<Bitmap>()
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                    val bmp = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                    pages.add(bmp)
                    renderedPages.add(bmp)
                    return Canvas(bmp)
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: java.io.OutputStream) {
                    outputStream.write("%PDF-1.4\n% Rendered ${pages.size} pages\n".toByteArray())
                }
                override fun close() = Unit
            }
        }
        val testPdfGenerator = PdfGeneratorEngine(context, mediaStorage, recordingFactory)

        val settings = settingsRepo.getSettingsOnce()
        val invCfg = settingsRepo.getInventoryConfigOnce()
        val reportPdf = testPdfGenerator.generateReportPdf(reportDetails, settings, outputFileName = "test_url_report.pdf")
        assertTrue(reportPdf.file.exists() && reportPdf.file.length() > 0 && reportPdf.pageCount >= 1)
        assertTrue(
            "Expected imported green product image pixels to be rendered on Report PDF",
            renderedPages.any { bmp ->
                (0 until bmp.height step 4).any { y ->
                    (0 until bmp.width step 4).any { x -> bmp.getPixel(x, y) == Color.GREEN }
                }
            },
        )
        renderedPages.clear()
        val invPdf = testPdfGenerator.generateInventoryReportPdf(invDetails, listOf(reopenedProd1), settings, invCfg, "test_url_inv.pdf")
        assertTrue(invPdf.file.exists() && invPdf.file.length() > 0 && invPdf.pageCount >= 1)
        assertTrue(
            "Expected imported green product image pixels to be rendered on Inventory PDF",
            renderedPages.any { bmp ->
                (0 until bmp.height step 4).any { y ->
                    (0 until bmp.width step 4).any { x -> bmp.getPixel(x, y) == Color.GREEN }
                }
            },
        )

        // Backup & Restore ZIP compatibility
        val backupZip = backupEngine.createBackupZip("test_url_backup.zip").getOrThrow()
        assertTrue(backupZip.exists() && backupZip.length() > 0)
        db.productDao().deleteProductsByIds(listOf(reopenedProd1.product.id))
        assertEquals(0, db.productDao().getProductWithDetails(reopenedProd1.product.id)?.images?.size ?: 0)
        backupEngine.restoreFromBackupBytes(backupZip.readBytes(), backupZip.name).getOrThrow()
        val restoredProd1 = productRepo.findProductByExactBarcode("00102030")!!
        assertTrue(ImageService.resolveProductImageStateless(restoredProd1.primaryImage, false) is ImageResolution.Available)
        assertFalse(db.productDao().getAllImageDownloadsOnce().isEmpty())
    }

    @Test
    fun `concurrent batch download with shared URL does not race when one product keeps existing image`() = runBlocking {
        // Seed an existing product with an existing valid image
        val existingImg = mediaStorage.saveProductImageBytesWithOriginal(
            makeTestBitmapBytes(60, 60, Color.GRAY, Bitmap.CompressFormat.PNG),
        )!!
        val existingPid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "CONC-1", name = "منتج موجود أ", basePrice = 10.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "88800011", isPrimary = true)),
            listOf(
                ProductImageEntity(
                    productId = 0L,
                    filePath = existingImg.activePath,
                    originalFilePath = existingImg.originalPath,
                    thumbnailPath = existingImg.thumbnailPath,
                    isPrimary = true,
                ),
            ),
        ).getOrThrow()

        val sharedPng = makeTestBitmapBytes(100, 100, Color.RED, Bitmap.CompressFormat.PNG)
        val networkCalls = AtomicInteger(0)
        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                networkCalls.incrementAndGet()
                Thread.sleep(25)
                RemoteHttpResponse(200, "image/png", sharedPng.size.toLong(), sharedPng, url)
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        // Also seed a second existing product WITHOUT an image, plus two new products, all sharing the same URL
        val noImgPid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "CONC-2", name = "منتج بدون صورة", basePrice = 12.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "88800022", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val sharedUrl = "https://cdn.example.com/shared_banner.png"
        val rows = listOf(
            listOf("الباركود", "الاسم", "رابط الصورة"),
            listOf("88800011", "منتج موجود أ", sharedUrl), // Policy: KEEP_EXISTING
            listOf("88800022", "منتج بدون صورة", sharedUrl), // Policy: needs download
            listOf("88800033", "منتج جديد 1", sharedUrl),
            listOf("88800044", "منتج جديد 2", sharedUrl),
        )
        val sheet = com.example.domain.excel.ParsedSheetData("Sheet1", rows.first(), rows, emptyList())
        val mappings = mapOf(
            0 to ProductImportField.PRIMARY_BARCODE,
            1 to ProductImportField.NAME,
            2 to ProductImportField.IMAGE_URL,
        )

        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals(existingPid, draft.rows[0].matchedExistingProductId)
        assertEquals(ExcelImageConflictPolicy.KEEP_EXISTING, draft.rows[0].imageConflictPolicy)
        assertEquals(noImgPid, draft.rows[1].matchedExistingProductId)

        val report = excelImport.commitReviewedImport(draft)
        assertEquals(2, report.insertedCount)
        assertEquals(1, report.updatedCount) // product noImgPid got an image even under SKIP policy!
        assertEquals(1, report.skippedCount) // existingPid kept old image
        assertEquals(3, report.imageDownloadSuccessCount)
        assertEquals(0, report.imageDownloadFailedCount)
        assertEquals(1, report.imageDownloadSkippedCount)
        assertEquals("Expected single deduplicated network download for concurrent shared URL", 1, networkCalls.get())

        val new1 = productRepo.findProductByExactBarcode("88800033")!!
        val new2 = productRepo.findProductByExactBarcode("88800044")!!
        assertNotEquals(new1.primaryImage!!.filePath, new2.primaryImage!!.filePath)
        assertTrue(File(new1.primaryImage!!.filePath).exists())
        assertTrue(File(new2.primaryImage!!.filePath).exists())
    }

    @Test
    fun `remote url validator blocks unsafe local hosts obfuscated ips userinfo and https downgrades`() = runBlocking {
        val unsafeUrls = listOf(
            "",
            "ftp://example.com/a.png",
            "file:///sdcard/a.png",
            "https://user:pass@cdn.example.com/a.png",
            "http://localhost/a.png",
            "http://sub.localhost/a.png",
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://printer.local/a.png",
            "http://127.0.0.1/a.png",
            "http://10.0.0.5/a.png",
            "http://172.16.4.2/a.png",
            "http://192.168.1.10/a.png",
            "http://169.254.169.254/latest/meta-data/",
            "http://[::1]/a.png",
            "http://2130706433/a.png",
            "http://0x7f000001/a.png",
            "http://127.1/a.png",
        )
        for (url in unsafeUrls) {
            val res = RemoteImageUrlValidator.validateSyntax(url)
            assertFalse("Expected URL to be blocked: $url", res.isValid)
        }

        assertTrue(RemoteImageUrlValidator.validateSyntax("https://cdn.example.com/products/img_01.jpg").isValid)

        // verifyHostSafe rejects DNS resolution to private IPs
        var threwSecurity = false
        try {
            RemoteImageUrlValidator.verifyHostSafe("evil-rebind.example.com") {
                arrayOf(InetAddress.getByAddress("evil-rebind.example.com", byteArrayOf(10, 0, 0, 1)))
            }
        } catch (_: SecurityUrlException) {
            threwSecurity = true
        }
        assertTrue("Expected SecurityUrlException when DNS resolves to 10.0.0.1", threwSecurity)

        // HTTPS -> HTTP downgrade rejected even on custom transport
        val validBytes = makeTestBitmapBytes()
        val downgradeDownloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { _, _, _, _ ->
                RemoteHttpResponse(200, "image/png", validBytes.size.toLong(), validBytes, "http://cdn.example.com/downgraded.png")
            },
        )
        val dlRes = downgradeDownloader.downloadAndVerifyBytes("https://cdn.example.com/secure.png")
        assertTrue(dlRes is RemoteImageBytesResult.Failure)
        assertEquals(RemoteImageFailureKind.BLOCKED_NETWORK, (dlRes as RemoteImageBytesResult.Failure).kind)

        // SVG content-type rejected even if bytes are non-empty
        val svgDownloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                val svg = "<svg xmlns=\"http://www.w3.org/2000/svg\"></svg>".toByteArray()
                RemoteHttpResponse(200, "image/svg+xml", svg.size.toLong(), svg, url)
            },
        )
        val svgRes = svgDownloader.downloadAndVerifyBytes("https://cdn.example.com/vector.svg")
        assertTrue(svgRes is RemoteImageBytesResult.Failure)
        assertEquals(RemoteImageFailureKind.UNSUPPORTED_FORMAT, (svgRes as RemoteImageBytesResult.Failure).kind)
    }

    @Test
    fun `foreign barcode conflict with IGNORE_NEW_BARCODE preserves foreign owner and links image to target product`() = runBlocking {
        val targetPid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "TGT-1", name = "منتج مستهدف", basePrice = 15.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "10101010", isPrimary = true)),
            emptyList(),
        ).getOrThrow()
        val foreignPid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "FGN-2", name = "منتج آخر", basePrice = 20.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "20202020", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val pngBytes = makeTestBitmapBytes(90, 90, Color.YELLOW, Bitmap.CompressFormat.PNG)
        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                RemoteHttpResponse(200, "image/png", pngBytes.size.toLong(), pngBytes, url)
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        val rows = listOf(
            listOf("الباركود", "باركود إضافي", "الاسم", "رابط الصورة"),
            listOf("10101010", "20202020", "منتج مستهدف", "https://cdn.example.com/target.png"),
        )
        val sheet = com.example.domain.excel.ParsedSheetData("Sheet1", rows.first(), rows, emptyList())
        val mappings = mapOf(
            0 to ProductImportField.PRIMARY_BARCODE,
            1 to ProductImportField.EXTRA_BARCODE,
            2 to ProductImportField.NAME,
            3 to ProductImportField.IMAGE_URL,
        )

        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals(ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT, draft.rows.single().conflictType)
        assertTrue(draft.rows.single().foreignConflictBarcodes.containsKey("20202020"))

        val resolved = draft.copy(
            rows = listOf(draft.rows.single().copy(newBarcodePolicy = ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE)),
        )
        val report = excelImport.commitReviewedImport(resolved)
        assertEquals(1, report.updatedCount)
        assertEquals(1, report.imageDownloadSuccessCount)

        // Foreign barcode still belongs exclusively to foreignPid and got NO image from targetPid's row
        val foreignAfter = productRepo.findProductByExactBarcode("20202020")!!
        assertEquals(foreignPid, foreignAfter.product.id)
        assertTrue(foreignAfter.images.isEmpty())

        // Target product received the downloaded image safely
        val targetAfter = db.productDao().getProductWithDetails(targetPid)!!
        assertEquals(1, targetAfter.images.size)
        assertTrue(File(targetAfter.primaryImage!!.filePath).exists())
    }

    private fun makeMinimalGifBytes(): ByteArray {
        // Minimal valid 1x1 red GIF89a
        return Base64.decode("R0lGODlhAQABAPAAAP8AAP///yH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==", Base64.DEFAULT)
    }

    private fun makeMinimalBmpBytes(): ByteArray {
        // Valid 2x2 24-bit uncompressed BMP
        val header = byteArrayOf(
            0x42, 0x4D, // BM
            70, 0, 0, 0, // file size 70 bytes
            0, 0, 0, 0,
            54, 0, 0, 0, // pixel offset 54
            40, 0, 0, 0, // BITMAPINFOHEADER size
            2, 0, 0, 0, // width = 2
            2, 0, 0, 0, // height = 2
            1, 0, // planes = 1
            24, 0, // 24 bpp
            0, 0, 0, 0, // BI_RGB
            16, 0, 0, 0, // image size
            0, 0, 0, 0,
            0, 0, 0, 0,
            0, 0, 0, 0,
            0, 0, 0, 0,
        )
        val pixels = byteArrayOf(
            0x00, 0x00, 0xFF.toByte(), 0x00, 0xFF.toByte(), 0x00, 0x00, 0x00,
            0xFF.toByte(), 0x00, 0x00, 0x00, 0xFF.toByte(), 0xFF.toByte(), 0x00, 0x00,
        )
        return header + pixels
    }

    @Test
    fun `multi format import supports jpg png webp gif bmp without relying on url extension`() = runBlocking {
        val jpgBytes = makeTestBitmapBytes(100, 80, Color.RED, Bitmap.CompressFormat.JPEG)
        val pngBytes = makeTestBitmapBytes(100, 80, Color.BLUE, Bitmap.CompressFormat.PNG)
        @Suppress("DEPRECATION")
        val webpBytes = makeTestBitmapBytes(100, 80, Color.GREEN, Bitmap.CompressFormat.WEBP)
        val gifBytes = makeMinimalGifBytes()
        val bmpBytes = makeMinimalBmpBytes()

        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                // Return generic application/octet-stream without file extensions in URL to prove magic-byte sniffing
                when {
                    url.endsWith("id=1") -> RemoteHttpResponse(200, "application/octet-stream", jpgBytes.size.toLong(), jpgBytes, url)
                    url.endsWith("id=2") -> RemoteHttpResponse(200, null, pngBytes.size.toLong(), pngBytes, url)
                    url.endsWith("id=3") -> RemoteHttpResponse(200, "application/octet-stream", webpBytes.size.toLong(), webpBytes, url)
                    url.endsWith("id=4") -> RemoteHttpResponse(200, "image/gif", gifBytes.size.toLong(), gifBytes, url)
                    url.endsWith("id=5") -> RemoteHttpResponse(200, "image/bmp", bmpBytes.size.toLong(), bmpBytes, url)
                    else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
                }
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        val rows = listOf(
            listOf("الباركود", "الاسم", "رابط الصورة"),
            listOf("550011", "صنف JPG", "https://cdn.example.com/photo?id=1"),
            listOf("550022", "صنف PNG", "https://cdn.example.com/photo?id=2"),
            listOf("550033", "صنف WEBP", "https://cdn.example.com/photo?id=3"),
            listOf("550044", "صنف GIF", "https://cdn.example.com/photo?id=4"),
            listOf("550055", "صنف BMP", "https://cdn.example.com/photo?id=5"),
        )
        val sheet = com.example.domain.excel.ParsedSheetData("Sheet1", rows.first(), rows, emptyList())
        val mappings = mapOf(
            0 to ProductImportField.PRIMARY_BARCODE,
            1 to ProductImportField.NAME,
            2 to ProductImportField.IMAGE_URL,
        )
        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        val report = excelImport.commitReviewedImport(draft)

        assertEquals(5, report.insertedCount)
        assertEquals(5, report.imageDownloadSuccessCount)
        assertEquals(0, report.imageDownloadFailedCount)

        val byBarcode = listOf(
            "550011" to ("jpg" to jpgBytes),
            "550022" to ("png" to pngBytes),
            "550033" to ("webp" to webpBytes),
            "550044" to ("gif" to gifBytes),
            "550055" to ("bmp" to bmpBytes),
        )
        for ((barcode, expected) in byBarcode) {
            val (expectedFmt, expectedRaw) = expected
            val prod = productRepo.findProductByExactBarcode(barcode)!!
            val img = prod.primaryImage!!
            assertTrue("Display file should exist for $barcode", File(img.filePath).exists())
            assertTrue("Original file should exist for $barcode", File(img.originalFilePath).exists())
            assertTrue("Thumbnail should exist for $barcode", File(img.thumbnailPath).exists())
            assertTrue(
                "Original untouched bytes should match $expectedFmt",
                expectedRaw.contentEquals(File(img.originalFilePath).readBytes()),
            )
            assertNotNull(
                "Active file for $expectedFmt must be decodable for display across UI/PDF",
                BitmapFactory.decodeFile(img.filePath),
            )
            val dl = report.imageDownloadRecords.first { it.barcode == barcode }
            assertEquals(expectedFmt, dl.detectedFormat)
            assertEquals(200, dl.httpStatusCode)
        }
    }

    @Test
    fun `diagnostic categorization distinguishes 403 404 429 5xx login wall corrupt bytes and partial success`() = runBlocking {
        @Suppress("DEPRECATION")
        val webpBytes = makeTestBitmapBytes(100, 90, Color.YELLOW, Bitmap.CompressFormat.WEBP)
        val calls403 = AtomicInteger(0)
        val calls429 = AtomicInteger(0)

        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                when (url) {
                    "https://cdn.example.com/ok.webp" ->
                        RemoteHttpResponse(200, "image/webp", webpBytes.size.toLong(), webpBytes, url)
                    "https://cdn.example.com/forbidden.jpg" -> {
                        calls403.incrementAndGet()
                        RemoteHttpResponse(403, "text/html", 9L, "Forbidden".toByteArray(), url)
                    }
                    "https://cdn.example.com/missing.jpg" ->
                        RemoteHttpResponse(404, "text/html", 9L, "Not Found".toByteArray(), url)
                    "https://cdn.example.com/rate_limited_then_ok.png" -> {
                        if (calls429.incrementAndGet() <= 2) {
                            RemoteHttpResponse(429, "text/plain", 0L, ByteArray(0), url)
                        } else {
                            RemoteHttpResponse(200, "image/webp", webpBytes.size.toLong(), webpBytes, url)
                        }
                    }
                    "https://cdn.example.com/server_down.jpg" ->
                        RemoteHttpResponse(503, "text/html", 0L, ByteArray(0), url)
                    "https://cdn.example.com/login_wall.jpg" ->
                        RemoteHttpResponse(
                            200,
                            "text/html",
                            60L,
                            "<html><body><form><input type=\"password\" name=\"pw\"></form></body></html>".toByteArray(),
                            "https://cdn.example.com/login",
                        )
                    "https://cdn.example.com/corrupt.jpg" ->
                        RemoteHttpResponse(200, "image/jpeg", 16L, ByteArray(16) { 0x12 }, url)
                    else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
                }
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        val rows = listOf(
            listOf("الباركود", "الاسم", "رابط الصورة"),
            listOf("660001", "منتج سليم WebP", "https://cdn.example.com/ok.webp"),
            listOf("660002", "منتج 403", "https://cdn.example.com/forbidden.jpg"),
            listOf("660003", "منتج 404", "https://cdn.example.com/missing.jpg"),
            listOf("660004", "منتج 429 يتعافى", "https://cdn.example.com/rate_limited_then_ok.png"),
            listOf("660005", "منتج 503", "https://cdn.example.com/server_down.jpg"),
            listOf("660006", "منتج يتطلب دخول", "https://cdn.example.com/login_wall.jpg"),
            listOf("660007", "منتج ملف تالف", "https://cdn.example.com/corrupt.jpg"),
        )
        val sheet = com.example.domain.excel.ParsedSheetData("Sheet1", rows.first(), rows, emptyList())
        val mappings = mapOf(
            0 to ProductImportField.PRIMARY_BARCODE,
            1 to ProductImportField.NAME,
            2 to ProductImportField.IMAGE_URL,
        )
        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        val report = excelImport.commitReviewedImport(draft)

        // All 7 products imported cleanly despite partial image failures
        assertEquals(7, report.insertedCount)
        assertEquals(2, report.imageDownloadSuccessCount) // ok.webp + 429 recovered
        assertEquals(5, report.imageDownloadFailedCount)
        assertEquals("HTTP 403 must not retry to bypass access controls", 1, calls403.get())

        val rec403 = report.failedImageDownloads.first { it.barcode == "660002" }
        assertEquals(403, rec403.httpStatusCode)
        assertEquals(RemoteImageFailureKind.HTTP_FORBIDDEN.arabicLabel, rec403.failureCategory)

        val rec404 = report.failedImageDownloads.first { it.barcode == "660003" }
        assertEquals(404, rec404.httpStatusCode)
        assertEquals(RemoteImageFailureKind.HTTP_NOT_FOUND.arabicLabel, rec404.failureCategory)

        val rec503 = report.failedImageDownloads.first { it.barcode == "660005" }
        assertEquals(503, rec503.httpStatusCode)
        assertEquals(RemoteImageFailureKind.HTTP_SERVER_ERROR.arabicLabel, rec503.failureCategory)

        val recLogin = report.failedImageDownloads.first { it.barcode == "660006" }
        assertEquals(RemoteImageFailureKind.HTTP_UNAUTHORIZED.arabicLabel, recLogin.failureCategory)
        assertTrue(recLogin.finalUrl.contains("/login"))

        val recCorrupt = report.failedImageDownloads.first { it.barcode == "660007" }
        assertEquals(RemoteImageFailureKind.CORRUPT_OR_NOT_IMAGE.arabicLabel, recCorrupt.failureCategory)

        // Verify XLSX error export carries structured diagnostic columns
        val errFile = excelExport.exportImageImportErrorsToXlsx(report.imageDownloadRecords, report.issues, "diag_errors.xlsx")
        val errSheet = excelImport.parseBytes(errFile.readBytes(), errFile.name).getOrThrow().sheets.first()
        assertTrue(errSheet.headers.contains("فئة التشخيص"))
        assertTrue(errSheet.headers.contains("رمز HTTP"))
    }

    @Test
    fun `retry failed skips succeeded downloads and all four fallback modes recover 403 images`() = runBlocking {
        val pngBytes = makeTestBitmapBytes(90, 90, Color.CYAN, Bitmap.CompressFormat.PNG)
        val jpgBytes = makeTestBitmapBytes(90, 90, Color.MAGENTA, Bitmap.CompressFormat.JPEG)
        @Suppress("DEPRECATION")
        val webpBytes = makeTestBitmapBytes(90, 90, Color.BLUE, Bitmap.CompressFormat.WEBP)

        val okFetchCount = AtomicInteger(0)
        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                when (url) {
                    "https://cdn.example.com/already_ok.png" -> {
                        okFetchCount.incrementAndGet()
                        RemoteHttpResponse(200, "image/png", pngBytes.size.toLong(), pngBytes, url)
                    }
                    "https://mirror.example.com/fixed.jpg" ->
                        RemoteHttpResponse(200, "image/jpeg", jpgBytes.size.toLong(), jpgBytes, url)
                    else -> RemoteHttpResponse(403, "text/html", 0L, ByteArray(0), url)
                }
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        val rows = listOf(
            listOf("الباركود", "الاسم", "رابط الصورة"),
            listOf("33300000", "منتج ناجح مسبقاً", "https://cdn.example.com/already_ok.png"),
            listOf("33300011", "منتج رفع يدوي", "https://blocked.example.com/p1.jpg"),
            listOf("33300022", "منتج مجلد محلي", "https://blocked.example.com/p2.jpg"),
            listOf("33300033", "منتج تعديل رابط", "https://blocked.example.com/p3.jpg"),
            listOf("33300044", "منتج API رسمي", "https://blocked.example.com/p4.jpg"),
        )
        val sheet = com.example.domain.excel.ParsedSheetData("Sheet1", rows.first(), rows, emptyList())
        val mappings = mapOf(
            0 to ProductImportField.PRIMARY_BARCODE,
            1 to ProductImportField.NAME,
            2 to ProductImportField.IMAGE_URL,
        )
        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        val report = excelImport.commitReviewedImport(draft)
        assertEquals(5, report.insertedCount)
        assertEquals(1, report.imageDownloadSuccessCount)
        assertEquals(4, report.imageDownloadFailedCount)
        assertEquals(1, okFetchCount.get())

        val countProductsBefore = db.productDao().getAllProductsOnce().size

        // Retry failed only -> must NOT re-download already_ok.png
        val retryRes = excelImport.retryFailedImageDownloads(batchId = report.downloadBatchId)
        assertEquals(4, retryRes.totalAttempted)
        assertEquals(1, okFetchCount.get())
        assertEquals(countProductsBefore, db.productDao().getAllProductsOnce().size)

        val dlManual = report.failedImageDownloads.first { it.barcode == "33300011" }
        val dlFolder = report.failedImageDownloads.first { it.barcode == "33300022" }
        val dlAltUrl = report.failedImageDownloads.first { it.barcode == "33300033" }
        val dlApi = report.failedImageDownloads.first { it.barcode == "33300044" }

        // Fallback 1: Manual upload bytes
        val manualRes = excelImport.fulfillDownloadFromLocalBytes(dlManual.id, webpBytes, "manual_picker").getOrThrow()
        assertEquals(ImageDownloadStatus.SUCCESS.name, manualRes.status)
        assertEquals("webp", manualRes.detectedFormat)

        // Fallback 2: Local folder batch match by barcode filename
        val folderRes = excelImport.matchAndImportFailedFromFolder(
            folderTreeUri = Uri.parse("content://mock/tree/images"),
            batchId = report.downloadBatchId,
            customCandidatesProvider = {
                listOf(LocalFolderImageCandidate("33300022.png") { pngBytes })
            },
        )
        assertEquals(1, folderRes.matchedCount)
        assertEquals(1, folderRes.succeededCount)
        assertEquals(dlFolder.id, folderRes.updatedRecords.single().id)

        // Fallback 3: Alternate URL replacement
        val altRes = excelImport.updateAndRetryFailedDownloadUrl(
            dlAltUrl.id,
            "https://mirror.example.com/fixed.jpg",
        ).getOrThrow()
        assertEquals(ImageDownloadStatus.SUCCESS.name, altRes.status)

        // Fallback 4: Authorized official HTTPS API (rejects non-HTTPS, succeeds with template + catalog JSON)
        var nonHttpsRejected = false
        try {
            excelImport.retryFailedUsingAuthorizedApi(
                OfficialApiImageConfig("http://api.supplier.com/img/{barcode}.png", "Authorization", "Bearer tok"),
                batchId = report.downloadBatchId,
            )
        } catch (_: IllegalArgumentException) {
            nonHttpsRejected = true
        }
        assertTrue("Expected official API fallback to reject insecure HTTP endpoint", nonHttpsRejected)

        val apiTransport = RemoteImageTransport { url, _, _, _ ->
            when (url) {
                "https://api.supplier.com/catalog.json" -> RemoteHttpResponse(
                    200,
                    "application/json",
                    64L,
                    """{"items":[{"barcode":"33300044","image_url":"https://api.supplier.com/media/33300044.webp"}]}""".toByteArray(),
                    url,
                )
                "https://api.supplier.com/media/33300044.webp" ->
                    RemoteHttpResponse(200, "image/webp", webpBytes.size.toLong(), webpBytes, url)
                else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
            }
        }
        val apiRes = excelImport.retryFailedUsingAuthorizedApi(
            config = OfficialApiImageConfig(
                endpointOrTemplate = "https://api.supplier.com/catalog.json",
                authHeaderName = "Authorization",
                authHeaderValue = "Bearer official-token",
            ),
            batchId = report.downloadBatchId,
            transportOverride = apiTransport,
        )
        assertEquals(1, apiRes.totalAttempted)
        assertEquals(1, apiRes.succeededCount)
        assertEquals(dlApi.id, apiRes.updatedRecords.single().id)

        // Final integrity assertions: 0 remaining failed downloads, 0 duplicated products, all 5 products have valid files!
        assertEquals(countProductsBefore, db.productDao().getAllProductsOnce().size)
        val batchFinal = db.productDao().getImageDownloadsByBatchOnce(report.downloadBatchId)
        assertTrue(batchFinal.none { it.status == ImageDownloadStatus.FAILED.name })
        for (bc in listOf("33300000", "33300011", "33300022", "33300033", "33300044")) {
            val prod = productRepo.findProductByExactBarcode(bc)!!
            assertEquals("Expected exactly 1 linked image for $bc", 1, prod.images.size)
            assertTrue(File(prod.primaryImage!!.filePath).exists())
        }
    }

    @Test
    fun `salla cdn 403 single and multiple urls across cdn salla sa and cdn files salla network recover via backend service and persist across restart`() = runBlocking {
        @Suppress("DEPRECATION")
        val webpBytes = makeTestBitmapBytes(110, 90, Color.GREEN, Bitmap.CompressFormat.WEBP)
        val pngBytes = makeTestBitmapBytes(110, 90, Color.MAGENTA, Bitmap.CompressFormat.PNG)
        val jpgBytes = makeTestBitmapBytes(110, 90, Color.BLUE, Bitmap.CompressFormat.JPEG)

        val direct403Calls = AtomicInteger(0)
        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                if (url.contains("salla")) {
                    direct403Calls.incrementAndGet()
                    RemoteHttpResponse(403, "text/html", 9L, "Forbidden".toByteArray(), url)
                } else {
                    RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
                }
            },
        )

        val backendCalls = AtomicInteger(0)
        val backendTransport = BackendHttpTransport { method, url, headers, bodyJson, _, _, _ ->
            if (method == "POST" && url == "https://sync.merchant.example/api/images/fetch-batch") {
                backendCalls.incrementAndGet()
                assertEquals("Bearer secret-session-token", headers["Authorization"])
                val reqObj = JSONObject(bodyJson ?: "{}")
                val items = reqObj.getJSONArray("images")
                val resArr = JSONArray()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val dlId = item.getLong("id")
                    val imgUrl = item.getString("url")
                    val (rawBytes, fmt) = when {
                        imgUrl.contains("cdn.files.salla.network") -> pngBytes to "png"
                        imgUrl.endsWith(".jpg") -> jpgBytes to "jpg"
                        else -> webpBytes to "webp"
                    }
                    resArr.put(
                        JSONObject().apply {
                            put("id", dlId)
                            put("url", imgUrl)
                            put("ok", true)
                            put("statusCode", 200)
                            put("finalUrl", imgUrl)
                            put("detectedFormat", fmt)
                            put("base64Data", Base64.encodeToString(rawBytes, Base64.NO_WRAP))
                        },
                    )
                }
                val payload = JSONObject().put("results", resArr).toString().toByteArray()
                RemoteHttpResponse(200, "application/json", payload.size.toLong(), payload, url)
            } else {
                RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
            }
        }
        val backendService = BackendImageSyncService(backendTransport)
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader, backendService)

        // Scenario 1 (single 403 cdn.salla.sa URL), Scenario 2 (multiple cdn.salla.sa URLs), Scenario 3 (cdn.files.salla.network)
        val xlsxBytes = buildXlsxBytes(
            headers = listOf("GTIN", "أسم المنتج", "صورة المنتج"),
            rows = listOf(
                listOf("6280000000011", "منظف واجهات فردي 403", "https://cdn.salla.sa/xyz/single_403.webp"),
                listOf("6280000000022", "قهوة مختصة متعددة من سلة", "https://cdn.salla.sa/xyz/multi_1.jpg\nhttps://cdn.salla.sa/xyz/multi_2.webp"),
                listOf("6280000000033", "عطر شبكة ملفات سلة", "https://cdn.files.salla.network/hash/perfume_cover.png"),
            ),
        )
        val sheet = excelImport.parseBytes(xlsxBytes, "salla_403.xlsx").getOrThrow().sheets.single()
        val mappings = excelImport.suggestMappings(sheet.headers, sheet.rows.drop(1))
        val draft = excelImport.buildPreImportReviewDraft(sheet, mappings, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        val initialReport = excelImport.commitReviewedImport(draft)

        assertEquals(3, initialReport.totalProductsProcessed)
        assertEquals(4, initialReport.totalImageUrlsCount) // 1 + 2 + 1
        assertEquals(0, initialReport.imageDownloadSuccessCount)
        assertEquals(4, initialReport.imageDownloadFailedCount)
        // Direct HTTP 403 must NOT retry multiple times per URL (4 unique URLs -> 4 single direct attempts)
        assertEquals(4, direct403Calls.get())

        // Server-side Companion Backend recovery
        val serverConfig = BackendImageSyncService.BackendServerConfig(
            backendBaseUrl = "https://sync.merchant.example/",
            backendAccessToken = "secret-session-token",
        )
        val recoveryRes = excelImport.retryFailedViaBackendService(
            config = serverConfig,
            batchId = initialReport.downloadBatchId,
        )
        assertEquals(4, recoveryRes.totalAttempted)
        assertEquals(4, recoveryRes.succeededCount)
        assertEquals(0, recoveryRes.failedCount)
        assertEquals(1, backendCalls.get())

        // Verify AppSettings never stores secret tokens (schema holds only backendServiceUrl)
        settingsRepo.saveSettings(settingsRepo.getSettingsOnce().copy(backendServiceUrl = "https://sync.merchant.example"))
        assertEquals("https://sync.merchant.example", settingsRepo.getSettingsOnce().backendServiceUrl)

        // Simulate App / Database Restart
        db.close()
        db = openFileDatabase()
        productRepo = ProductRepository(db, mediaStorage)

        val p1 = productRepo.findProductByExactBarcode("6280000000011")!!
        val p2 = productRepo.findProductByExactBarcode("6280000000022")!!
        val p3 = productRepo.findProductByExactBarcode("6280000000033")!!

        assertEquals(1, p1.images.size)
        assertEquals(2, p2.images.size) // Both multi_1.jpg & multi_2.webp persisted!
        assertEquals(1, p3.images.size)
        listOf(p1, p2, p3).forEach { prod ->
            prod.images.forEach { img ->
                assertTrue(File(img.filePath).exists())
                assertTrue(File(img.originalFilePath).exists())
                assertTrue(File(img.thumbnailPath).exists())
                assertTrue(ImageService.resolveProductImageStateless(img, preferThumbnail = false) is ImageResolution.Available)
            }
        }
        assertNotEquals(p2.images[0].filePath, p2.images[1].filePath)
    }

    @Test
    fun `salla excel maps No to IGNORE ignores empty barcode preserves GTIN imports product without GTIN and matches strict local GTIN folder`() = runBlocking {
        val jpgBytes = makeTestBitmapBytes(100, 80, Color.RED, Bitmap.CompressFormat.JPEG)
        @Suppress("DEPRECATION")
        val webpBytes = makeTestBitmapBytes(100, 80, Color.CYAN, Bitmap.CompressFormat.WEBP)
        val pngBytes = makeTestBitmapBytes(100, 80, Color.BLUE, Bitmap.CompressFormat.PNG)

        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ ->
                when (url) {
                    "https://cdn.salla.sa/ok/no_gtin_item.webp" ->
                        RemoteHttpResponse(200, "image/webp", webpBytes.size.toLong(), webpBytes, url)
                    "https://cdn.salla.sa/blocked/multi_folder.jpg" ->
                        RemoteHttpResponse(403, "text/html", 0L, ByteArray(0), url)
                    else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
                }
            },
        )
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader)

        // Exact Salla export header layout: empty "الباركود", populated "GTIN", plus "No." row numbers & no-GTIN product
        val xlsxBytes = buildXlsxBytes(
            headers = listOf("No.", "أسم المنتج", "الباركود", "GTIN", "صورة المنتج"),
            rows = listOf(
                listOf("1", "بخور ملكي فاخر", "", "06281000100012", "https://cdn.salla.sa/blocked/multi_folder.jpg"),
                listOf("2", "منتج بدون باركود GTIN", "", "", "https://cdn.salla.sa/ok/no_gtin_item.webp"),
                listOf("3", "شاحن سريع برقم علمي", "", "6.281000100029E+12", ""),
            ),
        )
        val sheet = excelImport.parseBytes(xlsxBytes, "salla_export.xlsx").getOrThrow().sheets.single()
        val sampleSlice = sheet.rows.drop(1)
        val suggested = excelImport.suggestMappings(sheet.headers, sampleSlice)

        assertEquals(ProductImportField.IGNORE, suggested[0]) // "No." MUST be ignored (never INTERNAL_CODE!)
        assertEquals(ProductImportField.NAME, suggested[1]) // "أسم المنتج"
        assertEquals(ProductImportField.IGNORE, suggested[2]) // Empty "الباركود" must NOT shadow populated GTIN
        assertEquals(ProductImportField.PRIMARY_BARCODE, suggested[3]) // "GTIN"
        assertEquals(ProductImportField.IMAGE_URL, suggested[4]) // "صورة المنتج"

        val draft = excelImport.buildPreImportReviewDraft(sheet, suggested, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals("06281000100012", draft.rows[0].primaryBarcode)
        assertEquals("", draft.rows[1].primaryBarcode)
        assertEquals("6281000100029", draft.rows[2].primaryBarcode)
        assertFalse(draft.rows[0].internalCode == "1") // "No." was ignored!

        val report = excelImport.commitReviewedImport(draft)
        assertEquals(3, report.insertedCount)
        assertEquals(1, report.productsWithoutGtinCount)
        assertEquals(1, report.imageDownloadSuccessCount)
        assertEquals(1, report.imageDownloadFailedCount)

        // Product without GTIN imported cleanly with auto ProductID, empty barcode list, and saved image
        val allAfter = db.productDao().getAllProductsWithDetailsOnce()
        val noGtinProd = allAfter.first { it.product.name == "منتج بدون باركود GTIN" }
        assertTrue(noGtinProd.barcodes.isEmpty())
        assertEquals(1, noGtinProd.images.size)
        assertTrue(File(noGtinProd.primaryImage!!.filePath).exists())

        // Verify MISSING_BARCODE filter & Product List query behavior cleanly via ProductsViewModel.applyFiltersAndSort
        val missingBarcodeFiltered = ProductsViewModel.applyFiltersAndSort(
            all = allAfter,
            repository = productRepo,
            query = "",
            filter = ProductFilterMode.MISSING_BARCODE,
        )
        assertEquals(listOf("منتج بدون باركود GTIN"), missingBarcodeFiltered.map { it.product.name })
        assertTrue(ImageService.resolveProductImageStateless(missingBarcodeFiltered.single().primaryImage, preferThumbnail = true) is ImageResolution.Available)

        val searchedByGtin = ProductsViewModel.applyFiltersAndSort(
            all = allAfter,
            repository = productRepo,
            query = "06281000100012",
            filter = ProductFilterMode.ALL,
        )
        assertEquals(1, searchedByGtin.size)
        assertEquals("بخور ملكي فاخر", searchedByGtin.single().product.name)

        // Strict local GTIN folder fallback:
        // - Multiple images matching 06281000100012 (_1.jpg, _2.webp) BOTH link to Product 1
        // - Image for GTIN-less / ambiguous product name ("بخور.png", "منتج عام.jpg") MUST NOT guess-match!
        val folderRes = excelImport.matchAndImportFailedFromFolder(
            folderTreeUri = Uri.parse("content://mock/tree/salla_gtin_photos"),
            batchId = report.downloadBatchId,
            customCandidatesProvider = {
                listOf(
                    LocalFolderImageCandidate("06281000100012.jpg") { jpgBytes },
                    LocalFolderImageCandidate("06281000100012_2.webp") { webpBytes },
                    LocalFolderImageCandidate("6281000100029.png") { pngBytes }, // matches prod #3 even though it had no URL!
                    LocalFolderImageCandidate("بخور.png") { pngBytes }, // ambiguous product-name-only file -> ignored
                )
            },
        )
        assertEquals(2, folderRes.matchedCount) // prod #1 (failed URL) + prod #3 (GTIN with no URL)
        assertEquals(3, folderRes.succeededCount) // 2 images for prod #1 + 1 for prod #3
        assertEquals(1, folderRes.extraLinkedCount) // 06281000100012_2.webp
        assertEquals(listOf("بخور.png"), folderRes.unmatchedFiles)

        val prod1AfterFolder = productRepo.findProductByExactBarcode("06281000100012")!!
        assertEquals(2, prod1AfterFolder.images.size)
        val prod3AfterFolder = productRepo.findProductByExactBarcode("6281000100029")!!
        assertEquals(1, prod3AfterFolder.images.size)
    }

    @Test
    fun `salla oauth catalog sync and export render verified salla images in both PDF and Excel`() = runBlocking {
        @Suppress("DEPRECATION")
        val greenWebp = makeTestBitmapBytes(120, 90, Color.GREEN, Bitmap.CompressFormat.WEBP)
        val blueJpg = makeTestBitmapBytes(120, 90, Color.BLUE, Bitmap.CompressFormat.JPEG)

        // Seed existing product with blocked 403 Salla CDN image record
        val pid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "SKU-SL-900", name = "مبخرة سلة الذكية", basePrice = 149.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "6289999000900", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val downloader = RemoteImageDownloader(
            mediaStorage = mediaStorage,
            transport = { url, _, _, _ -> RemoteHttpResponse(403, "text/html", 0L, ByteArray(0), url) },
        )
        val backendTransport = BackendHttpTransport { method, url, _, _, _, _, _ ->
            when {
                method == "GET" && url.endsWith("/api/salla/config-status") -> {
                    val b = JSONObject(mapOf("configured" to true, "connected" to true, "redirectUriConfigured" to true, "expiresAt" to 9999999999L)).toString().toByteArray()
                    RemoteHttpResponse(200, "application/json", b.size.toLong(), b, url)
                }
                method == "GET" && url.endsWith("/api/salla/auth/url") -> {
                    val b = JSONObject(mapOf("authorizeUrl" to "https://accounts.salla.sa/oauth2/auth?client_id=test&state=csrf123")).toString().toByteArray()
                    RemoteHttpResponse(200, "application/json", b.size.toLong(), b, url)
                }
                method == "GET" && url.contains("/api/salla/products") -> {
                    val body = JSONObject().apply {
                        put(
                            "products",
                            JSONArray().put(
                                JSONObject().apply {
                                    put("sallaProductId", 9001L)
                                    put("name", "مبخرة سلة الذكية")
                                    put("sku", "SKU-SL-900")
                                    put("gtin", "6289999000900")
                                    put("barcode", "6289999000900")
                                    put(
                                        "imageUrls",
                                        JSONArray()
                                            .put("https://cdn.salla.sa/store/main.webp")
                                            .put("https://cdn.files.salla.network/store/alt.jpg"),
                                    )
                                    put(
                                        "downloadedImages",
                                        JSONArray()
                                            .put(
                                                JSONObject().apply {
                                                    put("url", "https://cdn.salla.sa/store/main.webp")
                                                    put("ok", true)
                                                    put("statusCode", 200)
                                                    put("detectedFormat", "webp")
                                                    put("base64Data", Base64.encodeToString(greenWebp, Base64.NO_WRAP))
                                                },
                                            )
                                            .put(
                                                JSONObject().apply {
                                                    put("url", "https://cdn.files.salla.network/store/alt.jpg")
                                                    put("ok", true)
                                                    put("statusCode", 200)
                                                    put("detectedFormat", "jpg")
                                                    put("base64Data", Base64.encodeToString(blueJpg, Base64.NO_WRAP))
                                                },
                                            ),
                                    )
                                },
                            ),
                        )
                    }.toString().toByteArray()
                    RemoteHttpResponse(200, "application/json", body.size.toLong(), body, url)
                }
                else -> RemoteHttpResponse(404, null, 0L, ByteArray(0), url)
            }
        }
        val backendService = BackendImageSyncService(backendTransport)
        val excelImport = ExcelImportEngine(context, db, mediaStorage, downloader, backendService)
        val cfg = BackendImageSyncService.BackendServerConfig("https://sync.merchant.example", "tok")

        val status = backendService.getSallaConfigStatus(cfg).getOrThrow()
        assertTrue(status.configured && status.connected)
        assertTrue(backendService.getSallaAuthorizeUrl(cfg).getOrThrow().startsWith("https://accounts.salla.sa/"))

        val syncReport = excelImport.syncSallaCatalogViaBackend(cfg)
        assertEquals(1, syncReport.fetchedProductsCount)
        assertEquals(1, syncReport.matchedProductsCount)
        assertEquals(2, syncReport.linkedImagesCount)
        assertEquals(0, syncReport.failedImagesCount)

        val syncedProduct = db.productDao().getProductWithDetails(pid)!!
        assertEquals(2, syncedProduct.images.size)

        // Scenario 9a: Verify exported Excel (.xlsx) actually embeds real media image bytes!
        val exportedXlsx = excelExport.exportProductsToXlsx(
            products = listOf(syncedProduct),
            fileName = "salla_synced_export.xlsx",
            includeImages = true,
        )
        assertTrue(exportedXlsx.exists() && exportedXlsx.length() > 0)
        val zipEntries = mutableListOf<String>()
        ZipInputStream(exportedXlsx.inputStream()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                zipEntries.add(e.name)
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
        assertTrue("Expected embedded product image inside XLSX xl/media/", zipEntries.any { it.startsWith("xl/media/image") })

        // Scenario 9b: Verify rendered PDF draws the imported green product pixels!
        val repId = reportRepo.createEmptyReport(customTitle = "تقرير سلة بالصور")
        reportRepo.addProductToReport(repId, syncedProduct)
        val repDetails = reportRepo.getReportOnce(repId)!!
        val renderedBitmaps = mutableListOf<Bitmap>()
        val recPdfGen = PdfGeneratorEngine(
            context,
            mediaStorage,
            PdfSessionFactory {
                object : PdfSession {
                    override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                        val b = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                        renderedBitmaps.add(b)
                        return Canvas(b)
                    }
                    override fun endPage() = Unit
                    override fun writeTo(outputStream: java.io.OutputStream) = Unit
                    override fun close() = Unit
                }
            },
        )
        recPdfGen.generateReportPdf(repDetails, settingsRepo.getSettingsOnce(), outputFileName = "salla_sync_report.pdf")
        assertTrue(
            "Expected synced Salla green image pixels inside rendered PDF",
            renderedBitmaps.any { bmp ->
                (0 until bmp.height step 4).any { y ->
                    (0 until bmp.width step 4).any { x -> bmp.getPixel(x, y) == Color.GREEN }
                }
            },
        )
    }
}
