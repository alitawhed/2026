package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.di.AppContainer
import com.example.ui.theme.ReportManagerTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app_name string matches Arabic app identity`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("مدير التقارير", appName)
    }

    @Test
    fun `dashboard renders Arabic identity KPIs and navigation tabs without fake products`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val container = AppContainer(context)
        runBlocking {
            AppDatabase.ensureSeeded(container.database)
        }

        composeRule.setContent {
            ReportManagerTheme {
                ReportManagerApp(container = container)
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithText("مدير التقارير").assertIsDisplayed()
        composeRule.onNodeWithText("المهندس علي توحيد", substring = true).assertDoesNotExist()
        composeRule.onNodeWithText("00966573928022", substring = true).assertDoesNotExist()
        composeRule.onNodeWithText("+966573928022", substring = true).assertDoesNotExist()

        // Navigate across primary tabs
        composeRule.onNodeWithTag("nav_products").performClick()
        composeRule.waitUntil(5000) {
            runCatching { composeRule.onNodeWithTag("products_search_field").assertIsDisplayed() }.isSuccess
        }

        composeRule.onNodeWithTag("nav_templates").performClick()
        composeRule.waitUntil(5000) {
            runCatching { composeRule.onNodeWithText("مكتبة قوالب التقارير").assertIsDisplayed() }.isSuccess
        }

        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.waitUntil(5000) {
            runCatching { composeRule.onNodeWithTag("settings_save_btn").assertIsDisplayed() }.isSuccess
        }
    }
}
