package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.TemplateDefaults.toDomainModel
import com.example.data.local.TemplateDefaults.toEntity
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ReportEntity
import com.example.data.local.entity.ReportItemEntity
import com.example.data.repository.DuplicateCountAction
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.repository.SettingsRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.formatting.AppNumericSection
import com.example.domain.formatting.NumberFormatEngine
import com.example.domain.formatting.NumberFormatEngine.toNumberFormatSpec
import com.example.domain.formatting.NumberFormatEngine.withNumberFormatSpec
import com.example.domain.formatting.NumberFormatSpec
import com.example.domain.formatting.ProductsNumericConfig
import com.example.domain.model.ColumnType
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.TemplateKind
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.ui.components.formatCurrencyValue
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipFile

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DecimalFormattingSystemTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var inventoryRepo: InventoryRepository
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var excelExport: ExcelExportEngine
    private lateinit var excelImport: ExcelImportEngine

    private class CapturingPdfSession(
        val capturedCanvasCalls: MutableList<String>,
    ) : PdfSession {
        var pageCount = 0
            private set

        override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
            pageCount++
            return object : Canvas() {
                override fun drawText(text: String, x: Float, y: Float, paint: Paint) {
                    capturedCanvasCalls.add(text)
                }

                override fun drawText(text: String, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    capturedCanvasCalls.add(text.substring(start, end))
                }

                override fun drawText(text: CharSequence, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    capturedCanvasCalls.add(text.subSequence(start, end).toString())
                }
            }
        }

        override fun endPage() = Unit

        override fun writeTo(outputStream: OutputStream) {
            val minimalPdf = "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count $pageCount/Kids[]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
            outputStream.write(minimalPdf.toByteArray(Charsets.US_ASCII))
        }

        override fun close() = Unit
    }

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        inventoryRepo = InventoryRepository(db)
        settingsRepo = SettingsRepository(db)
        excelExport = ExcelExportEngine(mediaStorage)
        excelImport = ExcelImportEngine(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `central NumberFormatEngine handles 0 to 6 decimals, auto mode, trailing zero strip, and test matrix`() {
        val sampleValues = listOf(1.0, 20.0, 15.5, 15.25, 120.0)

        // 0 decimals: 1, 20, 16, 15, 120
        val spec0 = NumberFormatSpec(decimalPlaces = 0, autoDecimals = false, stripTrailingZeros = false)
        assertEquals(listOf("1", "20", "16", "15", "120"), sampleValues.map { NumberFormatEngine.formatDouble(it, spec0) })

        // 1 decimal: 1.0, 20.0, 15.5, 15.3, 120.0
        val spec1 = NumberFormatSpec(decimalPlaces = 1, autoDecimals = false, stripTrailingZeros = false)
        assertEquals(listOf("1.0", "20.0", "15.5", "15.3", "120.0"), sampleValues.map { NumberFormatEngine.formatDouble(it, spec1) })

        // 2 decimals: 1.00, 20.00, 15.50, 15.25, 120.00
        val spec2 = NumberFormatSpec(decimalPlaces = 2, autoDecimals = false, stripTrailingZeros = false)
        assertEquals(listOf("1.00", "20.00", "15.50", "15.25", "120.00"), sampleValues.map { NumberFormatEngine.formatDouble(it, spec2) })

        // 3..6 decimals on 20.0
        assertEquals("20.000", NumberFormatEngine.formatDouble(20.0, spec2.copy(decimalPlaces = 3)))
        assertEquals("20.0000", NumberFormatEngine.formatDouble(20.0, spec2.copy(decimalPlaces = 4)))
        assertEquals("20.00000", NumberFormatEngine.formatDouble(20.0, spec2.copy(decimalPlaces = 5)))
        assertEquals("20.000000", NumberFormatEngine.formatDouble(20.0, spec2.copy(decimalPlaces = 6)))

        // Auto mode according to original value
        val specAuto = NumberFormatSpec(decimalPlaces = 2, autoDecimals = true, stripTrailingZeros = false)
        assertEquals(listOf("1", "20", "15.5", "15.25", "120"), sampleValues.map { NumberFormatEngine.formatDouble(it, specAuto) })

        // Independent toggle: strip trailing zeros on fixed 2 decimals
        val spec2Strip = NumberFormatSpec(decimalPlaces = 2, autoDecimals = false, stripTrailingZeros = true)
        assertEquals(listOf("1", "20", "15.5", "15.25", "120"), sampleValues.map { NumberFormatEngine.formatDouble(it, spec2Strip) })

        // Negative zero, NaN, and thousands grouping
        assertEquals("0", NumberFormatEngine.formatDouble(-0.0, spec0))
        assertEquals("0.00", NumberFormatEngine.formatDouble(-0.0, spec2))
        assertEquals("1,250.50", NumberFormatEngine.formatDouble(1250.5, spec2))

        // formatCurrencyValue in CommonComponents uses spec cleanly
        assertEquals("20.000 ر.س", formatCurrencyValue(20.0, "ر.س", NumberFormatSpec(decimalPlaces = 3)))
        assertEquals("1 ر.س", formatCurrencyValue(1.0, "ر.س", NumberFormatSpec(decimalPlaces = 0)))
    }

    @Test
    fun `default specs match requirements across inventory, reports, and products`() {
        val invCols = InventoryColumnDefaults.defaultColumns()
        val invQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(invCols, "quantity")
        val invBaseQtySpec = NumberFormatEngine.resolveInventoryColumnSpec(invCols, "base_qty")
        val invFactorSpec = NumberFormatEngine.resolveInventoryColumnSpec(invCols, "conversion_factor")

        assertEquals(0, invQtySpec.decimalPlaces)
        assertFalse(invQtySpec.autoDecimals)
        assertEquals(0, invBaseQtySpec.decimalPlaces)
        assertTrue(invFactorSpec.autoDecimals)
        assertTrue(invFactorSpec.stripTrailingZeros)

        val detailedTemplate = TemplateDefaults.buildBuiltInTemplates()
            .first { it.templateKind == TemplateKind.DETAILED_REPORT.name }
        val repCols = TemplateDefaults.decodeColumns(detailedTemplate.columnsConfigJson)
        val repQtySpec = NumberFormatEngine.resolveReportQuantitySpec(repCols)
        val repPriceSpec = NumberFormatEngine.resolveReportPriceSpec(repCols)
        val repTotalSpec = NumberFormatEngine.resolveReportTotalSpec(repCols)
        val repPctSpec = NumberFormatEngine.resolveReportPercentageSpec(repCols)

        assertEquals(0, repQtySpec.decimalPlaces)
        assertFalse(repQtySpec.autoDecimals)
        assertEquals(2, repPriceSpec.decimalPlaces)
        assertEquals(2, repTotalSpec.decimalPlaces)
        assertEquals(1, repPctSpec.decimalPlaces)
        assertTrue(repPctSpec.stripTrailingZeros)

        val prodCfg = ProductsNumericConfig()
        assertEquals(0, prodCfg.quantityFormat.decimalPlaces)
        assertEquals(2, prodCfg.priceFormat.decimalPlaces)
        assertTrue(prodCfg.conversionFactorFormat.autoDecimals)
    }

    @Test
    fun `per-column and per-section isolation keeps inventory, reports, and products completely independent`() = runBlocking {
        // Configure Products decimal settings independently
        val customProductsCfg = ProductsNumericConfig(
            quantityFormat = NumberFormatSpec(decimalPlaces = 4),
            priceFormat = NumberFormatSpec(decimalPlaces = 3),
        )
        settingsRepo.saveProductsNumericConfig(customProductsCfg)

        // Create Inventory session + customize Inventory quantity column to 1 decimal ONLY (base_qty stays 0)
        inventoryRepo.createSession("جرد مستقل", "").getOrThrow()
        val customInvCols = InventoryColumnDefaults.defaultColumns().map { col ->
            if (col.columnKey == "quantity") col.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 1))
            else col
        }
        val invConfig = InventorySheetConfig(columns = customInvCols)
        settingsRepo.saveInventoryConfig(invConfig)

        // Create Report 1 (qty = 0 decimals, price = 2 decimals) and Report 2 (qty = 3 decimals, price = 0 decimals)
        val report1Id = reportRepo.createEmptyReport(customTitle = "تقرير 1")
        val report2Id = reportRepo.createEmptyReport(customTitle = "تقرير 2")

        val rep2Cols = db.reportDao().getReportWithDetails(report2Id)!!.sortedColumns.map { c ->
            val model = c.toDomainModel()
            when (model.columnKey) {
                "qty" -> model.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 3))
                "price" -> model.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 0))
                else -> model
            }
        }
        reportRepo.replaceReportColumns(report2Id, rep2Cols)

        // Read all three sections back
        val storedInvCfg = settingsRepo.getInventoryConfigOnce()
        val storedProdCfg = settingsRepo.getProductsNumericConfigOnce()
        val rep1Cols = db.reportDao().getReportWithDetails(report1Id)!!.sortedColumns.map { it.toDomainModel() }
        val rep2ColsLoaded = db.reportDao().getReportWithDetails(report2Id)!!.sortedColumns.map { it.toDomainModel() }

        // Inventory quantity changed to 1, base_qty untouched at 0
        assertEquals(1, NumberFormatEngine.resolveInventoryColumnSpec(storedInvCfg.columns, "quantity").decimalPlaces)
        assertEquals(0, NumberFormatEngine.resolveInventoryColumnSpec(storedInvCfg.columns, "base_qty").decimalPlaces)

        // Report 1 untouched (qty = 0, price = 2)
        assertEquals(0, NumberFormatEngine.resolveReportQuantitySpec(rep1Cols).decimalPlaces)
        assertEquals(2, NumberFormatEngine.resolveReportPriceSpec(rep1Cols).decimalPlaces)

        // Report 2 independent (qty = 3, price = 0, total untouched at 2)
        assertEquals(3, NumberFormatEngine.resolveReportQuantitySpec(rep2ColsLoaded).decimalPlaces)
        assertEquals(0, NumberFormatEngine.resolveReportPriceSpec(rep2ColsLoaded).decimalPlaces)
        assertEquals(2, NumberFormatEngine.resolveReportTotalSpec(rep2ColsLoaded).decimalPlaces)

        // Products independent (qty = 4, price = 3)
        assertEquals(4, storedProdCfg.quantityFormat.decimalPlaces)
        assertEquals(3, storedProdCfg.priceFormat.decimalPlaces)
    }

    @Test
    fun `raw values remain unrounded in database while display rounds cleanly without mutating precision`() = runBlocking {
        val sid = inventoryRepo.createSession("جرد الدقة الكاملة", "").getOrThrow()
        val pid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "PREC-1", name = "منتج كسور", basePrice = 12.345),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "777000111", isPrimary = true)),
            emptyList(),
        ).getOrThrow()
        val p = db.productDao().getProductWithDetails(pid)!!

        inventoryRepo.recordCountedItem(
            sessionId = sid,
            product = p,
            scannedBarcode = "777000111",
            barcodeType = "CODE_128",
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 15.25,
            notes = "",
            duplicateAction = DuplicateCountAction.REPLACE_EXISTING,
        ).getOrThrow()

        // Default inventory qty display is 0 decimals -> shows "15", while DB preserves exact 15.25
        val session = db.inventoryDao().getSessionWithDetails(sid)!!
        assertEquals(15.25, session.items.first().countedQty, 0.000001)
        val zeroQtyCol = InventoryColumnDefaults.defaultColumns().first { it.columnKey == "quantity" }
        assertEquals("15", NumberFormatEngine.formatDouble(session.items.first().countedQty, zeroQtyCol))

        // Switching column to 2 decimals reveals exact 15.25 again
        val twoQtyCol = zeroQtyCol.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 2))
        assertEquals("15.25", NumberFormatEngine.formatDouble(session.items.first().countedQty, twoQtyCol))
    }

    @Test
    fun `report and inventory PDF rendering match screen formatting across single and multiple pages`() = runBlocking {
        val quantities = listOf(1.0, 20.0, 15.5, 15.25, 120.0)
        // Add extra rows to force multiple PDF pages
        val products = (0 until 32).map { idx ->
            val pid = productRepo.createOrUpdateProduct(
                ProductEntity(
                    internalCode = "P-${idx + 1}",
                    name = "منتج اختبار رقم ${idx + 1}",
                    basePrice = 10.0 + idx * 0.5,
                ),
                listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "62810000${1000 + idx}", isPrimary = true)),
                emptyList(),
            ).getOrThrow()
            db.productDao().getProductWithDetails(pid)!!
        }

        // 1. Report test: qty=1, 20, 15.5, 15.25, 120.0 using Detailed template (includes discount column)
        val detailedTpl = TemplateDefaults.buildBuiltInTemplates()
            .first { it.templateKind == TemplateKind.DETAILED_REPORT.name }
        val detailedTplId = db.templateDao().getAllTemplatesOnce()
            .first { it.templateKind == detailedTpl.templateKind }.id
        val reportId = reportRepo.createEmptyReport(templateId = detailedTplId, customTitle = "تقرير اختبار المنازل")
        products.forEachIndexed { idx, prod ->
            val q = quantities[idx % quantities.size]
            reportRepo.addProductToReport(reportId, prod)
            val details = db.reportDao().getReportWithDetails(reportId)!!
            val lastItem = details.sortedItems.last().item
            reportRepo.updateReportItem(lastItem.copy(quantity = q, unitPrice = 15.5, discountPercent = 10.0))
        }
        val fullReport = db.reportDao().getReportWithDetails(reportId)!!
        val settings = settingsRepo.getSettingsOnce()

        // Run PDF with default settings (qty=0 decimals, price=2, total=2, discount=1)
        val drawnCanvas = mutableListOf<String>()
        val drawnCells = mutableListOf<String>()
        val pdfEngine = PdfGeneratorEngine(
            context = context,
            mediaStorage = mediaStorage,
            sessionFactory = object : PdfSessionFactory {
                override fun create() = CapturingPdfSession(drawnCanvas)
            },
        ).apply {
            drawnCellTextObserver = { drawnCells.add(it) }
        }

        val resDefault = pdfEngine.generateReportPdf(fullReport, settings, "report_default_decimals")
        assertTrue(resDefault.pageCount >= 2)
        // Qty 1.0 MUST be formatted as "1" (never "1.00") when qty decimalPlaces=0
        assertTrue(drawnCells.contains("1"))
        assertTrue(drawnCells.contains("20"))
        assertFalse(drawnCells.contains("1.00"))
        // Price 15.5 must be formatted with 2 decimals: "15.50 ر.س" or "15.50"
        assertTrue(drawnCells.any { it.startsWith("15.50") })
        // Discount 10.0 with default 1 + stripTrailingZeros=true -> "10%"
        assertTrue(drawnCells.contains("10%"))

        // Check cell text resolver matches ReportEditorScreen logic
        val qtyCol0 = fullReport.sortedColumns.map { it.toDomainModel() }.first { it.columnKey == "qty" }
        assertEquals("1", pdfEngine.resolveCellText(fullReport.sortedItems[0], qtyCol0, "2026/11/21", "ر.س"))
        assertEquals("20", pdfEngine.resolveCellText(fullReport.sortedItems[1], qtyCol0, "2026/11/21", "ر.س"))

        // Change Report qty column to 2 decimals & discount to 3 decimals -> regenerate PDF
        val updatedReportCols = fullReport.sortedColumns.map { col ->
            val m = col.toDomainModel()
            when (m.columnKey) {
                "qty" -> m.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 2))
                "discount" -> m.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 3, stripTrailingZeros = false))
                else -> m
            }
        }
        reportRepo.replaceReportColumns(reportId, updatedReportCols)
        val updatedReport = db.reportDao().getReportWithDetails(reportId)!!
        drawnCanvas.clear()
        drawnCells.clear()
        val resUpdated = pdfEngine.generateReportPdf(updatedReport, settings, "report_2dec_qty")
        assertTrue(resUpdated.pageCount >= 2)
        assertTrue(drawnCells.contains("1.00"))
        assertTrue(drawnCells.contains("20.00"))
        assertTrue(drawnCells.contains("15.50"))
        assertTrue(drawnCells.contains("15.25"))
        assertTrue(drawnCells.contains("10.000%"))

        // 2. Inventory PDF test with same matrix [1, 20, 15.5, 15.25, 120] across multiple pages
        val sid = inventoryRepo.createSession("جرد PDF متعدد الصفحات", "").getOrThrow()
        products.forEachIndexed { idx, prod ->
            val q = quantities[idx % quantities.size]
            inventoryRepo.recordCountedItem(
                sessionId = sid,
                product = prod,
                scannedBarcode = prod.primaryBarcode!!.barcodeValue,
                barcodeType = "CODE_128",
                unitType = "حبة",
                conversionFactor = 1.0,
                quantity = q,
                notes = "",
                duplicateAction = DuplicateCountAction.REPLACE_EXISTING,
            ).getOrThrow()
        }
        val invSession = db.inventoryDao().getSessionWithDetails(sid)!!
        val allProductsList = db.productDao().getAllProductsWithDetailsOnce()

        drawnCanvas.clear()
        drawnCells.clear()
        val invCols0 = InventoryColumnDefaults.defaultColumns()
        val invRes0 = pdfEngine.generateInventoryReportPdf(
            sessionDetails = invSession,
            allProducts = allProductsList,
            settings = settings,
            inventoryConfig = InventorySheetConfig(columns = invCols0),
            outputFileName = "inv_0dec",
        )
        assertTrue(invRes0.pageCount >= 2)
        assertTrue(drawnCells.contains("1"))
        assertTrue(drawnCells.contains("20"))
        assertFalse(drawnCells.contains("1.00"))
        // Expected sum: 6 full cycles * (1+20+15.5+15.25+120=171.75) + (1+20=21) = 1051.5 -> rounded at 0 decimals = "1,052"
        val expectedRawSum = (0 until 32).sumOf { quantities[it % quantities.size] }
        val expectedSum0 = NumberFormatEngine.formatDouble(
            expectedRawSum,
            NumberFormatSpec(decimalPlaces = 0),
        )
        assertTrue(drawnCanvas.any { it.contains("إجمالي الكميات: $expectedSum0") })

        // Now change Inventory qty to 1 decimal, verify header/footer/cells all update to 1 decimal
        drawnCanvas.clear()
        drawnCells.clear()
        val invCols1 = invCols0.map {
            if (it.columnKey == "quantity") it.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 1)) else it
        }
        val invRes1 = pdfEngine.generateInventoryReportPdf(
            sessionDetails = invSession,
            allProducts = allProductsList,
            settings = settings,
            inventoryConfig = InventorySheetConfig(columns = invCols1),
            outputFileName = "inv_1dec",
        )
        assertTrue(invRes1.pageCount >= 2)
        assertTrue(drawnCells.contains("1.0"))
        assertTrue(drawnCells.contains("20.0"))
        assertTrue(drawnCells.contains("15.5"))
        assertTrue(drawnCells.contains("15.3"))
        val expectedSum1 = NumberFormatEngine.formatDouble(expectedRawSum, NumberFormatSpec(decimalPlaces = 1))
        assertTrue(drawnCanvas.any { it.contains("إجمالي الكميات: $expectedSum1") })
    }

    @Test
    fun `excel export writes per-column numFmt codes while keeping lossless numeric values and text barcodes`() = runBlocking {
        val pid = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "XLS-1", name = "منتج إكسل", basePrice = 42.5, defaultQuantity = 20.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "0001234567890", isPrimary = true)),
            emptyList(),
        ).getOrThrow()
        val prod = db.productDao().getProductWithDetails(pid)!!

        // 1. Report XLSX with qty=0 decimals, price=3 decimals, total=2 decimals
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير إكسل")
        reportRepo.addProductToReport(rid, prod)
        val item = db.reportDao().getReportWithDetails(rid)!!.sortedItems.first().item
        reportRepo.updateReportItem(item.copy(quantity = 15.25, unitPrice = 42.5))
        val cols = db.reportDao().getReportWithDetails(rid)!!.sortedColumns.map { c ->
            val m = c.toDomainModel()
            when (m.columnKey) {
                "qty" -> m.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 0))
                "price" -> m.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 3))
                else -> m
            }
        }
        reportRepo.replaceReportColumns(rid, cols)
        val report = db.reportDao().getReportWithDetails(rid)!!

        val repFile = excelExport.exportReportToXlsx(report, "rep_fmt_test.xlsx")
        val repZip = readZipEntries(repFile)
        val stylesXml = repZip["xl/styles.xml"] ?: error("Missing styles.xml")
        val sheetXml = repZip["xl/worksheets/sheet1.xml"] ?: error("Missing sheet1.xml")

        assertTrue(stylesXml.contains("formatCode=\"@\""))
        assertTrue(stylesXml.contains("formatCode=\"#,##0\""))
        assertTrue(stylesXml.contains("formatCode=\"#,##0.000\""))
        assertTrue(stylesXml.contains("formatCode=\"#,##0.00\""))
        // Raw numeric value preserved unrounded in XML <v>
        assertTrue(sheetXml.contains("<v>15.25</v>"))
        assertTrue(sheetXml.contains("<v>42.5</v>"))
        // Barcode leading zeros preserved as inlineStr
        assertTrue(sheetXml.contains("0001234567890"))

        // 2. Inventory XLSX with quantity=0 decimals, base_qty=2 decimals
        val sid = inventoryRepo.createSession("جرد إكسل", "").getOrThrow()
        inventoryRepo.recordCountedItem(
            sessionId = sid,
            product = prod,
            scannedBarcode = "0001234567890",
            barcodeType = "CODE_128",
            unitType = "كرتون",
            conversionFactor = 12.0,
            quantity = 1.0,
            notes = "",
            duplicateAction = DuplicateCountAction.REPLACE_EXISTING,
        ).getOrThrow()
        val invSession = db.inventoryDao().getSessionWithDetails(sid)!!
        val baseQtyCol = InventoryColumnDefaults.defaultColumnForKey("base_qty")!!
            .withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 2))
            .copy(sortOrder = 99)
        val invCols = InventoryColumnDefaults.defaultColumns().map { c ->
            if (c.columnKey == "quantity") c.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 0)) else c
        } + baseQtyCol
        val invFile = excelExport.exportInventoryReportToXlsx(
            sessionDetails = invSession,
            allProducts = listOf(prod),
            fileName = "inv_fmt_test.xlsx",
            inventoryConfig = InventorySheetConfig(columns = invCols),
        )
        val invZip = readZipEntries(invFile)
        assertTrue(invZip["xl/styles.xml"]!!.contains("formatCode=\"#,##0\""))
        assertTrue(invZip["xl/styles.xml"]!!.contains("formatCode=\"#,##0.00\""))
        assertTrue(invZip["xl/worksheets/sheet1.xml"]!!.contains("<v>1</v>"))
        assertTrue(invZip["xl/worksheets/sheet1.xml"]!!.contains("<v>12</v>"))

        // 3. Products XLSX export + re-import roundtrip verification
        val prodCfg = ProductsNumericConfig(priceFormat = NumberFormatSpec(decimalPlaces = 3))
        val prodFile = excelExport.exportProductsToXlsx(listOf(prod), "prod_fmt_test", productsNumericConfig = prodCfg)
        val prodZip = readZipEntries(prodFile)
        assertTrue(prodZip["xl/styles.xml"]!!.contains("formatCode=\"#,##0.000\""))

        val reparsed = excelImport.parseBytes(prodFile.readBytes(), prodFile.name).getOrThrow().sheets.first()
        assertTrue(reparsed.rows.any { row -> row.any { it.contains("0001234567890") } })
    }

    @Test
    fun `database migration 5 to 6 preserves existing records and upgrades legacy inventory defaults safely`() {
        val dbName = "migration_5_to_6_test_${System.nanoTime()}.db"
        val dbFile = context.getDatabasePath(dbName)
        dbFile.parentFile?.mkdirs()

        // Create minimal v5 schema with existing rows
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbFile.absolutePath)
                .callback(
                    object : SupportSQLiteOpenHelper.Callback(5) {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            db.execSQL("CREATE TABLE IF NOT EXISTS ReportColumns (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, reportId INTEGER NOT NULL, columnKey TEXT NOT NULL, title TEXT NOT NULL, columnType TEXT NOT NULL, visible INTEGER NOT NULL, sortOrder INTEGER NOT NULL, widthMode TEXT NOT NULL, presetWidth TEXT NOT NULL, manualWidthPt REAL NOT NULL, minWidthPt REAL NOT NULL, maxWidthPt REAL NOT NULL, cellHeightPt REAL NOT NULL, alignment TEXT NOT NULL, wrapText INTEGER NOT NULL, fontSizeSp REAL NOT NULL, headerBgColorHex TEXT NOT NULL, headerTextColorHex TEXT NOT NULL, textColorHex TEXT NOT NULL, decimalPlaces INTEGER NOT NULL, numberFormat TEXT NOT NULL, customFieldKey TEXT NOT NULL)")
                            db.execSQL("CREATE TABLE IF NOT EXISTS AppSettings (id INTEGER NOT NULL PRIMARY KEY, appName TEXT NOT NULL, companyName TEXT NOT NULL, companyLogoPath TEXT NOT NULL, companyAddress TEXT NOT NULL, companyPhone TEXT NOT NULL, developerName TEXT NOT NULL, developerPhone TEXT NOT NULL, defaultCurrency TEXT NOT NULL, defaultPaperSize TEXT NOT NULL, defaultOrientation TEXT NOT NULL, defaultMarginMm REAL NOT NULL, defaultBarcodeType TEXT NOT NULL, barcodeDpi INTEGER NOT NULL, themeMode TEXT NOT NULL, accentColorHex TEXT NOT NULL, fontFamilyKey TEXT NOT NULL, headerDefaultText TEXT NOT NULL, footerDefaultText TEXT NOT NULL, cameraContinuousScan INTEGER NOT NULL, cameraFlashDefault INTEGER NOT NULL, scanBeepEnabled INTEGER NOT NULL, scanVibrateEnabled INTEGER NOT NULL, autoSaveEnabled INTEGER NOT NULL, exportFilePrefix TEXT NOT NULL, productPickerViewMode TEXT NOT NULL, inventoryConfigJson TEXT NOT NULL)")
                            db.execSQL("INSERT INTO ReportColumns (id, reportId, columnKey, title, columnType, visible, sortOrder, widthMode, presetWidth, manualWidthPt, minWidthPt, maxWidthPt, cellHeightPt, alignment, wrapText, fontSizeSp, headerBgColorHex, headerTextColorHex, textColorHex, decimalPlaces, numberFormat, customFieldKey) VALUES (1, 10, 'qty', 'الكمية', 'QUANTITY', 1, 0, 'AUTO_FIT', 'MEDIUM', 60.0, 32.0, 120.0, 32.0, 'CENTER', 0, 9.0, '#0F172A', '#FFFFFF', '#0F172A', 2, 'DECIMAL', '')")
                            val legacyInvJson = """{"paperSize":"A4","columns":[{"columnKey":"quantity","title":"الكمية","columnType":"QUANTITY","decimalPlaces":2}]}"""
                            db.execSQL("INSERT INTO AppSettings (id, appName, companyName, companyLogoPath, companyAddress, companyPhone, developerName, developerPhone, defaultCurrency, defaultPaperSize, defaultOrientation, defaultMarginMm, defaultBarcodeType, barcodeDpi, themeMode, accentColorHex, fontFamilyKey, headerDefaultText, footerDefaultText, cameraContinuousScan, cameraFlashDefault, scanBeepEnabled, scanVibrateEnabled, autoSaveEnabled, exportFilePrefix, productPickerViewMode, inventoryConfigJson) VALUES (1, 'مدير التقارير', 'شركتي', '', '', '', 'dev', '000', 'ر.س', 'A4', 'PORTRAIT', 10.0, 'CODE_128', 300, 'SYSTEM', '#0D9488', 'CAIRO', '', '', 0, 0, 1, 1, 1, 'rep', 'COMFORTABLE_LIST', '$legacyInvJson')")
                        }

                        override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                    },
                )
                .build(),
        )
        val v5Db = helper.writableDatabase
        AppDatabase.MIGRATION_5_6.migrate(v5Db)

        v5Db.query("SELECT columnKey, decimalPlaces, autoDecimals, stripTrailingZeros FROM ReportColumns WHERE id = 1").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("qty", c.getString(0))
            assertEquals(2, c.getInt(1))
            assertEquals(0, c.getInt(2))
            assertEquals(0, c.getInt(3))
        }
        var migratedInvJson = ""
        v5Db.query("SELECT inventoryConfigJson, productsNumericConfigJson FROM AppSettings WHERE id = 1").use { c ->
            assertTrue(c.moveToFirst())
            migratedInvJson = c.getString(0)
            assertEquals("", c.getString(1))
        }
        helper.close()
        dbFile.delete()

        // Decoding legacy inventoryConfigJson (schemaRevision < 2) upgrades default quantity to 0 decimals
        val decoded = InventoryColumnDefaults.decode(migratedInvJson)
        val decodedQty = decoded.columns.first { it.columnKey == "quantity" }
        assertEquals(0, decodedQty.decimalPlaces)

        // While user-saved schemaRevision=2 with explicit 2 decimals stays preserved
        val explicitTwo = InventorySheetConfig(
            schemaRevision = 2,
            columns = listOf(decodedQty.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 2))),
        )
        val reDecoded = InventoryColumnDefaults.decode(InventoryColumnDefaults.encode(explicitTwo))
        assertEquals(2, reDecoded.columns.first { it.columnKey == "quantity" }.decimalPlaces)
    }

    @Test
    fun `resetting to defaults restores required decimal configuration across all three sections`() {
        val invColsCustomized = InventoryColumnDefaults.defaultColumns().map {
            if (NumberFormatEngine.isNumericColumnType(it.columnType)) {
                it.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 5, stripTrailingZeros = true))
            } else it
        }
        val invReset = invColsCustomized.map {
            if (NumberFormatEngine.isNumericColumnType(it.columnType)) {
                it.withNumberFormatSpec(
                    NumberFormatEngine.defaultSpecForColumn(AppNumericSection.INVENTORY, it.columnKey, it.columnType),
                )
            } else it
        }
        assertEquals(0, NumberFormatEngine.resolveInventoryColumnSpec(invReset, "quantity").decimalPlaces)
        assertEquals(0, NumberFormatEngine.resolveInventoryColumnSpec(invReset, "base_qty").decimalPlaces)
        assertTrue(NumberFormatEngine.resolveInventoryColumnSpec(invReset, "conversion_factor").autoDecimals)

        val defaultTpl = TemplateDefaults.buildBuiltInTemplates().first()
        val repColsCustomized = TemplateDefaults.decodeColumns(defaultTpl.columnsConfigJson).map {
            if (NumberFormatEngine.isNumericColumnType(it.columnType)) {
                it.withNumberFormatSpec(NumberFormatSpec(decimalPlaces = 6))
            } else it
        }
        val repReset = repColsCustomized.map {
            if (NumberFormatEngine.isNumericColumnType(it.columnType)) {
                it.withNumberFormatSpec(
                    NumberFormatEngine.defaultSpecForColumn(AppNumericSection.REPORT, it.columnKey, it.columnType),
                )
            } else it
        }
        assertEquals(0, NumberFormatEngine.resolveReportQuantitySpec(repReset).decimalPlaces)
        assertEquals(2, NumberFormatEngine.resolveReportPriceSpec(repReset).decimalPlaces)
        assertEquals(2, NumberFormatEngine.resolveReportTotalSpec(repReset).decimalPlaces)
    }

    private fun readZipEntries(file: File): Map<String, String> {
        val out = mutableMapOf<String, String>()
        ZipFile(file).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (!entry.isDirectory && entry.name.endsWith(".xml", ignoreCase = true)) {
                    out[entry.name] = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
                }
            }
        }
        return out
    }
}
