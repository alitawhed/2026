package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.view.ContextThemeWrapper
import androidx.activity.ComponentActivity
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.DuplicateBarcodeException
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.ReportHeaderFooterConfig
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.domain.pdf.PrintDispatchResult
import com.example.domain.pdf.SafePdfPrintAdapter
import com.example.domain.pdf.SafePdfPrintHelper
import com.example.domain.pdf.findActivity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PrintingSafetyAndMultiBarcodeUpgradeTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun makePngBytes(width: Int = 180, height: Int = 180, color: Int = Color.BLUE): ByteArray {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            eraseColor(color)
        }
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    @Test
    fun `findActivity and SafePdfPrintHelper never crash on non-Activity or missing files`() {
        val tempPdf = File(context.cacheDir, "valid_print_${System.nanoTime()}.pdf").apply {
            writeText("%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF")
        }
        val emptyPdf = File(context.cacheDir, "empty_print_${System.nanoTime()}.pdf").apply {
            writeBytes(ByteArray(0))
        }
        val missingPdf = File(context.cacheDir, "does_not_exist_${System.nanoTime()}.pdf")

        try {
            // 1. Application context has no Activity -> returns Error safely instead of crashing PrintManager
            assertNull(context.findActivity())
            val appRes = SafePdfPrintHelper.printPdfWithActivity(context, tempPdf, "test_job")
            assertTrue("Expected Error when printing from Application context", appRes is PrintDispatchResult.Error)

            // 2. Real Robolectric Activity + ContextThemeWrapper resolves cleanly
            val activity = Robolectric.buildActivity(ComponentActivity::class.java).setup().get()
            val wrapped = ContextThemeWrapper(activity, android.R.style.Theme_Material_Light)
            assertEquals(activity, wrapped.findActivity())

            // 3. Missing / empty files fail gracefully before calling PrintManager
            assertTrue(SafePdfPrintHelper.printPdfWithActivity(wrapped, missingPdf, "missing") is PrintDispatchResult.Error)
            assertTrue(SafePdfPrintHelper.printPdfWithActivity(wrapped, emptyPdf, "empty") is PrintDispatchResult.Error)

            // 4. Valid Activity + non-empty PDF dispatches cleanly
            val okRes = SafePdfPrintHelper.printPdfWithActivity(wrapped, tempPdf, "good_job", isLandscape = true)
            assertTrue("Expected Started result for wrapped Activity, got $okRes", okRes is PrintDispatchResult.Started)
        } finally {
            tempPdf.delete()
            emptyPdf.delete()
        }
    }

    @Test
    fun `SafePdfPrintAdapter handles null fd cancellation and full byte stream copy safely`() {
        val sampleBytes = "%PDF-1.4\n%Sample Print Stream Payload\n%%EOF".toByteArray()
        val sourcePdf = File(context.cacheDir, "adapter_src_${System.nanoTime()}.pdf").apply {
            writeBytes(sampleBytes)
        }
        val destFile = File(context.cacheDir, "adapter_dst_${System.nanoTime()}.pdf")
        try {
            val adapter = SafePdfPrintAdapter(sourcePdf, knownPageCount = 2)

            // Null destination & null callback must never throw NPE
            adapter.onWrite(arrayOf(PageRange.ALL_PAGES), null, CancellationSignal(), null)

            // Cancelled signal on layout & write returns safely without throwing
            val cancelSignal = CancellationSignal().apply { cancel() }
            adapter.onLayout(null, PrintAttributes.Builder().build(), cancelSignal, null, null)
            adapter.onWrite(arrayOf(PageRange.ALL_PAGES), null, cancelSignal, null)

            // Valid write stream copies exact bytes into FileDescriptor
            ParcelFileDescriptor.open(
                destFile,
                ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_TRUNCATE,
            ).use { pfd ->
                adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(), null)
            }
            assertArrayEquals(sampleBytes, destFile.readBytes())
        } finally {
            sourcePdf.delete()
            destFile.delete()
        }
    }

    @Test
    fun `large 80-item PDF with images uses bounded cache and avoids trailing blank page`() = runBlocking {
        val pageBitmaps = mutableListOf<Bitmap>()
        val factory = PdfSessionFactory {
            object : PdfSession {
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                    val bmp = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                    pageBitmaps.add(bmp)
                    return Canvas(bmp)
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: OutputStream) {
                    outputStream.write("%PDF-1.4\n%80-items\n%%EOF".toByteArray())
                }
                override fun close() = Unit
            }
        }
        val engine = PdfGeneratorEngine(context, mediaStorage, factory)

        // Create 80 products sharing high-res images so cache eviction & pagination are both exercised
        val imgPaths = (1..5).map { idx ->
            mediaStorage.saveProductImageFromBytes(makePngBytes(240, 240, Color.rgb(30 * idx, 80, 180)))!!
        }
        val createdProducts = (1..80).map { i ->
            val pid = productRepo.createOrUpdateProduct(
                product = ProductEntity(
                    internalCode = "BIG-${i.toString().padStart(3, '0')}",
                    name = "صنف فحص الأداء رقم $i",
                    basePrice = i * 5.5,
                    defaultQuantity = 10.0,
                ),
                barcodes = listOf(
                    ProductBarcodeEntity(productId = 0L, barcodeValue = "0080${i.toString().padStart(6, '0')}", isPrimary = true),
                ),
                images = listOf(
                    ProductImageEntity(productId = 0L, filePath = imgPaths[i % imgPaths.size], isPrimary = true),
                ),
            ).getOrThrow()
            db.productDao().getProductWithDetails(pid)!!
        }

        val reportId = reportRepo.createEmptyReport(customTitle = "تقرير 80 صنف")
        createdProducts.forEach { reportRepo.addProductToReport(reportId, it) }
        val details = reportRepo.getReportOnce(reportId)!!

        // Disable all summary footer blocks: hasVisibleFooter == false must prevent trailing blank page
        val noFooterConfig = ReportHeaderFooterConfig(
            showTotals = false,
            showNotes = false,
            showTerms = false,
            showResponsible = false,
            showSignature = false,
            showStamp = false,
            showPageNumbers = true,
        )
        val noFooterJson = TemplateDefaults.json.encodeToString(ReportHeaderFooterConfig.serializer(), noFooterConfig)
        val modified = details.copy(report = details.report.copy(headerFooterConfigJson = noFooterJson))

        val result = engine.generateReportPdf(
            reportDetails = modified,
            settings = db.settingsDao().getSettingsOnce() ?: AppSettingsEntity(),
            outputFileName = "stress_80_products.pdf",
        )
        assertTrue(result.file.exists() && result.file.length() > 10L)
        assertTrue("Expected at least 4 pages for 80 items", result.pageCount >= 4)
        assertEquals(result.pageCount, pageBitmaps.size)

        // Last rendered page must contain substantial table ink (not a blank trailing page)
        val lastPage = pageBitmaps.last()
        var nonWhiteCount = 0
        for (y in 0 until lastPage.height step 10) {
            for (x in 0 until lastPage.width step 10) {
                if (lastPage.getPixel(x, y) != Color.WHITE) nonWhiteCount++
            }
        }
        assertTrue("Expected real table content on last page (got $nonWhiteCount ink samples)", nonWhiteCount > 25)
        pageBitmaps.forEach { if (!it.isRecycled) it.recycle() }
    }

    @Test
    fun `multi-barcode units leading zeros duplicate rejection and unified search work end-to-end`() = runBlocking {
        val pid1 = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "SKU-501", name = "ماء معدني 330 مل", basePrice = 2.0),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "0012345000011",
                    barcodeType = BarcodeFormatType.EAN_13.name,
                    label = "حبة",
                    unitType = "حبة",
                    conversionFactor = 1.0,
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()

        val pid2 = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "SKU-502", name = "عصير برتقال", basePrice = 5.0),
            barcodes = listOf(
                ProductBarcodeEntity(productId = 0L, barcodeValue = "0099999000022", isPrimary = true),
            ),
            images = emptyList(),
        ).getOrThrow()

        // Invalid conversionFactor <= 0 must be rejected
        val invalidFactor = productRepo.addBarcodeToProduct(
            productId = pid1,
            barcodeValue = "0012345000099",
            format = BarcodeFormatType.CODE_128,
            label = "كرتون",
            makePrimary = false,
            description = "معامل خطأ",
            unitType = "كرتون",
            conversionFactor = 0.0,
        )
        assertTrue(invalidFactor.isFailure)

        // Duplicate barcode owned by pid2 must fail with DuplicateBarcodeException
        val dupRes = productRepo.addBarcodeToProduct(
            productId = pid1,
            barcodeValue = "0099999000022",
            format = BarcodeFormatType.CODE_128,
            label = "كرتون",
            makePrimary = false,
        )
        assertTrue(dupRes.isFailure)
        assertTrue(dupRes.exceptionOrNull() is DuplicateBarcodeException)

        // Add carton barcode with unit metadata & leading zero preserved
        val cartonBarcodeId = productRepo.addBarcodeToProduct(
            productId = pid1,
            barcodeValue = "00088776655",
            format = BarcodeFormatType.CODE_128,
            label = "كرتون 24 حبة",
            makePrimary = false,
            description = "عبوة الكرتون الكامل",
            unitType = "كرتون",
            conversionFactor = 24.0,
        ).getOrThrow()

        var loaded = db.productDao().getProductWithDetails(pid1)!!
        assertEquals(2, loaded.barcodes.size)
        val carton = loaded.barcodes.first { it.id == cartonBarcodeId }
        assertEquals("00088776655", carton.barcodeValue)
        assertEquals("كرتون", carton.unitType)
        assertEquals(24.0, carton.conversionFactor, 0.001)

        // Update barcode unit metadata & promote to primary
        productRepo.updateBarcode(
            carton.copy(
                unitType = "عبوة كبيرة",
                conversionFactor = 12.0,
                description = "نصف كرتون",
            ),
        ).getOrThrow()
        productRepo.setPrimaryBarcode(pid1, cartonBarcodeId)

        loaded = db.productDao().getProductWithDetails(pid1)!!
        assertEquals(1, loaded.barcodes.count { it.isPrimary })
        assertEquals(cartonBarcodeId, loaded.primaryBarcode?.id)
        assertEquals(12.0, loaded.primaryBarcode!!.conversionFactor, 0.001)
        assertEquals("عبوة كبيرة", loaded.primaryBarcode!!.unitType)

        // Unified search matches alternative barcode, leading zeros, unitType, and internalCode
        val all = db.productDao().getAllProductsWithDetailsOnce()
        assertEquals(listOf(pid1), productRepo.filterProductsUnified(all, "0012345000011").map { it.product.id })
        assertEquals(listOf(pid1), productRepo.filterProductsUnified(all, "00088776655").map { it.product.id })
        assertEquals(listOf(pid1), productRepo.filterProductsUnified(all, "عبوة كبيرة").map { it.product.id })
        assertEquals(listOf(pid2), productRepo.filterProductsUnified(all, "SKU-502").map { it.product.id })

        // Delete secondary barcode keeps product + primary intact
        val nonPrimaryId = loaded.barcodes.first { !it.isPrimary }.id
        productRepo.deleteBarcode(pid1, nonPrimaryId)
        assertEquals(1, db.productDao().getProductWithDetails(pid1)!!.barcodes.size)
    }

    @Test
    fun `MIGRATION_3_4 preserves v3 data backfills barcode units and creates inventory schema`() {
        val dbFile = File(context.cacheDir, "legacy_v3_${System.nanoTime()}.db")
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbFile.absolutePath)
                .callback(object : SupportSQLiteOpenHelper.Callback(3) {
                    override fun onCreate(sDb: SupportSQLiteDatabase) {
                        sDb.execSQL(
                            """
                            CREATE TABLE ProductBarcodes (
                                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                productId INTEGER NOT NULL,
                                barcodeValue TEXT NOT NULL,
                                barcodeType TEXT NOT NULL,
                                label TEXT NOT NULL,
                                isPrimary INTEGER NOT NULL,
                                createdAt INTEGER NOT NULL
                            )
                            """.trimIndent(),
                        )
                    }

                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                })
                .build(),
        )

        val raw = helper.writableDatabase
        raw.execSQL("INSERT INTO ProductBarcodes (id, productId, barcodeValue, barcodeType, label, isPrimary, createdAt) VALUES (1, 10, '001122', 'CODE_128', 'كرتون', 0, 1700000000)")
        raw.execSQL("INSERT INTO ProductBarcodes (id, productId, barcodeValue, barcodeType, label, isPrimary, createdAt) VALUES (2, 10, '009988', 'EAN_13', 'رئيسي', 1, 1700000001)")

        AppDatabase.MIGRATION_3_4.migrate(raw)

        raw.query("SELECT barcodeValue, unitType, conversionFactor, description, updatedAt FROM ProductBarcodes ORDER BY id ASC").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("001122", c.getString(0))
            assertEquals("كرتون", c.getString(1))
            assertEquals(1.0, c.getDouble(2), 0.001)
            assertEquals("", c.getString(3))
            assertEquals(1700000000L, c.getLong(4))

            assertTrue(c.moveToNext())
            assertEquals("009988", c.getString(0))
            assertEquals("رئيسي", "حبة", c.getString(1))
        }

        // Verify all 3 inventory tables exist & accept writes
        raw.execSQL("INSERT INTO InventorySessions (id, title, sessionDate, status, notes, createdAt, updatedAt) VALUES (5, 'جرد قديم', 1700000000, 'OPEN', '', 1, 1)")
        raw.query("SELECT COUNT(*) FROM InventorySessions").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(1, c.getInt(0))
        }
        raw.query("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('InventorySessions','InventoryCountItems','StockAdjustmentLogs')").use { c ->
            assertEquals(3, c.count)
        }

        helper.close()
        dbFile.delete()
    }
}
