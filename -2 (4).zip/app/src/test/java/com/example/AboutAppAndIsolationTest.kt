package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.repository.SettingsRepository
import com.example.data.storage.MediaStorageManager
import com.example.di.AppContainer
import com.example.domain.backup.BackupDatabasePayload
import com.example.domain.backup.BackupManifest
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.barcode.BarcodeService
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.model.DeveloperIdentity
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.ThemeMode
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.ui.screens.AboutAppScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AboutAppAndIsolationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var dbFile: File
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var barcodeService: BarcodeService
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var productRepo: ProductRepository
    private lateinit var inventoryRepo: InventoryRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var excelExport: ExcelExportEngine

    private val forbiddenLeaks = listOf(
        "المهندس علي توحيد",
        "علي توحيد",
        "s2x518u@gmail.com",
        "00966573928022",
        "00967771084252",
        "+966573928022",
        "© جميع الحقوق محفوظة",
    )

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        dbFile = File(context.cacheDir, "about_isolation_test_${System.nanoTime()}.db")
        db = Room.databaseBuilder(context, AppDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        barcodeService = BarcodeService(db, mediaStorage)
        settingsRepo = SettingsRepository(db)
        productRepo = ProductRepository(db, mediaStorage, barcodeService = barcodeService)
        inventoryRepo = InventoryRepository(db, barcodeService = barcodeService)
        reportRepo = ReportRepository(db, mediaStorage, barcodeService = barcodeService)
        excelExport = ExcelExportEngine(mediaStorage)
        runBlocking {
            AppDatabase.ensureSeeded(db)
        }
    }

    @After
    fun tearDown() {
        barcodeService.closeForTest()
        db.close()
        dbFile.delete()
    }

    @Test
    fun `1 - about screen displays complete Arabic identity dynamic version features developer info and copyright in light mode`() {
        val versionInfo = DeveloperIdentity.resolveAppVersionInfo(context)

        composeRule.setContent {
            ReportManagerTheme(themeMode = ThemeMode.LIGHT) {
                AboutAppScreen(onBack = {})
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithText("حول التطبيق").assertIsDisplayed()
        composeRule.onNodeWithTag("about_app_name").assertIsDisplayed()
        composeRule.onNodeWithText("إدارة ذكية للمنتجات والجرد والتقارير").assertIsDisplayed()
        composeRule.onNodeWithTag("about_version_badge").assertIsDisplayed()
        composeRule.onNodeWithText("الإصدار ${versionInfo.versionName} (${versionInfo.versionCode})").assertIsDisplayed()

        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_description_card"))
        composeRule.onNodeWithText("مدير التقارير هو تطبيق متكامل", substring = true).assertIsDisplayed()

        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_features_section"))
        listOf(
            "إدارة المنتجات",
            "إدارة الصور",
            "مسح الباركود",
            "أنواع الباركود",
            "إدارة الجرد",
            "التقارير الاحترافية",
            "تصدير PDF",
            "تصدير Excel",
            "الطباعة",
            "التحكم بالأعمدة",
            "النسخ الاحتياطي",
            "استعادة البيانات",
        ).forEach { featureTitle ->
            composeRule.onNodeWithText(featureTitle).assertExists()
        }

        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_developer_card"))
        composeRule.onNodeWithText("معلومات المطور").assertIsDisplayed()
        composeRule.onNodeWithText("المهندس علي توحيد").assertIsDisplayed()
        composeRule.onAllNodesWithText("s2x518u@gmail.com").assertCountEquals(2)
        composeRule.onAllNodesWithText("s2x518u@gmail.com")[0].assertIsDisplayed()
        composeRule.onAllNodesWithText("00966573928022").assertCountEquals(3)
        composeRule.onAllNodesWithText("00967771084252").assertCountEquals(3)

        // No edit controls on About screen
        composeRule.onNodeWithText("تعديل الهوية من الإعدادات").assertDoesNotExist()

        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_copyright_footer"))
        composeRule.onNodeWithText("© جميع الحقوق محفوظة – مدير التقارير").assertIsDisplayed()
        composeRule.onAllNodesWithText("تطوير وبرمجة المهندس علي توحيد").assertCountEquals(2)
    }

    @Test
    fun `2 - about screen supports dark theme cleanly without crashes or missing sections`() {
        composeRule.setContent {
            ReportManagerTheme(themeMode = ThemeMode.DARK) {
                AboutAppScreen(onBack = {})
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("about_hero_card").assertIsDisplayed()
        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_developer_card"))
        composeRule.onNodeWithText("المهندس علي توحيد").assertIsDisplayed()
        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_copyright_footer"))
        composeRule.onNodeWithText("© جميع الحقوق محفوظة – مدير التقارير").assertIsDisplayed()
    }

    @Test
    fun `3 - whatsapp primary and secondary buttons launch exact wa_me urls with Arabic prefilled messages`() {
        val shadowApp = Shadows.shadowOf(context.applicationContext as Application)
        shadowApp.clearNextStartedActivities()

        composeRule.setContent {
            ReportManagerTheme {
                AboutAppScreen(onBack = {})
            }
        }

        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_whatsapp_primary_btn"))
        composeRule.onNodeWithTag("about_whatsapp_primary_btn").performScrollTo()
        composeRule.onNodeWithTag("about_whatsapp_primary_btn").performClick()
        composeRule.waitForIdle()

        val primaryIntent = shadowApp.nextStartedActivity
        assertNotNull("Primary WhatsApp intent should launch", primaryIntent)
        assertEquals(Intent.ACTION_VIEW, primaryIntent.action)
        val primaryData = primaryIntent.data?.toString().orEmpty()
        assertTrue("Expected https://wa.me/966573928022, got $primaryData", primaryData.startsWith("https://wa.me/966573928022?text="))
        assertEquals(DeveloperIdentity.PRIMARY_WHATSAPP_MESSAGE, Uri.parse(primaryData).getQueryParameter("text"))

        composeRule.onNodeWithTag("about_whatsapp_secondary_btn").performScrollTo()
        composeRule.onNodeWithTag("about_whatsapp_secondary_btn").performClick()
        composeRule.waitForIdle()

        val secondaryIntent = shadowApp.nextStartedActivity
        assertNotNull("Secondary WhatsApp intent should launch", secondaryIntent)
        assertEquals(Intent.ACTION_VIEW, secondaryIntent.action)
        val secondaryData = secondaryIntent.data?.toString().orEmpty()
        assertTrue("Expected https://wa.me/967771084252, got $secondaryData", secondaryData.startsWith("https://wa.me/967771084252?text="))
        assertEquals(DeveloperIdentity.SECONDARY_WHATSAPP_MESSAGE, Uri.parse(secondaryData).getQueryParameter("text"))

        // Browser fallback intent preserves wa.me + prefilled message when WhatsApp isn't installed
        val fallbackPrimary = DeveloperIdentity.buildBrowserWhatsAppIntent(isPrimary = true)
        assertEquals(null, fallbackPrimary.`package`)
        assertTrue(fallbackPrimary.data.toString().startsWith("https://wa.me/966573928022?text="))
    }

    @Test
    fun `4 - email intent uses mailto with exact address subject and body plus webmail fallback`() {
        val mailtoUri = DeveloperIdentity.buildEmailMailtoUri()
        assertEquals("mailto", mailtoUri.scheme)
        assertTrue(mailtoUri.schemeSpecificPart.startsWith("s2x518u@gmail.com"))
        val emailIntent = DeveloperIdentity.buildEmailIntent()
        assertEquals(Intent.ACTION_SENDTO, emailIntent.action)
        assertTrue(emailIntent.data.toString().contains(Uri.encode(DeveloperIdentity.EMAIL_SUBJECT)))
        assertTrue(emailIntent.data.toString().contains(Uri.encode(DeveloperIdentity.EMAIL_BODY)))

        val shadowApp = Shadows.shadowOf(context.applicationContext as Application)
        shadowApp.clearNextStartedActivities()

        composeRule.setContent {
            ReportManagerTheme {
                AboutAppScreen(onBack = {})
            }
        }
        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_email_btn"))
        composeRule.onNodeWithTag("about_email_btn").performScrollTo()
        composeRule.onNodeWithTag("about_email_btn").performClick()
        composeRule.waitForIdle()

        val launched = shadowApp.nextStartedActivity
        assertNotNull("Email click should launch mailto or browser fallback", launched)
        val uriStr = launched.data?.toString().orEmpty()
        assertTrue(
            "Expected s2x518u@gmail.com in launched URI, got $uriStr",
            uriStr.contains("s2x518u@gmail.com", ignoreCase = true) ||
                uriStr.contains("s2x518u%40gmail.com", ignoreCase = true),
        )
    }

    @Test
    fun `5 - phone call buttons require confirmation dialog and use ACTION_DIAL without CALL_PHONE permission`() {
        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS,
        )
        val perms = pkgInfo.requestedPermissions?.toList().orEmpty()
        assertFalse(
            "App must NOT request CALL_PHONE permission",
            perms.contains("android.permission.CALL_PHONE"),
        )

        val shadowApp = Shadows.shadowOf(context.applicationContext as Application)
        shadowApp.clearNextStartedActivities()

        composeRule.setContent {
            ReportManagerTheme {
                AboutAppScreen(onBack = {})
            }
        }

        // Primary phone dial button shows confirmation dialog first (never dials directly)
        composeRule.onNodeWithTag("about_app_list").performScrollToNode(hasTestTag("about_call_primary_btn"))
        composeRule.onNodeWithTag("about_call_primary_btn").performScrollTo()
        composeRule.onNodeWithTag("about_call_primary_btn").performClick()
        composeRule.waitForIdle()

        assertEquals(null, shadowApp.nextStartedActivity)
        composeRule.onNodeWithTag("dial_confirm_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("dial_confirm_btn").performClick()
        composeRule.waitForIdle()

        val primaryDialIntent = shadowApp.nextStartedActivity
        assertNotNull(primaryDialIntent)
        assertEquals(Intent.ACTION_DIAL, primaryDialIntent.action)
        assertEquals("tel:00966573928022", primaryDialIntent.data.toString())

        // Secondary phone dial button
        composeRule.onNodeWithTag("about_call_secondary_btn").performScrollTo()
        composeRule.onNodeWithTag("about_call_secondary_btn").performClick()
        composeRule.waitForIdle()

        assertEquals(null, shadowApp.nextStartedActivity)
        composeRule.onNodeWithTag("dial_confirm_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("dial_confirm_btn").performClick()
        composeRule.waitForIdle()

        val secondaryDialIntent = shadowApp.nextStartedActivity
        assertNotNull(secondaryDialIntent)
        assertEquals(Intent.ACTION_DIAL, secondaryDialIntent.action)
        assertEquals("tel:00967771084252", secondaryDialIntent.data.toString())
    }

    @Test
    fun `6 - developer info cannot be edited from settings or overwritten by backup restore`() = runBlocking {
        // Attempt direct SettingsRepository overwrite with tampered values
        val tampered = AppSettingsEntity(
            developerName = "مطور مزيف",
            developerPhone = "1111111111",
            companyName = "شركة العميل التجارية",
            companyPhone = "0500000000",
        )
        settingsRepo.saveSettings(tampered)
        val afterSettingsSave = settingsRepo.getSettingsOnce()
        assertEquals("المهندس علي توحيد", afterSettingsSave.developerName)
        assertEquals("+966573928022", afterSettingsSave.developerPhone)
        assertEquals("شركة العميل التجارية", afterSettingsSave.companyName)

        // Attempt ZIP backup restore overwrite with tampered AppSettingsEntity
        val backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        val payload = BackupDatabasePayload(
            settings = AppSettingsEntity(
                developerName = "Tampered Name",
                developerPhone = "000000000",
                companyName = "شركة المسترجع",
            ),
        )
        val manifest = BackupManifest(appVersion = "1.0")
        val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            zos.putNextEntry(ZipEntry("manifest.json"))
            zos.write(json.encodeToString(manifest).toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("database_export.json"))
            zos.write(json.encodeToString(payload).toByteArray())
            zos.closeEntry()
        }

        val restoreResult = backupEngine.restoreFromBackupBytes(baos.toByteArray(), "tamper_test.zip")
        assertTrue("Restore should succeed", restoreResult.isSuccess)
        val afterRestore = settingsRepo.getSettingsOnce()
        assertEquals("المهندس علي توحيد", afterRestore.developerName)
        assertEquals("+966573928022", afterRestore.developerPhone)
        assertEquals("شركة المسترجع", afterRestore.companyName)

        // Immutable Kotlin DeveloperIdentity remains unchanged
        assertEquals("المهندس علي توحيد", DeveloperIdentity.DEVELOPER_NAME)
        assertEquals("s2x518u@gmail.com", DeveloperIdentity.DEVELOPER_EMAIL)
        assertEquals("00966573928022", DeveloperIdentity.PRIMARY_PHONE_DISPLAY)
        assertEquals("00967771084252", DeveloperIdentity.SECONDARY_PHONE_DISPLAY)
    }

    @Test
    fun `7 - developer edit fields do not exist in Settings UI and Settings button opens AboutAppScreen`() {
        val container = AppContainer(context)
        val settingsVm = SettingsViewModel(container)
        var openedAbout = false

        composeRule.setContent {
            ReportManagerTheme {
                SettingsScreen(
                    viewModel = settingsVm,
                    onBack = {},
                    onOpenBackup = {},
                    onOpenAbout = { openedAbout = true },
                    onOpenDiagnostics = {},
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_dev_name").assertDoesNotExist()
        composeRule.onNodeWithTag("settings_dev_phone").assertDoesNotExist()
        composeRule.onNodeWithTag("settings_list").performScrollToNode(hasTestTag("settings_open_about_btn"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_open_about_btn").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertTrue("Settings About button should invoke navigation callback", openedAbout)
    }

    @Test
    fun `8 - strict isolation across products reports inventory PDF and Excel exports`() = runBlocking {
        // Default settings should not put developer phone in companyPhone
        val initialSettings = settingsRepo.getSettingsOnce()
        assertEquals("", initialSettings.companyPhone)

        // Seed product + inventory + report
        val productId = productRepo.createOrUpdateProduct(
            product = ProductEntity(
                internalCode = "PRD-100",
                name = "حبر طابعة أصلي",
                basePrice = 125.5,
                currency = "ر.س",
                defaultQuantity = 4.0,
            ),
            barcodes = listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "1234567890128",
                    barcodeType = "EAN_13",
                    isPrimary = true,
                ),
            ),
            images = emptyList(),
        ).getOrThrow()

        val savedProduct = db.productDao().getProductWithDetails(productId)!!
        val products = productRepo.allProducts.first()
        assertTrue(products.any { it.product.id == productId })

        val reportId = reportRepo.createEmptyReport(customTitle = "تقرير مبيعات شهري")
        val emptyReport = reportRepo.getReportOnce(reportId)!!
        assertEquals(
            "Report responsiblePerson must never be seeded from developerName",
            "",
            emptyReport.report.responsiblePerson,
        )
        reportRepo.addProductToReport(reportId = reportId, product = savedProduct)
        val populatedReport = reportRepo.getReportOnce(reportId)!!

        val sessionId = inventoryRepo.createSession(title = "جرد المستودع الرئيسي").getOrThrow()
        inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = savedProduct,
            scannedBarcode = "1234567890128",
            barcodeType = "EAN_13",
            unitType = "حبة",
            conversionFactor = 1.0,
            quantity = 5.0,
        ).getOrThrow()
        val populatedSession = inventoryRepo.getSessionOnce(sessionId)!!

        // Verify Excel & CSV exports contain zero developer info
        val productsXlsx = excelExport.exportProductsToXlsx(products, "isolation_products")
        val productsCsv = excelExport.exportProductsToCsv(products, "isolation_products_csv")
        val reportXlsx = excelExport.exportReportToXlsx(populatedReport, "isolation_report")
        val inventoryXlsx = excelExport.exportInventoryReportToXlsx(
            populatedSession,
            products,
            "isolation_inventory",
            InventoryColumnDefaults.decode(initialSettings.inventoryConfigJson),
        )

        val csvContent = productsCsv.readText()
        assertNoDeveloperLeaks("Products CSV", csvContent)
        assertNoDeveloperLeaks("Products XLSX", readAllZipXmlText(productsXlsx))
        assertNoDeveloperLeaks("Report XLSX", readAllZipXmlText(reportXlsx))
        assertNoDeveloperLeaks("Inventory XLSX", readAllZipXmlText(inventoryXlsx))

        // Verify PDF Report & PDF Inventory drawn texts contain zero developer info
        val drawnTexts = mutableListOf<String>()
        val recordingSessionFactory = RecordingPdfSessionFactory(drawnTexts)
        val pdfEngine = PdfGeneratorEngine(
            context = context,
            mediaStorage = mediaStorage,
            sessionFactory = recordingSessionFactory,
        )
        pdfEngine.drawnCellTextObserver = { drawnTexts += it }

        pdfEngine.generateReportPdf(
            reportDetails = populatedReport,
            settings = initialSettings,
            outputFileName = "isolation_report_pdf",
        )
        pdfEngine.generateInventoryReportPdf(
            sessionDetails = populatedSession,
            allProducts = products,
            settings = initialSettings,
            outputFileName = "isolation_inventory_pdf",
        )

        val combinedPdfText = drawnTexts.joinToString("\n")
        assertTrue("Recording PDF session should have drawn text", drawnTexts.isNotEmpty())
        assertNoDeveloperLeaks("PDF Reports & Inventory", combinedPdfText)
        assertFalse(
            "PDF footer must not contain 'إعداد: ' developer credit",
            combinedPdfText.contains("إعداد:"),
        )
    }

    private fun assertNoDeveloperLeaks(sourceLabel: String, content: String) {
        forbiddenLeaks.forEach { secret ->
            assertFalse(
                "$sourceLabel must NOT contain developer info '$secret'",
                content.contains(secret, ignoreCase = true),
            )
        }
    }

    private fun readAllZipXmlText(xlsxFile: File): String {
        val sb = StringBuilder()
        ZipInputStream(xlsxFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name.endsWith(".xml", ignoreCase = true)) {
                    sb.append(zis.bufferedReader().readText()).append('\n')
                }
                entry = zis.nextEntry
            }
        }
        return sb.toString()
    }
}

private class RecordingPdfSessionFactory(
    private val drawnTexts: MutableList<String>,
) : PdfSessionFactory {
    override fun create(): PdfSession = object : PdfSession {
        override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
            val bmp = Bitmap.createBitmap(widthPt.coerceAtLeast(100), heightPt.coerceAtLeast(100), Bitmap.Config.ARGB_8888)
            return object : Canvas(bmp) {
                override fun drawText(text: String, x: Float, y: Float, paint: Paint) {
                    drawnTexts += text
                    super.drawText(text, x, y, paint)
                }

                override fun drawText(text: String, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    drawnTexts += text.substring(start, end)
                    super.drawText(text, start, end, x, y, paint)
                }

                override fun drawText(text: CharSequence, start: Int, end: Int, x: Float, y: Float, paint: Paint) {
                    drawnTexts += text.subSequence(start, end).toString()
                    super.drawText(text, start, end, x, y, paint)
                }

                override fun drawText(text: CharArray, index: Int, count: Int, x: Float, y: Float, paint: Paint) {
                    drawnTexts += String(text, index, count)
                    super.drawText(text, index, count, x, y, paint)
                }

                override fun drawTextRun(
                    text: CharSequence,
                    start: Int,
                    end: Int,
                    contextStart: Int,
                    contextEnd: Int,
                    x: Float,
                    y: Float,
                    isRtl: Boolean,
                    paint: Paint,
                ) {
                    drawnTexts += text.subSequence(start, end).toString()
                    super.drawTextRun(text, start, end, contextStart, contextEnd, x, y, isRtl, paint)
                }

                override fun drawTextRun(
                    text: CharArray,
                    index: Int,
                    count: Int,
                    contextIndex: Int,
                    contextCount: Int,
                    x: Float,
                    y: Float,
                    isRtl: Boolean,
                    paint: Paint,
                ) {
                    drawnTexts += String(text, index, count)
                    super.drawTextRun(text, index, count, contextIndex, contextCount, x, y, isRtl, paint)
                }
            }
        }

        override fun endPage() {}
        override fun writeTo(outputStream: OutputStream) {
            outputStream.write("%PDF-1.4\n%Recording\n".toByteArray())
        }
        override fun close() {}
    }
}
