package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.local.entity.ProductWithDetails
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ParsedSheetData
import com.example.domain.excel.ProductImportField
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.PageOrientation
import com.example.domain.model.PaperSizeType
import com.example.domain.pdf.LabelPdfGenerator
import com.example.domain.pdf.LabelPrintItem
import com.example.domain.pdf.LabelSheetConfig
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import kotlinx.coroutines.runBlocking
import org.apache.poi.hssf.usermodel.HSSFClientAnchor
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.CellType
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExcelAndPdfAndBackupTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var excelImport: ExcelImportEngine
    private lateinit var excelExport: ExcelExportEngine
    private lateinit var pdfGenerator: PdfGeneratorEngine
    private lateinit var labelPdfGenerator: LabelPdfGenerator
    private lateinit var backupEngine: BackupRestoreEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        excelImport = ExcelImportEngine(context, db, mediaStorage)
        excelExport = ExcelExportEngine(mediaStorage)
        pdfGenerator = PdfGeneratorEngine(context, mediaStorage)
        labelPdfGenerator = LabelPdfGenerator(context, mediaStorage)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun makePngBytes(color: Int = Color.CYAN): ByteArray {
        val bmp = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        return ByteArrayOutputStream().use {
            bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            it.toByteArray()
        }
    }

    @Test
    fun `xlsx export and re-import preserves leading zero barcodes and anchored images`() = runBlocking {
        val imgPath = mediaStorage.saveProductImageFromBytes(makePngBytes(Color.MAGENTA))!!
        val products = listOf(
            ProductWithDetails(
                product = ProductEntity(
                    id = 1L,
                    internalCode = "P-001",
                    name = "منتج تجريبي عربي",
                    categoryName = "مشروبات",
                    basePrice = 19.75,
                    currency = "ر.س",
                    originCountry = "السعودية",
                ),
                barcodes = listOf(
                    ProductBarcodeEntity(id = 1L, productId = 1L, barcodeValue = "0012345678905", isPrimary = true),
                    ProductBarcodeEntity(id = 2L, productId = 1L, barcodeValue = "00042", isPrimary = false),
                ),
                images = listOf(ProductImageEntity(id = 1L, productId = 1L, filePath = imgPath, isPrimary = true)),
            ),
        )

        val xlsxFile = excelExport.exportProductsToXlsx(products, "test_roundtrip.xlsx", includeImages = true)
        assertTrue(xlsxFile.exists() && xlsxFile.length() > 0)

        val parsed = excelImport.parseBytes(xlsxFile.readBytes(), xlsxFile.name).getOrThrow()
        assertEquals("XLSX", parsed.fileType)
        val sheet = parsed.sheets.first()
        assertEquals(2, sheet.rows.size) // header + 1 row
        assertEquals("0012345678905", sheet.rows[1][2]) // Primary barcode keeps leading zeros
        assertEquals("00042", sheet.rows[1][3])         // Extra barcode keeps leading zeros
        assertEquals(1, sheet.extractedImages.size)
        assertEquals(1, sheet.extractedImages.first().anchoredRowZeroBased)

        val mapping = excelImport.suggestMappings(sheet.headers)
        val report = excelImport.executeImport(sheet, mapping, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals(1, report.insertedCount)
        assertEquals(2, report.barcodesImportedCount)
        assertEquals(1, report.autoLinkedImagesCount)
        assertTrue(report.unlinkedImages.isEmpty())

        val importedProd = productRepo.findProductByExactBarcode("0012345678905")
        assertNotNull(importedProd)
        assertEquals(2, importedProd!!.barcodes.size)
        assertEquals(1, importedProd.images.size)
    }

    @Test
    fun `unanchored xlsx image is never guess-linked to a product`() = runBlocking {
        // Minimal XLSX containing 1 product row + 1 drawing image anchored to non-existent row 99
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zos ->
            fun put(name: String, content: ByteArray) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(content)
                zos.closeEntry()
            }
            put(
                "xl/workbook.xml",
                """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="S1" sheetId="1" r:id="rId1"/></sheets></workbook>""".toByteArray(),
            )
            put(
                "xl/_rels/workbook.xml.rels",
                """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""".toByteArray(),
            )
            put(
                "xl/worksheets/sheet1.xml",
                """<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>اسم المنتج</t></is></c><c r="B1" t="inlineStr"><is><t>الباركود</t></is></c></row><row r="2"><c r="A2" t="inlineStr"><is><t>منتج بدون صورة</t></is></c><c r="B2" t="inlineStr"><is><t>00998877</t></is></c></row></sheetData></worksheet>""".toByteArray(),
            )
            put(
                "xl/worksheets/_rels/sheet1.xml.rels",
                """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdImg" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>""".toByteArray(),
            )
            put(
                "xl/drawings/drawing1.xml",
                """<?xml version="1.0" encoding="UTF-8"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><xdr:oneCellAnchor><xdr:from><xdr:col>2</xdr:col><xdr:row>99</xdr:row></xdr:from><xdr:pic><xdr:blipFill><a:blip r:embed="rPic1"/></xdr:blipFill></xdr:pic></xdr:oneCellAnchor></xdr:wsDr>""".toByteArray(),
            )
            put(
                "xl/drawings/_rels/drawing1.xml.rels",
                """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rPic1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/></Relationships>""".toByteArray(),
            )
            put("xl/media/image1.png", makePngBytes(Color.YELLOW))
        }

        val parsed = excelImport.parseBytes(out.toByteArray(), "unanchored.xlsx").getOrThrow()
        val sheet = parsed.sheets.first()
        val mapping = excelImport.suggestMappings(sheet.headers)
        val analysis = excelImport.analyzeBeforeImport(sheet, mapping, hasHeaderRow = true)
        assertEquals(0, analysis.anchoredImagesCount)
        assertEquals(1, analysis.unanchoredImages.size)

        val result = excelImport.executeImport(sheet, mapping, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
        assertEquals(0, result.autoLinkedImagesCount)
        assertEquals(1, result.unlinkedImages.size)
        assertTrue(productRepo.findProductByExactBarcode("00998877")!!.images.isEmpty())
    }

    @Test
    fun `xls legacy workbook and csv utf8 roundtrip preserve leading zeros and images`() = runBlocking {
        val wb = HSSFWorkbook()
        val sheet = wb.createSheet("بيانات")
        val header = sheet.createRow(0)
        header.createCell(0).setCellValue("اسم المنتج")
        header.createCell(1).setCellValue("الباركود")
        val r1 = sheet.createRow(1)
        r1.createCell(0).setCellValue("جهاز قياس")
        r1.createCell(1).setCellValue("000554433")

        val picIdx = wb.addPicture(makePngBytes(Color.RED), HSSFWorkbook.PICTURE_TYPE_PNG)
        val patriarch = sheet.createDrawingPatriarch()
        val anchor = HSSFClientAnchor(0, 0, 0, 0, 2, 1, 3, 2)
        patriarch.createPicture(anchor, picIdx)

        val xlsBytes = ByteArrayOutputStream().also { wb.write(it) }.toByteArray()
        wb.close()

        val parsedXls = excelImport.parseBytes(xlsBytes, "legacy.xls").getOrThrow()
        assertEquals("XLS", parsedXls.fileType)
        assertEquals("000554433", parsedXls.sheets.first().rows[1][1])
        assertEquals(1, parsedXls.sheets.first().extractedImages.size)
        assertEquals(1, parsedXls.sheets.first().extractedImages.first().anchoredRowZeroBased)

        val csv = "\uFEFFاسم المنتج,الباركود,السعر\nشاي أخضر,0000112233,25.5\n".toByteArray(Charsets.UTF_8)
        val parsedCsv = excelImport.parseBytes(csv, "items.csv").getOrThrow()
        assertEquals("CSV", parsedCsv.fileType)
        assertEquals("0000112233", parsedCsv.sheets.first().rows[1][1])
    }

    @Test
    fun `excel chunked import benchmark handles 100 1000 and 10000 products`() = runBlocking {
        suspend fun runBatch(count: Int): Long {
            val dbLocal = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
                .allowMainThreadQueries()
                .build()
            val importer = ExcelImportEngine(context, dbLocal, mediaStorage)
            val rows = buildList(count + 1) {
                add(listOf("اسم المنتج", "الباركود الرئيسي", "السعر"))
                for (i in 1..count) {
                    add(listOf("منتج رقم $i", "00${i.toString().padStart(8, '0')}", "${10 + (i % 90)}"))
                }
            }
            val sheet = ParsedSheetData(
                sheetName = "Batch$count",
                headers = rows.first(),
                rows = rows,
                extractedImages = emptyList(),
            )
            val mapping = mapOf(
                0 to ProductImportField.NAME,
                1 to ProductImportField.PRIMARY_BARCODE,
                2 to ProductImportField.BASE_PRICE,
            )
            val t0 = System.currentTimeMillis()
            val res = importer.executeImport(sheet, mapping, hasHeaderRow = true, policy = ImportDuplicatePolicy.SKIP)
            val elapsed = System.currentTimeMillis() - t0
            assertEquals(count, res.insertedCount)
            assertEquals(count, res.barcodesImportedCount)
            val sampleBarcode = "00${count.toString().padStart(8, '0')}"
            assertNotNull(dbLocal.productDao().findBarcodeExact(sampleBarcode))
            dbLocal.close()
            return elapsed
        }

        val t100 = runBatch(100)
        val t1000 = runBatch(1000)
        val t10000 = runBatch(10000)
        println("BENCHMARK_EXCEL_IMPORT: 100=${t100}ms, 1000=${t1000}ms, 10000=${t10000}ms")
        assertTrue(t100 >= 0 && t1000 >= 0 && t10000 >= 0)
    }

    @Test
    @Config(sdk = [34])
    @GraphicsMode(GraphicsMode.Mode.NATIVE)
    fun `pdf generator creates valid multi-page Arabic RTL report PDF across sizes and labels`() = runBlocking {
        val renderedPages = mutableListOf<Bitmap>()
        val recordingFactory = PdfSessionFactory {
            object : PdfSession {
                private val pages = mutableListOf<Bitmap>()
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): android.graphics.Canvas {
                    val bmp = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                    pages.add(bmp)
                    renderedPages.add(bmp)
                    return android.graphics.Canvas(bmp)
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: java.io.OutputStream) {
                    outputStream.write("%PDF-1.4\n% Rendered ${pages.size} pages\n".toByteArray())
                }
                override fun close() = Unit
            }
        }
        val testPdfGen = PdfGeneratorEngine(context, mediaStorage, recordingFactory)
        val testLabelGen = LabelPdfGenerator(context, mediaStorage, recordingFactory)

        val imgPath = mediaStorage.saveProductImageFromBytes(makePngBytes(Color.DKGRAY))!!
        for (i in 1..28) {
            productRepo.createOrUpdateProduct(
                ProductEntity(name = "صنف تجاري عربي طويل نسبياً رقم $i", basePrice = i * 12.5, originCountry = "مصر"),
                listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "00123456${i.toString().padStart(5, '0')}", isPrimary = true)),
                listOf(ProductImageEntity(productId = 0L, filePath = imgPath, isPrimary = true)),
            ).getOrThrow()
        }
        val products = db.productDao().getAllProductsWithDetailsOnce()
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير فحص الجودة المتعدد الصفحات")
        products.forEach { reportRepo.addProductToReport(rid, it) }
        val rptDetails = reportRepo.getReportOnce(rid)!!
        val settings = db.settingsDao().getSettingsOnce() ?: AppSettingsEntity()

        for ((paper, orient) in listOf(
            PaperSizeType.A4 to PageOrientation.PORTRAIT,
            PaperSizeType.A4 to PageOrientation.LANDSCAPE,
            PaperSizeType.A3 to PageOrientation.PORTRAIT,
            PaperSizeType.A5 to PageOrientation.PORTRAIT,
            PaperSizeType.LETTER to PageOrientation.PORTRAIT,
        )) {
            renderedPages.clear()
            val modified = rptDetails.copy(
                report = rptDetails.report.copy(paperSize = paper.name, orientation = orient.name),
            )
            val pdfRes = testPdfGen.generateReportPdf(modified, settings, "test_${paper.name}_${orient.name}.pdf")
            assertTrue(pdfRes.file.exists() && pdfRes.file.length() > 10)
            assertEquals(pdfRes.pageCount, renderedPages.size)
            // Verify non-blank white-background + ink pixels actually drawn on page 1
            val p1 = renderedPages.first()
            var nonWhitePixels = 0
            for (y in 0 until p1.height step 8) {
                for (x in 0 until p1.width step 8) {
                    if (p1.getPixel(x, y) != Color.WHITE) nonWhitePixels++
                }
            }
            assertTrue("Expected rendered table/header ink on ${paper.name} ${orient.name}", nonWhitePixels > 20)
            if (paper == PaperSizeType.A4 && orient == PageOrientation.PORTRAIT) {
                assertTrue("Expected multi-page report for 28 items", pdfRes.pageCount >= 2)
            }
        }

        renderedPages.clear()
        val labelRes = testLabelGen.generateLabelsPdf(
            items = listOf(
                LabelPrintItem("منتج ملصق", "0012345678905", BarcodeFormatType.EAN_13, "25.00 ر.س", copies = 10),
            ),
            config = LabelSheetConfig(),
        )
        assertTrue(labelRes.file.exists())
        assertTrue(labelRes.pageCount >= 1)
        assertEquals(labelRes.pageCount, renderedPages.size)
    }

    @Test
    fun `full zip backup and restore recovers products barcodes images reports and settings cleanly`() = runBlocking {
        val imgPath = mediaStorage.saveProductImageFromBytes(makePngBytes(Color.BLUE))!!
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "شاحن سريع 65W", basePrice = 89.0),
            barcodes = listOf(
                ProductBarcodeEntity(productId = 0L, barcodeValue = "0099112233445", isPrimary = true),
                ProductBarcodeEntity(productId = 0L, barcodeValue = "CHG-BOX-01", isPrimary = false),
            ),
            images = listOf(ProductImageEntity(productId = 0L, filePath = imgPath, isPrimary = true)),
        ).getOrThrow()

        val prod = db.productDao().getProductWithDetails(pid)!!
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير قبل النسخ الاحتياطي")
        reportRepo.addProductToReport(rid, prod)

        val zipFile = backupEngine.createBackupZip("full_verify_backup").getOrThrow()
        assertTrue(zipFile.exists() && zipFile.length() > 0)

        val inspection = backupEngine.inspectBackupBytes(zipFile.readBytes())
        assertTrue(inspection.isValid)
        assertTrue(inspection.missingFiles.isEmpty())
        assertEquals(1, inspection.manifest?.productCount)
        assertEquals(2, inspection.manifest?.barcodeCount)
        assertEquals(1, inspection.manifest?.reportCount)

        // Wipe DB and original files completely
        db.reportDao().deleteAllReports()
        db.productDao().deleteAllProducts()
        File(imgPath).delete()
        assertEquals(0, db.productDao().getAllProductsOnce().size)
        assertEquals(0, db.reportDao().getAllReportsWithDetailsOnce().size)

        // Restore from ZIP
        val restoreResult = backupEngine.restoreFromBackupBytes(zipFile.readBytes(), zipFile.name)
        assertTrue(restoreResult.isSuccess)

        val restoredProd = productRepo.findProductByExactBarcode("0099112233445")
        assertNotNull(restoredProd)
        assertEquals(2, restoredProd!!.barcodes.size)
        assertEquals(1, restoredProd.images.size)
        assertTrue(File(restoredProd.images.first().filePath).exists())

        val restoredReports = db.reportDao().getAllReportsWithDetailsOnce()
        assertEquals(1, restoredReports.size)
        assertEquals("تقرير قبل النسخ الاحتياطي", restoredReports.first().report.title)
        assertEquals(1, restoredReports.first().items.size)
        val restoredSnapPath = restoredReports.first().items.first().item.imageSnapshotPath
        assertTrue(restoredSnapPath.isNotBlank() && File(restoredSnapPath).exists())
    }
}
