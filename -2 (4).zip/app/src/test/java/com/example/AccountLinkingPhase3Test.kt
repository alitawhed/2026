package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import com.example.domain.auth.AuthActionResult
import com.example.domain.auth.AuthConfigurationStatus
import com.example.domain.auth.AuthErrorMapper
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.AuthInputValidator
import com.example.domain.auth.AuthProviderType
import com.example.domain.auth.AuthUserProfile
import com.example.ui.screens.AccountManagementScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class Phase3LinkingFakeAuthGateway : AuthGateway {
    private val _authStateFlow = MutableStateFlow<AuthUserProfile?>(null)
    override val authStateFlow: StateFlow<AuthUserProfile?> = _authStateFlow.asStateFlow()

    var requireRecentLoginOnNextSensitiveAction: Boolean = false
    private val passwordsByEmail = mutableMapOf<String, String>()
    private val usersByEmail = mutableMapOf<String, AuthUserProfile>()

    fun seedVerifiedEmailUser(uid: String, email: String, password: String) {
        val clean = AuthInputValidator.normalizeEmail(email)
        val user = AuthUserProfile(
            uid = uid,
            email = clean,
            displayName = "حساب البريد",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.EMAIL_PASSWORD),
        )
        passwordsByEmail[clean] = password
        usersByEmail[clean] = user
    }

    override fun currentUser(): AuthUserProfile? = _authStateFlow.value

    override fun configurationStatus(): AuthConfigurationStatus = AuthConfigurationStatus(
        isGoogleServicesConfigured = true,
        isFirebaseInitialized = true,
        googleWebClientIdPresent = true,
        statusMessage = "جاهز",
    )

    override suspend fun signInWithGoogleIdToken(idToken: String): AuthActionResult {
        val email = if (idToken == "collision-google-token") "ahmed@example.com" else "google.owner@example.com"
        val existing = usersByEmail[email]
        if (existing != null && !existing.hasGoogleProvider) {
            return AuthActionResult.AccountCollision(
                email = email,
                existingProviderHint = AuthProviderType.EMAIL_PASSWORD.arabicLabel,
                message = "البريد مرتبط مسبقاً بالبريد الإلكتروني وكلمة المرور.",
                pendingGoogleIdToken = idToken,
            )
        }
        val user = existing ?: AuthUserProfile(
            uid = "uid-google-fixed",
            email = email,
            displayName = "مستخدم Google",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.GOOGLE),
        )
        usersByEmail[email] = user
        _authStateFlow.value = user
        return AuthActionResult.Success(user, "تم تسجيل الدخول بحساب Google")
    }

    override suspend fun signInWithEmail(email: String, password: String): AuthActionResult {
        val clean = AuthInputValidator.normalizeEmail(email)
        if (passwordsByEmail[clean] != password) {
            return AuthActionResult.Failure("ERROR_WRONG_PASSWORD", AuthErrorMapper.mapCodeToArabic("ERROR_WRONG_PASSWORD"))
        }
        val user = usersByEmail[clean]!!
        _authStateFlow.value = user
        return if (!user.isAccountVerified) {
            AuthActionResult.RequiresEmailVerification(user, "يرجى تأكيد البريد الإلكتروني")
        } else {
            AuthActionResult.Success(user, "تم تسجيل الدخول")
        }
    }

    override suspend fun registerWithEmail(email: String, password: String, displayName: String): AuthActionResult {
        val clean = AuthInputValidator.normalizeEmail(email)
        val user = AuthUserProfile(
            uid = "uid-email-new",
            email = clean,
            displayName = displayName,
            isEmailVerified = false,
            providers = setOf(AuthProviderType.EMAIL_PASSWORD),
        )
        passwordsByEmail[clean] = password
        usersByEmail[clean] = user
        _authStateFlow.value = user
        return AuthActionResult.RequiresEmailVerification(user, "يرجى التحقق من البريد")
    }

    override suspend fun sendEmailVerification(): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value, "تم الإرسال")

    override suspend fun reloadCurrentUser(): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value, "تم التحديث")

    override suspend fun sendPasswordResetEmail(email: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value, "تم الإرسال")

    override suspend fun updatePassword(currentPassword: String?, newPassword: String): AuthActionResult {
        val u = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        passwordsByEmail[u.email] = newPassword
        return AuthActionResult.Success(u, "تم التحديث")
    }

    override suspend fun linkGoogleIdToken(idToken: String): AuthActionResult {
        val u = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        if (requireRecentLoginOnNextSensitiveAction) {
            return AuthActionResult.RequiresRecentLogin("ربط حساب Google", "يرجى إعادة المصادقة")
        }
        val updated = u.copy(providers = u.providers + AuthProviderType.GOOGLE)
        usersByEmail[updated.email] = updated
        _authStateFlow.value = updated
        return AuthActionResult.Success(updated, "تم ربط حساب Google بنفس المعرّف الثابت")
    }

    override suspend fun linkEmailPassword(email: String, password: String): AuthActionResult {
        val u = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        if (requireRecentLoginOnNextSensitiveAction) {
            return AuthActionResult.RequiresRecentLogin("ربط البريد وكلمة المرور", "يرجى إعادة المصادقة")
        }
        val clean = AuthInputValidator.normalizeEmail(email)
        passwordsByEmail[clean] = password
        val updated = u.copy(email = clean, providers = u.providers + AuthProviderType.EMAIL_PASSWORD)
        usersByEmail[clean] = updated
        _authStateFlow.value = updated
        return AuthActionResult.Success(updated, "تم ربط البريد وكلمة المرور بنفس المعرّف الثابت")
    }

    override suspend fun unlinkProvider(providerType: AuthProviderType): AuthActionResult {
        val u = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        if (u.providers.size <= 1) {
            return AuthActionResult.Failure("LAST_PROVIDER", "لا يمكن فك ربط الوسيلة الوحيدة")
        }
        if (requireRecentLoginOnNextSensitiveAction) {
            return AuthActionResult.RequiresRecentLogin("فك ربط ${providerType.arabicLabel}", "يرجى إعادة المصادقة")
        }
        val updated = u.copy(providers = u.providers - providerType)
        usersByEmail[updated.email] = updated
        _authStateFlow.value = updated
        return AuthActionResult.Success(updated, "تم فك الربط مع الإبقاء على نفس الحساب")
    }

    override suspend fun reauthenticateWithGoogleIdToken(idToken: String): AuthActionResult {
        requireRecentLoginOnNextSensitiveAction = false
        return AuthActionResult.Success(_authStateFlow.value, "تمت إعادة المصادقة عبر Google")
    }

    override suspend fun reauthenticateWithEmailPassword(email: String, password: String): AuthActionResult {
        val clean = AuthInputValidator.normalizeEmail(email)
        if (passwordsByEmail[clean] != password) {
            return AuthActionResult.Failure("ERROR_WRONG_PASSWORD", "كلمة المرور غير صحيحة")
        }
        requireRecentLoginOnNextSensitiveAction = false
        return AuthActionResult.Success(_authStateFlow.value, "تمت إعادة المصادقة بكلمة المرور")
    }

    override suspend fun signOut(): AuthActionResult {
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم تسجيل الخروج")
    }

    override suspend fun deleteCurrentAccount(): AuthActionResult {
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم الحذف")
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AccountLinkingPhase3Test {

    @get:Rule
    val composeRule = createComposeRule()

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `linking email password onto Google account preserves exact UID and prevents duplicate account`() = runTest(testDispatcher) {
        val gateway = Phase3LinkingFakeAuthGateway()
        val vm = AuthViewModel(authGateway = gateway)

        vm.signInWithGoogleIdTokenDirect("google-token-1")
        advanceUntilIdle()
        val initialUid = vm.uiState.value.currentUser?.uid
        assertEquals("uid-google-fixed", initialUid)

        vm.updateLinkEmailPasswordInputs(
            email = "google.owner@example.com",
            password = "StrongLink2026",
            confirmPassword = "StrongLink2026",
        )
        vm.linkEmailPassword()
        advanceUntilIdle()

        val linkedUser = vm.uiState.value.currentUser!!
        assertEquals(initialUid, linkedUser.uid)
        assertTrue(linkedUser.hasGoogleProvider)
        assertTrue(linkedUser.hasEmailPasswordProvider)
        assertEquals(2, linkedUser.providers.size)

        // Sign out and sign back in via Email/Password -> lands on exact same UID
        vm.signOut()
        advanceUntilIdle()
        vm.updateEmail("google.owner@example.com")
        vm.updatePassword("StrongLink2026")
        vm.signInWithEmail()
        advanceUntilIdle()
        assertEquals(initialUid, vm.uiState.value.currentUser?.uid)
    }

    @Test
    fun `unverified email account cannot link Google until verified`() = runTest(testDispatcher) {
        val gateway = Phase3LinkingFakeAuthGateway()
        val vm = AuthViewModel(authGateway = gateway)

        vm.updateDisplayName("أحمد")
        vm.updateEmail("unverified@example.com")
        vm.updatePassword("Pass12345")
        vm.updateConfirmPassword("Pass12345")
        vm.registerWithEmail()
        advanceUntilIdle()

        vm.linkGoogleIdTokenDirect("google-token-2")
        advanceUntilIdle()
        assertFalse(vm.uiState.value.currentUser!!.hasGoogleProvider)
        assertTrue(vm.uiState.value.errorMessage.orEmpty().contains("توثيق البريد"))
    }

    @Test
    fun `account collision triggers resolution flow that links Google onto existing verified UID`() = runTest(testDispatcher) {
        val gateway = Phase3LinkingFakeAuthGateway()
        gateway.seedVerifiedEmailUser("uid-ahmed-original", "ahmed@example.com", "OriginalPass123")
        val vm = AuthViewModel(authGateway = gateway)

        // User tries Google Sign-In first -> collision reported cleanly
        vm.signInWithGoogleIdTokenDirect("collision-google-token")
        advanceUntilIdle()
        assertNull(vm.uiState.value.currentUser)
        assertEquals("ahmed@example.com", vm.uiState.value.collisionEmail)
        assertNotNull(vm.uiState.value.collisionPendingGoogleIdToken)

        // User enters original account password to authenticate and link cleanly onto same UID
        vm.resolveCollisionByEmailSignInAndLink("OriginalPass123")
        advanceUntilIdle()
        assertNull(vm.uiState.value.collisionEmail)
        val resolved = vm.uiState.value.currentUser!!
        assertEquals("uid-ahmed-original", resolved.uid)
        assertTrue(resolved.hasEmailPasswordProvider)
        assertTrue(resolved.hasGoogleProvider)
    }

    @Test
    fun `unlink requires more than one provider and retries automatically after reauthentication`() = runTest(testDispatcher) {
        val gateway = Phase3LinkingFakeAuthGateway()
        gateway.seedVerifiedEmailUser("uid-reauth-test", "owner@example.com", "OwnerPass99")
        val vm = AuthViewModel(authGateway = gateway)

        vm.updateEmail("owner@example.com")
        vm.updatePassword("OwnerPass99")
        vm.signInWithEmail()
        advanceUntilIdle()

        // Guard: cannot unlink sole provider
        vm.unlinkProvider(AuthProviderType.EMAIL_PASSWORD)
        advanceUntilIdle()
        assertTrue(vm.uiState.value.errorMessage.orEmpty().contains("الوحيدة"))
        assertEquals(1, vm.uiState.value.currentUser!!.providers.size)

        // Link Google first -> 2 providers
        vm.linkGoogleIdTokenDirect("google-token-ok")
        advanceUntilIdle()
        assertEquals(2, vm.uiState.value.currentUser!!.providers.size)

        // Require recent login before unlinking -> triggers reauth -> auto-completes unlink!
        gateway.requireRecentLoginOnNextSensitiveAction = true
        vm.unlinkProvider(AuthProviderType.GOOGLE)
        advanceUntilIdle()
        assertNotNull(vm.uiState.value.requiresRecentLoginOperation)
        assertTrue(vm.uiState.value.currentUser!!.hasGoogleProvider)

        vm.reauthenticateWithEmail("OwnerPass99")
        advanceUntilIdle()
        assertNull(vm.uiState.value.requiresRecentLoginOperation)
        assertFalse(vm.uiState.value.currentUser!!.hasGoogleProvider)
        assertTrue(vm.uiState.value.currentUser!!.hasEmailPasswordProvider)
        assertEquals("uid-reauth-test", vm.uiState.value.currentUser!!.uid)
    }

    @Test
    @Config(sdk = [34], qualifiers = "w411dp-h915dp")
    fun `account management screen displays fixed UID, linked providers, and supports email link dialog`() {
        Dispatchers.resetMain()
        val gateway = Phase3LinkingFakeAuthGateway()
        val vm = AuthViewModel(authGateway = gateway)

        vm.signInWithGoogleIdTokenDirect("google-ui-token")
        composeRule.waitForIdle()
        vm.clearMessages()

        composeRule.setContent {
            ReportManagerTheme {
                AccountManagementScreen(
                    viewModel = vm,
                    onBack = {},
                    onOpenAuthScreen = {},
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("account_uid_label").performScrollTo().assertIsDisplayed()
        // Only Google is linked initially, so unlink Google button is disabled ("أساسي")
        composeRule.onNodeWithTag("account_unlink_google_btn").performScrollTo().assertIsNotEnabled()
        // Open Link Email dialog and complete linking
        composeRule.onNodeWithTag("account_link_email_btn").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("account_link_password_input").performScrollTo().performTextInput("SecureLink2026")
        composeRule.onNodeWithTag("account_link_confirm_password_input").performScrollTo().performTextInput("SecureLink2026")
        composeRule.onNodeWithTag("account_confirm_link_email_btn").performScrollTo().performClick()

        val deadline = System.currentTimeMillis() + 3_000L
        while (!vm.uiState.value.currentUser!!.hasEmailPasswordProvider && System.currentTimeMillis() < deadline) {
            Thread.sleep(20)
        }

        assertTrue(vm.uiState.value.currentUser!!.hasEmailPasswordProvider)
        assertTrue(vm.uiState.value.currentUser!!.hasGoogleProvider)
        assertEquals("uid-google-fixed", vm.uiState.value.currentUser!!.uid)
    }
}
