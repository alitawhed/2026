package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.TemplateDefaults
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.AddProductToReportResult
import com.example.data.repository.DuplicateBarcodeException
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.model.DuplicateProductBehavior
import com.example.domain.model.TemplateKind
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DatabaseAndRepositoriesTest {

    private lateinit var context: Context
    private lateinit var dbFile: File
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        dbFile = File(context.cacheDir, "test_report_mgr_${System.nanoTime()}.db")
        db = createFileDb()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
        dbFile.delete()
    }

    private fun createFileDb(): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()

    private fun samplePngBytes(color: Int = android.graphics.Color.BLUE): ByteArray {
        val bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        return ByteArrayOutputStream().use { bos ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            bos.toByteArray()
        }
    }

    @Test
    fun `seeded database contains 10 distinct templates default settings and zero fake products`() = runBlocking {
        val templates = db.templateDao().getAllTemplatesOnce()
        assertEquals(10, templates.size)
        val types = templates.map { it.templateKind }.toSet()
        assertEquals(TemplateKind.entries.size, types.size)

        val settings = db.settingsDao().getSettingsOnce()
        assertNotNull(settings)
        assertEquals("المهندس علي توحيد", settings?.developerName)
        assertEquals("+966573928022", settings?.developerPhone)

        assertEquals(0, db.productDao().getAllProductsOnce().size)
        assertEquals(0, db.reportDao().getAllReportsWithDetailsOnce().size)
    }

    @Test
    fun `multi-barcode product persists across DB reopen and prevents global duplicates`() = runBlocking {
        val codes = listOf(
            "0012345678905", // Leading zeros preserved
            "00987654",
            "CARTON-001",
            "PACK-002",
            "LEGACY-003",
        )
        val productId = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "شامبو طبيعي 500 مل", basePrice = 34.5, categoryName = "عناية"),
            barcodes = codes.mapIndexed { idx, code ->
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = code,
                    barcodeType = if (idx == 0) "EAN_13" else "CODE_128",
                    label = "وحدة $idx",
                    isPrimary = idx == 0,
                )
            },
            images = emptyList(),
        ).getOrThrow()

        // Search by EVERY one of the 5 barcodes
        for (c in codes) {
            val found = productRepo.findProductByExactBarcode(c)
            assertNotNull("Expected to find product by barcode $c", found)
            assertEquals(productId, found!!.product.id)
        }

        // Duplicate barcode rejection with conflict details
        val dupResult = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج منافس"),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "CARTON-001", isPrimary = true)),
            images = emptyList(),
        )
        assertTrue(dupResult.isFailure)
        val ex = dupResult.exceptionOrNull() as? DuplicateBarcodeException
        assertNotNull(ex)
        assertEquals(productId, ex!!.conflictingProductId)
        assertEquals("شامبو طبيعي 500 مل", ex.conflictingProductName)

        // Change primary barcode cleanly
        val savedDetails = db.productDao().getProductWithDetails(productId)!!
        val secondBarcode = savedDetails.barcodes.first { it.barcodeValue == "00987654" }
        productRepo.setPrimaryBarcode(productId, secondBarcode.id)
        val updatedDetails = db.productDao().getProductWithDetails(productId)!!
        assertEquals("00987654", updatedDetails.primaryBarcode?.barcodeValue)

        // Close and reopen SQLite database file to verify persistence
        db.close()
        db = createFileDb()
        val reopenedProduct = db.productDao().getProductWithDetails(productId)
        assertNotNull(reopenedProduct)
        assertEquals(5, reopenedProduct!!.barcodes.size)
        assertEquals("00987654", reopenedProduct.primaryBarcode?.barcodeValue)
    }

    @Test
    fun `reports always start empty and maintain immutable snapshots isolated from product mutations`() = runBlocking {
        val imgPath = mediaStorage.saveProductImageFromBytes(samplePngBytes(android.graphics.Color.RED))!!
        val productId = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "عطر فاخر", basePrice = 150.0, originCountry = "فرنسا"),
            barcodes = listOf(
                ProductBarcodeEntity(productId = 0L, barcodeValue = "0011223344557", barcodeType = "EAN_13", isPrimary = true),
            ),
            images = listOf(ProductImageEntity(productId = 0L, filePath = imgPath, isPrimary = true)),
        ).getOrThrow()

        val reportId = reportRepo.createEmptyReport(customTitle = "عرض أسعار مبدئي")
        val emptyReport = reportRepo.getReportOnce(reportId)!!
        assertEquals(0, emptyReport.items.size)

        val productDetails = db.productDao().getProductWithDetails(productId)!!
        val addRes = reportRepo.addProductToReport(reportId, productDetails)
        assertTrue(addRes is AddProductToReportResult.Added)

        val beforeMutation = reportRepo.getReportOnce(reportId)!!
        assertEquals(1, beforeMutation.items.size)
        val snapshotImgPath = beforeMutation.items.first().item.imageSnapshotPath
        assertTrue(snapshotImgPath.isNotBlank() && File(snapshotImgPath).exists())
        assertFalse(snapshotImgPath == imgPath) // Copied into report snapshot dir

        // Mutate source product price, name & replace image
        val newImgPath = mediaStorage.saveProductImageFromBytes(samplePngBytes(android.graphics.Color.GREEN))!!
        productRepo.createOrUpdateProduct(
            product = productDetails.product.copy(name = "عطر فاخر مطور", basePrice = 299.0),
            barcodes = productDetails.barcodes,
            images = listOf(ProductImageEntity(productId = productId, filePath = newImgPath, isPrimary = true)),
        ).getOrThrow()

        // Verify historical report retains original price, name, and snapshot image
        val afterMutation = reportRepo.getReportOnce(reportId)!!
        val snapItem = afterMutation.items.first().item
        assertEquals("عطر فاخر", snapItem.productNameSnapshot)
        assertEquals(150.0, snapItem.unitPrice, 0.001)
        assertTrue(File(snapItem.imageSnapshotPath).exists())

        // Delete item from report -> source product and its image remain intact
        reportRepo.deleteReportItem(reportId, snapItem.id)
        assertEquals(0, reportRepo.getReportOnce(reportId)!!.items.size)
        val survivingProduct = db.productDao().getProductWithDetails(productId)
        assertNotNull(survivingProduct)
        assertEquals(1, survivingProduct!!.images.size)
        assertTrue(File(survivingProduct.images.first().filePath).exists())
    }

    @Test
    fun `report duplicate product behaviors INCREMENT_QTY NEW_ROW and PREVENT work as specified`() = runBlocking {
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "قهوة عربية", basePrice = 40.0, defaultQuantity = 2.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "COFFEE-01", isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()
        val prod = db.productDao().getProductWithDetails(pid)!!

        val rid = reportRepo.createEmptyReport()
        assertTrue(reportRepo.addProductToReport(rid, prod) is AddProductToReportResult.Added)

        // Default is INCREMENT_QTY
        val resInc = reportRepo.addProductToReport(rid, prod)
        assertTrue(resInc is AddProductToReportResult.IncrementedExisting)
        assertEquals(4.0, (resInc as AddProductToReportResult.IncrementedExisting).newQty, 0.001)

        // Switch to PREVENT
        val rpt = reportRepo.getReportOnce(rid)!!.report
        reportRepo.updateReport(rpt.copy(duplicateBehavior = DuplicateProductBehavior.PREVENT.name))
        assertTrue(reportRepo.addProductToReport(rid, prod) is AddProductToReportResult.PreventedDuplicate)

        // Switch to NEW_ROW
        reportRepo.updateReport(rpt.copy(duplicateBehavior = DuplicateProductBehavior.NEW_ROW.name))
        assertTrue(reportRepo.addProductToReport(rid, prod) is AddProductToReportResult.Added)
        assertEquals(2, reportRepo.getReportOnce(rid)!!.items.size)
    }
}
