package com.example

import android.app.Activity
import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.android.billingclient.api.BillingClient.BillingResponseCode
import com.android.billingclient.api.BillingClient.OnPurchasesUpdatedSubResponseCode
import com.android.billingclient.api.BillingResult
import com.example.data.local.AppDatabase
import com.example.di.SharedAppServices
import com.example.domain.billing.BillingActionResult
import com.example.domain.billing.BillingConfigStore
import com.example.domain.billing.BillingConnectionState
import com.example.domain.billing.BillingErrorMapper
import com.example.domain.billing.BillingGateway
import com.example.domain.billing.BillingPeriodParser
import com.example.domain.billing.FeatureAccessDecision
import com.example.domain.billing.FreeFeature
import com.example.domain.billing.PlayBillingConfiguration
import com.example.domain.billing.PlayBillingManager
import com.example.domain.billing.ProFeature
import com.example.domain.billing.SubscriptionEntitlementState
import com.example.domain.billing.SubscriptionOfferUiModel
import com.example.domain.billing.SubscriptionPlanType
import com.example.domain.billing.SubscriptionStatus
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.TemplatesScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.SubscriptionViewModel
import com.example.ui.viewmodel.TemplatesViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class FakeBillingGateway(
    private val configStore: BillingConfigStore,
) : BillingGateway {
    private val _connectionState = MutableStateFlow(BillingConnectionState.CONNECTED)
    override val connectionState: StateFlow<BillingConnectionState> = _connectionState.asStateFlow()

    private val _availableOffers = MutableStateFlow<List<SubscriptionOfferUiModel>>(emptyList())
    override val availableOffers: StateFlow<List<SubscriptionOfferUiModel>> = _availableOffers.asStateFlow()

    private val _entitlementState = MutableStateFlow(SubscriptionEntitlementState())
    override val entitlementState: StateFlow<SubscriptionEntitlementState> = _entitlementState.asStateFlow()

    override val billingConfiguration: StateFlow<PlayBillingConfiguration> = configStore.configuration

    private val _lastStatusMessage = MutableStateFlow<String?>(null)
    override val lastStatusMessage: StateFlow<String?> = _lastStatusMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    override val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    var restoreResultEntitlement: SubscriptionEntitlementState? = null
    var playSubscriptionsOpened = false

    fun setOffers(offers: List<SubscriptionOfferUiModel>) {
        _availableOffers.value = offers
    }

    fun setEntitlement(state: SubscriptionEntitlementState) {
        _entitlementState.value = state
    }

    override fun connectAndRefresh(onComplete: (() -> Unit)?) {
        onComplete?.invoke()
    }

    override suspend fun refreshProductsAndPurchases(): BillingActionResult =
        BillingActionResult.Success("تم التحديث")

    override suspend fun launchSubscriptionPurchase(
        activity: Activity,
        offer: SubscriptionOfferUiModel,
        obfuscatedAccountUid: String?,
    ): BillingActionResult {
        val next = SubscriptionEntitlementState(
            status = if (offer.hasFreeTrial) SubscriptionStatus.TRIAL else SubscriptionStatus.ACTIVE,
            planType = offer.planType,
            activeProductId = offer.productId,
            activeBasePlanId = offer.basePlanId,
            purchaseToken = "tok_${offer.planType.name}",
            isAutoRenewing = true,
            isAcknowledged = true,
            linkedAuthUid = obfuscatedAccountUid,
            lastCheckedMs = System.currentTimeMillis(),
        )
        _entitlementState.value = next
        _lastStatusMessage.value = "تم تفعيل الاشتراك الاحترافي بنجاح."
        return BillingActionResult.Success("تم تفعيل الاشتراك")
    }

    override suspend fun restorePurchases(): BillingActionResult {
        val target = restoreResultEntitlement
        return if (target != null) {
            _entitlementState.value = target
            _lastStatusMessage.value = "تمت استعادة الاشتراك النشط بنجاح."
            BillingActionResult.Success("تمت الاستعادة")
        } else {
            BillingActionResult.Failure("لم يتم العثور على اشتراكات نشطة.")
        }
    }

    override suspend fun updateBillingConfiguration(config: PlayBillingConfiguration) {
        configStore.saveConfiguration(config)
    }

    override fun consumeStatusMessage() {
        _lastStatusMessage.value = null
    }

    override fun openPlaySubscriptionsCenter(context: Context) {
        playSubscriptionsOpened = true
    }

    override fun release() = Unit
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BillingAndSubscriptionPhase56Test {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        BillingConfigStore(context).apply {
            clearConfiguration()
            clearCachedEntitlement()
        }
    }

    @Test
    fun `entitlement manager enforces free vs pro split across all lifecycle statuses`() {
        val store = BillingConfigStore(context)
        val fakeBilling = FakeBillingGateway(store)
        val shared = SharedAppServices(context, billingGatewayOverride = fakeBilling)
        val mgr = shared.entitlementManager

        val nonProStatuses = listOf(
            SubscriptionStatus.FREE,
            SubscriptionStatus.PENDING,
            SubscriptionStatus.ON_HOLD_EXPIRED,
        )
        for (st in nonProStatuses) {
            fakeBilling.setEntitlement(SubscriptionEntitlementState(status = st))
            assertFalse("Status $st must not grant Pro", mgr.isProActive())
            FreeFeature.entries.forEach { freeFeat ->
                assertTrue("Free feature $freeFeat must ALWAYS stay open in $st", mgr.canAccessFreeFeature(freeFeat))
            }
            ProFeature.entries.forEach { proFeat ->
                assertTrue(
                    "Pro feature $proFeat must require upgrade in $st",
                    mgr.checkProFeatureAccess(proFeat) is FeatureAccessDecision.RequiresProUpgrade,
                )
            }
        }

        val proStatuses = listOf(
            SubscriptionStatus.TRIAL,
            SubscriptionStatus.ACTIVE,
            SubscriptionStatus.CANCELLED_GRACE,
        )
        for (st in proStatuses) {
            fakeBilling.setEntitlement(
                SubscriptionEntitlementState(
                    status = st,
                    planType = SubscriptionPlanType.PRO_YEARLY,
                    isAcknowledged = true,
                ),
            )
            assertTrue("Status $st must grant Pro", mgr.isProActive())
            ProFeature.entries.forEach { proFeat ->
                assertEquals(FeatureAccessDecision.Allowed, mgr.checkProFeatureAccess(proFeat))
            }
        }
    }

    @Test
    fun `billing config store and error mapper and period parser behave accurately without hardcoded ids`() {
        val store = BillingConfigStore(context)
        assertFalse(store.currentConfiguration().isConfigured)
        assertTrue(store.currentConfiguration().allConfiguredProductIds().isEmpty())

        store.saveConfiguration(
            PlayBillingConfiguration(
                subscriptionProductId = "report_manager_pro",
                monthlyBasePlanId = "monthly-base",
                yearlyBasePlanId = "yearly-base",
                trialOfferId = "trial-7d",
            ),
        )
        val loaded = store.currentConfiguration()
        assertTrue(loaded.isConfigured)
        assertEquals(listOf("report_manager_pro"), loaded.allConfiguredProductIds())
        assertEquals(
            SubscriptionPlanType.PRO_YEARLY,
            PlayBillingManager.resolvePlanType("report_manager_pro", "yearly-base", loaded, null),
        )
        assertEquals(
            SubscriptionPlanType.PRO_MONTHLY,
            PlayBillingManager.resolvePlanType("report_manager_pro", "monthly-base", loaded, null),
        )

        assertEquals(7, BillingPeriodParser.parseDays("P7D"))
        assertEquals(7, BillingPeriodParser.parseDays("P1W"))
        assertEquals(30, BillingPeriodParser.parseDays("P1M"))
        assertEquals(365, BillingPeriodParser.parseDays("P1Y"))

        val ineligible = BillingResult.newBuilder()
            .setResponseCode(BillingResponseCode.DEVELOPER_ERROR)
            .setOnPurchasesUpdatedSubResponseCode(OnPurchasesUpdatedSubResponseCode.USER_INELIGIBLE)
            .build()
        assertTrue(BillingErrorMapper.toArabicMessage(ineligible).contains("غير مؤهل"))
        assertTrue(BillingErrorMapper.toArabicMessage(BillingResponseCode.USER_CANCELED).contains("إلغاء"))
        assertTrue(BillingErrorMapper.toArabicMessage(BillingResponseCode.ITEM_ALREADY_OWNED).contains("استعادة المشتريات"))
    }

    @Test
    fun `subscription screen renders manual setup when unconfigured and real offers with restore when configured`() {
        val store = BillingConfigStore(context)
        val fakeBilling = FakeBillingGateway(store)
        val shared = SharedAppServices(context, billingGatewayOverride = fakeBilling)
        val container = shared.workspaceManager.currentContainer()
        val subVm = SubscriptionViewModel(container)

        composeRule.setContent {
            ReportManagerTheme {
                SubscriptionScreen(
                    viewModel = subVm,
                    onBack = {},
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("subscription_not_configured_card").assertIsDisplayed()

        // Now configure real Play Console offers + trial
        runBlocking {
            fakeBilling.updateBillingConfiguration(
                PlayBillingConfiguration(
                    subscriptionProductId = "report_pro",
                    monthlyBasePlanId = "monthly",
                    yearlyBasePlanId = "yearly",
                ),
            )
            fakeBilling.setOffers(
                listOf(
                    SubscriptionOfferUiModel(
                        productId = "report_pro",
                        basePlanId = "monthly",
                        offerToken = "tok_m",
                        planType = SubscriptionPlanType.PRO_MONTHLY,
                        title = "الباقة الشهرية",
                        formattedPrice = "19.99 SAR",
                        billingPeriodIso = "P1M",
                        billingPeriodArabic = "شهرياً",
                        hasFreeTrial = false,
                    ),
                    SubscriptionOfferUiModel(
                        productId = "report_pro",
                        basePlanId = "yearly",
                        offerId = "trial-7d",
                        offerToken = "tok_y",
                        planType = SubscriptionPlanType.PRO_YEARLY,
                        title = "الباقة السنوية",
                        formattedPrice = "149.99 SAR",
                        billingPeriodIso = "P1Y",
                        billingPeriodArabic = "سنوياً",
                        hasFreeTrial = true,
                        freeTrialDays = 7,
                        freeTrialLabel = "تجربة مجانية لمدة 7 أيام",
                    ),
                ),
            )
            fakeBilling.restoreResultEntitlement = SubscriptionEntitlementState(
                status = SubscriptionStatus.ACTIVE,
                planType = SubscriptionPlanType.PRO_YEARLY,
                activeProductId = "report_pro",
                activeBasePlanId = "yearly",
                isAutoRenewing = true,
                isAcknowledged = true,
            )
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("subscription_screen_list")
            .performScrollToNode(hasTestTag("subscription_offer_card_PRO_MONTHLY"))
        composeRule.onNodeWithTag("subscription_offer_card_PRO_MONTHLY").assertIsDisplayed()
        composeRule.onNodeWithTag("subscription_screen_list")
            .performScrollToNode(hasTestTag("subscription_offer_card_PRO_YEARLY"))
        composeRule.onNodeWithTag("subscription_offer_card_PRO_YEARLY").assertIsDisplayed()
        composeRule.onNodeWithTag("subscription_trial_badge_PRO_YEARLY").assertIsDisplayed()

        composeRule.onNodeWithTag("subscription_screen_list")
            .performScrollToNode(hasTestTag("subscription_restore_btn"))
        composeRule.onNodeWithTag("subscription_restore_btn").performClick()
        composeRule.waitForIdle()

        assertTrue(fakeBilling.entitlementState.value.isProEntitled)
        assertEquals(SubscriptionPlanType.PRO_YEARLY, fakeBilling.entitlementState.value.planType)

        composeRule.onNodeWithTag("subscription_manage_play_btn").performClick()
        assertTrue(fakeBilling.playSubscriptionsOpened)
    }

    @Test
    fun `templates screen shows pro upgrade dialog when free and opens editor when pro active`() {
        val store = BillingConfigStore(context)
        val fakeBilling = FakeBillingGateway(store)
        val shared = SharedAppServices(context, billingGatewayOverride = fakeBilling)
        val container = shared.workspaceManager.currentContainer()
        runBlocking { AppDatabase.ensureSeeded(container.database) }
        val templatesVm = TemplatesViewModel(container)
        var navigatedToSub = false

        composeRule.setContent {
            ReportManagerTheme {
                TemplatesScreen(
                    viewModel = templatesVm,
                    onBack = {},
                    onOpenNewReport = {},
                    onOpenSubscription = { navigatedToSub = true },
                )
            }
        }

        val deadline = System.currentTimeMillis() + 3000L
        while (templatesVm.templates.value.isEmpty() && System.currentTimeMillis() < deadline) {
            composeRule.waitForIdle()
            Thread.sleep(50)
        }
        val firstTpl = templatesVm.templates.value.first()
        composeRule.waitForIdle()

        // Tap edit template while FREE -> shows ProUpgradeDialog
        composeRule.onNodeWithTag("template_card_${firstTpl.id}").assertIsDisplayed()
        composeRule.onAllNodesWithTag("pro_upgrade_dialog_subscribe_btn").let { nodes ->
            assertEquals(0, nodes.fetchSemanticsNodes().size)
        }
        composeRule.onNodeWithTag("apply_template_${firstTpl.id}").assertIsDisplayed()
        // Trigger edit template (edit/copy/import are Pro gated)
        composeRule.onAllNodes(hasContentDescription("تعديل القالب"))[0].performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("pro_upgrade_dialog_subscribe_btn").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertTrue(navigatedToSub)

        // Grant Pro entitlement -> Edit Template dialog opens cleanly without paywall
        fakeBilling.setEntitlement(
            SubscriptionEntitlementState(
                status = SubscriptionStatus.ACTIVE,
                planType = SubscriptionPlanType.PRO_MONTHLY,
                isAcknowledged = true,
            ),
        )
        composeRule.waitForIdle()
        composeRule.onAllNodes(hasContentDescription("تعديل القالب"))[0].performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("تعديل القالب").assertIsDisplayed()
    }

    @Test
    fun `settings admin panel displays live system status and persists play billing product config`() {
        val store = BillingConfigStore(context)
        val fakeBilling = FakeBillingGateway(store)
        val shared = SharedAppServices(context, billingGatewayOverride = fakeBilling)
        val container = shared.workspaceManager.currentContainer()
        val settingsVm = SettingsViewModel(container)

        composeRule.setContent {
            ReportManagerTheme {
                SettingsScreen(
                    viewModel = settingsVm,
                    onOpenBackup = {},
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_list")
            .performScrollToNode(hasTestTag("settings_admin_status_card"))
        composeRule.onNodeWithTag("settings_admin_status_card").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_toggle_billing_config_btn").performScrollTo().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_billing_sub_product_id").performScrollTo().performTextInput("pro_sub_id")
        composeRule.onNodeWithTag("settings_billing_monthly_bp_id").performScrollTo().performTextInput("monthly_bp")
        composeRule.onNodeWithTag("settings_billing_yearly_bp_id").performScrollTo().performTextInput("yearly_bp")
        composeRule.onNodeWithTag("settings_save_billing_config_btn").performScrollTo().assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.waitUntil(3000) { store.currentConfiguration().subscriptionProductId == "pro_sub_id" }

        val saved = store.currentConfiguration()
        assertEquals("pro_sub_id", saved.subscriptionProductId)
        assertEquals("monthly_bp", saved.monthlyBasePlanId)
        assertEquals("yearly_bp", saved.yearlyBasePlanId)
    }
}
