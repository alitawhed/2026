package com.example

import android.content.Context
import android.content.ContextWrapper
import android.database.sqlite.SQLiteConstraintException
import android.graphics.Bitmap
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.InventoryRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportRepository
import com.example.data.storage.ImageEditParameters
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.diagnostics.DiagnosticExportEngine
import com.example.domain.diagnostics.DiagnosticModules
import com.example.domain.diagnostics.DiagnosticsFileStore
import com.example.domain.diagnostics.GlobalErrorMonitor
import com.example.domain.diagnostics.LogSeverity
import com.example.domain.diagnostics.OperationLogger
import com.example.domain.diagnostics.OperationOutcome
import com.example.domain.diagnostics.ScreenNames
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.pdf.LabelPdfGenerator
import com.example.domain.pdf.LabelPrintItem
import com.example.domain.pdf.LabelSheetConfig
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DiagnosticsAndCrossDeviceRestoreTest {

    private lateinit var baseContext: Context
    private lateinit var rootSandbox: File

    @Before
    fun setup() {
        baseContext = ApplicationProvider.getApplicationContext()
        rootSandbox = File(baseContext.cacheDir, "diag_test_${System.nanoTime()}").apply { mkdirs() }
    }

    @After
    fun tearDown() {
        rootSandbox.deleteRecursively()
    }

    private fun isolatedDeviceContext(deviceTag: String): Context {
        val deviceRoot = File(rootSandbox, deviceTag).apply { mkdirs() }
        val files = File(deviceRoot, "files").apply { mkdirs() }
        val cache = File(deviceRoot, "cache").apply { mkdirs() }
        return object : ContextWrapper(baseContext) {
            override fun getFilesDir(): File = files
            override fun getCacheDir(): File = cache
            override fun getApplicationContext(): Context = this
        }
    }

    private fun makePngBytes(color: Int = Color.BLUE, sizePx: Int = 64): ByteArray {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    @Test
    fun `global error monitor captures all 9 fault domains, groups recurring errors, and recovers crash on restart`() = runBlocking {
        val devCtx = isolatedDeviceContext("fault_domains_device")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(db)

        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val mediaStorage = MediaStorageManager(devCtx, monitor)
        val inventoryRepo = InventoryRepository(db, monitor)
        val productRepo = ProductRepository(db, mediaStorage, monitor)
        val reportRepo = ReportRepository(db, mediaStorage, monitor)
        val excelImport = ExcelImportEngine(devCtx, db, mediaStorage, errorMonitor = monitor)
        val backupEngine = BackupRestoreEngine(devCtx, db, mediaStorage, monitor)

        // Seed target DB records that MUST survive a failed ZIP restore intact
        val existingImg = mediaStorage.saveProductImageFromBytes(makePngBytes(Color.GREEN))!!
        val preservedPid = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "KEEP-1", name = "منتج حرج يجب عدم حذفه", basePrice = 99.5),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "0077777777777", isPrimary = true)),
            images = listOf(ProductImageEntity(productId = 0L, filePath = existingImg, isPrimary = true)),
        ).getOrThrow()
        val preservedProduct = db.productDao().getProductWithDetails(preservedPid)!!
        val preservedReportId = reportRepo.createEmptyReport(customTitle = "تقرير محمي قبل الاستعادة")
        reportRepo.addProductToReport(preservedReportId, preservedProduct)
        val preservedSessionId = inventoryRepo.createSession("جرد محمي قبل الفشل").getOrThrow()

        // 1) Domain 1: Products repository failure + duplicate/recurring fingerprint grouping + review
        val brokenDb = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        brokenDb.openHelper.writableDatabase.execSQL("DROP TABLE Products")
        val failingProductRepo = ProductRepository(brokenDb, mediaStorage, monitor)
        repeat(2) {
            val res = failingProductRepo.createOrUpdateProduct(
                product = ProductEntity(name = "منتج متعثر"),
                barcodes = emptyList(),
                images = emptyList(),
            )
            assertTrue(res.isFailure)
        }
        brokenDb.close()
        val productError = monitor.errors.value.firstOrNull {
            it.moduleName == DiagnosticModules.PRODUCTS && it.screenName == ScreenNames.PRODUCT_EDITOR
        }
        assertNotNull("Expected product failure captured", productError)
        assertEquals(2, productError!!.occurrenceCount)
        assertTrue(productError.isRecurring)
        assertTrue(productError.sourceFile.isNotBlank())
        assertTrue(productError.lineNumber > 0)
        assertTrue(productError.functionName.isNotBlank())
        assertTrue(productError.stackTrace.isNotBlank())
        assertEquals(1, monitor.getSimilarErrors(productError.fingerprint).size)
        monitor.markErrorReviewed(productError.errorId, reviewed = true)
        assertTrue(monitor.errors.value.first { it.errorId == productError.errorId }.isReviewed)

        // 2) Domain 2: Image editing/processing failure under DiagnosticModules.IMAGES
        val validPngFile = File(devCtx.cacheDir, "valid_src.png").apply { writeBytes(makePngBytes(Color.RED)) }
        val imgBlocker = File(mediaStorage.reportSnapshotsDir, "report_888").apply { writeText("dir_blocker") }
        val imgEditResult = mediaStorage.applyEditsToReportSnapshot(validPngFile.absolutePath, 888L, ImageEditParameters(rotateDegrees = 90))
        imgBlocker.delete()
        assertEquals(null, imgEditResult)
        assertTrue(monitor.errors.value.any { it.moduleName == DiagnosticModules.IMAGES })

        // 3) Domain 3: Excel read error (corrupted xls bytes -> Apache POI NotOLE2FileException)
        val excelRes = excelImport.parseBytes("corrupted_excel_payload".toByteArray(), "broken_sheet.xls")
        assertTrue(excelRes.isFailure)
        assertTrue(
            monitor.errors.value.any {
                it.moduleName == DiagnosticModules.EXCEL && it.screenName == ScreenNames.EXCEL_IMPORT
            },
        )

        // 4) Domain 4: PDF generation failure
        val failingSessionFactory = PdfSessionFactory {
            object : PdfSession {
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): android.graphics.Canvas {
                    throw IllegalStateException("Simulated native PDF page canvas error")
                }
                override fun endPage() = Unit
                override fun writeTo(outputStream: java.io.OutputStream) = Unit
                override fun close() = Unit
            }
        }
        val labelPdfGen = LabelPdfGenerator(devCtx, mediaStorage, failingSessionFactory, monitor)
        val pdfThrew = runCatching {
            labelPdfGen.generateLabelsPdf(
                items = listOf(LabelPrintItem("صنف ملصق", "0012345678905", BarcodeFormatType.EAN_13)),
                config = LabelSheetConfig(),
            )
        }.isFailure
        assertTrue(pdfThrew)
        assertTrue(
            monitor.errors.value.any {
                it.moduleName == DiagnosticModules.PDF && it.screenName == ScreenNames.LABEL_PRINTING
            },
        )

        // 5) Domain 5: SQLite failure (must be logged as CRITICAL and persisted to JSONL independently of SQLite)
        monitor.recordError(
            throwable = SQLiteConstraintException("FOREIGN KEY constraint failed (table=product_images)"),
            screenName = ScreenNames.PRODUCTS,
            moduleName = DiagnosticModules.SQLITE,
            operationName = "حفظ سجل SQLite",
        )
        val sqliteErr = monitor.errors.value.firstOrNull { it.moduleName == DiagnosticModules.SQLITE }
        assertNotNull(sqliteErr)
        assertEquals(LogSeverity.CRITICAL, sqliteErr!!.severity)

        // 6) Domain 6: Inventory missing session error
        val invFail = inventoryRepo.closeSession(sessionId = 999999L)
        assertTrue(invFail.isFailure)
        assertTrue(
            monitor.errors.value.any {
                it.moduleName == DiagnosticModules.INVENTORY && it.screenName == ScreenNames.INVENTORY
            },
        )

        // 7) Domain 7: Camera permission denial & initialization failure
        monitor.recordCustomError(
            screenName = ScreenNames.BARCODE_SCANNER,
            moduleName = DiagnosticModules.BARCODE_CAMERA,
            operationName = "طلب إذن الكاميرا",
            errorType = "CameraPermissionDenied",
            message = "رفض المستخدم صلاحية الكاميرا",
            wasHandled = true,
            severity = LogSeverity.WARNING,
        )
        assertTrue(
            monitor.errors.value.any {
                it.moduleName == DiagnosticModules.BARCODE_CAMERA &&
                    it.screenName == ScreenNames.BARCODE_SCANNER &&
                    it.errorType == "CameraPermissionDenied"
            },
        )

        // 8) Domain 8: Local storage copy I/O failure
        val storageBlocker = File(mediaStorage.reportSnapshotsDir, "report_777").apply { writeText("storage_blocker") }
        val copiedSnap = mediaStorage.copyToReportSnapshot(validPngFile.absolutePath, 777L)
        storageBlocker.delete()
        assertEquals("", copiedSnap)
        assertTrue(monitor.errors.value.any { it.moduleName == DiagnosticModules.STORAGE })

        // 9) Domain 9: ZIP Restore failure (corrupt bytes, missing manifest/db, incompatible future schema)
        // AND prove target SQLite data is 100% preserved!
        val badZipFail = backupEngine.restoreFromBackupBytes("not_a_zip_archive".toByteArray(), "corrupt.zip")
        assertTrue(badZipFail.isFailure)

        val futureSchemaZip = ByteArrayOutputStream().also { out ->
            ZipOutputStream(out).use { zos ->
                zos.putNextEntry(ZipEntry("manifest.json"))
                zos.write("""{"formatVersion":999,"databaseSchemaVersion":999,"appVersion":"99.0"}""".toByteArray())
                zos.closeEntry()
                zos.putNextEntry(ZipEntry("database_export.json"))
                zos.write("""{"products":[]}""".toByteArray())
                zos.closeEntry()
                zos.putNextEntry(ZipEntry("../../etc/passwd"))
                zos.write("ignored_zipslip".toByteArray())
                zos.closeEntry()
            }
        }.toByteArray()
        val futureRes = backupEngine.restoreFromBackupBytes(futureSchemaZip, "future_device.zip")
        assertTrue(futureRes.isFailure)

        // Target DB MUST still contain its original products, reports, and inventory sessions
        assertEquals(1, db.productDao().getAllProductsOnce().size)
        assertNotNull(productRepo.findProductByExactBarcode("0077777777777"))
        assertEquals(1, db.reportDao().getAllReportsWithDetailsOnce().size)
        assertEquals(1, db.inventoryDao().getAllSessionsOnce().size)

        // OperationLogger & LastRestoreDiagnostics must capture failed restore stages & preservation flag
        val failedRestoreOp = opLogger.operations.value.firstOrNull {
            it.moduleName == DiagnosticModules.BACKUP_RESTORE && it.outcome == OperationOutcome.FAILED
        }
        assertNotNull("Expected failed restore operation log", failedRestoreOp)
        assertTrue(failedRestoreOp!!.stages.isNotEmpty())
        assertTrue(failedRestoreOp.failureReason.isNotBlank())
        val restoreDiag = monitor.lastRestoreDiagnostics.value
        assertNotNull(restoreDiag)
        assertEquals("FAILED", restoreDiag!!.outcome)
        assertTrue(restoreDiag.targetDataPreservedOnFailure)

        // Wait briefly for async fileStore writes & verify SQLite-independent JSONL + Crash recovery across restart
        delay(200)
        val errorsBeforeRestart = fileStore.readAllErrors()
        assertTrue(errorsBeforeRestart.any { it.moduleName == DiagnosticModules.SQLITE })

        monitor.updateCurrentScreen(ScreenNames.REPORT_EDITOR)
        monitor.recordFatalCrashSynchronous("main", RuntimeException("Simulated fatal crash for recovery test"))

        // Simulate app restart with fresh GlobalErrorMonitor + same DiagnosticsFileStore
        val restartedLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val restartedMonitor = GlobalErrorMonitor(devCtx, fileStore, restartedLogger) { db.diagnosticsDao() }
        restartedMonitor.installGlobalHandlers()

        assertTrue(restartedMonitor.priorCrashDetected)
        val crashAlert = restartedMonitor.previousCrashAlert.value
        assertNotNull(crashAlert)
        assertTrue(crashAlert!!.isCrash)
        assertFalse(crashAlert.wasHandled)
        assertEquals(ScreenNames.REPORT_EDITOR, crashAlert.screenName)
        restartedMonitor.dismissPreviousCrashAlert()
        assertEquals(null, restartedMonitor.previousCrashAlert.value)

        db.close()
    }

    @Test
    fun `diagnostic ZIP export sanitizes secrets and never leaks database tables or product PII`() = runBlocking {
        val devCtx = isolatedDeviceContext("sanitization_device")
        val db = Room.inMemoryDatabaseBuilder(devCtx, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(db)

        val fileStore = DiagnosticsFileStore(devCtx.filesDir)
        val opLogger = OperationLogger(fileStore) { db.diagnosticsDao() }
        val monitor = GlobalErrorMonitor(devCtx, fileStore, opLogger) { db.diagnosticsDao() }
        val mediaStorage = MediaStorageManager(devCtx, monitor)
        val productRepo = ProductRepository(db, mediaStorage, monitor)
        val exportEngine = DiagnosticExportEngine(devCtx, monitor)

        // Populate sensitive business DB records that MUST NOT appear inside diagnostic export
        productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "CONF-99", name = "منتج سري للغاية للعميل الخاص", basePrice = 450.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "6289998887776", isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()

        // Record errors containing sensitive token, password, and API key strings
        monitor.recordError(
            throwable = IllegalStateException("Auth failed Authorization: Bearer super_secret_token_98765 password=MySecretPass99 api_key=AIzaSySecretKeyExample12345"),
            screenName = ScreenNames.SETTINGS,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "اختبار تعقيم السجلات",
        )
        monitor.recordError(
            throwable = IllegalStateException("Duplicate check Authorization: Bearer another_token_xyz"),
            screenName = ScreenNames.SETTINGS,
            moduleName = DiagnosticModules.SETTINGS,
            operationName = "اختبار تعقيم السجلات",
        )

        val zipFile = exportEngine.exportDiagnosticBundleZip().getOrThrow()
        assertTrue(zipFile.exists() && zipFile.length() > 0L)

        val entries = linkedMapOf<String, String>()
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                entries[entry.name] = zis.readBytes().toString(Charsets.UTF_8)
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        // Verify isolated Diagnostic ZIP structure (never contains business backup files)
        assertTrue(entries.containsKey("device_and_app_info.json"))
        assertTrue(entries.containsKey("diagnostic_summary.json"))
        assertTrue(entries.containsKey("error_logs.json"))
        assertTrue(entries.containsKey("recurring_errors.json"))
        assertTrue(entries.containsKey("operation_logs.json"))
        assertTrue(entries.containsKey("stack_traces.txt"))
        assertFalse("Diagnostic ZIP must NEVER contain backup manifest.json", entries.containsKey("manifest.json"))
        assertFalse("Diagnostic ZIP must NEVER contain database_export.json", entries.containsKey("database_export.json"))

        val allText = entries.values.joinToString("\n")
        assertFalse("Bearer token leaked!", allText.contains("super_secret_token_98765"))
        assertFalse("Secondary bearer token leaked!", allText.contains("another_token_xyz"))
        assertFalse("Password leaked!", allText.contains("MySecretPass99"))
        assertFalse("API key leaked!", allText.contains("AIzaSySecretKeyExample12345"))
        assertFalse("Product name from SQLite leaked!", allText.contains("منتج سري للغاية للعميل الخاص"))
        assertFalse("Product barcode from SQLite leaked!", allText.contains("6289998887776"))
        assertTrue("Redaction placeholder expected", allText.contains("[REDACTED"))

        db.close()
    }

    @Test
    fun `cross-device android-to-android ZIP backup restore transfers full DB and rebinds all images safely`() = runBlocking {
        // ---- PHONE A (Source Device) ----
        val phoneACtx = isolatedDeviceContext("phone_A")
        val dbA = Room.inMemoryDatabaseBuilder(phoneACtx, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(dbA)

        val fileStoreA = DiagnosticsFileStore(phoneACtx.filesDir)
        val opLoggerA = OperationLogger(fileStoreA) { dbA.diagnosticsDao() }
        val monitorA = GlobalErrorMonitor(phoneACtx, fileStoreA, opLoggerA) { dbA.diagnosticsDao() }
        val mediaA = MediaStorageManager(phoneACtx, monitorA)
        val prodRepoA = ProductRepository(dbA, mediaA, monitorA)
        val rptRepoA = ReportRepository(dbA, mediaA, monitorA)
        val invRepoA = InventoryRepository(dbA, monitorA)
        val backupEngineA = BackupRestoreEngine(phoneACtx, dbA, mediaA, monitorA)

        // Branding logo + product with multiple barcodes + primary AND extra gallery images
        val brandingLogoA = File(mediaA.brandingDir, "logo_a.png").apply {
            writeBytes(makePngBytes(Color.YELLOW, 48))
        }
        val curSettings = dbA.settingsDao().getSettingsOnce()!!
        dbA.settingsDao().saveSettings(curSettings.copy(companyName = "شركة النور للتجارة", companyLogoPath = brandingLogoA.absolutePath))

        val img1 = mediaA.saveDownloadedImageBytes(makePngBytes(Color.CYAN, 80), "png")!!
        val img2 = mediaA.saveDownloadedImageBytes(makePngBytes(Color.MAGENTA, 80), "png")!!
        val pidA = prodRepoA.createOrUpdateProduct(
            product = ProductEntity(internalCode = "CROSS-100", name = "عطر عربي فاخر 100مل", basePrice = 245.5, categoryName = "عطور"),
            barcodes = listOf(
                ProductBarcodeEntity(productId = 0L, barcodeValue = "0062811122233", isPrimary = true),
                ProductBarcodeEntity(productId = 0L, barcodeValue = "ALT-BOX-628", isPrimary = false, unitType = "كرتون", conversionFactor = 12.0),
            ),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = img1.activePath, originalFilePath = img1.originalPath, thumbnailPath = img1.thumbnailPath, isPrimary = true, sortOrder = 0),
                ProductImageEntity(productId = 0L, filePath = img2.activePath, originalFilePath = img2.originalPath, thumbnailPath = img2.thumbnailPath, isPrimary = false, sortOrder = 1),
            ),
        ).getOrThrow()
        val prodA = dbA.productDao().getProductWithDetails(pidA)!!

        val ridA = rptRepoA.createEmptyReport(customTitle = "تقرير التوريد عبر الأجهزة")
        rptRepoA.addProductToReport(ridA, prodA)

        val sidA = invRepoA.createSession("جرد المستودع الشمالي").getOrThrow()
        invRepoA.recordCountedItem(sidA, prodA, "0062811122233", "EAN_13", "حبة", 1.0, 14.0).getOrThrow()

        val exportedZipA = backupEngineA.createBackupZip("phone_a_transfer").getOrThrow()
        assertTrue(exportedZipA.exists() && exportedZipA.length() > 0L)
        dbA.close()

        // Simulate real-world cross-phone transfer quirk: an Android file manager / cloud share wrapped entries in a root folder!
        val transferredZipBytes = ByteArrayOutputStream().also { out ->
            ZipOutputStream(out).use { zos ->
                ZipInputStream(FileInputStream(exportedZipA)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            zos.putNextEntry(ZipEntry("SharedFromSamsung/${entry.name}"))
                            zos.write(zis.readBytes())
                            zos.closeEntry()
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
        }.toByteArray()

        // Completely wipe Phone A directory paths so Phone B cannot accidentally read Phone A files!
        File(rootSandbox, "phone_A").deleteRecursively()

        // ---- PHONE B (Target Device with real persistent Room file DB) ----
        val phoneBCtx = isolatedDeviceContext("phone_B")
        val dbFileB = File(rootSandbox, "phone_B_room.db")
        var dbB = Room.databaseBuilder(phoneBCtx, AppDatabase::class.java, dbFileB.absolutePath)
            .allowMainThreadQueries()
            .build()
        AppDatabase.ensureSeeded(dbB)

        val fileStoreB = DiagnosticsFileStore(phoneBCtx.filesDir)
        val opLoggerB = OperationLogger(fileStoreB) { dbB.diagnosticsDao() }
        val monitorB = GlobalErrorMonitor(phoneBCtx, fileStoreB, opLoggerB) { dbB.diagnosticsDao() }
        val mediaB = MediaStorageManager(phoneBCtx, monitorB)
        val prodRepoB = ProductRepository(dbB, mediaB, monitorB)
        val backupEngineB = BackupRestoreEngine(phoneBCtx, dbB, mediaB, monitorB)

        // Pre-existing different data on Phone B before restoring Phone A's backup
        prodRepoB.createOrUpdateProduct(
            product = ProductEntity(internalCode = "OLD-B", name = "منتج قديم على الهاتف الثاني", basePrice = 10.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "9990001112223", isPrimary = true)),
            images = emptyList(),
        ).getOrThrow()

        // Step 1: Inspect transferred ZIP on Phone B
        val inspection = backupEngineB.inspectBackupBytes(transferredZipBytes)
        assertTrue("Cross-device wrapped ZIP inspection should succeed: ${inspection.errorMessage}", inspection.isValid)
        assertTrue("Expected zero missing files", inspection.missingFiles.isEmpty())
        assertTrue("Expected zero corrupted files", inspection.corruptedFiles.isEmpty())
        val manifest = inspection.manifest!!
        assertEquals(1, manifest.productCount)
        assertEquals(2, manifest.barcodeCount)

        // Step 2: Restore onto Phone B
        val restoreRes = backupEngineB.restoreFromStagedZip(inspection.stagedZipFilePath, "SharedFromPhoneA.zip")
        assertTrue("Cross-device restore failed: ${restoreRes.exceptionOrNull()?.message}", restoreRes.isSuccess)

        // Step 3: Close Phone B DB and re-open it from disk to verify durable persistence!
        dbB.close()
        dbB = Room.databaseBuilder(phoneBCtx, AppDatabase::class.java, dbFileB.absolutePath)
            .allowMainThreadQueries()
            .build()
        val reopenedProdRepoB = ProductRepository(dbB, mediaB, monitorB)

        val restoredSettings = dbB.settingsDao().getSettingsOnce()!!
        assertEquals("شركة النور للتجارة", restoredSettings.companyName)
        assertTrue(
            "Branding logo must live inside phone_B storage",
            restoredSettings.companyLogoPath.startsWith(phoneBCtx.filesDir.absolutePath) &&
                File(restoredSettings.companyLogoPath).exists(),
        )

        val restoredProdB = reopenedProdRepoB.findProductByExactBarcode("0062811122233")
        assertNotNull(restoredProdB)
        assertEquals("عطر عربي فاخر 100مل", restoredProdB!!.product.name)
        assertEquals(2, restoredProdB.barcodes.size)
        assertNotNull(reopenedProdRepoB.findProductByExactBarcode("ALT-BOX-628"))

        // Verify ALL images (both primary & extra gallery) point strictly to existing Phone B files
        assertEquals(2, restoredProdB.images.size)
        restoredProdB.images.forEach { restoredImg ->
            assertTrue("Active path must point to phone_B", restoredImg.filePath.startsWith(phoneBCtx.filesDir.absolutePath))
            assertTrue("Active file must exist on disk", File(restoredImg.filePath).exists())
            assertTrue("Original file must exist on phone_B", File(restoredImg.originalFilePath).exists())
            assertTrue("Thumbnail file must exist on phone_B", File(restoredImg.thumbnailPath).exists())
        }

        // Verify Reports & Report Item Snapshot Image on Phone B
        val restoredReports = dbB.reportDao().getAllReportsWithDetailsOnce()
        assertEquals(1, restoredReports.size)
        assertEquals("تقرير التوريد عبر الأجهزة", restoredReports.first().report.title)
        val snapPathB = restoredReports.first().items.first().item.imageSnapshotPath
        assertTrue(snapPathB.startsWith(phoneBCtx.filesDir.absolutePath) && File(snapPathB).exists())

        // Verify Inventory Session & Counted Item on Phone B
        val restoredSessions = dbB.inventoryDao().getAllSessionsOnce()
        assertEquals(1, restoredSessions.size)
        val restoredSessionDetails = dbB.inventoryDao().getSessionWithDetails(restoredSessions.first().id)!!
        assertEquals("جرد المستودع الشمالي", restoredSessionDetails.session.title)
        assertEquals(1, restoredSessionDetails.items.size)
        assertEquals(14.0, restoredSessionDetails.items.first().countedQty, 0.001)

        // Verify Restore Verification Report & Operation Log on Phone B
        val lastDiagB = monitorB.lastRestoreDiagnostics.value
        assertNotNull(lastDiagB)
        assertEquals("SUCCESS", lastDiagB!!.outcome)
        assertTrue(lastDiagB.verificationChecks.any { it.passed })

        val restoreOpB = opLoggerB.operations.value.firstOrNull {
            it.moduleName == DiagnosticModules.BACKUP_RESTORE && it.outcome == OperationOutcome.SUCCESS
        }
        assertNotNull(restoreOpB)
        assertTrue(restoreOpB!!.stages.size >= 3)

        dbB.close()
    }
}
