package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ProductEntity
import com.example.di.SharedAppServices
import com.example.domain.auth.AuthActionResult
import com.example.domain.auth.AuthConfigurationStatus
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.AuthProviderType
import com.example.domain.auth.AuthUserProfile
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.workspace.WorkspaceIdentity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

private class Phase4WorkspaceFakeAuthGateway : AuthGateway {
    private val _authStateFlow = MutableStateFlow<AuthUserProfile?>(null)
    override val authStateFlow: StateFlow<AuthUserProfile?> = _authStateFlow.asStateFlow()

    fun setSignedInUser(user: AuthUserProfile?) {
        _authStateFlow.value = user
    }

    override fun currentUser(): AuthUserProfile? = _authStateFlow.value

    override fun configurationStatus(): AuthConfigurationStatus = AuthConfigurationStatus(
        isGoogleServicesConfigured = true,
        isFirebaseInitialized = true,
        googleWebClientIdPresent = true,
        statusMessage = "جاهز",
    )

    override suspend fun signInWithGoogleIdToken(idToken: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun signInWithEmail(email: String, password: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun registerWithEmail(email: String, password: String, displayName: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun sendEmailVerification(): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun reloadCurrentUser(): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun sendPasswordResetEmail(email: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun updatePassword(currentPassword: String?, newPassword: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun linkGoogleIdToken(idToken: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun linkEmailPassword(email: String, password: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun unlinkProvider(providerType: AuthProviderType): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun reauthenticateWithGoogleIdToken(idToken: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun reauthenticateWithEmailPassword(email: String, password: String): AuthActionResult =
        AuthActionResult.Success(_authStateFlow.value)

    override suspend fun signOut(): AuthActionResult {
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم تسجيل الخروج")
    }

    override suspend fun deleteCurrentAccount(): AuthActionResult {
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم حذف الحساب")
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class WorkspaceIsolationPhase4Test {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun `legacy local database remains untouched and isolated across account A, account B, sign out, and deletion`() = runBlocking {
        val fakeAuth = Phase4WorkspaceFakeAuthGateway()
        val shared = SharedAppServices(context, authGatewayOverride = fakeAuth)
        val manager = shared.workspaceManager

        // 1. Pre-auth / Local workspace keeps exact legacy DB name report_manager_db and context.filesDir
        val localIdentity = manager.syncWithCurrentUser()
        assertEquals(WorkspaceIdentity.Local, localIdentity)
        assertEquals(AppDatabase.LEGACY_DATABASE_NAME, localIdentity.databaseName)

        val localContainer = manager.containerForWorkspace(localIdentity)
        AppDatabase.ensureSeeded(localContainer.database)
        assertEquals(context.filesDir.absolutePath, localContainer.workspaceStorageRoot.absolutePath)

        val initialLocalCount = localContainer.productRepository.allProducts.first().size

        // Seed legacy product + image file on device BEFORE any user signs in
        val localProdId = localContainer.productRepository.createOrUpdateProduct(
            ProductEntity(
                name = "منتج محلي قديم",
                internalCode = "LOCAL-OLD-001",
                defaultQuantity = 25.0,
            ),
            emptyList(),
            emptyList(),
        ).getOrThrow()
        val localImgPath = localContainer.mediaStorage.saveBitmapAsProductImage(
            Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) },
        )!!
        assertTrue(File(localImgPath).exists())

        // 2. Sign in as Account A -> switches to isolated workspace, legacy data NOT migrated or visible
        val userA = AuthUserProfile(
            uid = "firebase-uid-account-alpha",
            email = "alpha@example.com",
            displayName = "حساب ألفا",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.GOOGLE),
        )
        fakeAuth.setSignedInUser(userA)
        val identityA = manager.syncWithCurrentUser()
        assertTrue(identityA is WorkspaceIdentity.Account)
        assertNotEquals(AppDatabase.LEGACY_DATABASE_NAME, identityA.databaseName)

        val containerA = manager.containerForWorkspace(identityA)
        AppDatabase.ensureSeeded(containerA.database)
        val productsAInitial = containerA.productRepository.allProducts.first()
        assertTrue(productsAInitial.isEmpty())

        // Create Account A's own product & image
        containerA.productRepository.createOrUpdateProduct(
            ProductEntity(
                name = "منتج خاص بحساب ألفا",
                internalCode = "ALPHA-001",
                defaultQuantity = 10.0,
            ),
            emptyList(),
            emptyList(),
        ).getOrThrow()
        val imgAPath = containerA.mediaStorage.saveBitmapAsProductImage(
            Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GREEN) },
        )!!
        assertTrue(imgAPath.startsWith(containerA.workspaceStorageRoot.absolutePath))
        assertFalse(imgAPath == localImgPath)

        // Attempt to delete localImgPath from containerA -> blocked because path is outside containerA.workspaceStorageRoot!
        containerA.mediaStorage.deleteFileIfInternal(localImgPath)
        assertTrue(File(localImgPath).exists())

        // 3. Switch to Account B -> completely isolated from Account A and Local
        val userB = AuthUserProfile(
            uid = "firebase-uid-account-beta",
            email = "beta@example.com",
            displayName = "حساب بيتا",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.EMAIL_PASSWORD),
        )
        fakeAuth.setSignedInUser(userB)
        val identityB = manager.syncWithCurrentUser()
        assertNotEquals(identityA.workspaceId, identityB.workspaceId)
        assertNotEquals(identityA.databaseName, identityB.databaseName)

        val containerB = manager.containerForWorkspace(identityB)
        AppDatabase.ensureSeeded(containerB.database)
        assertTrue(containerB.productRepository.allProducts.first().isEmpty())
        containerB.productRepository.createOrUpdateProduct(
            ProductEntity(
                name = "منتج خاص بحساب بيتا",
                internalCode = "BETA-001",
                defaultQuantity = 7.0,
            ),
            emptyList(),
            emptyList(),
        ).getOrThrow()

        // 4. Sign out -> returns cleanly to Local workspace; legacy data is intact; A & B remain intact on disk
        fakeAuth.signOut()
        val backToLocal = manager.syncWithCurrentUser()
        assertEquals(WorkspaceIdentity.Local, backToLocal)
        val localProductsAfterSwitch = localContainer.productRepository.allProducts.first()
        assertEquals(initialLocalCount + 1, localProductsAfterSwitch.size)
        assertTrue(localProductsAfterSwitch.any { it.product.id == localProdId })
        assertFalse(localProductsAfterSwitch.any { it.product.internalCode == "ALPHA-001" || it.product.internalCode == "BETA-001" })
        assertTrue(File(localImgPath).exists())
        assertTrue(File(imgAPath).exists())

        // Re-sign in Account A -> A's data is still there and never merged with B
        fakeAuth.setSignedInUser(userA)
        manager.syncWithCurrentUser()
        val productsARestored = containerA.productRepository.allProducts.first()
        assertEquals(1, productsARestored.size)
        assertEquals("ALPHA-001", productsARestored.first().product.internalCode)

        // Delete Firebase account A -> local workspace DB & files for A are STILL NOT auto-deleted
        fakeAuth.deleteCurrentAccount()
        manager.syncWithCurrentUser()
        assertEquals(1, containerA.database.productDao().getAllProductsOnce().size)
        assertTrue(File(imgAPath).exists())
    }

    @Test
    fun `backup restore engine v6 preserves format and operates strictly inside active workspace`() = runBlocking {
        val fakeAuth = Phase4WorkspaceFakeAuthGateway()
        val shared = SharedAppServices(context, authGatewayOverride = fakeAuth)
        val manager = shared.workspaceManager

        val userA = AuthUserProfile(
            uid = "uid-backup-isolated-a",
            email = "backup-a@example.com",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.GOOGLE),
        )
        fakeAuth.setSignedInUser(userA)
        val identityA = manager.syncWithCurrentUser()
        val containerA = manager.containerForWorkspace(identityA)
        AppDatabase.ensureSeeded(containerA.database)

        val localContainer = manager.containerForWorkspace(WorkspaceIdentity.Local)
        AppDatabase.ensureSeeded(localContainer.database)
        localContainer.productRepository.createOrUpdateProduct(
            ProductEntity(name = "بيانات محلية مستقلة", internalCode = "LOC-KEEP-1"),
            emptyList(),
            emptyList(),
        ).getOrThrow()

        containerA.productRepository.createOrUpdateProduct(
            ProductEntity(name = "منتج في نسخة ألفا", internalCode = "A-BKP-1", defaultQuantity = 3.0),
            emptyList(),
            emptyList(),
        ).getOrThrow()
        val zipFile = containerA.backupRestoreEngine.createBackupZip().getOrThrow()
        assertTrue(zipFile.exists())
        assertTrue(zipFile.absolutePath.startsWith(containerA.workspaceStorageRoot.absolutePath))

        val inspection = containerA.backupRestoreEngine.inspectBackupUri(android.net.Uri.fromFile(zipFile))
        assertTrue(inspection.isValid)
        assertEquals(BackupRestoreEngine.CURRENT_BACKUP_FORMAT_VERSION, inspection.manifest?.formatVersion)
        assertEquals(1, inspection.manifest?.productCount)

        // Clear Account A product and restore backup inside A -> restores A's product without affecting Local!
        containerA.database.productDao().getAllProductsOnce().forEach {
            containerA.productRepository.deleteProduct(it.id)
        }
        assertEquals(0, containerA.database.productDao().getAllProductsOnce().size)

        val restoreRes = containerA.backupRestoreEngine.restoreFromStagedZip(
            stagedZipPath = inspection.stagedZipFilePath,
            fileNameLabel = zipFile.name,
        )
        assertTrue(restoreRes.isSuccess)
        assertEquals(1, containerA.database.productDao().getAllProductsOnce().size)
        assertEquals("A-BKP-1", containerA.database.productDao().getAllProductsOnce().first().internalCode)

        // Verify Local database never lost or mixed data
        assertTrue(localContainer.database.productDao().getAllProductsOnce().any { it.internalCode == "LOC-KEEP-1" })
        assertFalse(localContainer.database.productDao().getAllProductsOnce().any { it.internalCode == "A-BKP-1" })
    }
}
