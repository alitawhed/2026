package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductImageEntity
import com.example.data.repository.AddProductToReportResult
import com.example.data.repository.ProductRepository
import com.example.data.repository.ReportProductPickRequest
import com.example.data.repository.ReportRepository
import com.example.data.storage.ImageEditParameters
import com.example.data.storage.ImageResolution
import com.example.data.storage.ImageService
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.barcode.BarcodeEngine
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.model.BarcodeFormatType
import com.example.domain.model.DuplicateProductBehavior
import com.example.domain.model.ReportImageSourceType
import com.example.domain.model.ReportRowSortMode
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import com.example.ui.components.resolveProductImageStateless
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class MajorUpgradeAndFixesTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var backupEngine: BackupRestoreEngine
    private lateinit var imageService: ImageService

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        reportRepo = ReportRepository(db, mediaStorage)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        imageService = ImageService(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun makeBitmap(width: Int = 100, height: Int = 80, color: Int = Color.BLUE): Bitmap {
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            eraseColor(color)
        }
    }

    private fun bitmapToCompactY(bitmap: Bitmap, invert: Boolean = false): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        return ByteArray(w * h) { i ->
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val lum = ((r * 77 + g * 150 + b * 29) shr 8).coerceIn(0, 255)
            val finalLum = if (invert) (255 - lum) else lum
            finalLum.toByte()
        }
    }

    private fun padYPlaneWithStride(compactY: ByteArray, width: Int, height: Int, rowStride: Int): ByteArray {
        val out = ByteArray(rowStride * height)
        for (row in 0 until height) {
            System.arraycopy(compactY, row * width, out, row * rowStride, width)
            // Fill padding bytes with deterministic noise to verify compaction ignores stride padding
            for (padCol in width until rowStride) {
                out[row * rowStride + padCol] = 0x55
            }
        }
        return out
    }

    // ==================== Pillar 1: MIGRATION_2_3 & Unified Image Service (IMP-0167) ====================

    @Test
    fun `MIGRATION_2_3 preserves all existing v2 products images and reports cleanly`() {
        val dbFile = File(context.cacheDir, "legacy_v2_${System.nanoTime()}.db")
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbFile.absolutePath)
                .callback(object : SupportSQLiteOpenHelper.Callback(2) {
                    override fun onCreate(sDb: SupportSQLiteDatabase) {
                        sDb.execSQL(
                            """
                            CREATE TABLE Reports (
                                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                reportNumber TEXT NOT NULL,
                                title TEXT NOT NULL
                            )
                            """.trimIndent(),
                        )
                        sDb.execSQL(
                            """
                            CREATE TABLE ReportItems (
                                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                reportId INTEGER NOT NULL
                            )
                            """.trimIndent(),
                        )
                        sDb.execSQL(
                            """
                            CREATE TABLE ReportItemImages (
                                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                reportItemId INTEGER NOT NULL,
                                filePath TEXT NOT NULL,
                                isPrimary INTEGER NOT NULL,
                                sortOrder INTEGER NOT NULL
                            )
                            """.trimIndent(),
                        )
                        sDb.execSQL(
                            """
                            CREATE TABLE AppSettings (
                                id INTEGER PRIMARY KEY NOT NULL,
                                appName TEXT NOT NULL
                            )
                            """.trimIndent(),
                        )
                    }

                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                })
                .build(),
        )

        val raw = helper.writableDatabase
        raw.execSQL("INSERT INTO Reports (id, reportNumber, title) VALUES (7, 'RPT-7', 'تقرير قديم')")
        raw.execSQL("INSERT INTO ReportItems (id, reportId) VALUES (21, 7)")
        raw.execSQL("INSERT INTO ReportItemImages (id, reportItemId, filePath, isPrimary, sortOrder) VALUES (1, 21, '/tmp/snap.png', 1, 0)")
        raw.execSQL("INSERT INTO AppSettings (id, appName) VALUES (1, 'مدير التقارير')")

        AppDatabase.MIGRATION_2_3.migrate(raw)

        raw.query("SELECT reportId, imageSourceType FROM ReportItemImages WHERE id = 1").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(7L, c.getLong(0))
            assertEquals("PRODUCT_PRIMARY", c.getString(1))
        }
        raw.query("SELECT rowSortMode FROM Reports WHERE id = 7").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("MANUAL", c.getString(0))
        }
        raw.query("SELECT productPickerViewMode, scannerEnabledFormats FROM AppSettings WHERE id = 1").use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("LIST", c.getString(0))
            assertEquals("", c.getString(1))
        }

        helper.close()
        dbFile.delete()
    }

    @Test
    fun `ImageService resolves IMP-0167 with corrupted query suffix restores missing active image from original after backup`() = runBlocking {
        val triplet1 = mediaStorage.saveBitmapTriplet(makeBitmap(90, 90, Color.MAGENTA))
        val triplet2 = mediaStorage.saveBitmapTriplet(makeBitmap(90, 90, Color.CYAN))
        val originalBytes1 = File(triplet1.originalPath).readBytes()

        // Simulate legacy broken paths:
        // Image 1: active path has "?t=1700000" query suffix (caused ProductDetail failure on File(path))
        // Image 2: active file & thumbnail deleted, only originalFilePath intact
        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(internalCode = "IMP-0167", name = "منتج تفاصيل IMP-0167", basePrice = 45.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "0016700016701", isPrimary = true)),
            images = listOf(
                ProductImageEntity(
                    productId = 0L,
                    filePath = "file://${triplet1.activePath}?t=1700000000",
                    originalFilePath = triplet1.originalPath,
                    thumbnailPath = triplet1.thumbnailPath,
                    isPrimary = true,
                    sortOrder = 0,
                ),
                ProductImageEntity(
                    productId = 0L,
                    filePath = triplet2.activePath,
                    originalFilePath = triplet2.originalPath,
                    thumbnailPath = triplet2.thumbnailPath,
                    isPrimary = false,
                    sortOrder = 1,
                ),
            ),
        ).getOrThrow()

        // Delete active & thumbnail of Image 2 while keeping original untouched
        File(triplet2.activePath).delete()
        File(triplet2.thumbnailPath).delete()

        val loadedProduct = db.productDao().getProductWithDetails(pid)!!
        assertEquals(2, loadedProduct.images.size)

        // Both stateless and ImageService resolvers MUST render IMP-0167 cleanly without failing on ?t=
        val res1 = resolveProductImageStateless(loadedProduct.images[0], preferThumbnail = false)
        assertTrue("Expected IMP-0167 image 1 to resolve cleanly via query-stripped path", res1 is ImageResolution.Available)

        val res2 = imageService.resolveProductImage(loadedProduct.images[1], preferThumbnail = false)
        assertTrue("Expected IMP-0167 image 2 to fall back cleanly to originalFilePath", res2 is ImageResolution.Available)
        assertTrue((res2 as ImageResolution.Available).usedFallback)

        // Audit & Repair (MUST create backup first, repair broken paths/missing active, rebuild thumb, never touch originals)
        val auditBefore = imageService.auditAllProductImages()
        assertEquals(2, auditBefore.repairableCount)

        val repairResult = imageService.repairBrokenImageReferences(backupEngine = backupEngine, createBackupFirst = true)
        assertNotNull("Backup ZIP must be created before any DB image repair", repairResult.backupFilePath)
        assertTrue(File(repairResult.backupFilePath!!).exists())
        assertTrue(repairResult.repairedCount >= 2)
        assertEquals(0, repairResult.reportAfter.repairableCount)
        assertEquals(0, repairResult.reportAfter.missingFilesCount)
        assertArrayEquals("Original image bytes must NEVER be altered", originalBytes1, File(triplet1.originalPath).readBytes())
    }

    // ==================== Pillar 2: Camera Barcode Scanner Decoding & Leading Zeros ====================

    @Test
    fun `BarcodeEngine decodes CameraX Y-plane with rowStride padding rotated angles inverted luminance and leading zeros`() {
        data class BarcodeCase(
            val code: String,
            val format: BarcodeFormatType,
            val allowedFormats: Set<BarcodeFormatType>? = null,
        )
        val cases = listOf(
            BarcodeCase("6281006530119", BarcodeFormatType.EAN_13),
            BarcodeCase("0012345678905", BarcodeFormatType.EAN_13, setOf(BarcodeFormatType.EAN_13)),
            BarcodeCase("0012345678905", BarcodeFormatType.CODE_128),
            BarcodeCase("01234565", BarcodeFormatType.EAN_8),
            BarcodeCase("036000291452", BarcodeFormatType.UPC_A),
            BarcodeCase("IMP-0167-ABC", BarcodeFormatType.CODE_128),
            BarcodeCase("https://example.com/item/IMP-0167", BarcodeFormatType.QR_CODE),
        )

        cases.forEach { (code, fmt, filter) ->
            val w = if (fmt.is2D) 360 else 560
            val h = if (fmt.is2D) 360 else 220
            val bmp = BarcodeEngine.generateHighResBitmap(
                value = code,
                format = fmt,
                widthPx = w,
                heightPx = h,
                showText = false,
                quietZoneModules = 20,
            )!!
            val compactY = bitmapToCompactY(bmp)
            bmp.recycle()

            // Simulate CameraX rowStride alignment padding (rowStride = w + 64)
            val paddedStride = w + 64
            val paddedY = padYPlaneWithStride(compactY, w, h, paddedStride)

            // Test rotationAngles (0, 90, 180, 270) when sensor rotation is reported cleanly or offset by 90°
            val (rot90Bytes, rot90W, rot90H) = BarcodeEngine.rotateYPlane(compactY, w, h, 90)
            val paddedRot90 = padYPlaneWithStride(rot90Bytes, rot90W, rot90H, rot90W + 32)

            val decodedNormal = BarcodeEngine.decodeYuvFrameWithRotation(
                yuvBytes = paddedY,
                width = w,
                height = h,
                rowStride = paddedStride,
                rotationDegrees = 0,
                allowedFormats = filter,
            )
            assertNotNull("Failed to decode padded $fmt ($code)", decodedNormal)
            assertEquals("Leading zeros or exact text altered for $fmt", code, decodedNormal!!.text)
            assertEquals(fmt, decodedNormal.format)

            val decodedRotated = BarcodeEngine.decodeYuvFrameWithRotation(
                yuvBytes = paddedRot90,
                width = rot90W,
                height = rot90H,
                rowStride = rot90W + 32,
                rotationDegrees = 0, // intentionally mismatched sensor metadata; engine searches perpendicular angles
                allowedFormats = filter,
            )
            assertNotNull("Failed to decode rotated 90° padded $fmt ($code)", decodedRotated)
            assertEquals(code, decodedRotated!!.text)
        }

        // Verify inverted light-on-dark QR / Code 128 frame decoding
        val invBmp = BarcodeEngine.generateHighResBitmap("INV-9901", BarcodeFormatType.CODE_128, 480, 200, showText = false)!!
        val invCompact = bitmapToCompactY(invBmp, invert = true)
        invBmp.recycle()
        val decodedInverted = BarcodeEngine.decodeYuvFrameWithRotation(
            yuvBytes = invCompact,
            width = 480,
            height = 200,
            rowStride = 480,
            rotationDegrees = 180,
            tryInverted = true,
        )
        assertNotNull("Inverted barcode decoding failed", decodedInverted)
        assertEquals("INV-9901", decodedInverted!!.text)
    }

    // ==================== Pillar 3: Visual Product Picker & Secondary Image Selection ====================

    @Test
    fun `Visual product picker selects non-primary gallery image without mutating ProductImages primary flag and supports batch add`() = runBlocking {
        val imgPrimary = mediaStorage.saveBitmapTriplet(makeBitmap(80, 80, Color.RED))
        val imgGallery = mediaStorage.saveBitmapTriplet(makeBitmap(80, 80, Color.GREEN))
        val imgOther = mediaStorage.saveBitmapTriplet(makeBitmap(80, 80, Color.BLUE))

        val pid1 = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج متعدد الصور", basePrice = 120.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "PICK-001", isPrimary = true)),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = imgPrimary.activePath, originalFilePath = imgPrimary.originalPath, thumbnailPath = imgPrimary.thumbnailPath, isPrimary = true, sortOrder = 0),
                ProductImageEntity(productId = 0L, filePath = imgGallery.activePath, originalFilePath = imgGallery.originalPath, thumbnailPath = imgGallery.thumbnailPath, isPrimary = false, sortOrder = 1),
            ),
        ).getOrThrow()

        val pid2 = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج ثاني", basePrice = 80.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "PICK-002", isPrimary = true)),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = imgOther.activePath, originalFilePath = imgOther.originalPath, thumbnailPath = imgOther.thumbnailPath, isPrimary = true, sortOrder = 0),
            ),
        ).getOrThrow()

        val prod1 = db.productDao().getProductWithDetails(pid1)!!
        val prod2 = db.productDao().getProductWithDetails(pid2)!!
        val nonPrimaryImg = prod1.images.first { !it.isPrimary }

        val rid = reportRepo.createEmptyReport(customTitle = "تقرير الاختيار البصري")
        val batchRes = reportRepo.addProductsBatchToReport(
            reportId = rid,
            requests = listOf(
                ReportProductPickRequest(
                    product = prod1,
                    selectedImageId = nonPrimaryImg.id,
                    selectedImagePathOverride = nonPrimaryImg.filePath,
                ),
                ReportProductPickRequest(product = prod2),
            ),
        )
        assertEquals(2, batchRes.addedCount)

        // Report item 1 MUST snapshot the chosen green gallery image pixel color
        val report = reportRepo.getReportOnce(rid)!!
        val row1 = report.sortedItems.first { it.item.sourceProductId == pid1 }
        val snapBmp = BitmapFactory.decodeFile(row1.item.imageSnapshotPath)!!
        assertEquals(Color.GREEN, snapBmp.getPixel(40, 40))
        snapBmp.recycle()

        val primaryImgRecord = row1.images.first { it.isPrimary }
        assertEquals(ReportImageSourceType.PRODUCT_GALLERY.name, primaryImgRecord.imageSourceType)
        assertEquals(nonPrimaryImg.id, primaryImgRecord.sourceImageId)

        // Source product's primary image flag MUST remain untouched (still RED!)
        val reloadedProd1 = db.productDao().getProductWithDetails(pid1)!!
        assertTrue(reloadedProd1.primaryImage!!.isPrimary)
        assertNotEquals(nonPrimaryImg.id, reloadedProd1.primaryImage!!.id)
    }

    // ==================== Pillar 4: Full Report Row Ordering + Batch + Duplicate + PDF/Excel ====================

    @Test
    fun `Report row ordering batch move duplicate manual edit stability PDF and Excel export remain 100pct synchronized`() = runBlocking {
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير الترتيب المتقدم")
        val rpt = reportRepo.getReportOnce(rid)!!.report.copy(duplicateBehavior = DuplicateProductBehavior.NEW_ROW.name)
        reportRepo.updateReport(rpt)

        // Create 4 distinct products and add product #1 twice -> 5 rows total
        val productIds = (1..4).map { idx ->
            val trip = mediaStorage.saveBitmapTriplet(makeBitmap(60, 60, if (idx % 2 == 0) Color.BLUE else Color.YELLOW))
            productRepo.createOrUpdateProduct(
                product = ProductEntity(
                    internalCode = "ORD-$idx",
                    name = "منتج رقم $idx",
                    basePrice = idx * 10.0,
                    categoryName = if (idx <= 2) "أ" else "ب",
                ),
                barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "BAR-00$idx", isPrimary = true)),
                images = listOf(ProductImageEntity(productId = 0L, filePath = trip.activePath, originalFilePath = trip.originalPath, thumbnailPath = trip.thumbnailPath, isPrimary = true)),
            ).getOrThrow()
        }

        productIds.forEach { pid ->
            reportRepo.addProductToReport(rid, db.productDao().getProductWithDetails(pid)!!)
        }
        // Add product #1 a second time (5th row, duplicate product)
        reportRepo.addProductToReport(rid, db.productDao().getProductWithDetails(productIds.first())!!)

        var rows = reportRepo.getReportOnce(rid)!!.sortedItems
        assertEquals(5, rows.size)

        // 1. Move row 5 (duplicate of product 1) -> position 1 (cross-page / top jump)
        val fifthItemId = rows[4].item.id
        reportRepo.moveReportRowToPosition(rid, fifthItemId, 1)
        rows = reportRepo.getReportOnce(rid)!!.sortedItems
        assertEquals(fifthItemId, rows[0].item.id)
        assertEquals(listOf(1, 2, 3, 4, 5), rows.map { it.item.serialNumber })

        // 2. Batch move rows 2 & 4 (indices 1 and 3) to end preserving their relative order
        val pickA = rows[1].item.id // product 1 first instance
        val pickB = rows[3].item.id // product 3
        reportRepo.moveReportRowsBatch(rid, setOf(pickA, pickB), targetInsertionIndex = 5)
        rows = reportRepo.getReportOnce(rid)!!.sortedItems
        assertEquals(listOf(pickA, pickB), rows.takeLast(2).map { it.item.id })
        assertEquals(listOf(1, 2, 3, 4, 5), rows.map { it.item.serialNumber })

        // 3. Sort by PRICE_DESC, verify prices descending
        reportRepo.applyReportRowSortMode(rid, ReportRowSortMode.PRICE_DESC)
        rows = reportRepo.getReportOnce(rid)!!.sortedItems
        assertEquals(40.0, rows.first().item.unitPrice, 0.001)
        assertEquals(ReportRowSortMode.PRICE_DESC.name, reportRepo.getReportOnce(rid)!!.report.rowSortMode)

        // 4. Move row manually -> switches to MANUAL, and subsequent quantity/price edit MUST preserve manual order!
        val lastId = rows.last().item.id
        reportRepo.moveReportRowToPosition(rid, lastId, 1)
        val movedFirst = reportRepo.getReportOnce(rid)!!.sortedItems.first().item
        reportRepo.updateReportItem(movedFirst.copy(unitPrice = 999.0, quantity = 3.0))
        val afterEdit = reportRepo.getReportOnce(rid)!!
        assertEquals(ReportRowSortMode.MANUAL.name, afterEdit.report.rowSortMode)
        assertEquals(lastId, afterEdit.sortedItems.first().item.id)
        assertEquals(1, afterEdit.sortedItems.first().item.serialNumber)

        // 5. Duplicate row inside report -> places copy right after source row with independent snapshot
        val dupId = reportRepo.duplicateReportRow(rid, lastId)!!
        val afterDup = reportRepo.getReportOnce(rid)!!.sortedItems
        assertEquals(6, afterDup.size)
        assertEquals(lastId, afterDup[0].item.id)
        assertEquals(dupId, afterDup[1].item.id)
        assertEquals((1..6).toList(), afterDup.map { it.item.serialNumber })
        assertNotEquals(afterDup[0].item.imageSnapshotPath, afterDup[1].item.imageSnapshotPath)

        // 6. Export Excel & PDF -> verify exported XLSX row sequence matches exact reordered rows!
        val finalDetails = reportRepo.getReportOnce(rid)!!
        val xlsxFile = ExcelExportEngine(mediaStorage).exportReportToXlsx(finalDetails, "ordered_sync_test")
        assertTrue(xlsxFile.exists())
        val sheetXml = readZipEntryText(xlsxFile, "xl/worksheets/sheet1.xml")
        assertNotNull(sheetXml)
        // First item name appears before second product name in XML string stream
        val p1Name = afterDup[0].item.productNameSnapshot
        val pOtherName = afterDup.first { it.item.productNameSnapshot != p1Name }.item.productNameSnapshot
        assertTrue(sheetXml!!.indexOf(p1Name) < sheetXml.indexOf(pOtherName))

        val sessionFactory = PdfSessionFactory {
            object : PdfSession {
                override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas =
                    Canvas(Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888))
                override fun endPage() = Unit
                override fun writeTo(outputStream: OutputStream) {
                    outputStream.write("%PDF-1.4\n".toByteArray())
                }
                override fun close() = Unit
            }
        }
        val pdfOut = PdfGeneratorEngine(context, mediaStorage, sessionFactory)
            .generateReportPdf(finalDetails, AppSettingsEntity(), "ordered_pdf_test")
        assertTrue(pdfOut.file.exists())
    }

    // ==================== Pillar 5: Report-Only Image Editing, Isolation & Backup/Restore ====================

    @Test
    fun `Report-only image edit affects only target row keeps sibling rows and source product intact and restores cleanly`() = runBlocking {
        val prodPrimary = mediaStorage.saveBitmapTriplet(makeBitmap(120, 80, Color.RED))
        val altPhoto = mediaStorage.saveBitmapTriplet(makeBitmap(120, 80, Color.GREEN))
        val origBytesBefore = File(prodPrimary.originalPath).readBytes()
        val activeBytesBefore = File(prodPrimary.activePath).readBytes()

        val pid = productRepo.createOrUpdateProduct(
            product = ProductEntity(name = "منتج اختبار عزل الصور", basePrice = 50.0),
            barcodes = listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "ISO-500", isPrimary = true)),
            images = listOf(
                ProductImageEntity(productId = 0L, filePath = prodPrimary.activePath, originalFilePath = prodPrimary.originalPath, thumbnailPath = prodPrimary.thumbnailPath, isPrimary = true),
                ProductImageEntity(productId = 0L, filePath = altPhoto.activePath, originalFilePath = altPhoto.originalPath, thumbnailPath = altPhoto.thumbnailPath, isPrimary = false, sortOrder = 1),
            ),
        ).getOrThrow()

        val prod = db.productDao().getProductWithDetails(pid)!!
        val rid = reportRepo.createEmptyReport(customTitle = "تقرير عزل الصور")
        val rpt = reportRepo.getReportOnce(rid)!!.report.copy(duplicateBehavior = DuplicateProductBehavior.NEW_ROW.name)
        reportRepo.updateReport(rpt)

        // Add same product as Row 1 and Row 2 inside same report
        val idRow1 = (reportRepo.addProductToReport(rid, prod) as AddProductToReportResult.Added).itemId
        val idRow2 = (reportRepo.addProductToReport(rid, prod) as AddProductToReportResult.Added).itemId

        val row2SnapBefore = File(reportRepo.getReportOnce(rid)!!.sortedItems[1].item.imageSnapshotPath).readBytes()

        // Edit Row 1 image ONLY inside the report (crop + rotate 90° + brightness)
        val editedSnapPath = reportRepo.applyReportOnlyImageEdits(
            reportId = rid,
            itemId = idRow1,
            params = ImageEditParameters(
                rotateDegrees = 90,
                cropLeft = 0.1f,
                cropTop = 0.1f,
                cropRight = 0.9f,
                cropBottom = 0.9f,
                brightness = -70f,
            ),
        )
        assertNotNull(editedSnapPath)
        assertTrue(editedSnapPath!!.contains("report_snapshots${File.separator}report_$rid"))

        // Verify Row 1 changed, Row 2 untouched, Product active & original bytes untouched!
        val afterEditDetails = reportRepo.getReportOnce(rid)!!
        val r1After = afterEditDetails.sortedItems.first { it.item.id == idRow1 }
        val r2After = afterEditDetails.sortedItems.first { it.item.id == idRow2 }

        assertEquals(ReportImageSourceType.REPORT_EDITED.name, r1After.images.first { it.isPrimary }.imageSourceType)
        assertArrayEquals("Sibling row snapshot must stay untouched!", row2SnapBefore, File(r2After.item.imageSnapshotPath).readBytes())
        assertArrayEquals("Source product active file must stay untouched!", activeBytesBefore, File(prodPrimary.activePath).readBytes())
        assertArrayEquals("Source product original file must stay untouched!", origBytesBefore, File(prodPrimary.originalPath).readBytes())

        // Replace Row 2 with alt gallery photo only inside report
        assertTrue(
            reportRepo.setReportItemImageFromPath(
                reportId = rid,
                itemId = idRow2,
                sourcePath = altPhoto.activePath,
                sourceType = ReportImageSourceType.PRODUCT_GALLERY,
                sourceProductId = pid,
            ),
        )
        val row2ImgBmp = BitmapFactory.decodeFile(reportRepo.getReportOnce(rid)!!.sortedItems[1].item.imageSnapshotPath)!!
        assertEquals(Color.GREEN, row2ImgBmp.getPixel(40, 40))
        row2ImgBmp.recycle()

        // Restore Row 1 back to original product primary image
        assertTrue(reportRepo.restoreReportItemOriginalProductImage(rid, idRow1))
        val restoredR1Bmp = BitmapFactory.decodeFile(reportRepo.getReportOnce(rid)!!.sortedItems[0].item.imageSnapshotPath)!!
        assertEquals(Color.RED, restoredR1Bmp.getPixel(40, 40))
        restoredR1Bmp.recycle()

        // Backup & Restore ZIP roundtrip preserves reordered items, image source types, and report snapshots
        reportRepo.moveReportRowToPosition(rid, idRow2, 1)
        val backupZip = backupEngine.createBackupZip("v3_full_upgrade_backup").getOrThrow()
        val backupBytes = backupZip.readBytes()
        assertTrue(backupEngine.inspectBackupBytes(backupBytes).isValid)

        // Wipe in-memory DB & restore from ZIP
        backupEngine.restoreFromBackupBytes(backupBytes).getOrThrow()
        val restoredReport = reportRepo.getReportOnce(rid)!!
        assertEquals(2, restoredReport.sortedItems.size)
        assertEquals(idRow2, restoredReport.sortedItems[0].item.id)
        assertEquals(ReportImageSourceType.PRODUCT_GALLERY.name, restoredReport.sortedItems[0].images.first { it.isPrimary }.imageSourceType)
        assertTrue(File(restoredReport.sortedItems[0].item.imageSnapshotPath).exists())
    }

    private fun readZipEntryText(zipFile: File, targetEntry: String): String? {
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name == targetEntry) {
                    return zis.readBytes().toString(Charsets.UTF_8)
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return null
    }
}
