package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.InventoryCountItemEntity
import com.example.data.local.entity.ProductBarcodeEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.DuplicateCountAction
import com.example.data.repository.InventoryRepository
import com.example.data.repository.InventoryScanLookupResult
import com.example.data.repository.InventoryUnitConflictException
import com.example.data.repository.ProductRepository
import com.example.data.repository.SettingsRepository
import com.example.data.storage.MediaStorageManager
import com.example.domain.backup.BackupRestoreEngine
import com.example.domain.excel.ExcelExportEngine
import com.example.domain.excel.ExcelImportConflictException
import com.example.domain.excel.ExcelImportEngine
import com.example.domain.excel.ExcelNewBarcodePolicy
import com.example.domain.excel.ExcelRowConflictType
import com.example.domain.excel.ExtractedExcelImage
import com.example.domain.excel.ImportDuplicatePolicy
import com.example.domain.excel.ParsedSheetData
import com.example.domain.excel.ProductImportField
import com.example.domain.layout.ColumnLayoutEngine
import com.example.domain.model.ColumnDistributionMode
import com.example.domain.model.InventoryBarcodeSourceMode
import com.example.domain.model.InventoryColumnDefaults
import com.example.domain.model.InventorySessionStatus
import com.example.domain.model.InventorySheetConfig
import com.example.domain.model.PageOrientation
import com.example.domain.pdf.PdfGeneratorEngine
import com.example.domain.pdf.PdfSession
import com.example.domain.pdf.PdfSessionFactory
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.OutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ExcelTransactionsAndInventoryUpgradeTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var mediaStorage: MediaStorageManager
    private lateinit var productRepo: ProductRepository
    private lateinit var inventoryRepo: InventoryRepository
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var excelImport: ExcelImportEngine
    private lateinit var excelExport: ExcelExportEngine
    private lateinit var backupEngine: BackupRestoreEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mediaStorage = MediaStorageManager(context)
        productRepo = ProductRepository(db, mediaStorage)
        inventoryRepo = InventoryRepository(db)
        settingsRepo = SettingsRepository(db)
        excelImport = ExcelImportEngine(context, db, mediaStorage)
        excelExport = ExcelExportEngine(mediaStorage)
        backupEngine = BackupRestoreEngine(context, db, mediaStorage)
        runBlocking { AppDatabase.ensureSeeded(db) }
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun makePngBytes(color: Int = Color.GREEN): ByteArray {
        val bmp = Bitmap.createBitmap(60, 60, Bitmap.Config.ARGB_8888).apply { eraseColor(color) }
        return ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            bmp.recycle()
            out.toByteArray()
        }
    }

    @Test
    fun `excel pre-import review classifies conflicts supports policies and rolls back atomically on failure`() = runBlocking {
        // Pre-seed two existing products
        val pidA = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "EX-01", name = "قهوة عربية 250 جم", basePrice = 35.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "00110011", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "EX-02", name = "هيل فاخر", basePrice = 80.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "00220022", isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val rows = listOf(
            listOf("رقم التعريف (ID)", "اسم المنتج", "الباركود الرئيسي", "السعر الأساسي", "التصنيف"),
            listOf("EX-01", "قهوة عربية 250 جم", "00110099", "35", "بن وقهوة"),
            listOf("EX-01", "قهوة عربية 250 جم", "00220022", "35", "بن وقهوة"),
            listOf("NEW-03", "بهارات مشكلة", "00330033", "18", "بهارات"),
            listOf("NEW-04", "كمون مطحون", "00330033", "14", "بهارات"),
        )
        val anchoredImg = ExtractedExcelImage(
            id = "img_row3",
            fileName = "spices.png",
            bytes = makePngBytes(Color.RED),
            anchoredRowZeroBased = 3,
            anchoredColZeroBased = 5,
        )
        val sheet = ParsedSheetData(
            sheetName = "ImportTest",
            headers = rows.first(),
            rows = rows,
            extractedImages = listOf(anchoredImg),
        )
        val mapping = mapOf(
            0 to ProductImportField.INTERNAL_CODE,
            1 to ProductImportField.NAME,
            2 to ProductImportField.PRIMARY_BARCODE,
            3 to ProductImportField.BASE_PRICE,
            4 to ProductImportField.CATEGORY,
        )

        val draft = excelImport.buildPreImportReviewDraft(
            sheet = sheet,
            mappings = mapping,
            hasHeaderRow = true,
            policy = ImportDuplicatePolicy.UPDATE,
        )
        assertEquals(4, draft.rows.size)
        assertEquals(ExcelRowConflictType.EXISTING_PRODUCT_NEW_BARCODE, draft.rows[0].conflictType)
        assertEquals(ExcelRowConflictType.FOREIGN_BARCODE_CONFLICT, draft.rows[1].conflictType)
        assertTrue(draft.rows[1].foreignConflictBarcodes.containsKey("00220022"))
        assertEquals(ExcelRowConflictType.INTRA_FILE_DUPLICATE, draft.rows[2].conflictType)
        assertEquals(ExcelRowConflictType.INTRA_FILE_DUPLICATE, draft.rows[3].conflictType)
        assertTrue(draft.computeSummary().unresolvedBlockingCount >= 3)

        try {
            excelImport.commitReviewedImport(draft)
            fail("Expected ExcelImportConflictException for unresolved conflicts")
        } catch (_: ExcelImportConflictException) {
            // expected
        }

        val resolved = draft.copy(
            rows = listOf(
                draft.rows[0].copy(newBarcodePolicy = ExcelNewBarcodePolicy.SET_AS_PRIMARY_KEEP_OLD),
                draft.rows[1].copy(newBarcodePolicy = ExcelNewBarcodePolicy.IGNORE_NEW_BARCODE),
                draft.rows[2],
                draft.rows[3].copy(skipRow = true),
            ),
        )
        assertEquals(0, resolved.computeSummary().unresolvedBlockingCount)
        assertFalse(resolved.isRowBlocking(resolved.rows[2]))

        val filesBeforeRollback = mediaStorage.productImagesDir.listFiles()?.map { it.absolutePath }?.toSet().orEmpty()
        val categoriesBefore = db.categoryDao().getAllCategoriesOnce().size
        val productsBefore = db.productDao().getAllProductsOnce().size
        val barcodesBefore = db.productDao().getAllBarcodesOnce().size

        try {
            excelImport.commitReviewedImport(
                review = resolved,
                beforeCommitHook = { throw IllegalStateException("Simulated disk/DB failure before commit") },
            )
            fail("Expected IllegalStateException from beforeCommitHook")
        } catch (_: IllegalStateException) {
            // expected
        }

        assertEquals(productsBefore, db.productDao().getAllProductsOnce().size)
        assertEquals(barcodesBefore, db.productDao().getAllBarcodesOnce().size)
        assertEquals(categoriesBefore, db.categoryDao().getAllCategoriesOnce().size)
        val filesAfterRollback = mediaStorage.productImagesDir.listFiles()?.map { it.absolutePath }?.toSet().orEmpty()
        assertEquals("Orphan image files left behind after transaction rollback", filesBeforeRollback, filesAfterRollback)

        val report = excelImport.commitReviewedImport(resolved)
        assertEquals(1, report.insertedCount)
        assertEquals(0, report.errorCount)
        assertEquals(1, report.autoLinkedImagesCount)

        val prodA = db.productDao().getProductWithDetails(pidA)!!
        assertEquals("00110099", prodA.primaryBarcode?.barcodeValue)
        assertTrue(prodA.barcodes.any { it.barcodeValue == "00110011" && !it.isPrimary })
        assertNotNull(productRepo.findProductByExactBarcode("00330033"))
    }

    @Test
    fun `pure count sheet workflow never mutates stock persists custom columns and exports matching pdf and xlsx`() = runBlocking {
        // Seed products: P1 has initial stock = 20.0 which MUST remain 20.0 forever during inventory count sheet
        val p1Id = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "INV-100", name = "حليب طويل الأجل", basePrice = 4.0, defaultQuantity = 20.0),
            listOf(
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "0011223344",
                    label = "حبة",
                    unitType = "حبة",
                    conversionFactor = 1.0,
                    isPrimary = true,
                ),
                ProductBarcodeEntity(
                    productId = 0L,
                    barcodeValue = "CARTON-12",
                    label = "كرتون 12",
                    unitType = "كرتون",
                    conversionFactor = 12.0,
                    isPrimary = false,
                ),
            ),
            emptyList(),
        ).getOrThrow()

        val p2Id = productRepo.createOrUpdateProduct(
            ProductEntity(internalCode = "INV-200", name = "أرز بسمتي 5 كجم", basePrice = 45.0, defaultQuantity = 10.0),
            listOf(ProductBarcodeEntity(productId = 0L, barcodeValue = "0055667788", unitType = "كيس", conversionFactor = 1.0, isPrimary = true)),
            emptyList(),
        ).getOrThrow()

        val sessionId = inventoryRepo.createSession("جرد مستودع الرياض المسائي", "فحص كميات نهاية الشهر").getOrThrow()
        assertEquals("INV-${sessionId.toString().padStart(4, '0')}", InventoryColumnDefaults.sheetNumberForSession(sessionId))

        // Lookup primary & alternative barcodes
        val lookupPrimary = inventoryRepo.lookupBarcodeForSession(sessionId, "0011223344") as InventoryScanLookupResult.MatchedRegistered
        assertEquals("حبة", lookupPrimary.unitType)
        assertEquals(1.0, lookupPrimary.conversionFactor, 0.001)
        assertFalse(lookupPrimary.isAlternativeBarcode)

        // Record count with 0.0 then replace/update
        val itemPrimaryId = inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = lookupPrimary.product,
            scannedBarcode = lookupPrimary.barcodeValue,
            barcodeType = lookupPrimary.barcodeType,
            unitType = lookupPrimary.unitType,
            conversionFactor = lookupPrimary.conversionFactor,
            quantity = 0.0,
            notes = "رف رقم 1",
        ).getOrThrow()

        // Lookup alternative barcode -> detects existing primary unit in session without mixing units
        val lookupAlt = inventoryRepo.lookupBarcodeForSession(sessionId, "CARTON-12") as InventoryScanLookupResult.MatchedRegistered
        assertEquals("كرتون", lookupAlt.unitType)
        assertEquals(12.0, lookupAlt.conversionFactor, 0.001)
        assertTrue(lookupAlt.isAlternativeBarcode)
        assertTrue(lookupAlt.otherUnitsInSession.any { it.contains("حبة") })

        // Duplicate scan with mismatched unitType throws InventoryUnitConflictException
        val conflictAdd = inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = lookupPrimary.product,
            scannedBarcode = "0011223344",
            barcodeType = lookupPrimary.barcodeType,
            unitType = "علبة",
            conversionFactor = 6.0,
            quantity = 1.0,
            duplicateAction = DuplicateCountAction.ADD_TO_EXISTING,
        )
        assertTrue(conflictAdd.isFailure)
        assertTrue(conflictAdd.exceptionOrNull() is InventoryUnitConflictException)

        // Update primary item to 5.0 and scan CARTON-12 with 2.5 cartons via ADD_TO_EXISTING
        inventoryRepo.updateCountItemQuantity(itemPrimaryId, 5.0, "رف رقم 1 محدّث").getOrThrow()
        inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = lookupAlt.product,
            scannedBarcode = lookupAlt.barcodeValue,
            barcodeType = lookupAlt.barcodeType,
            unitType = lookupAlt.unitType,
            conversionFactor = lookupAlt.conversionFactor,
            quantity = 2.0,
        ).getOrThrow()
        inventoryRepo.recordCountedItem(
            sessionId = sessionId,
            product = lookupAlt.product,
            scannedBarcode = lookupAlt.barcodeValue,
            barcodeType = lookupAlt.barcodeType,
            unitType = lookupAlt.unitType,
            conversionFactor = lookupAlt.conversionFactor,
            quantity = 0.5,
            duplicateAction = DuplicateCountAction.ADD_TO_EXISTING,
        ).getOrThrow()

        // Unregistered barcode lookup & record
        val unregLookup = inventoryRepo.lookupBarcodeForSession(sessionId, "UNKNOWN-999")
        assertTrue(unregLookup is InventoryScanLookupResult.UnregisteredBarcode)
        inventoryRepo.recordUnregisteredBarcode(sessionId, "UNKNOWN-999", "CODE_128", 3.0).getOrThrow()

        // Close & reopen cycle works cleanly
        inventoryRepo.closeSession(sessionId).getOrThrow()
        assertEquals(InventorySessionStatus.CLOSED.name, inventoryRepo.getSessionOnce(sessionId)!!.session.status)
        inventoryRepo.reopenSession(sessionId).getOrThrow()
        assertEquals(InventorySessionStatus.OPEN.name, inventoryRepo.getSessionOnce(sessionId)!!.session.status)

        // CRITICAL INVARIANT: Products.defaultQuantity MUST NEVER change from inventory count sheet!
        assertEquals(20.0, db.productDao().getProductWithDetails(p1Id)!!.product.defaultQuantity, 0.001)
        assertEquals(10.0, db.productDao().getProductWithDetails(p2Id)!!.product.defaultQuantity, 0.001)
        assertEquals(0, db.inventoryDao().getAllAdjustmentLogsOnce().size)

        // Test Column Customization & Independent Persistence:
        // Default has 8 columns: serial, image, internal_code, name, barcode, quantity, unit, notes
        val defaultCfg = settingsRepo.getInventoryConfigOnce()
        assertEquals(
            listOf("serial", "image", "internal_code", "name", "barcode", "quantity", "unit", "notes"),
            defaultCfg.columns.map { it.columnKey },
        )

        // Customize: keep only [serial, name, barcode, quantity] visible, pin 'name', reorder 'quantity' before 'barcode',
        // switch to PRIMARY_BARCODE + graphic enabled, LANDSCAPE orientation, hide 'notes' without losing row notes!
        val customizedCols = defaultCfg.columns.map { col ->
            when (col.columnKey) {
                "serial" -> col.copy(visible = true, sortOrder = 0)
                "name" -> col.copy(visible = true, pinned = true, sortOrder = 1, manualWidthPt = 160f)
                "quantity" -> col.copy(visible = true, sortOrder = 2, manualWidthPt = 72f)
                "barcode" -> col.copy(visible = true, sortOrder = 3, manualWidthPt = 128f)
                "notes" -> col.copy(visible = false, sortOrder = 4)
                "image" -> col.copy(visible = false, sortOrder = 5)
                "internal_code" -> col.copy(visible = false, sortOrder = 6)
                "unit" -> col.copy(visible = false, sortOrder = 7)
                else -> col
            }
        }.sortedBy { it.sortOrder }

        val customConfig = InventorySheetConfig(
            columns = customizedCols,
            distributionMode = ColumnDistributionMode.MANUAL,
            orientation = PageOrientation.LANDSCAPE,
            repeatTableHeader = true,
            barcodeSourceMode = InventoryBarcodeSourceMode.PRIMARY_BARCODE,
            renderBarcodeGraphic = true,
            showBarcodeTextBelow = true,
        )
        settingsRepo.saveInventoryConfig(customConfig)

        // Reload from DB to verify persistence across restarts
        val reloadedConfig = settingsRepo.getInventoryConfigOnce()
        assertEquals(PageOrientation.LANDSCAPE, reloadedConfig.orientation)
        assertEquals(InventoryBarcodeSourceMode.PRIMARY_BARCODE, reloadedConfig.barcodeSourceMode)
        assertTrue(reloadedConfig.columns.first { it.columnKey == "name" }.pinned)
        assertEquals(
            listOf("serial", "name", "quantity", "barcode"),
            reloadedConfig.columns.filter { it.visible }.map { it.columnKey },
        )

        // Layout Engine computes exact columns without overflow on A4 Landscape
        val layout = ColumnLayoutEngine.calculateLayout(
            reloadedConfig.toPageSpec(),
            reloadedConfig.columns,
            reloadedConfig.distributionMode,
        )
        assertFalse(layout.hasOverflow)
        assertEquals(4, layout.computedColumns.size)

        val sessionDetails = inventoryRepo.getSessionOnce(sessionId)!!
        val allProds = db.productDao().getAllProductsWithDetailsOnce()

        // Verify hiding 'notes' column did NOT delete item notes from DB
        assertEquals("رف رقم 1 محدّث", sessionDetails.sortedItems.first { it.id == itemPrimaryId }.notes)

        // Export Excel using reloadedConfig -> ONLY visible selected columns in exact order + leading zero barcode preserved + PRIMARY_BARCODE resolved!
        val xlsx = excelExport.exportInventoryReportToXlsx(sessionDetails, allProds, "count_sheet_custom.xlsx", reloadedConfig)
        assertTrue(xlsx.exists() && xlsx.length() > 0)
        val parsedSheets = excelImport.parseBytes(xlsx.readBytes(), xlsx.name).getOrThrow().sheets
        assertEquals(listOf("كشف الجرد", "بيانات الكشف"), parsedSheets.map { it.sheetName })
        assertEquals(listOf("الرقم التسلسلي", "اسم المنتج", "الكمية", "الباركود"), parsedSheets[0].headers)
        // Row scanned with CARTON-12 renders PRIMARY_BARCODE ("0011223344") when barcodeSourceMode == PRIMARY_BARCODE!
        assertTrue(parsedSheets[0].rows[2].contains("0011223344"))
        assertFalse(parsedSheets[0].rows[2].contains("CARTON-12"))

        // Switch to SCANNED_BARCODE -> Excel contains both "0011223344" and "CARTON-12"
        val scannedConfig = reloadedConfig.copy(barcodeSourceMode = InventoryBarcodeSourceMode.SCANNED_BARCODE)
        val xlsxScanned = excelExport.exportInventoryReportToXlsx(sessionDetails, allProds, "count_sheet_scanned.xlsx", scannedConfig)
        val parsedScanned = excelImport.parseBytes(xlsxScanned.readBytes(), xlsxScanned.name).getOrThrow().sheets
        assertTrue(parsedScanned[0].rows.flatten().contains("CARTON-12"))

        // Export PDF (Custom Config + Multi-page repeatTableHeader + Text-Only barcode mode)
        val renderedPages = mutableListOf<Bitmap>()
        val pdfEngine = PdfGeneratorEngine(
            context,
            mediaStorage,
            PdfSessionFactory {
                object : PdfSession {
                    override fun beginPage(widthPt: Int, heightPt: Int, pageNumber: Int): Canvas {
                        val b = Bitmap.createBitmap(widthPt, heightPt, Bitmap.Config.ARGB_8888)
                        renderedPages.add(b)
                        return Canvas(b)
                    }
                    override fun endPage() = Unit
                    override fun writeTo(outputStream: OutputStream) {
                        outputStream.write("%PDF-1.4\n%inventory\n%%EOF".toByteArray())
                    }
                    override fun close() = Unit
                }
            },
        )
        val invPdf = pdfEngine.generateInventoryReportPdf(
            sessionDetails = sessionDetails,
            allProducts = allProds,
            settings = settingsRepo.getSettingsOnce(),
            inventoryConfig = reloadedConfig,
            outputFileName = "inv_custom_graphic.pdf",
        )
        assertTrue(invPdf.file.exists() && invPdf.pageCount >= 1)
        assertEquals(invPdf.pageCount, renderedPages.size)
        // Verify Landscape page width > height
        assertTrue(renderedPages.first().width > renderedPages.first().height)
        renderedPages.forEach { if (!it.isRecycled) it.recycle() }
        renderedPages.clear()

        // Multi-page test (25 rows in Portrait) to confirm pagination & repeating header work cleanly
        val bigItems = (1..25).map { idx ->
            InventoryCountItemEntity(
                id = idx.toLong(),
                sessionId = sessionId,
                productId = p1Id,
                productInternalCode = "INV-100",
                productName = "صنف اختبار رقم $idx",
                scannedBarcode = "0011223344",
                barcodeType = "CODE_128",
                unitType = "حبة",
                countedQty = idx.toDouble(),
                baseUnitEquivalentQty = idx.toDouble(),
            )
        }
        val portraitTextConfig = InventorySheetConfig(
            orientation = PageOrientation.PORTRAIT,
            repeatTableHeader = true,
            renderBarcodeGraphic = false,
        )
        val multiPagePdf = pdfEngine.generateInventoryReportPdf(
            sessionDetails = sessionDetails.copy(items = bigItems),
            allProducts = allProds,
            settings = settingsRepo.getSettingsOnce(),
            inventoryConfig = portraitTextConfig,
            outputFileName = "inv_multipage.pdf",
        )
        assertTrue("Expected multi-page count sheet PDF", multiPagePdf.pageCount >= 2)
        assertTrue(renderedPages.first().height > renderedPages.first().width)
        renderedPages.forEach { if (!it.isRecycled) it.recycle() }

        // Backup v4 ZIP roundtrip restores inventory sessions, items & custom inventoryConfigJson
        val zip = backupEngine.createBackupZip("backup_v4_inv").getOrThrow()
        val inspect = backupEngine.inspectBackupBytes(zip.readBytes())
        assertTrue(inspect.isValid)
        assertEquals(1, inspect.manifest?.inventorySessionCount)
        assertEquals(3, inspect.manifest?.inventoryItemCount)

        db.inventoryDao().deleteAllSessions()
        db.productDao().deleteAllProducts()
        settingsRepo.saveInventoryConfig(InventorySheetConfig()) // reset before restore

        backupEngine.restoreFromBackupBytes(zip.readBytes(), zip.name).getOrThrow()
        val restoredSessions = db.inventoryDao().getAllSessionsOnce()
        assertEquals(1, restoredSessions.size)
        assertEquals(3, db.inventoryDao().getAllCountItemsOnce().size)
        val restoredConfig = settingsRepo.getInventoryConfigOnce()
        assertEquals(PageOrientation.LANDSCAPE, restoredConfig.orientation)
        assertEquals(InventoryBarcodeSourceMode.PRIMARY_BARCODE, restoredConfig.barcodeSourceMode)
        // Product stock still completely untouched after full restore
        assertEquals(20.0, productRepo.findProductByExactBarcode("CARTON-12")!!.product.defaultQuantity, 0.001)
    }

    @Test
    fun `database migration 4 to 5 adds inventoryConfigJson preserving existing AppSettings`() {
        val dbFile = context.getDatabasePath("migration_test_4_5.db")
        if (dbFile.exists()) dbFile.delete()
        val sqlite = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqlite.execSQL(
            """
            CREATE TABLE AppSettings (
                id INTEGER NOT NULL PRIMARY KEY,
                appName TEXT NOT NULL,
                developerName TEXT NOT NULL,
                developerPhone TEXT NOT NULL,
                companyName TEXT NOT NULL,
                companyAddress TEXT NOT NULL,
                companyPhone TEXT NOT NULL,
                companyLogoPath TEXT NOT NULL,
                headerDefaultText TEXT NOT NULL,
                fontFamilyKey TEXT NOT NULL,
                accentColorHex TEXT NOT NULL,
                defaultCurrency TEXT NOT NULL,
                defaultPaperSize TEXT NOT NULL,
                defaultOrientation TEXT NOT NULL,
                defaultMarginMm REAL NOT NULL,
                defaultBarcodeType TEXT NOT NULL,
                barcodeWidthPt REAL NOT NULL,
                barcodeHeightPt REAL NOT NULL,
                barcodeFontSizePt REAL NOT NULL,
                barcodeQuietZoneModules INTEGER NOT NULL,
                barcodeDpi INTEGER NOT NULL,
                cameraFlashDefault INTEGER NOT NULL,
                cameraContinuousScan INTEGER NOT NULL,
                scanBeepEnabled INTEGER NOT NULL,
                scanVibrateEnabled INTEGER NOT NULL,
                autoSaveEnabled INTEGER NOT NULL,
                themeMode TEXT NOT NULL,
                exportFilePrefix TEXT NOT NULL,
                productPickerViewMode TEXT NOT NULL,
                scannerEnabledFormats TEXT NOT NULL,
                updatedAt INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        sqlite.execSQL(
            """
            INSERT INTO AppSettings VALUES (
                1,'مدير التقارير','المهندس علي توحيد','+966573928022','شركة الاختبار','الرياض','0500000000',
                '','تقرير','CAIRO','#0D9488','ر.س','A4','PORTRAIT',10.0,'CODE_128',100.0,34.0,8.0,8,300,
                0,1,1,1,1,'SYSTEM','تقرير','LIST','',123456
            )
            """.trimIndent(),
        )
        sqlite.close()

        // Apply MIGRATION_4_5 via SupportSQLiteDatabase
        val helper = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
            androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbFile.absolutePath)
                .callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(5) {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) = Unit
                    override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                })
                .build(),
        )
        val supportDb = helper.writableDatabase
        AppDatabase.MIGRATION_4_5.migrate(supportDb)

        supportDb.query("SELECT companyName, inventoryConfigJson FROM AppSettings WHERE id = 1").use { cursor ->
            assertTrue(cursor.moveToFirst())
            assertEquals("شركة الاختبار", cursor.getString(0))
            assertEquals("", cursor.getString(1))
        }
        helper.close()
        dbFile.delete()
    }
}
