package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.domain.auth.AuthActionResult
import com.example.domain.auth.AuthConfigurationStatus
import com.example.domain.auth.AuthErrorMapper
import com.example.domain.auth.AuthGateway
import com.example.domain.auth.AuthInputValidator
import com.example.domain.auth.AuthProviderType
import com.example.domain.auth.AuthUserProfile
import com.example.domain.auth.FirebaseAuthGateway
import com.example.ui.screens.AuthScreen
import com.example.ui.theme.ReportManagerTheme
import com.example.ui.viewmodel.AuthScreenMode
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class FakeAuthGateway(
    private val initialConfigured: Boolean = true,
) : AuthGateway {
    private val _authStateFlow = MutableStateFlow<AuthUserProfile?>(null)
    override val authStateFlow: StateFlow<AuthUserProfile?> = _authStateFlow.asStateFlow()

    var simulateOffline: Boolean = false
    var requireRecentLoginOnDelete: Boolean = false
    var simulateEmailVerifiedAfterReload: Boolean = false
    private val registeredEmailPasswords = mutableMapOf<String, String>()
    private val registeredUsers = mutableMapOf<String, AuthUserProfile>()

    override fun currentUser(): AuthUserProfile? = _authStateFlow.value

    override fun configurationStatus(): AuthConfigurationStatus = AuthConfigurationStatus(
        isGoogleServicesConfigured = initialConfigured,
        isFirebaseInitialized = initialConfigured,
        googleWebClientIdPresent = initialConfigured,
        statusMessage = if (initialConfigured) "جاهز" else "غير مهيأ",
    )

    override suspend fun signInWithGoogleIdToken(idToken: String): AuthActionResult {
        if (simulateOffline) {
            return AuthActionResult.Failure("ERROR_NETWORK_REQUEST_FAILED", "لا يوجد اتصال", isNetworkError = true)
        }
        val email = "google.user@example.com"
        val existing = registeredUsers[email]
        if (existing != null && !existing.hasGoogleProvider) {
            return AuthActionResult.AccountCollision(
                email = email,
                existingProviderHint = AuthProviderType.EMAIL_PASSWORD.arabicLabel,
                message = "البريد مرتبط مسبقاً بالبريد وكلمة المرور",
                pendingGoogleIdToken = idToken,
            )
        }
        val user = existing ?: AuthUserProfile(
            uid = "uid-google-1",
            email = email,
            displayName = "مستخدم Google",
            isEmailVerified = true,
            providers = setOf(AuthProviderType.GOOGLE),
        )
        registeredUsers[email] = user
        _authStateFlow.value = user
        return AuthActionResult.Success(user, "تم تسجيل الدخول بحساب Google")
    }

    override suspend fun signInWithEmail(email: String, password: String): AuthActionResult {
        if (simulateOffline) {
            return AuthActionResult.Failure("ERROR_NETWORK_REQUEST_FAILED", "لا يوجد اتصال", isNetworkError = true)
        }
        val clean = AuthInputValidator.normalizeEmail(email)
        val storedPass = registeredEmailPasswords[clean]
            ?: return AuthActionResult.Failure("ERROR_USER_NOT_FOUND", AuthErrorMapper.mapCodeToArabic("ERROR_USER_NOT_FOUND"))
        if (storedPass != password) {
            return AuthActionResult.Failure("ERROR_WRONG_PASSWORD", AuthErrorMapper.mapCodeToArabic("ERROR_WRONG_PASSWORD"))
        }
        val user = registeredUsers[clean]!!
        _authStateFlow.value = user
        return if (!user.isAccountVerified) {
            AuthActionResult.RequiresEmailVerification(user, "يرجى تأكيد البريد الإلكتروني")
        } else {
            AuthActionResult.Success(user, "تم تسجيل الدخول")
        }
    }

    override suspend fun registerWithEmail(email: String, password: String, displayName: String): AuthActionResult {
        if (simulateOffline) {
            return AuthActionResult.Failure("ERROR_NETWORK_REQUEST_FAILED", "لا يوجد اتصال", isNetworkError = true)
        }
        val clean = AuthInputValidator.normalizeEmail(email)
        if (clean in registeredEmailPasswords) {
            return AuthActionResult.Failure("ERROR_EMAIL_ALREADY_IN_USE", AuthErrorMapper.mapCodeToArabic("ERROR_EMAIL_ALREADY_IN_USE"))
        }
        val user = AuthUserProfile(
            uid = "uid-email-${registeredUsers.size + 1}",
            email = clean,
            displayName = displayName.trim(),
            isEmailVerified = false,
            providers = setOf(AuthProviderType.EMAIL_PASSWORD),
        )
        registeredEmailPasswords[clean] = password
        registeredUsers[clean] = user
        _authStateFlow.value = user
        return AuthActionResult.RequiresEmailVerification(user, "تم إرسال رسالة التحقق إلى $clean")
    }

    override suspend fun sendEmailVerification(): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        return AuthActionResult.Success(user, "تم إعادة إرسال رسالة التحقق")
    }

    override suspend fun reloadCurrentUser(): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        val updated = if (simulateEmailVerifiedAfterReload) user.copy(isEmailVerified = true) else user
        registeredUsers[updated.email] = updated
        _authStateFlow.value = updated
        return if (updated.isAccountVerified) {
            AuthActionResult.Success(updated, "تم توثيق البريد بنجاح")
        } else {
            AuthActionResult.RequiresEmailVerification(updated, "لم يتم تأكيد البريد بعد")
        }
    }

    override suspend fun sendPasswordResetEmail(email: String): AuthActionResult {
        if (simulateOffline) {
            return AuthActionResult.Failure("ERROR_NETWORK_REQUEST_FAILED", "لا يوجد اتصال", isNetworkError = true)
        }
        return AuthActionResult.Success(_authStateFlow.value, "تم إرسال رابط إعادة التعيين إلى $email")
    }

    override suspend fun updatePassword(currentPassword: String?, newPassword: String): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        if (user.hasEmailPasswordProvider && currentPassword != registeredEmailPasswords[user.email]) {
            return AuthActionResult.Failure("ERROR_WRONG_PASSWORD", AuthErrorMapper.mapCodeToArabic("ERROR_WRONG_PASSWORD"))
        }
        registeredEmailPasswords[user.email] = newPassword
        return AuthActionResult.Success(user, "تم تحديث كلمة المرور")
    }

    override suspend fun linkGoogleIdToken(idToken: String): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        val linked = user.copy(providers = user.providers + AuthProviderType.GOOGLE)
        registeredUsers[linked.email] = linked
        _authStateFlow.value = linked
        return AuthActionResult.Success(linked, "تم الربط")
    }

    override suspend fun linkEmailPassword(email: String, password: String): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        val clean = AuthInputValidator.normalizeEmail(email)
        registeredEmailPasswords[clean] = password
        val linked = user.copy(providers = user.providers + AuthProviderType.EMAIL_PASSWORD)
        registeredUsers[clean] = linked
        _authStateFlow.value = linked
        return AuthActionResult.Success(linked, "تم الربط")
    }

    override suspend fun unlinkProvider(providerType: AuthProviderType): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        val next = user.copy(providers = user.providers - providerType)
        _authStateFlow.value = next
        return AuthActionResult.Success(next, "تم فك الربط")
    }

    override suspend fun reauthenticateWithGoogleIdToken(idToken: String): AuthActionResult {
        requireRecentLoginOnDelete = false
        return AuthActionResult.Success(_authStateFlow.value, "تمت إعادة المصادقة")
    }

    override suspend fun reauthenticateWithEmailPassword(email: String, password: String): AuthActionResult {
        val clean = AuthInputValidator.normalizeEmail(email)
        if (registeredEmailPasswords[clean] != password) {
            return AuthActionResult.Failure("ERROR_WRONG_PASSWORD", AuthErrorMapper.mapCodeToArabic("ERROR_WRONG_PASSWORD"))
        }
        requireRecentLoginOnDelete = false
        return AuthActionResult.Success(_authStateFlow.value, "تمت إعادة المصادقة")
    }

    override suspend fun signOut(): AuthActionResult {
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم تسجيل الخروج")
    }

    override suspend fun deleteCurrentAccount(): AuthActionResult {
        val user = _authStateFlow.value ?: return AuthActionResult.Failure("NO_ACTIVE_SESSION", "لا توجد جلسة")
        if (requireRecentLoginOnDelete) {
            return AuthActionResult.RequiresRecentLogin("حذف الحساب", "يرجى إعادة تأكيد هويتك قبل الحذف")
        }
        registeredEmailPasswords.remove(user.email)
        registeredUsers.remove(user.email)
        _authStateFlow.value = null
        return AuthActionResult.Success(null, "تم حذف الحساب")
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AuthPhase2Test {

    @get:Rule
    val composeRule = createComposeRule()

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `input validator enforces email format and password policy`() {
        assertNotNull(AuthInputValidator.validateEmail("bad-email"))
        assertNull(AuthInputValidator.validateEmail("Ali.Tawhid@Example.com"))

        val weakShort = AuthInputValidator.validatePasswordPolicy("abc1")
        assertFalse(weakShort.isValid)
        assertFalse(weakShort.hasMinLength)

        val noDigits = AuthInputValidator.validatePasswordPolicy("Abcdefgh")
        assertFalse(noDigits.isValid)
        assertFalse(noDigits.hasDigit)

        val withSpace = AuthInputValidator.validatePasswordPolicy("Abcd 1234")
        assertFalse(withSpace.isValid)
        assertFalse(withSpace.hasNoSpaces)

        val valid = AuthInputValidator.validatePasswordPolicy("StrongPass2026")
        assertTrue(valid.isValid)
        assertNull(valid.errorMessage)
    }

    @Test
    fun `error mapper provides Arabic messages for Firebase error codes`() {
        assertTrue(AuthErrorMapper.mapCodeToArabic("ERROR_INVALID_EMAIL").contains("البريد الإلكتروني"))
        assertTrue(AuthErrorMapper.mapCodeToArabic("ERROR_EMAIL_ALREADY_IN_USE").contains("مسجل مسبقاً"))
        assertTrue(AuthErrorMapper.mapCodeToArabic("ERROR_NETWORK_REQUEST_FAILED").contains("الشبكة"))
        assertTrue(AuthErrorMapper.mapCodeToArabic("ERROR_REQUIRES_RECENT_LOGIN").contains("إعادة المصادقة"))
        assertTrue(AuthErrorMapper.mapCodeToArabic("ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL").contains("مرتبط"))
    }

    @Test
    fun `email registration requires verification before verified state and supports reload`() = runTest(testDispatcher) {
        val gateway = FakeAuthGateway()
        val vm = AuthViewModel(authGateway = gateway)

        vm.setMode(AuthScreenMode.REGISTER)
        vm.updateDisplayName("أحمد علي")
        vm.updateEmail("ahmed@example.com")
        vm.updatePassword("Pass12345")
        vm.updateConfirmPassword("Pass12345")
        vm.registerWithEmail()
        advanceUntilIdle()

        val unverifiedUser = vm.uiState.value.currentUser
        assertNotNull(unverifiedUser)
        assertFalse(unverifiedUser!!.isAccountVerified)

        vm.resendVerificationEmail()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.statusMessage.orEmpty().contains("التحقق"))

        gateway.simulateEmailVerifiedAfterReload = true
        vm.refreshEmailVerificationStatus()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.currentUser!!.isAccountVerified)
    }

    @Test
    fun `email sign in handles wrong password throttling and password reset`() = runTest(testDispatcher) {
        val gateway = FakeAuthGateway()
        gateway.registerWithEmail("user@example.com", "Pass12345", "مستخدم")
        gateway.signOut()

        var nowMs = 1_000L
        val vm = AuthViewModel(authGateway = gateway, clockMs = { nowMs })

        vm.updateEmail("user@example.com")
        vm.updatePassword("Wrong9999")
        repeat(5) {
            vm.signInWithEmail()
            advanceUntilIdle()
        }
        assertEquals(5, vm.uiState.value.consecutiveFailures)

        // 6th attempt within cooldown is blocked locally
        vm.signInWithEmail()
        assertTrue(vm.uiState.value.errorMessage.orEmpty().contains("انتظار"))

        // Advance past 30s cooldown and sign in with valid password
        nowMs += 31_000L
        vm.updatePassword("Pass12345")
        vm.signInWithEmail()
        advanceUntilIdle()
        assertNotNull(vm.uiState.value.currentUser)
        assertEquals(0, vm.uiState.value.consecutiveFailures)

        // Password reset
        vm.sendPasswordReset()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.statusMessage.orEmpty().contains("إعادة التعيين"))
    }

    @Test
    fun `change password, google sign in, sign out, and delete with reauth work cleanly`() = runTest(testDispatcher) {
        val gateway = FakeAuthGateway()
        val vm = AuthViewModel(authGateway = gateway)

        vm.signInWithGoogleIdTokenDirect("sample-google-id-token")
        advanceUntilIdle()
        assertEquals("uid-google-1", vm.uiState.value.currentUser?.uid)
        assertTrue(vm.uiState.value.currentUser!!.isAccountVerified)

        // Sign out
        vm.signOut()
        advanceUntilIdle()
        assertNull(vm.uiState.value.currentUser)

        // Register email user, change password, test delete requiring recent login
        vm.setMode(AuthScreenMode.REGISTER)
        vm.updateDisplayName("سارة")
        vm.updateEmail("sara@example.com")
        vm.updatePassword("OldPass123")
        vm.updateConfirmPassword("OldPass123")
        vm.registerWithEmail()
        advanceUntilIdle()

        vm.updateChangePasswordInputs(
            currentPassword = "OldPass123",
            newPassword = "NewPass456",
            confirmNewPassword = "NewPass456",
        )
        vm.changePassword()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.statusMessage.orEmpty().contains("تحديث كلمة المرور"))

        gateway.requireRecentLoginOnDelete = true
        vm.deleteAccount()
        advanceUntilIdle()
        assertNotNull(vm.uiState.value.requiresRecentLoginOperation)
        assertNotNull(vm.uiState.value.currentUser)

        vm.reauthenticateWithEmail("NewPass456")
        advanceUntilIdle()
        assertNull(vm.uiState.value.requiresRecentLoginOperation)

        vm.deleteAccount()
        advanceUntilIdle()
        assertNull(vm.uiState.value.currentUser)
    }

    @Test
    fun `firebase auth gateway degrades safely when google-services json is absent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val gateway = FirebaseAuthGateway(context)
        val status = gateway.configurationStatus()
        assertFalse(status.isGoogleServicesConfigured)
        assertNull(gateway.currentUser())
        assertTrue(status.statusMessage.contains("google-services.json"))
    }

    @Test
    @Config(sdk = [34], qualifiers = "w411dp-h915dp")
    fun `auth screen renders Arabic branding, Google button, Email modes, and legal links`() {
        val gateway = FakeAuthGateway(initialConfigured = false)
        val vm = AuthViewModel(authGateway = gateway)

        composeRule.setContent {
            ReportManagerTheme {
                AuthScreen(
                    viewModel = vm,
                    onBack = {},
                    onContinueLocally = {},
                    onOpenPrivacyPolicy = {},
                )
            }
        }
        testDispatcher.scheduler.advanceUntilIdle()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("auth_brand_title").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_config_notice_card").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_google_continue_btn").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_email_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_password_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_forgot_password_link").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_privacy_policy_link").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_terms_link").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("auth_mode_register_chip").performScrollTo().performClick()
        testDispatcher.scheduler.advanceUntilIdle()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("auth_name_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("auth_confirm_password_input").performScrollTo().assertIsDisplayed()
    }
}
